// Bridge mouse-input checks. Extracts the real worker script and command
// plumbing out of local-bridge/server.cjs (no HTTP server is started) and
// proves the two things that were actually broken:
//   1. the generated PowerShell script must PARSE (the old builder joined the
//      lines with "; ", producing "switch ($p[0]) {;" and a worker that died
//      on start-up while the bridge still answered ok:true);
//   2. a worker answer of `err ...` must never be turned into a success.
// Run:  npm run test:bridge
const fs = require('fs')
const os = require('os')
const path = require('path')
const { spawnSync } = require('child_process')

const source = fs.readFileSync(path.join(__dirname, '..', 'local-bridge', 'server.cjs'), 'utf8')
let failures = 0
const check = (name, ok, detail) => {
  if (ok) {
    console.log('  ok -', name)
    return
  }
  failures += 1
  console.error('  FAIL -', name, detail ? '\n    ' + detail : '')
}

// ── the worker script ─────────────────────────────────────────────────────
const scriptStart = source.indexOf('function mouseWorkerScript()')
const scriptEnd = source.indexOf('function failPendingMouse')
check('mouseWorkerScript is present in the shipped bridge', scriptStart >= 0 && scriptEnd > scriptStart)
if (scriptStart < 0 || scriptEnd <= scriptStart) process.exit(1)
const mouseWorkerScript = new Function(source.slice(scriptStart, scriptEnd) + '\nreturn mouseWorkerScript')()
const worker = mouseWorkerScript()

check('the worker script is built with newlines, not "; " joins', !/;\s*function/.test(worker) && worker.includes('\n'))
check('the worker announces readiness before it reads commands',
  worker.includes('WriteLine("ready")') && worker.indexOf('WriteLine("ready")') < worker.indexOf('ReadLine()'))
check('every command is answered with "<seq> ok|err ..."',
  worker.includes('($seq + " " + $out)') && worker.includes('$out = ("err " + $_.Exception.Message)'))
check('the wheel constants are the real ones (0x0800 wheel, 0x1000 hwheel, not 0x0100)',
  worker.includes('0x0800') && worker.includes('0x1000') && !worker.includes('0x0100'))
check('absolute move reports the position the cursor actually reached',
  worker.includes('[System.Windows.Forms.Cursor]::Position = New-Object') && /return \('ok ' \+ \$c\.X/.test(worker))
check('the virtual desktop is read from the worker, not assumed',
  worker.includes('[System.Windows.Forms.SystemInformation]::VirtualScreen'))

// The real regression test: PowerShell's own parser on the generated file.
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jarvis-mouse-'))
const scriptPath = path.join(dir, 'worker.ps1')
const checkerPath = path.join(dir, 'check.ps1')
fs.writeFileSync(scriptPath, worker, 'ascii')
fs.writeFileSync(checkerPath, [
  'param([string]$Path)',
  '$errors = $null',
  '[void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$null, [ref]$errors)',
  'if ($errors.Count -gt 0) {',
  '  foreach ($e in $errors) { [Console]::Error.WriteLine("line " + $e.Extent.StartLineNumber + ": " + $e.Message) }',
  '  exit 1',
  '}',
  'Write-Output "PARSE OK"',
  ''
].join('\n'), 'ascii')
const parsed = spawnSync('powershell.exe', [
  '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', checkerPath, scriptPath
], { encoding: 'utf8', timeout: 30000 })
check('the generated PowerShell script parses cleanly',
  parsed.status === 0 && /PARSE OK/.test(String(parsed.stdout || '')),
  String(parsed.stderr || parsed.stdout || parsed.error || '').trim())

// Negative control: the parse gate must actually catch the bug it exists for,
// otherwise this whole check could pass on any text at all. The old builder fed
// a switch-based worker through a "; " join, which was a parse error:
//   "switch ($p[0]) {; 'move' { ... } }"  ->  Missing condition in switch
// statement clause.  The worker died on start-up while the bridge kept
// answering ok:true, which is why the cursor never moved.
const brokenPath = path.join(dir, 'broken.ps1')
fs.writeFileSync(brokenPath, "switch ($p[0]) {; 'move' { 'ok' }; 'ping' { 'pong' }}\n", 'ascii')
const broken = spawnSync('powershell.exe', [
  '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', checkerPath, brokenPath
], { encoding: 'utf8', timeout: 30000 })
check('the parse gate rejects the "; "-joined switch that silently killed the worker',
  broken.status !== 0 && /Missing condition in switch/.test(String(broken.stderr || '')),
  'a malformed worker parsed cleanly, so this check proves nothing: ' + String(broken.stderr || broken.stdout || '').trim())
fs.rmSync(dir, { recursive: true, force: true })

// ── the command plumbing ──────────────────────────────────────────────────
// mouseCommand() is driven with a stubbed worker so the answer mapping is the
// shipped code, not a copy of it.
const commandStart = source.indexOf('function mouseCommand(')
const commandEnd = source.indexOf('async function desktopBounds()')
check('mouseCommand is present in the shipped bridge', commandStart >= 0 && commandEnd > commandStart)
if (commandStart < 0 || commandEnd <= commandStart) process.exit(1)

function makeBridge (answers) {
  const written = []
  const sandbox = {
    isWindows: true,
    mouseWorkerError: '',
    MOUSE_ACTIONS: new Set(['move', 'relmove', 'lclick', 'rclick', 'ldown', 'lup', 'scroll', 'hscroll', 'pos', 'ping', 'bounds']),
    MOUSE_ACK_TIMEOUT: 60,
    MOUSE_QUEUE_LIMIT: 24,
    mouseSeq: 0,
    mousePending: new Map(),
    getMouseWorker: () => ({
      stdin: {
        write (line) {
          written.push(line.trim())
          const seq = Number(line.trim().split(' ')[0])
          const pending = sandbox.mousePending.get(seq)
          if (!pending) return
          const answer = answers.length ? answers.shift() : null
          if (answer === null || answer === undefined) return // let it time out
          clearTimeout(pending.timer)
          sandbox.mousePending.delete(seq)
          pending.resolve(answer)
        }
      }
    })
  }
  const mouseCommand = new Function(
    'isWindows', 'getMouseWorker', 'MOUSE_ACTIONS', 'MOUSE_ACK_TIMEOUT', 'MOUSE_QUEUE_LIMIT', 'mousePending', 'mouseSeq',
    source.slice(commandStart, commandEnd) + '\nreturn mouseCommand'
  )(sandbox.isWindows, sandbox.getMouseWorker, sandbox.MOUSE_ACTIONS, sandbox.MOUSE_ACK_TIMEOUT,
    sandbox.MOUSE_QUEUE_LIMIT, sandbox.mousePending, sandbox.mouseSeq)
  return { mouseCommand, written, sandbox }
}

async function main () {
  {
    const bridge = makeBridge(['ok 640 432'])
    const result = await bridge.mouseCommand('move', [640, 432])
    check('a move reaches the worker with rounded integer arguments',
      bridge.written[0] === '1 move 640 432', bridge.written[0])
    check('a move reports where the cursor actually landed',
      result.ok === true && result.x === 640 && result.y === 432, JSON.stringify(result))
    check('the pending entry is cleared after the answer', bridge.sandbox.mousePending.size === 0)
  }
  {
    const bridge = makeBridge(['ok 1200 700'])
    const result = await bridge.mouseCommand('move', [-1920.4, 0])
    check('multi-monitor coordinates are rounded, not clamped',
      bridge.written[0] === '1 move -1920 0' && result.ok === true, bridge.written[0])
  }
  {
    const bridge = makeBridge(['err the PowerShell input worker is not answering'])
    const result = await bridge.mouseCommand('move', [10, 10])
    check('an "err" answer is NEVER reported as a success',
      result.ok === false && /not answering/.test(String(result.error)), JSON.stringify(result))
  }
  {
    const bridge = makeBridge(['pos 1200 700'])
    const result = await bridge.mouseCommand('pos')
    check('pos answers with the real cursor coordinates', result.ok === true && result.x === 1200 && result.y === 700, JSON.stringify(result))
  }
  {
    const bridge = makeBridge(['bounds -1920 0 3840 1080'])
    const result = await bridge.mouseCommand('bounds')
    check('bounds answers with the virtual desktop rectangle',
      result.ok === true && result.desktop.left === -1920 && result.desktop.width === 3840, JSON.stringify(result))
  }
  {
    const bridge = makeBridge(['pong'])
    const result = await bridge.mouseCommand('ping')
    check('ping is the readiness probe', result.ok === true && result.ready === true, JSON.stringify(result))
  }
  {
    const bridge = makeBridge(['ok'])
    const result = await bridge.mouseCommand('lclick')
    check('a click without a position is still a success', result.ok === true, JSON.stringify(result))
  }
  {
    const bridge = makeBridge([])
    const result = await bridge.mouseCommand('move', [5, 5])
    check('a silent worker times out into a failure, never a fake success',
      result.ok === false && /did not answer/.test(String(result.error)), JSON.stringify(result))
    check('the timed-out entry is dropped instead of leaking',
      bridge.sandbox.mousePending.size === 0)
  }
  {
    const bridge = makeBridge([])
    const result = await bridge.mouseCommand('teleport', [1, 1])
    check('an unknown action is refused before it reaches the worker',
      result.ok === false && bridge.written.length === 0, JSON.stringify(result))
  }
  {
    const bridge = makeBridge([])
    for (let i = 0; i < 30; i += 1) bridge.sandbox.mousePending.set(i, { timer: setTimeout(() => {}, 1000), resolve: () => {} })
    const result = await bridge.mouseCommand('move', [1, 1])
    for (const [, pending] of bridge.sandbox.mousePending) clearTimeout(pending.timer)
    check('the queue guard drops commands past the limit instead of queueing forever',
      result.ok === false && /behind/.test(String(result.error)), JSON.stringify(result))
  }

  if (failures) {
    console.error('BRIDGE MOUSE: %d failure(s)', failures)
    process.exit(1)
  }
  console.log('BRIDGE MOUSE: worker script parses and every answer is mapped honestly')
}

main().catch((error) => {
  console.error('BRIDGE MOUSE: test harness failed', error)
  process.exit(1)
})
