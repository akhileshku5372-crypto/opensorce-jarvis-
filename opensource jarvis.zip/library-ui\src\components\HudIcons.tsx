import React from 'react';

export const JarvisTargetIcon: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 36 36" fill="none" className={className}>
    <circle
      cx="18"
      cy="18"
      r="15"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeDasharray="16 6"
      className="text-cyan-400/80"
    />
    <circle
      cx="18"
      cy="18"
      r="10.5"
      stroke="currentColor"
      strokeWidth="2"
      className="text-cyan-300"
    />
    <circle cx="18" cy="18" r="4.5" fill="currentColor" className="text-cyan-300" />
    <circle cx="7" cy="9" r="1.2" fill="currentColor" className="text-cyan-200" />
  </svg>
);

export const SoftSkillsHeadIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className}>
    {/* Head Profile Outline */}
    <path
      d="M24 6C15.5 6 10 12 10 20C10 23.5 11.2 26.8 13 29.5L13 38H27L27 33H32C34.2 33 36 31.2 36 29V24L39 21L36 18C35.2 11 30.2 6 24 6Z"
      stroke="#22d3ee"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Internal Neural Nodes */}
    <circle cx="20" cy="15" r="1.8" fill="#67e8f9" />
    <circle cx="27" cy="14" r="1.8" fill="#67e8f9" />
    <circle cx="17" cy="21" r="1.8" fill="#67e8f9" />
    <circle cx="25" cy="21" r="2" fill="#22d3ee" />
    <circle cx="29" cy="20" r="1.5" fill="#67e8f9" />
    <path
      d="M20 15L27 14M20 15L17 21M20 15L25 21M27 14L25 21M17 21L25 21M25 21L29 20"
      stroke="#22d3ee"
      strokeWidth="1.2"
      strokeOpacity="0.8"
    />
  </svg>
);

export const HardSkillsGearIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 48 48" fill="none" className={className}>
    <path
      d="M21.5 6H26.5L27.6 10.2C29 10.7 30.3 11.5 31.5 12.4L35.6 11.1L38.1 15.4L35 18.5C35.4 19.9 35.6 21.5 35.6 23L38.1 26.1L35.6 30.4L31.5 29.1C30.3 30 29 30.8 27.6 31.3L26.5 35.5H21.5L20.4 31.3C19 30.8 17.7 30 16.5 29.1L12.4 30.4L9.9 26.1L13 23C13 21.5 13.2 19.9 13.6 18.5L10.5 15.4L13 11.1L17.1 12.4C18.3 11.5 19.6 10.7 21 10.2L21.5 6Z"
      stroke="#22d3ee"
      strokeWidth="2.2"
      strokeLinejoin="round"
      transform="translate(0, 3)"
    />
    <circle
      cx="24"
      cy="24"
      r="5.5"
      stroke="#67e8f9"
      strokeWidth="2.2"
    />
  </svg>
);

export const JarvisRobotAvatar: React.FC<{ className?: string; speaking?: boolean }> = ({
  className = 'w-14 h-14',
  speaking = false,
}) => (
  <div
    className={`relative rounded-full flex items-center justify-center bg-gradient-to-b from-cyan-500/30 via-[#0a223d] to-[#051020] border border-cyan-400/60 shadow-[0_0_20px_rgba(34,211,238,0.35)] ${
      speaking ? 'ring-2 ring-cyan-300 shadow-[0_0_28px_rgba(34,211,238,0.75)]' : ''
    } ${className}`}
  >
    <svg viewBox="0 0 56 56" fill="none" className="w-full h-full p-1.5">
      <defs>
        <radialGradient id="jarvisHeadGlow" cx="50%" cy="40%" r="55%">
          <stop offset="0%" stopColor="#67e8f9" stopOpacity="0.9" />
          <stop offset="55%" stopColor="#0284c7" stopOpacity="0.75" />
          <stop offset="100%" stopColor="#082f49" stopOpacity="0.95" />
        </radialGradient>
      </defs>
      {/* Shoulders / Neck */}
      <path
        d="M14 46C16 40 21 38 28 38C35 38 40 40 42 46"
        stroke="#38bdf8"
        strokeWidth="2"
        strokeLinecap="round"
      />
      {/* Robot Cranium */}
      <rect
        x="15"
        y="11"
        width="26"
        height="24"
        rx="11"
        fill="url(#jarvisHeadGlow)"
        stroke="#67e8f9"
        strokeWidth="1.6"
      />
      {/* Side Ear Nodes */}
      <rect x="11.5" y="20" width="3" height="7" rx="1.5" fill="#22d3ee" />
      <rect x="41.5" y="20" width="3" height="7" rx="1.5" fill="#22d3ee" />
      {/* Visor / Eyes */}
      <rect x="18.5" y="19" width="19" height="7" rx="3.5" fill="#04101f" />
      <circle
        cx="23.5"
        cy="22.5"
        r="2.2"
        fill="#67e8f9"
        className={speaking ? 'animate-ping' : ''}
      />
      <circle cx="23.5" cy="22.5" r="2.2" fill="#e0f2fe" />
      <circle
        cx="32.5"
        cy="22.5"
        r="2.2"
        fill="#67e8f9"
        className={speaking ? 'animate-ping' : ''}
      />
      <circle cx="32.5" cy="22.5" r="2.2" fill="#e0f2fe" />
      {/* Mouth Line */}
      <path
        d={speaking ? 'M23 30Q28 33 33 30' : 'M24 30H32'}
        stroke="#67e8f9"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  </div>
);

export const CpuSparkline: React.FC = () => (
  <svg viewBox="0 0 46 16" fill="none" className="w-11 h-4">
    <path
      d="M1 13L8 12L13 6L18 11L24 12L31 3L37 11L45 10"
      stroke="#22d3ee"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const GpuSparkline: React.FC = () => (
  <svg viewBox="0 0 46 16" fill="none" className="w-11 h-4">
    <path
      d="M1 12L9 13L15 9L22 10L28 7L34 10L41 3L45 4"
      stroke="#22d3ee"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
