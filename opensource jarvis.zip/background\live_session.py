"""Gemini Live duplex session - continuous, interruptible, speech-to-speech.

Why this exists: `speak()` in voice_engine.py builds the whole reply as one audio
file and hands it to ffplay, so a turn costs STT + LLM + TTS + file write before
any sound starts, and barge-in can only mean killing a process that is already
playing the whole sentence. The Live API inverts that: the microphone stream is
uploaded continuously, Google's server decides when a turn begins and ends, and
it speaks back as 24 kHz PCM chunks that we play as they land. When the user
talks over it, the server sends `interrupted` and we drop the queued audio.

The turn-detection / interruption logic is therefore deliberately NOT duplicated
here - the server owns it. This module only does: open a session, push 16 kHz
PCM, play 24 kHz PCM, react to `interrupted`.

Run standalone to hear it without any microphone:

    .venv/Scripts/python.exe background/live_session.py --smoke
"""

import argparse
import base64
import json
import os
import queue
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import wave
from pathlib import Path

RATE_IN = 16000           # what the Live API wants upstream
RATE_OUT = 24000          # what it sends back
CHUNK_SAMPLES = 1600      # 100 ms at 16 kHz
WS_URL = ("wss://generativelanguage.googleapis.com/ws/"
          "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent")

# The model that produced 6.7s of sarcastic native audio in the 2026-10-17 probe.
MODEL_DEFAULT = os.environ.get("JARVIS_LIVE_MODEL", "gemini-3.8-live")
VOICE_DEFAULT = os.environ.get("JARVIS_LIVE_VOICE", "Charon")

# Written for a duplex audio session, not a chat box: the server owns turn
# detection (see setup_frame), so the persona's job is brevity, interruption
# etiquette and spoken form - the three things that make Live sound like the
# movie rather than like a TTS reading a chatbot.
PERSONA_DEFAULT = os.environ.get(
    "JARVIS_LIVE_PERSONA",
    "You are J.A.R.V.I.S., the voice of this machine. You are not in a chat "
    "window: this is a live two-way audio session, he talks over you constantly "
    "and that is normal.\n\n"
    "TEMPERAMENT. Dry, composed, faintly amused British butler. Precise and "
    "understated. Never gushing, never chirpy for no reason, never panicked - "
    "including when something has failed. Call him \"sir\" at most once a turn. "
    "One deadpan remark per turn is welcome; two is showing off.\n\n"
    "LENGTH. One thought per turn. Two short sentences is the ideal, three is "
    "the ceiling. No preamble, no restating his question, never \"Certainly\", "
    "\"Absolutely\", \"Of course\" or \"Great question\", never introduce "
    "yourself, never mention being an AI or a model. If he interrupts, stop "
    "cleanly and continue from where he cut in - do not restart the sentence and "
    "never recap what you already said.\n\n"
    "SUBSTANCE. Result first, detail only if it changes what he does next. If "
    "you do not know, say you do not know in one line and stop. Never invent. "
    "Never hedge with \"probably\" about something you measured, and never claim "
    "you did a thing you did not do.\n\n"
    "SPOKEN FORM. This is audio. Never read out code, file paths, URLs or email "
    "addresses - say what they are instead. Say numbers the way a person says "
    "them. Keep his language: if he mixes Hindi and English, mix it back exactly "
    "the way he said it; Japanese stays Japanese.\n\n"
    "INITIATIVE. If his instruction is ambiguous in a way one short question "
    "fixes, ask it. Otherwise take the most sensible reading, act, and say in "
    "one line what you chose. When something you are watching goes wrong, say so "
    "as it happens - quietly, once, no alarm.\n\n"
    "TOOLS. You have real tools and you must use them instead of guessing or "
    "refusing. `jarvis_command` is the single action door and it reaches every "
    "installed JARVIS capability - open or close apps, media, volume, "
    "brightness, files, screenshots, system status, opening a specific WhatsApp "
    "chat by contact name, web search, research, reminders, schedules and "
    "multi-step tasks. `web_search` is for current facts you cannot know. "
    "`remember_fact` stores something he asks you to remember; `recall_memory` "
    "reads what you already know. Call the matching tool BEFORE you answer an "
    "action or live-data request, then answer from its result. If you think a "
    "capability is missing, call `jarvis_command` FIRST - never tell him you "
    "have no tool before the router itself says it cannot do it. Never invent a "
    "result.\n\n"
    "DESKTOP ACTIONS. `jarvis_command` is a runner, not you: it acknowledges, "
    "then the real result arrives as a line beginning with SYSTEM:. Until that "
    "line arrives, say only a short acknowledgment - \"On it, sir\" - and never "
    "say it is done, opened, sent or saved. SYSTEM: lines are the only ground "
    "truth about what happened; they are not a question, so do not answer "
    "them - say their content plainly, in your own voice, and never contradict "
    "them. If SYSTEM: says it failed or was refused, report it as a failure "
    "without dressing it up.\n\n"
    "SCREEN. You cannot see pixels by yourself. When he asks what is on the "
    "screen, asks you to read it, or asks what he is looking at, call "
    "`look_at_screen` before answering and answer only from its result. Never "
    "say you cannot see the screen without calling it first; it is one snapshot, "
    "so a question about a changing screen needs another call. For screen-grounded "
    "mouse and keyboard work - click, type, scroll, press keys, or a multi-step "
    "desktop task - call `jarvis_command` with his request; JARVIS's existing "
    "screen agent sees the screen, grounds the target, acts and verifies. If the "
    "result stages a confirmation, ask him to say confirm; when he does, call "
    "`jarvis_command` with exactly \"confirm\". Never self-confirm and never say "
    "a click, keystroke or task is done before the SYSTEM: result says so.\n\n"
    "MODE. If he asks to leave live or duplex mode, call `exit_live_mode` and "
    "say one short goodbye. Do not call it for anything else."
)


def _pin_ipv4():
    """Idempotent: voice_engine may already have patched this in-process.

    This host advertises AAAA records with no IPv6 route, so the default
    resolution order costs ~161s per connection and a WebSocket simply fails.
    """
    if getattr(socket.getaddrinfo, "_jarvis_ipv4", False):
        return
    real = socket.getaddrinfo

    def getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        if family in (0, socket.AF_INET6):
            family = socket.AF_INET
        return real(host, port, family, type, proto, flags)

    getaddrinfo._jarvis_ipv4 = True
    socket.getaddrinfo = getaddrinfo


def api_key():
    for name in ("GOOGLE_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY_2", "GEMINI_API_KEY_2"):
        val = (os.environ.get(name) or "").strip()
        if val:
            return val
    env_file = Path(__file__).resolve().parent.parent / ".dev.vars"
    if env_file.exists():
        wanted = ("GOOGLE_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY_2")
        for line in env_file.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, _, v = line.partition("=")
                if k.strip() in wanted and v.strip():
                    return v.strip().strip('"').strip("'")
    return ""


class Pcm24kPlayer:
    """Play 24 kHz PCM16 as it arrives, and flush on demand.

    A queue fed by the network reader and drained by a sounddevice callback means
    the first sound starts as soon as the first chunk lands, instead of waiting
    for the sentence to finish. `flush()` is what makes barge-in feel instant.
    """

    def __init__(self):
        self._q = queue.Queue()
        self._lock = threading.Lock()
        self._stream = None
        self._speaking = threading.Event()
        self._bytes_played = 0
        # Bumped on every flush: the callback owns a small pre-roll buffer, so
        # draining the queue alone would still play up to one audio block of
        # the sentence the user just interrupted.
        self._flush_gen = 0

    def _ensure_stream(self):
        if self._stream is not None:
            return True
        try:
            import numpy as np
            import sounddevice as sd
        except Exception as exc:
            print("[LIVE] audio output unavailable: %r" % (exc,), file=sys.stderr)
            return False
        state = {"buf": np.zeros(0, dtype=np.int16), "gen": self._flush_gen}

        def callback(outdata, frames, _time, status):
            if state["gen"] != self._flush_gen:
                state["buf"] = np.zeros(0, dtype=np.int16)
                state["gen"] = self._flush_gen
            while len(state["buf"]) < frames:
                try:
                    item = self._q.get_nowait()
                except queue.Empty:
                    item = None
                    break
                if item is None:
                    continue
                state["buf"] = np.concatenate((state["buf"], item))
            if not len(state["buf"]):
                outdata[:] = 0
                self._speaking.clear()
                return
            take = state["buf"][:frames]
            outdata[:len(take)] = take.reshape(-1, 1)
            outdata[len(take):] = 0
            state["buf"] = state["buf"][len(take):]
            self._bytes_played += len(take) * 2

        # 20 ms blocks: the default WASAPI block is ~100 ms, which is audible
        # lag on the first word and on a barge-in. The device may refuse this
        # size; fall back to its default rather than losing audio entirely.
        try:
            self._stream = sd.OutputStream(samplerate=RATE_OUT, channels=1,
                                           dtype="int16", blocksize=480,
                                           latency="low", callback=callback)
        except Exception:
            self._stream = sd.OutputStream(samplerate=RATE_OUT, channels=1,
                                           dtype="int16", callback=callback)
        self._stream.start()
        return True

    def feed(self, pcm_bytes):
        import numpy as np
        arr = np.frombuffer(pcm_bytes, dtype=np.int16)
        if not arr.size:
            return
        if not self._ensure_stream():
            return
        self._speaking.set()
        self._q.put(arr)

    def flush(self):
        """Drop everything queued - the user just spoke over us."""
        self._flush_gen += 1
        n = 0
        while True:
            try:
                self._q.get_nowait()
                n += 1
            except queue.Empty:
                break
        self._speaking.clear()
        return n

    @property
    def speaking(self):
        return self._speaking.is_set()

    def close(self):
        self.flush()
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None


class LiveSession:
    """One persistent duplex session. Reader thread owns all incoming frames."""

    def __init__(self, on_transcript=None, on_state=None, model=MODEL_DEFAULT,
                 voice=VOICE_DEFAULT, persona=PERSONA_DEFAULT, tools=None,
                 on_tool_call=None):
        self.model, self.voice, self.persona = model, voice, persona
        self.player = Pcm24kPlayer()
        self.on_transcript = on_transcript or (lambda who, text: None)
        self.on_state = on_state or (lambda **kw: None)
        self.on_tool_call = on_tool_call
        # Function declarations, in the shape the endpoint accepts inside
        # setup.tools[0].functionDeclarations. Measured 2026-10-20: a native
        # audio session accepts tools and returns a real toolCall frame.
        self.tools = list(tools or [])
        self.ws = None
        self._reader = None
        self._closing = threading.Event()
        self._reconnecting = threading.Event()
        self._send_lock = threading.Lock()
        self._resume_handle = ""
        self._reconnect_attempts = 0
        self._idle_ticks = 0
        self._audio_in = 0
        self._audio_out = 0
        self.last_first_audio_latency = None
        self._awaiting_first_audio = False
        self._turn_started_at = 0.0
        self._turn_audio = 0
        self._tool_turn = False
        self.connected_at = 0.0

    # ---------------------------------------------------------------- wire
    def setup_frame(self):
        # Bisected against the live endpoint on 2026-10-17: `model` +
        # `generationConfig.responseModalities=[AUDIO]` + the two transcription
        # blocks + `systemInstruction` + `generationConfig.speechConfig` all get
        # setupComplete. Putting `speechConfig` at setup level makes the server
        # close the socket with an empty frame; it belongs in generationConfig.
        #
        # `realtimeInputConfig` was re-tested on 2026-10-20 against
        # gemini-3.8-live: at SETUP level (not inside generationConfig) the
        # automaticActivityDetection block is accepted and a turn still
        # completes. Low start sensitivity stops the mic from treating JARVIS's
        # own speaker output as the user starting a turn; high end sensitivity
        # keeps the reply latency down. An earlier comment said this field was
        # rejected in every shape - that was a different probe, and it is not
        # true for this model.
        #
        # `tools` and `sessionResumption` are the two additions verified against
        # the live endpoint on 2026-10-20: tools produced a real toolCall, and a
        # handle from sessionResumptionUpdate resumed the same conversation in a
        # fresh socket. They are only added when actually used, so the minimal
        # frame stays the known-good default.
        setup = {
            "model": "models/" + self.model,
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {
                    "voiceName": self.voice}}},
            },
            "systemInstruction": {"parts": [{"text": self.persona}]},
            "inputAudioTranscription": {},
            "outputAudioTranscription": {},
            "realtimeInputConfig": {
                "automaticActivityDetection": {
                    "startOfSpeechSensitivity": "START_SENSITIVITY_LOW",
                    "endOfSpeechSensitivity": "END_SENSITIVITY_HIGH",
                    "prefixPaddingMs": 20,
                    "silenceDurationMs": 400,
                }
            },
        }
        if self.tools:
            setup["tools"] = [{"functionDeclarations": self.tools}]
        if self._resume_handle:
            setup["sessionResumption"] = {"handle": self._resume_handle}
        return {"setup": setup}

    def audio_frame(self, pcm_bytes_16k):
        # `realtimeInput.audio` is the field this endpoint actually reads.
        # Bisected 2026-10-17: `realtimeInput.mediaChunks` - which the SDK types
        # and the docs both list first - is accepted without error but silently
        # ignored: the server replies with nothing but sessionResumptionUpdate.
        # `audio` yielded 8.1s of native speech plus input/output transcriptions.
        return {"realtimeInput": {"audio": {
            "mimeType": "audio/pcm;rate=16000",
            "data": base64.b64encode(pcm_bytes_16k).decode("ascii")}}}

    def audio_end_frame(self):
        return {"realtimeInput": {"audioStreamEnd": True}}

    def text_frame(self, text):
        return {"clientContent": {"turns": [{"role": "user", "parts": [{"text": text}]}],
                                  "turnComplete": True}}

    def tool_response_frame(self, call_id, name, result):
        body = result if isinstance(result, dict) else {"result": str(result)}
        return {"toolResponse": {"functionResponses": [{
            "id": call_id, "name": name, "response": body}]}}

    def intake(self, frame):
        """Return (audio_bytes, in_text, out_text, interrupted, turn_complete)."""
        sc = frame.get("serverContent") or {}
        audio, otext = b"", ""

        def texts(content):
            if not isinstance(content, dict):
                return ""
            parts = "".join(p.get("text") or "" for p in (content.get("parts") or []))
            if parts:
                return parts
            # Recorded on a live duplex turn, 2026-10-20: the endpoint sends the
            # transcription as a bare {"text": ...} instead of the documented
            # parts list, so reading only parts dropped every transcript - JARVIS
            # spoke but the chat history and /state stayed empty.
            return content.get("text") or ""

        itext = texts(sc.get("inputTranscription"))
        for turn in filter(None, ((sc.get("modelTurn"),) + tuple(sc.get("chunks") or ()))):
            for part in (turn.get("parts") or []):
                inline = part.get("inlineData")
                if inline and inline.get("data"):
                    audio += base64.b64decode(inline["data"])
                elif part.get("text"):
                    otext += part["text"]
        otext += texts(sc.get("outputTranscription"))
        return audio, itext, otext, bool(sc.get("interrupted")), bool(sc.get("turnComplete"))

    # ------------------------------------------------------------- session
    def open(self, timeout=15.0):
        self._closing.clear()
        self._resume_handle = ""
        self._reconnect_attempts = 0
        self._idle_ticks = 0
        if not self._connect(timeout):
            return False
        self._reader = threading.Thread(target=self._read_loop, daemon=True,
                                        name="jarvis-live-reader")
        self._reader.start()
        self.on_state(stage="live_ready", voice_mode="live", last_error="")
        return True

    def _connect(self, timeout=15.0):
        """Open one socket and complete setup. Safe to call again to resume."""
        import websocket
        key = api_key()
        if not key:
            self.on_state(stage="live_error", last_error="No GOOGLE_API_KEY for Live")
            return False
        _pin_ipv4()
        self._close_ws()
        try:
            ws = websocket.create_connection(
                "%s?key=%s" % (WS_URL, key), timeout=timeout,
                sslopt={"cert_reqs": ssl.CERT_REQUIRED})
        except Exception as exc:
            self.on_state(stage="live_error",
                          last_error="Live connect failed: %s" % type(exc).__name__)
            return False
        self.ws = ws
        self.connected_at = self.connected_at or time.monotonic()
        try:
            ws.send(json.dumps(self.setup_frame()))
            deadline = time.monotonic() + max(10.0, timeout)
            first = None
            while time.monotonic() < deadline:
                raw = ws.recv()
                if not raw:
                    continue
                try:
                    frame = json.loads(raw)
                except Exception:
                    continue
                if "setupComplete" in (frame.get("serverContent") or frame):
                    first = frame
                    break
                if frame.get("goAway") or frame.get("error"):
                    first = frame
                    break
            if first is None:
                self.on_state(stage="live_error", last_error="Live setup timed out")
                self._close_ws()
                return False
            if "setupComplete" not in (first.get("serverContent") or first):
                self.on_state(stage="live_error",
                              last_error="Live setup rejected: %s" % json.dumps(first)[:180])
                self._close_ws()
                return False
            # Idle keepalive after setup: a quiet session must not be mistaken
            # for a dead one. The reader keeps reading and pings after 30s.
            ws.settimeout(5.0)
            return True
        except Exception as exc:
            self.on_state(stage="live_error",
                          last_error="Live setup unread: %s" % type(exc).__name__)
            self._close_ws()
            return False

    def _close_ws(self):
        ws, self.ws = self.ws, None
        if ws is not None:
            try:
                ws.close()
            except Exception:
                pass

    def _reconnect(self, reason):
        """Resume the same conversation on a fresh socket, up to 3 tries.

        Gemini closes a Live session with a goAway frame before it expires; the
        same path handles a dead TCP socket. The handle from
        sessionResumptionUpdate is what makes the conversation continue instead
        of starting over.
        """
        if self._closing.is_set() or self._reconnecting.is_set():
            return False
        self._reconnect_attempts += 1
        if self._reconnect_attempts > 3:
            return False
        self._reconnecting.set()
        try:
            time.sleep(min(2.0, 0.4 * self._reconnect_attempts))
            self.on_state(stage="live_reconnecting",
                          last_error="Live reconnecting: %s" % reason)
            self._close_ws()
            if not self._connect(10.0):
                return False
            self._reconnect_attempts = 0
            self.on_state(stage="live_ready", voice_mode="live", last_error="")
            return True
        finally:
            self._reconnecting.clear()

    def _send_json(self, frame):
        if not self.ws or self._closing.is_set():
            return False
        with self._send_lock:
            try:
                self.ws.send(json.dumps(frame))
                return True
            except Exception:
                return False

    def _handle_tool_call(self, payload):
        calls = payload.get("functionCalls") or []
        if calls:
            # A tool-call turn is not a spoken turn: the model will answer after
            # the toolResponse. Suppress the premature live_turn_done so the
            # bridge records ONE exchange (user line + final reply), not two.
            self._tool_turn = True
        for call in calls:
            if not isinstance(call, dict):
                continue
            name = str(call.get("name") or "")
            call_id = str(call.get("id") or "")
            args = call.get("args") if isinstance(call.get("args"), dict) else {}
            self.on_state(stage="live_tool", tool=name)
            if not self.on_tool_call:
                self._send_json(self.tool_response_frame(
                    call_id, name, {"ok": False, "error": "tool unavailable"}))
                continue
            threading.Thread(target=self._run_tool,
                             args=(call_id, name, args), daemon=True,
                             name="jarvis-live-tool").start()

    def _run_tool(self, call_id, name, args):
        try:
            result = self.on_tool_call(name, args)
        except Exception as exc:
            result = {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
        if self._closing.is_set():
            return
        # The model is waiting on this response; a dropped one would leave the
        # turn hanging until its own timeout, so a failure is reported as text.
        if self._send_json(self.tool_response_frame(call_id, name, result)):
            self._turn_started_at = time.monotonic()
            self._awaiting_first_audio = True
            self._turn_audio = 0
            self.last_first_audio_latency = None

    def _read_loop(self):
        import websocket
        while not self._closing.is_set():
            ws = self.ws
            if ws is None:
                if self._reconnect("no socket"):
                    continue
                self.on_state(stage="live_lost", last_error="Live socket is gone")
                return
            try:
                raw = ws.recv()
            except websocket.WebSocketTimeoutException:
                self._idle_ticks += 1
                if self._idle_ticks % 6 == 0:
                    try:
                        ws.ping("jarvis-keepalive")
                    except Exception:
                        pass
                if self._idle_ticks < 24:       # 2 minutes of true silence
                    continue
                if self._reconnect("idle timeout"):
                    self._idle_ticks = 0
                    continue
                self.on_state(stage="live_lost",
                              last_error="Live socket idle for 2 minutes")
                return
            except Exception as exc:
                if self._closing.is_set():
                    return
                if self._reconnect("socket died: %s" % type(exc).__name__):
                    continue
                self.on_state(stage="live_lost",
                              last_error="Live socket died: %s" % type(exc).__name__)
                return
            self._idle_ticks = 0
            if not raw:
                continue
            try:
                frame = json.loads(raw)
            except Exception:
                continue
            if not frame:
                continue                     # the endpoint's own keepalive
            update = frame.get("sessionResumptionUpdate") or {}
            if update.get("newHandle"):
                self._resume_handle = str(update["newHandle"])
            if frame.get("goAway"):
                # Expiry is not a failure: resume before the server closes us.
                self.on_state(stage="live_expiring")
                if self._reconnect("goAway"):
                    continue
                self.on_state(stage="live_lost",
                              last_error="Live session expired and could not resume")
                return
            if "error" in frame:
                self.on_state(stage="live_error",
                              last_error=json.dumps(frame["error"])[:200])
                continue
            if frame.get("toolCall"):
                self._handle_tool_call(frame["toolCall"])
                continue
            if frame.get("toolCallCancellation"):
                self._tool_turn = False
                self.on_state(stage="live_tool_cancelled")
                continue
            audio, itext, otext, interrupted, complete = self.intake(frame)
            activity = (frame.get("serverContent") or {}).get("voiceActivity")
            if activity:
                # The server's own VAD telling us speech started/stopped. Kept as
                # a state signal so the UI can show "listening" without a client
                # side energy gate - and so a "it did not hear me" report can be
                # answered with evidence instead of a guess.
                act = str(activity.get("activity") or "").upper()
                self.on_state(stage="live_activity",
                              activity=act or str(list(activity)[:3]))
                if "START" in act:
                    self._turn_started_at = time.monotonic()
                    self._awaiting_first_audio = True
                    self._turn_audio = 0
                    self.last_first_audio_latency = None
            if itext.strip() and not self._turn_started_at:
                self._turn_started_at = time.monotonic()
                self._awaiting_first_audio = True
            if interrupted:
                dropped = self.player.flush()
                self._awaiting_first_audio = False
                self.on_state(stage="live_barge_in", dropped_chunks=dropped)
            if audio:
                if self._awaiting_first_audio and self._turn_started_at:
                    self.last_first_audio_latency = time.monotonic() - self._turn_started_at
                    self._awaiting_first_audio = False
                self._turn_audio += len(audio)
                self._audio_out += len(audio)
                self.player.feed(audio)
            if itext.strip():
                self.on_transcript("user", itext.strip())
            if otext.strip():
                self.on_transcript("jarvis", otext.strip())
            if complete:
                if self._tool_turn:
                    # The turn that only requested a tool is done; the spoken
                    # answer is still coming. Do not close the exchange yet, even
                    # if the model added a short spoken acknowledgment.
                    self._tool_turn = False
                    self._turn_started_at = 0.0
                    self._awaiting_first_audio = False
                    self._turn_audio = 0
                    continue
                self._tool_turn = False
                self.on_state(stage="live_turn_done",
                              first_audio_s=(round(self.last_first_audio_latency, 2)
                                             if self.last_first_audio_latency else None))
                self._turn_started_at = 0.0
                self._awaiting_first_audio = False
                self._turn_audio = 0

    def send_pcm(self, pcm_16k):
        if self._closing.is_set():
            return False
        # A reconnect is a gap, not a death. Returning False here would make the
        # bridge declare live_lost and hand the mic back for a 1-2s hiccup.
        if self._reconnecting.is_set() or self.ws is None:
            return True
        self._audio_in += len(pcm_16k)
        return self._send_json(self.audio_frame(pcm_16k))

    def send_text(self, text):
        """Used by the smoke test and for SYSTEM: action results."""
        if self._closing.is_set() or self._reconnecting.is_set() or not self.ws:
            return False
        self._turn_started_at = time.monotonic()
        self._awaiting_first_audio = True
        self._turn_audio = 0
        self.last_first_audio_latency = None
        return self._send_json(self.text_frame(text))

    def feed_wav_16k(self, path):
        """Stream a 16 kHz mono WAV into the session at real time."""
        with wave.open(str(path), "rb") as w:
            assert w.getnchannels() == 1 and w.getframerate() == RATE_IN, \
                "smoke clip must be 16 kHz mono PCM16"
            raw = w.readframes(w.getnframes())
        self.last_first_audio_latency = None
        step = CHUNK_SAMPLES * 2
        sent = 0
        for i in range(0, len(raw) - step, step):
            self._turn_started_at = self._turn_started_at or time.monotonic()
            if i == 0:
                self._awaiting_first_audio = True
            self.send_pcm(raw[i:i + step])
            sent += 1
            time.sleep(step / 2 / RATE_IN)          # real-time pacing
        self._turn_started_at = self._turn_started_at or time.monotonic()
        self._awaiting_first_audio = True
        return sent

    def close(self):
        self._closing.set()
        self._close_ws()
        self.player.close()
        reader, self._reader = self._reader, None
        if reader is not None and reader is not threading.current_thread():
            reader.join(timeout=2.0)

    def stats(self):
        return {"model": self.model, "voice": self.voice,
                "audio_up_bytes": self._audio_in, "audio_down_bytes": self._audio_out,
                "first_audio_s": (round(self.last_first_audio_latency, 2)
                                  if self.last_first_audio_latency else None),
                "session_s": round(time.monotonic() - self.connected_at, 1)
                if self.connected_at else None}


# ------------------------------------------------------------------ smoke
def _make_smoke_clip(text, out_wav):
    """edge-tts -> ffmpeg -> 16 kHz mono WAV, so the smoke test needs no mic."""
    import asyncio
    mp3 = Path(tempfile.gettempdir()) / "jarvis_smoke.mp3"

    async def synth():
        import edge_tts
        await edge_tts.Communicate(text, os.environ.get("JARVIS_VOICE_EN",
                                                        "en-GB-RyanNeural")).save(str(mp3))

    asyncio.run(asyncio.wait_for(synth(), 40))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp3),
                    "-ar", str(RATE_IN), "-ac", "1", str(out_wav)],
                   check=True, capture_output=True, timeout=60)
    return out_wav


def smoke():
    print("[smoke] building a spoken question without touching the microphone...")
    wav = Path(tempfile.gettempdir()) / "jarvis_smoke_16k.wav"
    asked = "Jarvis, what do you make of my code today?"
    _make_smoke_clip(asked, wav)
    print("[smoke] clip ready: %s (%d bytes)" % (wav.name, wav.stat().st_size))

    def on_transcript(who, text):
        print("  [%s] %s" % (who, text))

    def on_state(**kw):
        print("  <state> %s" % kw)

    s = LiveSession(on_transcript=on_transcript, on_state=on_state)
    t0 = time.monotonic()
    if not s.open():
        print("[smoke] FAILED to open a session - see the live_error above")
        return 1
    print("[smoke] session open in %.1fs (%s)" % (time.monotonic() - t0, s.model))
    n = s.feed_wav_16k(wav)
    print("[smoke] streamed %d chunks of speech -> letting the server answer" % n)
    # The mic never stops streaming, so the server's VAD hears the pause that
    # ends a turn. A file does not, so fake trailing silence in real time.
    #
    # Do NOT send realtimeInput.audioStreamEnd here: measured 2026-10-20, the
    # endpoint answers it with two bytes / no turn, which made this harness
    # report a false failure while a live mic turn worked. `audioStreamEnd` is
    # only for closing a stream, and a Live session deliberately keeps it open.
    silence = b"\x00\x00" * CHUNK_SAMPLES
    for _ in range(20):
        s.send_pcm(silence)
        time.sleep(CHUNK_SAMPLES / RATE_IN)
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline and not s._audio_out:
        time.sleep(0.2)
    st = s.stats()
    print("[smoke] %s" % st)
    if st["audio_down_bytes"]:
        secs = st["audio_down_bytes"] / (RATE_OUT * 2)
        print("[smoke] HEARD BACK: %.1fs of 24 kHz native audio, first chunk in %ss"
              % (secs, st["first_audio_s"]))
    else:
        print("[smoke] no audio came back - see the <state> lines above")
    while s.player.speaking and time.monotonic() < deadline:
        time.sleep(0.2)
    s.close()
    return 0 if st["audio_down_bytes"] else 1


def mic_run(seconds=None):
    """Talk to the Live model directly, without touching voice_engine.py.

    This is the evaluation harness: if this does not feel like Android Gemini,
    there is no point merging it into the 9k-line core. Ctrl+C to stop.
    """
    import numpy as np
    import sounddevice as sd

    q = queue.Queue()

    def callback(indata, frames, _t, status):
        if status:
            print("[mic] %s" % status, file=sys.stderr)
        q.put(indata.copy())

    s = LiveSession(
        on_transcript=lambda who, text: print("  %s %s" % (
            "YOU   " if who == "user" else "JARVIS", text)),
        on_state=lambda **kw: print("  <state> %s" % kw))
    if not s.open():
        print("[live] no session - check GOOGLE_API_KEY in .dev.vars")
        return 1
    rate = RATE_IN
    for attempt in (RATE_IN, 48000, 44100):
        try:
            with sd.InputStream(samplerate=attempt, channels=1, dtype="int16",
                                blocksize=512, callback=callback) as stream:
                rate = attempt
                print("[live] mic OPEN at %d Hz - just talk, no button. Ctrl+C stops."
                      % attempt, flush=True)
                t0 = time.monotonic()
                while True:
                    if seconds and time.monotonic() - t0 > seconds:
                        return 0
                    chunk = q.get() if not q.empty() else None
                    if chunk is None:
                        time.sleep(0.01)
                        continue
                    pcm = chunk.reshape(-1).astype(np.int16).tobytes()
                    if rate != RATE_IN:
                        step = rate // RATE_IN if rate % RATE_IN == 0 else None
                        arr = np.frombuffer(pcm, dtype=np.int16)
                        if step and step > 1:
                            pcm = arr[step - 1::step].tobytes()
                        else:
                            out_n = int(len(arr) * RATE_IN / rate)
                            idx = (np.arange(out_n) * rate / RATE_IN).astype(int)
                            pcm = arr[idx.clip(0, len(arr) - 1)].tobytes()
                    if not s.send_pcm(pcm):
                        print("[live] socket gone while streaming")
                        return 1
        except Exception as exc:
            print("[live] device refused %d Hz (%s)" % (attempt, type(exc).__name__))
            continue
    print("[live] no usable microphone rate")
    return 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true",
                    help="prove the duplex path with a synthesised clip, no mic")
    ap.add_argument("--mic", action="store_true",
                    help="talk to the Live model now, bypassing voice_engine")
    ap.add_argument("--seconds", type=float, default=0.0,
                    help="with --mic: stop after this many seconds (for checks)")
    ap.add_argument("--say", default="", help="ask this text instead of a clip")
    a = ap.parse_args()
    if a.mic:
        raise SystemExit(mic_run(a.seconds or None))
    if a.say:
        sess = LiveSession(on_transcript=lambda w, t: print("[%s] %s" % (w, t)),
                           on_state=lambda **k: print("<state>", k))
        if sess.open():
            sess.send_text(a.say)
            time.sleep(12)
            print(sess.stats())
            while sess.player.speaking:
                time.sleep(0.2)
            sess.close()
    else:
        raise SystemExit(smoke())
