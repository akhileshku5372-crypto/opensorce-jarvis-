﻿$root = "c:\Users\PRATEEK\Downloads\jarvis 1.0.5"
# .kokoro-env is a pip --target install (Lib\site-packages only; no venv Scripts).
# Run it with the uv-managed CPython 3.11 + PYTHONPATH into its site-packages.
$env:PYTHONPATH = Join-Path $root ".kokoro-env\Lib\site-packages"
$py = "C:\Users\PRATEEK\AppData\Roaming\uv\python\cpython-3.11.16-windows-x86_64-none\python.exe"
$out = Join-Path $root "_kokoro_out.log"
$err = Join-Path $root "_kokoro_err.log"
# Kill any stale kokoro engine, then relaunch with console output captured.
$procs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'kokoro_podcast\.py' -and $_.ProcessId -ne $PID }
foreach ($p in $procs) {
  Write-Output ("Stopping kokoro PID " + $p.ProcessId)
  Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Seconds 2
Start-Process -FilePath $py -ArgumentList '"C:\Users\PRATEEK\Downloads\jarvis 1.0.5\background\kokoro_podcast.py"' -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err
Write-Output "Kokoro engine relaunched (logs: _kokoro_out.log / _kokoro_err.log)."
Start-Sleep -Seconds 6
try {
  $h = Invoke-RestMethod -Uri 'http://127.0.0.1:7779/health' -TimeoutSec 8
  Write-Output ("HEALTH: " + ($h | ConvertTo-Json -Compress))
} catch {
  Write-Output ("HEALTH REQUEST FAILED: " + $_.Exception.Message)
}