"""Regression tests for the WhatsApp desktop driver's honesty contract.

The bug this pins down: the old `autosend_to()` name path returned success because no
exception was raised - it never checked which chat was open and never checked that the
message left. A user was told "message bhej diya" when nothing was sent, and a failed
search could paste into whichever chat happened to be open.

These tests need no WhatsApp and no screen: every UIA object is a fake.
"""
import importlib.util
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


WA = _load("whatsapp_desktop")


class Rect:
    def __init__(self, left=0, top=0, right=100, bottom=100):
        self.left, self.top, self.right, self.bottom = left, top, right, bottom
        self.width = lambda: right - left
        self.height = lambda: bottom - top


class Info:
    def __init__(self, control_type, runtime_id):
        self.control_type = control_type
        self.runtime_id = runtime_id


class El:
    def __init__(self, control_type, name="", rect=None, rid=None, clicks=None):
        self.element_info = Info(control_type, rid or (control_type, name))
        self._name = name
        self._rect = rect or Rect()
        self.clicks = clicks if clicks is not None else []
        self._selected = False

    def window_text(self):
        return self._name

    def rectangle(self):
        return self._rect

    def click_input(self):
        self.clicks.append(self._name)

    def invoke(self):
        """The UIA Invoke pattern - what the staged attachment's send button
        answers to without any keyboard focus (measured live)."""
        self.clicks.append("invoke:" + self._name)

    def type_keys(self, keys, **kw):
        """Emulate a real editable control.

        The driver clears with {END}+{BACKSPACE} and then PASTES (measured: typing
        drops characters in the real WebView2 box), and it refuses to press Enter
        unless the text can be read back. A fake that just appended the raw key
        string could not model that, so the behaviour is modelled properly here.
        """
        self.clicks.append("keys:" + keys)
        if keys == "{ENTER}":
            # A real composer is emptied by a successful send; the driver reads the
            # composer after Enter to tell "sent" apart from "still sitting there".
            self._sent = getattr(self, "_sent", "") + str(self._name)
            self._name = ""
            return
        if keys == "^a":
            self._selected = True
            return
        if keys == "^v":
            try:
                import pyperclip
                pasted = pyperclip.paste()
            except Exception:
                pasted = ""
            self._name = pasted or self._name
            self._selected = False
            return
        if keys == "{END}":
            return
        if keys == "{BACKSPACE}":
            self._name = self._name[:-1]
            return
        if self._selected:
            self._name = keys
            self._selected = False
            return
        self._name = self._name + keys

    def set_edit_text(self, text):
        """The UIA ValuePattern write - the driver's PRIMARY input path.

        Measured live: this reaches the WebView2 search box and message box with NO
        keyboard focus at all, which is what makes sends work while the IDE keeps
        stealing the foreground.
        """
        self._name = text
        self.clicks.append("value:" + str(text)[:20])


class FakeWin:
    def __init__(self, elems, rect=None):
        self._elems = elems
        self._rect = rect or Rect(0, 0, 1000, 900)

    def rectangle(self):
        return self._rect

    def descendants(self):
        return list(self._elems)


# ------------------------------------------------------------------ pure logic
class NameMatchingTest(unittest.TestCase):
    def test_norm_kills_nbsp_emoji_and_case(self):
        self.assertEqual(WA.norm("Comfort\xa0zone \U0001F602"), "comfort zone")
        self.assertEqual(WA.norm("  Vishesh  "), "vishesh")

    def test_norm_keeps_devanagari_and_kana(self):
        self.assertEqual(WA.norm("विशेष"), "विशेष")
        self.assertEqual(WA.norm("こんにちは"), "こんにちは")

    def test_prefix_and_exact_score_high(self):
        self.assertEqual(WA.score("comfort", "Comfort zone Akhilesh, Kushagra"), 1.0)
        self.assertEqual(WA.score("vishesh", "Vishesh"), 1.0)

    def test_unrelated_chat_scores_below_the_refuse_threshold(self):
        preview = "Study In Japan 1:15 pm 1 unread message General ~Shayan Bera : \U0001F602"
        self.assertLess(WA.score("general", WA.norm(preview)), 1.0)
        self.assertLess(WA.score("vishesh", preview), WA.MIN_MATCH,
                        "a wrong chat must never clear the bar")
        self.assertLess(WA.score("comfort zone", "Vishesh Yesterday then levi launcher"),
                        WA.MIN_MATCH)

    def test_empty_inputs_score_zero(self):
        self.assertEqual(WA.score("", "anything"), 0.0)
        self.assertEqual(WA.score("name", ""), 0.0)


class ComposerTargetingTest(unittest.TestCase):
    def test_search_box_is_never_the_composer(self):
        search = El("Edit", "Search or start a new chat", Rect(100, 300, 300, 340))
        box = El("Edit", "\n", Rect(1400, 860, 1800, 890))
        win = FakeWin([search, box])
        found = WA._composer(win)
        self.assertIs(found, box, "typing a message into search would only search")

    def test_missing_composer_is_reported(self):
        self.assertIsNone(WA._composer(FakeWin([El("Edit", "Search or start a new chat")])))

    def test_text_in_composer_requires_the_actual_text(self):
        box = El("Edit", "Namaste, main JARVIS hoon")
        self.assertTrue(WA._text_in_composer(box, "Namaste, main JARVIS hoon"))
        self.assertFalse(WA._text_in_composer(El("Edit", ""), "Namaste"))

    def test_type_keys_metacharacters_are_escaped(self):
        self.assertEqual(WA._escape("a+b"), "a{+}b")
        self.assertIn("{^}", WA._escape("^"))


class HeaderIdentificationTest(unittest.TestCase):
    def test_header_returns_the_open_chat_not_the_nav_buttons(self):
        # Geometry is the REAL one measured on this machine: the nav rail sits at
        # y=245 and the chat header at y=247, i.e. the header is BELOW the nav row.
        # A single top band would return "Chats" or "New chat".
        win = FakeWin([
            El("Button", "Chats", Rect(254, 245, 304, 295)),
            El("Button", "Menu", Rect(515, 247, 566, 297)),
            El("Button", "New chat", Rect(575, 247, 626, 297)),
            El("Button", "Resize the chat list panel", Rect(650, 232, 681, 282)),
            El("Button", "Profile details", Rect(670, 247, 740, 297)),
            El("Button", "Comfort zone Akhilesh, Kushagra, Vivek, You",
               Rect(743, 257, 945, 307)),
            El("Button", "Video call", Rect(942, 247, 992, 297)),
            El("Button", "Voice call", Rect(1012, 247, 1062, 297)),
            El("Button", "Search", Rect(1082, 247, 1132, 297)),
            El("DataGrid", "Chat list", Rect(320, 529, 638, 900)),
            El("Edit", "Search or start a new chat", Rect(405, 327, 561, 353)),
        ], Rect(239, 185, 1221, 935))
        self.assertEqual(WA.header_chat(win),
                         "Comfort zone Akhilesh, Kushagra, Vivek, You")

    def test_word_matched_hints_do_not_swallow_a_real_contact_name(self):
        # Regression, measured live 2026-10-19: the hint "all" was matched as a
        # SUBSTRING, and "Vivek Gautam (Ballu)" contains "all", so the real chat
        # name was filtered out and header_chat() returned "" - the chat was
        # open and the composer was found, yet the send refused as unverifiable.
        self.assertTrue(WA._is_hint("chats"))
        self.assertTrue(WA._is_hint("video call"))
        self.assertFalse(WA._is_hint("vivek gautam ballu"))

    def test_a_contact_subtitle_is_not_part_of_the_chat_name(self):
        # WhatsApp appends "click here for contact info" to contacts with no
        # saved name. Those words are UI chrome; comparing them against the
        # requested name made a CORRECT match score below the refuse threshold.
        self.assertEqual(WA._strip_header_suffix(
            "Vivek Gautam (Ballu) click here for contact info"),
            "Vivek Gautam (Ballu)")
        self.assertEqual(WA._strip_header_suffix("Akhilesh click here for contact info"),
                         "Akhilesh")
        self.assertTrue(WA._header_matches(
            "vivek ballu", "Vivek Gautam (Ballu) click here for contact info"))
        self.assertFalse(WA._header_matches(
            "akhilesh", "Vivek Gautam (Ballu) click here for contact info"))

    def test_no_header_element_returns_empty_string(self):
        self.assertEqual(WA.header_chat(FakeWin([El("Button", "Chats", Rect(0, 0, 10, 10))],
                                                Rect(0, 0, 100, 100))), "")

    # The geometry below is the REAL one measured on this machine on 2026-10-19:
    # window top=76, nav rail y=137, chat header y=150, splitter x=650. Both rules
    # were added after the old "first unfiltered element in the top 90px" test was
    # seen returning the nav rail ('Chats') and the window title text ('WhatsApp'),
    # which made every send fail verification as "wrong chat khuli".
    def test_measured_geometry_finds_the_header_not_the_nav_rail(self):
        win = FakeWin([
            El("Text", "WhatsApp", Rect(295, 89, 365, 110)),
            El("Button", "Chats", Rect(254, 135, 304, 185)),
            El("Button", "Menu", Rect(515, 137, 566, 187)),
            El("Button", "New chat", Rect(575, 137, 626, 187)),
            El("Button", "Resize the chat list panel", Rect(650, 122, 681, 172)),
            El("Button", "Profile details", Rect(670, 137, 740, 187)),
            El("Button", "Bhavishya- Jlpt5- Haryana", Rect(739, 150, 912, 200)),
            El("Button", "Video call", Rect(942, 137, 992, 187)),
            El("Button", "Voice call", Rect(1012, 137, 1062, 187)),
            El("Button", "Search", Rect(1082, 137, 1132, 187)),
        ], Rect(239, 76, 1221, 816))
        self.assertEqual(WA.header_chat(win), "Bhavishya- Jlpt5- Haryana")

    def test_the_splitter_button_is_not_mistaken_for_a_chat_name(self):
        # "Resize the chat list panel" sits at x=650, just right of the chat-list
        # DataGrid (right edge 638) and inside the header band, so geometry alone
        # cannot exclude it - only the name filter can.
        win = FakeWin([
            El("DataGrid", "Chat list", Rect(320, 529, 638, 900)),
            El("Button", "Resize the chat list panel", Rect(650, 122, 681, 172)),
        ], Rect(239, 76, 1221, 816))
        self.assertEqual(WA.header_chat(win), "")

    def test_nav_row_alone_yields_no_header(self):
        # No chat is open: the nav rail is all that exists, and inventing a name
        # from it would claim the wrong chat is open.
        win = FakeWin([
            El("Button", "Chats", Rect(254, 135, 304, 185)),
            El("Button", "New chat", Rect(575, 137, 626, 187)),
            El("Button", "Search", Rect(1082, 137, 1132, 187)),
        ], Rect(239, 76, 1221, 816))
        self.assertEqual(WA.header_chat(win), "")


class SearchBoxDiscoveryTest(unittest.TestCase):
    """The box's accessible NAME becomes its text once something is typed."""

    def test_placeholder_is_found_when_empty(self):
        win = FakeWin([El("Edit", "Search or start a new chat", Rect(405, 217, 561, 243))],
                      Rect(239, 76, 1221, 816))
        self.assertEqual(WA._search_box(win).window_text(),
                         "Search or start a new chat")

    def test_box_is_still_found_after_a_previous_search(self):
        # Regression: matching the placeholder alone meant the box was found once
        # and never again, so the second send of a session could not even search.
        win = FakeWin([El("Edit", "AkhileshVishesh", Rect(405, 217, 561, 243))],
                      Rect(239, 76, 1221, 816))
        self.assertIsNotNone(WA._search_box(win))

    def test_the_single_edit_is_never_confused_with_a_composer(self):
        # With no chat open there is exactly one Edit; with a chat open there are
        # two and only the placeholder-named one is the search field.
        win = FakeWin([
            El("Edit", "Search or start a new chat", Rect(405, 217, 561, 243)),
            El("Edit", "Akhilesh typed here", Rect(600, 760, 1200, 800)),
        ], Rect(239, 76, 1221, 816))
        self.assertEqual(WA._search_box(win).window_text(),
                         "Search or start a new chat")


class DeduplicationTest(unittest.TestCase):
    def test_webview_mirroring_collapses_to_one(self):
        same = ("DataItem", "row")
        elems = [El("DataItem", "Comfort zone", rid=same),
                 El("DataItem", "Comfort zone", rid=same),
                 El("DataItem", "Comfort zone", rid=same),
                 El("DataItem", "Vishesh", rid=("DataItem", "other"))]
        self.assertEqual(len(WA._uniq(elems)), 2,
                         "mirrored nodes must not turn one click into three")


# ------------------------------------------------------- the honesty contract
class NeverClaimsASendThatDidNotHappenTest(unittest.TestCase):
    def setUp(self):
        self.orig = (WA.available, WA._window, WA.open_chat, WA._preview_contains,
                     WA._ensure_foreground, WA._foreground_is_whatsapp, WA._app_frame,
                     WA._app_window_open)
        WA.available = lambda: (True, "ready")
        WA._window = lambda restore=True: FakeWin([])
        # These tests must never touch the real desktop. The driver now asserts that
        # the app owns the keyboard before it presses Enter (an Enter typed into the
        # IDE would be a real side effect), and on a machine where WhatsApp really is
        # running that check would raise the real window from inside a unit test.
        WA._ensure_foreground = lambda timeout=4.0: True
        WA._foreground_is_whatsapp = lambda: True
        WA._app_frame = lambda: 0
        WA._app_window_open = lambda: True
        self.addCleanup(self._restore)

    def _restore(self):
        (WA.available, WA._window, WA.open_chat, WA._preview_contains,
         WA._ensure_foreground, WA._foreground_is_whatsapp, WA._app_frame,
         WA._app_window_open) = self.orig

    def test_refuses_when_the_chat_could_not_be_verified(self):
        """The exact user complaint: 'bhej diya' while nothing was sent."""
        WA.open_chat = lambda name: (False, "", "wrong chat khuli - message NAHI bheja")
        ok, said = WA.send("Vishesh", "Namaste")
        self.assertFalse(ok, "an unverified chat must never report success")
        self.assertIn("NAHI bheja", said)

    def test_refuses_when_the_preview_never_shows_the_message(self):
        WA.open_chat = lambda name: (True, "Vishesh", "verified")
        box = El("Edit", "\n", Rect(1400, 860, 1800, 890))
        WA._composer_backup = WA._composer
        WA._composer = lambda win: box
        WA._preview_contains = lambda chat, text: False
        try:
            ok, said = WA.send("Vishesh", "Namaste testing honesty")
        finally:
            WA._composer = WA._composer_backup
        self.assertFalse(ok, "no preview proof means no claim of delivery")
        self.assertIn("confirm NAHI", said)
        self.assertIn("keys:{ENTER}", box.clicks, "it did press send, it just cannot prove it")

    def test_reports_success_only_with_preview_proof(self):
        WA.open_chat = lambda name: (True, "Vishesh", "verified")
        box = El("Edit", "Namaste from JARVIS", Rect(1400, 860, 1800, 890))
        WA._composer_backup = WA._composer
        WA._composer = lambda win: box
        WA._preview_contains = lambda chat, text: True
        try:
            ok, said = WA.send("Vishesh", "Namaste from JARVIS")
        finally:
            WA._composer = WA._composer_backup
        self.assertTrue(ok)
        self.assertIn("verify", said)

    def test_empty_message_is_refused_before_any_click(self):
        WA.open_chat = lambda name: (True, "Vishesh", "verified")
        ok, said = WA.send("Vishesh", "   ")
        self.assertFalse(ok)
        self.assertIn("khaali", said)

    def test_unavailable_app_says_so_instead_of_pretending(self):
        WA.available = lambda: (False, "WhatsApp desktop app band hai")
        ok, opened, why = WA.open_chat("Vishesh")
        self.assertFalse(ok)
        self.assertIn("band", why)


class TheSearchPickMustSettleTest(unittest.TestCase):
    """Measured live 2026-10-19: the row click opened the GROUP "Comfort zone".

    The owner asked for "Akhilesh"; the name also exists inside a group subtitle
    ("Comfort zone Akhilesh, Kushagra, Vivek, You") and inside other chats' message
    previews, and WhatsApp fills the search results in asynchronously. So the first
    row that merely CONTAINED the name cleared the bar and was clicked while the
    list was still moving. Both halves are regression-tested here.
    """

    def test_a_name_inside_a_preview_or_group_subtitle_never_matches(self):
        self.assertLess(
            WA.score("akhilesh", "Comfort zone Akhilesh, Kushagra, Vivek, You"),
            WA.MIN_MATCH, "a group subtitle is not the contact")
        self.assertLess(
            WA.best_row_score("akhilesh",
                              "Kushagra New No. 31/07/2026 Akhilesh bol raha tha"),
            WA.MIN_MATCH, "a message preview is not the contact")

    def test_a_real_name_still_matches_inside_a_short_title(self):
        # The bonus is for chat NAMES: "Ballu" vs "Vivek Gautam (Ballu)".
        self.assertGreaterEqual(WA.score("ballu", "Vivek Gautam (Ballu)"), 0.95)
        self.assertGreaterEqual(WA.best_row_score(
            "vivek ballu", "Vivek Gautam (Ballu) 14/08/2026 Teri baat"), WA.MIN_MATCH)

    def test_a_group_subtitle_is_not_part_of_the_group_name(self):
        self.assertEqual(WA._strip_header_suffix("Comfort zone click here for group info"),
                         "Comfort zone")

    def test_a_group_member_list_is_not_a_match_for_a_members_name(self):
        # The header of an open group lists its MEMBERS. Accepting a name inside that
        # list is what would turn a group click into a message to everyone.
        self.assertFalse(WA._header_matches(
            "akhilesh", "Comfort zone Akhilesh, Kushagra, Vivek, You"))
        self.assertTrue(WA._header_matches("comfort zone",
                                            "Comfort zone Akhilesh, Kushagra, You"))

    def _open_with_rounds(self, rounds, header, wait=6.0):
        """Drive open_chat against a chat list that changes between polls."""
        win = FakeWin([], Rect(300, 100, 1200, 1000))
        calls = {"n": 0}

        def _rows(_win):
            i = min(calls["n"], len(rounds) - 1)
            calls["n"] += 1
            return rounds[i]

        saved = (WA.available, WA._ensure_app_window, WA._window, WA._search_box,
                 WA._type_search, WA._ensure_foreground, WA._chat_rows,
                 WA.header_chat, WA._ui_window_handles, WA._point_reaches,
                 WA.OPEN_WAIT_S)
        WA.OPEN_WAIT_S = wait
        WA.available = lambda: (True, "ready")
        WA._ensure_app_window = lambda timeout=8.0: (True, "")
        WA._window = lambda restore=True: win
        WA._search_box = lambda w: El("Edit", "Search or start a new chat")
        WA._type_search = lambda box, name: (True, name)
        WA._ensure_foreground = lambda timeout=4.0: True
        WA._chat_rows = _rows
        WA.header_chat = lambda w: header
        WA._ui_window_handles = lambda: []
        WA._point_reaches = lambda hwnd, x, y: True
        try:
            return WA.open_chat("akhilesh")
        finally:
            (WA.available, WA._ensure_app_window, WA._window, WA._search_box,
             WA._type_search, WA._ensure_foreground, WA._chat_rows,
             WA.header_chat, WA._ui_window_handles, WA._point_reaches,
             WA.OPEN_WAIT_S) = saved

    def test_a_moving_result_list_is_never_clicked_mid_flight(self):
        # Round 1 is the not-yet-filtered list (the only passing row is a decoy),
        # rounds 2 and 3 are the real, settled result.
        decoy = El("DataItem", "Kushagra New No. Akhilesh", Rect(300, 900, 620, 960))
        real = El("DataItem", "Akhilesh 12:32 pm Photo", Rect(300, 480, 620, 540))
        rounds = [[("Kushagra New No. Akhilesh", decoy)],
                  [("Akhilesh 12:32 pm Photo", real)],
                  [("Akhilesh 12:32 pm Photo", real)]]
        ok, opened, why = self._open_with_rounds(rounds, "Akhilesh click here for contact info")
        self.assertTrue(ok, why)
        self.assertEqual(decoy.clicks, [], "a row seen while the list moves is never clicked")
        self.assertEqual(real.clicks, ["Akhilesh 12:32 pm Photo"])
        self.assertEqual(opened, "Akhilesh")

    def test_a_list_that_never_settles_is_refused(self):
        a = El("DataItem", "Akhilesh 12:32 pm Photo", Rect(300, 480, 620, 540))
        b = El("DataItem", "Akhilesh 12:32 pm Photo", Rect(300, 900, 620, 960))
        # The same row keeps moving every poll - WhatsApp result lists do animate.
        rounds = [[("Akhilesh 12:32 pm Photo", a)], [("Akhilesh 12:32 pm Photo", b)]] * 6
        ok, opened, why = self._open_with_rounds(
            rounds, "Akhilesh click here for contact info", wait=1.2)
        self.assertFalse(ok, "a list that keeps moving must never be clicked")
        self.assertEqual(a.clicks + b.clicks, [])
        self.assertEqual(opened, "")
        self.assertIn("badal", why)


class LiveMeasuredBehaviourTest(unittest.TestCase):
    """Regressions found while sending real test messages (2026-10-19).

    Each of these was found by actually driving the owner's WhatsApp, not by
    reading the code: the search box, the composer and the delivery proof all
    misbehaved once the app had real state in it.
    """

    def test_composer_is_found_by_position_not_by_being_empty(self):
        # The old rule skipped any Edit whose name was longer than 3 characters,
        # which only holds for an UNTOUCHED composer. Once text was typed the
        # accessible name became that text and the composer could not be found at
        # all - every send after the first failed and left half-typed text behind.
        win = FakeWin([
            El("Edit", "vivek ballu", Rect(875, 264, 1031, 290)),
            El("Edit", "elloSir,mainJARVIShoon.Yesirfektestmes",
               Rect(1250, 785, 1614, 841)),
        ], Rect(709, 123, 1691, 863))
        self.assertIsNotNone(WA._composer(win),
                             "the composer must be found even when it has text")

    def test_search_box_is_found_even_when_it_holds_text(self):
        # Same failure as the composer: with a chat open there are two Edits and
        # the search field's name is whatever was typed into it, not the
        # placeholder.
        win = FakeWin([
            El("Edit", "vishesh", Rect(875, 264, 1031, 290)),
            El("Edit", "\n", Rect(1250, 785, 1614, 841)),
        ], Rect(709, 123, 1691, 863))
        self.assertIsNotNone(WA._search_box(win))

    def test_a_row_with_a_date_tail_still_matches_its_name(self):
        # "Vivek Gautam (Ballu) 14/09/2026" scored 55% against "vivek ballu" and
        # was refused; the real name is still the same contact.
        row = "Vivek Gautam (Ballu) 14/09/2026"
        self.assertLess(WA.score("vivek ballu", row), 0.62)
        self.assertGreaterEqual(WA.best_row_score("vivek ballu", row), 0.62)

    def test_delivery_proof_accepts_the_header_with_its_contact_subtitle(self):
        # The header reads "Akhilesh click here for contact info" while the
        # chat-list row reads "Akhilesh 12:22 pm ...". Requiring the whole header
        # reported a FAILURE for a message that demonstrably went out.
        rows = [("Akhilesh 12:22 pm Hello Sir, main JARVIS hoon. Ye sirf ek test "
                 "message hai.", None),
                ("Vishesh 12:20 pm Hello Sir, main JARVIS hoon.", None)]
        win = FakeWin([El("DataItem", nm, Rect(790, 426, 1108, 522))
                       for nm, _ in rows], Rect(709, 123, 1691, 863))
        backup = WA._window
        WA._window = lambda *a, **k: win
        try:
            self.assertTrue(WA._preview_contains(
                "Akhilesh click here for contact info",
                "Hello Sir, main JARVIS hoon. Ye sirf ek test message hai."))
            # A message that is NOT in the preview must never count as delivered.
            self.assertFalse(WA._preview_contains(
                "Akhilesh click here for contact info", "koi aur message"))
        finally:
            WA._window = backup

    def test_the_verify_step_does_not_trust_a_dropped_prefix(self):
        # Typing dropped leading characters ("Hello Sir" arrived as "elloSir").
        # A prefix-only check passes that, so head, middle and tail are all
        # required.
        box = El("Edit", "elloSir main JARVIS hoon Ye test")
        self.assertFalse(WA._text_in_composer(box, "Hello Sir main JARVIS hoon Ye test"))
        good = El("Edit", "Hello Sir main JARVIS hoon Ye test")
        self.assertTrue(WA._text_in_composer(good, "Hello Sir main JARVIS hoon Ye test"))


class TheAppWindowAndTheKeyboardTest(unittest.TestCase):
    """Regressions from the real runtime failure the owner hit on 2026-10-19.

    The core logged 'search box me vishesh nahi likh paaya (usme do hai)'. Measured
    live, the cause was not the typing at all:

      * the Windows Store build keeps running with its window CLOSED, and the UIA
        tree (and every old check) still answers, so nothing could be typed or
        clicked while the code believed the app was fine;
      * the window the old code drove carries ex-style
        LAYERED|TOOLWINDOW|NOACTIVATE, so it can never be activated - the real frame
        is the WinUIDesktopWin32WindowClass window, and ShowWindow(SW_RESTORE) on
        THAT is what brings the app back on screen (measured: IsWindowVisible
        False -> True);
      * the IDE takes the foreground about once a second, so keystrokes must be
        gated on the app really owning the keyboard - otherwise the message is
        typed into the user's own editor;
      * the message box ignores the UIA ValuePattern while the search box honours
        it, so the two boxes need different mechanisms.

    Everything here is a fake: no WhatsApp, no screen.
    """

    def test_the_row_click_counts_the_app_frame_as_whatsapp(self):
        # WindowFromPoint at a chat row returns the FRAME's own child
        # (Microsoft.UI.Content.Desktop). Accepting only the WebView2 window refused
        # a click that would have hit the app and reported a covering window.
        saved = (WA._app_frame, WA._hit_test, WA._owns)
        WA._app_frame = lambda: 111
        WA._hit_test = lambda x, y: 222
        WA._owns = lambda target, hit: target == 111 and hit == 222
        try:
            self.assertTrue(WA._point_reaches(999, 10, 10),
                            "a point on the app frame IS a point on WhatsApp")
        finally:
            WA._app_frame, WA._hit_test, WA._owns = saved

    def test_the_row_click_is_refused_when_another_window_covers_it(self):
        saved = (WA._app_frame, WA._hit_test, WA._owns)
        WA._app_frame = lambda: 111
        WA._hit_test = lambda x, y: 333          # somebody else's window
        WA._owns = lambda target, hit: False
        try:
            self.assertFalse(WA._point_reaches(999, 10, 10),
                             "clicking a covered window must never be attempted")
        finally:
            WA._app_frame, WA._hit_test, WA._owns = saved

    def test_the_search_box_is_filled_without_a_single_keystroke(self):
        """The ValuePattern reaches the search box with NO keyboard focus.

        That is what made the name search work while the IDE kept stealing the
        keyboard: the old clear+paste typed into whatever was in front.
        """
        search = El("Edit", "Search or start a new chat", Rect(875, 264, 1031, 290))
        composer = El("Edit", "\n", Rect(1250, 785, 1614, 841))
        win = FakeWin([search, composer], Rect(709, 123, 1691, 863))
        saved = WA._window
        WA._window = lambda *a, **k: win
        try:
            ok, got = WA._type_search(None, "vishesh")
        finally:
            WA._window = saved
        self.assertTrue(ok, got)
        self.assertEqual(got.strip(), "vishesh")
        self.assertEqual([c for c in search.clicks if c.startswith("keys:")], [],
                         "the search box must not need a keystroke")

    def test_the_composer_falls_back_to_the_keyboard_when_the_pattern_is_ignored(self):
        """Measured: the message box reports ValuePattern support and ignores it.

        So "supported" must never be the reason to skip the keyboard - the live send
        failed with "message composer me theek se nahi dikha (usme '\\n' hai)".
        """
        class DeafBox(El):
            def set_edit_text(self, text):
                pass                              # exactly what the real composer does

        box = DeafBox("Edit", "\n", Rect(1250, 785, 1614, 841))
        saved = (WA._foreground_is_whatsapp, WA._ensure_foreground, WA._focus_box,
                 WA._clipboard_put)
        WA._foreground_is_whatsapp = lambda: True
        WA._ensure_foreground = lambda timeout=4.0: True
        WA._focus_box = lambda b: True

        def _put_clipboard(text):
            box._name = text                      # what the fake box shows after ^v
            try:
                import pyperclip
                pyperclip.copy(text)
            except Exception:
                pass
            return True

        WA._clipboard_put = _put_clipboard
        try:
            ok, why = WA._put_message(lambda: box, "Namaste Sir")
        finally:
            (WA._foreground_is_whatsapp, WA._ensure_foreground, WA._focus_box,
             WA._clipboard_put) = saved
        self.assertTrue(ok, why)
        self.assertEqual(box.window_text(), "Namaste Sir")

    def test_nothing_is_typed_when_whatsapp_does_not_own_the_keyboard(self):
        box = El("Edit", "\n", Rect(1250, 785, 1614, 841))
        saved = (WA._foreground_is_whatsapp, WA._ensure_foreground)
        WA._foreground_is_whatsapp = lambda: False
        WA._ensure_foreground = lambda timeout=4.0: False
        try:
            ok, _got, why = WA._keyboard_write(lambda: box, "Namaste")
        finally:
            WA._foreground_is_whatsapp, WA._ensure_foreground = saved
        self.assertFalse(ok)
        self.assertTrue(why, "a refusal must say why")
        self.assertEqual(box.window_text(), "\n", "nothing may be typed")
        self.assertEqual([c for c in box.clicks if c.startswith("keys:")], [],
                         "not one keystroke may go to whatever window is in front")

    def test_a_hidden_app_window_is_restored_before_anything_else(self):
        saved = (WA._app_window_open, WA._reveal, WA._ui_window_handles)
        state = {"open": False}
        WA._app_window_open = lambda: state["open"]
        WA._ui_window_handles = lambda: [(4242, "(8) WhatsApp", "Chrome_WidgetWin_1")]

        def _reveal(hwnd, tries=3):
            state["open"] = True                  # the real ShowWindow(SW_RESTORE)
            return True

        WA._reveal = _reveal
        try:
            ok, why = WA._ensure_app_window(timeout=0.2)
        finally:
            WA._app_window_open, WA._reveal, WA._ui_window_handles = saved
        self.assertTrue(ok, why)

    def test_an_app_window_that_will_not_open_is_reported_honestly(self):
        saved = (WA._app_window_open, WA._reveal, WA._ui_window_handles)
        WA._app_window_open = lambda: False
        WA._ui_window_handles = lambda: [(4242, "(8) WhatsApp", "Chrome_WidgetWin_1")]
        WA._reveal = lambda hwnd, tries=3: False
        try:
            ok, why = WA._ensure_app_window(timeout=0.1)
        finally:
            WA._app_window_open, WA._reveal, WA._ui_window_handles = saved
        self.assertFalse(ok)
        self.assertIn("WhatsApp", why)
        self.assertNotIn("bhej diya", why)

    def test_a_transient_uia_walk_hit_is_retried_instead_of_failing_the_send(self):
        """Measured live 2026-10-19: a send failed with a bare "KeyError: None".

        pywinauto raises it while walking the WebView2 tree - a stale element makes
        it look up known_control_type_ids[CurrentControlType] with None - and
        WhatsApp rebuilds that tree every time the search filter changes.
        """

        class FlakyWin:
            def __init__(self):
                self.calls = 0

            def descendants(self):
                self.calls += 1
                if self.calls == 1:
                    raise KeyError(None)
                return [El("DataItem", "Akhilesh 12:32 pm Photo")]

        win = FlakyWin()
        got = WA._descendants(win)
        self.assertEqual(len(got), 1, "the retry must return the real tree")
        self.assertEqual(win.calls, 2)

    def test_a_tree_that_never_answers_is_empty_and_never_a_fake_success(self):
        class DeadWin:
            def descendants(self):
                raise KeyError(None)

        self.assertEqual(WA._descendants(DeadWin()), [])

    def test_open_chat_refuses_when_the_app_window_cannot_be_opened(self):
        saved = (WA.available, WA._ensure_app_window)
        WA.available = lambda: (True, "ready")
        WA._ensure_app_window = lambda timeout=8.0: (
            False, "WhatsApp ki window background me band thi aur khul nahi paayi")
        try:
            ok, opened, why = WA.open_chat("vishesh")
        finally:
            WA.available, WA._ensure_app_window = saved
        self.assertFalse(ok)
        self.assertEqual(opened, "")
        self.assertIn("window", why)

    def test_the_app_frame_is_the_winui_window_and_not_the_webview_helper(self):
        """The frame search must name the class, not just the title.

        Measured: two top-level windows are titled "(8) WhatsApp"/"WhatsApp"; the one
        to drive is the WinUIDesktopWin32WindowClass frame owned by WhatsApp.Root.exe,
        because the WebView2 one is LAYERED|TOOLWINDOW|NOACTIVATE and cannot be
        activated or raised at all.
        """
        source = (ROOT / "background" / "whatsapp_desktop.py").read_text(encoding="utf-8")
        self.assertIn("WinUIDesktopWin32WindowClass", source)
        self.assertIn("_ensure_app_window", source)
        self.assertIn("IsWindowVisible", source)


class SendFileTest(unittest.TestCase):
    """The media flow: paste a FILE, require the measured preview signals, and
    never claim a send without the chat-list row proof.

    Live measured 2026-10-19: a pasted CF_HDROP file stages an attachment strip
    whose Button names the file ("Open photo, x.png, item 1 of 1") next to a
    "Send 1 selected" button; invoke() sends it and the chat-list row changes
    to "<time> Photo". Every test here drives send_file() through fakes that
    model exactly those signals.
    """

    def setUp(self):
        tmp = Path(tempfile.mkdtemp(prefix="wa_sendfile_"))
        self.addCleanup(shutil.rmtree, tmp, ignore_errors=True)
        self.FILE = str(tmp / "report.png")
        Path(self.FILE).write_bytes(b"p" * 10)
        self.rows = {"now": "Akhilesh 2:55 pm M"}
        self.staged = {"on": False}
        self.copied = []
        self.discarded = []
        self.opened = []
        self.box = PasteBox("Edit", "\n", Rect(1400, 860, 1800, 890), self.staged)
        self.preview = El("Button", "Open photo, report.png, item 1 of 1",
                          Rect(1100, 700, 1400, 740))
        self.send = SendButton("Button", "Send 1 selected",
                               Rect(1500, 700, 1600, 740), self.staged, self.rows)
        self.remove = El("Button", "Remove attachment",
                         Rect(1480, 690, 1520, 710))
        self._saved = (WA.available, WA._window, WA.open_chat, WA._composer,
                       WA._foreground_is_whatsapp, WA._ensure_foreground,
                       WA._row_preview, WA._clear_any, WA.ATTACH_WAIT_S,
                       WA.SEND_WAIT_S, WA.whatsapp_media.copy_file)
        WA.available = lambda: (True, "ready")
        WA.open_chat = lambda name: (self.opened.append(name),
                                     (True, "Akhilesh", "verified: Akhilesh"))[1]
        WA._composer = lambda win: self.box
        WA._foreground_is_whatsapp = lambda: True
        WA._ensure_foreground = lambda timeout=4.0: True
        WA._clear_any = lambda box_factory: ""
        WA.ATTACH_WAIT_S = 0.3
        WA.SEND_WAIT_S = 0.3
        WA._row_preview = lambda name: self.rows["now"]
        WA.whatsapp_media.copy_file = lambda path: (
            self.copied.append(str(path)), True)[1]
        self.addCleanup(self._restore)

    def _restore(self):
        (WA.available, WA._window, WA.open_chat, WA._composer,
         WA._foreground_is_whatsapp, WA._ensure_foreground,
         WA._row_preview, WA._clear_any, WA.ATTACH_WAIT_S,
         WA.SEND_WAIT_S, WA.whatsapp_media.copy_file) = self._saved

    def _window(self):
        elems = [self.box]
        if self.staged["on"]:
            elems += [self.preview, self.send, self.remove]
        return FakeWin(elems, Rect(0, 0, 1000, 900))

    def _run(self):
        WA._window = lambda restore=True: self._window()
        WA._discard_attachment_backup = WA._discard_attachment
        WA._discard_attachment = lambda win, box_factory: (
            self.discarded.append("discarded"),
            WA._discard_attachment_backup(win, box_factory))[1]
        try:
            return WA.send_file("Akhilesh", self.FILE)
        finally:
            WA._discard_attachment = WA._discard_attachment_backup

    def test_reports_success_only_with_the_row_proof(self):
        self.send.sends = True
        ok, said = self._run()
        self.assertTrue(ok)
        self.assertIn("verify", said)
        self.assertIn("photo", said)
        self.assertEqual(self.copied, [self.FILE])
        self.assertIn("invoke:Send 1 selected", self.send.clicks,
                      "the staged send button is pressed by invoke, not clicks")
        self.assertIn("keys:^v", self.box.clicks)
        self.assertEqual(self.opened, ["Akhilesh"])

    def test_no_preview_means_nothing_sent_and_nothing_staged(self):
        self.box.stages = False          # the paste happens, the app never stages
        ok, said = self._run()
        self.assertFalse(ok)
        self.assertIn("kuch nahi bheja", said)
        self.assertEqual(self.copied, [self.FILE], "the file was copied, the app "
                                                  "just never staged it")
        self.assertNotIn("invoke:Send 1 selected", self.send.clicks)
        self.assertTrue(self.discarded, "a half-staged paste is never left behind")

    def test_the_row_must_change_before_ok(self):
        self.send.sends = False          # invoke happens, but the row stays put
        self.staged["on"] = True
        ok, said = self._run()
        self.assertFalse(ok)
        self.assertTrue(self.discarded, "an attachment that never left is removed")

    def test_the_row_moving_without_media_is_not_proof(self):
        # The row changed to a TEXT message preview instead of a media one -
        # that is not proof THIS file went out.
        self.send.sends = True
        self.send.row_after = "Akhilesh 3:02 pm hello"
        ok, said = self._run()
        self.assertFalse(ok)
        self.assertIn("confirm NAHI", said)

    def test_a_missing_file_is_refused_before_any_chat_is_opened(self):
        ok, said = WA.send_file("Akhilesh", r"C:\definitely\not\here.png")
        self.assertFalse(ok)
        self.assertEqual(self.opened, [], "no chat was opened for a file that "
                                          "does not exist")
        self.assertIn("file", said)

    def test_the_keyboard_gate_blocks_the_paste(self):
        WA._foreground_is_whatsapp = lambda: False
        WA._ensure_foreground = lambda timeout=4.0: False
        ok, said = self._run()
        self.assertFalse(ok)
        self.assertEqual(self.copied, [], "nothing is pasted without the keyboard")
        self.assertIn("kuch nahi bheja", said)

    def test_clipboard_failure_is_reported(self):
        WA.whatsapp_media.copy_file = lambda path: False
        ok, said = self._run()
        self.assertFalse(ok)
        self.assertIn("clipboard", said)
        self.assertNotIn("keys:^v", self.box.clicks)


class PasteBox(El):
    """The composer: a real ^v stages the attachment strip (the driver reads
    the file from the clipboard, which the tests fake via copy_file)."""

    def __init__(self, control_type, name, rect, staged):
        super().__init__(control_type, name, rect)
        self._staged = staged
        self.stages = True

    def type_keys(self, keys, **kw):
        self.clicks.append("keys:" + keys)
        if keys == "^v" and self.stages:
            self._staged["on"] = True
        return


class SendButton(El):
    """invoke() reports the send only when the test says it really happened."""

    def __init__(self, control_type, name, rect, staged, rows):
        super().__init__(control_type, name, rect)
        self._staged = staged
        self._rows = rows
        self.sends = False
        self.row_after = "Akhilesh 3:02 pm Photo"

    def invoke(self):
        self.clicks.append("invoke:" + self._name)
        if self.sends:
            self._rows["now"] = self.row_after


class ReconnectScanTest(unittest.TestCase):
    """A dropped socket shows WhatsApp's own 'Reconnect' banner and the composer
    stays dead until that button is clicked. The scan must click exactly that
    button - one whose NAME is 'Reconnect' / 'Try again' - and nothing else."""

    def test_the_reconnect_button_is_clicked(self):
        btn = El("Button", "Reconnect")
        win = FakeWin([btn])
        self.assertEqual(WA._click_reconnect_if_shown(win), "Reconnect")
        self.assertEqual(btn.clicks, ["invoke:Reconnect"])

    def test_only_the_exact_recovery_button_is_clicked(self):
        send = El("Button", "Send 1 selected")
        banner = El("Text", "Reconnecting...")
        chat = El("DataItem", "Akhilesh 6:30 pm Photo")
        win = FakeWin([send, banner, chat])
        self.assertEqual(WA._click_reconnect_if_shown(win), "")
        self.assertEqual(send.clicks, [])
        self.assertEqual(banner.clicks, [])

    def test_no_reconnect_button_means_no_click_at_all(self):
        win = FakeWin([El("Button", "New chat")])
        self.assertEqual(WA._click_reconnect_if_shown(win), "")

    def test_no_window_is_a_clean_no_op(self):
        self.assertEqual(WA._click_reconnect_if_shown(None), "")


if __name__ == "__main__":
    unittest.main()


class TrayOnlyActivationTest(unittest.TestCase):
    """Live 2026-10-19: WhatsApp ran as a tray-only background process with no
    top-level window, so the send died on "app ko taskbar se open kijiye" - an
    instruction the OWNER had to obey. available() must wake the app itself
    (protocol relaunch, verified by a real window) and only then refuse."""

    def setUp(self):
        self._real = {k: getattr(WA, k) for k in
                      ("_ui_window_handles", "_process_running",
                       "_activate_app")}
        self.addCleanup(self._restore)

    def _restore(self):
        for k, v in self._real.items():
            setattr(WA, k, v)

    def test_a_tray_only_app_is_woken_up_not_refused(self):
        WA._ui_window_handles = lambda: []
        WA._process_running = lambda: [1234]
        WA._activate_app = lambda wait_s=10.0: True
        self.assertEqual(WA.available(), (True, "ready (window khadi kari)"))

    def test_a_wake_that_fails_is_reported_honestly(self):
        WA._ui_window_handles = lambda: []
        WA._process_running = lambda: [1234]
        WA._activate_app = lambda wait_s=10.0: False
        ok, why = WA.available()
        self.assertFalse(ok)
        self.assertIn("khul paayi", why)

    def test_no_process_at_all_stays_app_band_hai(self):
        WA._ui_window_handles = lambda: []
        WA._process_running = lambda: []
        self.assertEqual(WA.available()[1], "WhatsApp desktop app band hai")

    def test_activate_never_touches_startfile_without_a_process(self):
        fired = []
        real_startfile = getattr(WA.os, "startfile", None)

        def boom(target):
            fired.append(target)
            raise AssertionError("startfile without process")
        WA.os.startfile = boom
        try:
            # no process -> no relaunch, clean False
            WA._process_running = lambda: []
            self.assertFalse(WA._activate_app())
        finally:
            if real_startfile is not None:
                WA.os.startfile = real_startfile
            else:
                try:
                    del WA.os.startfile
                except AttributeError:
                    pass
        self.assertEqual(fired, [])

    def test_activate_verifies_the_window_instead_of_assuming(self):
        WA._process_running = lambda: [77]
        attempts = []

        def fake_startfile(target):
            attempts.append(target)

        WA.os.startfile = fake_startfile
        WA._app_window_open = lambda: False
        WA._ui_window_handles = lambda: [(11, "WhatsApp", "cls")]
        self.assertTrue(WA._activate_app(wait_s=0.3), "handles at the end = woken")
        self.assertEqual(attempts, ["whatsapp://"])
