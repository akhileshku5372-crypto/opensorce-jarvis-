/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  LayoutDashboard,
  Sparkles,
  Mic,
  Globe,
  Grid,
  Eye,
  Hand,
  Folder,
  CheckSquare,
  Database,
  Users,
  GitBranch,
  Shield,
  Settings,
  ChevronDown,
  ChevronRight,
  Sliders,
  Palette,
  Volume2,
  Key,
  Brain as BrainIcon,
} from 'lucide-react';
import { soundFx } from '../../services/soundEffects';

export type ActiveModule =
  | 'dashboard'
  | 'kamisensei'
  | 'voice_command'
  | 'web_intel'
  | 'modules'
  | 'vision'
  | 'gesture'
  | 'system_files'
  | 'productivity'
  | 'memory_core'
  | 'cowork'
  | 'repos'
  | 'security'
  | 'settings_general'
  | 'settings_appearance'
  | 'settings_audio'
  | 'settings_apikeys'
  | 'brain';

interface JarvisSidebarProps {
  activeModule: ActiveModule;
  onSelectModule: (module: ActiveModule) => void;
}

export const JarvisSidebar: React.FC<JarvisSidebarProps> = ({
  activeModule,
  onSelectModule,
}) => {
  const [settingsOpen, setSettingsOpen] = useState(true);

  const handleNav = (mod: ActiveModule) => {
    onSelectModule(mod);
    soundFx.playSelect();
  };

  interface NavItem {
    id: ActiveModule;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'kamisensei', label: 'KAMISENSEILM', icon: Sparkles, badge: 'AI' },
    { id: 'voice_command', label: 'Voice Command', icon: Mic },
    { id: 'web_intel', label: 'Web Intelligence', icon: Globe },
    { id: 'modules', label: 'Modules & Upgrades', icon: Grid },
    { id: 'vision', label: 'Vision System', icon: Eye },
    { id: 'gesture', label: 'Gesture Control', icon: Hand },
    { id: 'system_files', label: 'System & Files', icon: Folder },
    { id: 'productivity', label: 'Productivity', icon: CheckSquare },
    { id: 'memory_core', label: 'Memory Core', icon: Database },
    { id: 'cowork', label: 'Co-work', icon: Users },
    { id: 'repos', label: 'Repos', icon: GitBranch },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  const isSettingsActive =
    activeModule.startsWith('settings_') || activeModule === 'brain';

  return (
    <aside className="w-56 lg:w-60 bg-slate-950/85 border-r border-cyan-500/20 flex flex-col justify-between shrink-0 select-none overflow-hidden backdrop-blur-md">
      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeModule === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id as ActiveModule)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-rajdhani font-semibold transition-all group ${
                isActive
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-cyan-400' : 'text-slate-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono-code bg-cyan-950 text-cyan-300 border border-cyan-400/40">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Settings Group (Collapsible dropdown) */}
        <div className="pt-1">
          <button
            onClick={() => {
              setSettingsOpen(!settingsOpen);
              soundFx.playChirp();
            }}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-rajdhani font-semibold transition-colors ${
              isSettingsActive
                ? 'text-cyan-300'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Settings className="w-4 h-4 text-cyan-400" />
              <span>Settings</span>
            </div>
            {settingsOpen ? (
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            )}
          </button>

          {/* Settings Sub-options */}
          {settingsOpen && (
            <div className="pl-6 pr-1 py-1 space-y-0.5 border-l border-cyan-500/15 ml-4 my-1">
              <button
                onClick={() => handleNav('settings_general')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-xs font-rajdhani transition-colors ${
                  activeModule === 'settings_general'
                    ? 'text-cyan-300 bg-cyan-500/15 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-slate-500" />
                <span>General</span>
              </button>

              <button
                onClick={() => handleNav('settings_appearance')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-xs font-rajdhani transition-colors ${
                  activeModule === 'settings_appearance'
                    ? 'text-cyan-300 bg-cyan-500/15 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Palette className="w-3.5 h-3.5 text-slate-500" />
                <span>Appearance</span>
              </button>

              <button
                onClick={() => handleNav('settings_audio')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-xs font-rajdhani transition-colors ${
                  activeModule === 'settings_audio'
                    ? 'text-cyan-300 bg-cyan-500/15 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 text-slate-500" />
                <span>Audio & Voice</span>
              </button>

              <button
                onClick={() => handleNav('settings_apikeys')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-xs font-rajdhani transition-colors ${
                  activeModule === 'settings_apikeys'
                    ? 'text-cyan-300 bg-cyan-500/15 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Key className="w-3.5 h-3.5 text-slate-500" />
                <span>API Keys</span>
              </button>

              {/* BRAIN MODULE — Underneath Settings, active and glowing! */}
              <button
                onClick={() => handleNav('brain')}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-rajdhani font-bold transition-all ${
                  activeModule === 'brain'
                    ? 'bg-gradient-to-r from-cyan-500/30 to-blue-500/10 text-cyan-200 border border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                    : 'text-cyan-400/80 hover:text-cyan-200 hover:bg-cyan-950/40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <BrainIcon className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
                  <span className="tracking-wider">Brain</span>
                </div>
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Bottom: JARVIS CORE Status */}
      <div className="p-3 border-t border-cyan-500/20 bg-slate-950/90">
        <div className="flex items-center gap-2.5 p-2 rounded-xl bg-cyan-950/40 border border-cyan-500/30">
          <div className="relative w-7 h-7 rounded-full border border-cyan-400 flex items-center justify-center bg-cyan-900/40 shadow-[0_0_10px_rgba(6,182,212,0.5)]">
            <div className="w-3.5 h-3.5 rounded-full border border-dashed border-cyan-300 animate-arc-rotate" />
            <div className="absolute w-1.5 h-1.5 rounded-full bg-cyan-400" />
          </div>
          <div>
            <div className="text-[11px] font-orbitron font-bold text-white tracking-wider">
              JARVIS CORE
            </div>
            <div className="text-[9px] font-rajdhani text-cyan-300 font-semibold tracking-wide">
              CORE + BRIDGE ONLINE
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
