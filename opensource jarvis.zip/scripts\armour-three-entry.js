/* Entry for public/static/armour-bundle.js (Phase 5.1 armour studio).
 *
 * Why a SECOND bundle instead of extending three-bundle.min.js: that bundle
 * backs the working brain hologram and is committed as a built artifact with no
 * build script. The Armour Studio needs GLTFLoader, which the bundle does not
 * contain, and it only matters when the user opens the Armour view - so it ships
 * as its own lazily fetched file and the hologram's globals stay untouched.
 *
 * three.js is MIT licensed (see the three.js repository).
 */
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'

window.JARVIS_ARMOUR_THREE = { THREE, OrbitControls, GLTFLoader }
window.dispatchEvent(new CustomEvent('jarvis:armour-three-ready', {
  detail: { revision: THREE.REVISION }
}))