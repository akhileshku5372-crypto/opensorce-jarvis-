"""
KamiSensei Local Podcast Engine — Kokoro-82M (100% offline TTS).

A loopback-only HTTP micro-service that the JARVIS server (src/index.tsx)
calls to synthesize podcast dialogue locally — no ElevenLabs, no Edge-TTS,
no network egress at synthesis time.

Endpoints (all 127.0.0.1 only):
  GET  /health                        -> {ok, model_loaded, pipelines}
  POST /podcast/start                 -> {ok, session}
  POST /podcast/turn                  -> {ok, audio_b64, seconds, index}
  POST /podcast/finalize              -> {ok, url, file, seconds}
  POST /podcast/cancel                -> {ok}

Session flow: start -> turn* -> finalize. Each turn returns 24 kHz mono
WAV (base64) for instant client playback while the engine accumulates the
raw PCM; finalize stitches everything and muxes to
./public/static/podcast_<notebookId>.mp3 via ffmpeg (WAV fallback).

Voice mapping (Kokoro-82M, per-language — American-only chains like
am_adam / pm_alex / af_heart are DEPRECATED: they flatten non-English
pronunciation):
  lang "a" (English)     HostA -> am_michael (bm_george)  HostB -> af_bella (bf_emma)
  lang "j" (Japanese)    HostA -> jm_kumo                 HostB -> jf_alpha  [Tokyo pitch, misaki[ja]]
  lang "h" (Hindi)       HostA -> hm_omega                HostB -> hf_alpha  [native Indian phonetics]
  Hinglish / Trilingual  style-vector blend: en voice ⊕ 45% Hindi voice
                         (genuine Indian-English texture from one model's shared
                         style space; falls back to the pure en voice if the
                         Hindi voice pack cannot be loaded)

Language routing per text segment:
  Kana/Kanji runs    -> KPipeline(lang_code="j")  [misaki[ja] G2P, Tokyo pitch]
  Devanagari runs    -> KPipeline(lang_code="h")  [Hindi voice]
  everything else    -> base voice for the session language_mode
Run:  python background/kokoro_podcast.py
"""

from __future__ import annotations

import base64
import io
import json
import os
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple

HOST = "127.0.0.1"
PORT = int(os.environ.get("KOKORO_PORT", "7779"))
STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "public", "static")
SAMPLE_RATE = 24000
SESSION_TTL = 30 * 60  # seconds

# Voice chains are per-LANGUAGE: the voice family letter MUST match the
# pipeline lang_code, or misaki resolves the text through the wrong G2P
# (the old am_adam-on-Japanese bug that produced flat American audio).
LANG_VOICE_CHAINS: Dict[str, Dict[str, List[str]]] = {
    "a": {"HostA": ["am_michael", "bm_george"], "HostB": ["af_bella", "bf_emma"]},
    "j": {"HostA": ["jm_kumo", "jf_alpha"], "HostB": ["jf_alpha", "jm_kumo"]},
    "h": {"HostA": ["hm_omega", "hf_alpha"], "HostB": ["hf_alpha", "hm_omega"]},
    "b": {"HostA": ["bm_george", "am_michael"], "HostB": ["bf_emma", "af_bella"]},
}
# Hinglish coloring: blend the English base voice with this much Hindi voice.
HINGLISH_BLEND_WEIGHT = 0.45
HINGLISH_MODES = {"hinglish", "trilingual", "trilingual_mix", "trilingual (mix)", "mix", ""}
HINGLISH_BLEND: Dict[str, Tuple[str, str, float]] = {
    "HostA": ("am_michael", "hm_omega", HINGLISH_BLEND_WEIGHT),
    "HostB": ("af_bella", "hf_alpha", HINGLISH_BLEND_WEIGHT),
}

_CJK_RE = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uff66-\uff9f]")
_DEVANAGARI_RE = re.compile(r"[\u0900-\u097f]")
_SPLIT_RE = re.compile(r"([^。！？.!?]+[。！？.!?]*)")

_state_lock = threading.Lock()
_pipelines: Dict[str, Any] = {}
_voice_cache: Dict[Tuple[str, str], Any] = {}
_blend_cache: Dict[str, Any] = {}
_model_loaded = False
_sessions: Dict[str, Dict[str, Any]] = {}
_synthesis_lock = threading.Lock()  # Kokoro pipelines are not thread-safe


def _log(msg: str) -> None:
    sys.stdout.write("[kokoro-engine] %s\n" % msg)
    sys.stdout.flush()


def _get_pipeline(lang_code: str) -> Any:
    """Lazy per-language pipeline cache; first call downloads/loads weights."""
    global _model_loaded
    with _synthesis_lock:
        if lang_code not in _pipelines:
            from kokoro import KPipeline  # imported here: heavy torch import
            _log("loading KPipeline(lang_code=%s) ..." % lang_code)
            _pipelines[lang_code] = KPipeline(lang_code=lang_code)
            _model_loaded = True
            _log("KPipeline(%s) ready" % lang_code)
        return _pipelines[lang_code]


def _resolve_voice(speaker: str, lang_code: str) -> Tuple[Any, Any]:
    """Load a language-MATCHED voice tensor for the speaker.

    Only voices whose family letter equals the requested lang_code are tried,
    so a Japanese segment can never silently fall back to the American G2P.
    Returns (voice_tensor, pipeline); the tensor is cached and passed straight
    into KPipeline.__call__.
    """
    cache_key = (speaker, lang_code)
    if cache_key in _voice_cache:
        return _voice_cache[cache_key], _get_pipeline(lang_code)
    chain = LANG_VOICE_CHAINS.get(lang_code, {}).get(
        speaker, LANG_VOICE_CHAINS["a"][speaker if speaker in ("HostA", "HostB") else "HostA"])
    pipeline = _get_pipeline(lang_code)
    last_err: Optional[Exception] = None
    for voice in chain:
        if voice[0] != lang_code:
            continue  # family mismatch — the exact flat-accent bug this blocks
        try:
            tensor = pipeline.load_voice(voice)
            _voice_cache[cache_key] = tensor
            _log("voice %s loaded for %s/%s" % (voice, speaker, lang_code))
            return tensor, pipeline
        except Exception as err:  # voice pack missing/not downloadable
            last_err = err
            _log("voice %s unavailable (%s); trying next" % (voice, err))
    raise RuntimeError("no usable %s-family Kokoro voice for %s: %s" % (lang_code, speaker, last_err))


def _hinglish_blend_voice(speaker: str) -> Tuple[Any, Any]:
    """English base voice blended with the Hindi voice (Indian-English texture).

    Both voices come from the same Kokoro-82M style space, so the weighted
    average is a valid style tensor. Falls back to the pure English voice if
    the Hindi pack cannot be loaded.
    """
    if speaker in _blend_cache:
        return _blend_cache[speaker], _get_pipeline("a")
    en_name, hi_name, weight = HINGLISH_BLEND.get(speaker, HINGLISH_BLEND["HostA"])
    en_tensor, _ = _resolve_voice(speaker, "a")
    try:
        hi_pipeline = _get_pipeline("h")
        hi_tensor = hi_pipeline.load_voice(hi_name)
        import torch  # kokoro dependency; blending is a tensor op
        blended = (1.0 - weight) * en_tensor + weight * hi_tensor
        _blend_cache[speaker] = blended
        _log("hinglish blend %s: %.2f*%s + %.2f*%s" % (speaker, 1.0 - weight, en_name, weight, hi_name))
        return blended, _get_pipeline("a")
    except Exception as err:
        _log("hinglish blend unavailable (%s); using pure %s" % (err, en_name))
        return en_tensor, _get_pipeline("a")


def _synthesize_segment(text: str, voice: str, lang_code: str, speed: float) -> List[Any]:
    """Synthesize one segment -> list of numpy float32 audio chunks."""
    pipeline = _get_pipeline(lang_code)
    chunks: List[Any] = []
    for result in pipeline(text, voice=voice, speed=speed):
        audio = getattr(result, "audio", None)
        if audio is not None:
            chunks.append(audio)
    return chunks


def synthesize_turn(text: str, speaker: str, speed: float, language_mode: str = "hinglish") -> Tuple[bytes, float]:
    """Full dialogue turn -> (24 kHz mono WAV bytes, duration seconds).

    The turn is split into language-homogeneous segments: embedded Japanese
    (Kanji/Kana) is pronounced with authentic Tokyo pitch through misaki[ja]
    and jm_kumo/jf_alpha, Devanagari runs go through the Hindi pipeline, and
    Latin segments use the session's base voice (English, or the
    Hinglish en+hindi blend for Indian-English texture).
    """
    if not text or not text.strip():
        raise ValueError("empty turn text")

    speaker = "HostB" if speaker == "HostB" else "HostA"
    mode = (language_mode or "hinglish").strip().lower()
    try:
        if mode in ("hindi", "hi", "हिंदी"):
            base_voice, _base_pipeline = _resolve_voice(speaker, "h")
        elif mode in HINGLISH_MODES:
            base_voice, _base_pipeline = _hinglish_blend_voice(speaker)
        else:
            base_voice, _base_pipeline = _resolve_voice(speaker, "a")
    except Exception as err:
        _log("base voice resolution failed (%s); falling back to lang 'a'" % err)
        base_voice, _base_pipeline = _resolve_voice(speaker, "a")

    pcm_chunks: List[Any] = []
    for raw_segment in _SPLIT_RE.findall(text):
        segment = raw_segment.strip()
        if not segment:
            continue
        try:
            if _CJK_RE.search(segment):
                ja_voice, _jp = _resolve_voice(speaker, "j")
                pcm_chunks.extend(_synthesize_segment(segment, ja_voice, "j", speed))
            elif _DEVANAGARI_RE.search(segment):
                hi_voice, _hi = _resolve_voice(speaker, "h")
                pcm_chunks.extend(_synthesize_segment(segment, hi_voice, "h", speed))
            else:
                pcm_chunks.extend(_synthesize_segment(segment, base_voice, "a", speed))
        except Exception as err:
            _log("segment failed (%s); skipping: %r" % (err, segment[:60]))

    if not pcm_chunks:
        raise RuntimeError("synthesis produced no audio for turn")

    import numpy as np
    import soundfile as sf

    audio = np.concatenate([np.asarray(c, dtype=np.float32).flatten() for c in pcm_chunks])
    buffer = io.BytesIO()
    sf.write(buffer, audio, SAMPLE_RATE, subtype="PCM_16", format="WAV")
    duration = float(len(audio)) / float(SAMPLE_RATE)
    return buffer.getvalue(), duration


def _stitch_to_file(session: Dict[str, Any]) -> Tuple[str, str, float]:
    """Stitch session PCM -> mp3 in ./public/static (wav fallback)."""
    import numpy as np
    import soundfile as sf

    audio = np.concatenate([np.asarray(c, dtype=np.float32).flatten() for c in session["pcm"]])
    duration = float(len(audio)) / float(SAMPLE_RATE)
    notebook_id = session["notebook_id"]
    safe_id = re.sub(r"[^a-zA-Z0-9_-]+", "_", notebook_id)[:80] or "session"
    os.makedirs(STATIC_DIR, exist_ok=True)

    raw_path = os.path.join(STATIC_DIR, "podcast_%s.raw" % safe_id)
    with open(raw_path, "wb") as handle:
        handle.write(audio.astype(np.float32).tobytes())
    mp3_path = os.path.join(STATIC_DIR, "podcast_%s.mp3" % safe_id)
    try:
        import subprocess
        result = subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error",
             "-f", "f32le", "-ar", str(SAMPLE_RATE), "-ac", "1", "-i", raw_path,
             "-codec:a", "libmp3lame", "-qscale:a", "4", mp3_path],
            capture_output=True, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.decode("utf-8", "replace")[:200])
        url = "/static/podcast_%s.mp3" % safe_id
        final_path = mp3_path
    except Exception as err:
        _log("ffmpeg mux failed (%s); writing WAV fallback" % err)
        wav_path = os.path.join(STATIC_DIR, "podcast_%s.wav" % safe_id)
        sf.write(wav_path, audio, SAMPLE_RATE, subtype="PCM_16")
        url = "/static/podcast_%s.wav" % safe_id
        final_path = wav_path
    finally:
        try:
            os.remove(raw_path)
        except OSError:
            pass
    return url, final_path, duration


# ─────────────────────────────────────────────────────────────────────────────
# HTTP micro-service (loopback only). Matches the client contract in
# src/index.tsx (generate-podcast handler):
#   GET  /health                            -> {ok, model_loaded, pipelines}
#   POST /podcast/start    {notebook_id, speed}            -> {ok, session}
#   POST /podcast/turn     {session, speaker, text, speed} -> {ok, audio_b64, seconds, index}
#   POST /podcast/finalize {session}                       -> {ok, url, file, seconds}
#   POST /podcast/cancel   {session}                       -> {ok}
# ─────────────────────────────────────────────────────────────────────────────

MAX_BODY = 4 * 1024 * 1024  # 4 MiB request cap


class _PodcastHandler(BaseHTTPRequestHandler):
    server_version = "kokoro-podcast/1.0"

    # ── helpers ─────────────────────────────────────────────────────────────
    def _send_json(self, obj: Any, status: int = 200) -> None:
        try:
            body = json.dumps(obj).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def _read_body(self) -> Optional[Dict[str, Any]]:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length <= 0 or length > MAX_BODY:
            return None
        try:
            raw = self.rfile.read(length)
        except Exception:  # noqa: BLE001
            return None
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except Exception:  # noqa: BLE001
            return None
        return data if isinstance(data, dict) else None

    def _get_session(self, body: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        sid = (body or {}).get("session")
        if not isinstance(sid, str):
            return None
        with _state_lock:
            return _sessions.get(sid)

    # ── GET ──────────────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        if self.path.split("?")[0].rstrip("/") == "/health":
            with _state_lock:
                pipelines = sorted(_pipelines.keys())
            self._send_json({"ok": True, "model_loaded": bool(_model_loaded),
                             "pipelines": pipelines, "sessions": len(_sessions)})
            _log("GET /health -> pipelines=%s" % (pipelines or "none"))
            return
        self._send_json({"ok": False, "error": "not found"}, 404)

    # ── POST ─────────────────────────────────────────────────────────────────
    def do_POST(self) -> None:
        try:
            base = self.path.split("?")[0].rstrip("/")
            if base == "/podcast/start":
                self._handle_start()
            elif base == "/podcast/turn":
                self._handle_turn()
            elif base == "/podcast/finalize":
                self._handle_finalize()
            elif base == "/podcast/cancel":
                self._handle_cancel()
            elif base == "/tts":
                self._handle_tts()
            else:
                self._send_json({"ok": False, "error": "not found"}, 404)
        except Exception as err:  # noqa: BLE001
            _log("handler error: %r" % (err,))
            try:
                self._send_json({"ok": False, "error": str(err)[:300]}, 500)
            except Exception:  # noqa: BLE001
                pass

    def _handle_start(self) -> None:
        body = self._read_body() or {}
        notebook_id = str(body.get("notebook_id") or "session")[:160]
        try:
            speed = float(body.get("speed") or 1.0)
        except (TypeError, ValueError):
            speed = 1.0
        speed = max(0.5, min(2.0, speed))
        language_mode = str(body.get("language_mode") or "hinglish")[:40]
        sid = uuid.uuid4().hex[:12]
        with _state_lock:
            _sessions[sid] = {
                "id": sid,
                "notebook_id": notebook_id,
                "speed": speed,
                "language_mode": language_mode,
                "pcm": [],
                "turns": 0,
                "seconds": 0.0,
                "created_at": time.time(),
            }
        _log("session %s started (notebook=%s speed=%.2f lang=%s)" % (sid, notebook_id, speed, language_mode))
        self._send_json({"ok": True, "session": sid})

    def _handle_turn(self) -> None:
        body = self._read_body()
        sess = self._get_session(body)
        if sess is None:
            self._send_json({"ok": False, "error": "unknown session"}, 404)
            return
        text = str((body or {}).get("text") or "").strip()
        speaker = str((body or {}).get("speaker") or "HostA")[:32]
        try:
            speed = float((body or {}).get("speed") or sess["speed"])
        except (TypeError, ValueError):
            speed = sess["speed"]
        if not text:
            self._send_json({"ok": False, "error": "empty turn text"}, 400)
            return
        begin = time.time()
        try:
            wav_bytes, duration = synthesize_turn(text, speaker, speed, str(sess.get("language_mode") or "hinglish"))
        except Exception as err:  # noqa: BLE001
            _log("turn rejected (%s); skipped" % (err,))
            self._send_json({"ok": False, "error": str(err)[:300]})
            return
        # Accumulate raw PCM for the final stitch (WAV decode round-trip).
        try:
            import soundfile as sf
            samples, _sr = sf.read(io.BytesIO(wav_bytes), dtype="float32")
            with _state_lock:
                sess["pcm"].append(samples)
                sess["turns"] += 1
                sess["seconds"] += duration
        except Exception as err:  # noqa: BLE001
            _log("pcm accumulation failed (%s)" % (err,))
        audio_b64 = base64.b64encode(wav_bytes).decode("ascii")
        _log("session %s turn %d OK (%.2fs audio, %.1fs wall)" %
             (sess["id"], sess["turns"], duration, time.time() - begin))
        self._send_json({"ok": True, "audio_b64": audio_b64, "seconds": duration,
                         "index": sess["turns"]})

    def _handle_finalize(self) -> None:
        body = self._read_body()
        sess = self._get_session(body)
        if sess is None:
            self._send_json({"ok": False, "error": "unknown session"}, 404)
            return
        try:
            url, final_path, duration = _stitch_to_file(sess)
            _log("session %s finalized -> %s (%.2fs)" % (sess["id"], url, duration))
            self._send_json({"ok": True, "url": url,
                             "file": os.path.basename(final_path), "seconds": duration})
        except Exception as err:  # noqa: BLE001
            _log("finalize failed (%s)" % (err,))
            self._send_json({"ok": False, "error": str(err)[:300]}, 500)

    def _handle_cancel(self) -> None:
        body = self._read_body()
        sid = (body or {}).get("session")
        if isinstance(sid, str):
            with _state_lock:
                _sessions.pop(sid, None)
            _log("session %s cancelled" % sid)
        self._send_json({"ok": True})

    def _handle_tts(self) -> None:
        """One-shot single-speaker synthesis -> raw 24 kHz WAV bytes.

        The JARVIS voice core calls this as its local fallback so a cloud
        quota outage never degrades to the robotic Windows SAPI voice.
        Language is auto-routed inside synthesize_turn: embedded Japanese
        (CJK) and Hindi (Devanagari) segments use their native male voices
        (jm_kumo / hm_omega); Latin/Hinglish uses the en+hindi blend.
        """
        body = self._read_body()
        text = str((body or {}).get("text") or "").strip()
        if not text:
            self._send_json({"ok": False, "error": "empty text"}, 400)
            return
        speaker = str((body or {}).get("speaker") or "HostA")[:32]
        try:
            speed = float((body or {}).get("speed") or 1.0)
        except (TypeError, ValueError):
            speed = 1.0
        speed = max(0.5, min(2.0, speed))
        language_mode = str((body or {}).get("language_mode") or "hinglish")[:40]
        begin = time.time()
        try:
            wav_bytes, duration = synthesize_turn(text, speaker, speed, language_mode)
        except Exception as err:  # noqa: BLE001
            _log("tts rejected (%s)" % (err,))
            self._send_json({"ok": False, "error": str(err)[:300]}, 500)
            return
        _log("tts OK (%s) %.2fs audio, %.1fs wall" %
             (language_mode, duration, time.time() - begin))
        try:
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav_bytes)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(wav_bytes)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def log_message(self, fmt: str, *args: Any) -> None:  # silence default stderr
        pass


def _sweeper() -> None:
    """Drop sessions idle past SESSION_TTL (30 min)."""
    while True:
        time.sleep(60)
        now = time.time()
        stale = []
        with _state_lock:
            for key, sess in list(_sessions.items()):
                if now - sess.get("created_at", 0) > SESSION_TTL:
                    stale.append(key)
            for key in stale:
                _sessions.pop(key, None)
        if stale:
            _log("swept %d stale session(s)" % len(stale))


def main() -> int:
    server = ThreadingHTTPServer((HOST, PORT), _PodcastHandler)
    server.daemon_threads = True
    threading.Thread(target=_sweeper, daemon=True).start()
    _log("Kokoro-82M podcast engine listening on http://%s:%d" % (HOST, PORT))
    _log("model loads lazily on the first turn (Kokoro-82M weights cached via HF hub)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _log("shutting down")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
