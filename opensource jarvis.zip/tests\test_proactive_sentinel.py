"""Tests for proactive sentinel and system diagnostics."""
import unittest
from unittest.mock import MagicMock, patch
import background.proactive_sentinel as ps


class TestProactiveSentinel(unittest.TestCase):
    def setUp(self):
        ps.set_proactive_enabled(True)
        ps._LAST_ALERTS.clear()
        ps._WAS_LOW_BATTERY = False
        ps._CPU_SPIKE_COUNT = 0

    def test_diagnostic_report_en(self):
        report = ps.generate_diagnostic_report(lang="en")
        self.assertIn("nominal", report.lower())
        self.assertIn("voice", report.lower())

    def test_diagnostic_report_hi(self):
        report = ps.generate_diagnostic_report(lang="hi")
        self.assertIn("nominal", report.lower())
        self.assertIn("taiyar", report.lower())

    def test_low_battery_trigger(self):
        mock_speak = MagicMock()
        mock_sleep = MagicMock(return_value=False)
        mock_speaking = MagicMock(return_value=False)

        with patch.object(ps.telemetry, "battery", return_value={"available": True, "percent": 18.0, "plugged": False}):
            res = ps.evaluate_sentinel_tick(mock_speak, mock_sleep, mock_speaking, lang="en")
            self.assertEqual(res, "battery_low")
            mock_speak.assert_called_once()
            self.assertIn("18 percent", mock_speak.call_args[0][0])

    def test_ac_restored_trigger(self):
        mock_speak = MagicMock()
        mock_sleep = MagicMock(return_value=False)
        mock_speaking = MagicMock(return_value=False)

        ps._WAS_LOW_BATTERY = True
        with patch.object(ps.telemetry, "battery", return_value={"available": True, "percent": 22.0, "plugged": True}):
            res = ps.evaluate_sentinel_tick(mock_speak, mock_sleep, mock_speaking, lang="en")
            self.assertEqual(res, "ac_restored")
            mock_speak.assert_called_once()
            self.assertIn("External power restored", mock_speak.call_args[0][0])

    def test_suppressed_when_sleeping(self):
        mock_speak = MagicMock()
        mock_sleep = MagicMock(return_value=True)
        mock_speaking = MagicMock(return_value=False)

        with patch.object(ps.telemetry, "battery", return_value={"available": True, "percent": 15.0, "plugged": False}):
            res = ps.evaluate_sentinel_tick(mock_speak, mock_sleep, mock_speaking, lang="en")
            self.assertIsNone(res)
            mock_speak.assert_not_called()

    def test_proactive_toggle(self):
        self.assertTrue(ps.is_proactive_enabled())
        ps.set_proactive_enabled(False)
        self.assertFalse(ps.is_proactive_enabled())


if __name__ == "__main__":
    unittest.main()
