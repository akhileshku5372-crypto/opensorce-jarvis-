"""
KamiSensei Notebook Service — backend/api/notebooks.py
=======================================================
Canonical local notebook controller. This module is the absolute boot layer for
the notebook lifecycle:

  1. On import it FORCE-CREATES the three physical runtime directories:
     ./knowledge_base  ./chroma_db  ./notebooks
     (synchronous mkdir at the entry point — zero-failure boot).

  2. ``create_notebook(name)`` performs a synchronous disk operation that:
       - generates a distinct uuid,
       - creates the physical folder  ./notebooks/<uuid>',
       - writes ``metadata.json`` with the notebook name + an active UTC timestamp,
       - returns the strict success payload
         { "status": "success", "notebookId": "<uuid>", "name": "...", "createdAt": "..." }.

  3. ``list_notebooks()`` returns every persisted notebook descriptor.

Standard library only. CLI:
    python backend/api/notebooks.py --create --name "My Notes" --json
    python backend/api/notebooks.py --list --json
"""

import os
import sys
import json
import uuid
import argparse
from datetime import datetime, timezone
from pathlib import Path

# ── Absolute workspace root (repo-relative, works from any CWD) ─────────────
ROOT_DIR = Path(__file__).resolve().parent.parent.parent

try:
    from background import storage_paths as _storage_paths
except ImportError:  # pragma: no cover - direct-script execution
    import sys as _sys
    _sys.path.insert(0, str(ROOT_DIR))
    from background import storage_paths as _storage_paths

KNOWLEDGE_BASE_DIR = ROOT_DIR / "knowledge_base"
# RAG vectors and notebook descriptors follow the shared data root (D:).
CHROMA_DB_DIR = _storage_paths.kamisensei_rag_dir()
NOTEBOOKS_DIR = _storage_paths.kamisensei_notebooks()

# ── 1. ZERO-FAILURE BOOT: force-create every runtime directory, synchronously.
# ──    A single guarded mkdir call — an OS-level failure on one path can never
# ──    abort the whole import, but each path is still created if attainable.
for _runtime_dir in (KNOWLEDGE_BASE_DIR, CHROMA_DB_DIR, NOTEBOOKS_DIR):
    try:
        os.makedirs(str(_runtime_dir), exist_ok=True)
    except Exception as _boot_error:  # pragma: no cover - OS permission edge
        sys.stderr.write(f"[notebooks] directory boot failed for {_runtime_dir}: {_boot_error}\n")


def _active_timestamp() -> str:
    """ISO-8601 UTC timestamp for the 'active timestamp' field."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def create_notebook(name: str = "New Notebook") -> dict:
    """
    Create a persistent notebook folder + metadata.json descriptor.

    Strict response contract:
        { "status": "success", "notebookId": "<uuid>" }

    Extended fields (name, createdAt, path, file) are included so downstream
    consumers (bridge, UI pollers) can render without extra lookups.
    """
    notebook_id = str(uuid.uuid4())
    notebook_dir = NOTEBOOKS_DIR / notebook_id
    os.makedirs(str(notebook_dir), exist_ok=True)

    created_at = _active_timestamp()
    safe_name = str(name or "New Notebook").strip() or "New Notebook"

    metadata = {
        "id": notebook_id,
        "name": safe_name,
        "createdAt": created_at,
        "updatedAt": created_at,
        "sources": [],
        "messages": [],
        "settings": {},
    }
    metadata_path = notebook_dir / "metadata.json"
    with open(str(metadata_path), "w", encoding="utf-8") as fh:
        json.dump(metadata, fh, ensure_ascii=False, indent=2)

    return {
        "status": "success",
        "notebookId": notebook_id,
        "name": safe_name,
        "createdAt": created_at,
        "path": str(notebook_dir),
        "file": str(metadata_path),
    }


def list_notebooks() -> list:
    """Return every persisted notebook descriptor (safe read of folder dirs)."""
    notebooks: list = []
    if not NOTEBOOKS_DIR.exists():
        return notebooks
    for child in sorted(NOTEBOOKS_DIR.iterdir()):
        if not child.is_dir():
            continue
        meta_file = child / "metadata.json"
        legacy_file = child / "config.json"
        descriptor = meta_file if meta_file.exists() else legacy_file
        if not descriptor.exists():
            continue
        try:
            with open(str(descriptor), "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            meta.setdefault("id", child.name)
            meta.setdefault("notebookId", child.name)
            meta.setdefault("updatedAt", meta.get("createdAt") or _active_timestamp())
            notebooks.append(meta)
            if descriptor == legacy_file:
                # One-way compatibility migration: preserve old notebooks while
                # converging bridge and Python persistence on metadata.json.
                with open(str(meta_file), "w", encoding="utf-8") as fh:
                    json.dump(meta, fh, ensure_ascii=False, indent=2)
                legacy_file.unlink()
        except Exception as exc:
            sys.stderr.write(f"[notebooks] failed to read {descriptor}: {exc}\n")
    return notebooks


def delete_notebook(notebook_id: str) -> dict:
    """Remove a notebook folder recursively if it exists and is a uuid dir."""
    safe = str(notebook_id or "").strip()
    if not safe or "/" in safe or "\\" in safe or ".." in safe:
        return {"status": "error", "error": "Invalid notebook id."}
    notebook_dir = NOTEBOOKS_DIR / safe
    if not notebook_dir.exists():
        return {"status": "error", "error": "Notebook not found."}
    import shutil
    try:
        shutil.rmtree(str(notebook_dir))
    except OSError as exc:
        return {"status": "error", "error": f"Could not delete notebook: {exc}"}
    return {"status": "success", "notebookId": safe, "deleted": True}


def main() -> None:
    parser = argparse.ArgumentParser(description="KamiSensei Notebook Service")
    parser.add_argument("--create", action="store_true", help="Create a notebook")
    parser.add_argument("--name", type=str, default="", help="Notebook name")
    parser.add_argument("--delete", type=str, default="", help="Notebook id to delete")
    parser.add_argument("--list", action="store_true", help="List notebooks")
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    args = parser.parse_args()

    if args.create:
        result = create_notebook(args.name)
    elif args.delete:
        result = delete_notebook(args.delete)
    elif args.list:
        notebooks = list_notebooks()
        result = {"status": "success", "count": len(notebooks), "notebooks": notebooks}
    else:
        result = {"status": "error", "error": "No action specified. Use --create / --list / --delete."}

    if args.json:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()