"""JARVIS Extension System - MCP, Skill and Plugin managers in one place.

This is an ADDITIVE layer over code that already works. Nothing here replaces
an existing subsystem:

  * MCP      -> wraps background/mcp_client.py (the real stdio JSON-RPC client)
  * Skills   -> wraps background/skill_loader.py (the real SKILL.md loader)
  * Plugins  -> new manifest-driven extension points, registered into the
                existing cortex ToolRegistry through cowork_tools

Every manager exposes the same shape (`list/enable/disable/status/...`) so the
UI and the voice routes can treat them uniformly. Every installed capability is
handed to the real ToolRegistry - there are no mock integrations: a plugin or
MCP tool that cannot actually be reached is reported as unavailable rather than
faked as working.

Safety: plugins are data + an allowlisted entry module inside this repository.
No plugin can introduce a shell, and every tool call still passes through the
existing cortex confirm gate and the permission engine.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
import threading
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXT_DIR = Path(os.environ.get("JARVIS_EXTENSIONS_DIR")
               or (ROOT / "extensions"))
PLUGIN_DIR = EXT_DIR / "plugins"
STATE_PATH = EXT_DIR / "state.json"
MARKETPLACE_PATH = EXT_DIR / "marketplace.json"

# Validation pattern (anchored, whole-string) and the SEPARATE sanitiser used to
# coerce a folder name into a slug. These must not be the same object: an
# anchored pattern used with .sub() replaces the ENTIRE name whenever it
# matches, which turned every valid name into "-" and made install always fail.
_slugs = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,63}$", re.I)
_slug_dirty = re.compile(r"[^a-z0-9_\-]+")


def slugify(name: str) -> str:
    """Coerce a folder name into a valid slug ('My Plugin' -> 'my-plugin')."""
    return _slug_dirty.sub("-", str(name or "").strip().lower()).strip("-")

_lock = threading.RLock()
_disabled = set()          # names the user switched off (all three kinds)


def _load(name: str):
    """Load a background module under a stable key, shared with cowork_tools."""
    if name == "voice_engine":
        # The engine runs as __main__ and is never registered under the
        # cowork key, so a plain lookup would import a SECOND copy of the
        # brain: its own STATE, its own _CONFIRM event, its own
        # _AUTO_APPROVE. A spoken "haan" resolved by the live loop then
        # never reaches the gate the agent is actually waiting on, and
        # every confirm-gated tool times out into "confirmation refused".
        # Accept the live module only if it really is the engine, so this
        # can never start a second voice loop, mic or memory.
        live = sys.modules.get("__main__")
        if live is not None and hasattr(live, "submit_command"):
            return live
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    spec = importlib.util.spec_from_file_location(full, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


# ══════════════════════════════════════════════════════════════════════════
# 1. MCP MANAGER  (adapter over the existing mcp_client stdio client)
# ══════════════════════════════════════════════════════════════════════════
# A real handshake against every configured stdio server costs ~5s, and the
# dashboard polls this snapshot, so a bare snapshot() would re-probe on every
# poll. Cache the probe briefly and invalidate it whenever the MCP config
# changes, so a toggle/install is still reflected immediately.
_MCP_HEALTH_TTL = 30.0
_mcp_health_cache = {"at": 0.0, "rows": None}


def mcp_servers(force: bool = False) -> list:
    """Configured MCP servers with real handshake health.

    `enabled` is the union of the on-disk config and the runtime switch, so
    disabling here also stops the connector from being started. Results are
    cached for _MCP_HEALTH_TTL seconds; pass force=True to re-probe now.
    """
    now = time.monotonic()
    cached = _mcp_health_cache.get("rows")
    if (not force and cached is not None
            and now - _mcp_health_cache.get("at", 0.0) < _MCP_HEALTH_TTL):
        return [dict(r) if isinstance(r, dict) else r for r in cached]

    client = _load("mcp_client")
    try:
        rows = client.status(probe=True, timeout=6.0)
    except Exception as exc:
        return [{"name": "mcp", "enabled": False, "ok": False,
                 "error": "mcp_client failed: %s" % exc, "tools": []}]
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name") or "")
        row["enabled"] = bool(row.get("enabled")) and not is_disabled("mcp:" + name)
        row["source"] = "stdio"
    with _lock:
        _mcp_health_cache["rows"] = rows
        _mcp_health_cache["at"] = now
    return [dict(r) if isinstance(r, dict) else r for r in rows]


def _invalidate_mcp_health():
    """Drop cached MCP health + tool list after any config change.

    register/toggle/unregister all change the tool set, so the registry
    snapshot has to go with the health snapshot.
    """
    with _lock:
        _mcp_health_cache["rows"] = None
        _mcp_health_cache["at"] = 0.0
        _tool_list_cache["tools"] = None
        _tool_list_cache["at"] = 0.0


def mcp_register(name: str, command: str, args=None, description: str = "",
                 read_only: bool = True, allow_call: bool = False,
                 env: dict = None) -> tuple:
    """Register a local stdio MCP server into mcp/servers.json.

    `command` must be an allowlisted interpreter or a script inside this repo -
    the same rule mcp_client already enforces, re-checked here so a bad value
    is refused at registration time instead of failing silently later.
    """
    client = _load("mcp_client")
    command = str(command or "").strip()
    if not command:
        return (False, "command is required")
    allowed = getattr(client, "_ALLOWED_COMMANDS", set())
    candidate = Path(command if os.path.isabs(command) else str(ROOT / command))
    inside_repo = candidate.is_file() and candidate.resolve().is_relative_to(ROOT.resolve())
    if not inside_repo and Path(command).name.lower() not in allowed:
        return (False, "command '%s' is not allowlisted (repo script or %s)"
                % (Path(command).name, "/".join(sorted(allowed))))
    slug = str(name or "").strip()
    if not _slugs.match(slug):
        return (False, "invalid server name '%s' (a-z0-9, _ and -)" % slug)
    if inside_repo:
        command = str(candidate.relative_to(ROOT)).replace("\\", "/")
    entry = {
        "command": command,
        "args": [str(a) for a in (args or [])],
        "enabled": True,
        "allowCall": bool(allow_call),
        "readOnly": bool(read_only),
        "description": str(description or "")[:400],
    }
    if env:
        entry["env"] = {str(k): str(v) for k, v in dict(env).items()}
    try:
        path = client.CONFIG_PATH
        data = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
        servers = data.get("servers") if isinstance(data, dict) else None
        if not isinstance(servers, dict):
            servers = {}
        servers[slug] = entry
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"servers": servers}, indent=2) + "\n",
                        encoding="utf-8")
    except Exception as exc:
        return (False, "could not write MCP config: %s" % exc)
    _invalidate_mcp_health()
    return (True, "MCP server '%s' registered" % slug)


def mcp_tools(server: str = "", timeout: float = 6.0) -> list:
    """Real `tools/list` from the stdio servers (empty when unreachable)."""
    client = _load("mcp_client")
    try:
        if server:
            listed = client.list_tools(str(server), timeout=timeout)
            return list(listed.get("tools") or []) if listed.get("ok") else []
        return client.tools_snapshot(probe=True, timeout=timeout)
    except Exception:
        return []


def mcp_call(server: str, tool: str, args: dict = None, approved: bool = False) -> dict:
    """Call an MCP tool through the permission engine, then the real client."""
    perms = _load("permissions")
    verdict = perms.check("mcp", tool="%s.%s" % (server, tool), args=args or {},
                          approved=approved)
    if not verdict["allowed"]:
        return {"ok": False, "error": verdict["reason"],
                "requires_approval": verdict.get("requires_approval", False),
                "permission": verdict}
    client = _load("mcp_client")
    try:
        return client.call_tool(str(server), str(tool), dict(args or {}), timeout=30.0)
    except Exception as exc:
        return {"ok": False, "error": "MCP call failed: %s" % exc}


def mcp_set_enabled(server: str, enabled: bool) -> tuple:
    """Enable/disable one MCP server by rewriting the on-disk config flag."""
    client = _load("mcp_client")
    slug = str(server or "").strip()
    try:
        path = client.CONFIG_PATH
        data = json.loads(path.read_text(encoding="utf-8"))
        servers = data.get("servers") if isinstance(data, dict) else {}
        if slug not in (servers or {}):
            return (False, "unknown MCP server '%s'" % slug)
        servers[slug]["enabled"] = bool(enabled)
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    except Exception as exc:
        return (False, "could not update MCP config: %s" % exc)
    _invalidate_mcp_health()
    return (True, "MCP server '%s' %s" % (slug, "enabled" if enabled else "disabled"))


def mcp_unregister(server: str) -> tuple:
    client = _load("mcp_client")
    slug = str(server or "").strip()
    try:
        path = client.CONFIG_PATH
        data = json.loads(path.read_text(encoding="utf-8"))
        servers = data.get("servers") if isinstance(data, dict) else {}
        if slug not in (servers or {}):
            return (False, "unknown MCP server '%s'" % slug)
        servers.pop(slug)
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    except Exception as exc:
        return (False, "could not update MCP config: %s" % exc)
    _invalidate_mcp_health()
    return (True, "MCP server '%s' removed" % slug)


# ══════════════════════════════════════════════════════════════════════════
# 2. SKILL MANAGER  (adapter over the existing SKILL.md loader)
# ══════════════════════════════════════════════════════════════════════════
def _file_size(path) -> int:
    try:
        return Path(path).stat().st_size
    except Exception:
        return 0


def skills() -> list:
    """Installed skills with runtime enable/disable honoured.

    Wraps skill_loader so JARVIS keeps ONE loader identity - the prompt
    context and this manager can never disagree about what is installed.
    """
    loader = _load("skill_loader")
    try:
        rows = loader.load(force=True)
    except Exception as exc:
        return [{"name": "skills", "enabled": False, "error": str(exc), "kind": "skill"}]
    out = []
    for skill in rows:
        if not isinstance(skill, dict):
            continue
        name = str(skill.get("name") or "")
        out.append({
            "name": name, "slug": skill.get("slug") or name,
            "description": skill.get("description", ""),
            "triggers": skill.get("triggers") or [],
            "path": skill.get("path", ""), "kind": "skill",
            "enabled": not is_disabled("skill:" + name),
            "size_bytes": _file_size(skill.get("path")),
            "permission_category": "read_files",
        })
    return out


def skill_body(name: str) -> str:
    loader = _load("skill_loader")
    try:
        return loader.body(name) or ""
    except Exception:
        return ""


def skill_match(text: str, limit: int = 3) -> list:
    """Skills whose triggers match the text (disabled ones excluded)."""
    loader = _load("skill_loader")
    try:
        return [s for s in loader.match(text, limit=limit + 3)
                if not is_disabled("skill:" + str(s.get("name") or ""))][:limit]
    except Exception:
        return []


def skill_install(source_dir: str) -> tuple:
    """Install a skill folder that contains a SKILL.md."""
    src = Path(source_dir)
    if not src.is_dir():
        return (False, "not a folder: %s" % source_dir)
    if not any((src / n).is_file() for n in ("SKILL.md", "skill.md", "Skill.md")):
        return (False, "no SKILL.md found in %s" % src.name)
    slug = slugify(src.name)
    if not _slugs.match(slug):
        return (False, "invalid skill folder name '%s'" % src.name)
    dest = ROOT / "skills" / slug
    try:
        if dest.resolve() == src.resolve():
            return (False, "skill is already installed at %s" % slug)
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)
    except Exception as exc:
        return (False, "could not install skill: %s" % exc)
    try:
        _load("skill_loader").load(force=True)
    except Exception:
        pass
    return (True, "skill '%s' installed" % slug)


# ══════════════════════════════════════════════════════════════════════════
# 3. PLUGIN MANAGER  (new manifest-driven extension point)
# ══════════════════════════════════════════════════════════════════════════
def _plugin_manifest_path(folder: Path) -> Path:
    for name in ("plugin.json", "manifest.json"):
        candidate = folder / name
        if candidate.is_file():
            return candidate
    return folder / "plugin.json"


def _read_manifest(folder: Path) -> dict:
    try:
        data = json.loads(_plugin_manifest_path(folder).read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _folder_mtime(folder: Path) -> float:
    try:
        return folder.stat().st_mtime
    except Exception:
        return 0.0


def _parse_plugin(folder: Path) -> dict:
    """One plugin folder -> manifest + integrity + enable state."""
    slug = folder.name
    if not _slugs.match(slug):
        return None
    meta = _read_manifest(folder)
    entry = str(meta.get("entry") or "plugin.py").strip()
    try:
        entry_path = (folder / entry).resolve()
        inside = entry_path.is_relative_to(folder.resolve()) and entry_path.is_file()
    except Exception:
        inside = False
    tools = meta.get("tools") if isinstance(meta.get("tools"), list) else []
    return {
        "kind": "plugin", "name": str(meta.get("name") or slug), "slug": slug,
        "version": str(meta.get("version") or "0.0.0"),
        "description": str(meta.get("description") or "")[:300],
        "author": str(meta.get("author") or "")[:120],
        "category": str(meta.get("category") or "general")[:60],
        "tags": [str(t)[:40] for t in (meta.get("tags") or [])][:12],
        "entry": entry, "entry_ok": inside,
        "permission_category": str(meta.get("permission_category") or "execute_commands"),
        "requires_confirmation": bool(meta.get("requires_confirmation", True)),
        "config": meta.get("config") if isinstance(meta.get("config"), dict) else {},
        "tools": [str(t.get("name")) for t in tools
                  if isinstance(t, dict) and t.get("name")],
        "enabled": inside and not is_disabled("plugin:" + slug),
        "path": str(folder), "installed_at": _folder_mtime(folder),
    }


def plugins() -> list:
    """Every discoverable plugin folder, validated against its manifest."""
    if not PLUGIN_DIR.is_dir():
        return []
    out = []
    for folder in sorted(PLUGIN_DIR.iterdir()):
        if not folder.is_dir() or folder.name.startswith((".", "_")):
            continue
        parsed = _parse_plugin(folder)
        if parsed:
            out.append(parsed)
    return out


def _import_plugin(slug: str):
    """Import a plugin entry module (repo-local only, no shell, no network)."""
    key = "jarvis_plugin_" + str(slug)
    existing = sys.modules.get(key)
    if existing is not None:
        return (existing, "")
    try:
        folder = (PLUGIN_DIR / str(slug)).resolve()
        if not folder.is_relative_to(PLUGIN_DIR.resolve()) or not folder.is_dir():
            return (None, "plugin folder outside the plugins directory")
        entry = _read_manifest(folder).get("entry") or "plugin.py"
        path = (folder / str(entry)).resolve()
        if not path.is_relative_to(folder) or not path.is_file():
            return (None, "entry module missing: %s" % entry)
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
    except Exception as exc:
        sys.modules.pop(key, None)
        return (None, "import failed: %s: %s" % (type(exc).__name__, exc))
    return (mod, "")


def plugin_health(slug: str) -> dict:
    """Real health: can the entry module actually be imported?"""
    folder = PLUGIN_DIR / str(slug or "")
    parsed = _parse_plugin(folder) if folder.is_dir() else None
    if not parsed:
        return {"ok": False, "error": "plugin not found", "slug": slug}
    if not parsed["entry_ok"]:
        return {"ok": False, "error": "entry module missing", "slug": slug}
    mod, err = _import_plugin(slug)
    return {"ok": err == "" and mod is not None, "error": err, "slug": slug,
            "tools": parsed["tools"], "version": parsed["version"]}


def plugin_install(source: str) -> tuple:
    """Install a plugin from a folder or a .zip. No path escapes the repo.

    Validate-then-copy: a source without a manifest is rejected BEFORE anything
    is written, and any failure after the copy removes the partial install, so
    a failed install can never leave a half-plugin in the plugin directory.
    """
    src = Path(source)
    try:
        PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            slug = slugify(src.name)
            if not _slugs.match(slug):
                return (False, "invalid plugin folder name '%s'" % src.name)
            dest = PLUGIN_DIR / slug
            if dest.resolve() == src.resolve():
                return (False, "plugin is already installed at %s" % slug)
            manifest = _plugin_manifest_path(src)
            if not manifest.is_file():
                return (False, "no plugin.json/manifest.json found in '%s'"
                        % src.name)
            _replaced = dest.exists()
            if _replaced:
                shutil.rmtree(dest)
            shutil.copytree(src, dest)
        elif src.is_file() and src.suffix.lower() == ".zip":
            with zipfile.ZipFile(src) as zf:
                names = [n for n in zf.namelist() if n and not n.startswith("/")]
                roots = {n.split("/", 1)[0] for n in names if "/" in n}
                if len(roots) != 1:
                    return (False, "zip must contain exactly one plugin folder")
                slug = slugify(next(iter(roots)))
                if not _slugs.match(slug):
                    return (False, "invalid plugin folder name in zip")
                dest = PLUGIN_DIR / slug
                dest.mkdir(parents=True, exist_ok=True)
                for name in names:
                    if "/" not in name:
                        continue
                    target = (dest / name.split("/", 1)[1]).resolve()
                    if not target.is_relative_to(dest.resolve()):
                        shutil.rmtree(dest, ignore_errors=True)
                        return (False, "zip contains an unsafe path")
                    if name.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(name) as src_f, open(target, "wb") as out_f:
                            shutil.copyfileobj(src_f, out_f)
            if not _plugin_manifest_path(dest).is_file():
                shutil.rmtree(dest, ignore_errors=True)
                return (False, "no plugin.json/manifest.json in zip")
        else:
            return (False, "plugin source must be a folder or a .zip")
    except Exception as exc:
        try:
            if "dest" in dir() and Path(dest).is_relative_to(PLUGIN_DIR):
                shutil.rmtree(dest, ignore_errors=True)
        except Exception:
            pass
        return (False, "install failed: %s" % exc)
    # plugins() re-scans the directory on every call, so a new folder is
    # picked up immediately; no cache to invalidate here.
    return (True, "plugin '%s' installed" % slug)


def plugin_remove(slug: str) -> tuple:
    folder = PLUGIN_DIR / str(slug or "")
    if not folder.is_dir() or not folder.resolve().is_relative_to(PLUGIN_DIR.resolve()):
        return (False, "unknown plugin '%s'" % slug)
    try:
        shutil.rmtree(folder)
    except Exception as exc:
        return (False, "remove failed: %s" % exc)
    sys.modules.pop("jarvis_plugin_" + str(slug), None)
    return (True, "plugin '%s' removed" % slug)

# ══════════════════════════════════════════════════════════════════════════
# 4. RUNTIME ENABLE/DISABLE STATE (shared by all three managers)
# ══════════════════════════════════════════════════════════════════════════
def _load_state() -> dict:
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"disabled": []}
    return data if isinstance(data, dict) else {"disabled": []}


def _save_state(data: dict) -> None:
    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    except Exception:
        pass


def is_disabled(key: str) -> bool:
    return str(key or "") in _load_state().get("disabled", [])


def set_enabled(kind: str, name: str, enabled: bool) -> tuple:
    """Enable/disable any capability. Key is '<kind>:<name>'."""
    key = "%s:%s" % (str(kind or "").strip().lower(), str(name or "").strip())
    if not _slugs.match(str(name or "")):
        return (False, "invalid name '%s'" % name)
    if key.startswith("mcp:"):
        # The runtime switch is consulted when the health snapshot is built, so
        # a stale cache would keep showing the old enabled flag.
        _invalidate_mcp_health()
    elif key.startswith("plugin:"):
        # Toggling a plugin adds or removes its tools from the registry.
        _invalidate_mcp_health()
    with _lock:
        data = _load_state()
        disabled = [d for d in data.get("disabled", []) if d != key]
        if not enabled:
            disabled.append(key)
        data["disabled"] = sorted(set(disabled))
        data["updated_at"] = time.time()
        _save_state(data)
    return (True, "%s '%s' %s" % (kind, name, "enabled" if enabled else "disabled"))


def runtime_state() -> dict:
    return _load_state()


# ══════════════════════════════════════════════════════════════════════════
# 5. TOOL REGISTRY BRIDGE
# ══════════════════════════════════════════════════════════════════════════
def _plugin_tool_name(plugin: str, tool: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_]", "_", "plug_%s_%s" % (plugin, tool))
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$", safe):
        return ""
    if len(safe) > 64:
        safe = safe[:47] + "_" + hashlib.sha256(safe.encode()).hexdigest()[:16]
    return safe


def register_plugin_tools(registry) -> dict:
    """Register enabled plugin tools into the real cortex ToolRegistry.

    A plugin contributes tools by exposing a `TOOLS` list of dicts:
        {"name", "description", "parameters", "handler", "permission_category",
         "requires_confirmation"}
    `handler` is a plain Python callable, so there is no shell and no eval.
    Every handler is wrapped by the permission engine before it runs.
    """
    cortex = _load("cortex")
    perms = _load("permissions")
    registered = skipped = failed = 0
    errors = []
    for meta in plugins():
        if not meta.get("enabled"):
            skipped += 1
            continue
        mod, err = _import_plugin(meta["slug"])
        if mod is None:
            failed += 1
            errors.append("%s: %s" % (meta["slug"], err))
            continue
        specs = getattr(mod, "TOOLS", None)
        if not isinstance(specs, list) or not specs:
            skipped += 1
            continue
        for spec in specs:
            if not isinstance(spec, dict):
                skipped += 1
                continue
            raw = str(spec.get("name") or "").strip()
            handler = spec.get("handler")
            name = _plugin_tool_name(meta["slug"], raw)
            if not name or not callable(handler):
                skipped += 1
                continue
            category = str(spec.get("permission_category")
                           or meta.get("permission_category") or "execute_commands")

            def _wrap(fn=handler, cat=category, label=None):
                def _call(args: dict) -> dict:
                    # One user confirmation satisfies both gates: if the cortex
                    # confirm gate already approved THIS tool, consume that
                    # single-use record so the permission `ask` is satisfied too.
                    # A `deny` still wins - check() ignores `approved` for DENY.
                    approved = perms.take_approval(label) if label else False
                    verdict = perms.check(cat, tool=label or "", args=args or {},
                                          approved=approved)
                    if not verdict["allowed"]:
                        return {"ok": False, "output": verdict["reason"],
                                "requires_approval": verdict.get("requires_approval")}
                    try:
                        out = fn(dict(args or {}))
                    except Exception as exc:
                        return {"ok": False, "output": "plugin tool failed: %s: %s"
                                                    % (type(exc).__name__, exc)}
                    if isinstance(out, dict):
                        return out
                    return {"ok": True, "output": str(out)}
                return _call

            ok, _ = registry.register(cortex.ToolSpec(
                name,
                "%s [plugin %s] %s" % (str(spec.get("description") or "Plugin tool")[:200],
                                       meta["slug"], raw),
                _wrap(label=name),
                parameters=spec.get("parameters")
                if isinstance(spec.get("parameters"), dict) else {},
                requires_confirmation=bool(spec.get(
                    "requires_confirmation", meta.get("requires_confirmation", True))),
                timeout_s=float(spec.get("timeout_s", 20.0)),
                tags=("plugin", meta["slug"], raw, category)))
            if ok:
                registered += 1
            else:
                skipped += 1
    return {"registered": registered, "skipped": skipped, "failed": failed,
            "errors": errors[:8]}

# ══════════════════════════════════════════════════════════════════════════
# 6. MARKETPLACE  (local index; remote feeds need a URL, never a fake one)
# ══════════════════════════════════════════════════════════════════════════
def _bundled_marketplace() -> list:
    """Shipped catalog. Every entry points at something real in this repo."""
    return [
        {"id": "mcp-workspace", "name": "Workspace Reader (MCP)",
         "category": "mcp", "audience": "recommended",
         "description": "Read-only repo intelligence: list, read and search files.",
         "source": "bundled", "install": {"type": "mcp", "server": "files"},
         "requires": "none", "installed": True},
        {"id": "mcp-system", "name": "System Telemetry (MCP)",
         "category": "mcp", "audience": "recommended",
         "description": "Read-only CPU/RAM/disk/process snapshots and time.",
         "source": "bundled", "install": {"type": "mcp", "server": "system"},
         "requires": "none", "installed": True},
        {"id": "mcp-echo", "name": "Echo Connector (MCP)",
         "category": "mcp", "audience": "personal",
         "description": "Offline self-test connector, no credentials needed.",
         "source": "bundled", "install": {"type": "mcp", "server": "echo"},
         "requires": "none", "installed": True},
        {"id": "skill-meeting-notes", "name": "Meeting Notes (Skill)",
         "category": "skills", "audience": "recommended",
         "description": "Turn a rough transcript into structured meeting notes.",
         "source": "bundled", "install": {"type": "skill", "path": "skills/meeting-notes"},
         "requires": "none", "installed": True},
        {"id": "skill-daily-briefing", "name": "Daily Briefing (Skill)",
         "category": "skills", "audience": "recommended",
         "description": "A spoken morning brief from notes and calendar input.",
         "source": "bundled", "install": {"type": "skill", "path": "skills/daily-briefing"},
         "requires": "none", "installed": True},
        {"id": "ext-manager", "name": "Extension Manager (Plugin)",
         "category": "plugins", "audience": "recommended",
         "description": "Lists installed plugins, skills and MCP servers on demand.",
         "source": "bundled", "install": {"type": "plugin", "slug": "ext-manager"},
         "requires": "none", "installed": False},
    ]


def marketplace(query: str = "", category: str = "", audience: str = "") -> list:
    """Catalog rows with a live `installed` flag computed from the managers.

    `audience`: public | personal | recommended. `category`: mcp|skills|plugins.
    """
    rows = list(_bundled_marketplace())
    user_index = {}
    try:
        data = json.loads(MARKETPLACE_PATH.read_text(encoding="utf-8"))
        for row in (data.get("items") or []) if isinstance(data, dict) else []:
            if isinstance(row, dict) and row.get("id"):
                user_index[str(row["id"])] = row
    except Exception:
        pass
    for row in rows:
        custom = user_index.get(row["id"])
        if custom:
            row.update({k: v for k, v in custom.items() if k != "id"})
        row["installed"] = _market_installed(row)

    if category:
        want = str(category).strip().lower()
        rows = [r for r in rows if r.get("category") == want]
    if audience:
        want = str(audience).strip().lower()
        rows = [r for r in rows if r.get("audience") == want]
    if query:
        needle = str(query).strip().lower()
        rows = [r for r in rows if needle in ("%s %s %s" % (
            r.get("name", ""), r.get("description", ""), r.get("category", ""))).lower()]
    return rows


def _market_installed(row: dict) -> bool:
    spec = row.get("install") if isinstance(row.get("install"), dict) else {}
    kind = str(spec.get("type") or "")
    try:
        if kind == "mcp":
            return any(s.get("name") == spec.get("server")
                       for s in mcp_servers())
        if kind == "skill":
            want = str(spec.get("path") or "").rsplit("/", 1)[-1]
            return any(s.get("slug") == want for s in skills())
        if kind == "plugin":
            return any(p.get("slug") == spec.get("slug") for p in plugins())
    except Exception:
        return False
    return False


def marketplace_categories() -> list:
    return sorted({r.get("category") for r in _bundled_marketplace() if r.get("category")})


def marketplace_install(item_id: str) -> tuple:
    """Install a marketplace item through the real manager for its type."""
    row = next((r for r in marketplace() if r["id"] == str(item_id or "")), None)
    if not row:
        return (False, "unknown marketplace item '%s'" % item_id)
    spec = row.get("install") or {}
    kind = str(spec.get("type") or "")
    if kind == "mcp":
        return mcp_set_enabled(str(spec.get("server") or ""), True)
    if kind == "skill":
        return skill_install(str(spec.get("path") or ""))
    if kind == "plugin":
        return plugin_install(str(EXT_DIR / "plugins" / str(spec.get("slug") or "")))
    return (False, "item has no installable source")

# ══════════════════════════════════════════════════════════════════════════

def skill_remove(name: str) -> tuple:
    """Remove an installed skill. Refuses paths outside skills/."""
    loader = _load("skill_loader")
    try:
        skill = loader.get(name)
    except Exception:
        skill = None
    if not skill:
        return (False, "unknown skill '%s'" % name)
    path = Path(skill.get("path") or "")
    try:
        skills_dir = (ROOT / "skills").resolve()
        parent = path.parent.resolve()
        if not parent.is_relative_to(skills_dir) or parent == skills_dir:
            return (False, "refusing to remove %s (outside skills/)" % parent)
        if path.name.lower() == "skill.md":
            shutil.rmtree(parent)
        else:
            path.unlink()
    except Exception as exc:
        return (False, "could not remove skill: %s" % exc)
    try:
        loader.load(force=True)
    except Exception:
        pass
    return (True, "skill '%s' removed" % name)


def describe() -> str:
    """Spoken one-shot summary for the voice route."""
    caps = capabilities()
    counts = caps.get("counts") or {}
    return ("Sir, extensions ready: %d MCP connector(s), %d online; %d skill(s); "
            "%d plugin(s); %d tools (%d confirm-gated)."
            % (counts.get("mcp_total", 0), counts.get("mcp_online", 0),
               counts.get("skills", 0), counts.get("plugins", 0),
               counts.get("tools", 0), counts.get("tools_gated", 0)))
# 7. JARVIS AGENT  (discover -> select -> execute -> verify -> recover)
# ══════════════════════════════════════════════════════════════════════════
_TOOL_LIST_TTL = 20.0
_tool_list_cache = {"at": 0.0, "tools": None}


def _tool_list(force: bool = False) -> list:
    """Registry tool specs, cached briefly.

    build_default_registry() performs a real MCP discovery handshake, so
    re-running it on every dashboard poll is what made /extensions slow. The
    tool set only changes when MCP config or a plugin changes, both of which
    call _invalidate_mcp_health().
    """
    now = time.monotonic()
    cached = _tool_list_cache.get("tools")
    if (not force and cached is not None
            and now - _tool_list_cache.get("at", 0.0) < _TOOL_LIST_TTL):
        return cached
    tools = []
    try:
        registry = _load("cowork_tools").build_default_registry()
        # Plugin tools belong in the SAME registry the agent uses, otherwise the
        # UI would report a tool count that the planner can never call and a
        # plugin toggle would look like it did nothing.
        register_plugin_tools(registry)
        tools = registry.list()
    except Exception:
        tools = []
    with _lock:
        _tool_list_cache["tools"] = tools
        _tool_list_cache["at"] = now
    return tools


def capabilities() -> dict:
    """Everything JARVIS can currently do, from live subsystems only."""
    try:
        mcp_rows = mcp_servers()
    except Exception as exc:
        mcp_rows = [{"name": "mcp", "ok": False, "error": str(exc), "tools": []}]
    try:
        skill_rows = skills()
    except Exception as exc:
        skill_rows = [{"name": "skills", "enabled": False, "error": str(exc)}]
    try:
        plugin_rows = plugins()
    except Exception:
        plugin_rows = []
    tools = _tool_list()
    return {
        "mcp": mcp_rows,
        "skills": skill_rows,
        "plugins": plugin_rows,
        "tools": [{"name": t.name, "description": t.description[:160],
                   "requires_confirmation": t.requires_confirmation,
                   "tags": list(t.tags or ())} for t in tools],
        "counts": {
            "mcp_total": len(mcp_rows),
            "mcp_online": len([r for r in mcp_rows if r.get("ok")]),
            "skills": len(skill_rows),
            "plugins": len(plugin_rows),
            "plugins_enabled": len([p for p in plugin_rows if p.get("enabled")]),
            "tools": len(tools),
            "tools_gated": len([t for t in tools if t.requires_confirmation]),
        },
    }


def snapshot() -> dict:
    """One payload for the Extensions UI and the /extensions endpoint."""
    try:
        caps = capabilities()
    except Exception as exc:
        caps = {"mcp": [], "skills": [], "plugins": [], "tools": [],
                "counts": {}, "error": str(exc)}
    perms = _load("permissions")
    return {
        "mcp": caps.get("mcp") or [],
        "skills": caps.get("skills") or [],
        "plugins": caps.get("plugins") or [],
        "tools": caps.get("tools") or [],
        "counts": caps.get("counts") or {},
        "permissions": perms.policy(),
        "marketplace": marketplace(),
        "audit": perms.recent_audit(40),
        "ext_dir": str(EXT_DIR),
        "updated_at": time.time(),
    }


def select_capability(goal: str) -> dict:
    """Pick the best skill/plugin/tool for a goal. Deterministic, explainable.

    Returns {kind, name, reason, score}. Falls back to the brain when nothing
    matches, so this never guesses an action on its own.
    """
    text = str(goal or "").strip().lower()
    if not text:
        return {"kind": "none", "name": "", "reason": "empty goal", "score": 0.0}
    best = {"kind": "none", "name": "", "reason": "no matching capability",
            "score": 0.0}
    for skill in skill_match(text, limit=3):
        for trigger in (skill.get("triggers") or []):
            if len(trigger) >= 3 and trigger in text:
                score = len(trigger) / 40.0
                if score > best["score"]:
                    best = {"kind": "skill", "name": skill.get("name", ""),
                            "reason": "trigger '%s' matched" % trigger,
                            "score": min(1.0, score)}
    for tool in (capabilities().get("tools") or []):
        name = str(tool.get("name") or "").lower()
        if name and name in text:
            score = 0.8
            if score > best["score"]:
                best = {"kind": "tool", "name": tool.get("name", ""),
                        "reason": "tool name appears in the goal", "score": score}
    return best


def run_goal(goal: str) -> dict:
    """One real multi-step run through the existing Cortex agent loop.

    Cortex already owns Plan -> Act -> Observe with a step budget, loop
    detection and a confirmation gate; this only wires the extension system's
    tools into it, so no second agent engine is introduced.

    There is deliberately no `approve` flag here: approval belongs to the
    engine's confirm gate (and the permission engine's deny), so an HTTP
    caller cannot pretend to pre-approve a run.
    """
    cortex = _load("cortex")
    tools = _load("cowork_tools")
    registry = tools.build_default_registry()
    plug = register_plugin_tools(registry)

    # Reuse the ENGINE's real planner. It already speaks cortex's contract,
    # calls the same provider chain as the brain, and enforces the
    # never-invent-a-tool / never-repeat-a-call rules. Duplicating that logic
    # here would create a second, weaker agent loop.
    engine = _load("voice_engine")
    planner = getattr(engine, "_cortex_planner", None)
    if planner is None:
        return {"ok": False, "error": "planner unavailable",
                "plugin_tools": plug}

    ok, message = cortex.start(goal, planner, registry,
                               confirm=engine._cortex_confirm)
    if not ok:
        return {"ok": False, "error": message, "plugin_tools": plug}
    return {"ok": True, "run_id": cortex.snapshot().get("run_id"),
            "message": message, "tools": len(registry.list()),
            "plugin_tools": plug}


def _agent_prompt(goal: str, registry) -> str:
    rows = registry.catalog(max_rows=40)
    skill_context = ""
    try:
        skill_context = _load("skill_loader").context_for(goal)
    except Exception:
        skill_context = ""
    return ("EXTENSION SYSTEM ACTIVE. Goal: %s\n%s\n%s\n"
            "Reply with JSON: {\"done\": true, \"answer\": \"...\"} or "
            "{\"tool\": \"name\", \"args\": {...}}."
            % (goal[:500], rows, skill_context))
