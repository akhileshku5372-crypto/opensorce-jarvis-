"""WhatsApp Desktop (Windows Store app) driver - every step verified, fails closed.

Why this module exists: the old name-based path in `whatsapp_sender.py` opened the app,
guessed that Ctrl+F focuses the in-app search, pasted a name, pressed Enter, pasted a
message, pressed Enter, and returned success purely because nothing raised. It never
checked which chat was open and never checked that anything was sent. Two real
consequences:

  * it told the user "message bhej diya" when nothing left the composer, and
  * because `_wait_focus()` only tested the *window*, a failed search left the paste
    going into whichever chat was already open - i.e. a message to the wrong person.

Everything here is the opposite contract: an action is reported as done only when a
UIA element proves it happened, and the returned reason says exactly what was and was
not verified.

Requirements found by probing this machine (2026-10-19, the bugs that made every
send fail):
  * the visible window does NOT belong to WhatsApp.Root.exe - the Store app renders
    in WebView2, so the UI window is owned by a CHILD msedgewebview2.exe process
    (class `Chrome_WidgetWin_1`, title "(8) WhatsApp"). Matching windows against the
    root pid therefore never found it and every send died on "window nahi mili".
  * the app can sit in the tray with its window hidden (visible=False); UIA only
    returns live elements once it is restored, so the window is revealed first
  * the Store app renders in WebView2, so every element is mirrored ~3x - dedupe by
    runtime_id or one click becomes three
  * `DataItem.invoke()` raises NoPatternInterfaceError; `click_input()` works
  * automation ids are generated (`_r_e_`) - match on name + control type + position
  * the open chat is identified by a header Button named "<chat> <members...>", which
    sits BELOW the nav row (nav y=137, header y=150) and to the RIGHT of the chat-list
    splitter. A pure "top band" test returns the nav rail ("Chats") or even the app
    title text ("WhatsApp") instead of the chat name.
  * in-thread message bodies are NOT in the UIA tree, but the chat-list row preview
    does contain the last message, which is what makes send-verification possible
"""
from __future__ import annotations

import os
import re
import sys
import time

try:
    import whatsapp_media
except ImportError:                    # loaded by path (tests, _load_desktop)
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location(
        "whatsapp_media",
        os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "whatsapp_media.py"))
    whatsapp_media = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(whatsapp_media)
    sys.modules["whatsapp_media"] = whatsapp_media

APP_NAMES = ("WhatsApp.Root.exe", "WhatsApp.exe")
# The window that actually holds the UI, in preference order. The Store app is a
# WebView2 host: the real window belongs to a child msedgewebview2.exe process and
# is NOT in APP_NAMES. It is also a `Chrome_WidgetWin_1`, and that class is tried
# FIRST on purpose - the plain `WinUIDesktopWin32WindowClass` root of the same
# process also matches "whatsapp" and exposes a 12k-node duplicated UIA tree in
# which the chat rows and the composer cannot be resolved (rows=0, composer=None).
UI_CLASS_ORDER = ("Chrome_WidgetWin_1", "Chrome_WidgetWin_0",
                  "ApplicationFrameWindow", "WinUIDesktopWin32WindowClass")
UI_CLASS_HINTS = UI_CLASS_ORDER
MIN_MATCH = 0.62            # below this we refuse rather than guess a chat
OPEN_WAIT_S = float(os.environ.get("JARVIS_WA_OPEN_WAIT", "6.0"))
SEND_WAIT_S = float(os.environ.get("JARVIS_WA_SEND_WAIT", "10.0"))
TYPE_PAUSE = 0.02

# The composer is the only Edit whose name is blank and which sits in the bottom band
# of the window. The other Edit is the chat search box - typing a message there would
# just search.
SEARCH_NAME_HINT = "search or start a new chat"
# Matched as WHOLE WORDS, never as substrings. Plain substring matching broke a
# real contact: "Vivek Gautam (Ballu)" contains "all", so the hint for the "All"
# filter tab swallowed the actual chat name and header_chat() returned "" for it
# (measured 2026-10-19 - the chat opened, the composer was found, and the send
# still refused because the name could not be verified).
HEADER_HINTS = ("chats", "calls", "call", "status", "menu", "new chat", "profile",
                "search", "group video call", "unread", "all", "attach", "emoji",
                "voice message", "video call", "voice call", "back",
                # the chat-list splitter sits just right of the splitter line and
                # would otherwise be read as the chat name
                "resize", "chat list panel", "panel")


def _is_hint(norm_name: str, hints=HEADER_HINTS) -> bool:
    """True when the normalised name is one of the nav chrome labels."""
    words = set(norm_name.split())
    return any(hint in words for hint in hints)


def _process_running() -> list:
    """PIDs of running WhatsApp processes ([] when none is running)."""
    try:
        import psutil
        return [p.info["pid"] for p in psutil.process_iter(["pid", "name"])
                if (p.info["name"] or "") in APP_NAMES]
    except Exception:
        return []


def _activate_app(wait_s: float = 10.0) -> bool:
    """Wake a tray-only WhatsApp with its own protocol URI and wait for UI.

    Measured live 2026-10-19: the app runs as a background/tray process with
    NO top-level window, so every send died on "taskbar se open kijiye" - an
    instruction the OWNER has to obey for JARVIS to stay useful. Relaunching
    'whatsapp://' is exactly what tapping the taskbar icon does (ShellExecute
    on a fixed protocol string - no shell, no argv, no path), and the launch
    result is VERIFIED by waiting for a real window, not assumed.
    """
    if sys.platform != "win32" or not hasattr(os, "startfile"):
        return False
    if not _process_running():
        return False
    try:
        os.startfile("whatsapp://")      # noqa: S606 - fixed protocol, no argv
    except Exception:
        return False
    deadline = time.monotonic() + max(2.0, float(wait_s))
    while time.monotonic() < deadline:
        if _app_window_open():
            return True
        time.sleep(0.5)
    return bool(_ui_window_handles())


def available() -> tuple:
    """(ok, why) - pywinauto + a reachable WhatsApp window, or the reason not.

    Checks the WINDOW, not just the process: a running-but-tray-only app has no
    usable UI, and reporting "ready" there produced a send that quietly did
    nothing.
    """
    if sys.platform != "win32":
        return (False, "Windows pe hi chalta hai")
    try:
        import psutil  # noqa: F401
        from pywinauto import Desktop  # noqa: F401
    except Exception as exc:
        return (False, "pywinauto installed nahi (%s)" % type(exc).__name__)
    if not _ui_window_handles():
        if _process_running():
            # Tray-only app: wake it instead of pushing work onto the owner.
            if _activate_app():
                return (True, "ready (window khadi kari)")
            return (False, "WhatsApp app chal raha hai par uski window nahi khul paayi "
                           "- ek haath se app khulwao, phir main khud bhej dunga")
        return (False, "WhatsApp desktop app band hai")
    return (True, "ready")


def _ui_window_handles():
    """Every top-level window that could be the WhatsApp UI, best (largest) first.

    Found by window CLASS and TITLE, not by process name. Reason: the Microsoft
    Store build of WhatsApp is a WebView2 host, so the window that holds the chat
    list belongs to a child `msedgewebview2.exe` process. Filtering on
    WhatsApp.Root.exe / WhatsApp.exe pids therefore never matched it, `_window()`
    returned None on a machine where the app was open and logged in, and every
    send died on "WhatsApp ki window nahi mili" - which reads exactly like "the
    feature does not work".

    The title is checked for "whatsapp" but the class is what keeps an unrelated
    window out; "(8) WhatsApp" also carries the unread count, so an exact-title
    match would break the moment a message arrives.
    """
    if sys.platform != "win32":
        return []
    import ctypes
    user32 = ctypes.windll.user32
    found = []
    proc_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _cb(hwnd, _lparam):
        length = user32.GetWindowTextLengthW(hwnd)
        if not length:
            return True
        buf = ctypes.create_unicode_buffer(length + 2)
        user32.GetWindowTextW(hwnd, buf, length + 2)
        title = str(buf.value or "")
        if "whatsapp" not in title.casefold():
            return True
        cls_buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, cls_buf, 256)
        cls = str(cls_buf.value or "")
        if not any(cls.startswith(hint) for hint in UI_CLASS_HINTS):
            return True
        found.append((hwnd, title, cls))
        return True

    user32.EnumWindows(proc_type(_cb), 0)
    if not found:
        return []
    from ctypes import wintypes

    def _area(hwnd):
        rect = wintypes.RECT()
        try:
            user32.GetWindowRect(hwnd, ctypes.byref(rect))
        except Exception:
            return 0
        return (rect.right - rect.left) * (rect.bottom - rect.top)

    # Class preference first, area only as a tie-break WITHIN a class: a real UI is
    # never 0x0, and picking the bigger root window over the smaller WebView2 one
    # is what made rows/composer unresolvable.
    def _rank(item):
        hwnd, _title, cls = item
        for order, hint in enumerate(UI_CLASS_ORDER):
            if cls.startswith(hint):
                return (order, -_area(hwnd))
        return (len(UI_CLASS_ORDER), -_area(hwnd))

    ranked = sorted(found, key=_rank)
    best = ranked[0]
    return [best] if _area(best[0]) > 0 else []


def _reveal(hwnd, tries: int = 3) -> bool:
    """Bring the window forward so keystrokes and clicks actually reach it.

    Why this is not just SetForegroundWindow: Windows refuses to let a BACKGROUND
    process (the voice core, under PM2) take the foreground, so ShowWindow +
    SetForegroundWindow returned success while the window stayed behind the IDE -
    every search keystroke was typed into whatever the user was actually looking
    at, and the send silently never happened. Attaching the input queues of the
    calling thread to the target's and to the current foreground thread is the
    documented way to do this, and it is verified here by checking that
    GetForegroundWindow really is the target.

    The window restored is the app FRAME (`_app_frame`), never the WebView2 helper
    the UI tree lives in: the helper carries ex-style LAYERED|TOOLWINDOW|NOACTIVATE,
    so it cannot be activated at all, and while the app sat in the background
    _reveal still reported success on it while nothing was on screen. Measured
    2026-10-19: ShowWindow(SW_RESTORE) on the FRAME took IsWindowVisible from False
    to True and put the app back on screen; the same call on the helper does nothing.
    """
    import ctypes
    import time as _time
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    target = _app_frame() or int(hwnd or 0)
    if not target:
        return False
    for attempt in range(max(1, int(tries))):
        try:
            fg_hwnd = user32.GetForegroundWindow()
            current = kernel32.GetCurrentThreadId()
            target_thread = user32.GetWindowThreadProcessId(target, None)
            fg_thread = user32.GetWindowThreadProcessId(fg_hwnd, None)
            user32.AttachThreadInput(current, target_thread, True)
            if fg_thread and fg_thread != current:
                user32.AttachThreadInput(current, fg_thread, True)
            try:
                # A window that is not visible receives nothing at all, and the app
                # stays "running" in the background, so this restore is what makes
                # the rest of the flow possible.
                if not user32.IsWindowVisible(target):
                    user32.ShowWindow(target, 5)          # SW_SHOW
                user32.ShowWindow(target, 9)              # SW_RESTORE
                user32.BringWindowToTop(target)
                user32.SetForegroundWindow(target)
                user32.SetActiveWindow(target)
                user32.SetFocus(target)
            finally:
                user32.AttachThreadInput(current, target_thread, False)
                if fg_thread and fg_thread != current:
                    user32.AttachThreadInput(current, fg_thread, False)
            if _foreground_is_whatsapp():
                return True
        except Exception:
            return False
        _time.sleep(0.3)
    return False


def _app_frame():
    """The window that really SHOWS the app, or None.

    Measured on this machine (2026-10-19), and this is the whole reason JARVIS
    stopped sending: the UIA tree lives in a WebView2 window (class
    Chrome_WidgetWin_1, child of this frame) whose ex-style is
    LAYERED|TOOLWINDOW|NOACTIVATE. It cannot be activated, and when the owner
    closed the app to the background it stayed "visible" to the API while nothing
    was drawn on screen at all - so every check passed, every click landed on
    whatever was painted there (the IDE) and the search box only ever received
    part of a keystroke. The real frame is the WinUIDesktopWin32WindowClass window
    titled exactly "WhatsApp" that belongs to WhatsApp.Root.exe.
    """
    if sys.platform != "win32":
        return 0
    import ctypes
    user32 = ctypes.windll.user32
    hits = []

    def _cb(hwnd, _lparam):
        try:
            length = user32.GetWindowTextLengthW(hwnd)
            if not length:
                return True
            buf = ctypes.create_unicode_buffer(length + 2)
            user32.GetWindowTextW(hwnd, buf, length + 2)
            if str(buf.value or "").strip().casefold() != "whatsapp":
                return True
            cls_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buf, 256)
            if not str(cls_buf.value or "").startswith("WinUIDesktopWin32WindowClass"):
                return True
            hits.append(int(hwnd))
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p,
                                            ctypes.c_void_p)(_cb), 0)
    except Exception:
        return 0
    return hits[0] if hits else 0


def _app_window_open() -> bool:
    """Is the app really on screen (not just present in the UIA tree)?"""
    frame = _app_frame()
    if not frame:
        return True          # a build without a separate frame: nothing to check
    if sys.platform != "win32":
        return True
    import ctypes
    return bool(ctypes.windll.user32.IsWindowVisible(frame))


def _ensure_app_window(timeout: float = 8.0) -> tuple:
    """Make sure the app window is actually OPEN and on screen. (ok, why).

    A WhatsApp that was closed to the background still answers every check the old
    code did - the process runs, the UI tree exists, the search box resolves - and
    yet nothing can be typed or clicked, which is exactly what the owner saw. So the
    window is restored here and the result is verified rather than assumed.
    """
    if _app_window_open():
        return (True, "")
    handles = _ui_window_handles()
    if not handles:
        return (False, available()[1])
    deadline = time.monotonic() + max(1.0, float(timeout))
    while True:
        _reveal(handles[0][0], tries=1)
        if _app_window_open():
            return (True, "")
        if time.monotonic() >= deadline:
            break
        time.sleep(0.5)
    return (False, "WhatsApp ki window background me band thi aur khul nahi paayi - "
                   "usko ek baar khole rakhiye, phir main naam search karke bhej dunga")


def _window(restore: bool = True):
    import pywinauto
    try:
        desktop = pywinauto.Desktop(backend="uia")
    except Exception:
        return None
    for hwnd, _title, _cls in _ui_window_handles():
        if restore:
            _reveal(hwnd)
        try:
            win = desktop.window(handle=hwnd)
            if not win.exists(timeout=0.4):
                continue
            return win
        except Exception:
            continue
    return None


def _uniq(elems):
    """WebView2 mirrors every node ~3x; collapse so one action is one action."""
    seen, out = set(), []
    for e in elems:
        try:
            key = e.element_info.runtime_id
        except Exception:
            key = id(e)
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out


def _descendants(win):
    """The window's UIA tree, with one retry. [] when even that fails.

    Measured live 2026-10-19: a real send was reported as failed with a bare
    "send fail hua (KeyError: None)". pywinauto raises it while walking the WebView2
    tree - a stale element makes `known_control_type_ids[CurrentControlType]` look up
    None (uia_element_info line 112) - and WhatsApp rebuilds that tree every time the
    search filter changes. One retry turns a transient hiccup back into a send; if it
    still fails the caller sees no elements and reports a real failure, never a fake
    success.
    """
    for _attempt in range(2):
        try:
            return _uniq(win.descendants())
        except Exception:
            time.sleep(0.4)
    return []


def norm(value) -> str:
    """Lower-case, kill the NBSP WhatsApp puts in names, drop punctuation/emoji noise."""
    text = str(value or "").replace("\xa0", " ")
    text = text.casefold()
    text = re.sub(r"[^\w\u0900-\u097F\u3040-\u30ff ]+", " ", text)
    return " ".join(text.split())


def score(want: str, have: str) -> float:
    """0..1 similarity between a requested chat name and an element name.

    A chat NAME is short. Measured live 2026-10-19 the long strings in the list are
    message PREVIEWS and group member subtitles ("Comfort zone Akhilesh, Kushagra,
    Vivek, You", "Kushagra New No. 31/07/2026 Akhilesh bol raha tha"). They only
    ever CONTAIN the requested name, and the old fuzzy floor still scored them
    0.68-0.95 - above the refuse bar - so the click opened a group the owner never
    asked for. A long line can now only match as a PREFIX of the whole line.
    """
    a, b = norm(want), norm(have)
    if not a or not b:
        return 0.0
    if a == b or b.startswith(a):
        return 1.0
    words = b.split()
    if len(words) > 4:
        return 0.0
    # "the requested name is one word of the title" is evidence for a real chat NAME
    # ("Ballu" vs "Vivek Gautam (Ballu)").
    if a in words or b in a.split():
        return 0.95
    import difflib
    ratio = difflib.SequenceMatcher(None, a, b).ratio()
    if a in b:
        # "Comfort" matches "Comfort zone" strongly; a bare "General" inside a longer
        # name is weaker evidence.
        return max(ratio, 0.9 if b.startswith(a) else 0.55 + 0.4 * ratio)
    return ratio


_ROW_TAIL_RE = re.compile(
    r"\s+(?:\d{1,4}[/:.\-]\d{1,2}(?:[/:.\-]\d{1,4})?|\d{1,2}\s*[:.]\s*\d{2}"
    r"(?:\s*[ap]m)?|\d{1,2}:\d{2}"
    r"|yesterday|today|just now|now"
    r"|monday|tuesday|wednesday|thursday|friday|saturday|sunday"
    r"|(?:a|p|m)\s*m\.?\s*$)\b.*$",
    re.IGNORECASE)


def _row_candidates(name: str):
    """Plausible chat names inside one chat-list row.

    A row is not just the name: WhatsApp appends a date ("Vivek Gautam (Ballu)
    14/09/2026") or a last-message preview. Scoring the whole string dropped a
    real contact from 76% to 55%, below the refuse threshold, so the tail is
    stripped and the best projection wins.
    """
    text = " ".join(str(name or "").replace("\xa0", " ").split())
    if not text:
        return []
    out = [text, text.split("  ")[0][:60]]
    head = _ROW_TAIL_RE.sub("", text).strip()
    if head and head not in out:
        out.append(head)
        out.append(head.split("  ")[0][:60])
    return [c for c in out if c]


def best_row_score(want: str, name: str) -> float:
    """Highest similarity between `want` and any projection of a chat row."""
    highest = 0.0
    for candidate in _row_candidates(name):
        value = score(want, candidate)
        if value > highest:
            highest = value
        if highest >= 1.0:
            break
    return highest


def _chat_rows(win):
    """[(name, element)] from the chat list, best-scoring first."""
    out = []
    for e in _descendants(win):
        try:
            if e.element_info.control_type != "DataItem":
                continue
            nm = (e.window_text() or "").strip()
        except Exception:
            continue
        if nm:
            out.append((nm, e))
    return out


def _search_box(win):
    """The chat search field, or None.

    Measured facts (2026-10-19), all three needed:
      * the placeholder is "Search or start a new chat" while the box is empty;
      * once something is typed the accessible NAME becomes that text, so the
        placeholder can never be matched again - an earlier version found the box
        once per session and never again;
      * with a chat OPEN there are TWO Edits (search + composer). The composer is
        the one in the bottom band, so it must be excluded by position or the
        search returns None and no name can be typed at all.
    """
    edits = []
    for e in _descendants(win):
        try:
            if e.element_info.control_type != "Edit":
                continue
            edits.append(e)
        except Exception:
            continue
    for e in edits:
        try:
            if SEARCH_NAME_HINT in (e.window_text() or "").casefold():
                return e
        except Exception:
            continue
    try:
        bottom = win.rectangle().bottom
    except Exception:
        bottom = None
    upper = []
    for e in edits:
        try:
            if bottom is not None and e.rectangle().top >= bottom - 220:
                continue          # that is the message composer, not the search
            upper.append(e)
        except Exception:
            continue
    if len(upper) == 1:
        return upper[0]
    if not upper and edits:
        return edits[0]
    return None


def _clipboard_put(text: str) -> bool:
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except Exception:
        return False


def _foreground_hwnd() -> int:
    """Handle of the window that owns the keyboard right now, 0 when unknown."""
    if sys.platform != "win32":
        return 0
    import ctypes
    try:
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def _foreground_is_whatsapp() -> bool:
    """True only while the WhatsApp UI really owns the keyboard.

    Measured on this machine (2026-10-19) while sending real messages: the IDE
    takes the foreground back roughly once a second, so a synthesized keystroke is
    delivered to the IDE instead of to the app. That is how the search box kept the
    text "do" through a 56-backspace clear AND a Ctrl+V, and why a probe letter
    landed only about half the time. Everything that still needs a keystroke is
    gated on this check.

    Either the app FRAME or the WebView2 window it hosts counts as "WhatsApp":
    activating the app makes the frame the foreground window, while clicks land on
    the WebView2 window - both are the app being in front.
    """
    fg = _foreground_hwnd()
    if not fg:
        return False
    frame = _app_frame()
    if frame and int(fg) == int(frame):
        return True
    handles = _ui_window_handles()
    return bool(handles) and int(fg) == int(handles[0][0])


def _ensure_foreground(timeout: float = 4.0) -> bool:
    """Make WhatsApp the foreground window and CONFIRM it. False if it cannot."""
    handles = _ui_window_handles()
    if not handles:
        return False
    hwnd = handles[0][0]
    deadline = time.monotonic() + max(0.5, float(timeout))
    while True:
        if _foreground_hwnd() == hwnd:
            return True
        if time.monotonic() >= deadline:
            return False
        _reveal(hwnd, tries=1)
        time.sleep(0.25)


# When the socket drops WhatsApp shows its OWN recovery banner with a button
# that literally names "Reconnect" / "Try again", and until it is clicked the
# composer stays disabled. The owner asked for this to be handled ("reconnect
# mange tho kare"), and clicking that one button touches nothing else: it is
# WhatsApp's own UI, no message or attachment is involved. Anything else is
# left alone - a name that merely CONTAINS those words somewhere else must not
# be clicked.
_RECONNECT_RE = re.compile(
    r"^re-?\s?connect(?:ing|\s+required|\s+needed|\s+now)?$"
    r"|^try again$", re.I)


def _click_reconnect_if_shown(win):
    """Click WhatsApp's own 'Reconnect' button when it is showing. Returns the
    button name that was clicked ('' when the app never showed one)."""
    if win is None:
        return ""
    for e in _uniq(_descendants(win)):
        try:
            if e.element_info.control_type != "Button":
                continue
            nm = (e.window_text() or "").strip()
        except Exception:
            continue
        if nm and _RECONNECT_RE.fullmatch(nm.strip()):
            try:
                e.invoke()
                return nm
            except Exception:
                return ""
    return ""


def _hit_test(x: int, y: int) -> int:
    """Window handle at a screen point, 0 when it cannot be read."""
    if sys.platform != "win32":
        return 0
    import ctypes
    from ctypes import wintypes
    try:
        return int(ctypes.windll.user32.WindowFromPoint(wintypes.POINT(int(x), int(y))) or 0)
    except Exception:
        return 0


def _owns(target, hit) -> bool:
    """Is `hit` the window `target` itself or one of its children?"""
    if not target or not hit:
        return False
    if int(target) == int(hit):
        return True
    if sys.platform != "win32":
        return False
    import ctypes
    try:
        return bool(ctypes.windll.user32.IsChild(int(target), int(hit)))
    except Exception:
        return False


def _point_reaches(hwnd, x: int, y: int) -> bool:
    """Would a click at (x, y) land on WhatsApp, and not on whatever covers it?

    pywinauto clicks by moving the real cursor, so a window that is present but
    covered receives nothing - the IDE was measured covering the app. Without this
    check the row click looked harmless and the send failed later with a confusing
    "chat khuli par header se naam confirm nahi ho sakas".

    The FRAME is accepted as well as the WebView2 window, because that is what is
    really painted there: WindowFromPoint at a chat row returns the frame's own
    child (class Microsoft.UI.Content.Desktop), so testing only the WebView2 window
    refused clicks that would have hit the app perfectly and reported "WhatsApp ke
    upar koi doosri window hai" for a window that was in front all along.
    """
    targets = [t for t in (hwnd, _app_frame()) if t]
    if not targets:
        return False
    hit = _hit_test(x, y)
    for target in targets:
        if _owns(target, hit):
            return True
    return False


def _element_text(element) -> str:
    """Text of a UIA element; '' when the element has gone stale."""
    try:
        return element.window_text() or ""
    except Exception:
        return ""


def _pattern_write(box_factory, text: str, timeout: float = 5.0):
    """Write into a WebView2 box with the UIA ValuePattern. (ok, text, supported).

    This is the primary input path now, and it is the fix for the real failure: it
    needs NO keyboard focus and NO click. `box.set_edit_text()` reaches the control
    through UI Automation, where the old keyboard path (click, {END}, backspaces,
    Ctrl+V) did nothing at all while reporting that the click had worked - the
    owner saw it as "search box me 'vishesh' nahi likh paaya (usme 'do' hai)".

    Two measured details drive the code below:
      * the write is not instant - SetValue returns immediately and the box shows
        the new text a moment later. A single read-back reports the OLD value and
        looks like a failure (measured: SetValue("probeone") read back as the
        previous text, and the NEXT call showed "probeone"). So the value is
        polled.
      * the element is re-acquired for every read (`box_factory`) because the tree
        is rebuilt whenever the filtering changes.

    `supported` is False only when the control refuses the pattern altogether
    (AttributeError / pattern not available), which is what tells the caller to
    fall back to the keyboard instead of blaming the delivery.
    """
    box = box_factory()
    if box is None:
        return (False, "", True)
    try:
        box.set_edit_text(text)
    except Exception:
        return (False, _element_text(box), False)
    deadline = time.monotonic() + max(0.5, float(timeout))
    got = _element_text(box)
    while True:
        if norm(got) == norm(text):
            return (True, got, True)
        if time.monotonic() >= deadline:
            return (False, got, True)
        time.sleep(0.3)
        got = _element_text(box_factory())


def _focus_box(box) -> bool:
    """Give a WebView2 control the keyboard focus WITHOUT a mouse click.

    Measured 2026-10-19: UIA SetFocus works on both the search box and the message
    box ("do" -> "doz" with a probe letter), while a click on a window that had to
    be raised first is swallowed by the activation - which is exactly why the old
    click-then-type flow typed into nothing and left "do" sitting in the search box
    through a 56-backspace clear.
    """
    try:
        box.set_focus()
    except Exception:
        pass
    time.sleep(0.3)
    try:
        return bool(box.has_keyboard_focus())
    except Exception:
        return False


def _keyboard_write(box_factory, text: str) -> tuple:
    """Keyboard input path: the composer needs this (the ValuePattern is ignored).

    It refuses to type unless WhatsApp really owns the keyboard, because those
    keystrokes go to whatever window is in front - which on this machine is the
    user's own editor, so a blind retry can type into their code.
    """
    if not _foreground_is_whatsapp() and not _ensure_foreground():
        return (False, "", "keyboard WhatsApp par nahi hai")
    box = box_factory()
    if box is None:
        return (False, "", "box nahi mila")
    if not _focus_box(box):
        # A real click is the fallback for a machine where the window is comfortably
        # in front and UIA focus is not enough.
        try:
            box.click_input()
            time.sleep(0.35)
        except Exception:
            pass
    try:
        box.type_keys("{END}", pause=0.05)
        for _ in range(120):
            box.type_keys("{BACKSPACE}", pause=0.01)
        if not _clipboard_put(text):
            return (False, _element_text(box), "clipboard set nahi ho paya")
        box.type_keys("^a", pause=0.06)
        time.sleep(0.2)
        box.type_keys("^v", pause=0.08)
    except Exception as exc:
        return (False, _element_text(box), type(exc).__name__)
    time.sleep(1.0)
    got = _element_text(box_factory())
    return (norm(got) == norm(text), got, "")


def _type_search(search, name: str) -> tuple:
    """Put exactly `name` in the search box. Returns (ok, what_the_box_really_says).

    WhatsApp's WebView2 search box is unreliable for SYNTHETIC KEYBOARD input, and
    every trick was measured before this loop was written:

      * `^a` alone does NOT select-all - the old text survives and the new name is
        APPENDED (this produced the owner's "Comfortakhiles");
      * the app's own clear button ("End icon button") does not clear it;
      * pywinauto's `{BACKSPACE 60}` repeat syntax is dropped by this control;
      * typing one character at a time DROPS characters ("vivek ballu" arrived as
        "viveball", "vishesh" as "vishsh");
      * a clipboard paste usually lands, but not always - "vivek ballu" truncated
        to "vivek bal" once out of four attempts;
      * and, decisively, all of it depends on the window being foreground: while
        the IDE held the keyboard, 56 backspaces plus Ctrl+V left the box exactly
        as it was and the send failed with "search box me 'vishesh' nahi likh
        paaya (usme 'do' hai)".

    So the ValuePattern is used first (no focus, no click), and the keyboard is only
    a fallback for a build that does not expose the pattern. Either way the box is
    READ BACK and success requires an exact match, up to four attempts - a wrong
    search means opening the wrong chat, so the input is never assumed.
    """
    del search        # deliberately re-acquired; see the note above
    if not name:
        return (True, "")

    def _live_box():
        win = _window(restore=False)
        return _search_box(win) if win is not None else None

    last = ""
    pattern_supported = False
    for _attempt in range(4):
        ok, got, supported = _pattern_write(_live_box, name)
        if ok:
            return (True, got)
        last = got or last
        if supported:
            pattern_supported = True
        time.sleep(0.2)
    if pattern_supported:
        return (False, last)
    for _attempt in range(3):
        ok, got, _why = _keyboard_write(_live_box, name)
        if ok:
            return (True, got)
        last = got or last
    return (False, last)


def open_chat(name: str):
    """Search, pick, and VERIFY. Returns (ok, opened_chat_name, why)."""
    ok, why = available()
    if not ok:
        return (False, "", why)
    want = norm(name)
    if not want or len(want) > 60:
        return (False, "", "naam clear nahi hai")
    # A WhatsApp that was closed to the background still answers every other check -
    # the process runs, the UI tree exists - so the window is opened here first.
    ok_win, why_win = _ensure_app_window()
    if not ok_win:
        return (False, "", why_win)
    win = _window()
    if win is None:
        return (False, "", "WhatsApp ki window nahi mili (app minimize hai?)")
    # A dropped socket disables the composer until WhatsApp's own "Reconnect"
    # button is clicked - that clicks that button and nothing else.
    _reconnected = _click_reconnect_if_shown(win)
    if _reconnected:
        time.sleep(1.5)

    search = _search_box(win)
    if search is None:
        return (False, "", "search box UIA me nahi mila - WhatsApp ne UI badla hoga")
    # The name itself goes in through UI Automation, which needs no focus at all.
    # Bringing the window forward is still useful for the row CLICK below, so it is
    # attempted but no longer fatal - the click itself is verified against the
    # window that really owns that screen point.
    _ensure_foreground(timeout=3.0)
    typed_ok, box_text = _type_search(search, name)
    if not typed_ok:
        return (False, "", "search box me %r nahi likh paaya (usme %r hai) - kuch nahi "
                           "khola" % (name, str(box_text)[:24]))

    best, best_el, chosen = 0.0, None, ""
    spot = settled = None
    deadline = time.monotonic() + OPEN_WAIT_S
    while time.monotonic() < deadline:
        w = _window(restore=False) or win
        round_best, round_el, round_name = 0.0, None, ""
        for nm, el in _chat_rows(w):
            s = best_row_score(want, nm)
            if s > round_best:
                round_best, round_el, round_name = s, el, nm
        if round_el is not None and round_best > best:
            best, best_el, chosen = round_best, round_el, round_name
        if round_best >= MIN_MATCH:
            # WhatsApp fills the results in asynchronously. Measured live 2026-10-19:
            # the first passing row was clicked while the list was still moving and a
            # GROUP the owner never asked for opened ("Comfort zone" instead of
            # "Akhilesh"). A row is clicked only after the same pick (name + spot)
            # came back twice in a row, and a list that never settles is refused
            # rather than guessed.
            try:
                r = round_el.rectangle()
                round_spot = (norm(round_name), r.left, r.top)
            except Exception:
                round_spot = (norm(round_name), 0, 0)
            if spot == round_spot:
                settled = (round_best, round_el, round_name)
                break
            spot = round_spot
        time.sleep(0.4)
    if settled is not None:
        best, best_el, chosen = settled
    elif best_el is None or best < MIN_MATCH:
        return (False, "", "koi chat %r se match nahi hui (best %.0f%%) - kuch nahi khola"
                % (name, best * 100))
    else:
        return (False, "", "WhatsApp ki chat list lagatar badal rahi thi (result rukte "
                           "hi nahi) - galti se kisi aur ko na chala jaye, isliye kuch "
                           "nahi khola. Dobara boliye.")
    try:
        rect = best_el.rectangle()
    except Exception as exc:
        return (False, "", "chat row rect fail: %s" % type(exc).__name__)
    handles = _ui_window_handles()
    wa = handles[0][0] if handles else 0
    click_x = rect.left + max(4, rect.width() // 3)
    click_y = rect.top + max(3, rect.height() // 2)
    if wa and not _point_reaches(wa, click_x, click_y):
        # Something is covering WhatsApp (the IDE was measured doing it), so the
        # click would land on THAT window and the chat would never open.
        _ensure_foreground(timeout=3.0)
    if wa and not _point_reaches(wa, click_x, click_y):
        return (False, "", "WhatsApp ke upar koi doosri window hai - chat row ka click "
                           "wahan chala jata, isliye kuch nahi khola. Usko minimize "
                           "karke boliye.")
    try:
        best_el.click_input()
    except Exception as exc:
        return (False, "", "chat row click fail: %s" % type(exc).__name__)
    time.sleep(1.5)
    win = _window(restore=False) or win

    # THE check the old code never did: is the chat that is actually open the one we
    # asked for? The header exposes a Button named "<chat> <member, member, ...>".
    opened = header_chat(win)
    if not opened:
        return (False, "", "chat khuli par header se naam confirm nahi ho saka - "
                           "message NAHI bheja")
    if not _header_matches(want, opened):
        return (False, opened, "wrong chat khuli ('%s' maanga tha, '%s' mila) - "
                               "message NAHI bheja" % (name, opened))
    return (True, _strip_header_suffix(opened),
            "verified: %s" % _strip_header_suffix(opened))


def header_chat(win):
    """The name of the chat currently open, or ''.

    Measured on this machine (2026-10-19): the chat header sits BELOW the nav row
    (nav y=137, header y=150) and to the RIGHT of the chat-list splitter
    (splitter x=650, header x=739, call buttons x=942). A naive "first unfiltered
    element in the top band" returned the nav rail or even the 'WhatsApp' window
    title, so the verification step compared the wrong name and refused every send
    as "wrong chat khuli". Hence two extra rules: ignore anything at or above the
    nav row's own top, and ignore anything left of the splitter.
    """
    try:
        rect = win.rectangle()
        top, left, right = rect.top, rect.left, rect.right
    except Exception:
        return ""
    # Measured: window top=76, nav row y=137, chat header y=150, so the header is
    # ~+74 from the window top - BELOW the nav row but only just. The old +118 band
    # missed it entirely (header_chat returned ''), and the original "top 90" band
    # matched the nav rail first.
    band_top = top + 30
    band_bottom = top + 130
    splitter = _chat_list_right_edge(win)
    if splitter is None:
        splitter = left + int((right - left) * 0.45)
    for e in _descendants(win):
        try:
            if e.element_info.control_type not in ("Button", "Text", "Hyperlink"):
                continue
            nm = (e.window_text() or "").strip()
            if not nm or len(nm) > 120:
                continue
            er = e.rectangle()
            if er.top < band_top or er.top > band_bottom:
                continue
            if er.left < splitter:
                continue
        except Exception:
            continue
        low = norm(nm)
        if _is_hint(low):
            continue
        return nm
    return ""


# WhatsApp appends a subtitle to a contact's header when the number is not saved
# as a name: "Akhilesh click here for contact info", "Vivek Gautam (Ballu) click
# here for contact info". Those words are UI chrome, not the chat name, and
# comparing them against the requested name made a CORRECT match score below the
# refuse threshold (measured 2026-10-19 - "vivek ballu" vs the opened header).
_HEADER_SUFFIX_RE = re.compile(
    r"\s*(?:click\s+(?:here|to)\s+(?:for\s+|to\s+)?"
    r"(?:(?:contact|group|business)\s*info|see|view)"
    r"|open\s+chat|add\s+to\s+contacts?)\s*$",
    re.IGNORECASE)


def _strip_header_suffix(name: str) -> str:
    """The chat name a human would recognise, without WhatsApp's UI subtitle."""
    text = _HEADER_SUFFIX_RE.sub("", str(name or "").strip()).strip()
    return text or str(name or "").strip()


def _header_matches(want: str, header: str) -> bool:
    """Is the chat that opened the one that was asked for?

    Measured live 2026-10-19: a GROUP header is the group name followed by its
    MEMBERS ("Comfort zone Akhilesh, Kushagra, Vivek, You"). The old word-anywhere
    fallback accepted that as a match for "akhilesh", so a group click would have been
    taken as the right chat and the message would have gone to the whole group. Only
    the chat NAME may match now: a refusal is recoverable, a wrong-chat send is not.
    """
    opened = norm(_strip_header_suffix(header))
    if not opened or not want:
        return False
    return score(want, opened) >= MIN_MATCH


def _chat_list_right_edge(win):
    """x of the chat-list panel's right edge, or None when it is not in the tree."""
    try:
        for e in _descendants(win):
            try:
                if e.element_info.control_type != "DataGrid":
                    continue
                width = e.rectangle().width()
                if width > 60:
                    return e.rectangle().right
            except Exception:
                continue
    except Exception:
        return None
    return None


def _escape(text: str) -> str:
    """pywinauto type_keys metacharacters. `{c}` means "the literal character c"."""
    out = []
    for ch in str(text or ""):
        out.append("{%s}" % ch if ch in "^+%~%(){}[]" else ch)
    return "".join(out)


def _composer(win):
    """The message box: the Edit in the BOTTOM band, never the search field.

    Identified by POSITION, not by having an empty name. The old version skipped
    any Edit whose name was longer than 3 characters, which is only true of an
    untouched composer - the moment text is typed the accessible name becomes that
    text, and the composer could no longer be found at all. That made every send
    after the first impossible ("composer not found") and left half-typed text
    sitting in the box.
    """
    try:
        rect = win.rectangle()
        bottom = rect.bottom
    except Exception:
        return None
    fallback = None
    for e in _descendants(win):
        try:
            if e.element_info.control_type != "Edit":
                continue
            nm = (e.window_text() or "").strip()
            if SEARCH_NAME_HINT and SEARCH_NAME_HINT in nm.casefold():
                continue          # that is the chat search field
            r = e.rectangle()
            if r.width() <= 0 or r.height() <= 0:
                continue
            if r.top < bottom - 220:
                continue          # above the bottom band: not the composer
            if fallback is None:
                fallback = e
            # The composer is the widest box down there; the search field is never
            # in this band, but prefer width anyway when both somehow appear.
            if r.width() > (fallback.rectangle().width() if fallback else 0):
                fallback = e
        except Exception:
            continue
    return fallback


def _preview_contains(name: str, text: str) -> bool:
    """Proof of delivery: the chat-list row for `name` now previews our message.

    The name tested is the chat HEADER, and that header carries extra words the
    chat-list row never shows - measured live, the header reads "Akhilesh click
    here for contact info" while the row reads "Akhilesh 12:22 pm ...". Requiring
    the whole header therefore reported a FAILURE for a message that was
    demonstrably delivered. The full name is tried first, then progressively
    shorter prefixes, so a real match is still required - this widens the name,
    never the message.
    """
    win = _window()
    if win is None:
        return False
    snippet = norm(text)[:24]
    if not snippet:
        return False
    full = norm(name)
    if not full:
        return False
    words = full.split()
    forms = [full]
    for take in (3, 2, 1):
        if len(words) > take:
            forms.append(" ".join(words[:take]))
    for nm, _el in _chat_rows(win):
        row = norm(nm)
        if snippet not in row:
            continue
        for form in forms:
            if form and form in row:
                return True
    return False


def send(chat: str, text: str, mention: str = ""):
    """Open -> verify chat -> (mention) -> put the body -> send -> verify preview.

    Returns (ok, spoken_reason). Never returns ok=True without the preview check.
    """
    ok, opened, why = open_chat(chat)
    if not ok:
        return (False, why)
    body = str(text or "").strip()
    if not body:
        return (False, "message khaali hai - kuch nahi bheja")

    def _live_composer():
        return _composer(_window(restore=False))

    if _composer(_window()) is None:
        return (False, "%s khula hai par message box nahi mila - kuch nahi bheja" % opened)

    ok_body, why_body = _put_message(_live_composer, body, mention)
    if not ok_body:
        # Never leave a half-written message sitting in someone's chat box.
        _clear_any(_live_composer)
        return (False, why_body)

    ok_send, why_send = _press_send(_live_composer)
    if not ok_send:
        _clear_any(_live_composer)
        return (False, why_send)

    deadline = time.monotonic() + SEND_WAIT_S
    while time.monotonic() < deadline:
        if _preview_contains(opened, body):
            return (True, "%s ko message bhej diya, chat-list preview pe verify ho gaya"
                    % opened)
        time.sleep(0.5)
    # Enter was pressed but the proof never arrived. Delivery is genuinely unknown -
    # the chat-list preview is the only proof this app offers - so it is reported as
    # unconfirmed and never as sent.
    if _element_text(_live_composer()).strip():
        _clear_any(_live_composer)
        return (False, "%s me Enter dabaya par preview me message nahi dikha, aur text "
                       "composer me hi pada hai - bheja nahi gaya lagta hai" % opened)
    return (False, "%s me Enter dabaya aur composer khaali ho gaya, par preview me message "
                   "nahi dikha - bheja gaya ya nahi confirm NAHI hai" % opened)


# --- media: paste a real FILE and send it through the attachment preview ----
# Measured live 2026-10-19: pasting a CF_HDROP file into the composer opens an
# attachment strip whose Button is named "Open photo, <file>, item 1 of 1",
# next to "Send 1 selected" and "Remove attachment". invoke() on the send
# button needs no keyboard focus, and the chat-list row changes to
# "<time> Photo" once the file has really gone out.

ATTACH_WAIT_S = float(os.environ.get("JARVIS_WA_ATTACH_WAIT", "8.0"))


def _row_preview(name: str) -> str:
    """The chat-list row text of one chat ('' when the row is not there)."""
    win = _window(restore=False)
    if win is None:
        return ""
    want = norm(name)
    if not want:
        return ""
    for nm, _el in _chat_rows(win):
        if want in norm(nm):
            return nm
    return ""


def last_message_preview(name: str) -> str:
    """The verified chat-list row (name + time + last message preview).

    WhatsApp's UIA tree exposes the chat-list preview, not in-thread message
    bodies. This is the honest readout after opening a chat: it is the last
    message only, never the full thread. Uses the same scored row match as
    open_chat(), so a group row that merely contains the name cannot win.
    """
    win = _window(restore=False)
    if win is None:
        return ""
    want = norm(name)
    if not want:
        return ""
    best, best_name = 0.0, ""
    for nm, _el in _chat_rows(win):
        s = best_row_score(want, nm)
        if s > best:
            best, best_name = s, nm
    return best_name if best >= MIN_MATCH else ""


def _attachment_preview(win, filename: str):
    """The measured proof an attachment is really staged: a Button/TabItem that
    NAMES the file ('Open photo, x.png, item 1 of 1'). Returns (element, name)."""
    want = norm(os.path.basename(str(filename or "")))
    if not want:
        return None, ""
    for e in _uniq(_descendants(win)):
        try:
            if e.element_info.control_type not in ("Button", "TabItem"):
                continue
            nm = e.window_text() or ""
        except Exception:
            continue
        n = norm(nm)
        if want in n and n.startswith("open"):
            return e, nm
    return None, ""


def _attachment_send_button(win):
    """The staged attachment's own send button ('Send 1 selected')."""
    for e in _uniq(_descendants(win)):
        try:
            if e.element_info.control_type != "Button":
                continue
            nm = (e.window_text() or "").strip()
        except Exception:
            continue
        if re.match(r"(?i)^send\b.*\bselected\b", nm):
            return e, nm
    return None, ""


def _discard_attachment(win, box_factory) -> None:
    """Remove a staged attachment. A half-attached file is never left behind."""
    for e in _uniq(_descendants(win)):
        try:
            if e.element_info.control_type != "Button":
                continue
            nm = (e.window_text() or "").strip().casefold()
        except Exception:
            continue
        if nm.startswith("remove attachment"):
            try:
                e.invoke()
                return
            except Exception:
                try:
                    e.click_input()
                    return
                except Exception:
                    pass
    box = box_factory()
    if box is not None:
        try:
            box.type_keys("{ESC}", pause=0.05)
            time.sleep(0.3)
            box.type_keys("{ESC}", pause=0.05)
        except Exception:
            pass


def send_file(chat: str, path: str):
    """Open -> verify chat -> paste the FILE -> verify the attachment preview ->
    press the staged send button -> prove the chat-list row changed.

    Returns (ok, spoken_reason). Exactly like send(): ok=True only with the
    delivery proof; every other exit says what did NOT happen and leaves
    nothing staged in the composer.
    """
    target = str(path or "").strip()
    if not target or not os.path.isfile(target):
        return (False, "file hi nahi mili - kuch nahi bheja")
    ok, opened, why = open_chat(chat)
    if not ok:
        return (False, why)
    fname = os.path.basename(target)

    def _live():
        return _composer(_window(restore=False))

    if _live() is None:
        return (False, "%s khula hai par message box nahi mila - kuch nahi bheja"
                % opened)
    before = _row_preview(opened)
    _clear_any(_live)
    if not _foreground_is_whatsapp() and not _ensure_foreground():
        return (False, "keyboard WhatsApp par nahi aa paaya - paste nahi kiya, "
                       "kuch nahi bheja")
    if not whatsapp_media.copy_file(target):
        return (False, "file clipboard pe nahi rakhi ja saki - kuch nahi bheja")
    box = _live()
    if box is None:
        return (False, "message box nahi mila - kuch nahi bheja")
    try:
        box.click_input()
        time.sleep(0.4)
        box.type_keys("^v", pause=0.08)
    except Exception as exc:
        _discard_attachment(_window(restore=False), _live)
        return (False, "paste fail (%s) - kuch nahi bheja" % type(exc).__name__)

    staged, _staged_name = None, ""
    deadline = time.monotonic() + ATTACH_WAIT_S
    while time.monotonic() < deadline:
        win = _window(restore=False)
        staged, _staged_name = _attachment_preview(win, fname)
        if staged is not None and _attachment_send_button(win)[0] is not None:
            break
        time.sleep(0.4)
    if staged is None:
        _discard_attachment(_window(restore=False), _live)
        return (False, "attachment preview nahi aaya - file paste nahi hui, "
                       "kuch nahi bheja")
    btn, _btn_name = _attachment_send_button(_window(restore=False))
    if btn is None:
        _discard_attachment(_window(restore=False), _live)
        return (False, "send button nahi mila - attachment hata diya, kuch nahi bheja")
    try:
        btn.invoke()
    except Exception:
        if not _ensure_foreground():
            _discard_attachment(_window(restore=False), _live)
            return (False, "send button dab nahi paaya - attachment hata diya, "
                           "kuch nahi bheja")
        try:
            btn.click_input()
        except Exception as exc:
            _discard_attachment(_window(restore=False), _live)
            return (False, "send click fail (%s) - attachment hata diya, kuch nahi "
                           "bheja" % type(exc).__name__)

    deadline = time.monotonic() + SEND_WAIT_S
    while time.monotonic() < deadline:
        after = _row_preview(opened)
        if after and after != before:
            low = after.casefold()
            stem = os.path.splitext(fname)[0].casefold()
            if (any(w in low for w in ("photo", "video", "audio", "document"))
                    or (stem and stem in low)):
                return (True, "%s ko %s bhej diya, chat-list preview pe verify ho "
                              "gaya" % (opened, whatsapp_media.classify(target)))
            return (False, "%s ki chat-list row badli (%s) par usme media nahi "
                           "dikha - bheja gaya ya nahi confirm NAHI hai"
                    % (opened, after[:40]))
        time.sleep(0.5)
    if _attachment_preview(_window(restore=False), fname)[0] is not None:
        _discard_attachment(_window(restore=False), _live)
        return (False, "send ke baad attachment wahi pada hai - bheja nahi gaya "
                       "lagta hai")
    return (False, "%s me send dabaya par chat-list preview me media nahi dikha - "
                   "bheja gaya ya nahi confirm NAHI hai" % opened)


def _put_message(box_factory, body: str, mention: str = "") -> tuple:
    """Get the message into the composer, VERIFIED. Returns (ok, spoken_reason).

    Measured 2026-10-19, because the two boxes on this screen are NOT the same:
      * the SEARCH box takes the UIA ValuePattern with no keyboard focus at all -
        that is what made "vishesh" land while the IDE kept stealing the foreground;
      * the MESSAGE box ignores it. `set_edit_text` and the raw
        `iface_value.SetValue` both return without error and change nothing (it is a
        contenteditable), while a focus-verified keyboard paste lands exactly
        (measured "PROBE-A does not get sent") and single characters arrive intact.

    So the pattern is only TRIED here (cheap, and correct on a build that supports
    it) and the keyboard does the real work. "supported" is deliberately not trusted
    on the composer: it reports support and then ignores the write.
    """
    person = str(mention or "").strip()
    if person:
        return _put_mention(box_factory, body, person)
    ok, got, _supported = _pattern_write(box_factory, body, timeout=1.5)
    if ok:
        return (True, "")
    ok_kb, got_kb, why = _keyboard_write(box_factory, body)
    if ok_kb:
        return (True, "")
    detail = why or str(got_kb or got)[:24]
    return (False, "message composer me nahi gaya (%s) - Enter nahi dabaya, kuch nahi "
                   "bheja" % detail)


def _put_mention(box_factory, body: str, person: str) -> tuple:
    """@-mention + body. Keyboard only, because the picker answers to typed "@"."""
    if not _foreground_is_whatsapp() and not _ensure_foreground():
        return (False, "mention ke liye keyboard WhatsApp par chahiye, par focus kahin "
                       "aur hai - kuch nahi bheja")
    box = box_factory()
    if box is None:
        return (False, "message box nahi mila - kuch nahi bheja")
    try:
        box.type_keys("@", pause=TYPE_PAUSE)
        time.sleep(0.9)
        if not _pick_mention(_window(restore=False), person):
            return (False, "'%s' ka mention list me nahi mila - kuch nahi bheja" % person)
        box.type_keys(_escape(body), pause=TYPE_PAUSE, with_spaces=True)
    except Exception as exc:
        return (False, "mention type fail: %s - kuch nahi bheja" % type(exc).__name__)
    time.sleep(0.6)
    if not _text_in_composer(box_factory(), body):
        return (False, "mention ke saath message composer me theek se nahi dikha - "
                       "kuch nahi bheja")
    return (True, "")


def _clear_any(box_factory) -> str:
    """Empty a box, ValuePattern first. Leaves no half-written draft behind."""
    ok, got, _supported = _pattern_write(box_factory, "", timeout=1.0)
    if ok:
        return got
    box = box_factory()
    return _clear_composer(box) if box is not None else ""


def _press_send(box_factory) -> tuple:
    """Send the composed message. Returns (ok, spoken_reason).

    Enter is the ONLY keystroke the send path still needs, and it is gated on the
    foreground check. That gate is not only about reliability: with the IDE in
    front, Enter is delivered to the IDE (a real, unwanted side effect in whatever
    the user is writing) and the message would not have been sent either.
    """
    for _attempt in range(3):
        if not _ensure_foreground():
            continue
        box = box_factory()
        if box is None:
            return (False, "message box nahi mila - kuch nahi bheja")
        try:
            box.type_keys("{ENTER}", pause=TYPE_PAUSE)
            return (True, "")
        except Exception as exc:
            return (False, "send key fail: %s" % type(exc).__name__)
    return (False, "Enter nahi daba paaya - WhatsApp foreground me nahi aa paaya (koi "
                   "doosri window focus le rahi hai) - message NAHI bheja")


def _composer_text(box) -> str:
    try:
        return box.window_text() or ""
    except Exception:
        return ""


def _clear_composer(box, max_backspaces: int = 400) -> str:
    """Empty the message box. {END} + individual {BACKSPACE} is the only clear
    that measured 100% on this WebView2 control (the app's own clear button and
    Ctrl+A both failed)."""
    try:
        box.click_input()
        time.sleep(0.3)
        box.type_keys("{END}", pause=0.05)
        for _ in range(max_backspaces):
            box.type_keys("{BACKSPACE}", pause=0.008)
        time.sleep(0.7)
    except Exception:
        pass
    return _composer_text(box)


def _text_in_composer(box, body: str) -> bool:
    """Is the message really sitting in the composer?

    Checked in three places rather than only at the start, because the keystroke
    synthesiser drops characters: typing measured "Hello Sir" arriving as "elloSir",
    which a prefix-only check can pass while the message is wrong. Requiring the
    head, a middle chunk AND the tail to all be present catches that.
    """
    got = norm(_composer_text(box))
    want = norm(body)
    if not want or not got:
        return False
    if want in got:
        return True
    head = want[:14]
    mid = want[len(want) // 2: len(want) // 2 + 14]
    tail = want[-14:]
    return bool(head and mid and tail) and head in got and mid in got and tail in got


def _paste_into(box, text: str) -> bool:
    """Put `text` in the box as ONE event. Typing drops characters (measured:
    "vivek ballu" -> "viveball"), so the body is pasted and then verified."""
    if not _clipboard_put(text):
        return False
    try:
        box.type_keys("^a", pause=0.06)
        time.sleep(0.25)
        box.type_keys("^v", pause=0.08)
        time.sleep(1.2)
    except Exception:
        return False
    return True


def _pick_mention(win, person: str) -> bool:
    """After '@', WhatsApp shows a member list. Click the matching row, if any."""
    want = norm(person)
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        for nm, el in _chat_rows(win):
            if want and want in norm(nm):
                try:
                    el.click_input()
                    return True
                except Exception:
                    return False
        time.sleep(0.3)
    return False


def unread_summary(limit: int = 5):
    """What 'WhatsApp kholo aur batao' can honestly answer: unread chats + previews."""
    ok, why = available()
    if not ok:
        return (False, why)
    win = _window()
    if win is None:
        return (False, "window nahi mili")
    rows = []
    for nm, _el in _chat_rows(win):
        low = nm.lower()
        if "unread message" in low or re.search(r"^\s*\d+\s*unread", low):
            rows.append(" ".join(nm.replace("\xa0", " ").split())[:110])
        if len(rows) >= limit:
            break
    if not rows:
        return (True, "koi unread chat nahi dikhi")
    return (True, "; ".join(rows))
