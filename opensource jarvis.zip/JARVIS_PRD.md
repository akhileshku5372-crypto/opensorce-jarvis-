# J.A.R.V.I.S. — Master Product Requirements Document

**Version:** 1.0.0  
**Status:** Master Product Requirements  
**Target:** Windows desktop/laptop  
**Primary interface:** Natural voice conversation  
**Secondary interfaces:** Existing JARVIS UI, text, hand gestures

## 1. Product Vision

JARVIS is a persistent personal AI desktop assistant that lets the user interact naturally through voice, text, vision, hand gestures, web intelligence, memory, and controlled computer actions.

The target experience is not a chatbot requiring buttons or predefined commands. JARVIS should understand natural language, choose appropriate tools, execute actions, report results, and return to standby.

### Core loop

```text
Hey Jarvis → Wake → Listen → Understand → Reason/Plan
→ Tool/Action/Answer → Speak → Auto-resume
```

## 2. Priorities

| Priority | Meaning |
|---|---|
| P0 | Mandatory core functionality |
| P1 | Important advanced functionality |
| P2 | Future/hardware-dependent functionality |

P0 examples: voice, wake word, STT, TTS, LLM, dynamic actions, continuous loop.  
P1 examples: web research, memory, browser control, vision, gesture integration.  
P2 examples: robotics, smart-home integration, suit/wearable integration.

## 3. Core Architecture

```text
JARVIS UI
    ↓
JARVIS CORE RUNTIME
    ├── Conversation / State / Memory
    ├── Voice: STT / TTS / VAD
    └── LLM Brain
            ↓
      Intent / Tool Router
            ↓
 Browser / Windows / Files / Web / Vision / Gesture
            ↓
 Validation → Result → TTS
```

Requirements:
- Voice, LLM, STT, TTS, search and vision providers must be modular.
- UI must not be the assistant's core runtime.
- JARVIS must run independently of a visible browser tab.
- Use one canonical action/tool router.
- Avoid duplicate runtimes and duplicate action systems.

## 4. P0 — Continuous Voice

### Wake word
Default: **Hey JARVIS**

- No listening-button requirement for normal operation.
- Wake detection remains active in standby.

### Continuous conversation

```text
WAKE → LISTEN → UNDERSTAND → RESPOND/ACT → SPEAK → AUTO-RESUME
```

### Barge-in
If JARVIS is speaking and the user speaks:
1. Detect speech.
2. Immediately stop/cancel TTS.
3. Start listening.
4. Process the new utterance.

### Required states
`STANDBY`, `LISTENING`, `THINKING`, `SEARCHING`, `EXECUTING`, `SPEAKING`, `INTERRUPTED`, `ERROR`

## 5. P0 — Speech

STT/TTS should support:
- English
- Hindi
- Hinglish
- Japanese
- Mixed-language speech
- Additional languages supported by the selected provider

Support streaming/low-latency STT where practical, VAD, silence detection, noise handling, microphone selection, Bluetooth/headset microphones, laptop microphones, and device reconnects.

### TTS sanitization

Never send raw URLs, Markdown, JSON, code, tool payloads, HTML, or internal identifiers directly to TTS.

Bad: `Opening https colon slash slash youtube...`  
Good: `Opening YouTube.`

## 6. P0 — LLM Brain

The LLM handles:
- Natural-language understanding
- Reasoning
- Context
- Intent selection
- Tool selection
- Response generation
- Multi-step planning
- Multilingual understanding

Use a provider abstraction so the model can be replaced without rewriting JARVIS.

## 7. P0 — Dynamic Intent Engine

JARVIS must understand arbitrary natural-language requests and must not depend on a small hardcoded command list.

Routing categories may include:

`CONVERSATION`, `QUESTION`, `WEB_SEARCH`, `WEBSITE`, `APPLICATION`, `FILE`, `FOLDER`, `SYSTEM_CONTROL`, `BROWSER_ACTION`, `MEDIA`, `AUTOMATION`, `MULTI_STEP_TASK`

These are routing concepts, not limits on user requests.

A search must accept arbitrary user queries. Do not restrict searches to predefined examples such as YouTube, NotebookLM, JEE, or PCM.

## 8. P0 — Windows Control

Support, where authorized:
- Open/close/minimize/maximize/switch applications
- Open/search/create/read/rename/copy/move files and folders
- Clipboard
- Volume
- Screenshots
- System/battery/network information
- Window management

Application launches such as `Open VS Code` should launch the application directly without an unnecessary visible CMD/PowerShell window.

## 9. P0 — Browser Control

Support:
- Arbitrary websites
- Arbitrary web searches
- Navigation
- Tabs
- Back/forward
- Page reading where supported
- Page summarization
- In-page search

One complete utterance should normally cause one intended execution. Prevent duplicate actions and unnecessary tab creation.

## 10. P0 — Filesystem Intelligence

Understand natural-language requests such as:
- Open Downloads
- Find my physics notes
- Open my current project
- Find PDFs related to MEXT
- Create a folder

Use filesystem discovery rather than blindly sending every request to web search.

## 11. P0 — Tool System

Example tools:

`web_search`, `open_website`, `browser_control`, `open_application`, `open_file`, `open_folder`, `file_search`, `screenshot`, `screen_analysis`, `volume_control`, `clipboard`, `system_info`, `mouse_control`, `keyboard_control`, `gesture_control`

Tools require schemas, validation, timeouts, duplicate-call protection, normalized results, safe execution, and logging.

Never give the LLM unrestricted shell execution.

## 12. P0 — Security

Require validation for computer-control tools. Destructive/irreversible actions should require confirmation where appropriate, including deleting files, overwriting files, shutdown/restart, destructive system changes, external messages, and similar operations.

## 13. P1 — Web Intelligence

Support:
- Real-time web search
- News/current information
- Research
- Website discovery
- Result summarization
- Multi-source comparison
- Fact extraction
- Search refinement
- Follow-up research

Use live data when the question requires current information.

## 14. P1 — Memory

Memory layers:
- Current context
- Working memory
- Recent conversation
- Long-term memory

Avoid uncontrolled growth, duplicates, irrelevant storage, memory leaks, and inappropriate retention.

## 15. P1 — Multi-Step Tasks

Target flow:

```text
UNDERSTAND → PLAN → EXECUTE → OBSERVE → CORRECT → COMPLETE
```

Example: research multiple universities, compare them, and summarize the results.

## 16. P1 — Vision

Where supported:
- Camera
- Hand detection/landmarks
- Finger tracking
- Gesture recognition
- Screen understanding
- OCR
- Visual Q&A
- Object recognition
- UI analysis

## 17. P1 — Hand Gesture

**Existing working hand-gesture implementation is protected.**

Support:
- Hand skeleton
- Finger tracking
- Gesture recognition
- Cursor movement
- Click/double-click
- Drag
- Scroll
- Gesture-based UI interaction

The skeleton should remain clearly visible and sufficiently thick. Gesture control must not interfere with normal mouse operation unless active.

## 18. P1 — UI

The UI should represent real runtime states:
`IDLE`, `LISTENING`, `THINKING`, `SEARCHING`, `EXECUTING`, `SPEAKING`, `INTERRUPTED`, `ERROR`.

The voice orb should provide:
- Listening particle movement
- Thinking/processing animation
- Speaking audio-reactive particles

Animations should reflect actual runtime state.

## 19. P1 — Background Runtime

The JARVIS core must run independently of the visible UI/browser.

Expected:
- Chrome closed → voice can continue
- Chrome minimized → voice can continue
- UI minimized → voice can continue

The UI is an interface, not the assistant's brain.

## 20. P1 — System Monitoring

Where available:
- CPU
- GPU
- RAM
- Storage
- Battery
- Temperature
- Network
- Running processes
- Microphone/speakers
- Connected devices

## 21. P1 — Research and Technical Assistance

Support assistance with:
- Programming
- Debugging
- Mathematics
- Physics
- Chemistry
- Research
- Documentation
- File analysis
- Project analysis
- Codebase understanding
- Architecture planning
- Data analysis

## 22. P1 — Productivity

Potential modules:
- Notes
- Tasks
- Reminders
- Timers
- Calendar
- Documents
- Code generation
- Project management
- Clipboard assistance
- Summarization
- Translation
- Text transformation

## 23. P2 — Future Hardware

Use a device abstraction layer for future authorized:
- Phone
- Camera
- Smart devices
- Robotics
- Wearables
- External sensors

## 24. MCU JARVIS Reference Capabilities

These are fictional MCU references and architectural inspiration, not claims of available laptop hardware.

Reference capabilities include:
- Natural-language computer interface
- Stark technology management
- Mansion/environment control
- Suit integration
- Suit telemetry
- Health/vital monitoring
- Threat analysis
- Tracking
- Energy analysis
- Structural/environmental analysis
- Holographic analysis
- Security systems
- Facility control
- Remote computer interaction
- Iron Legion coordination
- Parallel processing
- Research assistance
- Natural personality

Translate these into real capabilities where possible. For example:
- Suit telemetry → laptop hardware telemetry
- Mansion control → authorized smart-device integration
- Holographic analysis → desktop visualization
- Security system → authorized computer/security monitoring
- Research assistant → web + documents + LLM reasoning

Do not fake unavailable hardware.

## 25. Out of Scope for Laptop MVP

Unless additional hardware exists:
- Iron Man armor control
- Repulsors
- Arc Reactor control
- Flight control
- Armor weapons
- Physical suit telemetry
- Biological vital sensors
- Physical Iron Legion robots
- Stark mansion hardware
- Physical holographic projectors
- Fictional satellite infrastructure

## 26. Provider Architecture

Use modular interfaces for:

```text
VoiceProvider
 ├── STT
 ├── TTS
 └── Realtime voice

SearchProvider
 ├── Provider A
 └── Provider B

VisionProvider
 ├── Local
 └── Cloud
```

Optional provider failure must not crash the entire assistant.

## 27. Performance

Priority:
1. Low latency
2. Reliable STT
3. Fast intent detection
4. Fast tool execution
5. Streaming responses
6. Immediate TTS
7. Speech interruption
8. Minimal unnecessary API calls
9. No duplicate actions
10. Stable long-running operation

Prefer a simple reliable architecture over a complex slow one.

## 28. Reliability

Extended operation must avoid:
- Memory leaks
- Duplicate listeners
- Duplicate actions
- Process accumulation
- Microphone lockups
- TTS deadlocks
- Browser-tab explosions
- Repeated tool calls
- State corruption

## 29. Error Recovery

When a feature fails:
1. Detect failure.
2. Identify the reason.
3. Retry when safe.
4. Use an alternative method when available.
5. Explain concisely.
6. Return to a usable state.

## 30. Configuration and Secrets

- Existing `.env` is a protected secret store.
- Never commit API keys.
- Never log complete keys.
- Use centralized configuration.
- Missing credentials must produce clear errors.
- Never hardcode keys in source.

## 31. Dependencies

Dependencies must be:
- Declared
- Reproducibly installed
- Validated at startup
- Kept minimal
- Checked before adding duplicates

## 32. Runtime

Production runtime should provide:
- One canonical JARVIS process
- One canonical voice runtime
- One canonical action router
- Clear process ownership
- Clean startup/shutdown
- Background execution
- Structured logs
- Recoverable errors

Avoid accidentally running old and new voice pipelines simultaneously.

## 33. Existing Project Protection

Unless explicitly authorized, protect:
- Existing UI/frontend
- Dashboard
- PRD
- `.env`
- Existing working hand-gesture module

If a protected component must change for technical reasons, stop and explain why before changing it.

## 34. Migration / Integration

When importing another codebase such as `Mark-LI-main`:
1. Inspect both codebases.
2. Identify reusable functionality.
3. Identify duplicates.
4. Connect useful imported modules to the active runtime.
5. Do not leave imported modules disconnected.
6. Avoid blind overwrites.
7. Preserve protected files.
8. Merge dependencies safely.
9. Use one canonical action router.
10. Verify end-to-end behavior.

Imported source files alone do not constitute integration.

## 35. Testing

Every P0 capability requires an end-to-end test.

### Voice
`Hey Jarvis → wake → listen → understand → respond → speak → resume`

### Arbitrary search
`Search the web for [any user query] → exactly one intended search → answer`

### Application
`Open VS Code → direct launch → no unnecessary CMD window`

### Browser
`Open YouTube → open YouTube → do not speak the URL character-by-character`

### Follow-up
`Search Japan universities → Only engineering ones → use previous context`

### Interruption
`JARVIS speaking → user speaks → TTS stops → JARVIS listens`

## 36. Definition of Done

A feature is complete only when:
- It works end-to-end.
- It works through the intended interface.
- Errors are handled.
- Duplicate execution is prevented.
- Protected functionality remains intact.
- No unnecessary manual UI interaction is required.
- The runtime returns to a stable state.

## 37. P0 Acceptance Checklist

- [ ] Wake word works
- [ ] No listening button required
- [ ] Continuous conversation works
- [ ] STT works
- [ ] TTS works
- [ ] Barge-in works
- [ ] Multilingual speech works
- [ ] LLM reasoning works
- [ ] Dynamic intent routing works
- [ ] Arbitrary web searches work
- [ ] Arbitrary websites open
- [ ] Applications launch directly
- [ ] Files/folders open
- [ ] Duplicate execution is prevented
- [ ] URLs are not spoken character-by-character
- [ ] Background runtime works
- [ ] Existing UI remains functional
- [ ] Existing hand gesture remains functional

## 38. P1 Acceptance Checklist

- [ ] Web research works
- [ ] Conversation memory works
- [ ] Browser control works
- [ ] Vision works
- [ ] Hand gesture integration works
- [ ] Screen understanding works
- [ ] System monitoring works
- [ ] Multi-step tasks work
- [ ] Productivity tools work
- [ ] Error recovery works reliably

## 39. P2 Roadmap

Future versions may add:
- Phone integration
- Smart-home control
- Robotics
- Wearables
- External sensors
- Advanced 3D/holographic interfaces
- Multi-device runtime
- Authorized remote-device control

## 40. Final Product Definition

> **JARVIS is a persistent, fast, multilingual, voice-first AI computer assistant that understands natural language, maintains context, dynamically chooses tools, controls the user's authorized computer environment, searches the live web, performs multi-step tasks, speaks naturally, can be interrupted, and continues operating in the background.**

Core principle:

```text
Natural conversation
        +
Reliable reasoning
        +
Dynamic tools
        +
Safe computer control
        +
Persistent runtime
        =
JARVIS
```

**End of PRD — Version 1.0.0**
