import os, json, base64, requests
from pathlib import Path
from dotenv import dotenv_values

vals = {}
for f in ('.env', '.dev.vars'):
    if Path(f).exists():
        vals.update({k: v for k, v in dotenv_values(f).items() if v})

for k, v in vals.items():
    if not os.environ.get(k):
        os.environ[k] = v

def _get_gemini_keys():
    keys = []
    for var_name in ('GOOGLE_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY_2', 'GEMINI_API_KEY_2'):
        val = (os.environ.get(var_name) or '').strip()
        if val and val not in keys:
            keys.append(val)
    return keys

def _gemini_synthesize(text, lang='en'):
    keys = _get_gemini_keys()
    if not keys:
        return None
    styles = {
        'en': 'clear, sophisticated, British-accented intelligent AI assistant',
        'hi': 'clear, polite, natural Hindi assistant',
        'hinglish': 'natural, conversational bilingual Hinglish assistant',
        'ja': 'polite, clear, respectful Japanese assistant'
    }
    style = styles.get(lang, styles['en'])
    payload = {
        'contents': [{
            'role': 'user',
            'parts': [{
                'text': text,
                'speech_metadata': {'style': style}
            }]
        }],
        'generationConfig': {
            'responseModalities': ['AUDIO'],
            'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': 'Puck'}}}
        }
    }
    tts_models = ['gemini-3.8-flash-tts', 'gemini-3.8-flash-lite-tts', 'gemini-3.1-flash-tts-preview']
    for m in tts_models:
        for k in keys:
            url = f'https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent'
            try:
                r = requests.post(url, headers={'x-goog-api-key': k, 'Content-Type': 'application/json'}, json=payload, timeout=12)
                if r.status_code == 200:
                    cand = r.json().get('candidates', [{}])[0]
                    parts = cand.get('content', {}).get('parts', [])
                    audio_part = next((p for p in parts if 'inlineData' in p), None)
                    if audio_part:
                        b64_data = audio_part['inlineData'].get('data', '')
                        return base64.b64decode(b64_data)
                elif r.status_code in (429, 503, 500):
                    print(f'Model {m} on key returned {r.status_code}, rotating key...')
                    continue
            except Exception:
                continue
    return None

def _gemini_transcribe(wav_bytes, lang='en'):
    keys = _get_gemini_keys()
    if not keys:
        return '', lang
    wav_b64 = base64.b64encode(wav_bytes).decode('utf-8')
    prompt = """You are the JARVIS high-precision Speech Recognition engine.
Context vocabulary: JARVIS, Jarvis, sir, status, system, weather, report.
Transcribe the spoken audio verbatim in its original spoken language.
Strict Rules:
1. The transcription MUST strictly be in one of these four languages:
   - English (e.g., 'Jarvis, check battery status')
   - Hindi in Devanagari script (e.g., 'जार्विस, सिस्टम रिपोर्ट दो')
   - Hinglish in Latin script (e.g., 'Jarvis, system status batao')
   - Japanese (e.g., 'ジャーヴィス、状況を報告してください')
2. Output ONLY the raw transcription text without any quotes, speaker tags, timestamps, or explanation.
3. If the audio is silent, background static, or unintelligible noise, output an empty string.
"""
    payload = {
        'contents': [{
            'parts': [
                {'inlineData': {'mimeType': 'audio/wav', 'data': wav_b64}},
                {'text': prompt}
            ]
        }],
        'generationConfig': {'temperature': 0.0}
    }
    models = ['gemini-flash-lite-latest', 'gemini-flash-latest', 'gemini-3.8-flash']
    for m in models:
        for k in keys:
            url = f'https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent'
            try:
                r = requests.post(url, headers={'x-goog-api-key': k, 'Content-Type': 'application/json'}, json=payload, timeout=12)
                if r.status_code == 200:
                    cand = r.json().get('candidates', [{}])[0]
                    text = cand.get('content', {}).get('parts', [{}])[0].get('text', '').strip()
                    if text in ['EMPTY', 'empty', '""', "''"]:
                        return '', lang
                    return text, lang
                elif r.status_code in (429, 503, 500):
                    print(f'STT model {m} returned {r.status_code}, rotating key...')
                    continue
            except Exception:
                continue
    return '', lang

# Generate speech with failover
wav_bytes = _gemini_synthesize('Jarvis, please run a diagnostic check on all subsystems.', 'en')
print('Synthesized WAV byte length:', len(wav_bytes) if wav_bytes else 0)

# Transcribe with failover
if wav_bytes:
    text, out_lang = _gemini_transcribe(wav_bytes, 'en')
    print('Transcribed text:', repr(text), 'Language:', out_lang)
