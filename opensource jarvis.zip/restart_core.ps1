# Use the same portable launcher; never hard-code a user directory/interpreter.
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'start-jarvis.ps1') -Float
