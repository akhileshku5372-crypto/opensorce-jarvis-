"""Self-learning P1 at the route level: corrections become durable learnings.

Run through run_command, so the exact place Sir speaks is what is tested:
  * "nahi, aise bolo..." -> spoken back "note kar liya", stored on device;
  * a bare "nahi karo" (a pending deny) records NOTHING;
  * "kya seekha?" reads the learning back;
  * the brain prompt (_memory_context) carries the standing orders.
Stdlib only - brain/speak faked, no mic, no TTS, no network.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_bg(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / ("%s.py" % name))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load_bg("voice_engine")
LEARNING = _load_bg("learning")


class _FakeAgent:
    def has_pending(self):
        return False


class CorrectionRouteTest(unittest.TestCase):
    def setUp(self):
        self.spoken = []
        self.agent = _FakeAgent()
        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: None
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        LEARNING.purge()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_a_correction_is_recorded_and_spoken_back(self):
        handled, said = self._route("nahi, short me bolo")
        self.assertTrue(handled)
        self.assertIn("note kar liya", said)
        stats = LEARNING.readoff()
        self.assertEqual(stats.get("total"), 1)
        self.assertEqual(stats.get("corrections"), 1)
        self.assertIn("short me bolo", stats.get("latest", [])[0])

    def test_a_bare_deny_records_nothing(self):
        handled, said = self._route("nahi karo")
        self.assertTrue(handled)
        self.assertEqual(LEARNING.readoff().get("total"), 0)
        self.assertNotIn("note kar liya", said)

    def test_kya_seekha_reads_the_learning_back(self):
        LEARNING.record("aisa mat karo - short bolo", "correction")
        handled, said = self._route("kya seekha tune")
        self.assertTrue(handled)
        self.assertIn("seekh", said)
        self.assertIn("short bolo", said)

    def test_the_brain_prompt_carries_the_standing_order(self):
        LEARNING.record("nahi, short bolo", "correction")
        prompt = ENGINE._memory_context("hello")
        self.assertIn("short bolo", prompt)

    def test_learning_failure_changes_nothing(self):
        # learning.py unimportable -> old behaviour, reply still flows.
        saved = ENGINE._load_bg

        def broken(name):
            if name == "learning":
                raise ImportError("learning khatam (test)")
            return saved(name)

        ENGINE._load_bg = broken
        try:
            handled, said = self._route("kya seekha tune")
            self.assertTrue(handled)
            self.assertNotIn("short bolo", said)
        finally:
            ENGINE._load_bg = saved


if __name__ == "__main__":
    unittest.main(verbosity=2)
