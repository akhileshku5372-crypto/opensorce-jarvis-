# JARVIS Voice Assistant — Failure Analysis & Duplex Design

**Date:** 2026-10-16 · **Workspace:** `C:\Users\PRATEEK\Desktop\jarvis-2.0`
**Scope:** voice in/out only. No new registry, no second mic pipeline (AGENTS.md invariant).

---

## 1. Why "every engine failed" — measured, not assumed

Live probe on 2026-10-16 against this project's own `.dev.vars` keys, no mic involved:

| Engine | Measured | Verdict |
|---|---|---|
| Groq STT `whisper-large-v3-turbo` | **1.18s**, transcript exact | healthy |
| `GOOGLE_API_KEY` | valid, 63 models visible | healthy |
| Gemini TTS `gemini-3.8-flash-lite-tts` | 3.4s OK once → then **HTTP 429 quota**; later **170s** for one sentence | unusable as primary |
| Gemini TTS `gemini-2.5-flash-preview-tts` | 4.4s OK | usable as backup |
| edge-tts `en-GB-RyanNeural` | **2.0s, 18.5 KB mp3** | healthy, and it was switched off |
| Kokoro-82M | package absent; HF cache 2.1 MB = **weights never downloaded** | never existed at runtime |
| PM2 | `pm2 list` empty, :7777/:7778/:7780 refused | the assistant was **off**, not broken |

### The five defects that produced the silence

1. **All three fallbacks were opt-in and nobody had opted in.** `edge-tts` required
   `JARVIS_FALLBACK_EDGETTS_ENABLE=1`, ElevenLabs required `JARVIS_ELEVENLABS_FALLBACK=1`,
   SAPI required `JARVIS_SAPI_ENABLE=1`. None of the three appear in `.env` or `.dev.vars`.
   So one Gemini 429 → `audio_path = None` → **text on screen, no sound**. This is the
   single direct cause of "koi Tony Stark-level voice nahi mili".
2. **`timeout=8` on the Gemini TTS POST** while TTS legitimately takes 3.4s–170s. Every
   slow-but-valid render raised, and the `except` path called `_mark_key_unhealthy()` →
   **both keys parked for 300s**. One bad second produced five minutes of muteness.
3. **`speech_metadata` was sent inside the message part.** It is not part of the API, so the
   "British-accented intelligent assistant" style was silently dropped — the voice was never
   shaped by it. `voiceName: 'Puck'` is an upbeat American voice; the British male identity
   lives in `tts_voice()` as `en-GB-RyanNeural`, which was unreachable because of defect 1.
4. **Attempt cascade.** 3 models × N keys, each up to 8s = a ~48s worst case before the
   chain gave up. That stall is almost certainly *why* the fallbacks were gated off —
   someone traded "no voice" for "very late voice".
5. **No streaming.** `speak()` synthesises the entire reply to a temp file, then plays it.
   STT 1.2s + LLM + TTS 4s ≈ **7–9s of dead air per turn**, which is the actual reason it
   never felt like Gemini Live — not the model choice.

### What the research paste got wrong

`SenseVoice-Small` has **no Hindi** (Mandarin, Cantonese, English, Japanese, Korean only), so
the recommendation to use it as the Hindi/Hinglish STT was wrong. `Voxtral TTS` and
`Fish Audio S2 Pro` are real but need CUDA; this machine runs `torch 2.14.1+cpu` on a Ryzen 7
250 with a Radeon 780M iGPU and 15.3 GB RAM, so every sub-50/70/100 ms figure in that paste
describes hardware the user does not own. `Kokoro-82M` **does** cover Hindi + Japanese (v1.0,
8 languages) and is CPU-viable — that part was accurate. The paste also recommended Silero VAD
and OpenWakeWord, both of which were already installed (`silero-vad 6.2.3`, `openwakeword 0.6.0`).

---

## 2. The invariant that decides the design

Gemini Live feels live because it is **native audio-to-audio over a persistent duplex
stream on Google's TPUs**, not because of a clever pipeline. Two separate wants:

- **Behaviour** — always-on listening, barge-in, only-my-voice, Hinglish, dry British male.
  Reproducible today on this CPU with free tiers. **This is the goal.**
- **Implementation** — end-to-end speech model. Not reproducible on 15 GB CPU-only RAM
  (3–4 B audio models ⇒ 5–15 s per turn). **Do not chase this here.**

## 3. Engine contract (the offline migration seam)

Every TTS engine already has the same shape — `(text, lang) -> path|None`. That is the seam:
on the future mini-server, register a new engine name in `_TTS_ORDER` (e.g. `kokoro`,
`f5`, `voxtral`) and nothing else in `speak()` changes. Same for STT. Keep it that way.

Ordering rationale, by measured latency: `edge` (2.0s, carries the JARVIS identity) →
`gemini` (4–4.6s, expressive, quota-capped) → `sapi` (English only, last resort) →
later `kokoro` (local, when weights exist). ElevenLabs stays available but off-path — it
costs money.

## 4. Implemented today

- `background/voice_engine.py` — `_TTS_ORDER`, `_TTS_FAILS`, `_TTS_DOWN_UNTIL`,
  `_tts_engine_ready()`, `_tts_report()`: engines are tried in order, always on, and a dead
  one is skipped after 2 consecutive failures for 120s instead of paying its timeout each
  turn. `_gemini_synthesize()`: timeout 8s→25s (env `JARVIS_GEMINI_TTS_TIMEOUT`), a timeout
  no longer poisons a key (only 429/503 rotate), 4xx stops the key loop, dead
  `speech_metadata` removed, model list and voice now env-overridable.
- `tests/test_tts_engine_chain.py` — 8 tests. **Verified red on HEAD, green after the fix**:
  Gemini failure still yields audio; edge first; chain advances; dead engine enters cooldown;
  all-dead degrades to text with `status=error` instead of a crash; timeout ≠ key cooldown;
  429 still rotates; payload has only `text` and timeout ≥ 20s.
- Gates: `npm run test:bridge` ✅ · `node --check public/static/app.js` ✅ · `npm run build` ✅
  (274 kB) · `tests.test_tts_engine_chain` 8/8 ✅.
- Known red, **pre-existing and untouched**: `test_voice_busy_recovery.test_gate_timeout_is_sane`
  asserts `_SPEAK_GATE_TIMEOUT ≤ 60` while HEAD ships 120. Either the test or the constant is
  stale; not this change's call.

## 5. Root cause #2, found next day: IPv6 stall (this is the real one)

2026-10-17, on the same machine, three socket tests against
`generativelanguage.googleapis.com:443`:

| Resolution order | Connect time |
|---|---|
| IPv4 only | **0.08s** |
| IPv6 only | **timeout** — this network has no IPv6 route |
| **Default (what Python does)** | **161.10s** |
| curl (tries IPv4 early) | 0.26s |

Google returns eight AAAA records before the A records. Python's
`socket.getaddrinfo` walks them in order and waits for each to fail, so **every
Gemini call from this codebase paid ~161s of connection stall before the first
byte.** Consequences, all of which were previously misread as "Gemini is broken":

- `timeout=8` could never pass → exception → `_mark_key_unhealthy()` → key parked
  300s → silence. The engine was fine; the transport was stalling.
- The "170s Gemini TTS" measurement in §1 was **not Google being slow** — it was
  this host's own resolution order.
- edge-tts looked like the only working engine because Microsoft's endpoint does
  not exhibit the same IPv6-first stall (measured 2.0s).
- `websocket-client` could not even reach the Live API (25s connect timeout). With
  IPv4 pinned, the same probe connects and streams in 5-9s.

Fix in code: `_pin_ipv4()` at import time in `voice_engine.py`, opt-out via
`JARVIS_IPV4_ONLY=0`. Measured after the pin: cold Gemini HTTPS call **0.59s**.
Same class of bug will exist in any other Python entry point that talks to Google
(`edge_tts_http.py`, `podcast_engine.py`) — not yet applied there.

## 6. The user's actual want is Google's own engine, and his free key already has it

Verified empirically with `scratch/live_ws_probe.py` (a real
`BidiGenerateContent` WebSocket session, text in → **native audio out**, no separate
TTS call) on `GOOGLE_API_KEY`, 2026-10-17:

| Model | Result |
|---|---|
| `gemini-3.8-live` | 6.5s → **213,600 B = 6.7s of 24 kHz PCM16** — *"I shall add that to the list of things I am entirely indifferent about."* |
| `gemini-3.1-flash-live-preview` | 8.5s → **10.2s of 24 kHz PCM16** — *"Right away, sir, as if your bidding were my sole purpose."* |
| `gemini-2.5-flash-native-audio-latest` | 9.5s → 3.4s audio (leaks reasoning-style text; prefer the two above) |

Both keys (`GOOGLE_API_KEY`, `GOOGLE_API_KEY_2`) list 63 models, 18 of which declare
`bidiGenerateContent`. Per [pricing](https://ai.google.dev/gemini-api/docs/pricing)
and the [Live API docs](https://ai.google.dev/gemini-api/docs/live-api), every Live
row is **"Free of charge"** on the free tier — with the caveat that free-tier traffic
is **used to improve Google's products**.

Why this is the requirement, not a compromise:
- **99 languages including Hindi and Japanese**, and the docs state native-audio models
  *"can switch between languages naturally during conversation"* — that is the Hinglish
  code-switching requirement, which Whisper-class STTs do badly
  ([Interspeech 2025 WER study](https://www.isca-archive.org/interspeech_2025/biswas25_interspeech.pdf)).
- **Server-side VAD and turn detection** (`realtimeInputConfig.automaticActivityDetection`)
  and an **`interrupted`** event on barge-in — i.e. no push-to-talk, talk-over-it-stops,
  which is precisely what he asked for.
- 16 kHz PCM in / 24 kHz PCM out, 20-40 ms chunks, ~10-15 min per session with `GoAway`
  + `sessionResumption`.

### Does an existing project already do this? Research verdict

- **No** repo exists that is "free + local + en/hi/hinglish/ja + Gemini-Live-like duplex".
- Frameworks that already wire Gemini Live and hand you interruption policy:
  [pipecat](https://github.com/pipecat-ai/pipecat) (BSD-2, `GeminiLiveLLMService`,
  active 2026-10-16) and [LiveKit Agents](https://github.com/livekit/agents)
  (Apache-2.0, 1.8.8 2026-10-15). Local-friendly STT/TTS plumbing:
  [RealtimeSTT](https://github.com/KoljaB/RealtimeSTT) (MIT), sherpa-onnx, Piper
  (archived but has `hi_IN` ×3, `ja_JP`, `en_GB` male voices, RTF 0.35 on a Pi 4).
- **Local speech-to-speech at Gemini quality on this machine does not exist.** Moshi
  needs ~24 GB GPU, Qwen2.5-Omni 18.4-93.6 GB GPU. On CPU-only 15 GB with
  `torch+cpu`, the offline ceiling is Piper/sherpa-class (real-time, but 2021-VITS
  quality) or Kokoro-82M (Apache-2.0, has British + Hindi + Japanese voices; **no
  published x86 RTF — unknown**).
- Known counter-evidence to watch: [adk-python #5542](https://github.com/google/adk-python/issues/5542)
  — English speech transcribed into Devanagari; `language_codes` is not honoured, so
  the only lever for language drift is the system instruction. Free tier also caps
  concurrent WebSocket connections (~3-5 per
  [Google's LiveKit sample](https://github.com/google-gemini/gemini-live-translate-livekit))
  — irrelevant for one assistant, fatal for fan-out.

## 7. Answer to "will you build a speech-to-speech engine from scratch?"

Not the model — that part cannot be rebuilt here (18-93 GB GPU) and would not reach
Gemini quality even if it could. What is worth building, and is a few hundred lines
rather than a research project, is the **duplex client**: one persistent WSS to
`gemini-3.8-live` opened from `voice_engine.py`, `openwakeword` + Silero kept as the
gate that opens/holds the socket, 20-40 ms mic frames streamed up, playback queue
flushed the moment `interrupted` arrives, persona carried in the system instruction.
That deletes STT→LLM→file-TTS from the conversation path instead of optimising it,
and it is the only version of "same as Android Gemini" that exists for him today.

## 9. Gemini Live duplex — built and verified 2026-10-17

New module: **`background/live_session.py`** (self-contained, nothing in
`voice_engine.py` imports it yet). `tests/test_live_session.py` = 14 tests, all offline.

### Wire format found by bisecting, not from the docs

The docs and the `google-genai` SDK types list `realtimeInput.mediaChunks` first.
**On this endpoint it is silently ignored** - the server accepts the frame and returns
nothing but `sessionResumptionUpdate`. What actually works is `realtimeInput.audio`:

| Upload shape | Result (measured) |
|---|---|
| `realtimeInput.mediaChunks[{mimeType,data}]` | **0 bytes back**, silence |
| **`realtimeInput.audio{mimeType:"audio/pcm;rate=16000",data}`** | **8.1s native 24 kHz audio** + `inputTranscription`, `outputTranscription`, `voiceActivity` frames |
| same + `realtimeInput.activityEnd` | 6.9s audio |

Setup frame: `model` + `generationConfig.responseModalities=["AUDIO"]` +
`generationConfig.speechConfig.voiceConfig.prebuiltVoiceConfig.voiceName` +
`systemInstruction` + the two transcription blocks = `setupComplete`.

**Rejected at setup (server closes the socket with an empty frame):** `realtimeInputConfig`
in any shape (`turnDetection`, `automaticActivityDetection`, or under `config`), and
`speechConfig` placed at setup level instead of inside `generationConfig`. Server-side VAD
is on by default, so turn timing is not configurable through this endpoint - the earlier
`2026-10-16` note in §6 that assumed `automaticActivityDetection` was wrong for this wire.

### Verified end to end, no microphone involved

```
[smoke] session open in 1.5s (gemini-3.8-live)
[smoke] streamed 34 chunks of speech
[smoke] {'audio_up_bytes': 156800, 'audio_down_bytes': 17280,
         'first_audio_s': 3.97, 'session_s': 4.9}
[smoke] HEARD BACK: 0.4s of 24 kHz native audio
```
`first_audio_s` here includes the 1.5s of artificial trailing silence the file replay
has to fake before the server's VAD will close the turn; the text-input path measured
**2.21s to first audio** with no such wait. A live microphone never waits.

### Two findings this surfaced about the existing pipeline

1. **`capture_loop` pins a device that cannot do 16 kHz.** The standalone runner opened
   the default input at **16000 Hz** on its first try, while `voice_engine` logs
   `device 12 rate 16000 failed: Invalid sample rate` and falls back to 48 kHz. The saved
   "proven device" is the reason the whole 48 kHz/VAD mismatch (§5) ever existed. Trying
   the default device first, or any device that accepts 16 kHz, is a better policy than
   the persisted one.
2. **The mic stream is the hard part, not the protocol.** `Pcm24kPlayer` is the borrowed
   queue-and-flush pattern from the analysed third-party repo: it plays 24 kHz PCM as it
   lands and `flush()` drops the queue on `interrupted`, which is what makes barge-in
   instant. `voice_engine.speak()` still writes a whole file and kills a process.

### Deliberately NOT done yet

- Not wired into `capture_loop`; `voice_engine.py` is untouched by this section. Merging
  is a ~10-line seam (`send_pcm(_resample_capture(chunk))` + `continue`) but it bypasses
  the wake gate, the chat/memory events, and the action router, so it goes in only after
  he has judged whether it feels like Gemini.
- No reconnect on `goAway` (~10-15 min per session).
- No echo cancellation. On speakers the assistant can hear itself and interrupt itself -
  a headset is the honest fix.
- Free tier means Google trains on this audio.

### How to try it right now (isolated, nothing else changes)

```powershell
.venv\Scripts\python.exe background\live_session.py --mic
```
Talk normally - no button, interrupt it freely. Ctrl+C exits. `--smoke` runs the same
path from a synthesised clip if the microphone is busy.


## 8. Next, in order

*(written before §9; items 2-6 are superseded by the Live duplex work — §9 is current)*

1. ~~Hear it~~ — done: `jarvis-ui`, `jarvis-windows-bridge`, `jarvis-voice` are online
   under PM2, `/health` reports `ok`, `status: "speaking"`, `mic_available: true`, and
   `/state` reports `tts_engine: "edge"`. Only he can judge the sound.
2. **Apply `_pin_ipv4()` to the other Google-speaking processes** (`edge_tts_http.py`,
   `podcast_engine.py`) — same stall, still unfixed there.
3. **Prototype the Live duplex session** behind `JARVIS_VOICE_MODE=live`, one turn
   end-to-end, keep the existing turn-based path as fallback so nothing regresses.
4. **Decide the free-tier trade** knowingly: free = Google trains on the audio, and
   the RPD ceiling is unpublished (check AI Studio quota page before committing).
5. **Barge-in polish** — discard the local playback buffer on `interrupted`; headset or
   real AEC, otherwise his own speaker output re-triggers the bot.
6. Still named and still undone: speaker verification (`voice-bio` — honestly BLOCKED,
   no `speechbrain`/`pyannote`), and the honesty debt: `presentation-builder`/
   `proactive-sentinel` have no capability card while the blueprint calls them LIVE, and
   `floating_ui.pyw:1013-1047` ships a panel that labels itself "Static mock — taps do
   nothing".
