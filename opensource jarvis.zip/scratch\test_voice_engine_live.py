import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import background.voice_engine as ve

print('=== JARVIS VOICE ENGINE LIVE VERIFICATION ===')
keys = ve._get_gemini_keys()
print(f'[CONFIG] Configured Gemini API keys: {len(keys)}')
assert len(keys) >= 2, f'Expected at least 2 Gemini keys, found {len(keys)}'

# 1. Test Gemini TTS synthesis in all 4 supported languages
for lang, test_phrase in [
    ('en', 'Sir, all perimeter sensors and neural modules are online.'),
    ('hi', 'नमस्ते सर, सभी प्रणालियाँ तैयार हैं।'),
    ('hinglish', 'Jarvis, system status report ready hai.'),
    ('ja', 'システムチェックが完了しました。')
]:
    wav_path = ve._gemini_synthesize(test_phrase, lang)
    assert wav_path and os.path.exists(wav_path), f'TTS failed for lang: {lang}'
    size = os.path.getsize(wav_path)
    print(f'[TTS] {lang}: generated {size} bytes ({wav_path})')
    
    # 2. Test Gemini STT transcribing the generated audio
    with open(wav_path, 'rb') as f:
        wav_bytes = f.read()
    transcribed_text, det_lang = ve._gemini_transcribe(wav_bytes, lang)
    print(f'[STT] {lang}: transcribed -> {transcribed_text!r} (detected lang: {det_lang})')
    assert transcribed_text, f'STT returned empty transcription for lang: {lang}'
    
    # Clean up temp wav
    try:
        os.remove(wav_path)
    except Exception:
        pass

print('[SUCCESS] All 4 languages verified for both Gemini TTS and STT with dual-key rotation!')
