/* Live Windows input check for hand-gesture control. NOT part of `npm test`.
 *
 * Run:  npm run test:gesture-live        (bridge must be running: npm run bridge)
 *
 * This drives the REAL desktop: it moves the real cursor, clicks, drags and
 * scrolls on a scratch PowerShell WinForms window that logs every event it
 * receives, and moves that window through the bridge's UI Automation path. The
 * target window is TopMost and positioned near the top-left, so injected input
 * cannot land on anything else.
 *
 * Nothing here is simulated: every assertion below compares a bridge answer
 * with the target process's own record of what Windows delivered. A bridge that
 * answers ok:true without moving the cursor fails this script.
 *
 * Exit codes: 0 all checks passed, 1 a check failed, 2 the environment is not
 * ready (bridge offline / not Windows) and nothing was touched.
 */
const fs = require('fs')
const os = require('os')
const path = require('path')
const { spawn, spawnSync } = require('child_process')

const BRIDGE = (process.env.JARVIS_BRIDGE_URL || 'http://127.0.0.1:7778').replace(/\/$/, '')
const results = []
const latencies = { move: [], mouse: [], ui: [] }

function record(name, ok, detail) {
  results.push({ name, ok: Boolean(ok) })
  console.log('  ' + (ok ? 'ok  ' : 'FAIL') + ' - ' + name + (detail ? '\n        ' + detail : ''))
}

function stats(values) {
  if (!values.length) return null
  const sorted = values.slice().sort((a, b) => a - b)
  const at = (fraction) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * fraction))]
  return {
    count: sorted.length,
    min: Math.round(sorted[0] * 10) / 10,
    median: Math.round(at(0.5) * 10) / 10,
    p95: Math.round(at(0.95) * 10) / 10,
    max: Math.round(sorted[sorted.length - 1] * 10) / 10
  }
}

async function post(url, body, timeout = 6000) {
  const started = performance.now()
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeout)
  })
  const payload = await response.json().catch(() => null)
  return { status: response.status, payload, ms: performance.now() - started }
}

const mouse = (body) => post(`${BRIDGE}/api/mouse`, body)
const ui = (body) => post(`${BRIDGE}/api/ui`, body)

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// An independent read of the real cursor, straight from PowerShell. The bridge
// is not asked, so a bridge that lies cannot pass this.
function readCursor() {
  const script = [
    'Add-Type -AssemblyName System.Windows.Forms',
    '$c = [System.Windows.Forms.Cursor]::Position',
    '[Console]::Out.WriteLine($c.X.ToString() + " " + $c.Y.ToString())'
  ].join('\n')
  const out = spawnSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script], { encoding: 'utf8', timeout: 20000 })
  const parts = String(out.stdout || '').trim().split(/\s+/).map(Number)
  if (parts.length !== 2 || !Number.isFinite(parts[0]) || !Number.isFinite(parts[1])) return null
  return { x: parts[0], y: parts[1] }
}

// ── the scratch target window ──────────────────────────────────────────────
const TARGET_SCRIPT = [
  '$ErrorActionPreference = "Stop"',
  'Add-Type -AssemblyName System.Windows.Forms',
  'Add-Type -AssemblyName System.Drawing',
  "Add-Type -MemberDefinition '[DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h, int c); [DllImport(\"user32.dll\")] public static extern bool IsWindowVisible(IntPtr h);' -Name Win -Namespace Jarvis",
  'function Say([string]$line) { [Console]::Out.WriteLine($line); [Console]::Out.Flush() }',
  '$form = New-Object System.Windows.Forms.Form',
  '$form.Text = "JARVIS gesture live target"',
  '$form.StartPosition = "Manual"',
  '$form.Location = New-Object System.Drawing.Point(60, 60)',
  '$form.Size = New-Object System.Drawing.Size(640, 420)',
  '$form.TopMost = $true',
  '$form.add_MouseEnter({ Say ("enter " + $_.X + " " + $_.Y) })',
  '$form.add_MouseDown({ Say ("down " + $_.X + " " + $_.Y + " " + $_.Button) })',
  '$form.add_MouseUp({ Say ("up " + $_.X + " " + $_.Y + " " + $_.Button) })',
  '$form.add_MouseMove({ if ($_.Button -eq [System.Windows.Forms.MouseButtons]::None) { Say ("hover " + $_.X + " " + $_.Y) } else { Say ("drag " + $_.X + " " + $_.Y) } })',
  '$form.add_MouseWheel({ Say ("wheel " + $_.Delta + " " + $_.X + " " + $_.Y) })',
  '$form.add_Move({ Say ("bounds " + $form.Left + " " + $form.Top + " " + $form.Width + " " + $form.Height) })',
  '$form.add_Resize({ Say ("bounds " + $form.Left + " " + $form.Top + " " + $form.Width + " " + $form.Height) })',
  '$form.Show()',
  // `windowsHide: true` sets STARTF_USESHOWWINDOW(SW_HIDE), and Windows applies
  // that to the FIRST ShowWindow call, so WinForms' own Show() leaves the form
  // hidden. A second, explicit ShowWindow(SW_SHOW) is what makes it real: a
  // hidden target receives no mouse input, which is exactly what the first live
  // run measured (no enter, no click, no wheel).
  '[void][Jarvis.Win]::ShowWindow($form.Handle, 5)',
  '$form.Activate()',
  'Say ("ready " + $form.Handle + " " + $form.Left + " " + $form.Top + " " + $form.Width + " " + $form.Height)',
  'Say ("visible " + [Jarvis.Win]::IsWindowVisible($form.Handle))',
  '[System.Windows.Forms.Application]::Run()',
  ''
].join('\n')

function startTarget() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jarvis-live-'))
  const scriptPath = path.join(dir, 'target.ps1')
  fs.writeFileSync(scriptPath, TARGET_SCRIPT, 'ascii')
  const child = spawn('powershell.exe', [
    '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath
  // windowsHide only suppresses the console window (CREATE_NO_WINDOW); it must
  // NOT be `-WindowStyle Hidden`, which SW_HIDEs the form's first window and
  // leaves a target that cannot receive real input.
  ], { windowsHide: true })
  const lines = []
  const waiters = []
  let buffer = ''
  const onLine = (line) => {
    lines.push(line)
    for (let i = waiters.length - 1; i >= 0; i -= 1) {
      if (waiters[i].match(line)) {
        waiters[i].resolve(line)
        waiters.splice(i, 1)
      }
    }
  }
  child.stdout.setEncoding('utf8')
  child.stdout.on('data', (chunk) => {
    buffer += chunk
    let index = buffer.indexOf('\n')
    while (index >= 0) {
      onLine(buffer.slice(0, index).trim())
      buffer = buffer.slice(index + 1)
      index = buffer.indexOf('\n')
    }
  })
  child.stderr.setEncoding('utf8')
  child.stderr.on('data', (chunk) => console.error('[target] ' + String(chunk).trim()))
  const stop = () => { try { child.kill() } catch { /* already gone */ } }
  return {
    child,
    stop,
    dir,
    lines,
    seen: (pattern) => lines.filter((line) => pattern.test(line)),
    // Wait for a line matching `pattern`, including lines that already arrived.
    wait: (pattern, timeout = 15000) => {
      const existing = lines.find((line) => pattern.test(line))
      if (existing) return Promise.resolve(existing)
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error('timed out waiting for ' + pattern)), timeout)
        waiters.push({ match: (line) => pattern.test(line), resolve: (line) => { clearTimeout(timer); resolve(line) } })
      })
    }
  }
}

function parseBounds(line) {
  const parts = String(line).split(/\s+/).slice(1).map(Number)
  return { x: parts[0], y: parts[1], width: parts[2], height: parts[3] }
}

// "ready <handle> <x> <y> <width> <height>"
function parseReady(line) {
  const parts = String(line).split(/\s+/).slice(1).map(Number)
  return { handle: parts[0], x: parts[1], y: parts[2], width: parts[3], height: parts[4] }
}

function near(a, b, tolerance) {
  return Math.abs(a - b) <= tolerance
}

async function main() {
  if (process.platform !== 'win32') {
    console.log('SKIP: live Windows input checks need Windows.')
    return 2
  }
  console.log('Live Windows input check against ' + BRIDGE)
  console.log('The real cursor will move and click on a scratch TopMost window.\n')

  const status = await fetch(`${BRIDGE}/api/status`, { signal: AbortSignal.timeout(4000) })
    .then((response) => response.json())
    .catch(() => null)
  if (!status || !status.ok) {
    console.log('SKIP: the bridge is not answering on ' + BRIDGE + '. Start it with: npm run bridge')
    return 2
  }
  const desktop = status.desktop
  record('the bridge reports the real virtual desktop', Boolean(desktop && desktop.width > 0 && desktop.height > 0),
    desktop ? `${desktop.left},${desktop.top} ${desktop.width}x${desktop.height}` : 'no desktop in /api/status')
  record('the PowerShell input worker answered a live ping',
    Boolean(status.mouse && status.mouse.ready), status.mouse ? JSON.stringify(status.mouse) : 'no mouse state in /api/status')
  if (!desktop || !status.mouse || !status.mouse.ready) return 1

  const home = readCursor()
  record('an independent PowerShell read of the real cursor works', Boolean(home),
    home ? `cursor at ${home.x},${home.y}` : 'could not read [System.Windows.Forms.Cursor]::Position')

  const target = startTarget()
  let handle = 0
  let form = null
  let failures = 0
  try {
    const ready = await target.wait(/^ready /)
    const opened = parseReady(ready)
    handle = opened.handle
    form = opened
    record('the scratch target window opened', handle > 0 && form.width > 0,
      `handle ${handle} at ${form.x},${form.y} ${form.width}x${form.height}`)
    const visibleLine = await target.wait(/^visible /, 8000).catch(() => '')
    record('the scratch target window is really visible on screen', /visible True/.test(visibleLine),
      visibleLine || 'the target never reported IsWindowVisible')

    // Focus first: wheel messages go to the focused window, and a focused
    // target also proves UI Automation can reach it before input is injected.
    const focused = await ui({ op: 'window', action: 'focus', handle })
    latencies.ui.push(focused.ms)
    record('UI Automation can focus the target window',
      Boolean(focused.payload && focused.payload.ok), JSON.stringify(focused.payload))

    // Park the cursor far away first so entering the target is a real entry.
    await mouse({ action: 'move', x: desktop.left + desktop.width - 4, y: desktop.top + Math.round(desktop.height / 2) })
    await sleep(120)

    const inside = { x: form.x + Math.round(form.width / 2), y: form.y + Math.round(form.height / 2) }

    // ── 1. move ───────────────────────────────────────────────────────────
    // The bridge's own answer is the worker reading [Cursor]::Position back
    // after the set. One independent PowerShell read at the end checks that the
    // worker is not lying; doing it after every move would spend ~800 ms per
    // call exposed to any other input source on the machine.
    const moves = []
    for (let i = 0; i < 8; i += 1) {
      const point = { x: inside.x - 120 + i * 30, y: inside.y - 60 + i * 15 }
      const answer = await mouse({ action: 'move', x: point.x, y: point.y })
      latencies.move.push(answer.ms)
      const landed = answer.payload && answer.payload.ok ? { x: answer.payload.x, y: answer.payload.y } : null
      const ok = Boolean(landed && near(landed.x, point.x, 1) && near(landed.y, point.y, 1))
      moves.push({ ok, point, landed })
    }
    const badMove = moves.find((entry) => !entry.ok)
    record('every bridge move reports the real cursor at the requested point (8 moves)',
      !badMove,
      badMove ? `requested ${badMove.point.x},${badMove.point.y} -> bridge ${JSON.stringify(badMove.landed)}` : 'all eight matched the worker readback')
    const lastPoint = moves[moves.length - 1].point
    const independent = readCursor()
    record('an independent PowerShell read confirms the final cursor position',
      Boolean(independent && near(independent.x, lastPoint.x, 2) && near(independent.y, lastPoint.y, 2)),
      `requested ${lastPoint.x},${lastPoint.y} -> independent read ${JSON.stringify(independent)}`)

    const hovered = target.seen(/^hover /).length + target.seen(/^enter /).length
    record('the target window saw the real cursor move over it', hovered > 0,
      hovered ? `${hovered} move events: ` + target.seen(/^hover /).slice(-2).join(' | ') : 'the target logged no mouse move at all')
    if (!hovered) {
      throw new Error('the scratch target never received the cursor, so clicking now would hit whatever is really under it')
    }

    // ── 2. clicks ─────────────────────────────────────────────────────────
    await mouse({ action: 'move', x: inside.x, y: inside.y })
    await sleep(120)
    const downBefore = target.seen(/^down /).length
    const upBefore = target.seen(/^up /).length
    let answer = await mouse({ action: 'lclick' })
    latencies.mouse.push(answer.ms)
    await sleep(200)
    const leftDown = target.seen(/^down /).slice(downBefore)
    const leftUp = target.seen(/^up /).slice(upBefore)
    record('a bridge left click is one real press and release on the target',
      answer.payload && answer.payload.ok && leftDown.length === 1 && leftUp.length === 1 && /Left/.test(leftDown[0]) && /Left/.test(leftUp[0]),
      `${leftDown.length} down / ${leftUp.length} up: ${leftDown.concat(leftUp).join(' | ')}`)

    const rightBefore = target.seen(/^down /).length
    answer = await mouse({ action: 'rclick' })
    latencies.mouse.push(answer.ms)
    await sleep(200)
    const rightDown = target.seen(/^down /).slice(rightBefore)
    record('a bridge right click arrives as a right button press',
      answer.payload && answer.payload.ok && rightDown.length === 1 && /Right/.test(rightDown[0]),
      rightDown.join(' | ') || 'no press logged')

    // ── 3. drag with a held button ────────────────────────────────────────
    const dragStart = { x: inside.x - 60, y: inside.y + 40 }
    await mouse({ action: 'move', x: dragStart.x, y: dragStart.y })
    const dragBefore = target.seen(/^drag /).length
    await mouse({ action: 'ldown' })
    for (let i = 1; i <= 6; i += 1) {
      await mouse({ action: 'move', x: dragStart.x + i * 12, y: dragStart.y + i * 6 })
      await sleep(30)
    }
    await mouse({ action: 'lup' })
    await sleep(200)
    const dragLines = target.seen(/^drag /).slice(dragBefore).map((line) => line.split(/\s+/).slice(1).map(Number))
    const dragSpan = dragLines.length
      ? Math.max(...dragLines.map((p) => p[0])) - Math.min(...dragLines.map((p) => p[0]))
      : 0
    record('a bridge drag moves the real pointer with the button held',
      dragLines.length >= 3 && dragSpan >= 40,
      `${dragLines.length} move-with-button events, x span ${dragSpan}px`)

    // ── 4. wheel ──────────────────────────────────────────────────────────
    const wheelBefore = target.seen(/^wheel /).length
    answer = await mouse({ action: 'scroll', delta: -240 })
    latencies.mouse.push(answer.ms)
    await sleep(250)
    const wheels = target.seen(/^wheel /).slice(wheelBefore).map((line) => Number(line.split(/\s+/)[1]))
    record('a bridge scroll arrives as a real mouse wheel event',
      answer.payload && answer.payload.ok && wheels.length >= 1 && wheels.every((delta) => delta < 0),
      `wheel deltas: ${wheels.join(', ') || 'none logged'}`)

    // ── 5. window control through UI Automation ───────────────────────────
    // Two pixel spaces meet here, and they are NOT the same on a scaled display:
    //   * the pointer/desktop space of this bridge is virtualised (1536x864)
    //   * UIA window rectangles are physical (1920x1080)
    // A window move therefore travels as 0..1 fractions of the desktop and is
    // resolved by the UIA process. The checks below prove that conversion by
    // reading the result from the target process itself.
    const list = await ui({ op: 'windows' })
    latencies.ui.push(list.ms)
    const listed = list.payload && list.payload.ok ? list.payload.windows : []
    const mine = listed.find((row) => row.handle === handle)
    record('UI Automation lists the real target window by handle and title',
      Boolean(mine && /JARVIS gesture live target/.test(mine.title)),
      mine ? JSON.stringify(mine) : `handle ${handle} not in ${listed.length}: ` + listed.map((row) => row.handle + ' ' + row.title).join(' | '))

    const screen = (list.payload && list.payload.screen) || []
    const physical = screen.length === 4 && screen[2] > 0 && screen[3] > 0
    const scale = physical && desktop.width > 0 ? screen[2] / desktop.width : 1
    record('the UIA pixel space is reported so callers never have to guess it', physical,
      `pointer/desktop ${desktop.width}x${desktop.height} (virtualised) vs UIA ${screen[2] || '?'}x${screen[3] || '?'} (physical), scale ${scale.toFixed(3)}`)
    const toVirtual = (box) => ({
      x: desktop.left + Math.round((box.x - (physical ? screen[0] : 0)) / scale),
      y: desktop.top + Math.round((box.y - (physical ? screen[1] : 0)) / scale)
    })
    const toPhysical = (box) => ({
      x: (physical ? screen[0] : 0) + Math.round((box.x - desktop.left) * scale),
      y: (physical ? screen[1] : 0) + Math.round((box.y - desktop.top) * scale),
      width: Math.round(box.width * scale),
      height: Math.round(box.height * scale)
    })
    const samePhysical = (a, b) => Boolean(a && b) && near(a.x, b.x, 4) && near(a.y, b.y, 4) &&
      near(a.width, b.width, 4) && near(a.height, b.height, 4)
    const boxToObject = (box) => (Array.isArray(box) ? { x: box[0], y: box[1], width: box[2], height: box[3] } : box)

    const fractions = { x: 0.08, y: 0.1, width: 0.42, height: 0.45 }
    const expected = physical ? {
      x: screen[0] + Math.round(fractions.x * screen[2]),
      y: screen[1] + Math.round(fractions.y * screen[3]),
      width: Math.round(fractions.width * screen[2]),
      height: Math.round(fractions.height * screen[3])
    } : null

    target.lines.length = 0
    const moved = await ui({ op: 'window', action: 'move', handle, rect: fractions })
    latencies.ui.push(moved.ms)
    let reported = null
    try {
      reported = parseBounds(await target.wait(/^bounds /, 4000))
    } catch (error) {
      reported = null
    }
    const asPhysical = reported ? toPhysical(reported) : null
    const bridgeBox = moved.payload && moved.payload.window && moved.payload.window.box
    record('a UI Automation window move lands where the fraction asked, verified by the target itself',
      Boolean(moved.payload && moved.payload.ok) && samePhysical(asPhysical, expected) && samePhysical(boxToObject(bridgeBox), expected),
      `fractions ${JSON.stringify(fractions)} -> expected ${JSON.stringify(expected)} physical | target reported ${JSON.stringify(reported)} (virtual) = ${JSON.stringify(asPhysical)} physical | bridge read back ${JSON.stringify(bridgeBox)}`)

    // The dashboard's own "move window to the centre" action sends exactly this
    // rect: check the shipped action, not just arbitrary fractions.
    const centre = { x: 0.19, y: 0.19, width: 0.62, height: 0.62 }
    const centred = await ui({ op: 'window', action: 'move', handle, rect: centre })
    latencies.ui.push(centred.ms)
    const centreBox = centred.payload && centred.payload.ok && centred.payload.window && centred.payload.window.box
    const centreObject = centreBox ? boxToObject(centreBox) : null
    const expectedCentre = physical ? {
      x: screen[0] + Math.round(centre.x * screen[2]),
      y: screen[1] + Math.round(centre.y * screen[3]),
      width: Math.round(centre.width * screen[2]),
      height: Math.round(centre.height * screen[3])
    } : null
    const screenCentre = physical ? { x: screen[0] + screen[2] / 2, y: screen[1] + screen[3] / 2 } : null
    record('the shipped "move window to the centre" rect really centres the window',
      Boolean(centreObject) && samePhysical(centreObject, expectedCentre) && Boolean(screenCentre) &&
        near(centreObject.x + centreObject.width / 2, screenCentre.x, 4) &&
        near(centreObject.y + centreObject.height / 2, screenCentre.y, 4),
      `rect ${JSON.stringify(centre)} -> read back ${JSON.stringify(centreBox)} (window centre ${centreObject ? Math.round(centreObject.x + centreObject.width / 2) + ',' + Math.round(centreObject.y + centreObject.height / 2) : '?'}, screen centre ${screenCentre ? Math.round(screenCentre.x) + ',' + Math.round(screenCentre.y) : '?'})`)

    const minimized = await ui({ op: 'window', action: 'minimize', handle })
    latencies.ui.push(minimized.ms)
    const wasMinimized = Boolean(minimized.payload && minimized.payload.ok && minimized.payload.window && minimized.payload.window.minimized)
    const restored = await ui({ op: 'window', action: 'restore', handle })
    latencies.ui.push(restored.ms)
    record('minimize and restore report the state they actually read back',
      wasMinimized && Boolean(restored.payload && restored.payload.ok && restored.payload.window && restored.payload.window.minimized === false),
      `minimize -> ${JSON.stringify(minimized.payload && minimized.payload.window)} restore -> ${JSON.stringify(restored.payload && restored.payload.window)}`)

    // ── 6. drag the real window by its title bar ──────────────────────────
    const before = await ui({ op: 'windows' })
    latencies.ui.push(before.ms)
    const beforeRow = before.payload && before.payload.ok ? before.payload.windows.find((row) => row.handle === handle) : null
    const current = (beforeRow && beforeRow.box) || (expected ? [expected.x, expected.y, expected.width, expected.height] : [140, 140, 700, 460])
    // The caption is a physical UIA rectangle; the cursor only understands the
    // virtualised pointer space, so convert before injecting the drag.
    const caption = toVirtual({ x: current[0] + 140, y: current[1] + 18 })
    const dragBy = { x: 120, y: 60 }
    await mouse({ action: 'move', x: caption.x, y: caption.y })
    await sleep(150)
    await mouse({ action: 'ldown' })
    for (let i = 1; i <= 6; i += 1) {
      await mouse({ action: 'move', x: caption.x + Math.round(dragBy.x * i / 6), y: caption.y + Math.round(dragBy.y * i / 6) })
      await sleep(40)
    }
    await mouse({ action: 'lup' })
    await sleep(400)
    const after = await ui({ op: 'windows' })
    latencies.ui.push(after.ms)
    const afterRow = after.payload && after.payload.ok ? after.payload.windows.find((row) => row.handle === handle) : null
    const delta = afterRow && afterRow.box ? { x: afterRow.box[0] - current[0], y: afterRow.box[1] - current[1] } : null
    record('dragging the title bar moves the real window by the dragged distance',
      Boolean(delta && near(delta.x, dragBy.x * scale, 30) && near(delta.y, dragBy.y * scale, 20)),
      `window moved ${JSON.stringify(delta)} physical for a ${dragBy.x},${dragBy.y} virtual cursor drag (expected about ${Math.round(dragBy.x * scale)},${Math.round(dragBy.y * scale)}) — Windows itself performed the move`)

    // ── 7. refusals ───────────────────────────────────────────────────────
    const refusals = [
      ['an unsupported window action is refused', await ui({ op: 'window', action: 'close', handle })],
      ['a zero window handle is refused', await ui({ op: 'window', action: 'minimize', handle: 0 })],
      ['a useless window rectangle is refused', await ui({ op: 'window', action: 'move', handle, x: 0, y: 0, width: 20, height: 20 })],
      ['an out-of-range window fraction is refused', await ui({ op: 'window', action: 'move', handle, rect: { x: 1.4, y: 0, width: 0.5, height: 0.5 } })],
      ['a window fraction smaller than a window is refused', await ui({ op: 'window', action: 'move', handle, rect: { x: 0.1, y: 0.1, width: 0.01, height: 0.01 } })],
      ['an unknown window operation is refused', await ui({ op: 'teleport', handle })]
    ]
    for (const [label, response] of refusals) {
      record(label, response.status === 400 && response.payload && response.payload.ok === false,
        `HTTP ${response.status} ${JSON.stringify(response.payload)}`)
    }
    const badMouse = await mouse({ action: 'teleport', x: 0, y: 0 })
    record('an unknown mouse action is refused, not silently accepted',
      badMouse.payload && badMouse.payload.ok === false, `HTTP ${badMouse.status} ${JSON.stringify(badMouse.payload)}`)

    failures = results.filter((entry) => !entry.ok).length
  } catch (error) {
    console.error('\nThe live check stopped early: ' + (error && error.message))
    failures = results.filter((entry) => !entry.ok).length + 1
  } finally {
    target.stop()
    fs.rmSync(target.dir, { recursive: true, force: true })
    if (home) {
      await mouse({ action: 'move', x: home.x, y: home.y }).catch(() => null)
      console.log(`\nCursor restored to ${home.x},${home.y}.`)
    }
  }

  const moveStats = stats(latencies.move)
  const mouseStats = stats(latencies.mouse)
  const uiStats = stats(latencies.ui)
  console.log('\nMeasured latency, real desktop (HTTP + worker + real Windows call, no browser):')
  console.log('  pointer move  ' + (moveStats ? `${moveStats.count} samples, min ${moveStats.min} ms, median ${moveStats.median} ms, p95 ${moveStats.p95} ms, max ${moveStats.max} ms` : 'no samples'))
  console.log('  mouse action  ' + (mouseStats ? `${mouseStats.count} samples, min ${mouseStats.min} ms, median ${mouseStats.median} ms, p95 ${mouseStats.p95} ms, max ${mouseStats.max} ms` : 'no samples'))
  console.log('  UIA window op ' + (uiStats ? `${uiStats.count} samples, min ${uiStats.min} ms, median ${uiStats.median} ms, p95 ${uiStats.p95} ms, max ${uiStats.max} ms` : 'no samples'))
  console.log('The UIA number includes spawning the Python UI Automation process, which is why it')
  console.log('is far slower than pointer control; it is not on the pointer loop.')
  console.log('The dashboard adds its own mapping plus pointer smoothing on top of the move number;')
  console.log('the in-app "Move: frame to real cursor" row measures that whole path.')
  console.log('')
  if (failures) {
    console.error(`${results.length - failures}/${results.length} live checks passed, ${failures} failed.`)
    return 1
  }
  console.log(`${results.length} live checks passed: real cursor moves, clicks, drags, wheel and window control.`)
  return 0
}

main().then((code) => process.exit(code)).catch((error) => {
  console.error('Live check crashed:', error)
  process.exit(1)
})
