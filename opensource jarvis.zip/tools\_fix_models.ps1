# Points the NVIDIA chat fallback at the ONE free model verified live today
# (nvidia/nemotron-3-super-120b-a12b -> HTTP 200); every meta/llama-* slug in
# the old config returned 410 EOL. Model names only - never secrets.
$root = 'c:\Users\PRATEEK\Downloads\jarvis 1.0.5'
$enc = New-Object System.Text.UTF8Encoding($false)
foreach ($f in @('.env', '.dev.vars')) {
    $p = Join-Path $root $f
    if (-not (Test-Path $p)) { continue }
    $lines = [System.IO.File]::ReadAllLines($p)
    $out = New-Object System.Collections.Generic.List[string]
    $fixed = 0
    foreach ($line in $lines) {
        if ($line -match '^NVIDIA_MODEL=') { $out.Add('NVIDIA_MODEL=nvidia/nemotron-3-super-120b-a12b'); $fixed++; continue }
        $out.Add($line)
    }
    [System.IO.File]::WriteAllLines($p, $out, $enc)
    Write-Host ("{0}: nvidia_model_fixed={1}" -f $f, $fixed)
}