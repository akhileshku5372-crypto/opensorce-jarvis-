# JARVIS — steering prompt (mini)

> Paste this at the top of a session. Every path below is real in this repo —
> verified 2026-10-18, not assumed.

You are working on **JARVIS**, a voice-first Windows assistant. Continue it; never
rebuild it. Read `AGENTS.md` first — it overrides this file.

## The one rule that matters
A tool returning a string is **not** a completed task. Say "ho gaya" only after the
effect is observed (window enumerated, file exists, bytes sent). Otherwise say
*unverified*. Most lost days on this repo came from trusting `[done]`.

## Where things live

| Concern | File |
|---|---|
| The brain: STT→route→act→TTS, ~9.5k lines | [background/voice_engine.py](background/voice_engine.py) |
| Deterministic routing cascade | same file, `run_command()` / `_phase1_handle()` |
| Multi-step action detection | `_multi_step_action()` / `_agent_owned()` |
| Plan → Act → Observe loop | [background/cortex.py](background/cortex.py) |
| Planner (never invent tools) | `_cortex_planner` in voice_engine |
| Agent-S: screenshot→act, real mouse/keyboard | [background/screen_agent.py](background/screen_agent.py) |
| Where an answer renders | [background/intent_router.py](background/intent_router.py) |
| Long-term memory (ChromaDB) | [background/conversation_memory.py](background/conversation_memory.py) |
| RAG over documents | [background/doc_index.py](background/doc_index.py) |
| Deep research | [background/firecrawl_client.py](background/firecrawl_client.py) + `firecrawl_keys.py` |
| **WhatsApp, desktop app, NO API** | [background/whatsapp_sender.py](background/whatsapp_sender.py) |
| Permission gates | [background/permissions.py](background/permissions.py) + `extensions/permissions.json` |
| HUD / floating window | [background/floating_ui.pyw](background/floating_ui.pyw) |
| Capability truth (LIVE/READY/BLOCKED) | [background/capability_registry.py](background/capability_registry.py) |
| OS actions, loopback only | [local-bridge/server.cjs](local-bridge/server.cjs) |
| Dashboard | [src/index.tsx](src/index.tsx) + [public/static/app.js](public/static/app.js) |
| Tools exposed to the model | [extensions/plugins/jarvis-modules/](extensions/plugins/jarvis-modules/) |

## Non-negotiables
- **One** microphone, one assistant, one memory, one tool registry. Never add a second.
- Loopback only on the bridge; allowlisted actions only; never route raw speech to a
  shell, path, or executable.
- `power_guard` refuses shutdown/restart/hibernate regardless of any grant.
- WhatsApp = desktop app. WhatsApp Web is rejected by the owner; do not reintroduce it.
- Never send to a person without an explicit named target.
- Secrets live in `.env` / `.dev.vars`; never log or expose them.

## Verify before you claim
```
node run_py.cjs -m unittest discover -s tests -p <suite>.py   # python, via .venv
npm run test:bridge && node --check public/static/app.js && npm run build
```
Run Python only through `node run_py.cjs --resolve`'s interpreter, or memory tests
fail as `memory_store_unavailable` — a harness artifact, not a bug.

**Line endings differ per file.** `voice_engine.py`, `test_core.py`, `cortex.py` are
CRLF (`cortex.py` is mixed). `screen_agent.py` is LF. Detect, never assume — a wrong
assumption silently corrupts the file.

**Edit discipline:** write → `py_compile` → tests → only then keep. Multi-line edits
via a self-reverting splice; a bare `Edit` on a CRLF string literal has broken the
engine twice.

**Prove the probe before believing a regression.** Inline-bash Devanagari arrives as
`?` (Windows codepage) — send non-Latin live input from a `.cjs` file using `\uXXXX`.
And `STATE["cortex"]` is stale unless `_sync_cortex_state()` ran; read `/cortex`, not
the state field.

## Known external walls (not code bugs — don't "fix" them)
- All 3 Firecrawl keys: HTTP 402. **Credits are per account, not per key**, so the
  3-key failover pool was never real redundancy.
- Google serves a captcha to `browser_navigate` (a background fetch that opens no
  window). Use the real Chrome window for browsing.
- Playwright is not installed; `browser_*` tools that need it will fail.
- Vision grounding uses `qwen/qwen3-vl-plus:free` — rate-limited, fails intermittently.
- UI-TARS-7B cannot run locally: CPU-only laptop, 15.3 GB RAM.

## Open work
1. `gui_open_app` — Start search with **verify-before-Enter** (never raw voice→exec).
2. Steps must prove their visible effect; `os_launch_app` now polls for a window —
   extend that pattern to the rest.
3. Planner arg alias still failing inside the agent path (`name` vs `app`) — inspect
   the real args before fixing again.
4. Burst guard (4 cmd/min) freezes a talking user; needs a voice-first limit.
5. Multi-recipient WhatsApp send — proven in tests, never on a real chat.

## Goal: WhatsApp media, no API (not built yet)

He wants: *"isko bhejo photo / audio / video bhej do"* → JARVIS sends it, desktop
app, zero WhatsApp API and no WhatsApp Web.

**Current truth:** [background/whatsapp_sender.py](background/whatsapp_sender.py)
sends **text only** — clipboard paste into the focused chat plus `wa.me` deep links.
There is no image, audio, video or attachment code in that file at all. Do not
describe media sending as working.

What exists to build on, so this is not from scratch:
- `_clipboard_set` / `_clipboard_get` — text today; an image can go on the clipboard
  the same way (CF_DIB / CF_HDROP), which is the cleanest route for photos.
- `_key(name)` — synthesised keypresses, so Ctrl+V after a paste.
- `_window_is_whatsapp()` — already proves the target window is up before acting.
- `resolve_contact()` + saved contacts — name → chat, no invented phone numbers.
- [background/screen_agent.py](background/screen_agent.py) `gui_locate_and_click` —
  for the attach (paperclip) button when a paste alone is not enough.

The shape of it: put the media on the clipboard (or resolve a real file path from an
allowlisted folder), focus the WhatsApp window, paste, then **verify the send actually
landed** before saying so — a chat window that still shows the composer filled is not
a delivered message.

Constraints that still apply: an explicit named recipient, the confirmation gate,
desktop app only, and never a path or filename taken straight from raw speech.
