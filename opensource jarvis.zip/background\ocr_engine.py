"""OCR Everywhere: real text extraction, with honest capability reporting.

Backs the "OCR Everywhere" catalog card. Two genuinely different paths, and
the card reports WHICH one is available instead of pretending both work:

  1. Digital PDF / image documents - PyMuPDF (already in requirements.txt).
     A real text layer is extracted, and for a scanned page PyMuPDF renders
     the page to an image and runs Tesseract on it.
  2. Live screen OCR - Tesseract only.

Tesseract is an external program and is NOT installed on this machine, so
path 2 (and the scanned-PDF branch) reports `available: False` with the
reason. That honesty is the requirement: the Modules page must never show a
working OCR badge when no OCR engine exists.

No shell, no user-supplied paths outside the repo/KamiSensei knowledge base,
and no network.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OCR_MODEL_DIR = Path(os.environ.get("JARVIS_OCR_MODEL_DIR")
                     or (ROOT / "models" / "ocr"))
_OCR_MODEL = "eng"

# Screenshot/OCR results are read-only local data; this is the maximum we ever
# return to a caller or write to a report.
MAX_CHARS = 12000
MAX_PAGES = 40


def _pymupdf():
    try:
        import pymupdf  # type: ignore
        return pymupdf
    except Exception:
        try:
            import fitz  # type: ignore
            return fitz
        except Exception:
            return None


def tesseract_path() -> str:
    """Real path to a Tesseract binary, or '' when it is not installed."""
    override = os.environ.get("JARVIS_TESSERACT_PATH")
    if override and Path(override).exists():
        return override
    found = shutil.which("tesseract")
    return found or ""


def _tessdata_ok(binary: str) -> bool:
    """Tesseract without traineddata fails at runtime, so check the model dir."""
    if not OCR_MODEL_DIR.is_dir():
        return False
    return any(OCR_MODEL_DIR.glob("*.traineddata"))


def capabilities() -> dict:
    """What can OCR actually do on this machine right now."""
    binary = tesseract_path()
    pdf = _pymupdf()
    ocr_ready = bool(binary) and _tessdata_ok(binary)
    return {
        "ok": True, "source": "local",
        "digital_pdf": {"available": pdf is not None,
                        "engine": "PyMuPDF" if pdf else "",
                        "reason": "" if pdf else
                        "PyMuPDF is not installed (pip install pymupdf)"},
        "screen_ocr": {"available": ocr_ready,
                       "engine": "Tesseract" if ocr_ready else "",
                       "binary": binary,
                       "reason": "" if ocr_ready else _tesseract_reason(binary)},
        "scanned_pdf": {"available": bool(pdf) and ocr_ready,
                        "reason": "" if (pdf and ocr_ready) else
                        ("rendering available but Tesseract is missing" if pdf
                         else "PyMuPDF is not installed")},
    }


def _tesseract_reason(binary: str) -> str:
    if not binary:
        return ("Tesseract is not installed. Install it and add it to PATH "
                "(winget install UB-Mannheim.TesseractOCR), then set "
                "JARVIS_TESSERACT_PATH if it is not on PATH.")
    return ("Tesseract is installed at %s but no traineddata model is present "
            "in %s - put %s.traineddata there."
            % (binary, OCR_MODEL_DIR, _OCR_MODEL))


# ── digital PDF text ────────────────────────────────────────────────────────
def extract_pdf(path: str, max_pages: int = MAX_PAGES) -> dict:
    """Real text-layer extraction. Scanned pages are reported, not invented."""
    pdf = _pymupdf()
    if pdf is None:
        return {"ok": False, "source": "local",
                "error": "PyMuPDF is not installed (pip install pymupdf)"}
    target = Path(str(path or "")).expanduser()
    try:
        if not target.is_file():
            return {"ok": False, "source": "local", "error": "file not found"}
        doc = pdf.open(str(target))
    except Exception as exc:
        return {"ok": False, "source": "local",
                "error": "could not open PDF: %s" % type(exc).__name__}
    try:
        limit = max(1, min(MAX_PAGES, int(max_pages or MAX_PAGES)))
        pages, scanned = [], []
        for index in range(min(doc.page_count, limit)):
            text = (doc.load_page(index).get_text("text") or "").strip()
            if text:
                pages.append({"page": index + 1, "text": text[:MAX_CHARS],
                              "chars": len(text)})
            else:
                scanned.append(index + 1)
        total = doc.page_count
    finally:
        try:
            doc.close()
        except Exception:
            pass
    body = "\n\n".join("[page %d]\n%s" % (p["page"], p["text"]) for p in pages)
    return {"ok": True, "source": "local", "kind": "pdf_text",
            "pages_total": total, "pages_with_text": len(pages),
            "pages_scanned": scanned,
            "ocr_needed_for": scanned[:MAX_PAGES],
            "chars": len(body), "text": body[:MAX_CHARS]}


def ocr_image(path: str, lang: str = None) -> dict:
    """Tesseract on one image. Reports unavailability instead of faking it."""
    binary = tesseract_path()
    if not binary or not _tessdata_ok(binary):
        return {"ok": False, "source": "local", "kind": "ocr_image",
                "error": _tesseract_reason(binary), "text": ""}
    target = Path(str(path or "")).expanduser()
    if not target.is_file():
        return {"ok": False, "source": "local", "kind": "ocr_image",
                "error": "image not found", "text": ""}
    out_base = Path(tempfile.gettempdir()) / "jarvis_ocr_out"
    try:
        done = subprocess.run(
            [binary, str(target), str(out_base), "-l", lang or _OCR_MODEL,
             "--tessdata-dir", str(OCR_MODEL_DIR)],
            capture_output=True, text=True, timeout=90, shell=False,
            creationflags=0x08000000 if os.name == "nt" else 0)
    except Exception as exc:
        return {"ok": False, "source": "local", "kind": "ocr_image",
                "error": "tesseract failed: %s" % type(exc).__name__, "text": ""}
    text_file = out_base.with_suffix(".txt")
    text = text_file.read_text(encoding="utf-8", errors="ignore") \
        if text_file.is_file() else ""
    try:
        text_file.unlink(missing_ok=True)
    except Exception:
        pass
    if done.returncode != 0 and not text:
        return {"ok": False, "source": "local", "kind": "ocr_image",
                "error": (done.stderr or "tesseract returned %d"
                          % done.returncode).strip()[:300], "text": ""}
    return {"ok": True, "source": "local", "kind": "ocr_image",
            "chars": len(text), "text": text[:MAX_CHARS]}


def ocr_pdf_scanned(path: str, max_pages: int = 5) -> dict:
    """Render scanned pages with PyMuPDF, then OCR them with Tesseract."""
    caps = capabilities()
    if not caps["scanned_pdf"]["available"]:
        return {"ok": False, "source": "local", "kind": "ocr_pdf",
                "error": caps["scanned_pdf"]["reason"], "text": ""}
    pdf = _pymupdf()
    target = Path(str(path or "")).expanduser()
    if not target.is_file():
        return {"ok": False, "source": "local", "kind": "ocr_pdf",
                "error": "file not found", "text": ""}
    first = extract_pdf(str(target), max_pages=max_pages)
    wanted = first.get("ocr_needed_for") or []
    if not wanted:
        return {"ok": True, "source": "local", "kind": "ocr_pdf",
                "text": first.get("text", ""), "pages_ocred": []}
    chunks, done_pages = [], []
    doc = pdf.open(str(target))
    try:
        for page_no in wanted[:max(1, min(MAX_PAGES, int(max_pages)))]:
            pix = doc.load_page(page_no - 1).get_pixmap(dpi=200)
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = Path(tmp.name)
            try:
                pix.save(str(tmp_path))
                out = ocr_image(str(tmp_path))
            finally:
                try:
                    tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass
            if out.get("ok") and out.get("text"):
                chunks.append("[page %d]\n%s" % (page_no, out["text"]))
                done_pages.append(page_no)
    finally:
        try:
            doc.close()
        except Exception:
            pass
    return {"ok": bool(chunks), "source": "local", "kind": "ocr_pdf",
            "pages_ocred": done_pages, "text": "\n\n".join(chunks)[:MAX_CHARS],
            "error": "" if chunks else "no text recovered from the scanned pages"}


# ── unified entry + tools ───────────────────────────────────────────────────
_SUFFIX_IMAGE = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
_SUFFIX_DOC = {".pdf"}


def read_document(path: str) -> dict:
    """Route a document to the real reader. Never guesses a result."""
    target = Path(str(path or "")).expanduser()
    if not target.is_file():
        return {"ok": False, "source": "local", "kind": "unknown",
                "error": "file not found: %s" % target.name[:80]}
    suffix = target.suffix.lower()
    if suffix in _SUFFIX_DOC:
        result = extract_pdf(str(target))
        # A PDF with no text layer needs real OCR; do not pretend the (empty)
        # text result is a successful read.
        if result.get("ok") and not result.get("chars") and result.get("pages_scanned"):
            scanned = ocr_pdf_scanned(str(target))
            if scanned.get("ok"):
                return scanned
            result["needs_ocr"] = True
            result["ocr_error"] = scanned.get("error", "")
        return result
    if suffix in _SUFFIX_IMAGE:
        return ocr_image(str(target))
    return {"ok": False, "source": "local", "kind": "unknown",
            "error": "no local reader for '.%s' files" % suffix.lstrip(".")}


def _tool_ocr_status(args: dict) -> dict:
    caps = capabilities()
    live = [k for k in ("digital_pdf", "scanned_pdf", "screen_ocr")
            if caps[k]["available"]]
    return {"ok": True,
            "output": ("Sir, OCR is available for: %s." % ", ".join(live)
                       if live else
                       "Sir, OCR can read digital PDFs only; scanned pages and "
                       "screen OCR need Tesseract, which is not installed."),
            "data": caps}


def _tool_read_document(args: dict) -> dict:
    out = read_document((args or {}).get("path", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error") or "document read failed"}
    head = (out.get("text") or "").strip()[:300]
    if out.get("needs_ocr"):
        return {"ok": False,
                "output": ("This PDF has no text layer and Tesseract is not "
                           "installed, so no text could be read.")}
    return {"ok": True,
            "output": "Sir, read %d characters from the document. It starts: %s"
                      % (out.get("chars", 0), head or "(empty)"),
            "data": out}


def _tool_ocr_screen(args: dict) -> dict:
    caps = capabilities()
    if not caps["screen_ocr"]["available"]:
        return {"ok": False, "output": caps["screen_ocr"]["reason"]}
    shot = (args or {}).get("image_path", "")
    if not shot:
        return {"ok": False,
                "output": "screen OCR needs an image path from a real capture"}
    return _tool_read_document({"path": shot})


def specs() -> list:
    """cortex ToolSpec list. Reading a local document is read-only."""
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("ocr_status",
                        "Which OCR paths are really available on this machine.",
                        _tool_ocr_status, parameters={},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("ocr", "vision")),
        cortex.ToolSpec("read_document",
                        "Extract real text from a local PDF or image.",
                        _tool_read_document, parameters={"path": "file path"},
                        requires_confirmation=False, timeout_s=60.0,
                        tags=("ocr", "documents")),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()


