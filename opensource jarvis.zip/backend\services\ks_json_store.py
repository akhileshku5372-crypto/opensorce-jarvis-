"""
KamiSensei JSON Store — backend/services/ks_json_store.py
=======================================================
Tiny file-backed JSON database for KamiSensei sources. Persists extracted
YouTube transcripts (and any future link sources) to backend/kamisensei_db.json
so they survive frontend state resets, notebook switches and page reloads.

Schema:
{
  "sources": [
    {
      "id": "<uuid>",
      "type": "youtube",
      "title": "<video title>",
      "url": "<youtube url>",
      "author": "<channel name>",
      "transcript": "<full clean text>",
      "created_at": "<ISO timestamp>"
    }
  ]
}

Pure standard library, synchronous atomic writes (write temp + rename) so a
crash mid-write can never corrupt the store.
"""

import argparse
import io
import json
import os
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

# Force UTF-8 on stdout so native-language characters (Japanese, Hindi, etc.)
# print safely instead of crashing with UnicodeEncodeError on Windows (cp1252).
# The bridge contract is a single JSON line on stdout — it must survive any
# language the store contains. Mirrors youtube_service.py.
if hasattr(sys.stdout, 'encoding') and sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Persistent sources move to the shared data root (D: by default). Falls back to
# the in-repo path only if that root is unusable, so existing data is still read.
try:
    from background import storage_paths as _storage_paths
except ImportError:  # pragma: no cover
    _storage_paths = None

_LEGACY_DB = ROOT_DIR / "kamisensei_db.json"
_DEFAULT_STORE = {"sources": []}


def _db_path() -> Path:
    if _storage_paths is not None:
        path = _storage_paths.kamisensei_sources()
        if str(path).startswith(str(_storage_paths.data_root())):
            return path
    return _LEGACY_DB


DB_PATH = _db_path()


def _refresh_db_path() -> Path:
    """Re-resolve the store path (the data root may change between calls)."""
    global DB_PATH
    DB_PATH = _db_path()
    return DB_PATH


def _atomic_write(path: Path, data: dict) -> None:
    """Write JSON atomically: dump to a temp file in the same dir, then rename."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".ks_db_", suffix=".json", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, str(path))
    except BaseException:
        # Never leave a half-written or orphaned temp file behind.
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
        raise


def read_store() -> dict:
    """Read and return the full store, falling back to an empty schema."""
    try:
        db = _refresh_db_path()
        if not db.exists():
            _atomic_write(db, _DEFAULT_STORE)
            return dict(_DEFAULT_STORE)
        with open(str(db), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or "sources" not in data:
            return dict(_DEFAULT_STORE)
        return data
    except (OSError, ValueError, json.JSONDecodeError):
        return dict(_DEFAULT_STORE)


def list_sources() -> list:
    """Return all saved sources, newest first."""
    store = read_store()
    sources = list(store.get("sources") or [])
    sources.sort(key=lambda s: s.get("created_at", ""), reverse=True)
    return sources


def find_source_by_url(url: str) -> dict | None:
    """Look up an already-saved source by its URL (duplicate guard)."""
    if not url:
        return None
    for src in read_store().get("sources") or []:
        if src.get("url") == url:
            return src
    return None


def add_source(*, type: str, title: str, url: str, transcript: str, author: str = "") -> dict:
    """
    Insert a new source into the store. If a source with the same URL already
    exists, the existing record is returned unchanged (idempotent / de-duped).

    Returns the saved source dict (with generated id + created_at).
    """
    store = read_store()
    existing = find_source_by_url(url)
    if existing:
        return existing

    title = str(title or "").strip() or url
    record = {
        "id": uuid.uuid4().hex,
        "type": str(type or "youtube").strip().lower() or "youtube",
        "title": title,
        "url": str(url or "").strip(),
        "author": str(author or "").strip(),
        "transcript": str(transcript or ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    store["sources"].append(record)
    _atomic_write(_refresh_db_path(), store)
    return record


def delete_source(source_id: str = "", url: str = "") -> bool:
    """Remove a source by id, or by normalized URL when no id is known.

    ``url`` acts as a fallback so the frontend can sync-remove the JSON-store
    copy when a notebook-scoped UI source is deleted (both must go together,
    otherwise the source reappears on the next page load).
    """
    store = read_store()
    sources = store.get("sources") or []
    before = len(sources)
    keep = []
    removed = False
    for src in sources:
        matches_id = bool(source_id) and src.get("id") == source_id
        matches_url = bool(url) and str(src.get("url") or "") == str(url).strip()
        if matches_id or matches_url:
            removed = True
            continue
        keep.append(src)
    if not removed:
        return False
    store["sources"] = keep
    _atomic_write(_refresh_db_path(), store)
    return True


# ── CLI contract consumed by the loopback bridge ──────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="KamiSensei JSON source store")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="Return all saved sources as JSON")

    p_add = sub.add_parser("add", help="Insert a source")
    p_add.add_argument("--type", default="youtube")
    p_add.add_argument("--title", default="")
    p_add.add_argument("--url", default="")
    p_add.add_argument("--transcript", default="")
    p_add.add_argument("--author", default="")

    p_del = sub.add_parser("delete", help="Delete a source by id or URL")
    p_del.add_argument("--id", default="")
    p_del.add_argument("--url", default="")

    args = parser.parse_args()
    if args.command == "list":
        print(json.dumps(list_sources(), ensure_ascii=False))
    elif args.command == "add":
        rec = add_source(
            type=args.type,
            title=args.title,
            url=args.url,
            transcript=args.transcript,
            author=args.author,
        )
        print(json.dumps(rec, ensure_ascii=False))
    elif args.command == "delete":
        print(json.dumps({"deleted": delete_source(args.id, args.url)}, ensure_ascii=False))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
