/* JARVIS Fight-Fitness Coach (Phase 6.3) - MediaPipe Pose rep counting.
 *
 * One camera, one stream: the view reuses the `video.camera-feed` element that
 * app.js already feeds, so this file never calls getUserMedia. Pose landmarks
 * come from @mediapipe/pose (the same solution-style API already used for the
 * hand tracker in @mediapipe/hands).
 *
 * The rep-counting state machine is deliberately pure and exported so it can be
 * tested WITHOUT a camera and WITHOUT a webcam permission - a coach whose logic
 * can only be verified by waving at a laptop is a coach nobody can verify.
 *
 * Honesty rules:
 *  - no landmarks => "body not visible", never a rep and never a fake count;
 *  - low-confidence visibility => counting is paused and says so;
 *  - every hint is derived from the measured angles, never invented.
 */
(function (root, factory) {
  var api = factory()
  if (typeof module !== 'undefined' && module.exports) module.exports = api
  root.__JARVIS_FIGHT__ = api
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict'

  // MediaPipe Pose 33-point landmark indices.
  var P = { nose: 0, shoulderL: 11, shoulderR: 12, elbowL: 13, elbowR: 14,
    wristL: 15, wristR: 16, hipL: 23, hipR: 24, kneeL: 25, kneeR: 26,
    ankleL: 27, ankleR: 28 }

  // Exercises. `joint` is [a, VERTEX, b] - the angle is measured AT the middle
  // index, so the landmark order matters: [shoulder, elbow, wrist] is the elbow
  // angle, not the shoulder angle.
  // `downBelow` is the bend that starts the down phase (a rep counts); `depth` is
  // the TIGHTER bend a full rep should reach (a smaller angle = deeper). So
  // depth must be SMALLER than downBelow - otherwise every counted rep passes
  // the depth check and the hint could never fire.
  var EXERCISES = {
    'push-up': { key: 'push-up', label: 'Push-ups',
      joint: [P.shoulderL, P.elbowL, P.wristL],
      downBelow: 115, upAbove: 155, depth: 95, tempoMs: [500, 4000] },
    'squat': { key: 'squat', label: 'Squats',
      joint: [P.hipL, P.kneeL, P.ankleL],
      downBelow: 120, upAbove: 165, depth: 95, tempoMs: [500, 4000] },
    'plank-hold': { key: 'plank-hold', label: 'Plank hold',
      joint: [P.shoulderL, P.hipR, P.ankleR], isHold: true,
      downBelow: 175, upAbove: 0, depth: 0, tempoMs: [0, 0] }
  }

  function angleAt(a, b, c) {
    // Interior angle at b, in degrees. All three points are {x, y, z}.
    if (!a || !b || !c) return null
    var v1x = a.x - b.x, v1y = a.y - b.y, v1z = (a.z || 0) - (b.z || 0)
    var v2x = c.x - b.x, v2y = c.y - b.y, v2z = (c.z || 0) - (b.z || 0)
    var dot = v1x * v2x + v1y * v2y + v1z * v2z
    var mag1 = Math.sqrt(v1x * v1x + v1y * v1y + v1z * v1z)
    var mag2 = Math.sqrt(v2x * v2x + v2y * v2y + v2z * v2z)
    if (!mag1 || !mag2) return null
    var cos = Math.max(-1, Math.min(1, dot / (mag1 * mag2)))
    return Math.acos(cos) * 180 / Math.PI
  }

  function jointAngle(landmarks, joint) {
    if (!joint || !landmarks) return null
    return angleAt(landmarks[joint[0]], landmarks[joint[1]], landmarks[joint[2]])
  }

  /* Rep counter: a phase machine, not a guess.
   * down -> up transition counts exactly one rep; partial movements do not. */
  function RepCounter(exerciseKey) {
    this.exercise = EXERCISES[exerciseKey] || EXERCISES['push-up']
    this.reps = 0
    this.phase = 'up'      // up | down
    this.holdMs = 0
    this.lastRepAt = 0
    this.hints = []
    this.lastAngle = null
  }

  RepCounter.prototype.update = function (landmarks, timestampMs, visibility) {
    var angle = jointAngle(landmarks, this.exercise.joint)
    this.lastAngle = angle
    if (angle == null || (visibility != null && visibility < 0.5)) {
      this.hints = ['body not clearly visible - step back so the whole body is in frame']
      return this.state()
    }
    var now = timestampMs || 0
    if (this.exercise.isHold) {
      // A hold rep is one continuous second on target; counted once it passes.
      var flat = angle >= this.exercise.downBelow
      this.holdMs = flat ? this.holdMs + 33 : 0
      if (this.holdMs >= 1000 && this.phase === 'up') {
        this.phase = 'done'
        this.reps += 1
        this.lastRepAt = now
      } else if (!flat && this.phase === 'done') {
        this.phase = 'up'
      }
      return this.state()
    }
    if (angle <= this.exercise.downBelow) {
      this.phase = 'down'
      this.deepest = Math.min(this.deepest == null ? angle : this.deepest, angle)
    } else if (angle >= this.exercise.upAbove && this.phase === 'down') {
      this.phase = 'up'
      this.reps += 1
      var elapsed = this.lastRepAt ? now - this.lastRepAt : 0
      this.hints = this.formHints(elapsed)
      this.lastRepAt = now
      this.deepest = null
    }
    return this.state()
  }

  RepCounter.prototype.formHints = function (elapsedMs) {
    var hints = []
    var tempo = this.exercise.tempoMs
    if (tempo[0] && elapsedMs && elapsedMs < tempo[0]) hints.push('too fast - control the descent')
    if (tempo[1] && elapsedMs && elapsedMs > tempo[1]) hints.push('slow - keep the tempo up')
    if (this.deepest != null && this.deepest > this.exercise.depth) {
      hints.push('depth shallow - go lower next rep')
    }
    this.hints = hints
    return hints
  }

  RepCounter.prototype.state = function () {
    return { exercise: this.exercise.key, reps: this.reps, phase: this.phase,
      angle: this.lastAngle == null ? null : Math.round(this.lastAngle),
      hints: this.hints.slice() }
  }

  // ── browser side: Pose glue + overlay ──────────────────────────────────────
  var browser = {
    pose: null, stream: null, raf: 0, active: false, exercise: 'push-up',
    counter: null, lastVideoTime: -1, cameraWarned: false,
    video: null, canvas: null, status: null, count: null, hints: null,
    landmarks: null
  }

  function ui() {
    if (!browser.video) {
      browser.video = document.querySelector('[data-fight-panel] video.camera-feed')
      browser.canvas = document.getElementById('fight-canvas')
      browser.status = document.getElementById('fight-status')
      browser.count = document.getElementById('fight-count')
      browser.hints = document.getElementById('fight-hints')
      browser.counter = new RepCounter(browser.exercise)
    }
    return browser
  }

  function paint(state) {
    if (browser.count) browser.count.textContent = String(state.reps)
    if (browser.status) {
      browser.status.textContent = state.angle == null
        ? 'body not visible'
        : (state.exercise + ' · ' + state.phase + ' · ' + state.angle + '°')
    }
    if (browser.hints) {
      browser.hints.textContent = state.hints.length
        ? state.hints.join(' · ') : 'form looks clean'
    }
  }

  function drawOverlay(landmarks) {
    var canvas = browser.canvas
    if (!canvas) return
    var video = browser.video
    if (!video) return
    var w = video.videoWidth || 640
    var h = video.videoHeight || 480
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w
      canvas.height = h
    }
    var ctx = canvas.getContext('2d')
    ctx.clearRect(0, 0, w, h)
    if (!landmarks) return
    ctx.fillStyle = '#36e2ff'
    for (var i = 0; i < landmarks.length; i++) {
      var lm = landmarks[i]
      ctx.beginPath()
      ctx.arc(lm.x * w, lm.y * h, 4, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  function loadPose(cb) {
    if (browser.pose) return cb()
    if (!root.Pose) {
      paint({ reps: 0, phase: 'idle', angle: null, exercise: browser.exercise,
        hints: ['pose library not loaded - check the CDN script'] })
      return
    }
    browser.pose = new root.Pose({
      locateFile: (file) => 'https://cdn.jsdelivr.net/npm/@mediapipe/pose/' + file
    })
    browser.pose.setOptions({
      modelComplexity: 1, smoothLandmarks: true,
      enableSegmentation: false, minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5
    })
    browser.pose.onResults(onResults)
    cb()
  }

  function onResults(results) {
    var landmarks = (results && results.poseLandmarks) || null
    browser.landmarks = landmarks
    drawOverlay(landmarks)
    var visibility = landmarks && landmarks[P.hipL]
      ? (landmarks[P.hipL].visibility || 1) : null
    var state = browser.counter.update(landmarks, performance.now(), visibility)
    paint(state)
  }

  function pump() {
    browser.raf = requestAnimationFrame(pump)
    var video = browser.video
    if (!video || video.readyState < 2 || !browser.pose) return
    if (video.currentTime === browser.lastVideoTime) return
    browser.lastVideoTime = video.currentTime
    try { browser.pose.send({ image: video }) } catch (_) {}
  }

  function open() {
    ui()
    browser.active = true
    if (!browser.cameraWarned && browser.video && !browser.video.srcObject) {
      browser.cameraWarned = true
      paint({ reps: browser.counter.reps, phase: 'idle', angle: null,
        exercise: browser.exercise,
        hints: ['camera off - use the dashboard camera button first'] })
    }
    loadPose(function () {
      if (!browser.raf) pump()
    })
  }

  function close() {
    ui()
    browser.active = false
    cancelAnimationFrame(browser.raf)
    browser.raf = 0
  }

  function setExercise(key) {
    ui()
    browser.exercise = EXERCISES[key] ? key : 'push-up'
    browser.counter = new RepCounter(browser.exercise)
    paint(browser.counter.state())
    return browser.exercise
  }

  function bind() {
    var box = document.getElementById('fight-exercises')
    if (!box || box.dataset.wired) return
    box.dataset.wired = '1'
    box.addEventListener('click', function (event) {
      var btn = event.target.closest('[data-exercise]')
      if (btn) setExercise(btn.dataset.exercise)
    })
  }

  function init() {
    ui()
    bind()
  }

  return {
    angleAt: angleAt, jointAngle: jointAngle, RepCounter: RepCounter,
    EXERCISES: EXERCISES, landmarks: P, init: init, open: open, close: close,
    setExercise: setExercise, onView: function (isFight) { isFight ? open() : close() },
    state: function () {
      ui()
      return browser.counter ? browser.counter.state() : { reps: 0, phase: 'idle' }
    }
  }
})