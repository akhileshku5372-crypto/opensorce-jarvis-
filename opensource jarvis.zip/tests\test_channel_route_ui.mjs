// Live end-to-end proof of the Universal Input Router against the RUNNING
// stack (vite :7777 + voice core :7780). Read-only: it types into the real
// composer, waits for the core, and asserts the dashboard switched panels.
//
// Run: node tests/test_channel_route_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const artifactsDir = path.join(root, 'artifacts', 'ui-audit', 'channel-route')
mkdirSync(artifactsDir, { recursive: true })

const UI = 'http://127.0.0.1:7777/'
const CORE = 'http://127.0.0.1:7780'

const CASES = [
  { text: 'teach me kanji N3 grammar', expect: 'kamisensei' },
  { text: 'remind me to call mom in 10 minutes', expect: 'calendar' },
  { text: 'how much RAM is being used right now', expect: 'system_health' }
]

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-route-ui-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=9222', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
  '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { rmSync(profile, { recursive: true, force: true }) } catch {}
}
setTimeout(() => { cleanup(); process.exit(124) }, 100000).unref()

async function connect() {
  // Launch a dedicated tab and attach to THAT target. Picking the first
  // "page" target can grab a different tab (e.g. about:blank) that never
  // received our navigation, which makes the page look empty.
  for (let i = 0; i < 40; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:9222/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) {
        const page = await res.json()
        if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
      }
    } catch {}
    await wait(500)
  }
  // Fall back to any page target if /json/new is unavailable.
  for (let i = 0; i < 20; i++) {
    try {
      const list = await (await fetch('http://127.0.0.1:9222/json/list')).json()
      const page = list.find((t) => t.type === 'page' && String(t.url).includes('7777'))
      if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
    } catch {}
    await wait(500)
  }
  throw new Error('CDP did not come up')
}

function cdp(ws) {
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id) }
  })
  return (method, params = {}) => new Promise((resolve) => {
    const mid = ++id
    pending.set(mid, resolve)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
}

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

try {
  const wsUrl = await connect()
  const ws = new WebSocket(wsUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', reject)
  })
  const send = cdp(ws)

  await send('Page.enable')
  await send('Runtime.enable')
  await send('Log.enable')

  const problems = []
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.method === 'Runtime.exceptionThrown') {
      problems.push('EXC ' + (m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text || '?'))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      problems.push('ERR ' + m.params.entry.text)
    }
  })

  await send('Page.navigate', { url: UI })

  // Vite dev transforms index.tsx on first hit, which can take many seconds
  // on this large page. Poll for the real mount instead of a fixed sleep.
  let mounted = false
  for (let i = 0; i < 45; i++) {
    const probe = await send('Runtime.evaluate', {
      expression: '({ ready: document.readyState, hasLog: !!document.getElementById("chat-log"), hasCowork: !!document.querySelector(\'[data-view-panel="cowork"]\'), views: document.querySelectorAll(".view").length })',
      returnByValue: true
    })
    const v = probe.result?.result?.value
    if (v?.hasLog && v?.hasCowork) { mounted = true; break }
    if (i % 10 === 9) console.log('  ..  waiting, probe=' + JSON.stringify(v))
    await wait(1000)
  }

  if (mounted) ok('dashboard mounted')
  else {
    bad('dashboard did not mount')
    if (problems.length) problems.slice(0, 6).forEach((p) => console.log('    ' + p))
  }

  // The dashboard only posts to the core once it has seen /state succeed.
  // Submitting before that silently falls through to the browser AI path,
  // which never reaches the router. Wait for the real signal.
  let coreOnline = false
  for (let i = 0; i < 40; i++) {
    const probe = await send('Runtime.evaluate', {
      expression: 'document.getElementById("bridge-label")?.textContent || ""',
      returnByValue: true
    })
    const label = String(probe.result?.result?.value || '')
    // The label is "CORE ONLINE" or "CORE + BRIDGE ONLINE" depending on the
    // bridge, so match on "CORE" rather than an exact phrase.
    if (label.includes('CORE')) { coreOnline = true; break }
    if (i % 10 === 9) console.log('  ..  waiting for core, label=' + label)
    await wait(1000)
  }
  if (coreOnline) ok('dashboard sees the core online')
  else bad('dashboard never reached CORE ONLINE - typed commands would bypass the router')

  for (const c of CASES) {
    // Remember the revision BEFORE submitting, so we only accept a route that
    // this command actually caused.
    let startRev = 0
    try {
      const before = await (await fetch(`${CORE}/state`)).json()
      startRev = Number(before.channel_revision || 0)
    } catch {}

    // The real composer is #chat-form / #chat-input (there is no
    // #command-form in the shipped dashboard).
    await send('Runtime.evaluate', {
      expression: `(() => {
        const i = document.getElementById('chat-input');
        if (!i) return 'no-input';
        i.value = ${JSON.stringify(c.text)};
        document.getElementById('chat-form').requestSubmit();
        return 'sent';
      })()`,
      returnByValue: true
    })
    const sent = await send('Runtime.evaluate', {
      expression: 'document.getElementById("chat-input") ? "present" : "absent"',
      returnByValue: true
    })
    if (sent.result?.result?.value !== 'present') {
      bad(`composer #chat-input missing - cannot drive "${c.text}"`)
      continue
    }
    // Poll the core until it reports THIS command's channel. A fixed sleep is
    // racy: the voice loop may still be speaking, and /action is throttled by
    // the command worker, so the route can land after our first read.
    let channel = 'timeout'
    let rev = 0
    const deadline = Date.now() + 20000
    while (Date.now() < deadline) {
      try {
        const state = await (await fetch(`${CORE}/state`)).json()
        const liveRev = Number(state.channel_revision || 0)
        if (liveRev > startRev) {
          channel = state.channel?.id
          rev = liveRev
          if (channel) break
        }
      } catch {}
      await wait(500)
    }

    const active = await send('Runtime.evaluate', {
      expression: 'document.querySelector(".view.active")?.dataset.viewPanel || "none"',
      returnByValue: true
    })
    const view = active.result?.result?.value

    if (channel === c.expect) ok(`"${c.text}" -> ${channel} (view=${view}, rev=${rev})`)
    else bad(`"${c.text}" expected ${c.expect}, got ${channel} (view=${view})`)
  }

  const flashed = await send('Runtime.evaluate', {
    expression: 'document.querySelectorAll("[data-active-panel]").length',
    returnByValue: true
  })
  const flashCount = flashed.result?.result?.value ?? 0
  console.log('  note  widgets flashed: ' + flashCount)

  // Visual proof: the dashboard is sitting on a routed panel, not the home view.
  try {
    const shot = await send('Page.captureScreenshot', { format: 'png' })
    if (shot.result?.data) {
      const out = path.join(artifactsDir, 'channel-route-live.png')
      writeFileSync(out, Buffer.from(shot.result.data, 'base64'))
      console.log('  ok   screenshot -> ' + path.relative(root, out))
    }
  } catch (err) {
    console.log('  note  screenshot skipped: ' + err.message)
  }
} catch (err) {
  bad(err.message)
} finally {
  cleanup()
}

console.log(`\nCHANNEL ROUTE UI: ${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
