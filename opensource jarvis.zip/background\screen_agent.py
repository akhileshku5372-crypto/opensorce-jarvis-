"""Screen agent: JARVIS ko screen dekh ke mouse/keyboard chalane ki shakti.

Design (UI-TARS / UFO2 / Agent-S research pattern):
  perceive -> ground -> act -> verify
  - perceive: PowerShell screen capture (voice_engine.analyze_screen jaisa)
  - ground:   VLM ko screenshot + task do -> EXACT pixel coordinates wapas
  - act:      pyautogui (allowlisted primitives only)
  - verify:   dobara screenshot, VLM se confirm

Safety (AGENTS.md ke andar):
  - Sirf allowlisted pyautogui primitives; koi shell/executable/paths nahi.
  - DESTRUCTIVE actions (type/hotkey/double_click) par confirmation: pehle
    "execute karun?" jaye ga, aur "confirm"/"haan" bolne par hi chalega.
  - pyautogui.FAILSAFE: mouse screen ke top-left corner pe = emergency stop.
"""
import base64
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time

import requests

try:
    from dotenv import load_dotenv
    for _f in (".env", ".dev.vars"):
        if os.path.exists(_f):
            load_dotenv(_f, override=False)
except Exception:
    pass

_FACTUAL_TEMPERATURE = 0.15
_CONFIRM_TTL = 120.0
_MAX_STEPS = 6          # perceive->ground->act loop ka safety cap

DESTRUCTIVE_ACTIONS = {"type", "hotkey", "double_click"}

_ALLOWED_KEYS = {
    "enter", "tab", "esc", "escape", "space", "backspace", "delete", "home",
    "end", "pageup", "pagedown", "up", "down", "left", "right",
    "winleft", "winright", "ctrlleft", "ctrlright", "altleft", "altright",
    "shiftleft", "shiftright", "capslock", "numlock", "insert",
    "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12",
}
_ALLOWED_SINGLE = _ALLOWED_KEYS - {"ctrlleft", "ctrlright", "winleft",
                                   "winright", "altleft", "altright",
                                   "shiftleft", "shiftright"}
# Short modifier spellings that pyautogui understands but the allowlist did not
# carry, so a plain ctrl+a / alt+tab / shift+s used to be refused outright.
_MODIFIER_ALIASES = {
    "ctrl": "ctrlleft", "control": "ctrlleft", "ctl": "ctrlleft",
    "alt": "altleft", "option": "altleft",
    "shift": "shiftleft", "win": "winleft", "windows": "winleft",
    "cmd": "winleft", "super": "winleft", "meta": "winleft",
}

_XKIRO_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

_PENDING = None   # {"task": {...}, "at": monotonic}


# ── DPI awareness ───────────────────────────────────────────────────────────
# Windows hands a non-DPI-aware process a SCALED resolution: on this 1920x1080
# machine (125% scaling) both the PowerShell capture and pyautogui reported
# 1536x864, so every VLM coordinate landed ~20% away from its target and the
# agent "did nothing". Awareness must be set before pyautogui/PIL are imported.
_DPI_AWARE = False


def _ensure_dpi_awareness() -> bool:
    """Per-monitor DPI awareness v2, once per process. True when active."""
    global _DPI_AWARE
    if _DPI_AWARE:
        return True
    _DPI_AWARE = True
    if os.name != "nt":
        return False
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)      # PROCESS_PER_MONITOR_DPI_AWARE
        return True
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDPIAware()
        return True
    except Exception:
        return False


_ensure_dpi_awareness()


def _png_size(image_b64: str):
    """(width, height) from a base64 PNG header - no image decode, no PIL."""
    try:
        raw = base64.b64decode(image_b64)
        if raw[:8] == b"\x89PNG\r\n\x1a\n":
            return (int.from_bytes(raw[16:20], "big"),
                    int.from_bytes(raw[20:24], "big"))
    except Exception:
        pass
    return (0, 0)


def available():
    try:
        import pyautogui  # noqa: F401
        return True
    except Exception:
        return False


def _capture_screen_png_b64():
    """Screenshot as base64 PNG in REAL pixel space (DPI-aware).

    The old path spawned PowerShell per capture: 1.3s AND a scaled-down image
    (1536x864 on a 1920x1080 screen) because that process was not DPI aware.
    Pillow grabs the same frame in-process in ~30ms at full resolution; the
    PowerShell path stays as a fallback for a locked-down machine.
    """
    _ensure_dpi_awareness()
    try:
        from PIL import ImageGrab
        import io as _io
        buf = _io.BytesIO()
        ImageGrab.grab().convert("RGB").save(buf, format="PNG")
        data = buf.getvalue()
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return base64.b64encode(data).decode("ascii")
    except Exception:
        pass
    fd, path = tempfile.mkstemp(suffix=".agent.png")
    os.close(fd)
    escaped = path.replace("\\", "/").replace("'", "''")
    script = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "Add-Type -AssemblyName System.Drawing;"
        "$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
        "$i=New-Object System.Drawing.Bitmap $b.Width,$b.Height;"
        "$g=[System.Drawing.Graphics]::FromImage($i);"
        "$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);"
        "$i.Save('" + escaped + "');$g.Dispose();$i.Dispose()"
    )
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
             "-Command", script],
            capture_output=True, timeout=25, creationflags=0x08000000)
        if proc.returncode != 0 or not os.path.getsize(path):
            return None
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode("ascii")
    except Exception:
        return None
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def capture_screen():
    """Public screen capture: raw PNG bytes, or None if the grab failed.

    The perception plugin's `source="screen"` path calls this name. It used to
    ask for a `capture_screen` that did not exist, and the hasattr guard hid
    it, so that source answered "screen capture unavailable" forever while the
    card claimed screen/camera perception was live.
    """
    b64 = _capture_screen_png_b64()
    if not b64:
        return None
    try:
        return base64.b64decode(b64)
    except Exception:
        return None


_SHELL_TITLES = {"", "search", "start", "task view", "program manager",
                 "windows input experience", "msctfime ui", "default imTip",
                 "settings", "shell input window"}


def _foreground_title():
    """Active window ka title (ctypes; koi external process nahi)."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(max(1, length + 1))
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return (buf.value or "").strip()
    except Exception:
        return ""


def _is_shell_title(title):
    """Start menu / search host / koi-real-app-nahi heuristic."""
    low = (title or "").strip().lower()
    if not low or low in _SHELL_TITLES:
        return True
    return low.startswith(("search", "start", "task view", "windows input"))


def _foreground_hwnd():
    """Active window ka hwnd (0 agar koi nahi)."""
    try:
        import ctypes
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def _force_foreground(hwnd) -> bool:
    """Raise a window even when another process owns the foreground.

    Windows only lets the FOREGROUND process set the foreground window, so a
    plain SetForegroundWindow() from the JARVIS process is ignored while the
    user is working in another app - the next keystroke then went to that app
    instead of the one JARVIS just raised. Attaching our input queue to the
    current foreground one for the duration is the standard workaround; a
    synthetic ALT tap is the second trick when the first is refused.
    """
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    if not hwnd:
        return False
    fg_tid = None
    try:
        cur = kernel32.GetCurrentThreadId()
        fg = user32.GetForegroundWindow()
        if fg:
            fg_tid = user32.GetWindowThreadProcessId(fg, None)
        attached = bool(fg_tid) and fg_tid != cur
        if attached:
            user32.AttachThreadInput(cur, fg_tid, True)
        try:
            user32.ShowWindow(hwnd, 9)                 # SW_RESTORE
            user32.BringWindowToTop(hwnd)
            user32.SetForegroundWindow(hwnd)
            user32.SetActiveWindow(hwnd)
        finally:
            if attached:
                user32.AttachThreadInput(cur, fg_tid, False)
        if user32.GetForegroundWindow() == hwnd:
            return True
        # Second chance: the ALT tap unlocks the foreground lock.
        user32.keybd_event(0x12, 0, 0, 0)             # VK_MENU down
        user32.keybd_event(0x12, 0, 0x0002, 0)        # VK_MENU up
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        return user32.GetForegroundWindow() == hwnd
    except Exception:
        return False


def _app_window_ready(timeout=6.0):
    """Wait karo jab tak foreground ek real app window na ban jaye
    (title stable 0.6s). Start menu/search host ko ignore karta hai.
    Returns window title ya None."""
    deadline = time.monotonic() + timeout
    last, stable_since = None, None
    while time.monotonic() < deadline:
        title = _foreground_title()
        if title and not _is_shell_title(title):
            now = time.monotonic()
            if title != last:
                last, stable_since = title, now
            elif now - stable_since >= 0.6:
                return title
        else:
            last, stable_since = None, None
        time.sleep(0.25)
    return None


def _vision_call(image_b64, question, max_tokens=500, grounding=False):
    """Multimodal VLM call for grounding & verification.

    Grounding prefers xKiro's Qwen3-VL (measured 60px average error on this
    machine) over Gemini flash-lite (110px), because a text-tuned vision model
    guesses coordinates. Planning keeps Gemini first: there it reasons, it does
    not aim. Either way a failure falls through to the next provider.
    """
    def _gemini():
        for gkey in (os.environ.get("GOOGLE_API_KEY"),
                     os.environ.get("GOOGLE_API_KEY_2")):
            gkey = (gkey or "").strip()
            if not gkey:
                continue
            model = (os.environ.get("GOOGLE_MODEL")
                     or "gemini-flash-lite-latest").strip()
            try:
                r = requests.post(
                    "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
                    headers={"Authorization": "Bearer " + gkey,
                             "Content-Type": "application/json"},
                    json={
                        "model": model,
                        "max_tokens": max_tokens,
                        "temperature": _FACTUAL_TEMPERATURE,
                        "messages": [{"role": "user", "content": [
                            {"type": "text", "text": question},
                            {"type": "image_url", "image_url": {
                                "url": "data:image/png;base64," + image_b64}},
                        ]}]
                    },
                    timeout=30)
                if r.status_code == 200:
                    data = r.json()
                    content = data.get("choices", [{}])[0].get("message", {}).get(
                        "content", "").strip()
                    if content:
                        return content
            except Exception:
                pass
        return None

    def _xkiro():
        key = (os.environ.get("XKIRO_API_KEY") or "").strip()
        if not key:
            return None
        model = os.environ.get("XKIRO_VISION_MODEL", "qwen/qwen3-vl-plus:free")
        try:
            r = requests.post(
                "https://api.xkiro.com/v1/chat/completions",
                headers={"Authorization": "Bearer " + key,
                         "User-Agent": _XKIRO_UA},
                json={"model": model, "max_tokens": max_tokens,
                      "temperature": _FACTUAL_TEMPERATURE,
                      "messages": [{"role": "user", "content": [
                          {"type": "text", "text": question},
                          {"type": "image_url",
                           "image_url": {"url": "data:image/png;base64," + image_b64}},
                      ]}]},
                timeout=45)
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
        return None

    order = (_xkiro, _gemini) if grounding else (_gemini, _xkiro)
    for fn in order:
        out = fn()
        if out:
            return out
    return None


def _ground_target(image_b64, target):
    """VLM se target element ke EXACT pixel coordinates.

    The model answers on a 0-1000 relative grid and we scale to the real pixel
    size of the screenshot we sent. Measured on this machine: absolute-pixel
    prompting drifted ~360px on Gemini flash-lite, the relative grid ~110px,
    and ~60px on Qwen3-VL - so the grid is the contract, not an optimisation.
    """
    width, height = _png_size(image_b64)
    if not width or not height:
        return None
    raw = _vision_call(image_b64, (
        "You are a precise GUI grounding engine. The screenshot is %d x %d "
        "pixels, but you must answer on a 0-1000 grid: x=0 is the left edge, "
        "x=1000 is the right edge, y=0 is the top edge, y=1000 is the bottom "
        "edge. Locate this element: \"%s\"\n"
        "Respond ONLY with a JSON object, no prose, no markdown: "
        '{"x": <int 0-1000>, "y": <int 0-1000>, "found": true|false, '
        '"element": "<short label>"}\n'
        "found=false only if the element is genuinely absent from this "
        "screenshot." % (width, height, target)), grounding=True)
    if not raw:
        return None
    m = re.search(r"\{[^{}]*\}", raw, re.S)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
        if data.get("found") and isinstance(data.get("x"), (int, float)) \
                and isinstance(data.get("y"), (int, float)):
            x = int(round(float(data["x"]) * width / 1000.0))
            y = int(round(float(data["y"]) * height / 1000.0))
            return (max(0, min(width - 1, x)), max(0, min(height - 1, y)),
                    str(data.get("element") or target))
    except Exception:
        return None
    return None


def _exec_click(x, y, kind="click"):
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.25
    if kind == "right":
        pyautogui.rightClick(int(x), int(y))
        return "right-clicked at (%s, %s)." % (x, y)
    if kind == "double":
        pyautogui.doubleClick(int(x), int(y))
        return "double-clicked at (%s, %s)." % (x, y)
    pyautogui.click(int(x), int(y))
    return "clicked at (%s, %s)." % (x, y)


def _exec_move(x, y):
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.moveTo(int(x), int(y), duration=0.2)
    return "mouse moved to (%s, %s)." % (x, y)


def _foreground_rect():
    """Rect of the focused window as (l, t, r, b); None when unknown."""
    try:
        import ctypes
        from ctypes import wintypes
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        if not hwnd:
            return None
        class _RECT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long),
                        ("r", ctypes.c_long), ("b", ctypes.c_long)]
        r = _RECT()
        if ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r)):
            if r.r > r.l and r.b > r.t:
                return (r.l, r.t, r.r, r.b)
    except Exception:
        pass
    return None


def _screen_signature(rect=None):
    """Tiny grayscale fingerprint, used only for "did anything move?".

    Cropped to the focused window when possible: a full-screen hash is useless
    here because any animating overlay (an IDE FPS counter, a blinking taskbar
    clock) changes every frame and would make every scroll look successful.
    """
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab(bbox=rect) if rect else ImageGrab.grab()
        return img.convert("L").resize((64, 36)).tobytes()
    except Exception:
        return None


def _signature_moved(before, after, threshold=2.5) -> bool:
    """Mean per-pixel level change above `threshold` counts as real motion."""
    if not before or not after or len(before) != len(after):
        return True                      # cannot compare -> assume it moved
    diff = sum(abs(x - y) for x, y in zip(before, after)) / float(len(before))
    return diff > threshold


# ---------------------------------------------------------------------------
# Live Screen: one local sampler, latest frame only, never a cloud video feed.
#
# The sampler runs in its own daemon thread and keeps the most recent JPEG in
# RAM.  It does not write screenshots to disk, does not upload anything, and
# `stop_watching()` clears every captured byte before it returns.  A caller
# that needs reading passes this latest frame to `local_ocr`; cloud vision is
# only an explicit opt-in fallback, and the model never gets a video stream.
# ---------------------------------------------------------------------------
_WATCH_SCOPE_FULL = "full_screen"
_WATCH_SCOPE_WINDOW = "active_window"
_WATCH_DEFAULT_SCOPE = os.environ.get("JARVIS_SCREEN_SCOPE", _WATCH_SCOPE_FULL)
try:
    _WATCH_DEFAULT_FPS = max(0.2, min(2.0, float(
        os.environ.get("JARVIS_SCREEN_FPS", "0.5"))))
except (TypeError, ValueError):
    _WATCH_DEFAULT_FPS = 0.5


def _watch_capture(scope):
    """Grab one frame locally. Kept as a seam so tests never touch the desktop."""
    from PIL import ImageGrab
    rect = _foreground_rect() if scope == _WATCH_SCOPE_WINDOW else None
    if rect:
        return ImageGrab.grab(bbox=rect)
    return ImageGrab.grab()


class ScreenWatcher:
    """Thread-safe, latest-frame-only local screen buffer."""

    def __init__(self):
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self._enabled = False
        self._scope = _WATCH_DEFAULT_SCOPE
        self._fps = _WATCH_DEFAULT_FPS
        self._jpeg_b64 = ""
        self._signature = None
        self._last_frame_at = 0.0
        self._last_change_at = 0.0
        self._foreground = ""
        self._error = ""
        self._frame_kb = 0.0
        self._frames = 0
        self._cleared_at = 0.0
        self._on_update = None

    def _status_locked(self):
        now = time.time()
        return {
            "enabled": bool(self._enabled),
            "scope": self._scope,
            "fps": round(float(self._fps), 2),
            "frames": int(self._frames),
            "last_frame_at": float(self._last_frame_at),
            "last_change_at": float(self._last_change_at),
            "foreground": self._foreground,
            "error": self._error,
            "cleared_at": float(self._cleared_at),
            "age_s": (round(max(0.0, now - self._last_frame_at), 1)
                      if self._last_frame_at else 0.0),
            "frame_kb": round(float(self._frame_kb), 1),
            "thread_alive": bool(self._thread and self._thread.is_alive()),
        }

    def _clear_locked(self):
        self._jpeg_b64 = ""
        self._signature = None
        self._last_frame_at = 0.0
        self._last_change_at = 0.0
        self._foreground = ""
        self._error = ""
        self._frame_kb = 0.0
        self._frames = 0

    def _supported(self):
        try:
            from PIL import ImageGrab  # noqa: F401
            return True, ""
        except Exception as exc:
            return False, "Pillow screen capture unavailable: %s" % (
                type(exc).__name__,)

    def start(self, scope=None, fps=None, on_update=None):
        with self._lock:
            self._scope = (scope if scope in (_WATCH_SCOPE_FULL, _WATCH_SCOPE_WINDOW)
                           else _WATCH_DEFAULT_SCOPE)
            if fps is not None:
                try:
                    self._fps = max(0.2, min(2.0, float(fps)))
                except (TypeError, ValueError):
                    self._fps = _WATCH_DEFAULT_FPS
            self._on_update = on_update
            if self._thread and self._thread.is_alive():
                self._enabled = True
                return self._status_locked()
            ok, reason = self._supported()
            if not ok:
                self._enabled = False
                self._error = reason
                return self._status_locked()
            self._enabled = True
            self._error = ""
            stop_event = threading.Event()
            self._stop = stop_event
            thread = threading.Thread(
                target=self._run, args=(stop_event,),
                name="jarvis-screen-watch", daemon=True)
            self._thread = thread
            thread.start()
            return self._status_locked()

    def _run(self, stop_event):
        while not stop_event.is_set():
            started = time.monotonic()
            try:
                with self._lock:
                    scope = self._scope
                    fps = self._fps
                    previous_foreground = self._foreground
                foreground_before = _foreground_title()
                image = _watch_capture(scope)
                image = image.convert("RGB")
                image.thumbnail((1280, 720))
                signature = image.convert("L").resize((64, 36)).tobytes()
                buf = io.BytesIO()
                image.save(buf, format="JPEG", quality=70, optimize=True)
                raw = buf.getvalue()
                encoded = base64.b64encode(raw).decode("ascii")
                foreground_after = _foreground_title()
                now = time.time()
                with self._lock:
                    if stop_event.is_set() or not self._enabled:
                        return
                    if foreground_before != foreground_after:
                        # The window changed while the pixels were being
                        # grabbed. Do not pair the OLD image with the NEW
                        # title; that produced a correct-looking analysis of
                        # the previous screen. Drop it and force a fresh grab.
                        self._jpeg_b64 = ""
                        self._last_frame_at = 0.0
                        self._signature = None
                        self._foreground = foreground_after
                        self._last_change_at = now
                        self._frame_kb = 0.0
                        self._error = ""
                        status = self._status_locked()
                        update = self._on_update
                    else:
                        moved = (self._signature is None
                                 or _signature_moved(
                                     self._signature, signature))
                        foreground = foreground_after
                        title_changed = foreground != previous_foreground
                        self._jpeg_b64 = encoded
                        self._last_frame_at = now
                        self._signature = signature
                        self._foreground = foreground
                        self._frame_kb = len(raw) / 1024.0
                        self._frames += 1
                        self._error = ""
                        # A tab/window switch can leave the pixels nearly
                        # identical (two dark pages). The title change is
                        # still a real change and must not wait for the 25s
                        # heartbeat.
                        if moved or title_changed:
                            self._last_change_at = now
                        status = self._status_locked()
                        update = self._on_update
            except Exception as exc:
                with self._lock:
                    if stop_event.is_set() or not self._enabled:
                        return
                    self._error = "%s: %s" % (type(exc).__name__, str(exc)[:120])
                    status = self._status_locked()
                    update = self._on_update
            if update is not None:
                try:
                    update(status)
                except Exception:
                    pass
            elapsed = time.monotonic() - started
            stop_event.wait(max(0.05, (1.0 / max(0.2, fps)) - elapsed))

    def stop(self):
        with self._lock:
            self._enabled = False
            self._stop.set()
            thread = self._thread
        if (thread is not None and thread.is_alive()
                and thread is not threading.current_thread()):
            thread.join(2.0)
        with self._lock:
            self._thread = None
            self._clear_locked()
            self._cleared_at = time.time()
            status = self._status_locked()
            update = self._on_update
        if update is not None:
            try:
                update(status)
            except Exception:
                pass
        return status

    def status(self):
        with self._lock:
            return self._status_locked()

    def latest(self, max_age=5.0):
        """Return the latest frame only when it is enabled and still fresh."""
        with self._lock:
            if not self._enabled or not self._jpeg_b64:
                return None
            age = max(0.0, time.time() - self._last_frame_at)
            if max_age is not None and age > float(max_age):
                return None
            return {
                "jpeg_b64": self._jpeg_b64,
                "captured_at": float(self._last_frame_at),
                "foreground": self._foreground,
                "scope": self._scope,
                "age_s": round(age, 2),
            }


_WATCHER = None
_WATCHER_LOCK = threading.RLock()


def _watcher():
    global _WATCHER
    with _WATCHER_LOCK:
        if _WATCHER is None:
            _WATCHER = ScreenWatcher()
        return _WATCHER


def start_watching(scope=None, fps=None, on_update=None):
    return _watcher().start(scope=scope, fps=fps, on_update=on_update)


def stop_watching():
    return _watcher().stop()


def watch_status():
    return _watcher().status()


def latest_frame(max_age=5.0):
    return _watcher().latest(max_age=max_age)


def _send_wheel(clicks: int) -> bool:
    """Modern SendInput wheel event. True when Windows accepted it.

    pyautogui's scroll() uses the legacy mouse_event API, which WinUI/XAML apps
    (the new Notepad, Chrome, Edge) silently ignore - the page just sits there.
    SendInput is the input path those apps actually honour.
    """
    if os.name != "nt":
        return False
    try:
        import ctypes
        from ctypes import wintypes

        class _MOUSEINPUT(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                        ("mouseData", wintypes.DWORD),
                        ("dwFlags", wintypes.DWORD),
                        ("time", wintypes.DWORD),
                        ("dwExtraInfo", ctypes.c_void_p)]

        class _INPUTUNION(ctypes.Union):
            _fields_ = [("mi", _MOUSEINPUT)]

        class _INPUT(ctypes.Structure):
            _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]

        sent = 0
        for _ in range(max(1, abs(int(clicks)))):
            inp = _INPUT()
            inp.type = 0                                  # INPUT_MOUSE
            inp.u.mi = _MOUSEINPUT(0, 0, 120 if clicks > 0 else -120,
                                   0x0800, 0, None)       # MOUSEEVENTF_WHEEL
            sent += int(ctypes.windll.user32.SendInput(
                1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) or 0)
            time.sleep(0.02)
        return sent > 0
    except Exception:
        return False


def _exec_scroll(amount):
    """Scroll, and prove it moved - wheel first, keyboard paging as fallback.

    Verified on this machine: a wheel event, legacy or SendInput, does not move
    the new Notepad at all, while a page key does. So the wheel is only claimed
    as success when the focused window's pixels actually changed.
    """
    import pyautogui
    pyautogui.FAILSAFE = True
    amount = max(-15, min(15, int(amount)))
    rect = _foreground_rect()
    before = _screen_signature(rect)
    _send_wheel(amount)
    time.sleep(0.35)
    after = _screen_signature(rect)
    if _signature_moved(before, after):
        return "scrolled %d (wheel)." % amount
    # Wheel was ignored (or there is nothing to scroll). Page with the keyboard
    # - honoured everywhere - and only then claim the scroll happened.
    _exec_press("pagedown" if amount < 0 else "pageup")
    time.sleep(0.35)
    moved = _screen_signature(rect)
    if _signature_moved(after, moved):
        return ("scrolled %d (this window ignores the wheel, used page keys)."
                % amount)
    return ("Sir, scroll nahi hua (%d) - is window me abhi scrollne ko kuch "
            "nahi bacha (top ya bottom pe hai)." % amount)


def _exec_type(text):
    """Unicode-safe typing: clipboard + paste (pyautogui.write ASCII only)."""
    try:
        import pyperclip
        pyperclip.copy(str(text))
    except Exception:
        return "Sir, typing unavailable (clipboard access nahi mila)."
    try:
        import pyautogui
        old_failsafe = pyautogui.FAILSAFE
        pyautogui.FAILSAFE = False
        try:
            pyautogui.hotkey("ctrlleft", "v")
        finally:
            pyautogui.FAILSAFE = old_failsafe
        return "typed: %r" % str(text)[:60]
    except Exception as exc:
        return "Sir, typing failed: %s" % exc


def _exec_press(key):
    import pyautogui
    key = str(key).strip().lower()
    if key not in _ALLOWED_SINGLE:
        return "Sir, %r key allowlisted nahi hai." % key
    try:
        old_failsafe = pyautogui.FAILSAFE
        pyautogui.FAILSAFE = False
        try:
            pyautogui.press(key)
        finally:
            pyautogui.FAILSAFE = old_failsafe
        return "pressed %s." % key
    except Exception as exc:
        return "Sir, press failed: %s" % exc


def _norm_modifiers(keys):
    """Map pyautogui's short modifier names onto the allowlisted left/right ones.

    "ctrl", "alt", "shift" and "win" are perfectly valid pyautogui key names but
    they were NOT in _ALLOWED_KEYS, so _exec_hotkey(["ctrl", "a"]) returned a
    refusal string and the caller (which mostly reports, not checks) carried on
    as if the select-all had happened. Ctrl+A silently never fired.
    """
    out = []
    for k in keys:
        name = str(k).strip().lower()
        out.append(_MODIFIER_ALIASES.get(name, name))
    return out


# A modifier + one ordinary character is the other half of real keyboard work
# (ctrl+a, ctrl+s, alt+f). Bare letters are still NOT single-press allowlisted:
# this only widens COMBINATIONS, so a stray "a" can never be typed as a key.
_KEY_CHAR_RE = re.compile(r"^[a-z0-9]$")


def _hotkey_key_allowed(key: str) -> bool:
    return key in _ALLOWED_KEYS or bool(_KEY_CHAR_RE.match(key))


def _exec_hotkey(keys):
    import pyautogui
    norm = _norm_modifiers(keys)
    if not norm or len(norm) > 4 or any(not _hotkey_key_allowed(k) for k in norm):
        return "Sir, ye hotkey combination allowlisted nahi hai."
    try:
        old_failsafe = pyautogui.FAILSAFE
        pyautogui.FAILSAFE = False
        try:
            pyautogui.hotkey(*norm)
        finally:
            pyautogui.FAILSAFE = old_failsafe
        return "hotkey %s." % "+".join(norm)
    except Exception as exc:
        return "Sir, hotkey failed: %s" % exc


def click_target(target, ui=None, lang="en", kind="click"):
    """'click on X' -> ground the element -> click. (simple, 1 step)"""
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    b64 = _capture_screen_png_b64()
    if not b64:
        return "Sir, screenshot capture nahi ho paya."
    hit = _ground_target(b64, target)
    if not hit:
        return "Sir, %r screen pe nahi mila." % target[:60]
    x, y, label = hit
    return _exec_click(x, y, kind) + " (%s)" % label[:40]


def has_pending():
    """True when SOMEONE is waiting for the user's "confirm".

    _GUI_PENDING belongs here too: a cortex gui click/type stages itself and
    waits for a spoken "confirm". Leaving it out meant that staged click could
    only ever be flushed by an identical tool re-invocation - the voice confirm
    route reported "koi pending task nahi hai" while a click sat armed.
    """
    return (_PENDING is not None or _PENDING_CLOSE is not None
            or _GUI_PENDING is not None)


def stage_task(task, prompt=None):
    """Pre-compose screen task stage karo; VLM/pyautogui sirf confirm ke baad.

    WhatsApp-send jaise outward actions pehle echoed confirmation maangte
    hain (user ko pata hai exactly kya type hoga) — koi bhi screenshot,
    grounding ya keystroke confirm_pending() se PEHLE nahi hota.
    """
    global _PENDING
    task = str(task or "").strip()[:300]
    if not task:
        return "Sir, kya karna hai?"
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    _PENDING = {"task": task, "at": time.monotonic()}
    return prompt or ('Sir, screen task staged hai: %s. Boliye "confirm" to '
                      "execute karunga." % task[:100])


def cancel_pending():
    """User ne mana kar diya -> staged action discard (TTL se pehle)."""
    global _PENDING, _PENDING_CLOSE, _GUI_PENDING
    had = (_PENDING is not None or _PENDING_CLOSE is not None
           or _GUI_PENDING is not None)
    _PENDING = None
    _PENDING_CLOSE = None
    _GUI_PENDING = None
    if had:
        return "Theek hai Sir, staged task cancel kar diya."
    return "Sir, koi pending task nahi hai."


def move_mouse(x, y):
    if not available():
        return "Sir, screen agent unavailable hai."
    return _exec_move(x, y)


def scroll_screen(amount):
    if not available():
        return "Sir, screen agent unavailable hai."
    return _exec_scroll(amount)


def press_key(key):
    if not available():
        return "Sir, screen agent unavailable hai."
    return _exec_press(key)


_TASK_PROMPT = (
    "You are the actuator of JARVIS, a desktop agent. A screenshot of the "
    "user's screen is provided.\n"
    "TASK: %s\n"
    "ALREADY DONE (step history): %s\n"
    "Decide the NEXT single action needed to complete the task. Respond ONLY "
    "with ONE JSON object, no prose, no markdown fences:\n"
    '{"action":"click","target":"<exact on-screen element text>",'
    '"kind":"click|right|double","reason":"..."}\n'
    '{"action":"move","target":"<element>","reason":"..."}\n'
    '{"action":"scroll","amount":<-15..15>,"reason":"..."}  # negative = down\n'
    '{"action":"type","text":"<what to type>","reason":"..."}\n'
    '{"action":"wait","seconds":<1-5>,"reason":"..."}  '
    '# app window open/load hone do\n'
    '{"action":"press","key":"<one key like enter>","reason":"..."}\n'
    '{"action":"hotkey","keys":["ctrl","s"],"reason":"..."}\n'
    '{"action":"done","message":"<1 short sentence: task result>"}\n'
    '{"action":"impossible","message":"<why>"}\n'
    "Rules: one action per response; prefer done as soon as the visible "
    "screen state matches the task; if the task requires closing, deleting "
    "or anything destructive, respond impossible; if the element is not on "
    "this screen, scroll or press keys to navigate first. "
    "CRITICAL: after clicking an app icon or a Start-menu search result, "
    "the app window takes a few seconds to open - use wait before the next "
    "step. NEVER type while the Start menu or a search box is focused; "
    "type only inside the target application window."
)


def _next_step(b64, task, history):
    raw = _vision_call(b64, _TASK_PROMPT % (task, history or "none"))
    if not raw:
        return None
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


def _execute_step(step, human_gated=False):
    """VLM decision -> grounded pyautogui action. Returns (done, message)."""
    global _PENDING
    if not isinstance(step, dict):
        return True, "Sir, vision ne samajh nahi paya, ruk gaya."
    action = str(step.get("action") or "").lower()
    if action == "done":
        return True, str(step.get("message") or "Task complete, Sir.")
    if action == "impossible":
        return True, "Sir, " + str(step.get("message") or
                                  "ye screen se possible nahi laga.")
    if action == "click":
        target = str(step.get("target") or "").strip()
        if not target:
            return True, "Sir, click target missing tha, ruk gaya."
        b64 = _capture_screen_png_b64()
        if not b64:
            return True, "Sir, screenshot capture nahi ho paya."
        hit = _ground_target(b64, target)
        if not hit:
            return True, "Sir, %r screen pe nahi mila." % target[:60]
        x, y, label = hit
        # HUMAN GATE: click bhi bina confirm ke execute nahi hoga. VLM apne man
        # se click nahi karega — user ko "confirm" bolna hoga.
        if not human_gated:
            _PENDING = {"task": "click %s" % target[:120],
                        "at": time.monotonic()}
            return True, ('Sir, screen pe "%s" pe click karna hai. Boliye '
                          '"confirm" to click karunga.' % target[:60])
        return False, _exec_click(x, y, str(step.get("kind") or "click")) \
            + " (%s)" % label[:40]
    if action == "move":
        target = str(step.get("target") or "").strip()
        if not target:
            return True, "Sir, move target missing tha, ruk gaya."
        b64 = _capture_screen_png_b64()
        if not b64:
            return True, "Sir, screenshot capture nahi ho paya."
        hit = _ground_target(b64, target)
        if not hit:
            return True, "Sir, %r screen pe nahi mila." % target[:60]
        x, y, label = hit
        # HUMAN GATE: move bhi bina confirm ke execute nahi hoga.
        if not human_gated:
            _PENDING = {"task": "move mouse to %s, %s" % (x, y),
                        "at": time.monotonic()}
            return True, ('Sir, mouse ko "%s" (%d, %d) pe lana hai. Boliye '
                          '"confirm" to move karunga.' % (label[:40], x, y))
        return False, _exec_move(x, y) + " (%s)" % label[:40]
    if action == "scroll":
        # HUMAN GATE: scroll bhi bina confirm ke execute nahi hoga.
        if not human_gated:
            _PENDING = {"task": "scroll %d" % (step.get("amount") or -5),
                        "at": time.monotonic()}
            return True, ('Sir, screen scroll karna hai. Boliye "confirm" '
                          'to scroll karunga.')
        return False, _exec_scroll(step.get("amount") or -5)
    if action == "wait":
        try:
            secs = max(1, min(5, int(step.get("seconds") or 2)))
        except (TypeError, ValueError):
            secs = 2
        time.sleep(secs)
        return False, "waited %d second(s)." % secs
    if action == "type":
        text = str(step.get("text") or "")
        if not text:
            return True, "Sir, type karne ko kuch nahi mila, ruk gaya."
        # HUMAN GATE: sirf explicit user-written content (voice write route /
        # dictation continuation) bina confirm ke type hota hai. VLM loop ka
        # apne-man-se-socha "type" KABHI auto-execute nahi hota (Start/Bing
        # me galat typing ka root cause) - pehle user se confirm maango.
        if not human_gated:
            _PENDING = {"task": "type %s" % text[:120],
                        "at": time.monotonic()}
            return True, ('Sir, screen pe type karna hai: "%s". Boliye '
                          '"confirm" to type karunga.' % text[:60])
        # GUARD: target app window focused hona chahiye - warna text Start
        # menu/Bing search bar mein chala jata hai (user-reported bug).
        if _is_shell_title(_foreground_title()):
            if not _app_window_ready(6.0):
                return False, ("app window not focused yet; still on the "
                               "Start menu/search host, waited before typing.")
        return False, _exec_type(text)
    if action == "press":
        if not human_gated:
            _PENDING = {"task": "press %s" % str(step.get("key") or "")[:20],
                        "at": time.monotonic()}
            return True, ('Sir, "%s" key dabana hai. Boliye "confirm" to '
                          "execute karunga." % str(step.get("key") or "")[:20])
        return False, _exec_press(step.get("key") or "")
    if action == "hotkey":
        if not human_gated:
            _PENDING = {"task": "hotkey %s" % "+".join(
                [str(k) for k in (step.get("keys") or [])])[:40],
                "at": time.monotonic()}
            return True, ('Sir, hotkey dabana hai. Boliye "confirm" to '
                          "execute karunga.")
        return False, _exec_hotkey(step.get("keys") or [])
    return True, "Sir, unknown action %r tha, ruk gaya." % action


def _run_steps(task, confirmed_gated=False):
    """Grounded perceive->act loop. Returns final spoken message."""
    history = []
    max_steps = int(os.environ.get("JARVIS_SCREEN_AGENT_STEPS", str(_MAX_STEPS)))
    for i in range(max_steps):
        b64 = _capture_screen_png_b64()
        if not b64:
            return "Sir, screenshot capture nahi ho paya."
        step = _next_step(b64, task, "; ".join(history))
        done, message = _execute_step(step, human_gated=confirmed_gated)
        history.append(message)
        if done:
            return message
        # App-window-open ke baad lamba settle (warna agla screenshot abhi
        # bhi Start menu dikhata hai -> VLM search bar mein type kar deta hai).
        msg_low = message.lower()
        if ("clicked" in msg_low or "pressed" in msg_low
                or "hotkey" in msg_low or "launched" in msg_low):
            _app_window_ready(4.0)   # app open/load hone do
            time.sleep(0.4)
        else:
            time.sleep(0.7)          # normal settle before next capture
    return ("Sir, %d steps mein task poora nahi hua. "
            "Thoda simplify karke bolo." % max_steps)


def _wait_shell_focus(timeout=3.0):
    """Win-menu/search host focus hone ka wait. Typing se PEHLE zaroori -
    warna keystrokes kisi aur window mein chale jaate hain."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        t = _foreground_title()
        if t and _is_shell_title(t):
            return True
        time.sleep(0.2)
    return False


def _is_browser_title(title):
    low = (title or "").lower()
    return ("bing" in low or "google chrome" in low
            or "microsoft edge" in low or "mozilla firefox" in low
            or "brave" in low)


def _index_launch(app):
    """Installed-app index (Start Menu/App Paths/Store) se launch attempt.

    The bridge allowlist is a fixed ~20-name table; this is the real, machine
    discovered fallback. Only index rows can launch, never the spoken words.
    """
    name = "jarvis_app_index"
    mod = sys.modules.get(name)
    if mod is None:
        try:
            import importlib.util
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "app_index.py")
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules[name] = mod
            spec.loader.exec_module(mod)
        except Exception:
            return None
    try:
        handled, message, _row = mod.launch_name(str(app or ""))
    except Exception:
        return None
    if not handled:
        return None
    # Dispatch is not delivery. os_launch_app learned this the hard way; the
    # voice path used to say "launch ho gaya" for an app that never opened.
    # Single-instance apps (Notepad, Excel) reuse an existing window, so an
    # already-open window counts as success too.
    needle = str((_row or {}).get("name") or app or "").strip()
    title = ""
    try:
        title = mod.window_appeared(needle, str(app or ""), timeout_s=4.0)
    except Exception:
        title = ""
    if title:
        return "%s (%s)" % (message, title[:50])
    return ("Sir, '%s' launch command chala hai par 4 second me koi window nahi "
            "dikhi. App slow hone se aisa hota hai - thodi der baad dobara "
            "dekhiye, ya use khud khol lein." % str(app or "")[:40])


def _unknown_app_message(app):
    """Fail closed for unknown app launches - but try the real app index first.

    Start-menu typing used to turn misheard speech into Bing searches and was
    the source of runaway browser tabs.  App launches now have two safe paths:
    the loopback bridge's fixed executable/URI allowlist, and the read-only
    installed-app index (argument-free launch from a discovered shortcut).
    """
    launched = _index_launch(app)
    if launched:
        return launched
    return ("Sir, '%s' approved local app list aur installed-app index dono mein "
            "nahi mila. Exact naam boliye; main isse search bar mein type nahi "
            "karunga." % str(app or "app")[:40])


# "open notepad and write X" / "notepad and write X" -> app + instruction.
# Split miss hone par poora vakya Start search mein type ho jata tha aur Bing
# khul jata tha (user-reported: "notepad and write 20 line essay on ...").
_APP_TOKEN = r"[a-z0-9][\w.+#&'\-]{0,20}(?:\s+[a-z0-9][\w.+#&'\-]{0,20})?"
_WRITE_CLAUSE = (r"\s+(?:and|aur|then|fir|phir|usme|us\s+mein|ke\s+baad)\s+"
                 r"(?:usme|us\s+mein|isme|ismein|is\s+mein|us\s+me|mein)?\s*"
                 r"(?:write|type|likho|likh|likhna|likhiye|likh\s+do)\b\s*:?\s*")
_SPLIT_APP_RE = re.compile(
    r"^\s*(?:please\s+)?(?:(?:open|launch|kholo|khol|chalao|chalu|start)\s+)?"
    r"(?:the\s+|ek\s+)?"
    r"(?P<app>(?!(?:write|type|likho|likh|essay|nibandh|paragraph|para|poem|"
    r"note|letter|story|summary|search|khoj|code|program|software|script|"
    r"function|website|calculator|game|content|article|blog)\b)" + _APP_TOKEN + r")"
    + _WRITE_CLAUSE + r"(?P<text>.*)$", re.I)


def _split_app_and_text(value):
    """'notepad and write hello' -> ('notepad', 'hello').

    Returns (None, None) jab koi writing clause nahi mila. Isse app naam aur
    instruction kabhi mix nahi hote (warna Start search Bing ban jata hai).
    """
    m = _SPLIT_APP_RE.match(str(value or ""))
    if not m:
        return None, None
    app = m.group("app").strip(" ,.")
    # "notepad kholo aur likho ..." -> app "notepad kholo" nahi hona chahiye.
    app = re.sub(r"\s+(?:kholo|khol|kholna|open|launch|chalao|chalu|start)\s*$",
                 "", app, flags=re.I).strip(" ,.")
    if not app:
        return None, None
    return app, m.group("text").strip()


# --------------------------------------------------------------------------
# App-name sanitizer + DIRECT (bridge) launch - requirement: "opening local
# applications must bypass keyboard typing in search bars and use direct
# system calls". Bridge pehle allowlisted exe (spawn shell:false) / fixed
# Windows URI / Start-apps scan (PowerShell) try karta hai, isliye notepad
# jaise apps Start search mein type hone hi nahi chahiye.
# --------------------------------------------------------------------------
_APP_JUNK_WORDS = frozenset((
    "jarvis", "jarvish", "jervis", "javis", "javes", "jarves", "jarbis",
    "jervus", "jaarvis", "jarviz", "zirvis", "darvish", "jrravis", "bro",
    "bhai", "bhaiya", "hey", "hello", "hallo", "halo", "helo", "please",
    "guys", "dad", "jemines", "jamines", "gemines",
    "जार्विस", "जारविस", "जर्विस", "भाई", "हे", "हेलो", "नमस्ते",
    "ジャービス", "ジャーヴィス", "جارویس", "برو", "بھائی",
))
_APP_VERB_WORDS = frozenset((
    "open", "launch", "start", "run", "kholo", "khol", "chalao", "chalu",
    "shuru", "press", "click", "type", "write", "likho", "likh", "dabao",
    "karo", "kardo", "do", "ko", "करो", "खोलो", "खोल", "開いて", "開く",
))


def _clean_app_name(value):
    """Concatenated voice junk -> ek chhota, safe app naam (ya '').

    "Notepad, Zirvis, press open Notepad..." -> "Notepad".
    Kabhi bhi poora vakya Start search mein type nahi hota: 3 words se zyada
    naam reject ho jata hai (warna Windows Search Bing/Edge khol deta hai).
    """
    text = str(value or "").strip()
    if not text:
        return ""
    # Sirf pehla clause (sentence) rakho - STT loops aage junk jodte hain.
    text = re.split(r"[.!?\u0964\u0965؟]", text)[0]
    parts = []
    for chunk in re.split(r"[,\u060c;]+", text):
        words = [w for w in re.split(r"\s+", chunk.strip()) if w]
        kept = []
        for w in words:
            core = w.strip(" .,!:;'\"()[]").lower()
            if core in _APP_JUNK_WORDS or core in _APP_VERB_WORDS:
                continue
            kept.append(w)
        if kept:
            parts.append(" ".join(kept))
    if not parts:
        return ""
    name = parts[0].strip(" .,-")
    if not name or len(name) > 40 or len(name.split()) > 3:
        return ""
    return name


def _bridge_launch(app):
    """Canonical bridge se direct OS launch. None = bridge ne handle nahi kiya."""
    app = str(app or "").strip()
    if not app:
        return None
    host = os.environ.get("JARVIS_BRIDGE_HOST", "127.0.0.1")
    port = os.environ.get("JARVIS_BRIDGE_PORT", "7778")
    try:
        r = requests.post("http://%s:%s/api/action" % (host, port),
                          json={"command": "open " + app}, timeout=8)
        if r.status_code >= 400:
            return None
        data = r.json()
        if data.get("handled"):
            return data.get("message") or ("Sir, '%s' khul gaya." % app)
    except Exception:
        return None
    return None


def launch_app(app):
    """App launch through the direct bridge only; never type into Start search."""
    raw = str(app or "").strip()
    if not raw:
        return "Sir, app ka naam boliye."
    # Defence in depth: agar poora sentence aaya hai to pehle app + instruction
    # split karo, announcement text Start search mein kabhi na jaye.
    name_only, text = _split_app_and_text(raw)
    if name_only:
        return screen_task("open %s and write" % name_only, None, "en", False,
                           text)
    clean = _clean_app_name(raw)
    if not clean:
        return ("Sir, app ka naam clear nahi tha - kripya sirf app ka naam "
                "boliye, jaise 'open notepad'.")
    direct = _bridge_launch(clean)
    if direct:
        return direct
    return _unknown_app_message(clean)


def launch_local(app):
    """Deterministic direct launch (no pyautogui, no typing).

    Returns a spoken message when handled, else None. voice_engine ise
    bridge-offline fallback ke liye use karta hai.
    """
    clean = _clean_app_name(app)
    if not clean:
        return None
    return _bridge_launch(clean)


# --------------------------------------------------------------------------
# Close window: title match -> WM_CLOSE. Destructive, so confirm pehle.
# ctypes only: koi shell, koi executable, koi filesystem path (AGENTS.md).
# --------------------------------------------------------------------------
_WM_CLOSE = 0x0010
# A window that is still open after WM_CLOSE and is asking the user a question.
_SAVE_PROMPT_RE = re.compile(
    r"save\s*as|do you want to save|unsaved|save changes|not responding",
    re.I)


def _prompt_dialog_open(app_hwnd=0) -> bool:
    """True when a modal save/confirm dialog is sitting on screen.

    Two ways to spot it: a title that reads like a prompt ("Save As", "Do you
    want to save"), or the standard Win32 dialog class (#32770) belonging to
    the app we just told to close. The new Notepad titles its dialog plain
    "Notepad", so the class check is what actually catches it.
    """
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        app_pid = 0
        if app_hwnd:
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(app_hwnd, ctypes.byref(pid))
            app_pid = int(pid.value or 0)
        found = []

        def _same_app(h):
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(h, ctypes.byref(pid))
            return int(pid.value or 0) == app_pid

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def _cb(h, _l):
            if not user32.IsWindowVisible(h):
                return True
            n = user32.GetWindowTextLengthW(h)
            title = ""
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(h, buf, n + 1)
                title = (buf.value or "").strip()
            if title and _SAVE_PROMPT_RE.search(_strip_invisible(title)):
                found.append(title)
                return True
            if app_pid and _same_app(h):
                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(h, cls, 64)
                if (cls.value or "") == "#32770":      # standard modal dialog
                    found.append(title or cls.value)
            return True

        user32.EnumWindows(_cb, 0)
        return bool(found)
    except Exception:
        return False
_VAGUE_TARGETS = re.compile(
    r"^(?:it|this|that|ye|yeh|yehi|isko|ise|window|app|application|tab|"
    r"current\s+window|ye\s+window|is\s+window)$", re.I)
_PENDING_CLOSE = None

# --- SAFETY: windows JARVIS kabhi band nahi karega ------------------------
# Yahan ek asli bug tha: repo folder ka naam "jarvis 1.0.5" hai, isliye user
# ke IDE window ka title "... - jarvis 1.0.5 - Antigravity IDE" mein "jarvis"
# match ho jata tha aur "close jarvis" ne IDE ko WM_CLOSE bhej diya tha.
# Ab process-name based protection hai: editor/IDE, shell hosts, JARVIS ka
# apna dashboard/HUD, aur apna runtime — sab protected.
_PROTECTED_PROCS = {
    # Editors / IDEs (in windows often show this repo path).
    "antigravity ide.exe", "antigravity.exe", "code.exe",
    "code - insiders.exe", "cursor.exe", "windsurf.exe", "devenv.exe",
    "pycharm64.exe", "pycharm.exe", "goland64.exe", "webstorm64.exe",
    "idea64.exe", "sublime_text.exe", "zed.exe", "trae.exe",
    # JARVIS runtime + HUD + terminals that host it.
    "pythonw.exe", "python.exe", "node.exe", "pm2.exe",
    "windowsterminal.exe", "wt.exe", "powershell.exe", "pwsh.exe",
    "cmd.exe", "conhost.exe", "opencode.exe", "codex.exe",
    # The machine actually runs these editors - a list that misses the real one
    # is worse than no list, because "close Qoder" closed the user's IDE.
    "qoder.exe", "kiro.exe", "augment.exe", "void.exe", "positron.exe",
    "zed.exe", "sublime_text.exe", "notepad++.exe", "dev-c++.exe",
    "rider64.exe", "clion64.exe", "datagrip64.exe", "rubymine64.exe",
    "android studio.exe", "studio64.exe", "devenv.exe", "brackets.exe",
    "atom.exe", "emacs.exe", "nvim.exe", "vim.exe", "helix.exe",
}
# Family patterns, so the next editor the user installs is protected too.
_PROTECTED_PROC_PATTERNS = re.compile(
    r"^(?:.*[-_. ])?(?:code|qoder|kiro|trae|windsurf|cursor|zed|idea|"
    r"pycharm|goland|webstorm|rider|clion|datagrip|studio|idea|"
    r"eclipse|netbeans|sublime|atom|brackets|dev|antigravity|augment|"
    r"opencode|codex|windsurf|chatgpt|claude|cursor)"
    r"(?:[-_. ]?insiders)?\.exe$", re.I)
_PROTECTED_TITLE_RE = re.compile(
    # Service windows only: dashboard/HUD/state server, plus the browser window
    # that hosts the dashboard ("JARVIS — AI Command Center - Google Chrome").
    # Bare "jarvis" kaafi nahi tha — usse user ki apni file/Notepad doc bhi
    # "protected" ban jati thi (repo folder ka naam hi "jarvis 1.0.5" hai).
    r"(?:127\.0\.0\.1:7777|localhost:7777|floating_ui|screen_agent\.py"
    r"|(?:jarvis|jervis|jarviz)\b[^|]*?(?:command\s+center|dashboard|"
    r"\bhud\b|control\s+panel|reactor|orb\b)"
    r"|(?:command\s+center|dashboard|\bhud\b)[^|]*?(?:jarvis|jervis|jarviz))",
    re.I)
_REFUSE_MSG = ("Sir, '%s' JARVIS ka apna window ya aapka code editor hai — "
               "usse main band nahi karunga. Kisi aur app ka naam boliye.")


def _wm_close(hwnd):
    """PostMessageW(WM_CLOSE) with correct 64-bit handle types."""
    import ctypes
    from ctypes import wintypes
    fn = ctypes.windll.user32.PostMessageW
    fn.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                   wintypes.LPARAM]
    fn.restype = wintypes.BOOL
    return bool(fn(hwnd, _WM_CLOSE, 0, 0))


def _window_process_name(hwnd):
    """hwnd -> lower-case exe name ('' agar query fail ho). ctypes only."""
    import ctypes
    from ctypes import wintypes
    try:
        k32 = ctypes.windll.kernel32
        pid = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd,
                                                     ctypes.byref(pid))
        if not pid.value:
            return ""
        h = k32.OpenProcess(0x1000, False, pid.value)  # QUERY_LIMITED_INFO
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(512)
            size = wintypes.DWORD(512)
            if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return (buf.value or "").rsplit("\\", 1)[-1].strip().lower()
        finally:
            k32.CloseHandle(h)
    except Exception:
        pass
    return ""


def _protected_reason(hwnd, title):
    """'' = band kar sakte hain; warna protection reason (never close)."""
    proc = _window_process_name(hwnd) if hwnd else ""
    if proc in _PROTECTED_PROCS or (proc and _PROTECTED_PROC_PATTERNS.match(proc)):
        return "process:" + proc
    if _PROTECTED_TITLE_RE.search(title or ""):
        return "title"
    return ""


_INVISIBLE_RE = re.compile(r"[\u200b\u200c\u200d\ufeff\u00ad\u2060]")


def _strip_invisible(text):
    """Drop zero-width / soft-hyphen marks that break title matching.

    'New tab - Personal - Microsoft\\u200b Edge' has an invisible U+200B in the
    middle, so a plain 'microsoft edge' substring never matched and Edge could
    be launched but never found again.
    """
    return _INVISIBLE_RE.sub("", str(text or ""))


def _title_hits(title, needle):
    """Word-boundary title match, ignoring invisible unicode marks.

    Substring match ek live bug tha: needle "code" ne "DreamCode JP - YouTube -
    Google Chrome" ko match kar liya aur wo window band ho gayi. Ab needle ko
    word boundary pe hi match karte hain ("code" != "DreamCode").
    Edge ka title me bhi ek invisible U+200B hota hai ("Microsoft\u200b Edge"),
    jise bina normalize kiye "microsoft edge" kabhi match hi nahi hota.
    """
    low = _strip_invisible(title).lower()
    needle = _strip_invisible(needle).strip().lower()
    if not low or not needle:
        return False
    body = re.escape(needle).replace(r"\ ", r"[\s\-_]+")
    return re.search(r"(?<![a-z0-9])" + body + r"(?![a-z0-9])", low) is not None


def _find_window(name):
    """Visible top-level window jiska title `name` ko contain kare.

    Returns (hwnd, title, blocked_title). `blocked_title` non-empty hone ka
    matlab: match mila but wo protected window hai (aapka IDE / JARVIS ka
    dashboard) — aise window ko kabhi close nahi karna.
    """
    import ctypes
    from ctypes import wintypes
    needle = str(name or "").strip().lower()
    if not needle:
        return None, "", ""
    try:
        user32 = ctypes.windll.user32
    except Exception:
        return None, "", ""
    hits, blocked = [], []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = (buf.value or "").strip()
            if _is_shell_title(title):
                return True
            if _title_hits(title, needle):
                if _protected_reason(hwnd, title):
                    blocked.append(title)
                    return True        # safe match dhoondte raho
                hits.append((hwnd, title))
                return False
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(_cb, 0)
    except Exception:
        return None, "", ""
    if hits:
        return hits[0][0], hits[0][1], ""
    return None, "", (blocked[0] if blocked else "")


def close_app(name, force=False):
    """Khuli window band karo. Pehli baar spoken confirmation maangta hai."""
    global _PENDING_CLOSE
    if not available():
        return "Sir, screen agent unavailable hai."
    name = str(name or "").strip()[:60]
    if not name:
        return "Sir, kaunsi window band karni hai?"
    if _VAGUE_TARGETS.match(name):
        hwnd = _foreground_hwnd()
        title = _foreground_title()
        if not hwnd or not title or _is_shell_title(title):
            return ("Sir, koi active app window nahi mili. Naam boliye, "
                    "jaise \"close notepad\".")
        if _protected_reason(hwnd, title):
            _PENDING_CLOSE = None
            return _REFUSE_MSG % title[:40]
        name = title
    # Protected target pe confirm maangna bekaar -> seedha refuse.
    _, _, blocked_now = _find_window(name)
    if blocked_now:
        _PENDING_CLOSE = None
        return _REFUSE_MSG % blocked_now[:40]
    if not force:
        _PENDING_CLOSE = {"app": name, "at": time.monotonic()}
        return ('Sir, "%s" band karna hai? Boliye "confirm" to band kar dunga.'
                % name[:50])
    hwnd, title, blocked = _find_window(name)
    if not hwnd:
        _PENDING_CLOSE = None
        if blocked:
            return _REFUSE_MSG % blocked[:40]
        return ("Sir, '%s' naam ki koi khuli window nahi mili. Taskbar pe naam "
                "dekh ke boliye." % name[:50])
    if _protected_reason(hwnd, title):          # belt-and-braces re-check
        _PENDING_CLOSE = None
        return _REFUSE_MSG % title[:40]
    _wm_close(hwnd)
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        if _find_window(name)[0] is None:
            return "Sir, '%s' band ho gaya." % title[:50]
        if _prompt_dialog_open(hwnd):
            return ("Sir, '%s' ne save/confirm ka dialog khol diya hai - "
                    "unsaved changes hain. Save karke boliye, phir main "
                    "dobara band kar dunga." % title[:45])
        time.sleep(0.25)
    return ("Sir, '%s' ko close signal bhej diya. Agar usme unsaved changes "
            "hain to app apna save dialog dikha raha hoga." % title[:50])


def screen_task(task, ui=None, lang="en", confirmed=False, write_text=None):
    """Entry point. Destructive tasks need spoken confirmation first.

    `write_text` optional hai: lamba content (jaise generated essay) yahan se
    aata hai, kyunki `task` 300 chars pe cap hota hai.
    """
    global _PENDING
    task = str(task or "").strip()[:300]
    if not task:
        return "Sir, boliye screen pe kya karna hai?"
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    destructive = bool(re.search(
        r"\b(close|quit|exit|delete|remove|uninstall|shutdown|restart|format|"
        r"\bkill|end task|empty(?:\s+the)?\s+(?:recycle|trash)|band\s+karo)\b",
        task, re.I))
    if destructive and not confirmed:
        _PENDING = {"task": task, "at": time.monotonic()}
        return ('Sir, "%s" destructive action hai. Boliye "confirm" to '
                "execute karunga." % task[:80])
    # "open X" / "open X and write Y" -> deterministic launch (VLM ke bharose
    # nahi), warna Start search hi Bing web search ban jata hai (user-reported).
    m = re.match(r'^(?:open|launch|kholo?|chalao|start|run)\s+(.+)$', task, re.I)
    if m:
        rest_txt = m.group(1).strip()
        name_only, split_text = _split_app_and_text(rest_txt)
        app = _clean_app_name(name_only or rest_txt)
        if not app:
            # Concatenated junk ("Notepad, Zirvis, press open Notepad...") -
            # Start search mein kabhi type nahi karte (Bing/Edge loop).
            return ("Sir, app ka naam clear nahi tha - kripya sirf app ka naam "
                    "boliye, jaise 'open notepad'.")
        body = write_text if write_text is not None else split_text
        # DIRECT launch only (bridge allowlisted exe/URI).  Unknown apps fail
        # closed; speech is never typed into the Windows Start search.
        direct = _bridge_launch(app)
        if body:
            if direct:
                msg = direct
                time.sleep(1.2)          # app window load hone do
                hwnd, win_title, _ = _find_window(app)
                if hwnd:
                    # Force the raise, not just ShowWindow: without the input
                    # queue attach Windows keeps the old foreground and the text
                    # below would be typed into whatever the user was using.
                    _force_foreground(hwnd)
                time.sleep(0.5)          # caret ready hone do
            else:
                return _unknown_app_message(app)
            # Direct type into the application
            typed = _exec_type(body)
            try:
                import pyautogui
                pyautogui.press('enter')
            except Exception:
                pass
            return msg + " " + typed
        if direct:
            return direct
        return _unknown_app_message(app)
    return _run_steps(task)


def confirm_pending():
    """User ne 'confirm' bola -> the MOST RECENT staged action chalao.

    Three independent things can be armed at once (a screen task, a window
    close, a cortex gui click/type), so the newest one is the one the user is
    answering for. Each keeps the same 120s single-use TTL: an approval can
    never be replayed later for a stale staged action.
    """
    global _PENDING, _PENDING_CLOSE, _GUI_PENDING
    armed = [(kind, item) for kind, item in
             (("screen", _PENDING), ("close", _PENDING_CLOSE),
              ("gui", _GUI_PENDING)) if item is not None]
    if not armed:
        return "Sir, koi pending task nahi hai."
    kind, item = max(armed, key=lambda pair: float(pair[1].get("at") or 0.0))
    if time.monotonic() - float(item.get("at") or 0.0) > _CONFIRM_TTL:
        if kind == "gui":
            _GUI_PENDING = None
        elif kind == "close":
            _PENDING_CLOSE = None
        else:
            _PENDING = None
        return "Sir, pending action expire ho gaya. Dobara boliye."
    if kind == "gui":
        return confirm_gui()
    if kind == "close":
        _PENDING_CLOSE = None
        return close_app(item["app"], force=True)
    _PENDING = None
    return _run_steps(item["task"], confirmed_gated=True)


# -----------------------------------------------------------------------------
# desktop GUI control: locate / type / read region (confirm-gated)
# -----------------------------------------------------------------------------
_GUI_PENDING = None   # {"element", "kind", "x", "y", "text", "at"}


def _ground_component(part):
    """Ground a UI part on the live desktop; returns (x, y, label) or None."""
    b64 = _capture_screen_png_b64()
    if not b64:
        return None
    return _ground_target(b64, part)


def gui_locate_and_click(args):
    """Stage (no click) or execute a coordinate click on the live desktop.

    CONFIRM-GATED (cortex). Stage first call: ground the element, report the
    exact pixel coordinates + label, and wait for 'confirm'. On the confirmed
    re-invocation (same tool + same args), re-ground the element and click.
    """
    global _GUI_PENDING
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    element_description = str(args.get("element_description") or "").strip()
    if not element_description:
        return "Sir, kya click karna hai (element description) boliye."
    kind = str(args.get("kind") or "click").strip().lower()
    if kind not in ("click", "right", "double"):
        kind = "click"
    hit = _ground_component(element_description)
    if not hit:
        return ("Sir, '%s' screen pe nahi mila. Agar woh alag jagah pe "
                "hai toh phir se boliye, ya x,y coordinates do."
                % element_description)
    x, y, label = hit
    if (_GUI_PENDING is not None
            and _GUI_PENDING.get("element") == element_description
            and _GUI_PENDING.get("kind") == kind):
        # Gate cleared -> execute the staged click.
        _GUI_PENDING = None
        return _exec_click(x, y, kind) + " (%s)" % label[:40]
    _GUI_PENDING = {"element": element_description, "kind": kind,
                    "x": x, "y": y, "at": time.monotonic()}
    return ("Sir, '%s' ko (%d, %d) par click karna hai. "
            "Boliye \"confirm\" to execute karunga."
            % (label[:40], x, y))

def gui_type_into(args):
    """Type text into the on-screen field the VLM grounds by name.

    CONFIRM-GATED (cortex). Stage first call: it reports the grounded field
    coordinates and waits for 'confirm'. On the confirmed re-invocation, the
    field is re-grounded, the foreground window is verified (Start/Bing guard)
    and the text is pasted through the clipboard (unicode-safe path).
    """
    global _GUI_PENDING
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    field_name = str(args.get("field_name") or "").strip()
    if not field_name:
        return ("Sir, field ka naam boliye (jaise 'search', 'address' ya "
                "'message').")
    text = str(args.get("text") or "")
    hit = _ground_component(field_name)
    if not hit:
        return ("Sir, '%s' screen pe nahi mila. Phir se boliye, "
                "ya x,y coordinates do." % field_name)
    x, y, label = hit
    if (_GUI_PENDING is not None
            and _GUI_PENDING.get("element") == field_name
            and _GUI_PENDING.get("kind") == "type"):
        _GUI_PENDING = None
        if _is_shell_title(_foreground_title()):
            if not _app_window_ready(6.0):
                return ("app window focused nahi hai abhi; wait kar raha "
                        "hoon before typing.")
        return _exec_type(text) + " (%s)" % label[:40]
    _GUI_PENDING = {"element": field_name, "kind": "type",
                    "text": text, "x": x, "y": y, "at": time.monotonic()}
    return ("Sir, '%s' (%d, %d) mein type karna hai: %r. "
            "Boliye \"confirm\" to execute karunga."
            % (label[:40], x, y, str(text)[:80]))


def gui_read_screen_region(args):
    """Capture the screen and report the region reference + pixel size.

    READ-ONLY (no confirm required): nothing is clicked, typed, or executed.
    Text transcription is deliberately NOT claimed here - that path needs
    Tesseract, which is not installed on this machine - so this tool always
    reports honestly what it captured instead of faking a transcript.
    """
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    region = str(args.get("region") or "primary").strip()[:24] or "primary"
    b64 = _capture_screen_png_b64()
    if not b64:
        return "Sir, screenshot capture nahi ho paya."
    return ("Sir, region '%s' ka capture hai (full screen). "
            "OCR (text) is not available on this machine "
            "(Tesseract missing) - send this region to a VLM for text if "
            "you need it." % region)

def confirm_gui():
    """Execute a previously staged gui click or type after the user confirmed.

    Re-grounds the element before acting (a moved window is handled safely),
    then clears the pending state. Called by the voice confirm route when the
    speaker approves a staged gui action.
    """
    global _GUI_PENDING
    if _GUI_PENDING is None:
        return "Sir, koi gui action stage nahi hai."
    action = dict(_GUI_PENDING)
    _GUI_PENDING = None
    element, kind = action["element"], action["kind"]
    if kind == "type":
        hit = _ground_component(element)
        if not hit:
            return ("Sir, '%s' screen pe nahi mila, confirm cancel "
                    "ho gaya." % element)
        x, y, label = hit
        if _is_shell_title(_foreground_title()):
            if not _app_window_ready(6.0):
                return "app window focused nahi hai abhi; wait kar raha hoon."
        _exec_type(action["text"])
        return ("Sir, '%s' mein paste kar diya: %r."
                % (label[:40], str(action["text"])[:60]))
    if kind in ("click", "right", "double"):
        hit = _ground_component(element)
        if not hit:
            return ("Sir, '%s' screen pe nahi mila, confirm cancel "
                    "ho gaya." % element)
        x, y, _ = hit
        return _exec_click(x, y, kind) + " (%s)" % element[:40]
    return "Sir, ye gui action execute nahi hoga."


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys as _sys
    name = "jarvis_cowork_cortex"
    existing = _sys.modules.get(name)
    if existing is not None:
        return existing
    from pathlib import Path
    path = Path(__file__).resolve().parent.parent / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    _sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


try:
    cortex = _load_cortex()
except Exception:  # pragma: no cover - cortex must never break boot
    cortex = None


def gui_scroll(args):
    """Scroll the focused window. Delegates to _exec_scroll, which clamps to
    the same +-15 the voice route uses. Reversible and non-destructive, so it
    is not confirm-gated."""
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    direction = str((args or {}).get("direction") or "down").strip().lower()
    if direction not in ("up", "down"):
        return "Sir, scroll direction up ya down honi chahiye."
    try:
        amount = int((args or {}).get("amount") or 5)
    except (TypeError, ValueError):
        return "Sir, scroll amount ek number honi chahiye."
    amount = max(1, min(15, abs(amount)))
    return _exec_scroll(amount if direction == "up" else -amount)


def gui_press_key(args):
    """Press one key. _exec_press refuses anything outside _ALLOWED_SINGLE, so
    the allowlist is the guard rather than a confirm prompt."""
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    key = str((args or {}).get("key") or "").strip().lower()
    if not key:
        return "Sir, kaunsi key press karni hai boliye."
    return _exec_press(key)


def gui_focus_app(args):
    """Bring an already-running app's window to the foreground.

    os_launch_app starts a process but does not raise its window, so a later
    gui_type_into / gui_scroll goes to whatever had focus instead - the step
    reports done while nothing visible happens. This restores + foregrounds
    the window so the following action actually lands on it, and it WAITS: a
    freshly launched app can take seconds to show a window, and the agent loop
    moves on immediately after a launch.
    """
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    app = str((args or {}).get("app") or "").strip()[:60]
    if not app:
        return "Sir, kaunsi window saamne laani hai (app) boliye."
    hwnd, title, _ = _find_window(app)
    if not hwnd:
        deadline = time.monotonic() + 4.0
        while time.monotonic() < deadline:
            time.sleep(0.4)
            hwnd, title, _ = _find_window(app)
            if hwnd:
                break
    if not hwnd:
        return ("Sir, '%s' ki koi khuli window nahi mili (4s me bhi nahi aayi)."
                % app)
    for _ in range(2):
        if _force_foreground(hwnd):
            return "focused %s." % (title or app)
        time.sleep(0.5)
    if _foreground_hwnd() == hwnd:
        return "focused %s." % (title or app)
    return ("Sir, '%s' ki window mili par Windows ne foreground nahi diya - "
            "manually click kar dijiye." % (title or app)[:40])


# Named chords only. A free-form hotkey(args) surface would let a misparsed
# goal press Win+R / Ctrl+Alt+Del and similar, so unknown combinations fail
# closed rather than reaching the keyboard.
_ALLOWED_COMBOS = {
    "ctrl+l": ("ctrl", "l"),          # focus the browser address bar
    "ctrl+t": ("ctrl", "t"),          # new tab
    "ctrl+w": ("ctrl", "w"),          # close tab
    "ctrl+s": ("ctrl", "s"),          # save
    "ctrl+f": ("ctrl", "f"),          # find in page
    "ctrl+enter": ("ctrl", "enter"),
    "alt+tab": ("alt", "tab"),        # switch window
    "ctrl+shift+t": ("ctrl", "shift", "t"),   # reopen last closed tab
    "ctrl+home": ("ctrl", "home"),    # jump to top
    "ctrl+end": ("ctrl", "end"),      # jump to bottom
}


def gui_press_combo(args):
    """Press one allowlisted key combination."""
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    combo = str((args or {}).get("combo") or "").strip().lower().replace(" ", "")
    if combo not in _ALLOWED_COMBOS:
        return ("Sir, '%s' allowlisted combo nahi hai. Allowed: %s"
                % (combo[:24], ", ".join(sorted(_ALLOWED_COMBOS))))
    keys = _ALLOWED_COMBOS[combo]
    try:
        import pyautogui
        old = pyautogui.FAILSAFE
        pyautogui.FAILSAFE = False
        try:
            pyautogui.hotkey(*keys)
        finally:
            pyautogui.FAILSAFE = old
    except Exception as exc:
        return "Sir, combo failed: %s" % type(exc).__name__
    time.sleep(0.35)
    return "pressed %s." % combo


def gui_type_active(args):
    """Type into whatever currently has keyboard focus. No screenshot, no VLM.

    Use this right after gui_press_combo("ctrl+l") or gui_focus_app: the field
    is already focused, so grounding it again with the vision model only adds a
    failure mode - and that is exactly what cost the last run its search.
    """
    if not available():
        return "Sir, screen agent unavailable hai (pyautogui missing)."
    text = str((args or {}).get("text") or "")[:400]
    if not text.strip():
        return "Sir, kya type karna hai (text) boliye."
    out = _exec_type(text)
    if str((args or {}).get("then_enter") or "").lower() in ("true", "1", "yes"):
        _exec_press("enter")
        return "typed and pressed enter. %s" % out
    return out


def specs() -> list:
    """Cortex ToolSpecs for the desktop GUI control surface."""
    if cortex is None:
        return []
    return [
        cortex.ToolSpec(
            "gui_locate_and_click",
            "Locate an element on the live desktop and click it (confirm-gated).",
            gui_locate_and_click,
            parameters={
                "element_description": "what to click, e.g. 'OK button'",
                "kind": "click | right | double",
            },
            requires_confirmation=True,
            timeout_s=30.0,
            tags=("desktop", "gui", "mouse", "click"),
        ),
        cortex.ToolSpec(
            "gui_type_into",
            "Type text into a grounded on-screen field (confirm-gated).",
            gui_type_into,
            parameters={
                "field_name": "field to type into, grounded by its on-screen label",
                "text": "text to paste into the field",
            },
            requires_confirmation=True,
            timeout_s=30.0,
            tags=("desktop", "gui", "type", "keyboard"),
        ),
        cortex.ToolSpec(
            "gui_read_screen_region",
            "Capture the screen and report the region reference + pixel size (read-only, no OCR claim).",
            gui_read_screen_region,
            parameters={"region": "region name (default: primary)"},
            requires_confirmation=True,
            timeout_s=15.0,
            tags=("desktop", "gui", "read", "screen"),
        ),
        cortex.ToolSpec(
            "gui_scroll",
            "Scroll the focused window up or down with the mouse wheel (clamped to 15 clicks).",
            gui_scroll,
            parameters={"direction": "up | down",
                        "amount": "wheel clicks, 1-15 (default 5)"},
            requires_confirmation=True,
            timeout_s=10.0,
            tags=("desktop", "gui", "mouse", "scroll"),
        ),
        cortex.ToolSpec(
            "gui_press_key",
            "Press one allowlisted keyboard key, e.g. enter, tab, escape, down.",
            gui_press_key,
            parameters={"key": "key name from the allowlist"},
            requires_confirmation=True,
            timeout_s=10.0,
            tags=("desktop", "gui", "keyboard", "key"),
        ),
        cortex.ToolSpec(
            "gui_focus_app",
            "Raise an already-running app's window to the foreground so the next click/type/scroll lands on it.",
            gui_focus_app,
            parameters={"app": "running app name, e.g. chrome"},
            requires_confirmation=True,
            timeout_s=10.0,
            tags=("desktop", "gui", "window", "focus"),
        ),
        cortex.ToolSpec(
            "gui_press_combo",
            "Press one allowlisted key combination, e.g. ctrl+l (browser "
            "address bar), ctrl+t (new tab), alt+tab, ctrl+end.",
            gui_press_combo,
            parameters={"combo": "lowercase combo like 'ctrl+l'"},
            requires_confirmation=True,
            timeout_s=10.0,
            tags=("desktop", "gui", "keyboard", "combo"),
        ),
        cortex.ToolSpec(
            "gui_type_active",
            "Type text into the field that ALREADY has keyboard focus - no screenshot, no vision model. Use right after gui_press_combo(ctrl+l).",
            gui_type_active,
            parameters={"text": "text to type",
                        "then_enter": "true to press Enter after typing"},
            requires_confirmation=True,
            timeout_s=20.0,
            tags=("desktop", "gui", "keyboard", "type"),
        ),
    ]
