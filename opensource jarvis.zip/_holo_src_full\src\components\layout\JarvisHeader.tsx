/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Mic,
  Activity,
  Wifi,
  Download,
  CheckCircle,
  Clock,
  Radio,
} from 'lucide-react';
import { SystemTelemetry } from '../../types/jarvis';
import { downloadProjectZip } from '../../services/zipExporter';
import { soundFx } from '../../services/soundEffects';

interface JarvisHeaderProps {
  telemetry: SystemTelemetry;
}

export const JarvisHeader: React.FC<JarvisHeaderProps> = ({ telemetry }) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
      setDateStr(
        now.toLocaleDateString('en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    setDownloadProgress(10);
    soundFx.playSelect();
    try {
      await downloadProjectZip((progress) => setDownloadProgress(progress));
    } catch (e) {
      console.error('ZIP generation failed:', e);
    } finally {
      setTimeout(() => {
        setIsDownloading(false);
        setDownloadProgress(0);
      }, 1000);
    }
  };

  return (
    <header className="h-14 border-b border-cyan-500/20 bg-slate-950/90 backdrop-blur-md px-4 flex items-center justify-between select-none z-30 shrink-0">
      {/* Left: JARVIS Brand & Arc Reactor */}
      <div className="flex items-center gap-3">
        <div className="relative w-8 h-8 rounded-full border border-cyan-400/80 flex items-center justify-center bg-cyan-950/40 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
          <div className="w-5 h-5 rounded-full border border-dashed border-cyan-300 animate-arc-rotate" />
          <div className="absolute w-2 h-2 rounded-full bg-cyan-300 shadow-[0_0_8px_#38bdf8]" />
        </div>

        <div>
          <div className="flex items-baseline gap-2">
            <span className="font-orbitron font-extrabold text-lg text-white tracking-widest text-shadow">
              JARVIS
            </span>
            <span className="text-[10px] font-rajdhani font-semibold text-cyan-400 tracking-wider">
              V1.0.5 / ONLINE
            </span>
          </div>
        </div>
      </div>

      {/* Center Left: Standby Microphone Pill */}
      <div className="hidden xl:flex items-center gap-2.5 px-3 py-1 rounded-full bg-cyan-950/30 border border-cyan-500/30 text-xs font-rajdhani text-cyan-300">
        <div className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-cyan-400">
          <Mic className="w-3 h-3 animate-pulse" />
        </div>
        <div className="flex items-center gap-1.5 text-[11px]">
          <span className="font-semibold tracking-wider text-white">STANDBY...</span>
          <span className="text-cyan-400/80">Background core active — say "Hey JARVIS"</span>
        </div>
      </div>

      {/* Center Right: Real-time System Gauges */}
      <div className="hidden lg:flex items-center gap-5 text-[11px] font-rajdhani">
        {/* CPU */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 font-semibold uppercase">CPU</span>
          <span className="text-cyan-300 font-mono-code font-bold">{telemetry.cpuUsage}%</span>
          <div className="flex gap-0.5">
            {[1, 2, 3, 4, 5].map((seg) => (
              <span
                key={seg}
                className={`w-1.5 h-2.5 rounded-[1px] ${
                  seg <= Math.ceil(telemetry.cpuUsage / 20)
                    ? 'bg-cyan-400 shadow-[0_0_4px_#22d3ee]'
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* RAM */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 font-semibold uppercase">RAM</span>
          <span className="text-cyan-300 font-mono-code font-bold">{telemetry.ramUsage}%</span>
          <div className="flex gap-0.5">
            {[1, 2, 3, 4, 5].map((seg) => (
              <span
                key={seg}
                className={`w-1.5 h-2.5 rounded-[1px] ${
                  seg <= Math.ceil(telemetry.ramUsage / 20)
                    ? 'bg-cyan-400 shadow-[0_0_4px_#22d3ee]'
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* DISK */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 font-semibold uppercase">DISK</span>
          <span className="text-cyan-300 font-mono-code font-bold">{telemetry.diskUsage}%</span>
          <div className="flex gap-0.5">
            {[1, 2, 3, 4, 5].map((seg) => (
              <span
                key={seg}
                className={`w-1.5 h-2.5 rounded-[1px] ${
                  seg <= Math.ceil(telemetry.diskUsage / 20)
                    ? 'bg-cyan-400 shadow-[0_0_4px_#22d3ee]'
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Clock Display */}
      <div className="hidden md:flex flex-col items-center justify-center font-rajdhani leading-none">
        <div className="font-orbitron font-bold text-sm text-cyan-300 tracking-wider">
          {timeStr || '06:16:41 PM'}
        </div>
        <div className="text-[10px] text-slate-400 tracking-wide mt-0.5">
          {dateStr || 'Sun, Oct 12, 2025'}
        </div>
      </div>

      {/* Right: Status Badges & Download ZIP */}
      <div className="flex items-center gap-3">
        {/* HUD Connected */}
        <div className="hidden sm:flex items-center gap-1 text-[11px] font-rajdhani text-emerald-400">
          <span className="w-2 h-2 rounded-full border border-emerald-400 flex items-center justify-center">
            <span className="w-1 h-1 rounded-full bg-emerald-400 animate-ping" />
          </span>
          <span className="text-slate-300">HUD</span> Connected
        </div>

        {/* Windows Bridge */}
        <div className="hidden sm:flex items-center gap-1 text-[11px] font-rajdhani text-cyan-400">
          <Wifi className="w-3 h-3 text-cyan-400" />
          <span className="text-slate-300">Windows Bridge</span> Connected
        </div>

        {/* Standby Indicator */}
        <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-[10px] font-rajdhani text-slate-300">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          Standby
        </div>

        {/* Download Project ZIP Button */}
        <button
          onClick={handleDownloadZip}
          disabled={isDownloading}
          title="Download Complete Project as .ZIP"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-950/80 border border-cyan-400/60 hover:bg-cyan-500/20 text-cyan-300 hover:text-white transition-all text-xs font-rajdhani font-semibold shadow-[0_0_10px_rgba(6,182,212,0.2)]"
        >
          {isDownloading ? (
            <>
              <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span>{downloadProgress}%</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">ZIP</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
