import pathlib, re
p=pathlib.Path("public/static/brain-holo.js")
s=p.read_text(encoding="utf-8")
old="  function whenReady(cb){ if(getThree()) cb(); else window.addEventListener('jarvis:three-ready',cb,{once:true}); }\n  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>whenReady(initIfNeeded),{once:true}); else whenReady(initIfNeeded);"
new="""  function whenReady(cb){ if(getThree()) cb(); else window.addEventListener('jarvis:three-ready',cb,{once:true}); }
  function _boot(){
    try{ whenReady(initIfNeeded); }catch(e){ console.warn('[brain-holo] boot err',e); }
    let _tries=0;
    const _retry=setInterval(()=>{
      _tries++;
      if(initialized){ clearInterval(_retry); return; }
      if(_tries>50){ clearInterval(_retry); console.warn('[brain-holo] retry gave up, status', window.__JARVIS_BRAIN_HOLO__ && window.__JARVIS_BRAIN_HOLO__.status && window.__JARVIS_BRAIN_HOLO__.status()); return; }
      if(getThree() && !initialized){
        try{ initIfNeeded(); }catch(e){ console.warn('[brain-holo] retry err',e); }
        if(initialized) clearInterval(_retry);
      }
    }, 400);
    try{
      const _wrap=document.getElementById('brain-canvas-wrap');
      if(_wrap && 'IntersectionObserver' in window){
        const io=new IntersectionObserver((entries)=>{
          entries.forEach(ent=>{
            if(ent.isIntersecting && ent.intersectionRatio>0.02){
              if(!initialized) try{ initIfNeeded(); }catch{}
              try{
                if(initialized && renderer && camera && ent.target){
                  const rr=ent.target.getBoundingClientRect();
                  if(rr.width>80 && rr.height>80){
                    camera.aspect=rr.width/rr.height; camera.updateProjectionMatrix(); renderer.setSize(rr.width, rr.height, false);
                  }
                }
              }catch{}
            }
          });
        },{threshold:0.02});
        io.observe(_wrap);
      }
    }catch{}
    try{
      document.addEventListener('click', (e)=>{
        const nav=e.target && e.target.closest && e.target.closest('[data-view="brain"]');
        if(nav){
          setTimeout(()=>{ try{ if(!initialized) initIfNeeded(); }catch{} }, 120);
          setTimeout(()=>{ try{ if(renderer&&camera&&wrap){ const r=wrap.getBoundingClientRect(); if(r.width>80){ camera.aspect=r.width/r.height; camera.updateProjectionMatrix(); renderer.setSize(r.width,r.height,false);} } }catch{} }, 400);
        }
      });
    }catch{}
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',_boot,{once:true}); else _boot();"""
if old in s:
    s=s.replace(old,new)
    print("p5 boot patched")
else:
    print("p5 miss")
    # debug
    print("whenReady count", s.count("whenReady"))
    import re
    m=re.search(r"function whenReady.*?whenReady\(initIfNeeded\).*?\)\(\);", s, re.S)
    print(m.group(0)[:500] if m else "no match")
    if m:
        s=s.replace(m.group(0), new + "\n})();")
        print("regex patched boot")
p.write_text(s,encoding="utf-8")
import pathlib as pl
dp=pl.Path("dist/static/brain-holo.js")
if dp.parent.exists(): dp.write_text(s,encoding="utf-8")
print("len",len(s))
