import os, json, time, requests
for line in open(".env", encoding="utf-8"):
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

out = {}

def probe(name, url, headers, payload=None, timeout=25):
    t0 = time.time()
    try:
        if payload is None:
            r = requests.get(url, headers=headers, timeout=timeout)
        else:
            r = requests.post(url, headers=headers, json=payload, timeout=timeout)
        out[name] = {"status": r.status_code, "secs": round(time.time() - t0, 1),
                     "body": r.text[:150].replace("\n", " ")}
    except Exception as e:
        out[name] = {"error": type(e).__name__ + ": " + str(e)[:100]}

# ---- NEW Groq key: models list + tiny chat (primary brain check) ----
gh = {"Authorization": "Bearer " + os.environ.get("GROQ_API_KEY", "")}
probe("groq:models", "https://api.groq.com/openai/v1/models", gh)
probe("groq:chat-primary", "https://api.groq.com/openai/v1/chat/completions", gh,
      {"model": "openai/gpt-oss-120b", "max_tokens": 40,
       "messages": [{"role": "user", "content": "say OK"}]})

# ---- NVIDIA NIM: hunt LIVE FREE models ----
nh = {"Authorization": "Bearer " + os.environ.get("NVIDIA_API_KEY", ""),
      "Accept": "application/json"}
for m in ("deepseek-ai/deepseek-r1", "meta/llama-3.1-8b-instruct",
          "nvidia/llama-3.1-nemotron-70b-instruct", "qwen/qwen3-235b-a22b",
          "meta/llama-3.3-70b-instruct"):
    probe("nvidia:" + m, "https://integrate.api.nvidia.com/v1/chat/completions", nh,
          {"model": m, "max_tokens": 30,
           "messages": [{"role": "user", "content": "say OK"}]})

# ---- OpenRouter: hunt LIVE FREE (:free) models ----
oh = {"Authorization": "Bearer " + os.environ.get("OPENROUTER_API_KEY", ""),
      "HTTP-Referer": "http://127.0.0.1:7777", "X-Title": "JARVIS"}
for m in ("meta-llama/llama-3.3-70b-instruct:free",
          "google/gemma-3-27b-it:free",
          "qwen/qwen3-235b-a22b:free",
          "mistralai/mistral-small-3.2-24b-instruct:free"):
    probe("openrouter:" + m, "https://openrouter.ai/api/v1/chat/completions", oh,
          {"model": m, "max_tokens": 30,
           "messages": [{"role": "user", "content": "say OK"}]})

print(json.dumps(out, indent=1))
