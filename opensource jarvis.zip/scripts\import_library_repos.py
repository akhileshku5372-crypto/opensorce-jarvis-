"""Find GitHub sources the library is allowed to store, and vendor them.

Why this exists: Project Gutenberg's search and gutendex both load their results
with JavaScript on this machine, so the only discovery path that returns real,
machine-checkable licence data here is the GitHub API. A repo is imported ONLY
when its own license endpoint says the licence lets us store the text
(MIT / BSD / Apache-2.0 / CC0-1.0 / CC-BY-4.0 / CC-BY-SA-4.0 / Unlicense).
Anything else stays a LINK card on the shelf - topic and URL, never their prose.

Writes, per repo:  skills/library/vendor/<repo>/{README.md,LICENSE,meta.json}

Run:  python scripts/import_library_repos.py            # discover + import
      python scripts/import_library_repos.py --dry-run   # only print the list
"""
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(ROOT, "skills", "library")
VENDOR = os.path.join(LIB, "vendor")
SOURCES = os.path.join(LIB, "sources.json")

ALLOWED = {"MIT", "BSD-3-Clause", "BSD-2-Clause", "Apache-2.0", "CC0-1.0",
           "CC-BY-4.0", "CC-BY-SA-4.0", "CC-BY-3.0", "Unlicense", "ISC", "Zlib"}
MIN_STARS = 25
MAX_PER_QUERY = 4
# A link card is still a card on his shelf, so the list has to stay readable:
# per-query cap plus a global cap, best-known first. Without this one run logged
# 174 "could not store" entries, including repos that are not study material at
# all, and the shelf would have painted every one of them.
MAX_LINKS_PER_QUERY = 3
MAX_LINKS_TOTAL = 26
# The two lists he pasted himself stay on the shelf whatever their star count is.
OWNER_NAMED = ["ryanburgess/engineer-manager", "linnykoleh/awesome-software-career-guide"]
# The unauthenticated search API allows ~10 requests per minute. Faster than this
# and the run silently loses every query after the tenth, which is how the first
# version "found" only four repos.
SEARCH_PAUSE = 8.0

# Something to read, not a tool to install. A repo only becomes a book when its
# own name or description says it is written material.
RELEVANT = re.compile(
    r"guide|handbook|book|learn|tutorial|walkthrough|awesome|list|roadmap|course|"
    r"curated|skills|interview|design|patterns|best[- ]practices|playbook|manual|"
    r"study|notes|career|communication|productivity|mentoring|writing", re.IGNORECASE)
NOT_A_BOOK = re.compile(r"cli$|^chrome-extension|boilerplate|starter kit|sdk$|^action-|theme$",
                        re.IGNORECASE)

# soft = how to work, talk, think, learn; hard = the craft itself
QUERIES = [
    ("soft", "communication", "topic:communication+topic:soft-skills"),
    ("soft", "career", "topic:career+topic:awesome"),
    ("soft", "interviewing", "topic:interview+topic:career"),
    ("soft", "productivity", "topic:productivity+topic:time-management"),
    ("soft", "learning", "topic:learning+topic:study"),
    ("soft", "writing", "topic:writing+topic:documentation"),
    ("soft", "mentoring", "topic:mentoring+topic:leadership"),
    ("soft", "focus", "topic:habits+topic:productivity"),
    ("soft", "negotiation", "topic:negotiation+topic:sales"),
    ("soft", "thinking", "topic:decision-making+topic:thinking"),
    ("soft", "memory", "topic:memory+topic:learning"),
    ("soft", "notes", "topic:note-taking+topic:knowledge-management"),
    ("soft", "management", "engineering+manager+handbook+in:readme"),
    ("soft", "feedback", "topic:feedback+topic:growth"),
    ("hard", "coding-interviews", "topic:coding-interview+topic:algorithms"),
    ("hard", "system-design", "topic:system-design"),
    ("hard", "python", "topic:python+topic:best-practices"),
    ("hard", "clean-code", "clean+code+guide+in:readme"),
    ("hard", "data-science", "topic:data-science+topic:learning"),
    ("hard", "devops", "topic:devops+topic:learning-path"),
    ("hard", "algorithms", "topic:algorithms+topic:study"),
    ("hard", "databases", "topic:database+topic:learning"),
    ("hard", "testing", "software+testing+guide+in:readme"),
    ("hard", "architecture", "software+architecture+book+in:readme"),
    ("hard", "api-design", "api+design+guide+in:readme"),
    ("hard", "sql", "topic:sql+topic:tutorial"),
    ("hard", "linux", "topic:linux+topic:learning"),
    ("hard", "git", "topic:git+topic:tutorial"),
    ("hard", "security", "topic:security+topic:learning"),
    ("hard", "machine-learning", "topic:machine-learning+topic:roadmap"),
    ("hard", "frontend", "topic:frontend+topic:best-practices"),
    ("hard", "refactoring", "refactoring+guide+in:readme"),
    ("hard", "agile", "topic:agile+topic:scrum"),
    ("hard", "requirements", "software+requirements+guide+in:readme"),
    # The zip shipped fake cards for exactly these topics. Each one now needs a
    # real, licensed document behind it, or the card goes away.
    ("soft", "habits", "topic:habits+topic:discipline"),
    ("soft", "study-plan", "topic:study+topic:notes"),
    ("soft", "confidence", "topic:public-speaking+topic:communication"),
    ("soft", "stress", "topic:mental-health+topic:self-care"),
    ("soft", "emotional-intelligence", "topic:emotional-intelligence"),
    ("soft", "interview-tips", "topic:interview+topic:preparation"),
    ("soft", "memory", "topic:memory+topic:techniques"),
    ("soft", "goal-setting", "topic:goals+topic:planning"),
]


def curl(url, accept=None):
    args = ["curl", "-sS", "--max-time", "45", "-A", "jarvis-library-import/1.0"]
    if accept:
        args += ["-H", f"Accept: {accept}"]
    args.append(url)
    res = subprocess.run(args, capture_output=True, timeout=90)
    if res.returncode != 0 or not res.stdout:
        return None
    try:
        return json.loads(res.stdout.decode("utf-8", "replace"))
    except ValueError:
        return res.stdout.decode("utf-8", "replace")


def search(query):
    from urllib.parse import quote_plus
    # quote_plus, not quote: GitHub separates search tokens with '+', and plain
    # quote() turns my '+' into '%2B' - a literal plus - so every multi-token
    # query silently returned zero repositories.
    url = ("https://api.github.com/search/repositories?q="
           + quote_plus(query.replace("+", " ") + " stars:>=50")
           + "&sort=stars&order=desc&per_page=15")
    data = curl(url, "application/vnd.github+json")
    if not isinstance(data, dict):
        print(f"  note  search({query!r}) returned no JSON object")
        return []
    if "items" not in data:
        print(f"  note  search({query!r}): {str(data)[:120]}")
    return data.get("items", [])


def licence_of(full_name):
    """The repo's own licence, straight from /license - never inferred.

    Returns (spdx, text), or (None, "") when the API did not answer (the
    unauthenticated core limit is 60 requests/hour, and a throttled response
    looks exactly like "no licence" to a naive reader). Callers must treat None
    as UNKNOWN and leave what is already on disk alone - a rate limit is not a
    licence change, and dropping a book over one would be worse than skipping it.
    """
    data = curl(f"https://api.github.com/repos/{full_name}/license", "application/vnd.github+json")
    if not isinstance(data, dict) or "message" in data:
        return None, ""
    lic = data.get("license") or {}
    name = lic.get("spdx_id") or "NONE"
    if name == "NOASSERTION":
        name = "NONE"
    raw = curl(data.get("url") or "", "application/vnd.github.raw+json")
    return name, raw if isinstance(raw, str) else ""


def readme_of(full_name, branch="HEAD"):
    for path in ("README.md", "readme.md", "README.rst", "Readme.md"):
        url = f"https://raw.githubusercontent.com/{full_name}/HEAD/{path}"
        raw = curl(url)
        if isinstance(raw, str) and len(raw.strip()) > 800:
            return path, raw
    return None, ""


def revendor_from_sources():
    """Re-pull README + chapters for every repo already listed in sources.json.

    --revendor exists because the search API is rate-limited and returns a
    different slice each run: the repos already accepted must be upgradable to
    multi-chapter volumes (and re-checkable) without trusting search again.
    """
    if not os.path.isfile(SOURCES):
        print("no sources.json yet")
        return
    with open(SOURCES, "r", encoding="utf-8") as fh:
        sources = json.load(fh)
    rows = sources.get("vendor_text_copied", [])
    keep = []
    for row in rows:
        full = str(row.get("repo", "")).replace("https://github.com/", "").strip("/")
        if not full or "/" not in full:
            continue
        info = curl(f"https://api.github.com/repos/{full}", "application/vnd.github+json")
        stars = int((info or {}).get("stargazers_count") or row.get("stars") or 0) if isinstance(info, dict) else 0
        desc = ((info or {}).get("description") or "")[:220] if isinstance(info, dict) else ""
        real, lic_text = licence_of(full)
        if real is None:
            print(f"  UNKNOWN {full}: the licence API did not answer (rate limit) - "
                  f"whatever is on disk stays, nothing re-fetched")
            continue
        if real not in ALLOWED:
            print(f"  DROP  {full}: /license now says {real} - text must not be stored")
            continue
        path, text = readme_of(full)
        if not text:
            print(f"  SKIP  {full}: no README")
            continue
        keep.append({"repo": full, "stream": str(row.get("use_for", "hard")).split(" /")[0],
                     "aisle": str(row.get("use_for", "")).split(" / ")[-1], "license": real,
                     "stars": stars, "readme_path": path, "readme": text,
                     "license_text": lic_text, "url": row.get("attribution") or f"https://github.com/{full}",
                     "description": desc})
        print(f"  REREAD {full} ({real}, {stars}*)")
        time.sleep(0.4)
    os.makedirs(VENDOR, exist_ok=True)
    if keep:
        vendor_dirs(keep)
    # The prune runs whether or not anything was re-fetched: sources.json is the
    # curation, and a rate-limited API must not leave 177 link cards on the shelf.
    write_sources(keep, [])
    print(f"re-vendored {len(keep)} repos with real chapter files" if keep
          else "nothing re-vendored (licence API silent?) - sources.json link list pruned")


def main():
    dry = "--dry-run" in sys.argv
    if "--revendor" in sys.argv:
        revendor_from_sources()
        return
    # --only habits,confidence runs a slice. The full list is 43 queries and the
    # unauthenticated search API allows ~10 per minute, so a slice is what fits
    # inside a normal shell timeout; the rest is picked up by a later run.
    only = []
    for arg in sys.argv[1:]:
        if arg.startswith("--only="):
            only = [t.strip().lower() for t in arg.split("=", 1)[1].split(",") if t.strip()]
    queries = [q for q in QUERIES if not only or q[1].lower() in only]
    if only:
        print(f"running {len(queries)} of {len(QUERIES)} queries: " + ", ".join(only))
    seen, keep, link_only = set(), [], []
    for stream, aisle, query in queries:
        items = search(query)
        taken = 0
        links_taken = 0
        for repo in items:
            full = repo["full_name"]
            if full in seen:
                continue
            seen.add(full)
            stars = int(repo.get("stargazers_count") or 0)
            desc = (repo.get("description") or "")[:220]
            if stars < MIN_STARS or not RELEVANT.search(full + " " + desc) or NOT_A_BOOK.search(full):
                continue
            lic = (repo.get("license") or {}).get("spdx_id") or "?"
            if lic not in ALLOWED:
                if links_taken >= MAX_LINKS_PER_QUERY:
                    continue
                links_taken += 1
                # Checked, and the answer was "we may not store this". It still
                # belongs on the shelf as a link, because that is what he asked
                # for - every source visible - but only as a link.
                link_only.append({"repo": full, "url": repo.get("html_url", ""), "license": lic,
                                  "stars": stars, "stream": stream, "aisle": aisle,
                                  "description": desc,
                                  "store": "topic + URL only, opened in the browser",
                                  "last_push": (repo.get("pushed_at") or "")[:10]})
                print(f"  LINK  {full} ({lic}, {stars}*) - licence does not allow storing")
                continue
            if taken >= MAX_PER_QUERY:
                continue
            real, lic_text = licence_of(full)
            lic_source = "GET /repos/…/license"
            if real is None:
                # The core API is throttled (60/hour unauthenticated). The search
                # payload already carries GitHub's own licence detection, so the
                # fallback is the same authority, batched - and it is recorded as
                # such in meta.json so the provenance is never faked.
                real, lic_text, lic_source = (lic if lic != "?" else None), "", "search payload (license API throttled)"
                if real is None:
                    print(f"  UNKNOWN {full}: no licence from the API or the search result")
                    continue
                print(f"  NOTE  {full}: licence API throttled, using the search payload ({real})")
            if real not in ALLOWED:
                if links_taken >= MAX_LINKS_PER_QUERY:
                    continue
                links_taken += 1
                link_only.append({"repo": full, "url": repo.get("html_url", ""),
                                  "license": real or "NONE", "stars": stars, "stream": stream,
                                  "aisle": aisle, "description": desc,
                                  "store": "topic + URL only, opened in the browser",
                                  "last_push": (repo.get("pushed_at") or "")[:10]})
                print(f"  LINK  {full}: search said {lic}, /license says {real} - not stored")
                continue
            path, text = readme_of(full)
            if not text:
                print(f"  SKIP  {full}: no readable README over 800 chars")
                continue
            keep.append({"repo": full, "stream": stream, "aisle": aisle, "license": real,
                         "licence_source": lic_source,
                         "stars": stars, "readme_path": path, "readme": text,
                         "license_text": lic_text, "url": repo.get("html_url", ""),
                         "description": desc})
            taken += 1
            print(f"  KEEP  {full} ({real}, {stars}*) {len(text)} chars")
        time.sleep(SEARCH_PAUSE)
    print("")
    print(f"stored as books: {len(keep)}   link-only (licence refused): {len(link_only)}")
    if dry:
        for k in keep:
            print("  book", k["repo"], k["license"], k["stream"], k["aisle"])
        for r in link_only[:40]:
            print("  link", r["repo"], r["license"])
        return
    os.makedirs(VENDOR, exist_ok=True)
    vendor_dirs(keep)
    write_sources(keep, link_only)
    print(f"vendored {len(keep)} repos into skills/library/vendor/; sources.json lists "
          f"{len(link_only)} link-only finds")


def write_sources(keep, link_only, dry=False):
    sources = {}
    if os.path.isfile(SOURCES):
        with open(SOURCES, "r", encoding="utf-8") as fh:
            sources = json.load(fh)
    index = sources.setdefault("index_only_do_not_copy", [])
    known = {str(i.get("repo", "")).rstrip("/").split("/")[-1].lower() for i in index}
    for row in link_only:
        if row["repo"].split("/")[-1].lower() in known:
            continue
        index.append({"repo": row["repo"], "url": row["url"], "license": row["license"],
                      "stars": row["stars"], "stream": row["stream"], "aisle": row["aisle"],
                      "sections": [row["aisle"]], "last_push": row.get("last_push", ""),
                      "store": "topic + URL only, opened in the browser",
                      "fix_available": "ask the maintainer to add a licence; until then no "
                                       "word of theirs goes into the library"})
        known.add(row["repo"].split("/")[-1].lower())

    # Prune to the best-known list, but never drop the sources he named himself.
    def stars_of(row):
        try:
            return int(row.get("stars") or 0)
        except (TypeError, ValueError):
            return 0

    def repo_key(row):
        """sources.json stores some repos as a full URL and some as owner/name -
        compare on the last path segment so the owner's own picks are never
        pruned by a formatting accident."""
        return str(row.get("repo", "")).rstrip("/").split("/")[-1].lower()

    named = {repo_key({"repo": r}) for r in OWNER_NAMED}
    keep_rows = [i for i in index
                 if repo_key(i) in named or "user-named" in str(i.get("store", ""))]
    rest = [i for i in index if i not in keep_rows]
    rest.sort(key=stars_of, reverse=True)
    sources["index_only_do_not_copy"] = keep_rows + rest[:max(0, MAX_LINKS_TOTAL - len(keep_rows))]
    vendored = sources.setdefault("vendor_text_copied", [])
    for k in keep:
        name = k["repo"].split("/")[-1]
        row = {"repo": k["repo"], "local": f"skills/library/vendor/{name}/",
               "files": ["README.md (%d bytes)" % len(k["readme"])]
                        + (["LICENSE (%s, kept)" % k["license"]] if k["license_text"] else []),
               "license": "%s - verified via GitHub API" % k["license"], "stars": k["stars"],
               "use_for": "%s / %s" % (k["stream"], k["aisle"]), "attribution": k["url"]}
        if not any(v.get("repo") == k["repo"] for v in vendored):
            vendored.append(row)
    if not dry:
        with open(SOURCES, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(sources, fh, ensure_ascii=False, indent=2)
            fh.write("\n")


def tree_markdown(full, max_files=8, max_bytes=220000):
    """The repo's own markdown files, so a vendored repo reads as chapters instead
    of one README. Only depth<=2 paths, only plain .md, capped by total bytes."""
    data = curl(f"https://api.github.com/repos/{full}/git/trees/HEAD?recursive=1",
                "application/vnd.github+json")
    if not isinstance(data, dict) or data.get("truncated"):
        return []
    out = []
    for row in data.get("tree", []):
        path = str(row.get("path") or "")
        if not path.lower().endswith(".md") or row.get("type") != "blob":
            continue
        if path.count("/") > 2 or len(out) >= max_files:
            continue
        size = int(row.get("size") or 0)
        if size < 1500 or size > 400000:
            continue
        out.append((path, size))
    out.sort(key=lambda r: -r[1])
    picked, total = [], 0
    for path, size in out:
        if total + size > max_bytes:
            continue
        raw = curl(f"https://raw.githubusercontent.com/{full}/HEAD/{path}")
        if isinstance(raw, str) and len(raw.strip()) > 800:
            picked.append((path, raw))
            total += len(raw)
    return picked


def vendor_dirs(keep):
    for k in keep:
        name = k["repo"].split("/")[-1]
        d = os.path.join(VENDOR, name)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "README.md"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(k["readme"])
        if k["license_text"]:
            with open(os.path.join(d, "LICENSE"), "w", encoding="utf-8", newline="\n") as fh:
                fh.write(k["license_text"])
        # Extra markdown files become numbered chapter files, and chapters.json
        # records the real title of each one (its first heading), not a guess.
        chapters = [{"n": 1, "file": "README.md", "title": k["repo"].split("/")[-1]}]
        extra = tree_markdown(k["repo"])
        for idx, (path, text) in enumerate(extra, start=2):
            if path.lower() == "readme.md":
                continue
            fname = f"chapter-{idx - 1:02d}.md"
            with open(os.path.join(d, fname), "w", encoding="utf-8", newline="\n") as fh:
                fh.write(text)
            head = re.search(r"^#+\s*(.+)$", text, re.MULTILINE)
            chapters.append({"n": len(chapters) + 1, "file": fname,
                             "title": (head.group(1).strip() if head else path)[:90]})
            time.sleep(0.15)
        with open(os.path.join(d, "chapters.json"), "w", encoding="utf-8", newline="\n") as fh:
            json.dump(chapters, fh, indent=2, ensure_ascii=False)
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8", newline="\n") as fh:
            json.dump({"slug": f"vendor-{name}", "repo": k["repo"], "url": k["url"],
                       "license": k["license"], "licence_source": k.get("licence_source", ""),
                       "stars": k["stars"], "stream": k["stream"],
                       "aisle": k["aisle"], "description": k["description"],
                       "readme_path": k["readme_path"], "chars": len(k["readme"]),
                       "chapter_count": len(chapters),
                       "checked_at": time.strftime("%Y-%m-%d")}, fh, indent=2, ensure_ascii=False)
        print(f"  WROTE vendor/{name}: {len(chapters)} chapters")


if __name__ == "__main__":
    main()
