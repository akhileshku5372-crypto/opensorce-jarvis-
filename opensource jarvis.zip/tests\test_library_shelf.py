"""The Skill Library shelf: what is on disk, one chapter, and the reading guard.

Run with the SAME interpreter JARVIS runs under:
  node run_py.cjs -m unittest discover -s tests -p test_library_shelf.py
"""
import json
import os
import re
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "background"))

import library_shelf  # noqa: E402


class ShelfHonesty(unittest.TestCase):
    def test_every_live_volume_has_real_text(self):
        shelf = library_shelf.shelf()
        self.assertTrue(shelf["ok"])
        readable = [b for b in shelf["books"] if b.get("readable", True)]
        self.assertGreaterEqual(len(readable), 1, "no book was ever imported")
        for book in readable:
            if book.get("kind") == "vendor":
                files = [os.path.join(library_shelf.VENDOR, book["slug"].replace("vendor-", ""),
                                      str(c.get("file", "README.md")))
                         for c in book["chapters"]] or []
            else:
                files = [os.path.join(library_shelf.BOOKS, book["slug"], "book.txt")]
            self.assertTrue(files and all(os.path.isfile(f) for f in files),
                            f"{book['slug']} lists chapters whose files are not on disk")
            self.assertGreaterEqual(len(book["chapters"]), 1)
            self.assertTrue(book["license"], f"{book['slug']} carries no licence")

    def test_link_cards_are_on_the_shelf_but_admit_they_hold_no_text(self):
        """He asked for every source to be visible. A source whose licence refuses
        storage is a LINK card: it must carry a URL and a reason, must say it is
        not readable, and must refuse a chapter read instead of returning blank."""
        shelf = library_shelf.shelf()
        links = [b for b in shelf["books"] if b.get("kind") == "link"]
        if not links:
            self.skipTest("no link-only sources listed")
        for row in links:
            self.assertFalse(row.get("readable", True), f"{row['slug']} claims to be readable")
            self.assertTrue(str(row.get("url", "")).startswith("http"), f"{row['slug']} has no URL")
            self.assertIn("link", str(row.get("split", "")))
            got = library_shelf.chapter(row["slug"], 1)
            self.assertFalse(got.get("ok"))
            self.assertEqual(got.get("error"), "link_only")
            self.assertTrue(got.get("reason"))

    def test_missing_sources_are_reported_with_a_reason(self):
        shelf = library_shelf.shelf()
        self.assertGreaterEqual(len(shelf["unavailable"]), 1)
        for row in shelf["unavailable"]:
            self.assertTrue(str(row.get("reason", "")).strip(), f"{row} has no reason")
            self.assertNotIn(row["slug"], [b["slug"] for b in shelf["books"]],
                             "an unavailable source must not also be painted as a volume")

    def test_counts_agree_with_the_lists(self):
        shelf = library_shelf.shelf()
        readable = [b for b in shelf["books"] if b.get("readable", True)]
        self.assertEqual(shelf["counts"]["live"], len(readable))
        self.assertEqual(shelf["counts"]["listed"], len(shelf["books"]))
        self.assertEqual(shelf["counts"]["links"],
                         len([b for b in shelf["books"] if b.get("kind") == "link"]))
        self.assertEqual(shelf["counts"]["unavailable"], len(shelf["unavailable"]))
        self.assertLessEqual(shelf["counts"]["live"], shelf["counts"]["listed"])


class ChapterReads(unittest.TestCase):
    def _slug(self):
        live = [b for b in library_shelf.shelf()["books"] if b.get("ok") and b.get("kind") != "vendor"]
        self.assertTrue(live, "no plain-text book on the shelf")
        return live[0]

    def test_chapter_returns_the_text_it_claims(self):
        book = self._slug()
        got = library_shelf.chapter(book["slug"], 1)
        self.assertTrue(got["ok"], got)
        self.assertGreater(len(got["text"]), 500)
        self.assertEqual(got["chars"], len(got["text"].strip()))
        self.assertEqual(got["chapter_count"], len(book["chapters"]))

    def test_chapter_number_is_clamped_not_crashed(self):
        book = self._slug()
        for n in (0, -5, "abc", 99999, None):
            got = library_shelf.chapter(book["slug"], n)
            self.assertTrue(got["ok"], f"n={n!r}: {got}")
            self.assertGreaterEqual(got["n"], 1)
            self.assertLessEqual(got["n"], got["chapter_count"])

    def test_slug_can_never_walk_out_of_the_library(self):
        for bad in ["../../knowledge_base", "..%2f..%2fetc", "a/b", "books/x", "",
                    "PRATEEK", "C:/Windows", ".", "..", "x" * 200]:
            got = library_shelf.chapter(bad, 1)
            self.assertFalse(got.get("ok"), f"{bad!r} was allowed: {got}")
            self.assertIn(got.get("error"), ("bad_slug", "not_found"))

    def test_vendor_volume_reads_its_own_files_and_nothing_else(self):
        vendors = [b for b in library_shelf.shelf()["books"] if b.get("kind") == "vendor"]
        if not vendors:
            self.skipTest("no vendored repo on disk")
        for book in vendors:
            first = library_shelf.chapter(book["slug"], 1)
            self.assertTrue(first.get("ok"), f"{book['slug']}: {first}")
            self.assertGreater(first["chars"], 800, f"{book['slug']} chapter 1 is a stub")
            self.assertEqual(first["chapter_count"], len(book["chapters"]))
            # a repo vendored with several markdown files must open each of them
            if len(book["chapters"]) > 1:
                last = library_shelf.chapter(book["slug"], len(book["chapters"]))
                self.assertTrue(last.get("ok"), last)
                self.assertNotEqual(last["text"][:60], first["text"][:60],
                                    "chapter N returned chapter 1's text")
            self.assertEqual(library_shelf.chapter(book["slug"] + "/../../windows", 1).get("error"),
                             "bad_slug")


class AskGuards(unittest.TestCase):
    def test_empty_question_never_reaches_the_pool(self):
        for q in ("", "  ", "ok"):
            out = library_shelf.ask("art-of-public-speaking", 1, q)
            self.assertFalse(out.get("ok"))
            self.assertEqual(out.get("error"), "empty_question")

    def test_ask_on_a_missing_book_reports_that_instead_of_answering(self):
        out = library_shelf.ask("no-such-book", 1, "What should I do tomorrow?")
        self.assertFalse(out.get("ok"))
        self.assertEqual(out.get("error"), "not_found")

    def test_window_never_dump_whole_chapter(self):
        book = [b for b in library_shelf.shelf()["books"]
                if b.get("ok") and b.get("kind") != "vendor"][0]
        biggest = max(book["chapters"], key=lambda c: c["chars"])
        got = library_shelf.chapter(book["slug"], biggest["n"])
        window, how = library_shelf._window(got["text"], "how do I practise this daily")
        self.assertLessEqual(len(window), library_shelf.ASK_CONTEXT_CHARS + 200,
                             "a long chapter must be windowed, not pasted whole")
        self.assertTrue(how)

    def test_window_falls_back_honestly_when_no_words_match(self):
        window, how = library_shelf._window("x" * 50000, "zz")
        self.assertEqual(len(window), library_shelf.ASK_CONTEXT_CHARS)
        self.assertIn("no words to match on", how)

    def test_speak_chunks_below_the_edge_tts_limit(self):
        # The 7782 service refuses >600 chars, so a long passage has to be cut.
        long = "Practice facing the audience, Sir. " * 120
        out = library_shelf.speak(long, "en")
        if not out.get("ok"):
            self.skipTest(f"edge-tts not answering: {out.get('reason')}")
        self.assertGreater(out["bytes"], 5000)
        self.assertGreaterEqual(out["segments"], 2)



    """The per-source check he asked for, plus the demo-data ban."""
class ShelfAudit(unittest.TestCase):
    def test_every_readable_volume_actually_opens(self):
        """His ask: "jo jo source tune add kiya usse ek baar check kar".

        Not a file-existence check - every readable volume is opened through the
        same chapter() the desk uses, so a volume that would paint an empty page
        fails here instead of in front of him.
        """
        shelf = library_shelf.shelf()
        readable = [b for b in shelf["books"] if b.get("readable", True)]
        self.assertGreaterEqual(len(readable), 5, "the shelf has almost nothing on it")
        thin = []
        for book in readable:
            got = library_shelf.chapter(book["slug"], 1)
            if not got.get("ok") or len(got.get("text", "").strip()) < 500:
                thin.append(f"{book['slug']}: {got.get('error') or got.get('reason') or str(len(got.get('text',''))) + ' chars'}")
        self.assertEqual(thin, [], "these volumes do not open into real text: " + "; ".join(thin))

    def test_the_desk_can_answer_from_a_volume_of_either_stream(self):
        """One readable soft volume and one readable hard volume must both carry
        enough text for the desk to work from - the hard side used to be empty."""
        shelf = library_shelf.shelf()
        for stream in ("soft", "hard"):
            rows = [b for b in shelf["books"] if b.get("readable", True) and b.get("stream") == stream]
            self.assertTrue(rows, f"no readable {stream} volume on the shelf")
            opened = [library_shelf.chapter(b["slug"], 1) for b in rows[:3]]
            self.assertTrue(any(o.get("ok") and o.get("chars", 0) > 800 for o in opened),
                            f"{stream} volumes exist but none opens with real text")

    def test_no_invented_sample_cards_survive_in_the_ui(self):
        """The zip shipped fake books ("Habits & Discipline", "Emotional
        Intelligence", ...) and fake notes. They must not come back through the
        bundle or the UI source, or a stale tab will keep showing them."""
        ui = os.path.join(ROOT, "library-ui", "src")
        banned = ("PRESET_LIBRARY_MATERIALS", "INITIAL_NOTES", "INITIAL_COLLECTIONS",
                  "Habits & Discipline", "here are the key insights")
        hits = []
        for base, _dirs, files in os.walk(ui):
            for name in files:
                if not name.endswith((".ts", ".tsx")):
                    continue
                with open(os.path.join(base, name), encoding="utf-8", errors="replace") as fh:
                    text = fh.read()
                for word in banned:
                    if word in text:
                        hits.append(f"{name}: {word}")
        self.assertEqual(hits, [], "demo data is back in the library UI: " + ", ".join(hits))
        bundle = os.path.join(ROOT, "public", "static", "library", "library-bundle.js")
        if os.path.isfile(bundle):
            with open(bundle, encoding="utf-8", errors="replace") as fh:
                data = fh.read()
            self.assertNotIn("Habits & Discipline", data, "the built bundle still carries demo cards")
            self.assertNotIn("here are the key insights", data, "the built bundle still carries the canned answer")
            self.assertIn("library/ask", data, "the built bundle is not the desk-wired one")


class ModuleHygiene(unittest.TestCase):
    """The desk must stay a thin client of the existing pipelines.

    These look for concrete integration points - hostnames, key names, imports -
    not the words "Groq"/"Gemini" in prose, because the module's own docstring
    says what it refuses to use.
    """
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, "background", "library_shelf.py"), encoding="utf-8") as fh:
            cls.src = fh.read()

    def test_no_second_brain_or_pipeline(self):
        for forbidden in ("voice_engine", "import openai", "from openai", "jarvis_core"):
            self.assertNotIn(forbidden, self.src,
                             f"library_shelf must not pull in {forbidden}")

    def test_hygiene_is_checked_in_code_not_in_prose(self):
        """Word-matching the file would fail on this module's own docstring, which
        is allowed to say what it refuses to use. So inspect only what can really
        reach out: imported modules, URL literals, and env-key-name literals."""
        import ast
        tree = ast.parse(self.src)
        imports, hosts, envish = set(), set(), set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.update(a.name.split(".")[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module.split(".")[0])
            elif isinstance(node, ast.Constant) and isinstance(node.value, str):
                v = node.value
                if "://" in v or re.match(r"^[\w.-]+\.(com|ai|dev|io)$", v):
                    hosts.add(v.lower())
                elif re.fullmatch(r"[A-Z][A-Z0-9_]{3,}", v):
                    envish.add(v)
        banned = ("groq", "gemini", "generativelanguage", "elevenlabs", "openai", "googleapiclient")
        for pool in (imports, hosts, envish):
            for item in pool:
                low = item.lower()
                for word in banned:
                    self.assertNotIn(word, low,
                                     f"library_shelf reaches for {word} via {item!r}")
        # the two things it IS allowed to talk to
        self.assertIn("radox_writer", self.src)
        self.assertIn("127.0.0.1:7782/tts", self.src)
        self.assertIn("no RADOX_API_KEY configured", self.src)

    def test_the_two_forbidden_providers_are_not_reachable(self):
        for host in ("api.groq.com", "generativelanguage.googleapis.com", "openai.com"):
            self.assertNotIn(host, self.src, f"{host} is not allowed on this desk")
        for key in ("GROQ_API_KEY", "GOOGLE_API_KEY", "OPENAI_API_KEY"):
            self.assertNotIn(key, self.src, f"{key} must not be read for this desk")

    def test_the_desk_answers_from_the_pool_it_is_given(self):
        # Behaviour, not word-matching: stub the pool and prove ask() goes to it.
        calls = {}

        class FakePool:
            @staticmethod
            def available():
                return True

            @staticmethod
            def write(prompt, system="", max_tokens=0, timeout=0, want=None):
                calls["prompt"] = prompt
                calls["system"] = system
                return "Stubbed Radox answer, Sir.", {"model": "stub", "ms": 1,
                                                      "attempts": [{"slot": 1, "ok": True}],
                                                      "error": "", "finish": "stop"}

        real = library_shelf._load_sibling
        library_shelf._load_sibling = lambda name: FakePool() if name == "radox_writer" else None
        try:
            out = library_shelf.ask("art-of-public-speaking", 1, "What should I do tomorrow?")
        finally:
            library_shelf._load_sibling = real
        self.assertTrue(out.get("ok"), out)
        self.assertEqual(out.get("engine"), "Radox")
        self.assertIn("PRATEEK ASKS", calls.get("prompt", ""))
        self.assertIn("supplied passage", calls.get("system", "").lower())
        # the chapter text really was carried into the prompt
        self.assertIn("BOOK:", calls.get("prompt", ""))
        loaded = [k for k in sys.modules if "groq" in k.lower() or "gemini" in k.lower()
                  or "openai" in k.lower()]
        self.assertEqual(loaded, [], f"ask() dragged in a provider: {loaded}")



if __name__ == "__main__":
    unittest.main(verbosity=2)
