# JARVIS v0.8 Local Requirements

## Mandatory software
- Windows 10 or Windows 11
- Node.js 20+
- npm 10+
- Python 3.10+ with pip
- Chrome or Microsoft Edge for the dashboard
- Internet access for cloud AI and CDN-loaded Lucide/MediaPipe assets
- A working microphone; camera is optional

## One-command install

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-windows.ps1
```

The setup script installs JavaScript and Python packages, validates the project, starts the UI and bridge with PM2, and starts the single background JARVIS core plus floating HUD.

## Runtime services
- UI/API: `http://127.0.0.1:7777`
- Windows bridge: `http://127.0.0.1:7778`
- Background core state/action channel: `http://127.0.0.1:7780`
- Floating HUD guard: UDP loopback port `7781`

The Python core owns microphone, wake word, STT, AI routing, tool routing, and TTS. The dashboard and floating HUD are clients; they do not start separate core engines. In v0.8 the microphone loop stays alive during network/LLM work, returns to standby automatically after speech, and uses sustained high-energy detection for barge-in while suppressing ordinary speaker echo.

## Declared packages
- JavaScript dependencies: `package-lock.json`
- Python dependencies: `requirements.txt` (`numpy`, `requests`, `sounddevice`)

## Configuration
- `.dev.vars`: local Hono/Wrangler provider keys
- `.env`: local runtime provider configuration
- `.env.example`: committed key-free template

Do not distribute `.env` or `.dev.vars` inside ZIP files. Keys pasted into chat must be rotated before use; copy only fresh replacements into both local files.

`.env` and `.dev.vars` are ignored by Git. Rotate any credential that has been posted in chat before production use.

## v0.8 hands-free acceptance requirements
- Launching `npm run jarvis` starts exactly one background voice core and reveals the floating HUD.
- No microphone or wake button is required after startup; `Hey JARVIS` activates the assistant.
- After command execution and TTS, the core automatically resumes passive wake listening.
- A deliberate user interruption during TTS cancels playback and begins a new utterance.
- Chrome/dashboard minimize or close does not stop voice; the floating orb and conversation panel remain on the desktop.
- The floating HUD is always-on-top, draggable, single-instance, and can restore the dashboard.
- The panel minus control (or Escape key) enters orb-only mode; the orb remains visible, and either its reactor face or cyan chevron restores the reference-style conversation panel.
- HUD history contains only revisioned events from the canonical core; an empty HUD must not fabricate demonstration messages.
- Windows microphone, TTS, startup, overlay, and desktop-action validation must be completed on the target PC.

## Supported local actions
Known and dynamically discovered apps, safe user folders/files, arbitrary domains, Google/YouTube search, browser navigation, screenshots, CPU/RAM/disk/battery telemetry, volume, clipboard shortcuts, window switch/minimize/maximize/restore, desktop reveal, and PC lock.

## Validation

```powershell
npm test
npm run build
curl.exe http://127.0.0.1:7777/api/health
curl.exe http://127.0.0.1:7778/api/status
curl.exe http://127.0.0.1:7780/health
```

Final microphone, wake-word, TTS playback, UI focus, and Windows action acceptance tests must be run on the target Windows laptop because the Linux build sandbox has no Windows desktop or physical microphone.
