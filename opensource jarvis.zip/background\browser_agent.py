"""Browser Agent: REAL page control via Playwright (Chromium).

Replaces the previous Firecrawl-only adapter, which could NOT see, click or
type on a rendered page. The "Browser Extension Bridge" card claimed
"page-aware control" while zero DOM tools existed; the 2026-09-29 audit caught
it and the card was BLOCKED. This module makes the claim true.

Architecture (AGENTS.md compliance):
  * THIN DRIVER, not a second brain. No LLM call and no agent loop lives here.
    It executes one primitive and returns data; all decision-making stays in
    the single Cortex planner behind the single confirm gate.
  * browser-use (MIT, github.com/browser-use/browser-use) is used ONLY for its
    Playwright session ergonomics. Its `Agent()` LLM loop is deliberately NOT
    used - that would be a second assistant pipeline, which AGENTS.md forbids.
  * No shell, no argv, no user-supplied path. URLs are validated to http/https
    only. Read actions are ungated; anything that MUTATES a remote page
    (click, type) declares requires_confirmation=True so the existing cortex
    confirm gate AND the permission category both apply.
  * One browser / context / page behind a lock, so two voice commands cannot
    interleave on the same page.
  * LAZY: nothing launches until the first real tool call, so idle JARVIS
    costs zero RAM.
  * The xKiro / Qwen provider stack is deliberately untouched by this module.
"""
from __future__ import annotations

import importlib.util
import re
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
SHOT_DIR = ROOT / "artifacts" / "browser"

NAV_TIMEOUT_MS = 20000
TEXT_LIMIT = 8000
MAX_SHOTS_KEPT = 20

_lock = threading.RLock()
_playwright = None
_browser = None
_context = None
_page = None
_last_error = ""


# ── availability ────────────────────────────────────────────────────────────
def playwright_installed() -> bool:
    return importlib.util.find_spec("playwright") is not None


def chromium_installed() -> bool:
    """True when a Playwright browser binary is actually on this machine."""
    if not playwright_installed():
        return False
    cache = Path.home() / "AppData" / "Local" / "ms-playwright"
    try:
        return (cache.is_dir()
                and any(p.name.startswith("chromium") for p in cache.iterdir()))
    except Exception:
        return False


def available() -> bool:
    return playwright_installed() and chromium_installed()


def capabilities() -> dict:
    """Honest report - the Modules card reads THIS, never a guess."""
    if not playwright_installed():
        return {"available": False,
                "reason": "pip install playwright (missing in this venv)"}
    if not chromium_installed():
        return {"available": False,
                "reason": "python -m playwright install chromium "
                          "(browser binary not downloaded yet)"}
    return {"available": True, "reason": "",
            "driver": "playwright/chromium",
            "actions": ["navigate", "read_text", "click", "type", "screenshot",
                        "tabs", "back", "title"]}


def _err(message: str) -> dict:
    return {"ok": False, "error": str(message)[:300]}


# ── safety ──────────────────────────────────────────────────────────────────
# A leading "scheme:" that is NOT http/https must be rejected outright. Without
# this, safe_url("javascript:alert(1)") would prepend https:// and produce the
# nonsense-but-harmless "https://javascript:alert(1)" instead of refusing the
# dangerous input outright, which is exactly the kind of quiet mangling that
# hides a bug until someone finds it.
_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.\-]*:")


def safe_url(raw: str) -> str:
    """Only http/https survives. file://, javascript:, data: are rejected.

    Same posture as the loopback bridge: the user's words SELECT a destination,
    they never become a path or an execution vector.
    """
    text = str(raw or "").strip()
    if not text:
        return ""
    if _SCHEME_RE.match(text):
        # An explicit scheme was given - it MUST already be http(s).
        if not text.lower().startswith(("http://", "https://")):
            return ""
    else:
        # No scheme at all: treat a bare host as https, but reject anything
        # that looks like a Windows path (C:\...) or a UNC share.
        if "\\" in text or re.match(r"^[a-zA-Z]:", text):
            return ""
        text = "https://" + text
    parsed = urlparse(text)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return ""
    return text


# ── lazy singleton ──────────────────────────────────────────────────────────
def _ensure_page():
    """Launch Chromium on first use. Returns (page, error)."""
    global _playwright, _browser, _context, _page, _last_error
    if _page is not None:
        try:
            if not _page.is_closed():
                return _page, ""
        except Exception:
            _page = None
    if not playwright_installed():
        return None, "playwright is not installed in this venv"
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception as exc:
        return None, "playwright import failed: %s" % type(exc).__name__
    try:
        if _playwright is None:
            _playwright = sync_playwright().start()
        if _browser is None or not _browser.is_connected():
            _browser = _playwright.chromium.launch(
                headless=True,
                args=["--disable-dev-shm-usage", "--no-sandbox"])
            _context = _browser.new_context(
                viewport={"width": 1366, "height": 850})
        _page = _context.new_page()
        _page.set_default_timeout(NAV_TIMEOUT_MS)
        return _page, ""
    except Exception as exc:
        _last_error = "%s: %s" % (type(exc).__name__, exc)
        return None, ("could not launch Chromium - run `python -m playwright "
                      "install chromium` (%s)" % _last_error[:120])


def close() -> dict:
    """Release the browser. Safe when nothing is open."""
    global _playwright, _browser, _context, _page
    with _lock:
        for obj in (_context, _browser):
            try:
                if obj is not None:
                    obj.close()
            except Exception:
                pass
        try:
            if _playwright is not None:
                _playwright.stop()
        except Exception:
            pass
        _playwright = _browser = _context = _page = None
    return {"ok": True}


# ── actions ─────────────────────────────────────────────────────────────────
def navigate(url: str) -> dict:
    """Open a URL in the real browser and return its title + text."""
    target = safe_url(url)
    if not target:
        return _err("only http/https URLs are allowed")
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            resp = page.goto(target, wait_until="domcontentloaded",
                             timeout=NAV_TIMEOUT_MS)
            body = page.inner_text("body") or ""
            return {"ok": True, "url": page.url, "title": page.title(),
                    "status": (resp.status if resp is not None else None),
                    "text": body[:TEXT_LIMIT], "truncated": len(body) > TEXT_LIMIT}
        except Exception as exc:
            return _err("navigate failed: %s" % type(exc).__name__)


def read_text(url: str = "") -> dict:
    """Read the current page (or navigate first when given a URL)."""
    if url:
        return navigate(url)
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            body = page.inner_text("body") or ""
            return {"ok": True, "url": page.url, "title": page.title(),
                    "text": body[:TEXT_LIMIT],
                    "truncated": len(body) > TEXT_LIMIT}
        except Exception as exc:
            return _err("read failed: %s" % type(exc).__name__)


def title() -> dict:
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            return {"ok": True, "url": page.url, "title": page.title()}
        except Exception as exc:
            return _err("title failed: %s" % type(exc).__name__)


def click(selector: str) -> dict:
    """Click one element. MUTATES a remote page -> confirm gated by the caller."""
    sel = str(selector or "").strip()[:200]
    if not sel:
        return _err("no selector given")
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            page.click(sel, timeout=NAV_TIMEOUT_MS)
            return {"ok": True, "clicked": sel, "url": page.url}
        except Exception as exc:
            return _err("click failed on %r: %s" % (sel, type(exc).__name__))


def type_text(selector: str, text: str) -> dict:
    """Type into one element. MUTATES a remote page -> confirm gated."""
    sel = str(selector or "").strip()[:200]
    value = str(text or "")[:500]
    if not sel:
        return _err("no selector given")
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            page.fill(sel, value, timeout=NAV_TIMEOUT_MS)
            return {"ok": True, "filled": sel, "length": len(value)}
        except Exception as exc:
            return _err("type failed on %r: %s" % (sel, type(exc).__name__))


def screenshot(name: str = "") -> dict:
    """Capture the current viewport to artifacts/browser/."""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    slug = "".join(c for c in str(name or "") if c.isalnum() or c in "-_")[:40]
    path = SHOT_DIR / ("%s-%s.png" % (slug or "page", stamp))
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            SHOT_DIR.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(path))
            _prune_shots()
            return {"ok": True, "path": str(path.relative_to(ROOT)),
                    "url": page.url}
        except Exception as exc:
            return _err("screenshot failed: %s" % type(exc).__name__)


def _prune_shots() -> None:
    try:
        shots = sorted(SHOT_DIR.glob("*.png"), key=lambda p: p.stat().st_mtime,
                       reverse=True)
        for old in shots[MAX_SHOTS_KEPT:]:
            old.unlink()
    except Exception:
        pass


def tabs() -> dict:
    """List open tabs. Uses the real context when one exists."""
    with _lock:
        if _context is None:
            return {"ok": True, "tabs": [], "count": 0,
                    "note": "no browser session is open yet"}
        try:
            rows = [{"index": i, "title": (p.title() or "")[:120], "url": p.url}
                    for i, p in enumerate(_context.pages)]
            return {"ok": True, "tabs": rows, "count": len(rows)}
        except Exception as exc:
            return _err("tabs failed: %s" % type(exc).__name__)


def back() -> dict:
    with _lock:
        page, err = _ensure_page()
        if page is None:
            return _err(err)
        try:
            page.go_back(timeout=NAV_TIMEOUT_MS)
            return {"ok": True, "url": page.url, "title": page.title()}
        except Exception as exc:
            return _err("back failed: %s" % type(exc).__name__)


def describe() -> str:
    caps = capabilities()
    if not caps["available"]:
        return "Sir, browser unavailable: %s." % caps["reason"]
    return ("Sir, browser ready: Playwright Chromium, page control for "
            "navigate, read, click, type, screenshot and tabs.")


# ── cortex tool specs ───────────────────────────────────────────────────────
def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()


def _unavailable(action: str) -> dict:
    caps = capabilities()
    return {"ok": False,
            "output": "Browser %s is not available: %s" % (
                action, caps.get("reason", "playwright/chromium missing")),
            "error": caps.get("reason", "browser unavailable")}


def _tool_status(args: dict) -> dict:
    return {"ok": True, "output": describe(), "data": capabilities()}


def _tool_navigate(args: dict) -> dict:
    if not available():
        return _unavailable("navigate")
    out = navigate((args or {}).get("url", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "navigation failed")}
    return {"ok": True,
            "output": "Opened %s - %s (%d chars)." % (
                out.get("url", "")[:90], out.get("title", "")[:60],
                len(out.get("text", ""))),
            "data": out}


def _tool_read(args: dict) -> dict:
    if not available():
        return _unavailable("read")
    out = read_text((args or {}).get("url", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "read failed")}
    return {"ok": True,
            "output": "%s - %s\n%s" % (out.get("url", "")[:90],
                                       out.get("title", "")[:60],
                                       out.get("text", "")[:2000]),
            "data": out}


def _tool_click(args: dict) -> dict:
    if not available():
        return _unavailable("click")
    out = click((args or {}).get("selector", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "click failed")}
    return {"ok": True, "output": "Clicked %s." % out.get("clicked"), "data": out}


def _tool_type(args: dict) -> dict:
    if not available():
        return _unavailable("type")
    out = type_text((args or {}).get("selector", ""), (args or {}).get("text", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "type failed")}
    return {"ok": True, "output": "Typed into %s." % out.get("filled"), "data": out}


def _tool_screenshot(args: dict) -> dict:
    if not available():
        return _unavailable("screenshot")
    out = screenshot((args or {}).get("name", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "screenshot failed")}
    return {"ok": True, "output": "Saved %s." % out.get("path"), "data": out}


def _tool_tabs(args: dict) -> dict:
    if not available():
        return _unavailable("tabs")
    out = tabs()
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "tabs failed")}
    return {"ok": True, "output": "%d tab(s) open." % out.get("count", 0),
            "data": out}


# The Firecrawl research surface that already existed, kept intact.


MAX_SNAPSHOT_CHARS = 8000

_firecrawl_mod = None


def _firecrawl():
    global _firecrawl_mod
    if _firecrawl_mod is not None:
        return _firecrawl_mod
    import importlib.util
    path = ROOT / "background" / "firecrawl_client.py"
    spec = importlib.util.spec_from_file_location("jarvis_cowork_firecrawl", path)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _firecrawl_mod = mod
    return mod

def tool_web_research(args: dict) -> dict:
    try:
        topic = cortex.read_str_param(args, "topic", max_chars=300)
        depth = cortex.read_str_param(args, "depth", required=False, default="search",
                                      max_chars=10).lower()
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    client = _firecrawl()
    if client is None:
        return cortex.fail_result("research client load nahi hua.")
    try:
        if depth == "deep":
            data = client.research(topic)
        else:
            data = client.search(topic, max_results=5)
    except Exception as exc:
        return cortex.fail_result("research fail: %s: %s" % (type(exc).__name__, exc))
    if isinstance(data, dict) and data.get("error"):
        return cortex.fail_result(str(data["error"])[:400])
    report = str((data or {}).get("report") or (data or {}).get("answer") or "")[:4000]
    results = (data or {}).get("results") or []
    sources = [str(u) for u in ((data or {}).get("sources") or [])][:8]
    for item in results[:5]:
        if isinstance(item, dict) and item.get("url") and item["url"] not in sources:
            sources.append(item["url"])
    lines = [report] if report else []
    for item in results[:5]:
        if isinstance(item, dict) and item.get("url"):
            lines.append("- %s :: %s" % (item.get("title") or item["url"],
                                         str(item.get("content") or "")[:200]))
    return cortex.ok_result("\n".join(lines)[:4000] or "(koi result nahi)",
                            sources=sources)


def tool_web_extract(args: dict) -> dict:
    try:
        url = cortex.read_str_param(args, "url", max_chars=500)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if not url.lower().startswith(("http://", "https://")):
        return cortex.fail_result("url http(s) se shuru hona chahiye.")
    client = _firecrawl()
    if client is None:
        return cortex.fail_result("extract client load nahi hua.")
    try:
        data = client.extract(url)
    except Exception as exc:
        return cortex.fail_result("extract fail: %s: %s" % (type(exc).__name__, exc))
    if isinstance(data, dict) and data.get("error"):
        return cortex.fail_result(str(data["error"])[:400])
    return cortex.ok_result(str((data or {}).get("content") or "")[:4000] or "(khaali page)")


def tool_web_snapshot(args: dict) -> dict:
    try:
        url = cortex.read_str_param(args, "url", max_chars=500)
        name = cortex.read_str_param(args, "name", required=False, default="page",
                                     max_chars=60)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if not url.lower().startswith(("http://", "https://")):
        return cortex.fail_result("url http(s) se shuru hona chahiye.")
    safe = "".join(c if (c.isalnum() or c in "-_") else "_" for c in name)[:40] or "page"
    target = (ROOT / "artifacts" / "browser" / (safe + ".md")).resolve()
    try:
        target.relative_to(ROOT)
    except ValueError:
        return cortex.fail_result("snapshot path repo ke bahar hai.")
    got = tool_web_extract({"url": url})
    if not got.get("ok"):
        return got
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("# %s\n\nSource: %s\n\n%s\n"
                          % (safe, url, str(got.get("output") or "")[:MAX_SNAPSHOT_CHARS]),
                          encoding="utf-8")
    except Exception as exc:
        return cortex.fail_result("snapshot fail: %s: %s" % (type(exc).__name__, exc))
    return cortex.ok_result("snapshot save: artifacts/browser/%s.md" % safe,
                            path=str(target.relative_to(ROOT)))


def specs() -> list:
    """One registry list: real page control + the Firecrawl research tools.

    Page reads (navigate/read/screenshot/tabs) are free. Anything that MUTATES
    a remote page (click/type) declares requires_confirmation=True so the
    existing cortex confirm gate AND the permission category both apply.
    """
    return [
        cortex.ToolSpec("browser_status",
                        "Real browser driver status (Playwright/Chromium).",
                        _tool_status, parameters={},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("browser",)),
        cortex.ToolSpec("browser_navigate",
                        "Open a URL in a real browser and return its text.",
                        _tool_navigate, parameters={"url": "http(s) URL"},
                        requires_confirmation=False, timeout_s=45.0,
                        tags=("browser", "web")),
        cortex.ToolSpec("browser_read",
                        "Read the visible text of the current (or given) page.",
                        _tool_read, parameters={"url": "optional http(s) URL"},
                        requires_confirmation=False, timeout_s=45.0,
                        tags=("browser", "web")),
        cortex.ToolSpec("browser_screenshot",
                        "Capture the current page to artifacts/browser/.",
                        _tool_screenshot, parameters={"name": "file label"},
                        requires_confirmation=False, timeout_s=30.0,
                        tags=("browser", "vision")),
        cortex.ToolSpec("browser_tabs",
                        "List the open browser tabs.",
                        _tool_tabs, parameters={},
                        requires_confirmation=False, timeout_s=20.0,
                        tags=("browser",)),
        cortex.ToolSpec("browser_click",
                        "Click one element on the current page (CSS selector).",
                        _tool_click, parameters={"selector": "CSS selector"},
                        requires_confirmation=True, timeout_s=40.0,
                        tags=("browser", "write")),
        cortex.ToolSpec("browser_type",
                        "Type text into one element on the current page.",
                        _tool_type,
                        parameters={"selector": "CSS selector", "text": "text"},
                        requires_confirmation=True, timeout_s=40.0,
                        tags=("browser", "write")),
        # ── Firecrawl research surface (kept: it is real and works) ──
        cortex.ToolSpec("web_research", "Web search ya deep brief nikalo.",
                        tool_web_research,
                        parameters={"topic": "search topic",
                                    "depth": "search|deep (default search)"}),
        cortex.ToolSpec("web_extract", "Ek URL ka clean text nikalo.",
                        tool_web_extract,
                        parameters={"url": "http(s) URL"}),
        cortex.ToolSpec("web_snapshot", "Page text ko repo me save karo.",
                        tool_web_snapshot,
                        parameters={"url": "http(s) URL",
                                    "name": "file naam (default page)"}),
    ]


def describe() -> str:
    caps = capabilities()
    research = " + Firecrawl research/extract/snapshot" if _firecrawl() else ""
    if not caps["available"]:
        return ("Sir, browser page control unavailable: %s. Web research is "
                "still available%s." % (caps.get("reason", ""),
                                         " via Firecrawl"))
    return ("Sir, browser ready: Playwright Chromium with real page control "
            "(navigate, read, click, type, screenshot, tabs)%s." % research)
