"""REAL browser MCP server for JARVIS (Model Context Protocol over stdio).

This turns the Phase-1 Playwright driver into a genuine MCP connector instead
of an internal helper. Any MCP client (JARVIS, an IDE, another agent) can now
do real-world browsing: open a page, read what it actually says, find links,
click a real element, fill a real form, capture the screen.

It speaks newline-delimited JSON-RPC 2.0 over stdio: initialize ->
notifications/initialized -> tools/list -> tools/call.

Why it is safe (AGENTS.md):
  * NO shell, NO argv, NO executable path, NO filesystem path. The only inputs
    are an http/https URL (validated) and a CSS selector (length-capped).
    file://, javascript:, data: and Windows paths are refused outright.
  * The driver is the SAME shared instance the voice route uses
    (background/browser_agent.py under its shared module key), so there is no
    second browser and no second agent loop.
  * Read tools are annotated read-only. click/fill MUTATE a remote page, so
    they are marked destructiveHint=true and the caller's confirm gate decides;
    this server never self-approves anything.
  * Every tool has a bounded output size and a hard timeout.
"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_TEXT = 6000

# Each MCP stdio call in this repo's client spawns a fresh server process, so
# an in-memory page would be lost between calls and "click after browse" would
# silently act on about:blank. The last real URL is therefore remembered on
# disk, and any tool called without an explicit url restores that page first.
# This is what makes multi-step browsing actually work over MCP.
SESSION_FILE = ROOT / "artifacts" / "browser" / "_mcp_session.json"


def _remember_url(url: str) -> None:
    try:
        if not url or not str(url).startswith(("http://", "https://")):
            return
        SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        SESSION_FILE.write_text(json.dumps({"url": url, "at": time.time()}),
                                encoding="utf-8")
    except Exception:
        pass


def _last_url() -> str:
    try:
        data = json.loads(SESSION_FILE.read_text(encoding="utf-8"))
        url = str(data.get("url") or "")
        return url if url.startswith(("http://", "https://")) else ""
    except Exception:
        return ""


def _restore(mod):
    """Reopen the remembered page so state-dependent tools work."""
    page, _err = mod._ensure_page()
    if page is not None:
        try:
            if not page.is_closed() and page.url not in ("about:blank", ""):
                return True
        except Exception:
            pass
    url = _last_url()
    if not url:
        return False
    out = mod.navigate(url)
    return bool(out.get("ok"))

TOOLS = [
    {
        "name": "browse",
        "description": ("Open a real web page in a browser and return its "
                        "rendered title and visible text. This actually loads "
                        "and renders the page; it is not an HTTP fetch."),
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "url": {"type": "string",
                    "description": "http(s) URL. file://, javascript: and "
                                   "data: are refused."}},
            "required": ["url"]},
    },
    {
        "name": "read_page",
        "description": "Read the visible text of the page already open, "
                       "optionally navigating first when a url is given.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "url": {"type": "string", "description": "optional http(s) URL"}}},
    },
    {
        "name": "list_links",
        "description": "List the real hyperlinks on the current page with "
                       "their text and href. Use this to decide what to click.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "find_text",
        "description": "Search the current page for a phrase and report "
                       "whether it is present, plus a short excerpt.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string", "description": "phrase to look for"}},
            "required": ["query"]},
    },
    {
        "name": "screenshot",
        "description": "Capture what is currently on screen to a PNG file.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "name": {"type": "string", "description": "file label"}}},
    },
    {
        "name": "click",
        "description": ("Click a real element on the current page by CSS "
                        "selector. This MUTATES the remote page, so the "
                        "caller's confirmation gate must approve it first."),
        "annotations": {"readOnlyHint": False, "destructiveHint": True},
        "inputSchema": {"type": "object", "properties": {
            "selector": {"type": "string",
                         "description": "CSS selector, e.g. a.submit"}},
            "required": ["selector"]},
    },
    {
        "name": "fill",
        "description": ("Type text into a real form field by CSS selector. "
                        "This MUTATES the remote page and must be confirmed "
                        "before it runs. It never submits the form."),
        "annotations": {"readOnlyHint": False, "destructiveHint": True},
        "inputSchema": {"type": "object", "properties": {
            "selector": {"type": "string", "description": "CSS selector"},
            "text": {"type": "string", "description": "text to type"}},
            "required": ["selector", "text"]},
    },
]

_driver = None


def _driver_module():
    """The ONE shared Playwright driver, loaded under the shared key."""
    global _driver
    if _driver is not None:
        return _driver
    key = "jarvis_cowork_browser_agent"
    existing = sys.modules.get(key)
    if existing is not None:
        _driver = existing
        return _driver
    path = ROOT / "background" / "browser_agent.py"
    if not path.is_file():
        return None
    spec = importlib.util.spec_from_file_location(key, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    _driver = mod
    return _driver


def _reply(request_id, result):
    sys.stdout.write(json.dumps(
        {"jsonrpc": "2.0", "id": request_id, "result": result}) + "\n")
    sys.stdout.flush()


def _text(request_id, message, is_error=False):
    _reply(request_id, {"content": [{"type": "text", "text": str(message)}],
                       "isError": bool(is_error)})


def _not_ready(request_id, action):
    mod = _driver_module()
    reason = ("browser_agent module is missing" if mod is None else
              (mod.capabilities() or {}).get("reason", "driver not available"))
    _text(request_id, "Cannot %s: %s" % (action, reason), True)


def _trim(value, limit=MAX_TEXT):
    text = str(value or "")
    return text[:limit] + ("..." if len(text) > limit else "")


def _handle(request_id, params):
    name = params.get("name")
    args = params.get("arguments") or {}
    mod = _driver_module()
    if mod is None or not mod.available():
        return _not_ready(request_id, name or "use the browser")

    if name == "browse":
        out = mod.navigate(args.get("url", ""))
        if not out.get("ok"):
            return _text(request_id, out.get("error", "browse failed"), True)
        _remember_url(out.get("url", ""))
        return _text(request_id, json.dumps({
            "url": out.get("url"), "title": out.get("title"),
            "http_status": out.get("status"),
            "text": _trim(out.get("text"))}))

    if name == "read_page":
        out = mod.read_text(args.get("url", "") or "")
        if not out.get("ok"):
            if not _restore(mod):
                return _text(request_id, "no page open and no previous URL "
                                         "to restore; call browse first", True)
            out = mod.read_text("")
        if out.get("url"):
            _remember_url(out.get("url", ""))
        return _text(request_id, json.dumps({
            "url": out.get("url"), "title": out.get("title"),
            "text": _trim(out.get("text"))}))

    if name == "list_links":
        if not _restore(mod):
            return _text(request_id, "no page open; call browse first", True)
        page, err = mod._ensure_page()
        if page is None:
            return _text(request_id, err or "no page", True)
        try:
            links = page.eval_on_selector_all(
                "a[href]",
                "els => els.slice(0,40).map(e => ({text: "
                "(e.innerText||'').trim().slice(0,80), href: e.href}))")
        except Exception as exc:
            return _text(request_id, "list_links failed: %s"
                         % type(exc).__name__, True)
        return _text(request_id, json.dumps({
            "url": page.url, "count": len(links), "links": links}))

    if name == "find_text":
        query = str(args.get("query") or "").strip()[:120]
        if not query:
            return _text(request_id, "find_text needs a query", True)
        if not _restore(mod):
            return _text(request_id, "no page open; call browse first", True)
        out = mod.read_text("")
        if not out.get("ok"):
            return _text(request_id, out.get("error", "read failed"), True)
        body = out.get("text") or ""
        at = body.casefold().find(query.casefold())
        return _text(request_id, json.dumps({
            "query": query, "found": at >= 0, "url": out.get("url"),
            "excerpt": body[max(0, at - 120): at + len(query) + 160] if at >= 0 else ""}))

    if name == "screenshot":
        if not _restore(mod):
            return _text(request_id, "no page open; call browse first", True)
        out = mod.screenshot(str(args.get("name") or "mcp"))
        if not out.get("ok"):
            return _text(request_id, out.get("error", "screenshot failed"), True)
        return _text(request_id, json.dumps(out))

    if name == "click":
        if not _restore(mod):
            return _text(request_id, "no page open; call browse first", True)
        out = mod.click(str(args.get("selector") or ""))
        if not out.get("ok"):
            return _text(request_id, out.get("error", "click failed"), True)
        _remember_url(out.get("url", ""))
        return _text(request_id, json.dumps(out))

    if name == "fill":
        if not _restore(mod):
            return _text(request_id, "no page open; call browse first", True)
        out = mod.type_text(str(args.get("selector") or ""),
                            str(args.get("text") or ""))
        if not out.get("ok"):
            return _text(request_id, out.get("error", "fill failed"), True)
        return _text(request_id, json.dumps(out))

    return _text(request_id, "unknown tool: %s" % name, True)


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, request_id = message.get("method"), message.get("id")
        if method == "initialize":
            _reply(request_id, {"protocolVersion": "2024-11-05",
                                "capabilities": {"tools": {}},
                                "serverInfo": {"name": "jarvis-browser",
                                               "version": "1.0.0"}})
        elif method == "tools/list":
            _reply(request_id, {"tools": TOOLS})
        elif method == "tools/call":
            try:
                _handle(request_id, message.get("params") or {})
            except Exception as exc:
                _text(request_id, "%s: %s" % (type(exc).__name__, exc), True)
        elif request_id is not None:
            _reply(request_id, {"error": {"code": -32601,
                        "message": "method not found: %s" % method}})


if __name__ == "__main__":
    main()
