"""Tests for the presentation_builder module (Automated Presentation Builder).

Verifies slide deck normalization, PPTX file rendering, disk reopening validation,
and theme support without requiring network or external LLM calls.
"""
from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(name: str):
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    spec = importlib.util.spec_from_file_location(full, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


BUILDER = _load("presentation_builder")


class PresentationBuilderTest(unittest.TestCase):
    def test_capabilities_returns_truthful_state(self):
        cap = BUILDER.capabilities()
        self.assertIsInstance(cap, dict)
        self.assertIn("pptx", cap)
        self.assertTrue(cap["pptx"], "python-pptx should be installed in virtualenv")
        self.assertIn("themes", cap)
        self.assertIn("jarvis", cap["themes"])
        self.assertIn("midnight", cap["themes"])

    def test_normalise_handles_dict_structure(self):
        deck = {
            "title": "Quantum Computing",
            "subtitle": "Principles & Horizons",
            "slides": [
                {"heading": "Introduction", "bullets": ["Qubits and superposition", "Entanglement"], "speaker_notes": "Note 1"},
                {"heading": "Hardware", "bullets": ["Superconducting circuits", "Trapped ions"], "speaker_notes": "Note 2"},
            ],
        }
        title, subtitle, slides = BUILDER._normalise(deck)
        self.assertEqual(title, "Quantum Computing")
        self.assertEqual(subtitle, "Principles & Horizons")
        self.assertEqual(len(slides), 2)
        self.assertEqual(slides[0]["heading"], "Introduction")
        self.assertEqual(len(slides[0]["bullets"]), 2)
        self.assertEqual(slides[0]["speaker_notes"], "Note 1")

    def test_render_pptx_creates_and_verifies_file(self):
        deck = {
            "title": "Autonomous Agents",
            "subtitle": "Architecture & Operations",
            "slides": [
                {
                    "heading": "Core Loop",
                    "bullets": ["Perceive environment", "Plan actions", "Execute with verification"],
                    "speaker_notes": "Emphasize loopback and safety gates.",
                },
                {
                    "heading": "Tool Integration",
                    "bullets": ["Strict allowlisting", "Confirmation required for external I/O"],
                    "speaker_notes": "Point to permissions.json.",
                },
            ],
        }
        with tempfile.TemporaryDirectory() as tmpdir:
            out_path = Path(tmpdir) / "test_deck.pptx"
            ok, detail = BUILDER.render_pptx(deck, out_path, theme="jarvis")
            self.assertTrue(ok, "render_pptx failed: %s" % detail)
            self.assertTrue(out_path.exists(), "PPTX file was not written to disk")
            self.assertGreater(out_path.stat().st_size, 1000, "PPTX file is unexpectedly small")
            self.assertIn("slide(s)", detail)

            # Strict verification: inspect via python-pptx
            from pptx import Presentation
            prs = Presentation(str(out_path))
            # 1 Title slide + 2 Content slides = 3 slides total
            self.assertEqual(len(prs.slides), 3)

    def test_create_presentation_rejects_empty_topic(self):
        res = BUILDER.create_presentation("")
        self.assertFalse(res["ok"])
        self.assertIn("no topic", res.get("error", ""))


if __name__ == "__main__":
    unittest.main()
