"""jarvis-modules: the real backing for the Modules & Upgrades matrix.

The old Modules page was 48 hardcoded standby cards that did nothing. This
plugin replaces that fiction with a live, honest matrix and ships the NEW
capabilities as callable tools.

It is strictly ADDITIVE and reuses the systems that already exist:
  * the tools land in the real cortex ToolRegistry via register_plugin_tools()
  * every handler is wrapped by the real permission engine (background/permissions.py)
  * the new capability code lives in background/ modules (telemetry, scheduler_core,
    focus_analytics, ocr_engine, video_editor, capability_registry) - no logic is
    reimplemented here, this plugin only exposes them.
  * destructive/new-write actions declare requires_confirmation so the existing
    cortex confirm gate still asks the user.

There is no second tool registry, no second permission system, and no new
model download. All inference stays local.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent


def _bg(name: str):
    """Load a background module under the shared cowork key."""
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    if not path.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location(full, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[full] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


# ── handlers: thin, and every one delegates to the real module ──────────────
def _call(name: str, args: dict, method: str, spec_keys=()):
    mod = _bg(name)
    if mod is None:
        return {"ok": False, "output": "%s module unavailable" % name}
    fn = getattr(mod, method, None)
    if not callable(fn):
        return {"ok": False, "output": "%s.%s missing" % (name, method)}
    kwargs = {}
    for key in spec_keys:
        if (args or {}).get(key) not in (None, ""):
            kwargs[key] = args[key]
    try:
        return fn(args, **kwargs) if spec_keys else fn(args)
    except Exception as exc:
        return {"ok": False,
                "output": "%s failed: %s: %s" % (name, type(exc).__name__, exc)}


def _handle_modules(args):
    return _call("capability_registry", args or {}, "_tool_modules")


def _handle_module_detail(args):
    return _call("capability_registry", args or {}, "_tool_module_detail")


def _handle_telemetry(args):
    return _call("telemetry", args or {}, "_tool_snapshot")


def _handle_top_processes(args):
    return _call("telemetry", args or {}, "_tool_top")


def _handle_focus(args):
    return _call("focus_analytics", args or {}, "_tool_focus")


def _handle_ocr_status(args):
    return _call("ocr_engine", args or {}, "_tool_ocr_status")


def _handle_read_document(args):
    return _call("ocr_engine", args or {}, "_tool_read_document")


def _handle_video_status(args):
    return _call("video_editor", args or {}, "_tool_video_status")


def _handle_cut_silence(args):
    return _call("video_editor", args or {}, "_tool_cut_silence")


def _handle_caption(args):
    return _call("video_editor", args or {}, "_tool_caption")


def _handle_scene_labels(args):
    return _call("video_editor", args or {}, "_tool_scene_labels")


def _handle_set_timer(args):
    return _call("scheduler_core", args or {}, "_tool_set_timer")


def _handle_repeat(args):
    return _call("scheduler_core", args or {}, "_tool_schedule_every")


def _handle_at(args):
    return _call("scheduler_core", args or {}, "_tool_schedule_at")


def _handle_cancel_timer(args):
    return _call("scheduler_core", args or {}, "_tool_cancel")


def _handle_save_workflow(args):
    return _call("scheduler_core", args or {}, "_tool_save_workflow")


def _handle_run_workflow(args):
    return _call("scheduler_core", args or {}, "_tool_run_workflow")


def _handle_scheduler_status(args):
    return _call("scheduler_core", args or {}, "_tool_scheduler_status")


def _handle_writer_capabilities(args):
    return _call("content_writer", args or {}, "_tool_capabilities")


def _handle_write_document(args):
    return _call("content_writer", args or {}, "_tool_write_document")


def _handle_presentation_capabilities(args):
    return _call("presentation_builder", args or {}, "_tool_capabilities")


def _handle_create_presentation(args):
    return _call("presentation_builder", args or {}, "_tool_create_presentation")


# ── Document RAG (Phase 2, background/doc_index.py) ────────────────────────
def _handle_doc_search(args):
    return _call("doc_index", args or {}, "_tool_doc_search")


def _handle_doc_index(args):
    return _call("doc_index", args or {}, "_tool_doc_index")


def _handle_doc_status(args):
    return _call("doc_index", args or {}, "_tool_doc_status")


# ── Calendar (Phase 4, background/calendar_ics.py) ─────────────────────────
def _handle_calendar_status(args):
    return _call("calendar_ics", args or {}, "_tool_calendar_status")


def _handle_calendar_connect(args):
    return _call("calendar_ics", args or {}, "_tool_calendar_connect")


def _handle_calendar_disconnect(args):
    return _call("calendar_ics", args or {}, "_tool_calendar_disconnect")


def _handle_calendar_today(args):
    return _call("calendar_ics", args or {}, "_tool_calendar_today")


def _handle_calendar_upcoming(args):
    return _call("calendar_ics", args or {}, "_tool_calendar_upcoming")


# ── Data Forge (Phase 6.2, background/data_forge.py) ────────────────────────
def _handle_data_status(args):
    return _call("data_forge", args or {}, "_tool_data_forge_status")


def _handle_data_create(args):
    return _call("data_forge", args or {}, "_tool_data_forge_create")


def _handle_data_telemetry(args):
    return _call("data_forge", args or {}, "_tool_data_forge_telemetry")


def _handle_data_query(args):
    return _call("data_forge", args or {}, "_tool_data_forge_query")


# The contract background/extensions.py reads when registering into the real
# cortex ToolRegistry. permission_category selects the real permission bucket:
# read-only tools use read_files, anything that writes or renders uses
# edit_files/execute_commands so the confirm gate still applies.
TOOLS = [
    {"name": "modules_status",
     "description": "Honest Modules & Upgrades matrix: live/ready/blocked counts.",
     "handler": _handle_modules, "permission_category": "read_files",
     "parameters": {"state": "LIVE|READY|BLOCKED"},
     "requires_confirmation": False},
    {"name": "modules_detail",
     "description": "One module card with its real state and reason.",
     "handler": _handle_module_detail, "permission_category": "read_files",
     "parameters": {"id": "capability id"},
     "requires_confirmation": False},
    {"name": "telemetry_snapshot",
     "description": "Real local CPU/RAM/disk/process/battery snapshot.",
     "handler": _handle_telemetry, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "telemetry_top_processes",
     "description": "Top local processes by memory, sampled live.",
     "handler": _handle_top_processes, "permission_category": "read_files",
     "parameters": {"limit": "how many rows (1-20)"},
     "requires_confirmation": False},
    {"name": "focus_analytics",
     "description": "Real measured foreground-app usage and screen time.",
     "handler": _handle_focus, "permission_category": "read_files",
     "parameters": {"limit": "how many apps (1-40)"},
     "requires_confirmation": False},
    {"name": "ocr_status",
     "description": "Which OCR paths are really available on this machine.",
     "handler": _handle_ocr_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "read_document",
     "description": "Extract real text from a local PDF or image.",
     "handler": _handle_read_document, "permission_category": "read_files",
     "parameters": {"path": "file path"}, "requires_confirmation": False},
    {"name": "video_editor_status",
     "description": "Which video stages (silence cut, captions, scene labels) are real.",
     "handler": _handle_video_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "video_cut_silence",
     "description": "Detect and remove real silence from a local video.",
     "handler": _handle_cut_silence, "permission_category": "edit_files",
     "parameters": {"path": "video file path", "min_silence_s": "seconds"},
     "requires_confirmation": True},
    {"name": "video_caption",
     "description": "Transcribe a local video/audio with local Whisper to .srt.",
     "handler": _handle_caption, "permission_category": "edit_files",
     "parameters": {"path": "media file path", "model": "tiny|base"},
     "requires_confirmation": True},
    {"name": "video_scene_labels",
     "description": "Label sampled video frames with the local perception model.",
     "handler": _handle_scene_labels, "permission_category": "read_files",
     "parameters": {"path": "video file path"},
     "requires_confirmation": False},
    {"name": "scheduler_set_timer",
     "description": "Arm a one-shot or recurring timer for a JARVIS command.",
     "handler": _handle_set_timer, "permission_category": "execute_commands",
     "parameters": {"command": "command to run", "seconds": "one-shot seconds",
                    "interval_s": "recurring seconds", "label": "label"},
     "requires_confirmation": True},
    {"name": "scheduler_repeat",
     "description": "Repeat a command on an interval (e.g. 30m).",
     "handler": _handle_repeat, "permission_category": "execute_commands",
     "parameters": {"command": "command", "every": "30m|2h|1d"},
     "requires_confirmation": True},
    {"name": "scheduler_at",
     "description": "Schedule a command for a clock time (09:30, mon 09:30).",
     "handler": _handle_at, "permission_category": "execute_commands",
     "parameters": {"command": "command", "when": "clock time"},
     "requires_confirmation": True},
    {"name": "scheduler_cancel",
     "description": "Cancel an armed timer by id.",
     "handler": _handle_cancel_timer, "permission_category": "execute_commands",
     "parameters": {"id": "timer id"}, "requires_confirmation": True},
    {"name": "automation_save_workflow",
     "description": "Save a named, ordered list of commands (no execution).",
     "handler": _handle_save_workflow, "permission_category": "edit_files",
     "parameters": {"name": "workflow name", "steps": "list of commands"},
     "requires_confirmation": True},
    {"name": "automation_run_workflow",
     "description": "Return the ordered steps of a saved workflow to run.",
     "handler": _handle_run_workflow, "permission_category": "execute_commands",
     "parameters": {"name": "workflow name"}, "requires_confirmation": True},
    {"name": "scheduler_status",
     "description": "Armed timers, saved workflows and run history.",
     "handler": _handle_scheduler_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    # ── Professional Content Writer (background/content_writer.py) ──
    # Real web research (Firecrawl) + a real LLM + a real PDF/DOCX file on
    # disk. It WRITES a new file, so it is gated under edit_files and asks for
    # confirmation like any other write.
    {"name": "writer_capabilities",
     "description": "What the content writer can really do on this machine "
                    "right now (research, writing models, PDF, DOCX).",
     "handler": _handle_writer_capabilities, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "write_document",
     "description": "Research one or more topics on the live web and write a "
                    "professional PDF and/or DOCX document into the Artifacts "
                    "list. Returns the real file names, word count, source "
                    "count and the model that produced the text.",
     "handler": _handle_write_document, "permission_category": "edit_files",
     "parameters": {"topics": "topic or list of topics",
                    "format": "pdf | docx | both",
                    "tone": "writing tone", "audience": "target audience",
                    "length": "brief | standard | deep",
                    "research": "true to run live web research"},
     # This tool is NOT a 20s tool. It performs live web search, an LLM write,
     # and a PDF/DOCX render. The cortex default (20s) killed every real run with
     # "timed out after 20.0s" BEFORE the document was produced - the UI then
     # showed a failed node and an empty Artifacts list even though the whole
     # pipeline worked when called directly. The timeout is a cooperative join
     # bound on a daemon thread, not a hard kill, so a generous budget is safe:
     # the flow can still be cancelled and an approval still times out at 900s.
     "timeout_s": 900.0,
     "requires_confirmation": True},
    # ── Presentation Builder (background/presentation_builder.py) ──
    # Real web research + the real model chain + python-pptx -> a real, themed
    # .pptx on disk, opened in PowerPoint. Writes a new file, so it is gated
    # under edit_files with the same generous timeout as write_document (live
    # research + LLM + render far exceeds the cortex 20s default).
    {"name": "presentation_capabilities",
     "description": "What presentation building can really do on this machine "
                    "right now (python-pptx, research, model chain, themes).",
     "handler": _handle_presentation_capabilities,
     "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "create_presentation",
     "description": "Research a topic on the live web, ask the live model chain "
                    "to design slides, write a real themed .pptx into "
                    "artifacts/presentations and open it in PowerPoint. "
                    "Example: 'make a 6-slide presentation on AGI'.",
     "handler": _handle_create_presentation,
     "permission_category": "edit_files",
     "parameters": {"topic": "presentation topic",
                    "slides_count": "content slides, 1-15 (default 6)",
                    "theme": "jarvis | midnight | minimal | corporate",
                    "research": "true to run live web research",
                    "open_after": "open the deck when built (default true)"},
     "timeout_s": 900.0,
     "requires_confirmation": True},
    # ── Document RAG (background/doc_index.py, Phase 2) ─────────────────────
    # Real local RAG over the user's own files: PyMuPDF/python-docx/python-pptx
    # extraction + local ChromaDB embeddings. Search is read-only; indexing
    # only READS user files and writes to the JARVIS store, and it runs on a
    # background thread so it can never hit the cortex timeout.
    {"name": "doc_search",
     "description": "Semantic search across the user's indexed documents "
                    "(Desktop/Documents: PDF, DOCX, PPTX, txt, md, csv). "
                    "Returns exact file name + page citations.",
     "handler": _handle_doc_search, "permission_category": "read_files",
     "parameters": {"query": "what to search for",
                    "k": "how many results, 1-10"},
     "requires_confirmation": False},
    {"name": "doc_index",
     "description": "Index or refresh the document knowledge base on a "
                    "background thread (incremental by mtime/size; reports "
                    "real scanned/indexed/no_text counts).",
     "handler": _handle_doc_index, "permission_category": "read_files",
     "parameters": {"roots": "optional folder path(s), ';' separated",
                    "include_code": "also index code/config files",
                    "limit": "max files this run",
                    "reset": "wipe and rebuild the index"},
     "requires_confirmation": False},
    {"name": "doc_index_status",
     "description": "Honest document-index state: files, chunks, roots, "
                    "last run, no-text files, errors.",
     "handler": _handle_doc_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},

    # ── Calendar (Phase 4, background/calendar_ics.py) ──────────────────────
    # FREE and READ-ONLY: a calendar is read through its secret iCal feed, so
    # there is no OAuth client, no cloud console and no bank account. Setting the
    # feed stores a bearer secret (DPAPI-encrypted), so it is the one gated
    # action; every read is read_files.
    {"name": "calendar_status",
     "description": "Honest calendar feed state: a feed configured, stored "
                    "DPAPI-encrypted, read-only, no OAuth. No network call.",
     "handler": _handle_calendar_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "calendar_connect",
     "description": "Set the calendar from a private iCal feed URL (Google "
                    "Calendar -> Integrate calendar -> secret address) or a "
                    "local .ics file. The URL is a bearer secret and is stored "
                    "encrypted with Windows DPAPI.",
     "handler": _handle_calendar_connect, "permission_category": "communication",
     "parameters": {"url": "the secret iCal address or a .ics file path"},
     "timeout_s": 60.0, "requires_confirmation": True},
    {"name": "calendar_disconnect",
     "description": "Forget the stored feed URL locally. Nothing is changed in "
                    "Google - the feed itself stays exactly as it was.",
     "handler": _handle_calendar_disconnect,
     "permission_category": "communication",
     "parameters": {}, "requires_confirmation": True},
    {"name": "calendar_today",
     "description": "Today's real agenda in local time, all-day events "
                    "included, recurring events expanded and sorted by start.",
     "handler": _handle_calendar_today, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "calendar_upcoming",
     "description": "The next N real calendar events from now.",
     "handler": _handle_calendar_upcoming, "permission_category": "read_files",
     "parameters": {"n": "how many, 1-25 (default 5)"},
     "requires_confirmation": False},

    # ── Data Forge (Phase 6.2, background/data_forge.py) ─────────────────────
    # Writes NEW dataset files into artifacts/datasets, so it sits in edit_files
    # (ASK) rather than read_files. SQL is restricted to SELECT/WITH by the
    # module itself, and telemetry_dataset only reads the local machine.
    {"name": "data_forge_status",
     "description": "Honest dataset state: engine (duckdb or stdlib), parquet "
                    "support, and the real dataset files produced so far.",
     "handler": _handle_data_status, "permission_category": "read_files",
     "parameters": {}, "requires_confirmation": False},
    {"name": "data_forge_create",
     "description": "Write a real .csv/.tsv/.jsonl/.parquet dataset from a file "
                    "path or from rows. A requested format is never silently "
                    "downgraded: parquet without DuckDB fails with the reason.",
     "handler": _handle_data_create, "permission_category": "edit_files",
     "parameters": {"path": "a real .csv/.jsonl/.parquet file to convert",
                    "rows": "or a JSON array of row objects",
                    "name": "dataset name", "format": "csv|tsv|jsonl|parquet"},
     "timeout_s": 120.0, "requires_confirmation": True},
    {"name": "data_forge_telemetry",
     "description": "Build a dataset from this machine's REAL telemetry "
                    "(CPU per core, RAM, disk free space, battery) - no sample "
                    "rows are invented.",
     "handler": _handle_data_telemetry, "permission_category": "edit_files",
     "parameters": {}, "timeout_s": 60.0, "requires_confirmation": True},
    {"name": "data_forge_query",
     "description": "Read-only SQL (SELECT/WITH) over the produced datasets "
                    "via DuckDB. Writes and DDL are refused.",
     "handler": _handle_data_query, "permission_category": "read_files",
     "parameters": {"sql": "SELECT ... FROM 'artifacts/datasets/x.parquet'",
                    "limit": "max rows (default 50)"},
     "timeout_s": 60.0, "requires_confirmation": False},

]

