"""Automated Presentation Builder: topic -> styled .pptx deck.

ADDITIVE. Reuses the systems that already exist and adds no second brain, no
second permission engine and no second registry:

  * RESEARCH  background/content_writer.research()  - real Firecrawl search
  * DRAFT     background/content_writer.llm()        - the real provider chain
              (OpenRouter preferred -> xKiro free floor -> Groq), and the model
              that actually answered is reported back by name.
  * PARSE     background/content_writer._json_object() - fence-tolerant JSON
  * RENDER    python-pptx                            - a real .pptx on disk
  * PUBLISH   artifacts/presentations/ and os.startfile opens it in PowerPoint
              (the same guarded open os_executor uses; .pptx is not an exec).

Exposed through the real cortex ToolRegistry via the jarvis-modules plugin.
Every stage reports failure honestly: a research/model error is returned with a
reason, and ``ok`` is True only when a REAL file exists on disk. Never fabricates
a slide count, a source, or a claim the notes do not support.
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PPT_DIR = ROOT / "artifacts" / "presentations"

MAX_TITLE = 160
MAX_TOPIC = 400
MAX_SLIDES = 20
MAX_BULLETS = 8
MAX_BULLET = 320
MAX_NOTES = 1200

# Load .env / .dev.vars exactly like content_writer so the shared keys resolve.
try:
    from dotenv import dotenv_values as _dotenv_values

    for _f in (".env", ".dev.vars"):
        _p = os.path.join(ROOT, _f)
        if os.path.isfile(_p):
            for _k, _v in _dotenv_values(_p).items():
                if _v and not os.environ.get(_k):
                    os.environ[_k] = _v
except Exception:
    pass


def _bg(name: str):
    """Load a background module under the shared cowork key (one identity)."""
    import importlib.util
    import sys

    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    if not path.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location(full, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[full] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _cw():
    """The content_writer module, reused for research + the real LLM chain."""
    return _bg("content_writer")


def _clean(value, limit=MAX_TOPIC) -> str:
    text = str(value or "").replace("\x00", "").strip()
    return text[:limit]


def _slug(value) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return (text or "deck")[:60]


# ── themes: name -> {bg, title, text, accent, subtle} hex (no '#') ─────────────
_THEMES = {
    "jarvis": {"bg": "0B1220", "title": "22D3EE", "text": "E5E7EB",
               "accent": "22D3EE", "subtle": "94A3B8"},
    "midnight": {"bg": "0F172A", "title": "38BDF8", "text": "E2E8F0",
                 "accent": "38BDF8", "subtle": "94A3B8"},
    "minimal": {"bg": "FFFFFF", "title": "111827", "text": "1F2937",
                "accent": "2563EB", "subtle": "6B7280"},
    "corporate": {"bg": "FFFFFF", "title": "1E3A8A", "text": "111827",
                  "accent": "1D4ED8", "subtle": "475569"},
}


def capabilities() -> dict:
    """What this module can really do on THIS machine, right now."""
    pptx_ok, pptx_note = True, "python-pptx available."
    try:
        import pptx  # noqa: F401
    except Exception as exc:
        pptx_ok = False
        pptx_note = "python-pptx not installed: %s" % type(exc).__name__
    cw = _cw()
    cap = cw.capabilities() if cw is not None else {}
    return {
        "pptx": pptx_ok,
        "pptx_note": pptx_note,
        "research": bool(cap.get("research")),
        "research_note": cap.get("research_note", "content_writer unavailable"),
        "writing": bool(cw is not None) and bool(cap.get("writing")),
        "writing_note": cap.get("writing_note", "content_writer unavailable"),
        "writing_providers": cap.get("writing_providers", []),
        "preferred_models": cap.get("preferred_models", []),
        "fallback_models": cap.get("fallback_models", []),
        "themes": sorted(_THEMES.keys()),
    }


# ── stage 1: real web research (reused from content_writer) ────────────────────
def research(topic: str) -> tuple:
    """Real Firecrawl search via content_writer. Returns (notes, sources, errors)."""
    cw = _cw()
    if cw is None:
        return "", [], ["content_writer unavailable"]
    found = cw.research([_clean(topic, 200)])
    return (found.get("notes", ""), found.get("sources", []),
            found.get("errors", []))


# ── stage 2: ask the real model chain for the slide JSON ───────────────────────
def _system(theme: str) -> str:
    return (
        "You are a presentation designer. Given a topic and optional research "
        "notes, produce a clear, factual slide deck. Ground every claim in the "
        "notes; never invent statistics or citations. Answer ONLY with valid "
        "JSON and no markdown fence, matching this schema exactly:\n"
        '{"title": string, "subtitle": string, "slides": '
        '[{"heading": string, "bullets": [string, ...], '
        '"speaker_notes": string}]}\n'
        "Rules: the FIRST slide is the title slide (heading empty, no bullets). "
        "Content bullets are short (4-7 words each), 3-6 per slide. "
        "Theme: %s." % theme
    )


def compose(topic: str, notes: str, sources: list, slides_count: int,
            theme: str) -> tuple:
    """Ask the real model chain for slide JSON. Returns (deck, meta)."""
    cw = _cw()
    if cw is None:
        return {}, {"model": "", "provider": "", "attempted": [],
                    "fallbacks": ["content_writer unavailable"]}
    src = "\n".join("- %s (%s)" % (s.get("title", "Source"), s.get("url", ""))
                    for s in (sources or [])[:12])
    prompt = (
        "TOPIC: %s\n\n"
        "RESEARCH NOTES (the only factual basis you have):\n%s\n\n"
        "SOURCES:\n%s\n\n"
        "Build a deck of about %d content slides plus one title slide. Return "
        "the JSON object only." % (topic, notes or "(none)", src or "(none)",
                                   slides_count))
    text, meta = cw.llm([{"role": "system", "content": _system(theme)},
                         {"role": "user", "content": prompt}], max_tokens=3000)
    deck = cw._json_object(text)
    if not deck and text:
        # A model that returned prose still produced real work; keep it on one
        # slide rather than discarding the tokens.
        deck = {"title": topic, "subtitle": "",
                "slides": [{"heading": "", "bullets": [],
                            "speaker_notes": _clean(text, MAX_NOTES)}]}
        meta["degraded"] = "model returned prose, not slide JSON"
    deck["_sources"] = sources
    deck["_topic"] = topic
    return deck, meta


# ── stage 3: real .pptx rendering (python-pptx) ────────────────────────────────
def _hex(value: str):
    """'22D3EE' -> RGBColor. Falls back to cyan on any problem."""
    from pptx.dml.color import RGBColor
    try:
        return RGBColor.from_string(str(value).lstrip("#").upper()[:6])
    except Exception:
        return RGBColor.from_string("22D3EE")


def _normalise(deck: dict) -> tuple:
    """Pull a clean (title, subtitle, slides) out of whatever the model returned.

    Never invents a slide that the model did not produce; only trims and clamps.
    """
    title = _clean(deck.get("title"), MAX_TITLE) or _clean(deck.get("_topic"), MAX_TITLE) or "Presentation"
    subtitle = _clean(deck.get("subtitle"), 200)
    raw = deck.get("slides")
    slides = [s for s in raw if isinstance(s, dict)] if isinstance(raw, list) else []
    out = []
    for s in slides[:MAX_SLIDES]:
        bullets = [_clean(b, MAX_BULLET) for b in (s.get("bullets") or [])
                   if _clean(b, MAX_BULLET)]
        out.append({
            "heading": _clean(s.get("heading"), 160),
            "bullets": bullets[:MAX_BULLETS],
            "speaker_notes": _clean(s.get("speaker_notes"), MAX_NOTES),
        })
    return title, subtitle, out


def render_pptx(deck: dict, path: Path, theme: str = "jarvis") -> tuple:
    """Write a real, themed .pptx. Returns (ok, detail)."""
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
    except Exception as exc:
        return False, "python-pptx not installed: %s" % type(exc).__name__
    try:
        pal = _THEMES.get(str(theme or "jarvis").lower(), _THEMES["jarvis"])
        title, subtitle, slides = _normalise(deck)
        if not slides:
            return False, "no slides to render"
        prs = Presentation()
        prs.slide_width = Inches(13.333)
        prs.slide_height = Inches(7.5)
        blank = prs.slide_layouts[6]
        bg, fg, accent, subtle = (pal["bg"], pal["title"], pal["accent"], pal["subtle"])

        def _bg(slide):
            try:
                slide.background.fill.solid()
                slide.background.fill.fore_color.rgb = _hex(bg)
            except Exception:
                pass

        def _line(slide, l, t, w, h, text, size, color, bold=False):
            box = slide.shapes.add_textbox(l, t, w, h)
            tf = box.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            run = p.add_run()
            run.text = text
            run.font.size = Pt(size)
            run.font.bold = bold
            run.font.color.rgb = _hex(color)
            return box

        # Title slide
        slide = prs.slides.add_slide(blank)
        _bg(slide)
        _line(slide, Inches(0.8), Inches(2.6), Inches(11.7), Inches(1.6),
              title, 40, fg, bold=True)
        if subtitle:
            _line(slide, Inches(0.8), Inches(4.2), Inches(11.7), Inches(0.8),
                  subtitle, 18, subtle)

        # Content slides
        for s in slides:
            slide = prs.slides.add_slide(blank)
            _bg(slide)
            if s["heading"]:
                _line(slide, Inches(0.6), Inches(0.5), Inches(12.1), Inches(0.9),
                      s["heading"], 28, fg, bold=True)
                # thin accent rule under the heading
                rule = slide.shapes.add_textbox(Inches(0.7), Inches(1.45),
                                                Inches(2.0), Inches(0.06))
                rule.fill.solid()
                rule.fill.fore_color.rgb = _hex(accent)
                rule.line.fill.background()
            top = Inches(2.0) if s["heading"] else Inches(1.0)
            if s["bullets"]:
                box = slide.shapes.add_textbox(Inches(0.8), top,
                                               Inches(11.7), Inches(4.8))
                tf = box.text_frame
                tf.word_wrap = True
                for i, bullet in enumerate(s["bullets"]):
                    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                    run = p.add_run()
                    run.text = "\u2022  " + bullet
                    run.font.size = Pt(18)
                    run.font.color.rgb = _hex(pal["text"])
                    p.space_after = Pt(10)
            if s["speaker_notes"]:
                slide.notes_slide.notes_text_frame.text = s["speaker_notes"]

        path.parent.mkdir(parents=True, exist_ok=True)
        prs.save(str(path))
        # Reopen to strictly verify file integrity on disk
        reopened = Presentation(str(path))
        actual_count = len(reopened.slides)
        return True, "%d slide(s)" % actual_count
    except Exception as exc:
        return False, "pptx render failed: %s: %s" % (type(exc).__name__, exc)


# ── stage 4: orchestrate + publish into artifacts/presentations ────────────────
def _open_in_powerpoint(path: Path) -> str:
    """Open the finished deck the same guarded way os_executor opens documents.

    Returns a short honest status string; a failure here never fails the build
    (the file already exists on disk).
    """
    try:
        os.startfile(str(path))  # noqa: S606  (local, user-confirmed .pptx)
        return "opened in PowerPoint"
    except Exception as exc:
        return "saved; auto-open failed: %s" % type(exc).__name__


def create_presentation(topic_raw, slides_count: int = 6, theme: str = "jarvis",
                        do_research: bool = True, open_after: bool = True) -> dict:
    """Full pipeline. ``ok`` is True only when a REAL .pptx exists on disk."""
    topic = _clean(topic_raw, MAX_TOPIC)
    if not topic:
        return {"ok": False, "error": "no topic given",
                "hint": "e.g. create_presentation('Artificial General Intelligence', 6)"}
    try:
        slides_count = int(slides_count)
    except Exception:
        slides_count = 6
    slides_count = max(1, min(slides_count, 15))
    theme = str(theme or "jarvis").lower()
    if theme not in _THEMES:
        theme = "jarvis"
    started = time.time()
    notes, sources, research_errors = "", [], []
    if do_research:
        notes, sources, research_errors = research(topic)
    deck, meta = compose(topic, notes, sources, slides_count, theme)
    if not deck or not deck.get("slides"):
        return {"ok": False, "error": "no model produced a deck",
                "providers": meta.get("attempted") or [],
                "failures": meta.get("fallbacks") or [],
                "research_errors": research_errors}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = "%s-%s.pptx" % (_slug(deck.get("title") or topic), stamp)
    path = PPT_DIR / base
    ok, detail = render_pptx(deck, path, theme)
    if not ok:
        return {"ok": False, "error": detail,
                "providers": meta.get("attempted") or [],
                "failures": meta.get("fallbacks") or []}
    title, subtitle, slides = _normalise(deck)
    opened = _open_in_powerpoint(path) if open_after else "not opened (open_after=False)"
    return {
        "ok": True,
        "title": title,
        "subtitle": subtitle,
        "slide_count": len(slides),
        "theme": theme,
        "file": {"name": path.name, "path": "presentations/" + path.name,
                 "abs_path": str(path), "bytes": path.stat().st_size,
                 "detail": detail},
        "source_count": len(sources),
        "model": meta.get("model", ""),
        "provider": meta.get("provider", ""),
        "fallbacks": meta.get("fallbacks") or [],
        "degraded": meta.get("degraded", ""),
        "research_errors": research_errors,
        "open_status": opened,
        "elapsed_s": round(time.time() - started, 1),
    }


# ── tool handlers (called through the real permission engine) ──────────────────
def _tool_capabilities(args):
    return {"ok": True, "output": capabilities()}


def _tool_create_presentation(args):
    args = args or {}
    result = create_presentation(
        args.get("topic") or args.get("input") or "",
        slides_count=args.get("slides_count") or args.get("slides") or 6,
        theme=str(args.get("theme") or args.get("style_theme") or "jarvis"),
        do_research=bool(args.get("research", True)),
        open_after=bool(args.get("open_after", True)))
    if not result.get("ok"):
        return {"ok": False, "output": result.get("error", "failed"),
                "detail": result}
    summary = ("%s\n%s | %d slides | %d sources | theme:%s | model: %s\n%s" % (
        result["title"], result["file"]["name"], result["slide_count"],
        result["source_count"], result["theme"], result["model"] or "unknown",
        result["open_status"]))
    if result.get("fallbacks"):
        summary += "\nFallbacks used: %s" % "; ".join(result["fallbacks"])
    return {"ok": True, "output": summary, "files": [result["file"]],
            "detail": result}


# ── registry specs (the SAME names the plugin advertises) ──────────────────────
def specs() -> list:
    return [
        {"name": "create_presentation",
         "func": _tool_create_presentation,
         "requires_confirmation": True,
         "description": "Build a real, themed .pptx deck on a topic (researches "
                        "the web, asks the live model chain for slides, writes "
                        "the file and opens it)."},
        {"name": "presentation_capabilities",
         "func": _tool_capabilities,
         "requires_confirmation": False,
         "description": "Report whether .pptx building, research and the model "
                        "chain actually work on this machine right now."},
    ]



