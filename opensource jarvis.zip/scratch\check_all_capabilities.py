import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import background.capability_registry as cr

snap = cr.snapshot(force=True)
counts = snap["counts"]
print(f'TOTAL: {snap["total"]} | LIVE: {counts.get("LIVE", 0)} | READY: {counts.get("READY", 0)} | BLOCKED: {counts.get("BLOCKED", 0)}')

print('\n--- READY MODULES ---')
for row in snap["capabilities"]:
    if row["state"] == "READY":
        print(f'  {row["id"]}: {row["name"]} -> {row["reason"]}')

print('\n--- BLOCKED MODULES ---')
for row in snap["capabilities"]:
    if row["state"] == "BLOCKED":
        print(f'  {row["id"]}: {row["name"]} -> {row["reason"]}')
