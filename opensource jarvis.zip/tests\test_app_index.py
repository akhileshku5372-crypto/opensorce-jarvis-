"""App index + installed-app launcher safety tests (stdlib only, no launch).

Lock in the rules that make "open <any installed app>" safe:
  * only index rows can ever be launched (never the spoken words),
  * no argv is ever built from user input; UWP uses one validated AUMID,
  * forged/non-allowlisted URI or AUMID targets are refused,
  * weak and ambiguous matches ask instead of guessing,
  * discovery is real (Start Menu .lnk files) and never fabricated.
"""
import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


APP_INDEX = _load("app_index")


def _shared_cortex():
    """Load cortex under the ONE name every module uses (identity check)."""
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / "cortex.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


CORTEX = _shared_cortex()


def _install(rows):
    """Force a deterministic index (bypasses the real machine + cache)."""
    with APP_INDEX._cache["lock"]:
        APP_INDEX._cache["rows"] = list(rows)
        APP_INDEX._cache["at"] = 9e9


LNK_ROWS = [
    {"name": "Notepad++", "kind": "lnk", "target": r"C:\Start\Notepad++.lnk",
     "source": "start-menu"},
    {"name": "Visual Studio Code", "kind": "lnk", "target": r"C:\Start\VSCode.lnk",
     "source": "start-menu"},
    {"name": "Steam", "kind": "lnk", "target": r"C:\Start\Steam.lnk",
     "source": "start-menu"},
    {"name": "Spotify", "kind": "exe", "target": r"C:\Apps\Spotify.exe",
     "source": "app-paths"},
]


class ScoringTest(unittest.TestCase):
    def setUp(self):
        _install(LNK_ROWS)

    def test_exact_and_prefix_resolve(self):
        row, _alts = APP_INDEX.resolve("notepad++")
        self.assertEqual(row["name"], "Notepad++")
        row, _alts = APP_INDEX.resolve("visual studio")
        self.assertEqual(row["name"], "Visual Studio Code")
        row, _alts = APP_INDEX.resolve("spotify")
        self.assertEqual(row["kind"], "exe")

    def test_short_and_unknown_queries_never_match(self):
        self.assertEqual(APP_INDEX.search("no"), [])
        self.assertEqual(APP_INDEX.resolve("zzzzqq"), (None, []))

    def test_ambiguous_query_asks_instead_of_guessing(self):
        _install([
            {"name": "Report Lab", "kind": "lnk", "target": r"C:\a.lnk",
             "source": "start-menu"},
            {"name": "Report Maker", "kind": "lnk", "target": r"C:\b.lnk",
             "source": "start-menu"},
        ])
        row, alts = APP_INDEX.resolve("report")
        self.assertIsNone(row, "ambiguous match must not launch anything")
        self.assertTrue(alts)

    def test_launch_name_reports_close_matches(self):
        _install([
            {"name": "Report Lab", "kind": "lnk", "target": r"C:\a.lnk",
             "source": "start-menu"},
            {"name": "Report Maker", "kind": "lnk", "target": r"C:\b.lnk",
             "source": "start-menu"},
        ])
        handled, message, row = APP_INDEX.launch_name("report")
        self.assertTrue(handled)
        self.assertIsNone(row)
        self.assertIn("exact match nahi mila", message)


class LaunchSafetyTest(unittest.TestCase):
    def test_shortcut_launch_passes_only_the_indexed_target(self):
        with mock.patch.object(APP_INDEX, "_startfile") as start:
            ok, message = APP_INDEX.launch(LNK_ROWS[0])
        self.assertTrue(ok, message)
        start.assert_called_once_with(r"C:\Start\Notepad++.lnk")

    def test_uwp_launch_uses_one_validated_aumid_argument(self):
        row = {"name": "Photos", "kind": "aumid",
               "target": "Microsoft.Windows.Photos_8wekyb3d8bbwe!App",
               "source": "store"}
        with mock.patch.object(APP_INDEX, "_spawn") as spawn, \
                mock.patch.object(APP_INDEX, "_window_matches", return_value=True):
            ok, _message = APP_INDEX.launch(row)
        self.assertTrue(ok)
        argv = spawn.call_args[0][0]
        self.assertEqual(len(argv), 2)
        self.assertTrue(argv[0].lower().endswith("explorer.exe"))
        self.assertTrue(argv[1].startswith("shell:AppsFolder\\"))

    def test_forged_targets_are_refused(self):
        self.assertFalse(APP_INDEX.launch(
            {"name": "evil", "kind": "uri", "target": "https://evil.example",
             "source": "x"})[0])
        self.assertFalse(APP_INDEX.launch(
            {"name": "evil", "kind": "aumid", "target": "pkg!App & calc.exe",
             "source": "x"})[0])
        self.assertFalse(APP_INDEX.launch(
            {"name": "evil", "kind": "weird", "target": "x", "source": "x"})[0])
        self.assertFalse(APP_INDEX.launch("not-a-dict")[0])

    def test_uwp_launch_without_window_says_so_honestly(self):
        row = {"name": "Photos", "kind": "aumid",
               "target": "Microsoft.Windows.Photos_8wekyb3d8bbwe!App",
               "source": "store"}
        with mock.patch.object(APP_INDEX, "_spawn"), \
                mock.patch.object(APP_INDEX, "_window_matches", return_value=False):
            ok, message = APP_INDEX.launch(row)
        self.assertTrue(ok)
        self.assertIn("confirm nahi hui", message)

    def test_builtin_uris_stay_a_fixed_allowlist(self):
        self.assertIn("ms-settings:", APP_INDEX._URI_ALLOWLIST)
        self.assertIn("whatsapp:", APP_INDEX._URI_ALLOWLIST)


class DiscoveryTest(unittest.TestCase):
    def test_start_menu_discovery_reads_real_lnk_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base / "Games").mkdir()
            for name in ("Steam", "Figma", "obsidian"):
                (base / (name + ".lnk")).write_bytes(b"x")
            (base / "Games" / "Valorant.lnk").write_bytes(b"x")
            (base / "Ignore.txt").write_text("nope", encoding="utf-8")
            rows = APP_INDEX.index_from_dirs([base])
        self.assertEqual(sorted(r["name"] for r in rows),
                         ["Figma", "Steam", "Valorant", "obsidian"])
        self.assertTrue(all(r["kind"] == "lnk" for r in rows))

    def test_real_machine_index_is_populated_on_windows(self):
        if os.name != "nt":
            self.skipTest("Start Menu/App Paths scan is Windows-only")
        rows = APP_INDEX.build_index(force=True)
        self.assertGreaterEqual(len(rows), 20)
        self.assertTrue(any(r["name"] == "notepad" for r in rows))
        _install(rows)   # leave a warm, real cache for the rest of the suite


class ToolTest(unittest.TestCase):
    def setUp(self):
        _install(LNK_ROWS)

    def test_specs_expose_find_and_launch(self):
        specs = APP_INDEX.specs()
        self.assertEqual({spec.name for spec in specs},
                         {"os_find_apps", "os_launch_app"})
        flags = {spec.name: spec.requires_confirmation for spec in specs}
        # Finding apps is read-only; launching drives the OS, so it is gated
        # and rides the `computer_control` permission category.
        self.assertFalse(flags["os_find_apps"])
        self.assertTrue(flags["os_launch_app"])

    def test_find_apps_reports_real_matches(self):
        got = APP_INDEX.tool_find_apps({"query": "steam"})
        self.assertTrue(got["ok"], got)
        self.assertIn("Steam", got["output"])

    def test_launch_app_fails_honestly_for_unknown_name(self):
        got = APP_INDEX.tool_launch_app({"name": "zzzzqq"})
        self.assertFalse(got["ok"])
        self.assertIn("nahi mila", got["output"])

    def test_launch_app_only_uses_indexed_targets(self):
        # Dispatch is not delivery: tool_launch_app waits for a real window
        # before it may claim success (commit 2256845). The window probe is
        # mocked here so the test asserts the indexed-target rule, not timing.
        with mock.patch.object(APP_INDEX, "_startfile") as start, \
                mock.patch.object(APP_INDEX, "window_appeared",
                                  return_value="Spotify Premium"):
            got = APP_INDEX.tool_launch_app({"name": "spotify"})
        self.assertTrue(got["ok"], got)
        start.assert_called_once_with(r"C:\Apps\Spotify.exe")
        self.assertEqual(got.get("window"), "Spotify Premium")

    def test_launch_app_never_claims_success_without_a_window(self):
        # Same launch, but no window shows up: the result must be an honest
        # failure (and retryable), never "ho gaya".
        with mock.patch.object(APP_INDEX, "_startfile"), \
                mock.patch.object(APP_INDEX, "window_appeared", return_value=""):
            got = APP_INDEX.tool_launch_app({"name": "spotify"})
        self.assertFalse(got["ok"], got)
        self.assertIn("nahi dikhi", got["output"])
        self.assertTrue(got.get("retryable"))

    def test_tool_specs_use_the_shared_cortex_module(self):
        self.assertIs(APP_INDEX._load_cortex(), CORTEX)


class StartAppsSourceTest(unittest.TestCase):
    """Per-user MSIX/Store apps (WhatsApp Desktop) must be discoverable."""

    def _rows(self, payload):
        import json as _json
        import subprocess as _subprocess
        with mock.patch.object(APP_INDEX, "_starts_apps_cache",
                               {"at": 0.0, "rows": []}), \
             mock.patch.object(_subprocess, "run") as runner:
            runner.return_value = type("R", (), {"stdout": _json.dumps(payload),
                                                  "stderr": ""})()
            return APP_INDEX._start_apps_rows()

    def test_store_app_rows_are_parsed(self):
        rows = self._rows([{"Name": "WhatsApp",
                            "AppID": "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"},
                           {"Name": "Photos", "AppID": "Microsoft.Windows.Photos_8wekyb3d8bbwe!App"}])
        names = sorted(r["name"] for r in rows)
        self.assertEqual(names, ["Photos", "WhatsApp"])
        self.assertTrue(all(r["kind"] == "aumid" for r in rows))
        self.assertTrue(all(r["source"] == "start-apps" for r in rows))

    def test_bad_rows_are_dropped(self):
        rows = self._rows([{"Name": "Bad", "AppID": "not a valid aumid"},
                           {"Name": "", "AppID": ""}])
        self.assertEqual(rows, [])

    def test_single_object_payload_is_handled(self):
        rows = self._rows({"Name": "WhatsApp",
                           "AppID": "5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App"})
        self.assertEqual([r["name"] for r in rows], ["WhatsApp"])

    def test_command_is_constant_and_shell_free(self):
        import inspect
        source = inspect.getsource(APP_INDEX._start_apps_rows)
        self.assertIn('"-NoProfile"', source)
        self.assertIn("shell=False", source)
        self.assertNotIn("shell=True", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)

