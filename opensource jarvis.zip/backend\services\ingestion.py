"""
KamiSensei Knowledge Base & Vector Ingestion Service
====================================================
Automated ChromaDB vector storage and PDF ingestion for the KamiSensei
Japanese learning protocol inside JARVIS.

Zero-User Intervention:
- Automatically creates './knowledge_base' and './chroma_db' if they do not exist.
- Connects to a persistent ChromaDB instance at './chroma_db'.
- Initializes collection 'kami_sensei_knowledge'.
- Gracefully alerts when knowledge_base is empty:
  "Sir, please drop your Japanese PDFs into the knowledge_base folder to begin learning."
"""

import os
import sys
import json
import hashlib
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger("KamiSensei.Ingestion")

# Resolve root workspace directory
ROOT_DIR = Path(__file__).resolve().parent.parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# RAG vectors move to the shared data root (D: by default) so the corpus is no
# longer inside the repo on C:. The COLLECTION NAME is unchanged, so existing
# behaviour and retrieval stay identical - only the on-disk location moved.
try:
    from background import storage_paths as _storage_paths
except ImportError:  # pragma: no cover - direct-script execution
    sys.path.insert(0, str(ROOT_DIR))
    from background import storage_paths as _storage_paths

KNOWLEDGE_BASE_DIR = ROOT_DIR / "knowledge_base"
CHROMA_DB_DIR = _storage_paths.kamisensei_rag_dir()
COLLECTION_NAME = "kami_sensei_knowledge"

# Automatically ensure directories exist at startup
os.makedirs(KNOWLEDGE_BASE_DIR, exist_ok=True)
os.makedirs(CHROMA_DB_DIR, exist_ok=True)


class KamiSenseiIngestionService:
    def __init__(
        self,
        knowledge_dir: Optional[Path] = None,
        chroma_dir: Optional[Path] = None,
        collection_name: str = COLLECTION_NAME
    ):
        self.knowledge_dir = Path(knowledge_dir or KNOWLEDGE_BASE_DIR)
        self.chroma_dir = Path(chroma_dir or CHROMA_DB_DIR)
        self.collection_name = collection_name
        
        # Ensure directories exist
        os.makedirs(self.knowledge_dir, exist_ok=True)
        os.makedirs(self.chroma_dir, exist_ok=True)

        self._client = None
        self._collection = None
        self._init_db()

    def _init_db(self):
        """Initializes persistent ChromaDB client and collection."""
        try:
            import chromadb
            from chromadb.config import Settings

            self._client = chromadb.PersistentClient(
                path=str(self.chroma_dir),
                settings=Settings(anonymized_telemetry=False)
            )
            self._collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"description": "KamiSensei Japanese Study Materials Vector Store"}
            )
            logger.info(f"ChromaDB initialized at '{self.chroma_dir}' [Collection: '{self.collection_name}']")
        except Exception as exc:
            logger.error(f"Failed to initialize ChromaDB: {exc}")
            self._client = None
            self._collection = None

    def check_knowledge_base(self) -> Dict[str, Any]:
        """
        Checks the knowledge_base folder. If empty, outputs the required console alert:
        'Sir, please drop your Japanese PDFs into the knowledge_base folder to begin learning.'
        """
        files = self.list_knowledge_files()
        is_empty = len(files) == 0

        if is_empty:
            alert_msg = "Sir, please drop your Japanese PDFs into the knowledge_base folder to begin learning."
            print(f"\n[JARVIS / KAMI-SENSEI] {alert_msg}\n")
            logger.info(alert_msg)

        return {
            "is_empty": is_empty,
            "files_count": len(files),
            "files": files,
            "knowledge_dir": str(self.knowledge_dir),
            "chroma_dir": str(self.chroma_dir),
            "collection_name": self.collection_name,
            "chunks_count": self._collection.count() if self._collection else 0,
            "db_connected": self._collection is not None
        }

    def list_knowledge_files(self) -> List[Dict[str, Any]]:
        """Lists all study documents (PDF, TXT, MD) in the knowledge_base directory with page counts and vector stats."""
        if not self.knowledge_dir.exists():
            return []

        supported_extensions = {".pdf", ".txt", ".md", ".json"}
        files_info = []

        try:
            import pymupdf as fitz
        except ImportError:
            try:
                import fitz
            except ImportError:
                fitz = None

        for item in sorted(self.knowledge_dir.iterdir()):
            if item.is_file() and item.suffix.lower() in supported_extensions:
                stat = item.stat()
                page_count = 1
                if item.suffix.lower() == ".pdf" and fitz:
                    try:
                        with fitz.open(str(item)) as d:
                            page_count = len(d)
                    except Exception:
                        page_count = 0

                # Count vector chunks for this source if collection exists
                chunks_count = 0
                if self._collection:
                    try:
                        res = self._collection.get(where={"source": item.name})
                        chunks_count = len(res.get("ids", []))
                    except Exception:
                        chunks_count = 0

                files_info.append({
                    "name": item.name,
                    "path": str(item),
                    "size_bytes": stat.st_size,
                    "size_display": self._format_size(stat.st_size),
                    "pages": page_count,
                    "chunks": chunks_count,
                    "indexed": chunks_count > 0,
                    "modified_time": stat.st_mtime,
                    "extension": item.suffix.lower()
                })

        return files_info

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        for unit in ["B", "KB", "MB", "GB"]:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} TB"

    def extract_text_from_file(self, file_path: Path) -> List[Dict[str, Any]]:
        """High-performance text & page extraction using PyMuPDF (fitz).
        Processes large 200+ page PDFs in sequential 10-page batches to prevent
        memory bloat, filtering out empty or image-only pages.
        """
        chunks = []
        ext = file_path.suffix.lower()

        if ext == ".pdf":
            doc = None
            total_pages = 0
            try:
                try:
                    import pymupdf as fitz
                except ImportError:
                    import fitz

                doc = fitz.open(str(file_path))
                total_pages = len(doc)
                batch_size = 10

                for batch_start in range(0, total_pages, batch_size):
                    batch_end = min(batch_start + batch_size, total_pages)
                    for page_idx in range(batch_start, batch_end):
                        try:
                            page = doc[page_idx]
                            text = page.get_text("text") or ""
                            cleaned = text.strip()
                            # OCR scanned/image-only pages when Tesseract is available.
                            # This is real extraction, never synthetic textbook content.
                            if (not cleaned or len(cleaned) <= 5) and page.get_images(full=True) and os.getenv("KAMISENSEI_OCR_ENABLED", "1") != "0":
                                try:
                                    ocr_language = os.getenv("KAMISENSEI_OCR_LANG", "eng+jpn")
                                    ocr_dpi = max(72, min(int(os.getenv("KAMISENSEI_OCR_DPI", "150")), 300))
                                    text_page = page.get_textpage_ocr(language=ocr_language, dpi=ocr_dpi, full=True)
                                    cleaned = (page.get_text("text", textpage=text_page) or "").strip()
                                except Exception as ocr_err:
                                    logger.warning("OCR failed on page %s of %s: %s", page_idx + 1, file_path.name, ocr_err)
                            # Clean string serialization to trap and ignore empty pages.
                            if cleaned and len(cleaned) > 5:
                                chunks.append({
                                    "page": page_idx + 1,
                                    "text": cleaned,
                                    "source": file_path.name,
                                    "type": "pdf"
                                })
                        except Exception as page_err:
                            logger.warning(f"Error reading page {page_idx+1} of {file_path.name}: {page_err}")
                logger.info(f"Extracted {len(chunks)} text pages from {total_pages}-page PDF '{file_path.name}'")
            except Exception as e:
                logger.error(f"PyMuPDF error reading PDF {file_path.name}: {e}")
                # Fallback to pypdf if fitz fails
                try:
                    from pypdf import PdfReader
                    reader = PdfReader(str(file_path))
                    for page_idx, page in enumerate(reader.pages):
                        text = page.extract_text() or ""
                        cleaned = text.strip()
                        if cleaned:
                            chunks.append({
                                "page": page_idx + 1,
                                "text": cleaned,
                                "source": file_path.name,
                                "type": "pdf"
                            })
                except Exception as pypdf_err:
                    logger.error(f"Fallback pypdf failed for {file_path.name}: {pypdf_err}")
            finally:
                if doc is not None:
                    try:
                        doc.close()
                    except Exception:
                        pass

            if len(chunks) == 0 and total_pages > 0:
                logger.warning(
                    "PDF '%s' has %s pages but no extractable text layer; "
                    "it was not indexed. Run OCR before ingestion.",
                    file_path.name,
                    total_pages,
                )
        elif ext in {".txt", ".md", ".json"}:
            try:
                text = file_path.read_text(encoding="utf-8", errors="ignore").strip()
                if text:
                    chunks.append({
                        "page": 1,
                        "text": text,
                        "source": file_path.name,
                        "type": ext.replace(".", "")
                    })
            except Exception as e:
                logger.error(f"Error reading text file {file_path.name}: {e}")

        return chunks

    def chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """Recursive-style overlapping splitter: 1000-char windows with a
        200-char overlap so sentence boundaries survive retrieval context."""
        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start += (chunk_size - overlap)
        return chunks

    def ingest_all(self, force_reindex: bool = False) -> Dict[str, Any]:
        """
        Scans ./knowledge_base, extracts content from study materials in batches,
        chunks text, and stores vector embeddings in ChromaDB.
        """
        status = self.check_knowledge_base()
        if status["is_empty"]:
            return {
                "ok": True,
                "ingested_files": 0,
                "ingested_chunks": 0,
                "message": "Knowledge base folder is empty. Drop Japanese PDFs into ./knowledge_base to begin."
            }

        # Quota guard BEFORE any embedding work: the RAG corpus is by far the
        # largest consumer of the data root, and chunking + embedding a whole
        # PDF set would blow past the ceiling before anyone could react.
        if not _storage_paths.guard_write(0):
            return {
                "ok": False,
                "error": "storage_quota_reached",
                "detail": _storage_paths.quota_status(),
                "message": "JARVIS data storage is full. Free space or raise JARVIS_DATA_MAX_GB.",
            }

        if not self._collection:
            return {"ok": False, "error": "ChromaDB collection is not available."}

        if force_reindex:
            try:
                # Reset collection
                self._client.delete_collection(self.collection_name)
                self._collection = self._client.create_collection(
                    name=self.collection_name,
                    metadata={"description": "KamiSensei Japanese Study Materials Vector Store"}
                )
            except Exception as e:
                logger.warning(f"Could not reset collection: {e}")

        files = self.list_knowledge_files()
        total_chunks = 0
        documents = []
        metadatas = []
        ids = []

        # FILE IDENTITY / DEDUPE: sha256 per file persisted beside the vector
        # store so the same file is never re-extracted and re-embedded on every
        # ingestion pass (only `--force` re-indexes everything deliberately).
        hashes_path = self.chroma_dir / "file_hashes.json"
        stored_hashes: Dict[str, str] = {}
        try:
            if hashes_path.exists():
                stored_hashes = json.loads(hashes_path.read_text(encoding="utf-8") or "{}")
        except Exception as hash_err:
            logger.warning(f"Could not read file hash registry ({hash_err}); starting fresh.")
            stored_hashes = {}

        def _file_hash(p: Path) -> str:
            digest = hashlib.sha256()
            with p.open("rb") as fh:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    digest.update(block)
            return digest.hexdigest()

        skipped_files = 0
        processed_files = 0
        for file_info in files:
            path = Path(file_info["path"])
            try:
                file_hash = _file_hash(path)
            except Exception as hash_err:
                logger.error(f"Could not hash {file_info['name']}: {hash_err}")
                file_hash = None

            # Skip: unchanged file that already carries indexed chunks.
            if (not force_reindex
                    and file_hash
                    and stored_hashes.get(file_info["name"]) == file_hash
                    and file_info.get("chunks", 0) > 0):
                logger.info(f"Skipping '{file_info['name']}' — hash unchanged and already indexed.")
                skipped_files += 1
                continue

            extracted_pages = self.extract_text_from_file(path)
            if not extracted_pages:
                logger.warning("Skipping '%s' because no real text could be extracted.", file_info["name"])
                continue

            # Remove stale chunks before replacing a changed source. This keeps
            # deleted/shortened pages from surviving an upsert under old IDs.
            try:
                self._collection.delete(where={"source": file_info["name"]})
            except Exception as delete_err:
                logger.warning("Could not clear stale vectors for %s: %s", file_info["name"], delete_err)

            processed_files += 1
            for page_data in extracted_pages:
                sub_chunks = self.chunk_text(page_data["text"])
                for idx, chunk_text in enumerate(sub_chunks):
                    chunk_id = f"{path.stem}_p{page_data['page']}_c{idx}"
                    ids.append(chunk_id)
                    documents.append(chunk_text)
                    metadatas.append({
                        "source": file_info["name"],
                        "page": page_data["page"],
                        "chunk_index": idx,
                        "text_content": chunk_text,
                        "type": path.suffix.lower().replace(".", "")
                    })
                    total_chunks += 1

            if file_hash:
                stored_hashes[file_info["name"]] = file_hash

        upsert_errors = 0
        if documents:
            # Batch upsert into ChromaDB in blocks of 50 to prevent Node/Python memory exhaustion
            batch_size = 50
            for i in range(0, len(documents), batch_size):
                b_docs = documents[i:i+batch_size]
                b_meta = metadatas[i:i+batch_size]
                b_ids = ids[i:i+batch_size]
                try:
                    self._collection.upsert(
                        ids=b_ids,
                        documents=b_docs,
                        metadatas=b_meta
                    )
                except Exception as upsert_err:
                    upsert_errors += 1
                    logger.error(f"Error during batch upsert at index {i}: {upsert_err}")

            if upsert_errors == 0:
                try:
                    hashes_path.write_text(json.dumps(stored_hashes, indent=2), encoding="utf-8")
                except Exception as hash_err:
                    logger.warning("Could not persist file hash registry: %s", hash_err)
                logger.info(
                    "Successfully ingested %s changed file(s) into %s vector chunks (%s unchanged skipped).",
                    processed_files,
                    total_chunks,
                    skipped_files,
                )

        ok = upsert_errors == 0
        return {
            "ok": ok,
            "ingested_files": processed_files,
            "skipped_files": skipped_files,
            "ingested_chunks": total_chunks,
            "total_collection_count": self._collection.count() if self._collection else 0,
            "message": (
                f"Successfully ingested {processed_files} changed file(s) into {total_chunks} chunks; "
                f"skipped {skipped_files} unchanged file(s)."
                if ok else f"Ingestion completed with {upsert_errors} failed vector batch(es)."
            )
        }

    def query(
        self,
        query_text: str,
        top_k: int = 4,
        sources: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """Dynamic multi-source semantic search across the whole collection with
        direct Page-Range bypass for explicit page/lesson queries.
        """
        # 1. CORE PAGE-RANGE EXTRACTION BYPASS:
        # If Sir's query references a specific page (e.g., "Page 45", "p45", "Lesson 14"),
        # bypass vector semantic matching and directly extract the entire raw text of
        # the targeted page PLUS the next 2 sequential pages without chunking loss.
        try:
            try:
                from .page_extractor import PageExtractorService
            except ImportError:
                from backend.services.page_extractor import PageExtractorService

            # Use this service instance's knowledge directory. The old global
            # singleton ignored custom/test notebook roots and could extract a
            # page from the wrong workspace.
            page_extractor = PageExtractorService(knowledge_dir=self.knowledge_dir)
            source_hint = sources[0] if sources and len(sources) == 1 else None
            page_res = page_extractor.get_page_context(query_text, source_hint=source_hint)
            if page_res and page_res.get("text"):
                logger.info(f"Direct Page-Range Extractor matched: {page_res['source_tag']}")
                return [{
                    "text": page_res["text"],
                    "metadata": {
                        "source": page_res.get("source", "Japanese Textbook"),
                        "page": page_res.get("start_page", 1),
                        "pages_extracted": page_res.get("pages_extracted", []),
                        "type": "page_extractor"
                    },
                    "source": page_res.get("source", "Japanese Textbook"),
                    "page": page_res.get("start_page", 1),
                    "distance": 0.0,
                    "source_tag": page_res.get("source_tag", "[Source: Textbook Page]")
                }]
        except Exception as p_err:
            logger.warning(f"PageExtractor check skipped: {p_err}")

        if not self._collection or self._collection.count() == 0:
            logger.info("Query called on empty ChromaDB collection; returning empty list.")
            return []

        try:
            where_filter = None
            if sources:
                normalized = sorted({str(s).strip() for s in sources if str(s).strip()})
                if normalized:
                    where_filter = {"source": {"$in": normalized}}

            total = self._collection.count()
            query_kwargs: Dict[str, Any] = {
                "query_texts": [query_text],
                "n_results": max(1, min(top_k, total)),
                "include": ["documents", "metadatas", "distances"],
            }
            if where_filter:
                query_kwargs["where"] = where_filter

            results = self._collection.query(**query_kwargs)
            docs = results.get("documents", [[]])[0]

            # STRICT SOURCE BOUNDARY: when the user selected specific sources,
            # an empty result stays empty — the database is NEVER silently
            # searched beyond the selection (KamiSensei answers honestly that
            # no data was found instead of pulling unrelated material).
            if not docs and where_filter:
                logger.info(f"Source-filtered query matched no chunks in {sorted(normalized)} — returning empty (strict source boundary).")

            metas = results.get("metadatas", [[]])[0]
            distances = results.get("distances", [[]])[0] if "distances" in results else [0.0] * len(docs)

            matched = []
            for d, m, dist in zip(docs, metas, distances):
                meta = dict(m) if isinstance(m, dict) else {}
                # DYNAMIC METADATA TRACKING: extract the exact 'source' string
                # from every matched chunk's metadata array (never hardcoded).
                source_name = str(meta.get("source") or "Unknown Source")
                page = None
                try:
                    raw_page = meta.get("page")
                    if raw_page is not None and int(raw_page) >= 1:
                        page = int(raw_page)
                except (TypeError, ValueError):
                    page = None
                meta["source"] = source_name
                if page is not None:
                    meta["page"] = page
                else:
                    meta.pop("page", None)
                matched.append({
                    "text": d,
                    "metadata": meta,
                    "source": source_name,
                    "page": page,
                    "distance": dist,
                    "source_tag": (
                        f"[Source: {source_name}, Page {page}]"
                        if page is not None else f"[Source: {source_name}]"
                    )
                })

            if matched:
                unique_sources = sorted({m["source"] for m in matched})
                logger.info(f"Global semantic search matched {len(matched)} chunks across {len(unique_sources)} source(s): {unique_sources}")
            return matched
        except Exception as e:
            logger.error(f"Error querying ChromaDB: {e}", exc_info=True)
            return []


# Global singleton instance for easy import
ingestion_service = KamiSenseiIngestionService()


def main():
    """CLI entrypoint for testing and inspection."""
    import argparse
    parser = argparse.ArgumentParser(description="KamiSensei Vector Ingestion Service")
    parser.add_argument("--status", action="store_true", help="Check knowledge base & database status")
    parser.add_argument("--ingest", action="store_true", help="Ingest all files in knowledge_base into ChromaDB")
    parser.add_argument("--force", action="store_true", help="Force re-indexing of all files")
    parser.add_argument("--query", type=str, help="Query the knowledge base for semantic matches")
    parser.add_argument(
        "--sources",
        type=str,
        default="",
        help="Comma-separated list of source filenames to filter results (e.g. genki1.pdf,tobira.pdf)"
    )
    parser.add_argument("--topk", type=int, default=4, help="Maximum number of matches to return")
    parser.add_argument("--json", action="store_true", help="Output results in JSON format")

    args = parser.parse_args()
    service = KamiSenseiIngestionService()

    if args.query:
        source_list = [s.strip() for s in args.sources.split(",") if s.strip()] if args.sources else None
        matches = service.query(args.query, top_k=max(1, args.topk), sources=source_list)
        if args.json:
            print(json.dumps({"query": args.query, "matches": matches}, indent=2))
        else:
            print(f"\nQuery: {args.query}")
            print(f"Matches found: {len(matches)}\n" + "="*40)
            for m in matches:
                tag = m.get("source_tag") or f"[Source: {m['metadata'].get('source')}, Page {m['metadata'].get('page')}]"
                print(f"{tag}: {m['text'][:140]}...")
    elif args.ingest:
        res = service.ingest_all(force_reindex=args.force)
        if args.json:
            print(json.dumps(res, indent=2))
        else:
            print(f"Ingestion Result: {res['message']} (Total in DB: {res.get('total_collection_count', 0)})")
    else:
        status = service.check_knowledge_base()
        if args.json:
            print(json.dumps(status, indent=2))
        else:
            print("="*50)
            print("KamiSensei Knowledge Base Status:")
            print(f"  • Knowledge Base Directory: {status['knowledge_dir']}")
            print(f"  • ChromaDB Storage Directory: {status['chroma_dir']}")
            print(f"  • Database Connected: {status['db_connected']}")
            print(f"  • Collection Name: {status['collection_name']}")
            print(f"  • Files Count: {status['files_count']}")
            print(f"  • Vector Chunks: {status['chunks_count']}")
            print("="*50)


if __name__ == "__main__":
    main()
