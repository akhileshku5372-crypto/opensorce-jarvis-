# Launcher: starts the Kokoro podcast engine detached with the uv CPython 3.11.
# .kokoro-env is a pip --target install (Lib\site-packages only; no venv Scripts),
# so the interpreter is the uv-managed CPython 3.11 with PYTHONPATH into it.
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$py = 'C:\Users\PRATEEK\AppData\Roaming\uv\python\cpython-3.11.16-windows-x86_64-none\python.exe'
$engine = Join-Path $root 'background\kokoro_podcast.py'
$env:PYTHONPATH = Join-Path $root '.kokoro-env\Lib\site-packages'
$server = Start-Process -FilePath $py -ArgumentList """$engine""" `
  -WorkingDirectory $root -WindowStyle Hidden -PassThru
Start-Sleep -Seconds 6
Write-Output '---ENGINE HEALTH---'
try {
  $h = Invoke-RestMethod -Uri 'http://127.0.0.1:7779/health' -TimeoutSec 8
  Write-Output ($h | ConvertTo-Json -Compress)
} catch {
  Write-Output ('health check failed: ' + $_.Exception.Message)
}
Write-Output ('engine pid: ' + $server.Id)