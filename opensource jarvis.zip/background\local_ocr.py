"""Local, key-free screen reading through Windows.Media.Ocr.

The Live Screen loop already has the latest JPEG frame in memory. This module
hands that frame to Windows' built-in OCR engine through stdin; the helper
decodes it into an in-memory WinRT stream, so no screenshot or OCR text is
written to disk. The caller receives real text and a deterministic activity
summary - no cloud vision call, no API key, no local LLM.

This is deliberately a thin adapter:
  * `read_base64()` returns `{ok, text, error, elapsed_ms, source}`
  * `summarize()` only states facts that are present in the frame/title
  * a missing Windows OCR language is reported as an error, never as "no text"
"""
from __future__ import annotations

import base64
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

MAX_TEXT = 2000
DEFAULT_TIMEOUT = 8.0
_SCRIPT = Path(__file__).with_name("windows_ocr.ps1")
_CREATE_NO_WINDOW = 0x08000000
_POWERSHELL = None


def _powershell() -> str:
    global _POWERSHELL
    if _POWERSHELL:
        return _POWERSHELL
    candidate = shutil.which("powershell.exe")
    if not candidate:
        root = os.environ.get("SystemRoot", r"C:\Windows")
        candidate = str(Path(root) / "System32" / "WindowsPowerShell" /
                        "v1.0" / "powershell.exe")
    _POWERSHELL = candidate
    return candidate


def available() -> bool:
    """True when the helper exists on this Windows machine.

    The actual OCR engine is checked by the first frame: a machine can have
    PowerShell but no OCR language pack, and that failure must be visible.
    """
    return (os.name == "nt" and _SCRIPT.is_file()
            and Path(_powershell()).exists())


def _decode_frame(image_b64: str) -> bytes:
    raw = str(image_b64 or "").strip()
    if raw.startswith("data:"):
        _, _, raw = raw.partition(",")
    if not raw:
        raise ValueError("empty screen frame")
    try:
        data = base64.b64decode(raw, validate=True)
    except Exception as exc:
        raise ValueError("screen frame is not valid base64") from exc
    if not data:
        raise ValueError("empty screen frame")
    return data


def clean_text(raw: str) -> str:
    """Normalise OCR output without inventing words or dropping unique lines."""
    text = str(raw or "").replace("\x00", "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = []
    seen = set()
    for line in text.split("\n"):
        line = " ".join(line.replace("\ufeff", "").split()).strip()
        line = line.strip("|")
        if not line:
            continue
        key = line.casefold()
        if key in seen:
            continue
        seen.add(key)
        lines.append(line)
    return "\n".join(lines)[:MAX_TEXT].rstrip()


def read_base64(image_b64: str, timeout: float = DEFAULT_TIMEOUT) -> dict:
    """OCR one in-memory JPEG/PNG frame with Windows.Media.Ocr."""
    started = time.monotonic()
    result = {"ok": False, "text": "", "error": "", "elapsed_ms": 0,
              "source": "windows-ocr"}
    try:
        if not available():
            raise RuntimeError(
                "Windows OCR helper unavailable (PowerShell or "
                "windows_ocr.ps1 missing)")
        data = _decode_frame(image_b64)
        encoded = base64.b64encode(data)
        if os.name == "nt":
            flags = _CREATE_NO_WINDOW
        else:
            flags = 0
        proc = subprocess.run(
            [_powershell(), "-NoLogo", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-File", str(_SCRIPT)],
            input=encoded,
            capture_output=True,
            timeout=float(timeout),
            creationflags=flags,
        )
        stdout = proc.stdout.decode("utf-8", "replace")
        stderr = proc.stderr.decode("utf-8", "replace")
        if proc.returncode != 0:
            reason = " ".join((stderr or stdout).split()).strip()
            if "OCR_ENGINE_UNAVAILABLE" in reason:
                reason = ("Windows OCR language pack is not installed "
                          "(install the English OCR feature in Windows)")
            elif "OCR_ERROR:" in reason:
                reason = reason.split("OCR_ERROR:", 1)[1].strip()
            raise RuntimeError(reason or "Windows OCR exited with code %s" %
                               proc.returncode)
        result["ok"] = True
        result["text"] = clean_text(stdout)
    except subprocess.TimeoutExpired:
        result["error"] = ("Windows OCR timed out after %ss" %
                           round(float(timeout), 1))
    except Exception as exc:
        result["error"] = str(exc) or type(exc).__name__
    result["elapsed_ms"] = int((time.monotonic() - started) * 1000)
    return result


_KNOWN_APPS = (
    ("google ai studio", "Google AI Studio"),
    ("gmail", "Gmail"),
    ("youtube", "YouTube"),
    ("github", "GitHub"),
    ("visual studio code", "VS Code"),
    ("qoder", "Qoder"),
    ("android studio", "Android Studio"),
    ("whatsapp", "WhatsApp"),
    ("telegram", "Telegram"),
    ("discord", "Discord"),
    ("slack", "Slack"),
    ("chrome", "Chrome browser"),
    ("edge", "Edge browser"),
    ("firefox", "Firefox browser"),
    ("powershell", "PowerShell"),
    ("windows terminal", "Windows Terminal"),
    ("command prompt", "Command Prompt"),
    ("notepad", "Notepad"),
    ("file explorer", "File Explorer"),
    ("explorer", "File Explorer"),
    ("microsoft word", "Microsoft Word"),
    ("microsoft excel", "Microsoft Excel"),
    ("settings", "Windows Settings"),
    ("calculator", "Calculator"),
    ("paint", "Paint"),
)

_SIGNAL_NOISE = (
    "live screen", "screen off", "windows ke bu", "diagnostic subroutine",
    "power at percent", "fps ",
)

_RISK_WORDS = (
    "are you sure", "confirm", "confirmation", "delete", "remove",
    "permanently", "warning", "error", "failed", "denied", "blocked",
    "kya aap", "pakka",
)


def _title(foreground: str) -> str:
    return " ".join(str(foreground or "").split()).strip()[:180]


def _title_has(needle: str, title: str) -> bool:
    """Match a short app name on a word boundary, not inside another word.

    Without this, a title such as "Knowledge Base" contains "edge" and would
    be reported as Microsoft Edge.
    """
    if " " in needle or "." in needle:
        return needle in title
    return re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(needle),
                     title) is not None


def _unread_count(title: str, text: str) -> int:
    for source in (title, text):
        match = re.search(r"\binbox\s*\((\d{1,4})\)", source, re.I)
        if match:
            return int(match.group(1))
        match = re.search(r"\b(\d{1,4})\s*(?:unread|new)\b", source, re.I)
        if match:
            return int(match.group(1))
    return 0


def _signal_line(text: str) -> str:
    """Pick a content-like line instead of a taskbar item or a file UUID."""
    best = ""
    best_score = 0.0
    fallback = ""
    for raw in str(text or "").splitlines()[:40]:
        line = " ".join(raw.split()).strip()
        if len(line) < 12 or not any(ch.isalpha() for ch in line):
            continue
        low = line.casefold()
        if any(noise in low for noise in _SIGNAL_NOISE):
            continue
        if not fallback:
            fallback = line[:100]
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9_.'-]*", line)
                 if len(w) >= 2]
        if len(words) < 3:
            continue
        if low.startswith(("search ", "search for", "type here",
                           "ask anything", "new tab", "http://", "https://")):
            continue
        if sum(1 for ch in line if ch.isalpha()) < 12:
            continue
        # Longer sentences are usually real content; OCR often puts the
        # taskbar and window chrome first, and those lines repeat on every
        # screen. Prefer the best content line, not merely the first one.
        score = min(len(line), 100) + 8.0 * len(words)
        if score > best_score:
            best = line[:100]
            best_score = score
    return best or fallback


def summarize(text: str, foreground: str = "") -> str:
    """A deterministic, honest activity summary; no model is involved."""
    title = _title(foreground)
    # Classify from the window title only. OCR text can contain a file type
    # ("Chrome HTML") and must not make File Explorer look like a browser.
    title_low = title.casefold()
    low = (title + "\n" + str(text or "")).casefold()
    facts = []
    app = ""
    for needle, label in _KNOWN_APPS:
        if _title_has(needle, title_low):
            app = label
            break
    if app:
        if title and title.casefold() != app.casefold():
            facts.append("%s active hai (%s)" % (app, title[:90]))
        else:
            facts.append("%s active hai" % app)
    elif title:
        facts.append("active window %s hai" % title)
    unread = _unread_count(title, text)
    if unread:
        facts.append("%s unread/new items dikh rahe hain" % unread)
    risky = [word for word in _RISK_WORDS if word in low]
    if risky:
        facts.append("screen par %s jaisa text hai, isliye main koi "
                     "action khud nahi karunga" % ", ".join(risky[:2]))
    if text:
        facts.append("screen par %s characters readable hain" % len(text))
        first = _signal_line(text)
        if first:
            facts.append("pehli readable line: %s" % first)
    else:
        facts.append("is frame mein readable text nahi mila")
    if not facts:
        facts.append("screen se abhi koi readable text nahi mila")
    return ("Sir, " + "; ".join(facts) + ".")[:600]
