// Direct test of the installed edge-tts package (bypass server) to capture the real error.
import('edge-tts').then(async (mod) => {
  const ctrl = new AbortController()
  const to = setTimeout(() => ctrl.abort(), 20000)
  try {
    console.log('typeof tts:', typeof mod.tts, '| keys:', Object.keys(mod).slice(0,5))
    const buf = await mod.tts('नमस्ते please こんにちは।', { voice: 'en-US-AndrewMultilingualNeural', rate: '-3%' })
    console.log('buffer type:', typeof buf, '| bytes:', buf && buf.byteLength, '| ctor:', buf && buf.constructor && buf.constructor.name)
    if (buf && buf.byteLength) console.log('SUCCESS — first bytes:', Buffer.from(buf).slice(0,4))
  } catch (e) {
    console.log('tts() ERROR:', e && e.stack ? e.stack : e)
  } finally { clearTimeout(to) }
}).catch((e) => { console.log('IMPORT ERROR:', e && e.stack); process.exit(1) })

const controller = new AbortController()
const t = setTimeout(() => controller.abort(), 24000)
try {
  const r = await fetch('http://127.0.0.1:7777/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: 'नमस्ते please こんにちは।', lang: 'auto' }),
    signal: controller.signal,
  })
  const voice = r.headers.get('X-TTS-Voice') || '(no X-TTS-Voice header)'
  let len = r.headers.get('content-length') || ''
  if (!len) { try { const b = await r.blob(); len = `${Math.round(b.size/1024)}KB` } catch { len = '?' } }
  console.log(`HTTP ${r.status} | X-TTS-Voice: ${voice} | audio: ${len}`)
} catch (e) {
  console.log('error:', e.name === 'AbortError' ? 'TIMEOUT (>24s)' : e.message)
} finally { clearTimeout(t) }
