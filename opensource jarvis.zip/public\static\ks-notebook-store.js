/* ─────────────────────────────────────────────────────────────────────────────
 * KAMI-SENSEI Data Isolation Engine  (public/static/ks-notebook-store.js)
 * Loads before ks-state.js and app.js; exposes window.KSNotebooks.
 *
 * Two strictly segregated storage layers (no crosstalk possible):
 *   1. REGISTRY  "jarvis_kamisensei_library"        -> NotebookMetadata[] ONLY.
 *      Source of truth for the dashboard card grid. Never holds notebook
 *      payloads, chat text, or source data.
 *   2. PER-NOTEBOOK "jarvis_kamisensei_data_<id>"   -> FullNotebookState.
 *      Fully isolated matrix per session: metadata + sources + chatHistory +
 *      artifacts. One key per notebook — a notebook can never read another's.
 *
 * Identity rules:
 *   - User-created notebooks mint a crypto.randomUUID() (math/date fallback)
 *     and are committed to BOTH layers synchronously BEFORE the view mounts,
 *     so a browser refresh can never drop a newly created workspace.
 *   - Featured catalog workbooks (Genki I/II, Tobira, JLPT N3, Kanji Master)
 *     resolve to a STABLE id derived from their catalog key, so reopening
 *     "Genki I" restores the same workspace instead of recycling a fresh one.
 * ───────────────────────────────────────────────────────────────────────────── */
;(function () {
  'use strict'

  const LIBRARY_KEY = 'jarvis_kamisensei_library'
  const DATA_PREFIX = 'jarvis_kamisensei_data_'

  function generateSecureUUID() {
    try {
      if (typeof window !== 'undefined' && window.crypto && typeof window.crypto.randomUUID === 'function') {
        return window.crypto.randomUUID()
      }
    } catch (err) { /* fall through to math/date identity */ }
    return 'nb-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now().toString(36)
  }

  function safeParse(raw, fallback) {
    try {
      const parsed = JSON.parse(raw)
      return parsed && typeof parsed === 'object' ? parsed : fallback
    } catch (err) {
      return fallback
    }
  }

  /* ── Schema normalizers: every field gets a clean runtime default ────────── */
  function normalizeMetadata(meta, fallbackId) {
    const now = Date.now()
    return {
      id: String((meta && meta.id) || fallbackId || generateSecureUUID()),
      title: String((meta && meta.title) || 'Untitled Notebook'),
      createdAt: Number((meta && meta.createdAt) || now),
      updatedAt: Number((meta && meta.updatedAt) || (meta && meta.createdAt) || now),
      catalogKey: (meta && meta.catalogKey) ? String(meta.catalogKey) : null
    }
  }
  function normalizeChatMessage(msg) {
    if (!msg || typeof msg !== 'object') return null
    const role = msg.role === 'assistant' ? 'assistant' : 'user'
    const content = typeof msg.content === 'string' ? msg.content : ''
    if (!content) return null
    return {
      id: typeof msg.id === 'string' ? msg.id : 'm' + Math.random().toString(36).slice(2, 9),
      role,
      content,
      timestamp: Number(msg.timestamp) || Date.now(),
      type: msg.type === 'audio_overview_loading' || msg.type === 'audio_overview_player' ? msg.type : 'text',
      citations: Array.isArray(msg.citations) ? msg.citations.slice(0, 12) : []
    }
  }
  function normalizeState(raw, fallbackMeta) {
    const meta = normalizeMetadata(
      (raw && raw.metadata) || fallbackMeta,
      fallbackMeta ? fallbackMeta.id : undefined
    )
    const sources = Array.isArray(raw && raw.sources)
      ? raw.sources.filter((s) => s && typeof s === 'object').map((s) => ({
          id: String(s.id || generateSecureUUID()),
          name: String(s.name || ''),
          pageCount: Number(s.pageCount) || 0,
          status: s.status === 'indexing' || s.status === 'error' ? s.status : 'indexed',
          fileSize: Number.isFinite(s.fileSize) ? s.fileSize : undefined
        }))
      : []
    const chatHistory = Array.isArray(raw && raw.chatHistory)
      ? raw.chatHistory.map(normalizeChatMessage).filter(Boolean).slice(-60)
      : []
    const artifacts = Array.isArray(raw && raw.artifacts) ? raw.artifacts.filter((a) => a && typeof a === 'object') : []
    const selectedSources = Array.isArray(raw && raw.selectedSources)
      ? raw.selectedSources.map((s) => String(s)).filter(Boolean)
      : []
    return { metadata: meta, sources, selectedSources, chatHistory, artifacts }
  }

  function emptyState(metadata) {
    return { metadata: normalizeMetadata(metadata), sources: [], chatHistory: [], artifacts: [] }
  }

  /* ── Registry (library) layer ────────────────────────────────────────────── */
  function readLibrary() {
    const raw = localStorage.getItem(LIBRARY_KEY)
    const list = raw ? safeParse(raw, []) : []
    return Array.isArray(list) ? list.map((m) => normalizeMetadata(m)).filter((m) => m.title) : []
  }
  function writeLibrary(list) {
    localStorage.setItem(LIBRARY_KEY, JSON.stringify(list))
    return list
  }
  function upsertLibrary(metadata) {
    const list = readLibrary().filter((m) => m.id !== metadata.id)
    return writeLibrary([metadata, ...list])
  }

  /* ── Per-notebook data layer ─────────────────────────────────────────────── */
  function readState(id) {
    if (!id) return null
    const raw = localStorage.getItem(DATA_PREFIX + id)
    if (!raw) return null
    return normalizeState(safeParse(raw, null))
  }
  function writeState(state) {
    if (!state || !state.metadata || !state.metadata.id) return null
    localStorage.setItem(DATA_PREFIX + state.metadata.id, JSON.stringify(state))
    return state
  }

  const KSNotebooks = {
    generateSecureUUID,

    /* Registry access for the dashboard card grid. */
    list() { return readLibrary() },
    get(id) { return readLibrary().find((m) => m.id === id) || null },

    /* CLEAN SLATE INITIALIZER: commits registry + empty data matrix
     * synchronously, then returns the metadata. No async gap, no ephemeral
     * in-memory-only workspace — refresh-proof by construction. */
    create(customName) {
      const timestamp = Date.now()
      const ordinal = readLibrary().length + 1
      const metadata = normalizeMetadata({
        id: generateSecureUUID(),
        title: (customName && customName.trim()) || `Untitled Notebook (${ordinal})`,
        createdAt: timestamp,
        updatedAt: timestamp
      })
      writeLibrary([metadata, ...readLibrary()])
      writeState(emptyState(metadata))
      return metadata
    },

    /* Featured workbook resolution: stable identity across reloads. */
    ensureForCatalog(catalogKey, title) {
      const existing = readLibrary().find((m) => m.catalogKey === catalogKey)
      if (existing) {
        const state = readState(existing.id)
        if (state) return existing.metadata
        // Metadata survived but the data sector was lost — rebuild the canvas.
        const rebuilt = emptyState(existing)
        writeState(rebuilt)
        return rebuilt.metadata
      }
      const timestamp = Date.now()
      const metadata = normalizeMetadata({
        id: 'catalog-' + String(catalogKey).replace(/[^a-z0-9_-]/gi, ''),
        title: title || catalogKey,
        createdAt: timestamp,
        updatedAt: timestamp,
        catalogKey
      })
      writeLibrary([metadata, ...readLibrary()])
      writeState(emptyState(metadata))
      return metadata
    },

    /* SECURE LOAD ROUTER: read a notebook's isolated matrix; if the metadata
     * exists but the data sector is missing, force-create an empty canvas. */
    load(id) {
      const state = readState(id)
      if (state) return state
      const meta = this.get(id)
      if (meta) {
        const fresh = emptyState(meta)
        writeState(fresh)
        return fresh
      }
      return null
    },

    /* PERSISTENT MUTATOR — synchronous localStorage write + registry touch. */
    update(id, updater) {
      const prev = this.load(id)
      if (!prev || typeof updater !== 'function') return null
      let next
      try { next = updater(prev) } catch (err) { console.error('[KSNotebooks] updater failed:', err); return null }
      next = normalizeState(next, prev.metadata)
      next.metadata.updatedAt = Date.now()
      writeState(next)
      upsertLibrary(next.metadata)
      return next
    },

    /* Chat-typed convenience mutator used by the streaming client. */
    updateChat(id, chatHistory) {
      return this.update(id, (prev) => ({ ...prev, chatHistory: (Array.isArray(chatHistory) ? chatHistory : []).slice(-60) }))
    },

    /* Chat append (single turn) — keeps writes tiny during long sessions. */
    appendChat(id, message) {
      const msg = normalizeChatMessage(message)
      if (!msg) return null
      return this.update(id, (prev) => ({ ...prev, chatHistory: prev.chatHistory.concat(msg).slice(-60) }))
    },

    /* Full node removal (registry entry + isolated data sector). */
    remove(id) {
      writeLibrary(readLibrary().filter((m) => m.id !== id))
      try { localStorage.removeItem(DATA_PREFIX + id) } catch (err) { /* already gone */ }
    },

    /* Direct read of the chat slice for a notebook (sync). */
    chatOf(id) {
      const state = readState(id)
      return state ? state.chatHistory : []
    },

    /* Rename a notebook's metadata (registry + its data sector stay linked). */
    rename(id, title) {
      const meta = this.get(id)
      if (!meta) return null
      const clean = String(title || '').trim()
      if (!clean) return null
      const updated = { ...meta, title: clean, updatedAt: Date.now() }
      upsertLibrary(updated)
      const state = readState(id)
      if (state) { state.metadata = { ...state.metadata, title: clean, updatedAt: updated.updatedAt }; writeState(state) }
      return updated
    },

    /* Boot-time registry healer: purges blank/duplicate-id entries, mints a
     * stable id when a record lost one, and rebuilds a missing data sector so
     * no notebook can ever be created-but-invisible or open someone else's. */
    heal() {
      const list = readLibrary()
      if (!list.length) return 0
      const seen = new Map()
      const healed = []
      let changed = 0
      list.forEach((m) => {
        const id = String(m.id || '').trim()
        if (!id) { changed++; return } // drop orphaned metadata with no identity
        if (seen.has(id)) { changed++; return } // drop duplicate id (old bug produced these)
        seen.set(id, true)
        const meta = normalizeMetadata(m)
        healed.push(meta)
        if (!readState(meta.id)) { writeState(emptyState(meta)); changed++ } // rebuild missing sector
      })
      if (changed || healed.length !== list.length) writeLibrary(healed)
      // Catalog workbooks must not collide with the same client id across calls.
      return changed
    },

    /* Snapshot a notebook for export: metadata + chat transcript. */
    snapshot(id) {
      const meta = this.get(id)
      const state = readState(id)
      return {
        metadata: meta,
        title: meta ? meta.title : 'Untitled Notebook',
        chatHistory: state ? state.chatHistory : [],
        sourceCount: state && Array.isArray(state.sources) ? state.sources.length : 0
      }
    }
  }

  window.KSNotebooks = KSNotebooks
})()
