export type SourceType = 'PDF' | 'Book' | 'Web' | 'Notes' | 'Course';
export type SkillCategory = 'soft' | 'hard';
export type SoftSubcategory = 'COMMUNICATION' | 'THINKING' | 'BEHAVIOUR' | 'LIFE';
export type HardSubcategory = 'TECH' | 'MATH' | 'SCIENCE' | 'CODING' | 'TOOLS';
export type NavSection = 'Home' | 'Library' | 'Search' | 'Notes' | 'Collections' | 'Settings';
export type WorkspaceMode = 'EXPLORE' | 'RESEARCH' | 'LEARN' | 'BUILD';
export type PhysicalLook =
  | 'dark-book'
  | 'cream-notebook'
  | 'open-laptop'
  | 'pdf-binder'
  | 'holo-screen';

export interface MaterialItem {
  id: string;
  title: string;
  subtitle: string;
  type: SourceType;
  category: SkillCategory;
  subcategory: SoftSubcategory | HardSubcategory;
  author: string;
  dateAdded: string;
  durationOrPages: string;
  fileSize?: string;
  tier?: number; // 0 to 4 (5 golden shelf rows)
  physicalLook?: PhysicalLook;
  summary: string;
  paragraphs: string[];
  keyTakeaways: string[];
  linkedIds: string[];
  // Real shelf fields. A volume only exists when its text is on disk under
  // skills/library/books/, so these come from the core's /library/shelf and are
  // never filled in by the UI.
  slug?: string;
  chapterN?: number;
  chapterCount?: number;
  license?: string;
  attribution?: string;
  // A LINK card: the source is on the shelf because he asked for every source to
  // be visible, but its licence does not allow storing the text, so there is
  // nothing here to read, quote or speak.
  readable?: boolean;
  url?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'jarvis';
  text: string;
  timestamp: string;
  sourceTitle?: string;
  citation?: string;
  numberedPoints?: { title: string; detail: string }[];
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  category: SkillCategory;
  subcategory: SoftSubcategory | HardSubcategory;
  updatedAt: string;
  linkedSourceId?: string;
}

export interface CollectionItem {
  id: string;
  name: string;
  description: string;
  category: 'soft' | 'hard' | 'mixed';
  materialIds: string[];
}

export const SOFT_SUBCATEGORIES: SoftSubcategory[] = [
  'COMMUNICATION',
  'THINKING',
  'BEHAVIOUR',
  'LIFE',
];

export const HARD_SUBCATEGORIES: HardSubcategory[] = [
  'TECH',
  'MATH',
  'SCIENCE',
  'CODING',
  'TOOLS',
];

export const JARVIS_QUOTES: string[] = [
  '"Knowledge is the only thing that grows when you share it."',
  '"An organized archive turns raw information into decisive action."',
  '"Precision in thought precedes precision in engineering."',
  '"Cross-referencing soft intuition with hard computation yields mastery."',
  '"Every complex system is built upon clearly understood fundamentals."',
];

/**
 * Smart Filename & Title Cleaner:
 * Converts raw machine filenames (like "WhatsApp Image 2026-10-15 at 17.22.10_abc.pdf"
 * or "my_public_speaking_notes_final_v2.pdf") into a clean, human-readable book/PDF cover title.
 */
export function formatCleanShelfTitle(
  rawName: string,
  category: SkillCategory = 'soft',
  type: SourceType = 'PDF'
): string {
  // 1. Strip file extension
  let cleaned = rawName.replace(/\.[^/.]+$/, '').trim();

  // 2. Detect raw camera / WhatsApp / screenshot machine filenames
  const isMachineAutoName =
    /^(whatsapp\s*(image|document|video|audio|file)?|img|dsc|pxl|screenshot|screen\s*shot|scan|document|file|untitled|image|photo)[\s_-]*(\d|\(|$)/i.test(
      cleaned
    );

  // 3. Remove date/time stamps like "2026-10-15 at 17.22.10..." or "20261015_172210"
  cleaned = cleaned
    .replace(/\b20\d{2}[-_.\s]\d{1,2}[-_.\s]\d{1,2}(\s*at\s*[\d._\s-]+)?.*$/i, '')
    .replace(/\b20\d{6}[_-]?\d{4,6}.*$/i, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\b(final|v\d+|copy|\(\d+\))\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (
    isMachineAutoName ||
    !cleaned ||
    cleaned.length < 3 ||
    /^(whatsapp(\s+image|\s+document)?|img|screenshot|scan|document|untitled)$/i.test(cleaned)
  ) {
    if (category === 'soft') {
      return type === 'PDF'
        ? 'Public Speaking PDF'
        : type === 'Notes'
        ? 'Confidence Notes'
        : 'Better Communication';
    } else {
      return type === 'PDF'
        ? 'Physics Formulas PDF'
        : type === 'Notes'
        ? 'Math Notes'
        : 'Python & AI Guide';
    }
  }

  // Title-case words cleanly if all lowercase
  if (cleaned === cleaned.toLowerCase()) {
    cleaned = cleaned
      .split(' ')
      .map((w) => (w.length > 0 ? w[0].toUpperCase() + w.slice(1) : w))
      .join(' ');
  }

  // Keep length reasonable for book cover printing (max 34 chars)
  if (cleaned.length > 34) {
    cleaned = cleaned.slice(0, 32).trim();
  }

  return cleaned;
}

/**
 * Deterministic Physical Appearance Engine (Zero AI/LLM API keys needed).
 * Takes ANY random title/type and computes a realistic physical 3D look, emblem,
 * companion book spine colors, and shelf tier.
 */
export function resolvePhysicalAppearance(item: MaterialItem, indexOnShelf = 0): {
  look: PhysicalLook;
  emblem:
    | 'python'
    | 'code'
    | 'atom'
    | 'math'
    | 'brain'
    | 'pdf'
    | 'web'
    | 'video'
    | 'folder'
    | 'book'
    | 'japanese';
  accentColor: string;
  spineColors: string[];
  tier: number;
} {
  const t = item.title.toLowerCase();
  let hash = 0;
  for (let i = 0; i < item.title.length; i++) {
    hash = (hash * 31 + item.title.charCodeAt(i)) >>> 0;
  }

  // Determine Physical Look if not explicitly specified
  let look: PhysicalLook = item.physicalLook || 'dark-book';
  if (!item.physicalLook) {
    if (item.type === 'PDF' || t.includes('pdf')) {
      look = 'pdf-binder';
    } else if (
      item.type === 'Notes' ||
      t.includes('notes') ||
      t.includes('plan') ||
      t.includes('habit') ||
      t.includes('speak')
    ) {
      look = 'cream-notebook';
    } else if (t.includes('< />') || t.includes('code') || t.includes('laptop')) {
      look = 'open-laptop';
    } else if (
      item.type === 'Web' ||
      item.type === 'Course' ||
      t.includes('stress') ||
      t.includes('system') ||
      t.includes('web') ||
      t.includes('ai')
    ) {
      look = 'holo-screen';
    } else {
      const looks: PhysicalLook[] = [
        'pdf-binder',
        'dark-book',
        'cream-notebook',
        'holo-screen',
      ];
      look = looks[hash % looks.length];
    }
  }

  // Determine Emblem purely from keywords or type
  let emblem:
    | 'python'
    | 'code'
    | 'atom'
    | 'math'
    | 'brain'
    | 'pdf'
    | 'web'
    | 'video'
    | 'folder'
    | 'book'
    | 'japanese' = 'book';

  if (item.type === 'PDF' || t.includes('pdf')) emblem = 'pdf';
  else if (t.includes('python')) emblem = 'python';
  else if (t.includes('< />') || t.includes('coding') || t.includes('rust') || t.includes('js'))
    emblem = 'code';
  else if (
    t.includes('physics') ||
    t.includes('chem') ||
    t.includes('quantum') ||
    t.includes('science')
  )
    emblem = 'atom';
  else if (t.includes('math') || t.includes('formula') || t.includes('jee') || t.includes('algebra'))
    emblem = 'math';
  else if (
    t.includes('ai') ||
    t.includes('ml') ||
    t.includes('stress') ||
    t.includes('emotional') ||
    t.includes('mind')
  )
    emblem = 'brain';
  else if (t.includes('n4') || t.includes('日本') || t.includes('lang')) emblem = 'japanese';
  else if (item.type === 'Web' || t.includes('web') || t.includes('system')) emblem = 'web';
  else if (item.type === 'Course' || t.includes('course')) emblem = 'video';
  else if (t.includes('project') || t.includes('folder')) emblem = 'folder';

  const palette = ['#22d3ee', '#38bdf8', '#f59e0b', '#10b981', '#a855f7', '#f43f5e'];
  const accentColor = palette[hash % palette.length];

  const spineColors = [
    palette[(hash + 1) % palette.length],
    palette[(hash + 2) % palette.length],
    palette[(hash + 4) % palette.length],
  ];

  const tier = typeof item.tier === 'number' ? item.tier : indexOnShelf % 5;

  return { look, emblem, accentColor, spineColors, tier };
}

// Complete Library matching the 2nd reference image (image_49473250.png / image_9ffe2923.png) across all 5 tiers!
