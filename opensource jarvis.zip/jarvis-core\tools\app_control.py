"""
app_control.py — Operating System Bridging Actions
==================================================
Safe wrapper scripts around `psutil` (optional), `subprocess`, and the
project's allowlisted local Windows bridge (127.0.0.1:7778).

Provides the raw telemetry + action primitives the brain's tool schemas call:
    system_snapshot()   -> CPU / RAM / battery / uptime / active window
    set_volume(action)  -> up / down / mute / unmute        (via bridge)
    bridge_action(cmd)  -> any allowlisted bridge command
    open_url(url)       -> validated http(s) open           (via bridge/webbrowser)
    list_top_processes()-> heaviest processes by CPU

Nothing here runs arbitrary shell strings coming from AI/user input — every
side-effect path goes through the fixed bridge allowlist or a fixed local
implementation, matching the project's security model.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from typing import Optional
from urllib.parse import urlparse

import requests

try:
    import psutil  # type: ignore
except Exception:  # pragma: no cover
    psutil = None

_BRIDGE = os.environ.get("JARVIS_BRIDGE_BASE", "http://127.0.0.1:7778").rstrip("/")


def configure(bridge_base: str) -> None:
    global _BRIDGE
    if bridge_base:
        _BRIDGE = bridge_base.rstrip("/")


# ---------------------------------------------------------------------------
# Telemetry
# ---------------------------------------------------------------------------
def _fallback_cpu_ram() -> dict:
    """Linux /proc fallback when psutil is absent."""
    out = {"cpu_percent": None, "ram_percent": None, "ram_used_gb": None,
           "ram_total_gb": None}
    try:
        with open("/proc/meminfo") as fh:
            info = {}
            for line in fh:
                k, _, v = line.partition(":")
                info[k.strip()] = int(v.strip().split()[0])
        total = info.get("MemTotal", 0)
        avail = info.get("MemAvailable", 0)
        if total:
            out["ram_total_gb"] = round(total / 1048576, 1)
            out["ram_used_gb"] = round((total - avail) / 1048576, 1)
            out["ram_percent"] = round((total - avail) * 100.0 / total, 1)
    except Exception:
        pass
    try:
        load1 = os.getloadavg()[0]
        ncpu = os.cpu_count() or 1
        out["cpu_percent"] = round(min(100.0, load1 * 100.0 / ncpu), 1)
    except Exception:
        pass
    return out


def system_snapshot() -> dict:
    """One-shot machine vitals dict (never raises)."""
    snap: dict = {"time": time.strftime("%A, %d %B %Y %H:%M"),
                  "platform": sys.platform}
    if psutil is not None:
        try:
            snap["cpu_percent"] = psutil.cpu_percent(interval=0.15)
            vm = psutil.virtual_memory()
            snap["ram_percent"] = vm.percent
            snap["ram_used_gb"] = round(vm.used / 1073741824, 1)
            snap["ram_total_gb"] = round(vm.total / 1073741824, 1)
            batt = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
            if batt is not None:
                snap["battery_percent"] = round(batt.percent)
                snap["on_ac_power"] = bool(batt.power_plugged)
            snap["uptime_hours"] = round((time.time() - psutil.boot_time()) / 3600, 1)
        except Exception:
            snap.update(_fallback_cpu_ram())
    else:
        snap.update(_fallback_cpu_ram())

    # Active window title (Windows only, ctypes — no extra deps)
    if sys.platform == "win32":
        try:
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(length + 1)
            ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
            snap["active_window"] = buf.value
        except Exception:
            pass

    # Bridge telemetry (merges CPU/RAM measured by the Node bridge when up)
    try:
        r = requests.get(_BRIDGE + "/api/status", timeout=2)
        if r.status_code < 400:
            data = r.json()
            snap["bridge_online"] = True
            for key in ("cpu", "ram", "hostname"):
                if key in data:
                    snap[f"bridge_{key}"] = data[key]
    except Exception:
        snap["bridge_online"] = False
    return snap


def list_top_processes(limit: int = 5) -> list:
    """Heaviest processes by CPU (psutil required; empty list otherwise)."""
    if psutil is None:
        return []
    procs = []
    try:
        for p in psutil.process_iter(["name", "cpu_percent", "memory_percent"]):
            procs.append(p.info)
        procs.sort(key=lambda d: d.get("cpu_percent") or 0, reverse=True)
        return [{"name": d.get("name"),
                 "cpu": round(d.get("cpu_percent") or 0, 1),
                 "ram": round(d.get("memory_percent") or 0, 1)}
                for d in procs[:limit]]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Actions (all through the allowlisted bridge)
# ---------------------------------------------------------------------------
def bridge_action(command: str, timeout: int = 20) -> dict:
    """Run one allowlisted command on the local Windows bridge."""
    command = (command or "").strip()
    if not command:
        return {"ok": False, "error": "empty command"}
    try:
        r = requests.post(_BRIDGE + "/api/action",
                          json={"command": command}, timeout=timeout)
        data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if r.status_code < 400:
            return {"ok": True, "result": data.get("message") or data or "done"}
        return {"ok": False, "error": data.get("error") or f"bridge {r.status_code}"}
    except Exception as exc:
        return {"ok": False, "error": f"bridge offline: {exc}"}


def set_volume(action: str) -> dict:
    action = (action or "").strip().lower()
    mapping = {"up": "volume up", "down": "volume down",
               "mute": "mute volume", "unmute": "unmute volume"}
    if action not in mapping:
        return {"ok": False, "error": "action must be up/down/mute/unmute"}
    return bridge_action(mapping[action])


def open_url(url: str) -> dict:
    """Validated http/https open — bridge first, local webbrowser fallback."""
    url = (url or "").strip()
    parsed = urlparse(url if "://" in url else "https://" + url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return {"ok": False, "error": "only http/https URLs allowed"}
    clean = parsed.geturl()
    res = bridge_action(f"open url {clean}")
    if res.get("ok"):
        return res
    try:
        import webbrowser
        webbrowser.open(clean)
        return {"ok": True, "result": f"opened {parsed.netloc} locally"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def take_screenshot() -> dict:
    return bridge_action("take screenshot")


def lock_pc() -> dict:
    return bridge_action("lock pc")


def switch_window() -> dict:
    return bridge_action("switch window")
