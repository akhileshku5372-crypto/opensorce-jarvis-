"""Kokoro-82M dependency probe for KamiSensei Podcast Studio.

Exit code 0 -> every local-TTS dependency imports cleanly (prints PROBE OK).
Exit code 1 -> a dependency is missing/broken (re-run: powershell -File _install_kokoro.ps1).
Run:  python _probe_kokoro.py
"""
import importlib
import sys


def _check(module_name, attr=None):
    try:
        mod = importlib.import_module(module_name)
        if attr and not hasattr(mod, attr):
            return False, "missing attribute %r" % attr
        ver = getattr(mod, "__version__", None)
        return True, ver if ver is not None else "ok"
    except Exception as exc:  # noqa: BLE001 - intentional broad probe
        return False, "%s: %s" % (exc.__class__.__name__, str(exc)[:240])


def main() -> int:
    checks = [
        ("kokoro", "KPipeline"),
        ("torch", None),
        ("soundfile", None),
        ("misaki", None),
        ("fugashi", None),
        ("unidic_lite", None),
        ("scipy", None),
        ("transformers", None),
        ("phonemizer", None),
        ("espeakng_loader", None),
    ]
    failed = []
    print("Kokoro-82M dependency probe:")
    for name, attr in checks:
        ok, detail = _check(name, attr)
        print("  %s  %-14s (%s)" % ("OK  " if ok else "MISS", name, detail))
        if not ok:
            failed.append(name)
    if failed:
        print("\nPROBE FAIL: missing -> " + ", ".join(failed))
        print("Re-run:  powershell -NoProfile -ExecutionPolicy Bypass -File _install_kokoro.ps1")
        return 1
    print("\nPROBE OK: kokoro-82m-local engine is ready.")
    print("Start it:  python background/kokoro_podcast.py  (listens on 127.0.0.1:7779)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

