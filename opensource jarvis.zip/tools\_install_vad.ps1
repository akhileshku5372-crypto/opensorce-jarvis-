# Sequential venv installs (two parallel pips collide on the pip cache lock).
$root = 'c:\Users\PRATEEK\Downloads\jarvis 1.0.5'
$pip = Join-Path $root '.venv\Scripts\pip.exe'
$log = Join-Path $root '_install.log'
"=== $(Get-Date -Format s) pillow ===" | Out-File -Append $log -Encoding utf8
& $pip install Pillow --quiet 2>&1 | Out-File -Append $log -Encoding utf8
"=== $(Get-Date -Format s) torch cpu ===" | Out-File -Append $log -Encoding utf8
& $pip install torch --index-url https://download.pytorch.org/whl/cpu --quiet 2>&1 | Out-File -Append $log -Encoding utf8
"=== $(Get-Date -Format s) silero-vad ===" | Out-File -Append $log -Encoding utf8
& $pip install silero-vad --quiet 2>&1 | Out-File -Append $log -Encoding utf8
"=== DONE rc=$LASTEXITCODE ===" | Out-File -Append $log -Encoding utf8