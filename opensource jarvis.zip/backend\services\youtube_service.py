"""
KamiSensei YouTube Transcript Service — backend/services/youtube_service.py
===========================================================================
Canonical YouTube ingestion engine for the KamiSensei "+ Add sources" flow.

Responsibilities:

  1. ``extract_yt_transcript(video_url)`` — fetch the full caption track of a
     YouTube video (manual AND auto-generated subtitles) via
     ``youtube_transcript_api`` and return it cleaned into a single, highly
     readable continuous text string.
  2. Metadata (title / author) is resolved instantly through the stdlib
     oEmbed endpoint; ``yt-dlp`` (YoutubeDL, ``skip_download=True``) is used
     ONLY as a fallback metadata extractor — it NEVER downloads video or
     audio files.
  3. CLI contract consumed by the loopback bridge (local-bridge/server.cjs):
         python backend/services/youtube_service.py --url <link> --json
     which prints a single JSON object on stdout:
         {"status": "success", "title": ..., "author": ..., "transcript": ...}

The bridge validates the URL against a YouTube host allowlist before this
module ever sees it; this module re-validates defensively as well. No shell,
no arbitrary execution, loopback-only consumers.
"""

import argparse
import html
import json
import re
import sys
import io
import urllib.parse
import urllib.request

# Force UTF-8 on stdout so native-language characters (Japanese, Hindi, etc.)
# print safely instead of crashing with UnicodeEncodeError on Windows.
if hasattr(sys.stdout, 'encoding') and sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ── YouTube URL validation / video-id extraction ────────────────────────────
YOUTUBE_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtube-nocookie.com", "www.youtube-nocookie.com", "youtu.be", "www.youtu.be",
}

VIDEO_ID_PATTERNS = [
    re.compile(r"[?&]v=([A-Za-z0-9_-]{11})"),
    re.compile(r"youtu\.be/([A-Za-z0-9_-]{11})"),
    re.compile(r"/shorts/([A-Za-z0-9_-]{11})"),
    re.compile(r"/embed/([A-Za-z0-9_-]{11})"),
    re.compile(r"/live/([A-Za-z0-9_-]{11})"),
]
BARE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")

TAG_RE = re.compile(r"<[^>]+>")
WHITESPACE_RE = re.compile(r"\s+")
PUNCT_SPACE_RE = re.compile(r"\s+([,.!?;:])")


def is_youtube_url(url: str) -> bool:
    """Defensive host allowlist check (the bridge applies its own first)."""
    try:
        parsed = urllib.parse.urlsplit(str(url or ""))
        if parsed.scheme not in ("http", "https"):
            return False
        return bool(parsed.hostname) and parsed.hostname.lower() in YOUTUBE_HOSTS
    except Exception:
        return False


def extract_video_id(url: str) -> str:
    """Pull the 11-character video id out of any common YouTube URL shape."""
    raw = str(url or "").strip()
    if BARE_ID_RE.match(raw):
        return raw
    for pattern in VIDEO_ID_PATTERNS:
        match = pattern.search(raw)
        if match:
            return match.group(1)
    raise ValueError("Could not extract a YouTube video id from the provided link.")


# ── Transcript fetching (youtube-transcript-api) ────────────────────────────
def _transcript_segments(video_id: str):
    """
    Fetch the ORIGINAL-language caption track — never a translation.

    The old implementation ranked English first, so an English translation
    track would win over the video's native language (Japanese, Hindi, …).
    That is now reversed:

      1. Manually-created transcript (creator's own captions — highest fidelity).
      2. Auto-generated transcript (always in the video's spoken language).

    We never call .translate(), so a Japanese video yields Japanese text,
    a Hindi video yields Hindi text, etc., with native characters intact.

    Returns (segments, language_code, is_generated).
    """
    from youtube_transcript_api import YouTubeTranscriptApi

    api = YouTubeTranscriptApi()
    try:
        transcript_list = api.list(video_id)
        all_transcripts = list(transcript_list)
    except Exception as exc:
        raise RuntimeError(f"Could not list transcripts: {exc}")

    if not all_transcripts:
        raise RuntimeError("No caption tracks (manual or auto-generated) are available for this video.")

    # Split into manually-created vs auto-generated.  The list also contains
    # community-contributed translations in many languages (all marked
    # is_translatable), so we cannot just grab manual[0] — it might be Arabic
    # on an English video.  Auto-generated transcripts are ALWAYS in the video's
    # original spoken language, so they tell us which language to lock onto.
    manual = [t for t in all_transcripts if not getattr(t, "is_generated", False)]
    generated = [t for t in all_transcripts if getattr(t, "is_generated", False)]

    # Determine the video's original spoken language from auto-generated track.
    original_lang = None
    if generated:
        original_lang = getattr(generated[0], "language_code", "") or None
    elif manual:
        original_lang = getattr(manual[0], "language_code", "") or None

    chosen = None
    is_generated = False

    if original_lang:
        # Prefer a MANUAL transcript in the original language (creator's captions).
        manual_in_orig = [t for t in manual if getattr(t, "language_code", "") == original_lang]
        if manual_in_orig:
            chosen = manual_in_orig[0]
            is_generated = False
        else:
            # Fall back to auto-generated in the original language.
            gen_in_orig = [t for t in generated if getattr(t, "language_code", "") == original_lang]
            if gen_in_orig:
                chosen = gen_in_orig[0]
                is_generated = True

    # Last resort: whatever is available (should rarely happen).
    if chosen is None:
        if manual:
            chosen = manual[0]
            is_generated = False
        elif generated:
            chosen = generated[0]
            is_generated = True
        else:
            raise RuntimeError("No caption tracks are available for this video.")

    try:
        fetched = chosen.fetch()
    except Exception as exc:
        raise RuntimeError(f"Could not fetch transcript: {exc}")

    # Modern fetch() returns a FetchedTranscript object; older versions return
    # a plain list of dicts. Normalise both into [{"text", "start", "duration"}].
    if hasattr(fetched, "to_raw_data"):
        segments = fetched.to_raw_data()
    elif isinstance(fetched, list):
        segments = fetched
    else:
        segments = list(fetched)

    language_code = getattr(chosen, "language_code", "") or ""
    return segments, language_code, is_generated


def clean_transcript_text(segments) -> str:
    """
    Normalise raw caption JSON into one continuous, readable text string:
    strip legacy caption tags, unescape entities, collapse whitespace, tidy
    punctuation spacing, and drop consecutive duplicated caption lines that
    auto-generated tracks often emit.
    """
    lines = []
    for seg in segments or []:
        if isinstance(seg, dict):
            text = str(seg.get("text") or "")
        else:
            text = str(getattr(seg, "text", "") or "")
        text = html.unescape(TAG_RE.sub("", text))
        text = WHITESPACE_RE.sub(" ", text).strip()
        if text and (not lines or text.lower() != lines[-1].lower()):
            lines.append(text)
    joined = " ".join(lines)
    joined = PUNCT_SPACE_RE.sub(r"\1", joined)
    return joined.strip()


# ── Metadata (stdlib oEmbed first, yt-dlp ONLY as fallback) ─────────────────
def _oembed_metadata(url: str):
    """Instant, dependency-free title/author lookup via YouTube oEmbed."""
    endpoint = "https://www.youtube.com/oembed?format=json&url=" + urllib.parse.quote(str(url), safe="")
    request = urllib.request.Request(endpoint, headers={"User-Agent": "Mozilla/5.0 (KamiSensei local service)"})
    with urllib.request.urlopen(request, timeout=8) as response:
        data = json.loads((response.read() or b"{}").decode("utf-8", "replace"))
    return {"title": str(data.get("title") or ""), "author": str(data.get("author_name") or "")}


class _SilentLogger:
    """Swallows every yt-dlp log line so stdout stays pure JSON for the bridge."""

    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        pass


def _ytdlp_metadata(url: str):
    """
    FALLBACK metadata extractor. Uses the yt-dlp Python library with
    skip_download=True — it reads metadata only and NEVER downloads any
    video or audio content.
    """
    from yt_dlp import YoutubeDL

    options = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,       # metadata only, never media files
        "noplaylist": True,
        "socket_timeout": 15,
        "logger": _SilentLogger(),
    }
    with YoutubeDL(options) as ydl:
        info = ydl.extract_info(str(url), download=False)
    return {
        "title": str(info.get("title") or "") if info else "",
        "author": str(info.get("uploader") or info.get("channel") or "") if info else "",
    }


def fetch_metadata(url: str) -> dict:
    """Title/author resolution: instant oEmbed first, yt-dlp as the fallback."""
    try:
        meta = _oembed_metadata(url)
        if meta.get("title"):
            return {**meta, "metadata_source": "oembed"}
    except Exception:
        pass
    try:
        meta = _ytdlp_metadata(url)
        if meta.get("title"):
            return {**meta, "metadata_source": "yt-dlp"}
    except Exception:
        pass
    return {"title": "", "author": "", "metadata_source": "none"}


# ── Public entry point ───────────────────────────────────────────────────────
def extract_yt_transcript(video_url: str) -> dict:
    """
    Full pipeline: validate -> video id -> captions -> clean text -> metadata.

    Returns a JSON-safe dict:
        {"status": "success", "video_id", "title", "author", "language",
         "is_generated", "segment_count", "duration_chars", "transcript"}
    or {"status": "error", "error": "..."}.
    """
    url = str(video_url or "").strip()
    if not url:
        return {"status": "error", "error": "A YouTube URL is required."}
    if not is_youtube_url(url):
        return {"status": "error", "error": "Only youtube.com / youtu.be links are supported."}

    try:
        video_id = extract_video_id(url)
    except ValueError as exc:
        return {"status": "error", "error": str(exc)}

    try:
        segments, language_code, is_generated = _transcript_segments(video_id)
    except Exception as exc:
        message = str(exc) or exc.__class__.__name__
        return {"status": "error", "video_id": video_id,
                "error": f"Transcript unavailable: {message[:400]}"}

    transcript_text = clean_transcript_text(segments)
    if not transcript_text:
        return {"status": "error", "video_id": video_id,
                "error": "The caption track exists but produced no readable text."}

    metadata = fetch_metadata(url)
    return {
        "status": "success",
        "video_id": video_id,
        "title": metadata.get("title") or video_id,
        "author": metadata.get("author") or "",
        "metadata_source": metadata.get("metadata_source") or "none",
        "language": language_code,
        "is_generated": is_generated,
        "segment_count": len(segments),
        "duration_chars": len(transcript_text),
        "transcript": transcript_text,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="KamiSensei YouTube transcript extractor")
    parser.add_argument("--url", type=str, required=True, help="YouTube watch/shorts/youtu.be link")
    parser.add_argument("--json", action="store_true", help="Emit JSON (canonical bridge contract)")
    args = parser.parse_args()

    result = extract_yt_transcript(args.url)
    # Single-line JSON on stdout; diagnostics never pollute the bridge contract.
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
