﻿import os, json, time, requests
for line in open(".env", encoding="utf-8"):
    line=line.strip()
    if line and not line.startswith("#") and "=" in line:
        k,v=line.split("=",1); os.environ.setdefault(k.strip(), v.strip())
def go(name, url, hdr, payload, timeout=22):
    t0=time.time()
    try:
        r=requests.post(url, headers=hdr, json=payload, timeout=timeout)
        print(name, r.status_code, round(time.time()-t0,1), r.text[:170].replace(chr(10)," "), flush=True)
    except Exception as e:
        print(name, "ERR", type(e).__name__, str(e)[:110], flush=True)
gm=os.environ.get("GOOGLE_MODEL","gemini-2.5-flash")
for kn in ("GOOGLE_API_KEY","GOOGLE_API_KEY_2"):
    if os.environ.get(kn):
        go(kn, "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"%gm,
           {"x-goog-api-key":os.environ[kn]},
           {"contents":[{"parts":[{"text":"say OK"}]}],"generationConfig":{"maxOutputTokens":100}})
go("NVIDIA","https://integrate.api.nvidia.com/v1/chat/completions",
   {"Authorization":"Bearer "+os.environ.get("NVIDIA_API_KEY","")},
   {"model":os.environ.get("NVIDIA_MODEL","meta/llama-3.1-70b-instruct"),"max_tokens":50,
    "messages":[{"role":"user","content":"say OK"}]})
