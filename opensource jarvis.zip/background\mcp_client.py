"""Minimal MCP (Model Context Protocol) stdio client for JARVIS.

Implements the real thing, not a mock:
  * transport: newline-delimited JSON-RPC 2.0 over the server's stdio
    (the MCP stdio transport);
  * handshake: `initialize` -> `notifications/initialized` -> `tools/list`;
  * calls: `tools/call` with `{"name": ..., "arguments": {...}}`.

Safety (AGENTS.md: never pass arbitrary input to executables):
  * a server is only started when it is declared in `mcp/servers.json`
    (on-device config, never in `public/`);
  * `command` must be an allowlisted interpreter (python/node/py/npx/uvx/deno)
    or a script path inside this repository;
  * arguments are passed as an argv list - there is no shell, no `shell=True`;
  * every call has a timeout and a bounded output size;
  * tool *calls* need `"allowCall": true` on that server - otherwise the server
    is list-only and calls are refused with an honest message.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = Path(os.environ.get("JARVIS_MCP_CONFIG") or (ROOT / "mcp" / "servers.json"))
PROTOCOL_VERSION = "2024-11-05"
CLIENT_INFO = {"name": "jarvis-voice-engine", "version": "1.0.0"}

_ALLOWED_COMMANDS = {"python", "python3", "py", "node", "npx", "uvx", "deno"}
_MAX_OUTPUT = 20000
_DEFAULT_TIMEOUT = 20.0


def _load_config() -> dict:
    try:
        raw = CONFIG_PATH.read_text(encoding="utf-8", errors="ignore")
        data = json.loads(raw or "{}")
    except Exception:
        return {}
    servers = data.get("servers") if isinstance(data, dict) else None
    return servers if isinstance(servers, dict) else {}


def _resolve(entry: dict) -> tuple:
    """(argv, cwd, error) for one config entry - validated, never guessed."""
    command = str(entry.get("command") or "").strip()
    args = entry.get("args") or []
    if not command:
        return (None, None, "command missing")
    if not isinstance(args, list) or any(not isinstance(a, str) for a in args):
        return (None, None, "args must be a list of strings")
    # A script inside the repo is fine; anything else must be allowlisted.
    candidate = Path(command if os.path.isabs(command) else os.path.join(ROOT, command))
    inside_repo = candidate.is_file() and candidate.resolve().is_relative_to(ROOT.resolve())
    if not inside_repo and Path(command).name.lower() not in _ALLOWED_COMMANDS:
        return (None, None, "command '%s' is not allowlisted (repo script or %s)"
                % (Path(command).name, "/".join(sorted(_ALLOWED_COMMANDS))))
    argv = [sys.executable, str(candidate)] if inside_repo else [command]
    if inside_repo and sys.platform == "win32" and candidate.suffix.lower() == ".py":
        argv = [sys.executable, str(candidate)]     # never rely on file association
    argv += list(args)
    raw_cwd = entry.get("cwd") or ROOT
    cwd = Path(raw_cwd if os.path.isabs(str(raw_cwd)) else os.path.join(ROOT, str(raw_cwd)))
    if not cwd.resolve().is_relative_to(ROOT.resolve()):
        return (None, None, "cwd must stay inside the repository")
    return (argv, str(cwd), "")


def servers() -> list:
    """Config entries in a UI/voice friendly shape."""
    out = []
    for name, entry in sorted(_load_config().items()):
        if not isinstance(entry, dict):
            continue
        argv, cwd, error = _resolve(entry)
        out.append({
            "name": str(name),
            "enabled": bool(entry.get("enabled", True)) and not error,
            "configured": True,
            "allow_call": bool(entry.get("allowCall", False)),
            "description": str(entry.get("description") or ""),
            "read_only": bool(entry.get("readOnly", False)),
            "transport": "stdio",
            "error": error,
        })
    return out


def _run(server: dict, requests: list, timeout: float = _DEFAULT_TIMEOUT) -> dict:
    """Run the handshake + requests in one shot; returns {id: response|None, 'error': str}.

    All requests are written before reading, then stdin is closed - MCP stdio
    servers answer line by line and exit when stdin ends, so this cannot deadlock.
    """
    argv, cwd = server.get("argv"), server.get("cwd")
    if not argv:
        return {"error": server.get("error") or "server not usable"}
    payload = "".join(json.dumps(request) + "\n" for request in requests)
    flags = 0x08000000 if sys.platform == "win32" else 0
    try:
        proc = subprocess.Popen(
            argv, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
            creationflags=flags)
    except Exception as exc:
        return {"error": "spawn failed: %s: %s" % (type(exc).__name__, exc)}
    try:
        out, err = proc.communicate(payload, timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
            proc.communicate(timeout=5)
        except Exception:
            pass
        return {"error": "timeout after %.0fs" % timeout}
    responses = {}
    for line in (out or "").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            message = json.loads(line)
        except Exception:
            continue
        if isinstance(message, dict) and "id" in message:
            responses[message["id"]] = message
    if not responses:
        detail = (err or "").strip().splitlines()
        return {"error": "no JSON-RPC reply" + (" (%s)" % detail[-1][:120] if detail else "")}
    return responses


def _handshake(call_id: int = 1) -> list:
    return [
        {"jsonrpc": "2.0", "id": call_id, "method": "initialize",
         "params": {"protocolVersion": PROTOCOL_VERSION, "capabilities": {},
                    "clientInfo": CLIENT_INFO}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
    ]


def list_tools(name: str, timeout: float = _DEFAULT_TIMEOUT) -> dict:
    """`tools/list` for one server. Returns {ok, tools|error}."""
    server = _enabled(name)
    if not server:
        return {"ok": False, "error": "server '%s' is not configured/enabled" % name}
    if server.get("error"):
        return {"ok": False, "error": server["error"]}
    responses = _run(server, _handshake() + [
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}], timeout)
    if responses.get("error"):
        return {"ok": False, "error": responses["error"]}
    init = responses.get(1) or {}
    if "error" in init:
        return {"ok": False, "error": "initialize failed: %s" % init["error"].get("message")}
    listed = responses.get(2) or {}
    if "error" in listed:
        return {"ok": False, "error": "tools/list failed: %s" % listed["error"].get("message")}
    tools = ((listed.get("result") or {}).get("tools")) or []
    clean = []
    for tool in tools:
        if not isinstance(tool, dict) or not tool.get("name"):
            continue
        clean.append({
            "name": str(tool["name"]),
            "description": str(tool.get("description") or "")[:300],
            "schema": tool.get("inputSchema") or {},
            "annotations": tool.get("annotations") or {},
        })
    return {"ok": True, "tools": clean[:40],
            "server_info": (init.get("result") or {}).get("serverInfo") or {}}


def call_tool(name: str, tool: str, arguments: dict, timeout: float = _DEFAULT_TIMEOUT) -> dict:
    """`tools/call`. Requires allowCall on that server. Returns {ok, text|error}."""
    server = _enabled(name)
    if not server:
        return {"ok": False, "error": "server '%s' is not configured/enabled" % name}
    if server.get("error"):
        return {"ok": False, "error": server["error"]}
    if not server.get("allow_call"):
        return {"ok": False,
                "error": "server '%s' is list-only; set \"allowCall\": true in mcp/servers.json to allow tool calls" % name}
    if not tool:
        return {"ok": False, "error": "tool name required"}
    responses = _run(server, _handshake() + [{
        "jsonrpc": "2.0", "id": 2, "method": "tools/call",
        "params": {"name": tool, "arguments": arguments if isinstance(arguments, dict) else {}},
    }], timeout)
    if responses.get("error"):
        return {"ok": False, "error": responses["error"]}
    called = responses.get(2) or {}
    if "error" in called:
        return {"ok": False, "error": "%s" % called["error"].get("message")}
    result = called.get("result") or {}
    parts = []
    for block in result.get("content") or []:
        if isinstance(block, dict) and block.get("type") in (None, "text") and isinstance(block.get("text"), str):
            parts.append(block["text"])
    text = "\n".join(parts).strip()[:_MAX_OUTPUT]
    if result.get("isError"):
        return {"ok": False, "error": text or "tool reported an error"}
    return {"ok": True, "text": text or "(empty result)"}


def _enabled(name: str) -> dict:
    """Resolved spawn info for one enabled server ({} when not usable)."""
    for server in servers():
        if server["name"] == name and server["enabled"]:
            argv, cwd, error = _resolve(_load_config().get(name) or {})
            return {"argv": argv, "cwd": cwd, "allow_call": server["allow_call"],
                    "read_only": server["read_only"], "error": error, "name": name}
    return {}


def status(probe: bool = True, timeout: float = 8.0) -> list:
    """Per-server status. probe=True actually handshakes (honest, not guessed)."""
    out = []
    for server in servers():
        entry = {"name": server["name"], "enabled": server["enabled"],
                 "allow_call": server["allow_call"], "read_only": server["read_only"],
                 "tools": [], "ok": False, "error": server["error"] or "",
                 "description": server["description"]}
        if server["enabled"] and probe:
            listed = list_tools(server["name"], timeout=timeout)
            entry["ok"] = bool(listed.get("ok"))
            if listed.get("ok"):
                entry["tools"] = [tool["name"] for tool in listed.get("tools") or []]
            else:
                entry["error"] = listed.get("error", "unknown error")
        out.append(entry)
    return out


def describe(probe: bool = True) -> str:
    """Spoken summary for the `mcp status` voice route."""
    entries = status(probe=probe)
    if not entries:
        return ("Sir, koi MCP connector configured nahi hai. mcp/servers.json me "
                "server add kijiye (command allowlisted hona chahiye).")
    good = [e for e in entries if e["enabled"] and e["ok"]]
    bad = [e for e in entries if e["enabled"] and not e["ok"]]
    off = [e for e in entries if not e["enabled"]]
    parts = ["Sir, %d connector: %d online" % (len(entries), len(good))]
    if good:
        parts.append("(%s)" % ", ".join(
            "%s: %d tools" % (e["name"], len(e["tools"])) for e in good))
    for entry in bad:
        parts.append("%s offline (%s)" % (entry["name"], (entry["error"] or "error")[:70]))
    for entry in off:
        parts.append("%s disabled" % entry["name"])
    return "; ".join(parts) + "."


def tools_snapshot(probe: bool = True, timeout: float = 8.0) -> list:
    """[{server, tool, description}] across enabled servers (for UI + prompt)."""
    rows = []
    for server in servers():
        if not server["enabled"]:
            continue
        listed = list_tools(server["name"], timeout=timeout)
        if not listed.get("ok"):
            continue
        for tool in listed.get("tools") or []:
            rows.append({"server": server["name"], "tool": tool["name"],
                         "description": tool["description"],
                         "schema": tool.get("schema") or {},
                         "annotations": tool.get("annotations") or {},
                         "read_only": server["read_only"],
                         "allow_call": server["allow_call"]})
    return rows


def catalog(max_rows: int = 12) -> str:
    """Prompt fragment listing callable MCP tools (empty string when none)."""
    rows = [r for r in tools_snapshot() if r["allow_call"]][:max_rows]
    if not rows:
        return ""
    listed = " | ".join("%s.%s: %s" % (r["server"], r["tool"], r["description"][:110])
                        for r in rows)
    return (" MCP CONNECTORS (external tools you can call): %s. "
            "Sir says 'mcp call <server>.<tool> {json}' and JARVIS runs it locally." % listed)


def find_tool(tool: str) -> list:
    """Enabled+callable servers exposing `tool`."""
    wanted = str(tool or "").strip().lower()
    return [r for r in tools_snapshot() if r["allow_call"] and r["tool"].lower() == wanted]
