"""Cowork tools: default registry factory for the planning loop.

build_default_registry() wires the Open-Interpreter-inspired OS executor
(os_executor.py) and the Browser-Use-inspired web agent (browser_agent.py)
into the cortex ToolRegistry. Core routing loop untouched - yeh sirf
factory hai, caller (voice engine / cowork UI) decide karta hai kab call
karna hai.

Permission Guard coverage:
  * read/list/research/extract/snapshot = free (read-only)
  * os_write_file / os_run_command / MCP tools not explicitly marked read-only =
    requires_confirmation=True, so the cortex confirm gate asks the user before
    anything changes.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path


def _load(name: str):
    import importlib.util
    import sys
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    root = Path(__file__).resolve().parent.parent
    path = root / "background" / (name + ".py")
    spec = importlib.util.spec_from_file_location(full, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load("cortex")
os_executor = _load("os_executor")
browser_agent = _load("browser_agent")
mcp_client = _load("mcp_client")
app_index = _load("app_index")
whatsapp_sender = _load("whatsapp_sender")
whatsapp_web = _load("whatsapp_web")
screen_agent = _load("screen_agent")


def _mcp_tool_name(server: str, tool: str) -> str:
    raw = "mcp_%s_%s" % (server, tool)
    safe = re.sub(r"[^a-zA-Z0-9_]", "_", raw)
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$", safe):
        return ""
    if len(safe) > 64:
        safe = safe[:47] + "_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return safe


def _mcp_handler(server: str, tool: str, schema: dict) -> callable:
    def _handler(args: dict) -> dict:
        supplied = dict(args or {})
        properties = schema.get("properties") if isinstance(schema, dict) else {}
        properties = properties if isinstance(properties, dict) else {}
        supplied.pop("tool", None)
        if not properties:
            supplied = {}
        else:
            required = schema.get("required") if isinstance(schema, dict) else []
            required = set(required) if isinstance(required, list) else set()
            missing = required - set(supplied)
            if missing:
                return {"ok": False,
                        "output": "missing MCP argument(s): %s" % ", ".join(sorted(missing))}
            # Never forward planner-invented properties outside the server schema.
            supplied = {key: value for key, value in supplied.items() if key in properties}
        try:
            result = mcp_client.call_tool(server, tool, supplied, timeout=30.0)
        except Exception as exc:
            return {"ok": False, "output": "MCP connector failed: %s" % exc}
        if not result.get("ok"):
            return {"ok": False, "output": "MCP connector failed: %s" %
                    result.get("error", "unknown error")}
        return {"ok": True, "output": str(result.get("text") or ""),
                "server": server, "tool": tool}
    return _handler


def register_mcp_tools(registry: "cortex.ToolRegistry") -> dict:
    """Expose configured, callable MCP tools to the existing Cortex loop."""
    try:
        rows = mcp_client.tools_snapshot(probe=True, timeout=4.0)
    except Exception as exc:
        return {"registered": 0, "skipped": 0, "error": str(exc)}
    registered = skipped = 0
    for row in rows:
        if not isinstance(row, dict) or not row.get("allow_call"):
            continue
        server = str(row.get("server") or "").strip()
        original = str(row.get("tool") or "").strip()
        name = _mcp_tool_name(server, original)
        if not name or not server or not original:
            skipped += 1
            continue
        annotations = row.get("annotations") if isinstance(row.get("annotations"), dict) else {}
        # The per-tool MCP readOnlyHint is authoritative: the browser server
        # marks browse/read_page/find_text readOnlyHint=True and click/type
        # readOnlyHint=False. Gating on the server-level "read_only" flag alone
        # confirm-gated harmless read-only research, which then failed closed
        # over HTTP (no human to approve) and killed whole agent goals. So:
        # an explicit True makes the tool safe, an explicit False always gates,
        # and an absent hint falls back to the server-level flag.
        hint = annotations.get("readOnlyHint")
        if hint is True:
            read_only = True
        elif hint is False:
            read_only = False
        else:
            read_only = bool(row.get("read_only"))
        description = "%s [MCP %s.%s]" % (
            str(row.get("description") or "MCP tool")[:260], server, original)
        schema = row.get("schema") if isinstance(row.get("schema"), dict) else {}
        ok, _ = registry.register(cortex.ToolSpec(
            name, description, _mcp_handler(server, original, schema),
            parameters=schema.get("properties") if isinstance(schema.get("properties"), dict) else {},
            requires_confirmation=not read_only, timeout_s=35.0,
            tags=("mcp", server, original)))
        if ok:
            registered += 1
        else:
            skipped += 1
    return {"registered": registered, "skipped": skipped, "error": ""}


# ── Permission gate for CORE tools ───────────────────────────────────────────
# Plugin tools are wrapped by extensions.register_plugin_tools, but the desktop
# control surface (os_*, gui_*) was registered raw: `computer_control` in
# permissions.json mapped to ZERO tools, so a deny could never block a click or
# a keystroke. Same two-gate model as plugins - one spoken "confirm" satisfies
# both (the cortex gate calls permissions.grant_approval(tool) right after the
# user approves, and this wrapper consumes it once), and a `deny` always wins
# because check() ignores `approved` for DENY.
_PERMISSION_CATEGORY = {
    # mouse / keyboard / window / app control
    "gui_locate_and_click": "computer_control",
    "gui_type_into": "computer_control",
    "gui_type_active": "computer_control",
    "gui_press_key": "computer_control",
    "gui_press_combo": "computer_control",
    "gui_focus_app": "computer_control",
    "gui_scroll": "computer_control",
    "os_launch_app": "computer_control",
    "os_open_file": "computer_control",
    # screen capture is perception: it shows the room, so it rides `camera`
    "gui_read_screen_region": "camera",
    # repo mutation
    "os_write_file": "edit_files",
    "os_run_command": "execute_commands",
    # read-only, `read_files` defaults to auto
    "os_read_file": "read_files",
    "os_list_files": "read_files",
    "os_search_text": "read_files",
    "os_find_files": "read_files",
    "os_find_apps": "read_files",
}


def _permission_wrapped(spec):
    """Same spec, handler guarded by the shared permission engine.

    No shell, no eval - just the same two gates every plugin tool already has.
    A tool whose category is switched to `ask` but which is not confirm-gated
    fails closed with a plain reason instead of silently running.
    """
    category = _PERMISSION_CATEGORY.get(spec.name)
    if not category:
        return spec
    perms = _load("permissions")
    handler = spec.handler
    name = spec.name

    def _call(args: dict) -> dict:
        approved = perms.take_approval(name)
        verdict = perms.check(category, tool=name, args=args or {},
                              approved=approved)
        if not verdict["allowed"]:
            if verdict.get("requires_approval") and not spec.requires_confirmation:
                return {"ok": False,
                        "output": ("%s now needs approval but is not wired to "
                                   "the confirm gate - %s is blocked until the "
                                   "policy allows it."
                                   % (name, category)),
                        "requires_approval": True}
            return {"ok": False, "output": verdict["reason"],
                    "requires_approval": verdict.get("requires_approval")}
        try:
            out = handler(dict(args or {}))
        except Exception as exc:
            return {"ok": False, "output": "%s failed: %s: %s"
                                       % (name, type(exc).__name__, exc)}
        if isinstance(out, dict):
            return out
        return {"ok": True, "output": str(out)}

    return cortex.ToolSpec(
        name, spec.description, _call,
        parameters=spec.parameters,
        requires_confirmation=spec.requires_confirmation,
        timeout_s=spec.timeout_s,
        tags=tuple(spec.tags) + ("permission", category))


def build_default_registry() -> "cortex.ToolRegistry":
    registry = cortex.ToolRegistry()
    for spec in os_executor.specs():
        registry.register(_permission_wrapped(spec))
    for spec in app_index.specs():
        registry.register(_permission_wrapped(spec))
    for spec in whatsapp_sender.specs():
        registry.register(spec)
    for spec in browser_agent.specs():
        registry.register(spec)
    if screen_agent is not None:
        for spec in screen_agent.specs():
            registry.register(_permission_wrapped(spec))
    if whatsapp_web is not None:
        for spec in whatsapp_web.specs():
            registry.register(spec)
    # Discovery is real: only tools successfully returned by configured stdio
    # servers are registered. Offline/unavailable connectors are skipped rather
    # than replaced with mock implementations.
    register_mcp_tools(registry)
    return registry


def catalog(max_rows: int = 16) -> str:
    return build_default_registry().catalog(max_rows=max_rows)


def describe() -> str:
    registry = build_default_registry()
    specs = registry.list()
    free = [s.name for s in specs if not s.requires_confirmation]
    gated = [s.name for s in specs if s.requires_confirmation]
    return ("Sir, cowork tools ready: %d tools (%s free, %s confirm-gated)."
            % (len(specs), len(free), len(gated)))
