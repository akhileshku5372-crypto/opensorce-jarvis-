// Isolated, read-only layout audit. No dependencies or desktop actions.
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const phase = process.argv[2] || 'before'
const out = path.join(root, 'artifacts', 'ui-audit', phase)
mkdirSync(out, { recursive: true })
// Distinguish a page-level overflow (real bug) from an intentional
// internal horizontal scroller (e.g. .ks-featured-row): only elements
// reachable via an `overflow-x: hidden|clip|auto|scroll` ancestor chain
// count as page overflow; inner scroller children are reported separately.
const SCROLLER_SEL = '.ks-featured-row,.ks-tabs,.chat-body-container,.chat-log,.activity-list,.nav-list,.ks-nb-grid,.ks-tab-search,.ks-chat-messages,.module-upgrade-grid,.rail-panel .activity-list,.rail-chat-list,.chat-history-list'
const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-ui-audit-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })
setTimeout(() => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  process.exit(124)
}, 110000).unref()
const wait = ms => new Promise(resolve => setTimeout(resolve, ms))
let ws, seq = 0
const pending = new Map(), errors = [], results = []
const endpoint = new Promise((resolve, reject) => {
  let log = ''
  const timer = setTimeout(() => reject(new Error('Chrome startup timed out')), 15000)
  chrome.stderr.on('data', data => {
    log += data
    const match = log.match(/DevTools listening on (ws:\/\/[^\s]+)/)
    if (match) { clearTimeout(timer); resolve(match[1]) }
  })
  chrome.on('error', reject)
})
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++seq
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' timeout')) }, 15000)
    pending.set(id, { resolve, reject, timer })
    ws.send(JSON.stringify({ id, method, params }))
  })
}
async function evaluate(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails))
  return r.result.value
}
try {
  const browserUrl = await endpoint
  const origin = new URL(browserUrl).origin.replace('ws:', 'http:')
  const targets = await (await fetch(origin + '/json/list')).json()
  const target = targets.find(t => t.type === 'page') || targets[0]
  if (!target) throw new Error('no debuggable target')
  ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true })
    ws.addEventListener('error', reject, { once: true })
  })
  ws.addEventListener('message', event => {
    const msg = JSON.parse(String(event.data))
    if (msg.id && pending.has(msg.id)) {
      const p = pending.get(msg.id); clearTimeout(p.timer); pending.delete(msg.id)
      if (msg.error) p.reject(new Error(JSON.stringify(msg.error))); else p.resolve(msg.result)
    } else if (msg.method === 'Runtime.exceptionThrown') errors.push(msg.params.exceptionDetails)
    else if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') errors.push(msg.params.entry)
  })
  await send('Page.enable'); await send('Runtime.enable'); await send('Log.enable')
  await send('Page.navigate', { url: 'http://127.0.0.1:7777' })
  await wait(4500)
  const sizes = process.env.AUDIT_SIZES ? JSON.parse(process.env.AUDIT_SIZES) : [[390,844],[1366,768]]
  const views = await evaluate(`Array.from(document.querySelectorAll('.nav-item[data-view]'), e => e.dataset.view)`)
  for (const [width, height] of sizes) {
    await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false })
    await wait(250)
    for (const view of views) {
      const layout = await evaluate(`(() => {
        document.querySelector('.nav-item[data-view="${view}"]')?.click();
        window.scrollTo(0,0);
        const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
        const outside = [];
        const innerScroll = [];
        // Every view panel must live inside .workspace, otherwise it ignores the
        // fixed sidebar offset + workspace padding and gets clipped under the
        // sidebar (the Modules & Upgrades bug) while this scan never sees it.
        const strays = [...document.querySelectorAll('[data-view-panel]')]
          .filter(v => !v.closest('.workspace'))
          .map(v => v.dataset.viewPanel);
        for (const e of document.querySelectorAll('.workspace *')) {
          if (outside.length >= 12 && innerScroll.length >= 6) break;
          if (!visible(e) || e.closest('#toast-region')) continue;
          const r = e.getBoundingClientRect();
          if (!(r.width > 0 && (r.right > innerWidth + 2 || r.left < -2))) continue;
          const rec = {tag:e.tagName, id:e.id, cls:String(e.className).slice(0,80), width:Math.round(r.width)};
          // Intentional internal scroller content (e.g. workbook cards in the
          // featured row) is NOT page overflow — it scrolls inside its row.
          if (e.closest('${SCROLLER_SEL}')) { if (innerScroll.length < 6) innerScroll.push(rec); continue; }
          outside.push(rec);
        }
        return {pageWidth:document.documentElement.scrollWidth, viewport:innerWidth, height:document.documentElement.scrollHeight, outside, innerScroll, strays};
      })()`)
      results.push({ width, height, view, ...layout })
      if (['dashboard','settings','kamisensei','modules'].includes(view)) {
        const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
        writeFileSync(path.join(out, `${view}-${width}.png`), Buffer.from(shot.data, 'base64'))
      }
    }
  }
  const overflow = results.filter(r => r.pageWidth > r.width + 2 || r.outside.length || r.strays.length)
  writeFileSync(path.join(out, 'report.json'), JSON.stringify({ results, errors }, null, 2))
  console.log(JSON.stringify({ cases: results.length, overflow, errors, out }, null, 2))
} finally {
  try { if (ws) ws.close() } catch {}
  // Only terminate the isolated browser process tree created by this audit.
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { chrome.kill() } catch {}
  await wait(800)
  try { rmSync(profile, { recursive: true, force: true, maxRetries: 3 }) } catch {}
}
