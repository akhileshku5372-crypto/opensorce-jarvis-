"""Phase 2 - document RAG over the user's real files.

"JARVIS, search my documents for the battery report" is answered from the
files that are actually on this machine: PDF (PyMuPDF), DOCX (python-docx),
PPTX (python-pptx) and plain text/Markdown/CSV, embedded locally in ChromaDB.
No cloud call is involved in retrieval.

Design rules (same honesty rules as the rest of the repo)
---------------------------------------------------------
* Nothing is indexed by accident. Only an explicit allowlist of document
  extensions is scanned, and only in Desktop/Documents unless the user names a
  folder. On this machine that filter turns ~185,000 files into ~1,850 real
  documents (88 MB); without it the index would be mostly .pyc/.class/.jar
  noise and the embeddings would cost minutes of CPU per run.
* Code/config files (.py, .json, ...) are indexed ONLY when the user names the
  folder explicitly - a whole-repo dump is not "my documents".
* Every run reports scanned / indexed / updated / unchanged / failed / no_text
  counts, with the reason per failure. A scanned PDF with no text layer is
  reported, never silently "indexed".
* Re-indexing is incremental by (mtime, size); unchanged files are not
  re-embedded. A changed file has its old chunks deleted first, so stale text
  can never be cited.
* The store lives under the shared data root (storage_paths.jarvis_docs_dir)
  and honours the shared storage quota.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

try:
    import storage_paths as _paths
except ImportError:                                  # pragma: no cover
    from background import storage_paths as _paths

COLLECTION = "jarvis_documents"

# Documents the user means by "my documents".
DOC_EXTS = {".pdf", ".docx", ".txt", ".md", ".pptx", ".csv", ".rtf", ".odt"}
# Project files: only when the user names the folder explicitly ("index the
# folder C:\dev\myproject"), because a default scan would drown in them.
CODE_EXTS = {".py", ".js", ".ts", ".tsx", ".jsx", ".html", ".css", ".c", ".cpp",
             ".h", ".hpp", ".java", ".json", ".yaml", ".yml", ".toml", ".sql"}
# Directories that never hold user documents worth citing. Deliberately does
# NOT include "appdata": that name is both a real Windows tree and a common
# parent of temp/test roots, and skipping it silently emptied whole scans.
SKIP_PARTS = {
    "node_modules", ".git", ".venv", "venv", "site-packages", "__pycache__",
    ".cache", ".next", ".nuxt", "build", "dist", "target", "obj",
    "$recycle.bin", "system volume information", ".gradle", ".m2", ".conda",
    ".npm", ".vscode", ".idea", ".pytest_cache", ".mypy_cache",
}
MAX_FILE_BYTES = 20 * 1024 * 1024          # a 20 MB+ doc is not worth the time
CHUNK_CHARS = 1100
MAX_CHUNKS_PER_FILE = 400
EMBED_BATCH = 64                           # chunks per ChromaDB add
ROOTS_ENV = "JARVIS_DOC_ROOTS"             # ';' separated absolute paths


# ── store ──────────────────────────────────────────────────────────────────


def _collection():
    """Open the document collection, or None when ChromaDB is unavailable."""
    try:
        import chromadb
        from chromadb.config import Settings
        _paths.jarvis_docs_dir().mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(
            path=str(_paths.jarvis_docs_dir()),
            settings=Settings(anonymized_telemetry=False))
        return client.get_or_create_collection(
            name=COLLECTION, metadata={"hnsw:space": "cosine"})
    except Exception:
        return None


def _client():
    """The persistent client, for operations that need delete_collection."""
    try:
        import chromadb
        from chromadb.config import Settings
        _paths.jarvis_docs_dir().mkdir(parents=True, exist_ok=True)
        return chromadb.PersistentClient(
            path=str(_paths.jarvis_docs_dir()),
            settings=Settings(anonymized_telemetry=False))
    except Exception:
        return None


def _manifest_path() -> Path:
    return _paths.jarvis_docs_dir() / "manifest.json"


def _load_manifest() -> dict:
    try:
        data = json.loads(_manifest_path().read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data.setdefault("files", {})
            return data
    except Exception:
        pass
    return {"version": 1, "files": {}}


def _save_manifest(manifest: dict) -> None:
    try:
        _manifest_path().write_text(
            json.dumps(manifest, indent=1, default=str), encoding="utf-8")
    except Exception:
        pass


# ── scanning ───────────────────────────────────────────────────────────────


def _default_roots():
    """Desktop + Documents, or JARVIS_DOC_ROOTS when set."""
    raw = (os.environ.get(ROOTS_ENV) or "").strip()
    if raw:
        found = []
        for part in re.split(r"[;|]", raw):
            part = part.strip()
            if not part:
                continue
            candidate = Path(os.path.expandvars(part))
            if candidate.is_dir():
                found.append(candidate)
        if found:
            return found
    home = Path.home()
    roots = [home / name for name in ("Desktop", "Documents")
             if (home / name).is_dir()]
    return roots or ([home] if home.is_dir() else [])


def _skippable(path: Path, store_dir: Path) -> bool:
    for part in path.parts:
        low = part.casefold()
        if low in SKIP_PARTS or part.startswith("$") or part.startswith("."):
            return True
    # Never index the RAG store's own files (embeddings, manifest). Only the
    # store subdir - not the whole data root - because on a legacy layout the
    # data root is the repo itself and the repo's .md files are real documents.
    try:
        path.resolve().relative_to(store_dir.resolve())
        return True
    except Exception:
        return False


def _scan(roots, include_code=False):
    """Eligible (path, mtime, size) rows + skip counters. Pure filesystem."""
    exts = set(DOC_EXTS) | (set(CODE_EXTS) if include_code else set())
    files, skipped = [], {"ext": 0, "big": 0, "dir": 0, "other": 0}
    store_dir = _paths.jarvis_docs_dir()
    for root in roots:
        root = Path(root)
        for path in root.rglob("*"):
            try:
                if not path.is_file():
                    continue
                if _skippable(path, store_dir):
                    skipped["dir"] += 1
                    continue
                if path.suffix.lower() not in exts:
                    skipped["ext"] += 1
                    continue
                stat = path.stat()
                if stat.st_size > MAX_FILE_BYTES:
                    skipped["big"] += 1
                    continue
                if stat.st_size == 0:
                    skipped["other"] += 1
                    continue
                files.append((path, stat.st_mtime, stat.st_size))
            except OSError:
                skipped["other"] += 1
    files.sort(key=lambda row: str(row[0]).casefold())
    return files, skipped


# ── extraction ─────────────────────────────────────────────────────────────


def _fitz():
    try:
        import pymupdf as fitz
        return fitz
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            return None


def _pdf_pages(path: Path):
    """[(page_number, text)] for a PDF; page numbers feed the citations."""
    fitz = _fitz()
    if fitz is None:
        return None, "pymupdf_missing"
    pages = []
    with fitz.open(str(path)) as doc:
        if doc.needs_pass:
            return None, "password_protected"
        for number, page in enumerate(doc, start=1):
            try:
                text = page.get_text("text") or ""
            except Exception:
                continue
            if text.strip():
                pages.append((number, text))
    return pages, ""


def _docx_pages(path: Path):
    """DOCX has no reliable page numbers; sections of one big chunk."""
    try:
        import docx
    except ImportError:
        return None, "python_docx_missing"
    doc = docx.Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text and p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    text = "\n".join(parts).strip()
    return ([(None, text)] if text else []), ""


def _pptx_pages(path: Path):
    """[(slide_number, text)] so a citation can name the slide."""
    try:
        from pptx import Presentation
    except ImportError:
        return None, "python_pptx_missing"
    deck = Presentation(str(path))
    pages = []
    for number, slide in enumerate(deck.slides, start=1):
        parts = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                text = shape.text_frame.text
                if text and text.strip():
                    parts.append(text)
        try:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = slide.notes_slide.notes_text_frame.text
                if notes and notes.strip():
                    parts.append(notes)
        except Exception:
            pass
        body = "\n".join(parts).strip()
        if body:
            pages.append((number, body))
    return pages, ""


def _text_pages(path: Path):
    raw = path.read_bytes()[:MAX_FILE_BYTES]
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return [(None, raw.decode("utf-16", "replace"))], ""
    try:
        return [(None, raw.decode("utf-8"))], ""
    except UnicodeDecodeError:
        # cp1252 never fails on any byte, so this is a lossless fallback.
        try:
            return [(None, raw.decode("cp1252"))], ""
        except Exception:
            return [(None, raw.decode("utf-8", "replace"))], ""


_EXTRACTORS = {".pdf": _pdf_pages, ".docx": _docx_pages, ".pptx": _pptx_pages}


def _pages_of(path: Path):
    """(pages, error). pages = [(page_number|None, text)]. Never raises."""
    extract = _EXTRACTORS.get(path.suffix.lower(), _text_pages)
    try:
        return extract(path)
    except Exception as exc:
        return None, "%s: %s" % (type(exc).__name__, str(exc)[:120])


def _chunks(text, limit=CHUNK_CHARS):
    """Paragraph-aware chunks; long paragraphs are hard-split at `limit`."""
    body = re.sub(r"[ \t]+", " ", str(text or ""))
    body = re.sub(r"\n{3,}", "\n\n", body).strip()
    if not body:
        return []
    out, current = [], ""
    for para in body.split("\n\n"):
        para = para.strip()
        if not para:
            continue
        while len(para) > limit:
            head, para = para[:limit], para[limit:]
            if current:
                out.append(current)
                current = ""
            out.append(head)
        if not current:
            current = para
        elif len(current) + len(para) + 2 <= limit:
            current += "\n\n" + para
        else:
            out.append(current)
            current = para
    if current:
        out.append(current)
    return out[:MAX_CHUNKS_PER_FILE]


# ── indexing ───────────────────────────────────────────────────────────────


class _QuotaStop(Exception):
    pass


def index(roots=None, include_code=None, limit=0, reset=False, progress=None):
    """Index documents synchronously. Returns an honest report dict.

    Slow by nature (real files, local embeddings) - the voice/HTTP callers use
    start_index() so nothing blocks; tests call this directly.
    """
    collection = _collection()
    if collection is None:
        return {"ok": False, "error": "doc_store_unavailable"}
    root_list = [Path(r) for r in (roots or _default_roots())]
    if not root_list:
        return {"ok": False, "error": "no_roots",
                "detail": "Desktop/Documents nahi mile, Sir."}
    # A folder the user named himself may be a project, so code/config files
    # count there; the default Desktop/Documents scan stays documents-only.
    if include_code is None:
        include_code = bool(roots)
    if reset:
        client = _client()
        if client is not None:
            try:
                client.delete_collection(COLLECTION)
            except Exception:
                pass
            collection = client.get_or_create_collection(
                name=COLLECTION, metadata={"hnsw:space": "cosine"})
        else:
            try:
                collection.delete(where={"path": {"$ne": ""}})
            except Exception:
                pass
    manifest = _load_manifest()
    if reset:
        manifest = {"version": 1, "files": {}}
    known = manifest.setdefault("files", {})
    files, skipped = _scan(root_list, include_code=include_code)
    total_found = len(files)
    if limit:
        files = files[:int(limit)]
    report = {
        "ok": True, "roots": [str(r) for r in root_list],
        "include_code": bool(include_code),
        "scanned": len(files), "found": total_found,
        "indexed": 0, "updated": 0, "unchanged": 0, "failed": 0,
        "no_text": 0, "chunks": 0, "skipped": skipped,
        "stopped": "", "errors": [],
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S"), "finished_at": "",
    }

    batch_ids, batch_docs, batch_meta = [], [], []

    def flush():
        if not batch_ids:
            return
        estimate = sum(len(d) * 4 for d in batch_docs)
        if not _paths.guard_write(estimate):
            raise _QuotaStop()
        collection.add(ids=list(batch_ids), documents=list(batch_docs),
                       metadatas=list(batch_meta))
        batch_ids.clear()
        batch_docs.clear()
        batch_meta.clear()

    stopped = ""
    for position, (path, mtime, size) in enumerate(files, start=1):
        key = str(path)
        previous = known.get(key) or {}
        if not reset and previous.get("mtime") == mtime \
                and previous.get("size") == size:
            report["unchanged"] += 1
            if progress:
                progress({"phase": "scan", "done": position,
                          "total": len(files), "file": key})
            continue
        pages, error = _pages_of(path)
        if error:
            report["failed"] += 1
            if len(report["errors"]) < 20:
                report["errors"].append({"file": key, "error": error})
            known[key] = {"mtime": mtime, "size": size, "status": "error",
                          "error": error, "indexed_at":
                          time.strftime("%Y-%m-%d %H:%M")}
            continue
        rows = [(page, chunk) for page, text in (pages or [])
                for chunk in _chunks(text)]
        try:
            # Stale chunks of a changed file must never survive: the old text
            # would be cited as if it were current.
            collection.delete(where={"path": key})
        except Exception:
            pass
        if not rows:
            report["no_text"] += 1
            known[key] = {
                "mtime": mtime, "size": size, "chunks": 0, "status": "no_text",
                "indexed_at": time.strftime("%Y-%m-%d %H:%M"),
                # A scanned PDF is the classic case: no text layer at all.
                "error": ("text layer nahi mila"
                          if path.suffix.lower() == ".pdf" else "khali file")}
            continue
        name = path.name
        for page, chunk in rows:
            chunk_id = "%s#%s#%d" % (key.casefold(), page if page else 0,
                                     len(batch_ids))
            batch_ids.append(chunk_id)
            batch_docs.append(chunk)
            batch_meta.append({"path": key, "name": name,
                               "page": int(page) if page else 0,
                               "mtime": float(mtime)})
        try:
            flush()
        except _QuotaStop:
            stopped = "storage_quota_reached"
            break
        except Exception as exc:
            report["failed"] += 1
            known[key] = {"mtime": mtime, "size": size, "status": "error",
                          "error": "%s: %s" % (type(exc).__name__,
                                               str(exc)[:120])}
            continue
        known[key] = {"mtime": mtime, "size": size, "chunks": len(rows),
                      "pages": len(pages or []),
                      "status": "ok", "indexed_at":
                      time.strftime("%Y-%m-%d %H:%M")}
        report["chunks"] += len(rows)
        report["indexed" if not previous else "updated"] += 1
        if progress:
            progress({"phase": "embed", "done": position, "total": len(files),
                      "file": key, "chunks": report["chunks"]})
        if position % 100 == 0:
            _save_manifest(manifest)

    try:
        flush()
    except _QuotaStop:
        stopped = "storage_quota_reached"
    except Exception as exc:
        report["errors"].append({"file": "", "error":
                                 "%s: %s" % (type(exc).__name__, exc)})
    if stopped:
        report["stopped"] = stopped
        report["ok"] = False
    # Files that no longer exist are dropped from the store and the manifest,
    # so a search can never cite a deleted document.
    stale = [p for p in known if not Path(p).exists()]
    for path_key in stale:
        try:
            collection.delete(where={"path": path_key})
        except Exception:
            pass
        known.pop(path_key, None)
    report["removed"] = len(stale)
    report["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    manifest["last_run"] = report
    manifest["roots"] = report["roots"]
    _save_manifest(manifest)
    return report


# Module-level state for the background runner.
_RUN_LOCK = threading.Lock()
_RUN = {"thread": None, "progress": {}, "report": None}


def index_running() -> bool:
    thread = _RUN.get("thread")
    return bool(thread is not None and thread.is_alive())


def start_index(roots=None, include_code=None, limit=0, reset=False) -> dict:
    """Kick off indexing on a daemon thread; returns immediately."""
    if index_running():
        return {"ok": False, "error": "already_running",
                "progress": dict(_RUN.get("progress") or {})}
    _RUN["progress"] = {}
    _RUN["report"] = None

    def _work():
        try:
            _RUN["report"] = index(roots=roots, include_code=include_code,
                                   limit=limit, reset=reset, progress=(
                                       lambda p: _RUN.update({"progress": p})))
        except Exception as exc:
            _RUN["report"] = {"ok": False, "error":
                              "%s: %s" % (type(exc).__name__, exc)}

    thread = threading.Thread(target=_work, name="jarvis-doc-index",
                              daemon=True)
    _RUN["thread"] = thread
    thread.start()
    return {"ok": True, "started": True,
            "roots": [str(r) for r in (roots or _default_roots())],
            "include_code": bool(include_code) if include_code is not None
            else bool(roots),
            "note": "background me chal raha hai"}


# ── query + citations ──────────────────────────────────────────────────────


def _citation(row: dict) -> str:
    page = row.get("page") or 0
    where = ", page %d" % page if page else ""
    return "%s%s: \"%s\"" % (row.get("document") or "?", where,
                             row.get("excerpt") or "")


def format_citations(rows) -> list:
    return [_citation(row) for row in (rows or [])]


def query(text, k=5) -> dict:
    """Semantic top-k over the indexed documents, with citations."""
    body = str(text or "").strip()
    if not body:
        return {"ok": False, "error": "empty_query"}
    collection = _collection()
    if collection is None:
        return {"ok": False, "error": "doc_store_unavailable"}
    try:
        total = int(collection.count() or 0)
    except Exception:
        total = 0
    if total == 0:
        return {"ok": False, "error": "index_empty",
                "hint": "'index my documents' boliye, Sir - phir search kar "
                        "dunga."}
    want = max(1, min(int(k or 5), 10))
    try:
        raw = collection.query(query_texts=[body],
                               n_results=max(3, min(want * 3, 20)))
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    docs = (raw.get("documents") or [[]])[0]
    metas = (raw.get("metadatas") or [[]])[0]
    dists = (raw.get("distances") or [[]])[0]
    rows, seen = [], set()
    for doc, meta, dist in zip(docs, metas, dists):
        meta = meta or {}
        path = str(meta.get("path") or "")
        page = int(meta.get("page") or 0)
        dedupe = (path.casefold(), page)
        if dedupe in seen:
            continue
        seen.add(dedupe)
        rows.append({
            "document": str(meta.get("name") or Path(path).name or "?"),
            "path": path, "page": page,
            "excerpt": " ".join(str(doc or "").split())[:240],
            "score": round(max(0.0, 1.0 - float(dist or 0.0)), 3)})
        if len(rows) >= want:
            break
    return {"ok": True, "query": body, "count": len(rows), "results": rows,
            "total_chunks": total, "formatted": format_citations(rows)}


def spoken(query_text, rows) -> str:
    """Speech-ready, citation-first summary. Never invents content."""
    rows = list(rows or [])
    if not rows:
        return ("Sir, mere index me is baare me kuch nahi mila: \"%s\"."
                % str(query_text or "")[:60])
    head = rows[0]
    line = ("Sir, %d result mile. Pehla: %s%s - \"%s\""
            % (len(rows), head.get("document") or "?",
               (", page %d" % head["page"]) if head.get("page") else "",
               str(head.get("excerpt") or "")[:160]))
    others = [("%s%s" % (r.get("document") or "?",
                         (", page %d" % r["page"]) if r.get("page") else ""))
              for r in rows[1:4]]
    if others:
        line += ". Baaki: " + "; ".join(others)
    return line + "."


def status() -> dict:
    """Honest state of the document store for voice/UI/tests."""
    collection = _collection()
    out = {"available": collection is not None, "collection": COLLECTION,
           "dir": str(_paths.jarvis_docs_dir()),
           "files": 0, "chunks": 0, "no_text": 0, "errors": 0,
           "roots": [str(r) for r in _default_roots()],
           "running": index_running(),
           "progress": dict(_RUN.get("progress") or {}),
           "last_run": None}
    manifest = _load_manifest()
    files = manifest.get("files") or {}
    out["files"] = sum(1 for row in files.values()
                       if (row or {}).get("status") == "ok")
    out["no_text"] = sum(1 for row in files.values()
                         if (row or {}).get("status") == "no_text")
    out["errors"] = sum(1 for row in files.values()
                        if (row or {}).get("status") == "error")
    if collection is not None:
        try:
            out["chunks"] = int(collection.count() or 0)
        except Exception:
            pass
    out["last_run"] = manifest.get("last_run")
    return out


def clear() -> dict:
    """Wipe the document index (collection + manifest)."""
    client = _client()
    if client is None:
        return {"ok": False, "error": "doc_store_unavailable"}
    try:
        client.delete_collection(COLLECTION)
    except Exception:
        pass
    try:
        _manifest_path().unlink()
    except Exception:
        pass
    return {"ok": True, "cleared": True}


# ── tool wrappers (extensions/plugins/jarvis-modules) ──────────────────────


def _tool_doc_search(args):
    body = str((args or {}).get("query") or "").strip()
    if not body:
        return {"ok": False, "output": "Sir, kya dhundo, bataiye."}
    out = query(body, k=(args or {}).get("k") or 5)
    if not out.get("ok"):
        if out.get("error") == "index_empty":
            return {"ok": False, "output": out["hint"]}
        return {"ok": False, "output": "Document search nahi chala: %s"
                % out.get("error", "unknown")}
    if not out["results"]:
        return {"ok": True, "output": "Is baare me index me kuch nahi mila."}
    lines = ["%d. %s" % (i, cite)
             for i, cite in enumerate(out["formatted"], start=1)]
    return {"ok": True, "output": "\n".join(lines)}


def _tool_doc_index(args):
    args = args or {}
    roots = args.get("roots")
    if isinstance(roots, str) and roots.strip():
        roots = [r.strip() for r in re.split(r"[;|]", roots) if r.strip()]
    elif not roots:
        roots = None
    # None = "auto" (code files only when the user named the folder himself);
    # an explicit true/false from the caller is honoured as given.
    include = args.get("include_code")
    if isinstance(include, str):
        include = include.strip().casefold() not in ("", "0", "false", "no", "off")
    elif include is not None:
        include = bool(include)
    out = start_index(roots=roots, include_code=include,
                      limit=int(args.get("limit") or 0),
                      reset=bool(args.get("reset")))
    if not out.get("ok"):
        return {"ok": False, "output": "Index already chal raha hai: %s"
                % (out.get("progress") or {})}
    return {"ok": True, "output":
            "Document indexing background me shuru kar diya: %s"
            % ", ".join(out.get("roots") or [])}


def _tool_doc_status(args):
    out = status()
    run = out.get("last_run") or {}
    lines = ["Document index: %d files, %d chunks (%s)"
             % (out["files"], out["chunks"], out["dir"]),
             "Roots: %s" % ", ".join(out.get("roots") or []),
             "No-text files: %d, errors: %d" % (out["no_text"], out["errors"])]
    if out.get("running"):
        lines.append("Abhi chal raha hai: %s" % (out.get("progress") or {}))
    if run:
        lines.append("Last run: %s files scanned, %s chunks, %s failed"
                     % (run.get("scanned"), run.get("chunks"),
                        run.get("failed")))
    return {"ok": True, "output": "\n".join(lines)}
