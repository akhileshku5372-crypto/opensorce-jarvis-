"""Regression: the "JARVIS is busy" 429 deadlock.

Reproduces the live failure where a wedged TTS/audio backend left the single
command worker parked in its `_SPEAKING` gate. The 4-slot queue then filled
and every later command was rejected with HTTP 429 "Command queue full" while
/state still reported status=idle - JARVIS looked alive but heard nothing.

Stdlib + fakes only: no audio, no network, no mic.
"""
import importlib.util
import queue
import subprocess
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


import sys  # noqa: E402  (needed after _load registration)
ENGINE = _load("voice_engine")


class PlaybackCeilingTest(unittest.TestCase):
    """A hung audio backend must never wait longer than _PLAY_TIMEOUT."""

    def test_play_timeout_is_bounded(self):
        self.assertLessEqual(ENGINE._PLAY_TIMEOUT, 90.0,
                             "90s unbounded wait is what wedged the worker")
        self.assertGreater(ENGINE._PLAY_TIMEOUT, 0)

    def test_hung_ffplay_is_killed_and_returns(self):
        """Simulate ffplay that never exits: _play_mp3 must return, not hang."""
        engine = ENGINE
        engine._FFPLAY = "ffplay"          # pretend it is installed

        class HungProc:
            returncode = None
            killed = False

            def wait(self, timeout=None):
                if timeout is None:
                    time.sleep(999)        # unbounded wait = the original bug
                raise subprocess.TimeoutExpired("ffplay", timeout)

            def poll(self):
                return None

            def kill(self):
                HungProc.killed = True

        real_timeout = engine._PLAY_TIMEOUT
        with mock.patch.object(engine.subprocess, "Popen", return_value=HungProc()):
            engine._PLAY_TIMEOUT = 0.2
            start = time.time()
            result = engine._play_mp3("fake.mp3", engine._TTS_GENERATION)
            elapsed = time.time() - start
        engine._PLAY_TIMEOUT = real_timeout
        engine._FFPLAY = None
        self.assertFalse(result, "a hung player must report failure, not success")
        self.assertTrue(HungProc.killed, "the hung process must be killed")
        self.assertLess(elapsed, 5.0,
                        "_play_mp3 blocked %.1fs - the worker would be stuck"
                        % elapsed)


class SpeakGateTest(unittest.TestCase):
    """The worker must not park forever on a stale _SPEAKING flag."""

    def test_gate_timeout_is_sane(self):
        """Long enough to outlast real audio, short enough to never park forever.

        The old bound of 60s predated the current ceiling: _PLAY_TIMEOUT alone is
        90s, so a gate under that would cut off a legitimately long utterance and
        hand the worker a stale _SPEAKING flag. What must stay true is that the
        gate is bounded at all - an unbounded wait is what wedged the queue and
        made every later command answer HTTP 429 "Command queue full".
        """
        self.assertGreater(ENGINE._SPEAK_GATE_TIMEOUT, 0)
        self.assertGreaterEqual(ENGINE._SPEAK_GATE_TIMEOUT, ENGINE._PLAY_TIMEOUT,
                                "the gate would truncate audio that is still playing")
        self.assertLessEqual(ENGINE._SPEAK_GATE_TIMEOUT, ENGINE._PLAY_TIMEOUT * 2,
                             "an unbounded gate is the original deadlock")

    def test_worker_drains_even_when_speaking_flag_is_stuck(self):
        """A stuck speech gate must not stop a new command from running."""
        engine = ENGINE
        engine._SPEAK_GATE_TIMEOUT = 0.3
        engine._COMMANDS = queue.Queue(maxsize=4)
        engine._TURN_EPOCH = 0
        engine._SPEAKING.set()          # simulate the wedged-audio state
        try:
            for i in range(4):
                engine._COMMANDS.put_nowait(("cmd%d" % i, None, None,
                                             "typed", 0, "dashboard"))
            start = time.time()
            processed = 0
            for _ in range(4):
                item = engine._COMMANDS.get(timeout=1)
                _cmd, _ui, _bridge, _origin, epoch, _panel = item
                # Mirrors the worker gate loop exactly.
                gate = time.time() + engine._SPEAK_GATE_TIMEOUT
                while engine._SPEAKING.is_set() and epoch == engine._TURN_EPOCH:
                    if time.time() > gate:
                        engine._SPEAKING.clear()
                        break
                    time.sleep(0.02)
                processed += 1
                engine._COMMANDS.task_done()
            elapsed = time.time() - start
        finally:
            engine._SPEAKING.clear()
        self.assertEqual(processed, 4)
        self.assertLess(elapsed, 10.0, "gate loop blocked for %.1fs" % elapsed)


class QueueRecoveryTest(unittest.TestCase):
    """submit_command must recover instead of answering 'busy' forever.

    The real worker is never spawned here: it would block on the very speech
    gate under test. A live sentinel `_command_thread` is installed so
    submit_command's `if _command_thread is None ... start worker` branch is
    skipped, isolating the queue-saturation recovery path.
    """

    def setUp(self):
        self.engine = ENGINE
        self.engine._COMMANDS = queue.Queue(maxsize=4)
        self.engine._SPEAKING.clear()
        # A live sentinel thread object so submit_command never spawns a
        # worker. `_WORKER_LOCK` is a plain Lock, so holding it here would
        # deadlock against submit_command's own acquire().
        self.engine._command_thread = threading.Thread(
            target=lambda: time.sleep(60), daemon=True)
        self.engine._command_thread.start()
        self.addCleanup(self._stop_sentinel)

    def _stop_sentinel(self):
        self.engine._command_thread = None

    def _fill(self):
        for i in range(4):
            self.engine._COMMANDS.put_nowait(("stale%d" % i, None, None,
                                              "typed", 0, "dashboard"))

    def test_drain_empties_a_stuck_queue(self):
        self._fill()
        self.assertTrue(self.engine._COMMANDS.full())
        self.assertEqual(self.engine._drain_command_queue(), 4)
        self.assertTrue(self.engine._COMMANDS.empty())

    def test_drain_on_empty_queue_is_safe(self):
        self.assertEqual(self.engine._drain_command_queue(), 0)

    def test_submit_recovers_when_queue_is_full(self):
        """The exact user symptom: a full queue must still accept the command."""
        engine = self.engine
        self._fill()
        with mock.patch.object(engine, "interrupt_playback"):
            accepted = engine.submit_command("jarvis status", None, None,
                                             "typed", "dashboard")
        self.assertTrue(accepted,
                        "submit_command still reports busy on a wedged queue")
        self.assertGreaterEqual(engine._COMMANDS.qsize(), 1)

    def test_submit_succeeds_on_healthy_queue(self):
        accepted = self.engine.submit_command("jarvis status", None, None,
                                              "typed", "dashboard")
        self.assertTrue(accepted)
        self.engine._drain_command_queue()


class BackwardCompatibilityTest(unittest.TestCase):
    def test_signatures_unchanged(self):
        import inspect
        self.assertEqual(
            list(inspect.signature(ENGINE.submit_command).parameters)[:5],
            ["text", "ui", "bridge", "source", "source_panel_id"])
        self.assertEqual(
            list(inspect.signature(ENGINE.run_command).parameters)[:5],
            ["text", "ui", "bridge", "source", "source_panel_id"])


if __name__ == "__main__":
    unittest.main()
