---
name: screen-control
description: See the live screen and operate the mouse/keyboard through JARVIS's existing screen agent - perceive, ground, act, verify, confirm before destructive work, and never claim an action that did not happen.
triggers: screen pe kya, meri screen, screen dekho, screen read, read my screen, screen task, screen control, mouse, keyboard, click karo, type karo, desktop task, gui
---

# Screen Control

Ye skill tab use karo jab Sir screen dekhne ya mouse/keyboard se kaam karne ko
kahe. Naya executor mat banao: JARVIS ke andar pehle se `screen_agent.py` aur
registered `gui_*` tools hain, aur wahi canonical path hai.

## 1. Pehle dekho, phir bolo
- "Screen pe kya hai", "meri screen dekho", "read my screen" par pehle screen
  capture karo. Live mode mein `look_at_screen` tool; classic mode mein
  `analyze_screen()` route.
- Bina dekhe "main dekh nahi sakta" mat bolo. Capture fail ho tabhi failure
  batao, aur exact reason batao.
- Ek snapshot sirf us waqt ki tasveer hai. Screen badal rahi ho to dobara dekho.

## 2. Screen-grounded action ka contract
Har action pehle perceive -> ground -> act -> verify:
1. **Perceive**: screenshot lo.
2. **Ground**: on-screen label/text se exact target dhoondo; coordinates
   guess mat karo.
3. **Act**: sirf allowlisted primitive - click, right-click, double-click,
   type/paste, scroll, one key, allowlisted hotkey.
4. **Verify**: dobara screenshot/read-back se confirm karo ki result hua.

Multi-step desktop task ke liye existing `screen_agent.screen_task()` loop use
karo. Ek visible element ke liye Cortex ke registered tools:
`gui_locate_and_click`, `gui_type_into`, `gui_read_screen_region`,
`gui_scroll`, `gui_press_key`, `gui_focus_app`, `gui_press_combo`,
`gui_type_active`.

## 3. Safety aur confirmation
- Destructive action (close/delete/uninstall/shutdown/restart, unsaved data)
  pehle confirm maango. Bina "confirm" ke mat chalao.
- Staged action ka sirf ek confirm valid hai; 120s ke baad expire.
- Shell, executable path, arbitrary filesystem path, ya naya automation
  library mat banao.
- Mouse ko top-left corner pe le jaana emergency stop hai; usse override mat
  karo.

## 4. Honesty aur self-learning
- Action ke result se pehle "ho gaya", "click kar diya" ya "type kar diya"
  mat bolo. Sirf real tool result bolo.
- Successful screen task P2 result ledger aur P3 recipe memory mein khud
  record hota hai. Usi ko dobara invent mat karo.
- "Kya kaam sikhe" poocha jaye to learned recipe batao, lekin naya task bina
  confirmation execute mat karo.
- Agar target screen pe nahi mila, seedha bolo - "nahi mila" - aur scroll ya
  wait jaisa safe next step suggest karo.
