"""WhatsApp deep-link sender tests (no browser, no network, no send).

Covers the two clean parameters, real wa.me URL shape, urlencoding of the
message, honest refusal for a contact NAME, confirm-gating in the registry,
and the voice route: number -> deep link, name -> existing staged typing.
"""
import importlib.util
import os
import sys
import tempfile
import unittest
import webbrowser
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]

# Every test run targets a THROWAWAY ledger/recipes store - the owner's live
# artifacts/brain/*.json must never be written by a test process.
os.environ.setdefault(
    "JARVIS_RESULTS_STORE",
    os.path.join(tempfile.gettempdir(), "jarvis_test_results.json"))
os.environ.setdefault(
    "JARVIS_ROUTINES_STORE",
    os.path.join(tempfile.gettempdir(), "jarvis_test_routines.json"))


def _refuse(name):
    """Turn a real OS launch into a loud test failure.

    A router-level test that forgets to patch `_open_desktop` used to ShellExecute
    a live `whatsapp://` URI - WhatsApp really opened on the desktop with a test
    number. Unit tests must never touch the real desktop, so the two escape routes
    (`os.startfile`, `webbrowser.open`) now raise instead.
    """
    def refuse(target, *args, **kwargs):
        raise AssertionError(
            "test tried to really %s %r - patch _open_desktop()/_open_browser()"
            % (name, str(target)[:90]))
    return refuse


if hasattr(os, "startfile"):
    os.startfile = _refuse("startfile")
webbrowser.open = _refuse("open in browser")
webbrowser.open_new = _refuse("open in browser")
webbrowser.open_new_tab = _refuse("open in browser")


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


WA = _load("whatsapp_sender")


def _shared_cortex():
    """Load cortex under the ONE name every module uses (identity check)."""
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / "cortex.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


CORTEX = _shared_cortex()


class PhoneGateTest(unittest.TestCase):
    """The number system is gone; the one survivor detects numbers to REFUSE."""

    def test_looks_like_phone_gate_still_flags_numbers(self):
        self.assertTrue(WA.looks_like_phone("919812345678"))
        self.assertFalse(WA.looks_like_phone("hello"))
        self.assertFalse(WA.looks_like_phone(""))


class NoBlankRecipientTest(unittest.TestCase):
    """A blank recipient must never become a hidden person's chat.

    The old contact book is gone (owner order); the remaining rule is that a
    blank/whitespace recipient is a name mode with an EMPTY label, so nothing
    opens and the route asks for a real name.
    """

    def test_recipient_target_for_blank_input_is_name_mode_with_no_label(self):
        for blank in ("", "   ", None):
            number, label, mode = WA._recipient_target(blank)
            self.assertEqual(number, "")
            self.assertEqual(mode, "name")

    def test_blank_refusal_happens_at_the_call_sites(self):
        import contextlib, tempfile
        with tempfile.TemporaryDirectory() as _tmp:
            stack = contextlib.ExitStack()
            self.app_links = []
            stack.enter_context(mock.patch.object(
                WA, "desktop_app_installed", return_value=(True, "t")))
            stack.enter_context(mock.patch.object(
                WA, "_open_desktop",
                side_effect=lambda url: (self.app_links.append(url), True)[1]))
            with stack:
                ok, message = WA.send_to("", "hello")
            self.assertFalse(ok)
            self.assertEqual(self.app_links, [])
            self.assertIn("naam", message.lower())


class DeepLinkTest(unittest.TestCase):
    def test_name_only_app_link_has_no_phone_parameter(self):
        url, error = WA.build_app_link("i am & ok")
        self.assertEqual(error, "")
        self.assertTrue(url.startswith(
            "whatsapp://send?text=i%20am%20%26%20ok"), url)
        self.assertNotIn("phone=", url)

    def test_name_web_link_shape(self):
        url, error = WA.build_name_link("line1\nline2")
        self.assertEqual(error, "")
        self.assertTrue(url.startswith("https://web.whatsapp.com/send?text="), url)
        self.assertIn("line1%0Aline2", url)

    def test_empty_message_is_refused(self):
        self.assertNotEqual(WA.build_app_link("   ")[1], "")
        self.assertNotEqual(WA.build_name_link("   ")[1], "")

    def test_long_message_is_bounded(self):
        url, error = WA.build_app_link("a" * 5000)
        self.assertEqual(error, "")
        self.assertLessEqual(len(url), 1400)


class SendTest(unittest.TestCase):
    """DESKTOP app first, web only as an honest fallback - NAME only now."""

    def setUp(self):
        self._tmp = None

    def _stack(self, installed=True, window=True, desktop_ok=True, browser_ok=True):
        import contextlib
        stack = contextlib.ExitStack()
        self.app_links = []
        self.web_links = []
        stack.enter_context(mock.patch.object(
            WA, "desktop_app_installed",
            return_value=(installed, "test evidence" if installed else "")))
        stack.enter_context(mock.patch.object(
            WA, "_open_desktop",
            side_effect=lambda url: (self.app_links.append(url), desktop_ok)[1]))
        stack.enter_context(mock.patch.object(
            WA, "_window_is_whatsapp", return_value=window))
        stack.enter_context(mock.patch.object(
            WA, "_open_browser",
            side_effect=lambda url: (self.web_links.append(url), browser_ok)[1]))
        return stack

    def test_desktop_app_is_preferred_over_web(self):
        with self._stack():
            ok, message = WA.send_to("akhilesh", "hello sir")
        self.assertTrue(ok, message)
        self.assertEqual(len(self.app_links), 1)
        self.assertTrue(self.app_links[0].startswith(
            "whatsapp://send?text=hello"), self.app_links[0])
        self.assertNotIn("phone=", self.app_links[0])
        self.assertEqual(self.web_links, [], "web must NOT open when the app works")
        self.assertIn("APP", message)
        self.assertIn("akhilesh", message)
        self.assertIn("Send", message)

    def test_a_number_is_never_the_recipient(self):
        with self._stack():
            ok, message = WA.send_to("919812345678", "hello sir")
        self.assertFalse(ok)
        self.assertEqual(self.app_links, [])
        self.assertEqual(self.web_links, [])
        self.assertIn("number", message.lower())
        self.assertIn("naam", message.lower())

    def test_app_opened_but_window_unverified_is_honest(self):
        with self._stack(window=False):
            ok, message = WA.send_to("akhilesh", "hi")
        self.assertTrue(ok)
        self.assertIn("request bhej diya", message)
        self.assertEqual(self.web_links, [])

    def test_no_installed_app_falls_back_to_web_and_says_so(self):
        with self._stack(installed=False):
            ok, message = WA.send_to("akhilesh", "hello")
        self.assertTrue(ok, message)
        self.assertEqual(self.app_links, [])
        self.assertEqual(len(self.web_links), 1)
        self.assertTrue(self.web_links[0].startswith(
            "https://web.whatsapp.com/send?text=hello"))
        self.assertIn("WEB", message)
        self.assertIn("installed nahi mila", message)

    def test_app_scheme_failure_falls_back_to_web(self):
        with self._stack(desktop_ok=False):
            ok, message = WA.send_to("akhilesh", "hello")
        self.assertTrue(ok)
        self.assertEqual(len(self.app_links), 1)
        self.assertEqual(len(self.web_links), 1)

    def test_no_app_and_no_browser_is_an_honest_failure(self):
        with self._stack(installed=False, browser_ok=False):
            ok, message = WA.send_to("akhilesh", "hello")
        self.assertFalse(ok)
        self.assertIn("browser", message.lower())

    def test_tool_send_reports_the_channel_it_used(self):
        with self._stack():
            got = WA.tool_send({"recipient_data": "akhilesh",
                                "message": "on my way"})
        self.assertTrue(got["ok"], got)
        self.assertEqual(got["channel"], "app")
        self.assertTrue(got["app_url"].startswith("whatsapp://send?text="))
        self.assertNotIn("phone=", got["app_url"])
        with self._stack(installed=False):
            web = WA.tool_send({"recipient_data": "akhilesh", "message": "hi"})
        self.assertEqual(web["channel"], "web")
        self.assertEqual(web["mode"], "name")
        # A spoken number is refused by the tool too.
        with self._stack():
            refused = WA.tool_send({"recipient_data": "919812345678",
                                    "message": "on my way"})
        self.assertFalse(refused["ok"], refused)
        self.assertIn("number", str(refused.get("error") or refused).lower())


class DesktopInstallCheckTest(unittest.TestCase):
    def test_forced_check_reports_the_real_machine_truth(self):
        installed, evidence = WA.desktop_app_installed(force=True)
        self.assertIsInstance(installed, bool)
        if installed:
            self.assertTrue(evidence, "installed must always carry evidence")
            self.assertIn("whatsapp", ("%s whatsapp" % evidence).lower())

    def test_cold_cache_never_claims_installed(self):
        with mock.patch.dict(WA._install_cache,
                             {"at": 0.0, "installed": False, "evidence": "",
                              "ready": False, "warming": False}, clear=True), \
             mock.patch.object(WA, "_warm_install_check", lambda: None):
            installed, evidence = WA.desktop_app_installed()
        self.assertFalse(installed, "a cold cache must not invent an install")
        self.assertIn("chal raha hai", evidence)

    def test_stale_cache_keeps_serving_the_last_truth(self):
        with mock.patch.dict(WA._install_cache,
                             {"at": 0.0, "installed": True,
                              "evidence": "installed app: WhatsApp (start-apps)",
                              "ready": True, "warming": False}, clear=True), \
             mock.patch.object(WA, "_warm_install_check", lambda: None):
            installed, evidence = WA.desktop_app_installed()
        self.assertTrue(installed)
        self.assertIn("WhatsApp", evidence)

    def test_app_link_shape(self):
        url, error = WA.build_app_link("i am & ok")
        self.assertEqual(error, "")
        self.assertEqual(url, "whatsapp://send?text=i%20am%20%26%20ok")
        self.assertEqual(WA.build_app_link("  ")[1], "message khaali hai.")


class _FakeGui:
    """Records key actions instead of touching the real desktop."""

    def __init__(self):
        self.actions = []

    def hotkey(self, *keys):
        self.actions.append(("hotkey", keys))

    def press(self, key):
        self.actions.append(("press", key))


class AutoSendTest(unittest.TestCase):
    """A real send: desktop-driver name search -> verified delivery."""

    def _stack(self, ready=True, launch_ok=True,
               send_result=(True, "Sir, akhilesh ko message bhej diya, "
                                  "chat-list preview pe verify ho gaya")):
        import contextlib
        stack = contextlib.ExitStack()
        self.gui = _FakeGui()
        self.launched = []
        self.driver_calls = []

        class _FakeDesktop:
            def __init__(self, owner):
                self._owner = owner

            def send(self, chat, text, mention=""):
                self._owner.driver_calls.append((chat, text, mention))
                return send_result

            def open_chat(self, chat):
                self._owner.driver_calls.append(("open", chat))
                return (True, chat, "header verified")

            def last_message_preview(self, chat):
                return "%s 12:22 pm hello" % chat

        stack.enter_context(mock.patch.object(
            WA, "can_autosend",
            return_value=(ready, "test" if ready else "app not installed")))
        stack.enter_context(mock.patch.object(
            WA, "_open_desktop",
            side_effect=lambda url: (self.launched.append(url), True)[1]
            if launch_ok else False))
        stack.enter_context(mock.patch.object(
            WA, "_load_desktop", return_value=_FakeDesktop(self)))
        return stack

    def test_sends_by_name_through_the_verified_driver(self):
        """A name goes through the verifying desktop driver - no deep link."""
        with self._stack():
            ok, message = WA.autosend_to("akhilesh", "kal meeting hai")
        self.assertTrue(ok, message)
        self.assertEqual(self.driver_calls, [("akhilesh", "kal meeting hai", "")])
        self.assertEqual(self.launched, [], "no whatsapp:// link for a name")
        # The removed behaviour, pinned so it cannot come back: blind Ctrl+F into
        # whatever had focus, then Enter, then a success claim.
        self.assertNotIn(("hotkey", ("ctrl", "f")), self.gui.actions)

    def test_the_name_path_reports_a_failed_search(self):
        """The phantom-send bug: never report a send the chat cannot confirm."""
        with self._stack(send_result=(False, "wrong chat khuli - message NAHI bheja")):
            ok, message = WA.autosend_to("akhilesh", "hello")
        self.assertFalse(ok)
        self.assertIn("NAHI bheja", message)

    def test_no_app_installed_is_an_honest_refusal(self):
        with self._stack(ready=False):
            ok, message = WA.autosend_to("akhilesh", "hello")
        self.assertFalse(ok)
        self.assertEqual(self.launched, [])
        self.assertIn("app not installed", message)
        self.assertIn("kuch nahi bheja", message.lower())

    def test_a_spoken_number_is_never_the_send_target(self):
        """2026-10-19 owner order: numbers are refused in the open."""
        with self._stack():
            ok, message = WA.autosend_to("919812345678", "hello")
            ok2, message2 = WA.autosend_to("+91 98765 43210", "hello")
        self.assertFalse(ok)
        self.assertFalse(ok2)
        self.assertEqual(self.launched, [], "no whatsapp://send?phone link ever")
        self.assertEqual(self.driver_calls, [])
        for said in (message, message2):
            self.assertIn("number", said.lower())
            self.assertIn("naam", said.lower())

    def test_open_chat_uses_the_verified_driver_and_never_sends(self):
        with self._stack():
            ok, opened, why = WA.open_chat("akhilesh")
            preview = WA.last_preview("akhilesh")
        self.assertTrue(ok, why)
        self.assertEqual(opened, "akhilesh")
        self.assertEqual(self.driver_calls, [("open", "akhilesh")])
        self.assertIn("hello", preview)

    def test_blank_name_is_refused_before_anything_opens(self):
        with self._stack():
            ok, message = WA.autosend_to("   ", "hello")
        self.assertFalse(ok)
        self.assertEqual(self.launched, [])
        self.assertEqual(self.driver_calls, [])
        self.assertIn("naam clear nahi hua", message)

    def test_tool_autosend_is_registered_and_gated(self):
        spec = [s for s in WA.specs() if s.name == "whatsapp_autosend"][0]
        self.assertTrue(spec.requires_confirmation)
        self.assertEqual(set(spec.parameters), {"recipient_data", "message"})
        with self._stack():
            got = WA.tool_autosend({"recipient_data": "akhilesh",
                                    "message": "hi"})
        self.assertTrue(got["ok"], got)
        self.assertTrue(got["sent"])



class RegistryTest(unittest.TestCase):
    def test_spec_has_the_two_clean_params_and_is_confirm_gated(self):
        spec = WA.specs()[0]
        self.assertEqual(spec.name, "whatsapp_send")
        self.assertEqual(set(spec.parameters), {"recipient_data", "message"})
        self.assertTrue(spec.requires_confirmation)

    def test_registered_tool_is_gated_in_the_real_registry(self):
        tools = _load("cowork_tools")
        registry = tools.build_default_registry()
        row = registry.get("whatsapp_send")
        self.assertIsNotNone(row)
        self.assertTrue(row.requires_confirmation)

    def test_uses_the_shared_cortex_module(self):
        self.assertIs(WA._load_cortex(), CORTEX)


class PhrasingTest(unittest.TestCase):
    """Every natural phrasing must parse - the 'message' keyword is optional."""

    def setUp(self):
        self.engine = _load("voice_engine")

    def test_new_phrasings_parse(self):
        cases = [
            ("open whatsapp send hello to akhilesh", ("akhilesh", "hello")),
            ("send hello to akhilesh", ("akhilesh", "hello")),
            ("whatsapp send kal meeting hai to amit bhejo", ("amit", "kal meeting hai")),
            ("send a message to akhilesh", ("akhilesh", "")),
            # A phone-number sentence is DELIBERATELY not parseable into a
            # target any more (owner order): it is refused by the route before
            # any send shape exists - see NoNumberSystemTest/VoiceRouteTest.
            ("whatsapp pe akhilesh ko main aa raha hu kal bhejo",
             ("akhilesh", "main aa raha hu kal")),
            # Real STT output from the live session (message BEFORE "ko whatsapp",
            # contact after it) - pattern 1 used to swap these two.
            ("iss message ko whatsapp pe akhilesh ko bhejo",
             ("akhilesh", "iss message")),
            ("kal meeting hai 4 pm pee iss message ko whatsapp pe akhilesh ko bhej do",
             ("akhilesh", "kal meeting hai 4 pm pee iss")),
            ("send - kal meeting hai 4 pm pee iss message ko whatsapp pe "
             "akhilesh ko send", ("akhilesh", "kal meeting hai 4 pm pee iss")),
        ]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(self.engine._parse_whatsapp_message(raw), expected)

    def test_message_send_is_never_read_as_an_app(self):
        for raw in ("open whatsapp send hello to akhilesh",
                    "whatsapp pe akhilesh ko hello bhejo"):
            self.assertTrue(self.engine._looks_like_message_send(raw), raw)
        for raw in ("open whatsapp", "open notepad", "play music",
                    "whatsapp kya hai"):
            self.assertFalse(self.engine._looks_like_message_send(raw), raw)


class NoNumberSystemTest(unittest.TestCase):
    """2026-10-19 owner order: WhatsApp by NAME only.

    The number contact book, the save parser and every wa.me/phone deep link
    are gone. A spoken number is refused in the open; a request to "save" a
    number routed to the honest answer that there is no number book anymore.
    """

    def setUp(self):
        self.engine = _load("voice_engine")

    def test_the_save_parser_no_longer_exists(self):
        self.assertFalse(hasattr(self.engine, "_parse_whatsapp_contact_save"))
        self.assertFalse(hasattr(WA, "save_contact"))
        self.assertFalse(hasattr(WA, "resolve_contact"))
        self.assertFalse(hasattr(WA, "list_contacts"))

    def test_the_list_ask_gets_the_honest_no_book_answer(self):
        for ask in ("batao kis ka number save kiya hai",
                    "mere saved contacts batao",
                    "contacts ki list dikhao"):
            self.assertTrue(self.engine._WA_LIST_ASK_RE.search(ask), ask)
        said = self.engine._wa_list_reply(None)
        self.assertIn("contact book ab nahi hai", said)
        self.assertIn("naam", said)

    def test_the_router_never_saves_numbers(self):
        # The phrase must NOT fall to the brain AND must not save anything:
        # it is answered by the router's no-book line.
        self.spoken = []
        self._real_speak = self.engine.speak
        self.engine.speak = lambda message, ui=None: (
            self.spoken.append(str(message)), True)[1]
        try:
            handled = self.engine.run_command(
                "akhilesh ka number 919812345678 save karo", None, None, "typed")
        finally:
            self.engine.speak = self._real_speak
        said = " ".join(self.spoken)
        self.assertTrue(handled)
        self.assertNotIn("save ho gaya", said)
        self.assertFalse(hasattr(WA, "CONTACTS_FILE"),
                         "no contact book may exist at all")


class VoiceRouteTest(unittest.TestCase):
    """Any contact, any message: number + saved name + bare name all work."""

    def setUp(self):
        self.engine = _load("voice_engine")
        self.opened = []
        self.spoken = []

        class FakeAgent:
            def __init__(self):
                self.staged_task = None

            def stage_task(self, task, prompt=None):
                self.staged_task = str(task or "")
                return "STAGED"

            def has_pending(self):
                return False

            def confirm_pending(self):
                return "CONFIRMED"

            def cancel_pending(self):
                return "CANCELLED"

        self.agent = FakeAgent()
        self._real_speak = self.engine.speak
        self._real_agent = self.engine._screen_agent
        # Other test files load whatsapp_sender under the same sys.modules name
        # with their OWN module instance (test_whatsapp_route._load_bg). The
        # engine's lazy __import__("whatsapp_sender") must find THIS file's
        # instance while these tests run, or it would silently use a real,
        # unpatched sender (can_autosend=True on a machine that has the app).
        self._real_host = sys.modules.get("whatsapp_sender")
        sys.modules["whatsapp_sender"] = WA
        self._real = {
            "installed": WA.desktop_app_installed,
            "desktop": WA._open_desktop,
            "window": WA._window_is_whatsapp,
            "browser": WA._open_browser,
            "can": WA.can_autosend,
        }
        self._real_startfile = None
        try:
            index_mod = sys.modules.get("app_index") or _load("app_index")
            self.index = index_mod
            self._real_startfile = index_mod._startfile
            index_mod._startfile = lambda target: self.opened.append("APP:" + target)
        except Exception:
            self.index = None
        self.engine.speak = lambda message, ui=None: (self.spoken.append(str(message)), True)[1]
        self.engine._screen_agent = lambda: self.agent
        # Desktop app is "installed" in tests; nothing real is ever launched.
        # can_autosend is OFF here so these tests exercise the link/draft path
        # (the real auto-send flow is covered by AutoSendVoiceTest).
        WA.desktop_app_installed = lambda: (True, "test evidence")
        WA.can_autosend = lambda force=False: (False, "autosend disabled in this test")
        self.engine._WA_PENDING.clear()
        WA._open_desktop = lambda url: (self.opened.append(url), True)[1]
        WA._window_is_whatsapp = lambda timeout_s=3.0: True
        WA._open_browser = lambda url: (self.opened.append(url), True)[1]
        self.addCleanup(self._restore)

    def _restore(self):
        self.engine.speak = self._real_speak
        self.engine._screen_agent = self._real_agent
        if self._real_host is None:
            sys.modules.pop("whatsapp_sender", None)
        else:
            sys.modules["whatsapp_sender"] = self._real_host
        WA.desktop_app_installed = self._real["installed"]
        WA.can_autosend = self._real["can"]
        WA._open_desktop = self._real["desktop"]
        WA._window_is_whatsapp = self._real["window"]
        WA._open_browser = self._real["browser"]
        self.engine._WA_PENDING.clear()
        if self.index is not None and self._real_startfile is not None:
            self.index._startfile = self._real_startfile

    def _route(self, text):
        self.spoken.clear()
        self.opened.clear()
        with self.engine._recent_lock:
            self.engine._recent.clear()
        with self.engine._action_stamps_lock:
            self.engine._action_stamps.clear()
        handled = self.engine.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    # --- the exact phrasing from the live transcript -------------------
    def test_open_whatsapp_send_hello_to_name_is_not_an_app_launch(self):
        handled, said = self._route("open whatsapp send hello to akhilesh")
        self.assertTrue(handled)
        self.assertEqual(len(self.opened), 1, self.opened)
        self.assertEqual(self.opened[0], "whatsapp://send?text=hello")
        self.assertFalse(any(link.startswith("APP:") for link in self.opened),
                         "a message request must never launch an app")
        self.assertIsNone(self.agent.staged_task)
        self.assertIn("Send", said)

    def test_a_name_never_sends_to_a_number_behind_it(self):
        # The old contact-book hijack is gone: a name opens a name-search
        # draft. No phone parameter may appear in any link the route builds.
        handled, said = self._route("akhilesh ko whatsapp pe kal meeting hai bhejo")
        self.assertTrue(handled)
        self.assertEqual(len(self.opened), 1, self.opened)
        self.assertNotIn("phone=", self.opened[0])
        self.assertIn("whatsapp://send?text=", self.opened[0])
        self.assertIn("akhilesh", said)

    def test_a_spoken_number_is_refused_in_the_open(self):
        handled, said = self._route("whatsapp pe 919812345678 ko hello bhejo")
        self.assertTrue(handled)
        self.assertEqual(self.opened, [], "nothing may be opened for a number")
        self.assertIsNone(self.agent.staged_task)
        self.assertIn("number", said.lower())
        self.assertIn("naam", said.lower())

    def test_send_without_message_asks_instead_of_guessing(self):
        handled, said = self._route("open whatsapp send a message to akhilesh")
        self.assertTrue(handled)
        self.assertEqual(self.opened, [])
        self.assertIn("kya bhejna hai", said)

    def test_no_app_and_no_browser_never_falls_back_to_blind_typing(self):
        # The old fallback staged a VLM screen task ('search for the chat named
        # "...", type "...", press Enter'). It could not prove delivery, it
        # spoke that internal instruction to the user, and it still reported a
        # send. With no app and no browser the only honest answer is "nothing
        # was sent".
        WA.desktop_app_installed = lambda: (False, "")
        WA._open_desktop = lambda url: False
        WA._open_browser = lambda url: False
        handled, said = self._route("whatsapp pe akhilesh ko hello bhejo")
        self.assertTrue(handled)
        self.assertIsNone(self.agent.staged_task)
        self.assertNotIn("STAGED", said)
        for leaked in ("chat named", "press Enter", "message box"):
            self.assertNotIn(leaked, said)
        self.assertIn("nahi mila", said)

    def test_contact_save_ask_is_answered_without_any_book(self):
        # The number book is gone: the ask is answered by the router's honest
        # line, nothing is stored, and the chat brain is not dragged into it.
        handled, said = self._route("akhilesh ka number 919812345678 save karo")
        self.assertTrue(handled)
        self.assertIn("contact book ab nahi hai", said)
        self.assertNotIn("save ho gaya", said)


class AutoSendVoiceTest(unittest.TestCase):
    """Voice: one spoken confirm, then the message REALLY goes out."""

    def setUp(self):
        self.engine = _load("voice_engine")
        self.spoken = []
        self.sent = []

        class FakeAgent:
            def has_pending(self):
                return False

            def confirm_pending(self):
                return "SCREEN_CONFIRMED"

            def cancel_pending(self):
                return "SCREEN_CANCELLED"

            def stage_task(self, task, prompt=None):
                return "STAGED"

        self.agent = FakeAgent()
        self._real = {
            "speak": self.engine.speak,
            "agent": self.engine._screen_agent,
            "can": WA.can_autosend,
            "auto": WA.autosend_to,
            "send": WA.send_to,
        }
        # Same rule as VoiceRouteTest: pin the engine's lazy
        # __import__("whatsapp_sender") to THIS file's module instance for the
        # duration of the test; other files re-register the same name.
        self._real_host = sys.modules.get("whatsapp_sender")
        sys.modules["whatsapp_sender"] = WA
        self.engine.speak = lambda message, ui=None: (self.spoken.append(str(message)), True)[1]
        self.engine._screen_agent = lambda: self.agent
        self.engine._WA_PENDING.clear()
        WA.can_autosend = lambda force=False: (True, "test")
        WA.autosend_to = lambda recipient, message: (
            self.sent.append((recipient, message)),
            (True, "Sir, message bhej diya."))[1]
        WA.send_to = lambda recipient, message: (True, "DRAFTED")
        self.addCleanup(self._restore)

    def _restore(self):
        self.engine.speak = self._real["speak"]
        self.engine._screen_agent = self._real["agent"]
        if self._real_host is None:
            sys.modules.pop("whatsapp_sender", None)
        else:
            sys.modules["whatsapp_sender"] = self._real_host
        WA.can_autosend = self._real["can"]
        WA.autosend_to = self._real["auto"]
        WA.send_to = self._real["send"]
        self.engine._WA_PENDING.clear()
        self.engine._WA_SKIP_UNTIL["at"] = 0.0

    def _route(self, text):
        self.spoken.clear()
        with self.engine._recent_lock:
            self.engine._recent.clear()
        with self.engine._action_stamps_lock:
            self.engine._action_stamps.clear()
        handled = self.engine.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_request_asks_confirm_and_sends_nothing_yet(self):
        handled, said = self._route("whatsapp pe akhilesh ko kal meeting bhejo")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [], "nothing may be sent before confirm")
        self.assertIn("confirm", said.lower())
        self.assertIn("kal meeting", said)

    def test_the_same_sentence_cannot_confirm_itself(self):
        # The request is re-dispatched by the voice path; it must NOT auto-send.
        handled, said = self._route("akhilesh ko whatsapp pe kal meeting bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [], "nothing sent before an explicit confirm")
        self.assertIn("confirm", said.lower())
        handled, said = self._route("akhilesh ko whatsapp pe kal meeting bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [], "the identical repeat must not confirm")
        self.assertIn("haan bhej do", said)
        # an explicit confirm does send
        self._route("haan bhej do")
        self.assertEqual(self.sent, [("akhilesh", "kal meeting")])

    def test_confirm_actually_sends_the_message(self):
        self._route("whatsapp pe akhilesh ko kal meeting bhejo")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [("akhilesh", "kal meeting")])
        self.assertIn("bhej diya", said)

    def test_deny_sends_nothing(self):
        self._route("whatsapp pe akhilesh ko kal meeting bhejo")
        handled, said = self._route("nahi karo")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [])
        self.assertIn("nahi bheja", said)

    def test_unrelated_reply_keeps_the_pending_send(self):
        self._route("whatsapp pe akhilesh ko kal meeting bhejo")
        handled, said = self._route("aaj mausam kaisa hai")
        self.assertEqual(self.sent, [])
        self.assertIn("confirm nahi mila", said)
        # still pending -> a later confirm works
        self._route("haan bhej do")
        self.assertEqual(self.sent, [("akhilesh", "kal meeting")])

    def test_no_autosend_support_falls_back_to_draft(self):
        WA.can_autosend = lambda force=False: (False, "app not installed")
        handled, said = self._route("whatsapp pe akhilesh ko hello bhejo")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [])
        self.assertIn("DRAFTED", said)

    def test_bina_confirm_switch_sends_without_asking(self):
        handled, said = self._route("bina confirm bhejo")
        self.assertTrue(handled)
        self.assertIn("bina confirm", said)
        self._route("whatsapp pe akhilesh ko hello bhejo")
        self.assertEqual(self.sent, [("akhilesh", "hello")],
                         "skip-window must send straight away")
        # ...and it can be switched back on
        self._route("confirm wapas karo")
        self._route("whatsapp pe akhilesh ko hi bhejo")
        self.assertEqual(len(self.sent), 1, "confirm must be asked again")

    def test_the_shape_he_typed_really_reaches_the_send(self):
        # Live 2026-10-19: "Vishesh ko hello bhej do WhatsApp par" matched no
        # pattern (the app word never sits next to the verb), so the chat brain
        # answered instead - with a confirm ask for an action that did not exist.
        handled, said = self._route("Vishesh ko hello bhej do WhatsApp par")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [], "nothing may be sent before confirm")
        self.assertIn("Vishesh", said)
        self.assertIn("hello", said)
        self.assertIn("confirm", said.lower())
        handled, said = self._route("confirm")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [("Vishesh", "hello")])

    def test_the_first_word_of_the_message_is_never_stripped(self):
        # "... ko mein offline hun ..." must be sent as "mein offline hun": the
        # leading-filler strip used to eat the first word and would have sent
        # "offline hun".
        handled, said = self._route(
            "vishesh ko mein offline hun bol do message on whatsapp")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [])
        self.assertIn("mein offline hun", said)
        self._route("confirm")
        self.assertEqual(self.sent, [("vishesh", "mein offline hun")])

    def test_an_unreadable_send_is_answered_here_not_by_the_brain(self):
        # The brain used to reply with its own confirm ask for a pending send that
        # did not exist; he said "confirm" and got the guard's "kuch bhi nahi
        # kiya". A send request the parser cannot read is now answered by the
        # router, in the open, with nothing sent and no confirm asked.
        handled, said = self._route(
            "vishesh ko ye bhej do whatsapp par ki main offline hun")
        self.assertTrue(handled)
        self.assertEqual(self.sent, [])
        self.assertNotIn("confirm", said.lower())
        for leaked in ("click", "type ", "press enter", "chat named"):
            self.assertNotIn(leaked, said.lower())
        self.assertIn("kuch bhi nahi bheja", said)
        self.assertIn("bhejo", said)          # names the sentence shape that works


if __name__ == "__main__":
    unittest.main(verbosity=2)

