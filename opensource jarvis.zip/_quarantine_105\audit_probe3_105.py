"""Phase 1-4 read-only checks: no sends, no clicks, no network LLM."""
import importlib.util, os, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load_bg(name):
    full="jarvis_cowork_"+name
    if full in sys.modules: return sys.modules[full]
    p=ROOT/"background"/(name+".py")
    import importlib.util as iu
    spec=iu.spec_from_file_location(full,p)
    m=iu.module_from_spec(spec); sys.modules[full]=m
    spec.loader.exec_module(m); return m
def present(key):
    v=os.environ.get(key,"")
    if v.strip(): return True
    for f in (".env",".dev.vars"):
        try:
            for line in (ROOT/f).read_text(encoding="utf-8",errors="ignore").splitlines():
                line=line.strip()
                if line.startswith(key+"=") and line.split("=",1)[1].strip():
                    return True
        except Exception: pass
    return False
print("KEYS_PRESENT",{k:present(k) for k in ["XKIRO_API_KEY","GROQ_API_KEY","OPENROUTER_API_KEY","GOOGLE_API_KEY","FIRECRAWL_API_KEY"]})
wa=load_bg("whatsapp_sender")
print("WA_DESKTOP",wa.desktop_app_installed())
print("WA_AUTOSEND",wa.can_autosend())
ww=load_bg("whatsapp_web")
print("WAWEB_CAPS",ww.capabilities())
cw=load_bg("content_writer")
print("WRITER_CAPS",{k:cw.capabilities().get(k) for k in ["research","writing","pdf","docx"] if k in cw.capabilities()})
print("WRITER_SPECS",[s.name if hasattr(s,'name') else s.get('name') for s in cw.specs()] if hasattr(cw,'specs') else "no specs fn")
pb=load_bg("presentation_builder")
print("PB_CAPS_KEYS",list(pb.capabilities().keys()))
# who calls presentation_builder.specs?
import subprocess
print("DONE")
