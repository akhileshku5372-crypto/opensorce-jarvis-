# -*- coding: utf-8 -*-
"""_probe_resolve.py — verify GOOGLE model-name slug + retry XKIRO DNS."""
import json, urllib.request, urllib.error

def get(url, timeout=20):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Jarvis-probe/1.0'}), timeout=timeout) as r:
            return r.status, r.read(2000).replace(b'\n', b' ')[:300]
    except Exception as e:
        return None, type(e).__name__ + ' ' + str(e)[:90]

print('--- Google models index (no key) ---')
st, body = get('https://generativelanguage.googleapis.com/v1/models')
print('HTTP', st)
if st == 200:
    try:
        data = json.loads(body)
        names = [m['name'].split('/')[-1] for m in data.get('models', [])]
        print('available model names:', [n for n in names if any(s in n for s in ('flash', 'flash-latest', '2.5', '2.0', '1.5', 'flash-001'))][:12])
    except Exception as e:
        print('parse error:', e, body[:120])

for name in ('gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-pro', 'gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash'):
    st, body = get('https://generativelanguage.googleapis.com/v1/models/%s' % name)
    print('%-28s -> HTTP %s %s' % (name, st, body[:80]))

print('\n--- XKIRO DNS retry 60s later ---')
import time
time.sleep(60)
st, body = get('https://llm.eqium.com/v1/models')
print('https://llm.eqium.com/v1/models -> HTTP', st)
