/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { SubsystemId, SubsystemInfo, BrainNode, HologramTheme, ZoomLevel } from '../../types/jarvis';
import { soundFx } from '../../services/soundEffects';

interface BrainCanvasProps {
  subsystems: Record<SubsystemId, SubsystemInfo>;
  selectedSubsystemId: SubsystemId | null;
  onSelectSubsystem: (id: SubsystemId) => void;
  onSelectNode: (node: BrainNode | null) => void;
  hologramTheme: HologramTheme;
  isExploded: boolean;
  isRotating: boolean;
  onZoomLevelChange?: (level: ZoomLevel) => void;
  pulseTrigger?: number; // increments when a live command sparks the brain
}

export const BrainCanvas: React.FC<BrainCanvasProps> = ({
  subsystems,
  selectedSubsystemId,
  onSelectSubsystem,
  onSelectNode,
  hologramTheme,
  isExploded,
  isRotating,
  onZoomLevelChange,
  pulseTrigger,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [hoveredNode, setHoveredNode] = useState<{ name: string; region: string; x: number; y: number } | null>(null);

  // References for Three.js state
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const pointsMeshRef = useRef<THREE.Points | null>(null);
  const linesGroupRef = useRef<THREE.Group | null>(null);
  const pulsesGroupRef = useRef<THREE.Group | null>(null);
  const centroidsGroupRef = useRef<THREE.Group | null>(null);
  const brainRootRef = useRef<THREE.Group | null>(null);
  const reticlesGroupRef = useRef<THREE.Group | null>(null);

  // Animation & interaction state
  const animFrameIdRef = useRef<number>(0);
  const isDraggingRef = useRef<boolean>(false);
  const prevMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const rotationVelocityRef = useRef<{ x: number; y: number }>({ x: 0, y: 0.002 });
  const targetCameraPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0.4, 5.2));
  const explodeAmountRef = useRef<number>(0);

  // Node database
  const nodesRef = useRef<BrainNode[]>([]);
  const centroidMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());

  // Color palette helper
  const getThemeColors = useCallback((theme: HologramTheme) => {
    switch (theme) {
      case 'stark_gold':
        return { primary: 0xf59e0b, secondary: 0xfbbf24, pulse: 0xffffff, bg: 0x030712 };
      case 'quantum_violet':
        return { primary: 0xa855f7, secondary: 0xc084fc, pulse: 0x38bdf8, bg: 0x030712 };
      case 'tactical_emerald':
        return { primary: 0x10b981, secondary: 0x34d399, pulse: 0x6ee7b7, bg: 0x030712 };
      case 'neural_crimson':
        return { primary: 0xef4444, secondary: 0xf87171, pulse: 0xfbbf24, bg: 0x030712 };
      case 'arc_cyan':
      default:
        return { primary: 0x06b6d4, secondary: 0x38bdf8, pulse: 0xffffff, bg: 0x030712 };
    }
  }, []);

  // Initialize scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x020617, 0.06);

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0.4, 5.2);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Master brain root group
    const brainRoot = new THREE.Group();
    scene.add(brainRoot);
    brainRootRef.current = brainRoot;

    // Build Anatomical Hologram Brain Points
    const { pointsMesh, nodes, originalPositions } = generateBrainGeometry(subsystems);
    nodesRef.current = nodes;
    brainRoot.add(pointsMesh);
    pointsMeshRef.current = pointsMesh;

    // Build Neural Fiber Pathways
    const linesGroup = new THREE.Group();
    brainRoot.add(linesGroup);
    linesGroupRef.current = linesGroup;

    // Build Active Synaptic Pulses
    const pulsesGroup = new THREE.Group();
    brainRoot.add(pulsesGroup);
    pulsesGroupRef.current = pulsesGroup;

    // Build Cluster Centroid Markers
    const centroidsGroup = new THREE.Group();
    brainRoot.add(centroidsGroup);
    centroidsGroupRef.current = centroidsGroup;

    // Populate Centroids
    nodes.forEach((node) => {
      if (node.isCentroid) {
        const geom = new THREE.SphereGeometry(0.12, 16, 16);
        const sub = subsystems[node.subsystemId];
        const mat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(sub.color),
          transparent: true,
          opacity: 0.9,
          wireframe: true,
        });
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(...node.position);
        mesh.userData = { nodeId: node.id, subsystemId: node.subsystemId, node };
        centroidsGroup.add(mesh);
        centroidMeshesRef.current.set(node.id, mesh);

        // Outer glow ring
        const ringGeom = new THREE.RingGeometry(0.14, 0.18, 24);
        const ringMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(sub.color),
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.5,
        });
        const ringMesh = new THREE.Mesh(ringGeom, ringMat);
        ringMesh.position.set(...node.position);
        centroidsGroup.add(ringMesh);
      }
    });

    // Populate Axon Tract Lines & Pulses
    const fiberCurves: { curve: THREE.CatmullRomCurve3; subsystemId: SubsystemId }[] = [];
    nodes.forEach((n1) => {
      n1.connections.forEach((connId) => {
        const n2 = nodes.find((n) => n.id === connId);
        if (n2 && n1.id < n2.id) {
          // Curving tract through middle/internal path
          const p1 = new THREE.Vector3(...n1.position);
          const p2 = new THREE.Vector3(...n2.position);
          const mid = new THREE.Vector3()
            .addVectors(p1, p2)
            .multiplyScalar(0.5);
          mid.y += (Math.random() - 0.5) * 0.3;
          mid.x *= 0.7; // pull towards internal core
          mid.z *= 0.8;

          const curve = new THREE.CatmullRomCurve3([p1, mid, p2]);
          fiberCurves.push({ curve, subsystemId: n1.subsystemId });

          const curvePoints = curve.getPoints(24);
          const lineGeom = new THREE.BufferGeometry().setFromPoints(curvePoints);
          const sub = subsystems[n1.subsystemId];
          const lineMat = new THREE.LineBasicMaterial({
            color: new THREE.Color(sub.color),
            transparent: true,
            opacity: 0.28,
            blending: THREE.AdditiveBlending,
          });
          const line = new THREE.Line(lineGeom, lineMat);
          linesGroup.add(line);
        }
      });
    });

    // Create 32 traveling action potential pulses
    const pulseCount = 36;
    const pulseSpheres: { mesh: THREE.Mesh; curve: THREE.CatmullRomCurve3; progress: number; speed: number }[] = [];
    const pulseGeom = new THREE.SphereGeometry(0.04, 8, 8);
    for (let i = 0; i < pulseCount && fiberCurves.length > 0; i++) {
      const { curve, subsystemId } = fiberCurves[i % fiberCurves.length];
      const sub = subsystems[subsystemId];
      const pMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(sub.color),
        transparent: true,
        opacity: 0.95,
      });
      const pMesh = new THREE.Mesh(pulseGeom, pMat);
      pulsesGroup.add(pMesh);
      pulseSpheres.push({
        mesh: pMesh,
        curve,
        progress: Math.random(),
        speed: 0.003 + Math.random() * 0.007,
      });
    }

    // Build Hologram Concentric Reticles & Ground Ring
    const reticlesGroup = new THREE.Group();
    scene.add(reticlesGroup);
    reticlesGroupRef.current = reticlesGroup;

    // Floor holographic radar grid
    const floorRing1 = new THREE.Mesh(
      new THREE.RingGeometry(2.4, 2.45, 64),
      new THREE.MeshBasicMaterial({ color: 0x06b6d4, side: THREE.DoubleSide, transparent: true, opacity: 0.22 })
    );
    floorRing1.rotation.x = Math.PI / 2;
    floorRing1.position.y = -1.6;
    reticlesGroup.add(floorRing1);

    const floorRing2 = new THREE.Mesh(
      new THREE.RingGeometry(3.1, 3.12, 64),
      new THREE.MeshBasicMaterial({ color: 0x0ea5e9, side: THREE.DoubleSide, transparent: true, opacity: 0.15 })
    );
    floorRing2.rotation.x = Math.PI / 2;
    floorRing2.position.y = -1.6;
    reticlesGroup.add(floorRing2);

    // Cross-axis coordinate reticles
    const axisMat = new THREE.LineBasicMaterial({ color: 0x06b6d4, transparent: true, opacity: 0.15 });
    const axisGeomX = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-3.2, -1.6, 0),
      new THREE.Vector3(3.2, -1.6, 0),
    ]);
    const axisGeomZ = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, -1.6, -3.2),
      new THREE.Vector3(0, -1.6, 3.2),
    ]);
    reticlesGroup.add(new THREE.Line(axisGeomX, axisMat));
    reticlesGroup.add(new THREE.Line(axisGeomZ, axisMat));

    // Handle Resize
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Mouse Raycaster for centroid tooltips and click selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;
      mouse.x = (clientX / rect.width) * 2 - 1;
      mouse.y = -(clientY / rect.height) * 2 + 1;

      // Centroid hover detection
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(centroidsGroup.children);
      if (intersects.length > 0) {
        const hit = intersects[0].object as THREE.Mesh;
        if (hit.userData?.node) {
          const node = hit.userData.node as BrainNode;
          const sub = subsystems[node.subsystemId];
          setHoveredNode({
            name: `${node.label} (${sub.title})`,
            region: sub.lobeRegion,
            x: clientX,
            y: clientY,
          });
          container.style.cursor = 'pointer';
          return;
        }
      }
      setHoveredNode(null);
      container.style.cursor = isDraggingRef.current ? 'grabbing' : 'grab';
    };

    container.addEventListener('mousemove', handlePointerMove);

    // Animation Loop
    let clock = new THREE.Clock();

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Explode Lobe Animation interpolation
      const targetExplode = isExploded ? 0.75 : 0;
      explodeAmountRef.current = THREE.MathUtils.lerp(explodeAmountRef.current, targetExplode, 0.08);

      // Update positions for exploded view
      if (pointsMeshRef.current && originalPositions) {
        const positions = pointsMeshRef.current.geometry.attributes.position.array as Float32Array;
        for (let i = 0; i < originalPositions.length; i += 3) {
          const ox = originalPositions[i];
          const oy = originalPositions[i + 1];
          const oz = originalPositions[i + 2];

          // Radial expansion factor
          const factor = 1 + explodeAmountRef.current * 0.45;
          positions[i] = ox * factor;
          positions[i + 1] = oy * factor;
          positions[i + 2] = oz * factor;
        }
        pointsMeshRef.current.geometry.attributes.position.needsUpdate = true;
      }

      // Smooth camera position lerping
      if (cameraRef.current) {
        cameraRef.current.position.lerp(targetCameraPosRef.current, 0.05);

        // Report zoom level
        const dist = cameraRef.current.position.length();
        let currentZoomLevel: ZoomLevel = 'overview';
        if (dist < 2.5) currentZoomLevel = 'node';
        else if (dist < 3.8) currentZoomLevel = 'network';
        else if (dist < 4.8) currentZoomLevel = 'region';
        else currentZoomLevel = 'overview';

        onZoomLevelChange?.(currentZoomLevel);
      }

      // Rotate Brain if auto-rotate enabled or inertial dragging
      if (brainRootRef.current) {
        if (!isDraggingRef.current && isRotating) {
          brainRootRef.current.rotation.y += 0.0035;
        } else {
          brainRootRef.current.rotation.y += rotationVelocityRef.current.y;
          brainRootRef.current.rotation.x += rotationVelocityRef.current.x;
          // Friction damping
          rotationVelocityRef.current.y *= 0.94;
          rotationVelocityRef.current.x *= 0.94;
        }
      }

      // Rotate Floor Radar Rings slowly in reverse
      if (reticlesGroupRef.current) {
        reticlesGroupRef.current.rotation.y -= 0.001;
      }

      // Pulse traveling action potentials along axon fiber curves
      pulseSpheres.forEach((p) => {
        p.progress += p.speed;
        if (p.progress > 1) p.progress = 0;
        const pt = p.curve.getPoint(p.progress);
        const factor = 1 + explodeAmountRef.current * 0.45;
        p.mesh.position.set(pt.x * factor, pt.y * factor, pt.z * factor);

        // Flash pulse size
        const s = 0.8 + Math.sin(time * 8 + p.progress * 10) * 0.3;
        p.mesh.scale.set(s, s, s);
      });

      // Subtle breathing pulse on centroid rings
      centroidMeshesRef.current.forEach((mesh) => {
        const s = 1 + Math.sin(time * 3 + mesh.position.x * 2) * 0.08;
        mesh.scale.set(s, s, s);
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animFrameIdRef.current);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handlePointerMove);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [subsystems, isExploded, isRotating, onZoomLevelChange, getThemeColors]);

  // Update theme colors
  useEffect(() => {
    if (!pointsMeshRef.current) return;
    const colors = getThemeColors(hologramTheme);
    const mat = pointsMeshRef.current.material as THREE.PointsMaterial;
    if (mat) {
      mat.color.setHex(colors.primary);
    }
  }, [hologramTheme, getThemeColors]);

  // Handle pulse trigger flash (when user submits a command or action occurs)
  useEffect(() => {
    if (!pulseTrigger || !brainRootRef.current) return;
    soundFx.playPulse();

    // Momentary surge in point sizes and fiber glow
    if (pointsMeshRef.current) {
      const mat = pointsMeshRef.current.material as THREE.PointsMaterial;
      const originalSize = mat.size;
      mat.size = 0.08;
      setTimeout(() => {
        mat.size = originalSize;
      }, 300);
    }
  }, [pulseTrigger]);

  // Focus on selected subsystem
  useEffect(() => {
    if (!selectedSubsystemId || !cameraRef.current) return;
    const sub = subsystems[selectedSubsystemId];
    if (sub) {
      // Lerp camera towards that lobe
      const [cx, cy, cz] = sub.clusterPosition;
      targetCameraPosRef.current = new THREE.Vector3(cx * 1.5, cy * 1.2 + 0.3, cz * 1.5 + 2.4);
      soundFx.playSelect();
    }
  }, [selectedSubsystemId, subsystems]);

  // Mouse drag to rotate
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !brainRootRef.current) return;
    const deltaX = e.clientX - prevMousePosRef.current.x;
    const deltaY = e.clientY - prevMousePosRef.current.y;

    brainRootRef.current.rotation.y += deltaX * 0.007;
    brainRootRef.current.rotation.x += deltaY * 0.007;

    rotationVelocityRef.current = {
      x: deltaY * 0.002,
      y: deltaX * 0.002,
    };

    prevMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  // Wheel to zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomDelta = e.deltaY * 0.003;
    const currentPos = targetCameraPosRef.current;
    const dir = currentPos.clone().normalize();
    const newLen = THREE.MathUtils.clamp(currentPos.length() + zoomDelta, 1.8, 8.5);
    targetCameraPosRef.current = dir.multiplyScalar(newLen);
  };

  // Click on Canvas
  const handleClick = (e: React.MouseEvent) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current || !sceneRef.current) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    if (centroidsGroupRef.current) {
      const intersects = raycaster.intersectObjects(centroidsGroupRef.current.children);
      if (intersects.length > 0) {
        const hit = intersects[0].object as THREE.Mesh;
        if (hit.userData?.subsystemId) {
          const subId = hit.userData.subsystemId as SubsystemId;
          const node = hit.userData.node as BrainNode;
          onSelectSubsystem(subId);
          onSelectNode(node);
          soundFx.playChirp();
          return;
        }
      }
    }
  };

  // Helper buttons for reset and fit
  const handleResetCamera = () => {
    targetCameraPosRef.current = new THREE.Vector3(0, 0.4, 5.2);
    if (brainRootRef.current) {
      brainRootRef.current.rotation.set(0, 0, 0);
    }
    soundFx.playSelect();
  };

  const handleZoomIn = () => {
    const current = targetCameraPosRef.current;
    const len = Math.max(1.8, current.length() - 0.7);
    targetCameraPosRef.current = current.clone().normalize().multiplyScalar(len);
    soundFx.playChirp();
  };

  const handleZoomOut = () => {
    const current = targetCameraPosRef.current;
    const len = Math.min(8.0, current.length() + 0.7);
    targetCameraPosRef.current = current.clone().normalize().multiplyScalar(len);
    soundFx.playChirp();
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden flex items-center justify-center">
      {/* Three.js Container */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleClick}
      />

      {/* Floating Holographic Cursor Tooltip */}
      {hoveredNode && (
        <div
          className="fixed pointer-events-none z-50 transform -translate-x-1/2 -translate-y-full mb-3 px-3 py-1.5 rounded bg-slate-950/90 border border-cyan-500/50 backdrop-blur shadow-lg shadow-cyan-950/50 text-xs"
          style={{ left: hoveredNode.x + mountRef.current!.getBoundingClientRect().left, top: hoveredNode.y + mountRef.current!.getBoundingClientRect().top }}
        >
          <div className="flex items-center gap-1.5 text-cyan-300 font-semibold font-orbitron">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            {hoveredNode.name}
          </div>
          <div className="text-[11px] text-slate-400 font-mono-code">{hoveredNode.region}</div>
          <div className="text-[10px] text-emerald-400 mt-0.5">Click to inspect subsystem</div>
        </div>
      )}

      {/* 3D Viewport Quick Controls (Floating bottom center) */}
      <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 z-20 flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-950/80 border border-cyan-500/30 backdrop-blur text-xs text-slate-300 font-rajdhani">
        <button
          onClick={handleZoomIn}
          title="Zoom In"
          className="px-2 py-0.5 rounded hover:bg-cyan-500/20 hover:text-cyan-300 transition-colors font-bold"
        >
          +
        </button>
        <span className="text-slate-600">|</span>
        <button
          onClick={handleZoomOut}
          title="Zoom Out"
          className="px-2 py-0.5 rounded hover:bg-cyan-500/20 hover:text-cyan-300 transition-colors font-bold"
        >
          -
        </button>
        <span className="text-slate-600">|</span>
        <button
          onClick={handleResetCamera}
          title="Reset Camera & Fit Brain"
          className="px-2 py-0.5 rounded hover:bg-cyan-500/20 hover:text-cyan-300 transition-colors text-[11px] tracking-wider uppercase font-semibold"
        >
          Reset View
        </button>
      </div>
    </div>
  );
};

// ==========================================
// Procedural Anatomical Brain Generator
// ==========================================
function generateBrainGeometry(subsystems: Record<SubsystemId, SubsystemInfo>) {
  const pointsCount = 4200;
  const positions: number[] = [];
  const colors: number[] = [];
  const nodes: BrainNode[] = [];

  // Register centroid nodes for the 8 JARVIS subsystems
  Object.values(subsystems).forEach((sub) => {
    const [cx, cy, cz] = sub.clusterPosition;
    nodes.push({
      id: `node-${sub.id}-centroid`,
      label: sub.title,
      subsystemId: sub.id,
      position: [cx, cy, cz],
      color: sub.color,
      size: 0.16,
      activityLevel: 0.95,
      isCentroid: true,
      connections: [],
      description: `${sub.title} neural processing hub (${sub.lobeRegion})`,
    });
  });

  // Interconnect centroids into a coherent neural graph
  const centroidList = nodes.filter((n) => n.isCentroid);
  for (let i = 0; i < centroidList.length; i++) {
    for (let j = i + 1; j < centroidList.length; j++) {
      centroidList[i].connections.push(centroidList[j].id);
      centroidList[j].connections.push(centroidList[i].id);
    }
  }

  // Generate thousands of cortical surface and deep neural points
  for (let i = 0; i < pointsCount; i++) {
    // Hemispheric separation: left hemisphere (u < 0.5) vs right (u >= 0.5)
    const isLeft = Math.random() < 0.5;
    const hemiSign = isLeft ? -1 : 1;

    // Spherical coordinates
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);

    // Base brain dimensions (ellipsoid stretched along Z-axis)
    const rx = 1.15;
    const ry = 0.95;
    const rz = 1.45;

    // Cortex gyri & sulci undulating waves
    const gyrusFolds =
      1 +
      0.09 * Math.sin(theta * 7) * Math.cos(phi * 9) +
      0.05 * Math.sin(phi * 16) +
      0.04 * Math.cos(theta * 12);

    let x = rx * Math.sin(phi) * Math.cos(theta) * gyrusFolds;
    let y = ry * Math.sin(phi) * Math.sin(theta) * gyrusFolds;
    let z = rz * Math.cos(phi) * gyrusFolds;

    // Hemispheric split: push apart laterally and pinch medial longitudinal fissure
    x = hemiSign * (0.07 + Math.abs(x) * 0.94);

    // Anatomical shaping:
    // 1. Flatten bottom, taper cerebellum and brainstem
    if (y < -0.3 && z < -0.3) {
      // Cerebellum bulge
      y = y * 0.9 - 0.2;
      x = x * 0.85;
    }
    if (y < -0.7 && Math.abs(x) < 0.4 && z > -0.5 && z < 0.2) {
      // Brainstem stalk
      x = x * 0.45;
      z = z * 0.5 - 0.1;
    }
    // 2. Prefrontal cortex curvature
    if (z > 0.8) {
      y = y * 0.95;
      x = x * 0.92;
    }

    // Assign to nearest subsystem cluster for coloring
    let nearestSub: SubsystemInfo = subsystems.planning;
    let minDistance = Infinity;

    Object.values(subsystems).forEach((sub) => {
      const [cx, cy, cz] = sub.clusterPosition;
      const dist = Math.hypot(x - cx, y - cy, z - cz);
      if (dist < minDistance) {
        minDistance = dist;
        nearestSub = sub;
      }
    });

    positions.push(x, y, z);

    // Color gradient blending
    const baseColor = new THREE.Color(nearestSub.color);
    // Subtle bioluminescent variation
    baseColor.offsetHSL(0, (Math.random() - 0.5) * 0.15, (Math.random() - 0.5) * 0.2);
    colors.push(baseColor.r, baseColor.g, baseColor.b);

    // Sample occasional secondary synapse nodes
    if (i % 60 === 0) {
      nodes.push({
        id: `node-synapse-${i}`,
        label: `${nearestSub.title} Synapse #${i}`,
        subsystemId: nearestSub.id,
        position: [x, y, z],
        color: nearestSub.color,
        size: 0.08,
        activityLevel: 0.5 + Math.random() * 0.4,
        connections: [`node-${nearestSub.id}-centroid`],
      });
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

  const material = new THREE.PointsMaterial({
    size: 0.045,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
  });

  const pointsMesh = new THREE.Points(geometry, material);

  return {
    pointsMesh,
    nodes,
    originalPositions: new Float32Array(positions),
  };
}
