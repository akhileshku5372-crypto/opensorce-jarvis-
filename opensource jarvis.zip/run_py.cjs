/* One interpreter resolver for PM2, diagnostics and every Python service. */
const { spawn, spawnSync } = require('child_process')
const path = require('path')
const fs = require('fs')

function resolvePython() {
  const local = path.join(__dirname, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
  const candidates = process.env.JARVIS_PYTHON
    ? [[process.env.JARVIS_PYTHON, []]]
    : [...(fs.existsSync(local) ? [[local, []]] : []),
       ...(process.platform === 'win32' ? [['py', ['-3.12']], ['py', ['-3.11']], ['py', ['-3']]] : []),
       ['python', []], ['python3', []]]
  for (const [exe, args] of candidates) {
    const probe = spawnSync(exe, [...args, '-c', 'import sys; print(sys.executable); sys.exit(0 if sys.version_info >= (3,10) else 1)'], {
      encoding: 'utf8', timeout: 10000, windowsHide: true
    })
    if (probe.status === 0 && probe.stdout.trim()) return probe.stdout.trim().split(/\r?\n/).pop()
  }
  throw new Error('Python 3.10+ not found. Run setup-windows.ps1 or set JARVIS_PYTHON to a real python.exe.')
}

if (require.main === module) {
  try {
    const python = resolvePython()
    const script = process.argv[2]
    if (script === '--resolve') { console.log(python); process.exit(0) }
    if (!script) throw new Error('usage: node run_py.cjs <script.py | -m module | --resolve> [arguments]')
    const args = script === '-m' ? process.argv.slice(2) : [path.resolve(__dirname, script), ...process.argv.slice(3)]
    const child = spawn(python, ['-u', ...args], {
      cwd: __dirname, stdio: 'inherit', windowsHide: true,
      env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' }
    })
    child.on('error', err => { console.error('[run_py]', err.message); process.exitCode = 1 })
    child.on('exit', (code, signal) => process.exit(code ?? (signal ? 1 : 0)))
    for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { if (!child.killed) child.kill(signal) })
    process.on('exit', () => { if (!child.killed) child.kill() })
  } catch (err) { console.error('[run_py]', err.message); process.exitCode = 1 }
}
module.exports = { resolvePython }
