"""YouTube open/search route, word-order independent.

Live 2026-10-17 21:46 transcript: "मुझे जेईई मेन फिजिक्स का लेक्चर खोल दो
YouTube पे" reached `[INTENT] os:` and then fell all the way to the brain, which
answered with an instruction string instead of opening anything. The old regex
required "youtube" BEFORE the verb, so every Hindi sentence that puts the site
token last (the normal Hindi order) was unparseable.

Stdlib only - no mic, no TTS, no network, no real browser.

Run:  node run_py.cjs -m unittest discover -s tests -p test_youtube_route.py
"""
import importlib.util
import os
import sys
import unittest
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _refuse(name):
    """No unit test may open a real app or window."""
    def refuse(target, *args, **kwargs):
        raise AssertionError("test tried to really %s %r" % (name, str(target)[:90]))
    return refuse


if hasattr(os, "startfile"):
    os.startfile = _refuse("startfile")
webbrowser.open = _refuse("open in browser")
webbrowser.open_new = _refuse("open in browser")
webbrowser.open_new_tab = _refuse("open in browser")


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "voice_engine", ROOT / "background" / "voice_engine.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load_engine()

# The live utterances from jarvis-voice-out-2.log (21:46:09 and 21:46:37), plus
# the English/Hinglish orders that already worked and must keep working.
HINDI_LAST = [
    "मुझे जेईई में, मुझे जेईई मेन फिजिक्स का लेक्चर खोल दो YouTube पे",
    "मैंने YouTube बोला की YouTube पे तुम यही मेंस का लेक्चर खोल दो फिजिक्स का",
    "jee mains physics ka lecture khol do youtube pe",
]
ENGLISH_ORDER = [
    "youtube pe maan mera song search karo",
    "search maan mera song in youtube",
    "youtube search for lofi beats",
    "play arijit singh songs on youtube",
    # "notebook" contains "not": the complaint guard must stay word-bounded.
    "youtube pe notebook movie play karo",
]
# A bare site open is NOT a search: it must stay on the _DIRECT_SITES path.
# A complaint about YouTube is not a command either.
NOT_A_SEARCH = [
    "open youtube",
    "youtube kholo",
    "kyu youtube open nahi ho raha",
    "youtube kya hai",
    "whatsapp pe akhilesh ko hello bhejo",
    "",
    None,
]
# "reSEARCH" contains "search" and "youtuber" contains "youtube". An unbounded
# verb pattern stole these away from the Firecrawl research route
# (test_core.test_do_research_phrasing_routes_to_firecrawl), so the research
# phrasings are pinned here too.
RESEARCH_NOT_YOUTUBE = [
    "do research on 2026 august new youtube content policy and explain in "
    "hinglish with hindi accent",
    "research karo 2026 youtube policy ke baare mein",
    "deep research karo youtube ke baare mein",
    "youtube content policy par research karo",
]


class QueryParseTest(unittest.TestCase):
    def test_hindi_site_last_parses(self):
        for raw in HINDI_LAST:
            with self.subTest(raw=raw[:40]):
                query = ENGINE._youtube_query(raw)
                self.assertTrue(query, "no query parsed from %r" % raw[:60])
                self.assertGreaterEqual(len(query.split()), 2)

    def test_hindi_query_keeps_the_subject(self):
        query = ENGINE._youtube_query(HINDI_LAST[0])
        for word in ("फिजिक्स", "लेक्चर"):
            self.assertIn(word, query)
        # The site token and the verb are not part of what to search for.
        self.assertNotIn("youtube", query.lower())
        self.assertNotIn("खोल", query)
        # Live 2026-10-17 23:52, with the route already working, the query went
        # out as "मुझे जेईई मेन फिजिक्स का लेक्चर दो पे": a Devanagari matra is
        # not \w in Python's re, so r"\bमुझे\b" never matched and every Hindi
        # framing word survived into the search.
        words = query.split()
        for filler in ("मुझे", "दो", "पे", "का", "में"):
            self.assertNotIn(filler, words)

    def test_hindi_stopwords_survive_their_own_matras(self):
        for word in ("मुझे", "दो", "पे", "कीजिए", "थोड़ा"):
            with self.subTest(word=word):
                self.assertIsNotNone(ENGINE._YT_STOPWORDS.search(word))
        # The edge must not bite into a longer word: "कि" is a stopword,
        # "किसी" is not.
        self.assertIsNone(ENGINE._YT_STOPWORDS.search("किसी"))
        self.assertEqual(
            " ".join(ENGINE._YT_STOPWORDS.sub(" ", "किसी को").split()), "किसी")

    def test_hindi_verbs_match_without_a_trailing_consonant(self):
        for word in ("खोलो", "चलाओ", "देखो", "सुनो"):
            with self.subTest(word=word):
                self.assertIsNotNone(ENGINE._YT_VERB_RE.search(word))
        # "खोल" must not match inside "खोलोगे" nor inside a longer noun.
        self.assertIsNone(ENGINE._YT_VERB_RE.search("खोलोगे"))

    def test_english_orders_keep_working(self):
        for raw in ENGLISH_ORDER:
            with self.subTest(raw=raw):
                query = ENGINE._youtube_query(raw)
                self.assertTrue(query, "no query parsed from %r" % raw)
                self.assertNotIn("youtube", query.lower())

    def test_bare_open_and_complaints_are_not_searches(self):
        for raw in NOT_A_SEARCH:
            with self.subTest(raw=str(raw)[:30]):
                self.assertIsNone(ENGINE._youtube_query(raw))

    def test_research_phrasings_stay_with_firecrawl(self):
        for raw in RESEARCH_NOT_YOUTUBE:
            with self.subTest(raw=raw[:40]):
                self.assertIsNone(ENGINE._youtube_query(raw))

    def test_verb_pattern_is_word_bounded(self):
        self.assertIsNone(ENGINE._YT_VERB_RE.search("do research on that"))
        self.assertIsNotNone(ENGINE._YT_VERB_RE.search("search karo"))
        self.assertIsNone(ENGINE._YT_SITE_RE.search("that youtuber"))


class RouteHonestyTest(unittest.TestCase):
    """A failed launch must not be announced as a search that is running."""

    def setUp(self):
        self.spoken = []
        self.opened = []
        self._real = {"speak": ENGINE.speak, "open": ENGINE._open_url,
                      "brain": ENGINE.brain}
        ENGINE.speak = lambda message, ui=None: (
            self.spoken.append(str(message)), True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE._open_url = self._real["open"]
        ENGINE.brain = self._real["brain"]

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        ENGINE.run_command(text, None, None, "typed")
        return " ".join(self.spoken)

    def test_failed_launch_says_it_failed(self):
        ENGINE._open_url = lambda url: None
        said = self._route("youtube pe lofi beats search karo")
        self.assertIn("khul nahi paaya", said)
        self.assertNotIn("search kar raha hoon", said)

    def test_successful_launch_names_the_query(self):
        ENGINE._open_url = lambda url: (self.opened.append(url),
                                        "Opening the website, Sir.")[1]
        said = self._route("youtube pe lofi beats search karo")
        self.assertIn("lofi beats", said)
        self.assertEqual(len(self.opened), 1)
        self.assertIn("search_query=lofi%20beats", self.opened[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
