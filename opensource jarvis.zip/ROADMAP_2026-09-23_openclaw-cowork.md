# JARVIS → OpenClaw / Claude Cowork: Old Context + Advanced Evolution Plan (23-Sep-2026)

Tumhara "old context" (project ab tak kya hai, kahan se aaya) + OpenClaw aur Claude Cowork ke
verified capabilities + exact gap analysis + phased plan. Sab JARVIS ke existing architecture
constraints ke andar (no second mic/brain, HUD = visual client, bridge allowlist-only).

---

## 1. OLD CONTEXT — JARVIS ab tak (kya bana hua hai)

**Kya hai:** ek voice-first personal JARVIS — single canonical Python voice runtime
(`background/voice_engine.py`) + loopback-only Windows action bridge (`local-bridge/server.cjs`)
+ minimal dashboard (Hono `src/index.tsx` + `public/static/app.js`) + floating HUD
(`background/floating_ui.pyw`) jo sirf visual client hai. PM2 se 5 services chalti hain
(ui:7777, bridge:7778, voice:7780, podcast:7781, edge-tts:7782).

**Journey (commits se):** Hono edge server + LLM orchestration (`5bc18b3`) → UI layout repair
(`570b731`) → Modules & Upgrades roadmap restore (`930be8d`/`fe9c2eb`) → **sleep ("stop") system**
(`1f5ebd9`) — deep silence until "Hey JARVIS wake up", timed auto-wake.

**Jo already strong hai (rare in hobby projects):**
- **Wake pipeline**: OpenWakeWord (ONNX `hey_jarvis`) + text gate with mishear tables
  (Hindi/Urdu/Japanese scripts), Silero VAD, neural backstop, media-noise protection
- **Multi-provider brain chain**: Gemini → Groq → OpenRouter → xKiro → Ollama (free-tier failover)
- **Real OS control**: allowlisted app launch/close, windows, media keys, mouse, keyboard,
  file explorer — destructive actions confirmation-gated
- **Screen agent**: perceive→ground→act→verify GUI automation (`screen_agent.py`)
- **KamiSensei**: RAG study assistant (ChromaDB, PDF/OCR, artifacts, notebooks, podcast)
- **Research**: Firecrawl search + deep-research → spoken report
- **Sleep system**: honest silence semantics (banaya gaya is hafte)
- **Honest UI discipline**: no fake demo turns, real runtime states only

**Jo abhi MISSING hai (yahi OpenClaw/Cowork ka core):** messaging channels, skills system,
scheduled jobs, hooks/webhooks, multi-agent sessions, plugin marketplace, doc-centric workspace,
parallel task runs, cloud-safe remote access.

---

## 2. OPENCLAW — kya hai, kya karta hai (docs.openclaw.ai se verified)

OpenClaw = **self-hosted Gateway** jo tumhare chat apps ko AI agents se jodta hai — "your AI
assistant, on your own hardware, in every chat app you already use". No hosted middleman.

| Capability | Detail |
|---|---|
| **One Gateway process** | Single service on your machine/server; everything routes through it |
| **Channels (plugins)** | Discord, Signal, Telegram, **WhatsApp**, iMessage, Matrix, Teams, Slack, Google Chat, Zalo — pairing + `allowFrom` access groups + `requireMention` group rules |
| **Skills** | "Teach the agent repeatable procedures it loads on demand" — markdown/defined skill files |
| **Automation** | **Cron jobs, hooks, webhooks** — scheduled/triggered work |
| **Multi-agent routing** | Isolated sessions per agent, workspace, or sender |
| **Media** | Send/receive images, audio, documents through channels |
| **Control UI** | Browser dashboard for chat, config, sessions |
| **Mobile nodes** | iOS/Android nodes: camera, screen, voice workflows |
| **ClawHub** | Plugin marketplace (publish/curation/trust) |
| **Models** | Any provider + failover + local models |
| **Security model** | "Trust boundary", **policy as code**, identity & roles, secrets mgmt, versioned state with guarded upgrades, provenance |

**Core insight:** OpenClaw brilliant hai *reach* (phone se baat kar pao) aur *operational
discipline* (skills, cron, policy) mein — but voice-first desktop OS control usme nahi hai.
**Wahi JARVIS ka moat hai.**

## 3. CLAUDE COWORK — kya hai (Anthropic ke verified anchors)

Cowork Anthropic ka **agentic coworking** product hai (Pro plan mein included):
"Brainstorm in chat, build in Cowork". Verified anchors:

| Anchor (blog/news) | Kya batata hai |
|---|---|
| **"Claude Cowork and chat are now one"** (Sep 16, 2026) | Cowork ab chat ke saath merge ho chuka — alag app nahi, ek hi surface |
| **"Claude gets its own browser in Cowork"** (Aug 26, 2026) | Cowork ke paas apna agentic browser hai (Claude khud browse karke kaam karta hai) |
| Products lineup (claude.com) | Cowork = Claude Code ke saath baitha product; capabilities: **Skills, Connectors, Plugins, Artifacts, Extensions** |

Cowork ka DNA (jaise ye category kaam karti hai):
- **Doc-centric workspace**: chat + documents + files ek jagah — assistant document ke andar kaam karta hai
- **Skills reuse**: Claude Code wale skills Cowork mein bhi chalte hain
- **Connectors / MCP**: Gmail, Calendar, Slack, koi bhi remote MCP tool
- **Parallel agentic work**: ek se zyada task ek saath
- **Files in/out**: user files dete hai, agent banata/edit karke wapas deta hai

---

## 4. GAP ANALYSIS — JARVIS vs OpenClaw vs Cowork

| Capability | OpenClaw | Cowork | JARVIS aaj | Gap |
|---|---|---|---|---|
| Voice-first + wake word + sleep semantics | partial | ✗ | ✅✅ | **JARVIS ahead** |
| Desktop OS control (windows, apps, input) | partial | ✗ | ✅✅ | **JARVIS ahead** |
| Screen GUI agent (perceive→act→verify) | ✗ | ✗ | ✅ | **JARVIS ahead** |
| Chat channels (WhatsApp/Telegram/…) | ✅✅ | ✗ | ✗ (sirf WhatsApp chat prep card) | **BIG GAP #1** |
| Skills system (loadable procedures) | ✅✅ | ✅ | ✗ (hardcoded intents) | **BIG GAP #2** |
| Cron / scheduled jobs / webhooks | ✅✅ | partial | partial (Scheduler Core = standby card) | **GAP #3** |
| Multi-agent / isolated sessions | ✅✅ | ✅ | ✗ | **GAP #4** |
| Doc-centric workspace (chat+docs+files) | ✗ | ✅✅ | partial (KamiSensei notebooks!) | **GAP #5** |
| Agentic browser | ✗ | ✅✅ | ✗ (Web Intelligence = search only) | **GAP #6** |
| Plugin/marketplace ecosystem | ✅ (ClawHub) | ✅ (Plugins/MCP) | ✗ | later |
| Remote access (phone reach) | ✅✅ | cloud | ✗ (loopback only — by design) | **GAP #1 ka hissa** |
| Memory | per-agent sessions | conversation+ | ChromaDB + Mem0 (light) | strengthen |

## 5. EVOLUTION PLAN — phased (JARVIS ke constraints ke andar)

### PHASE A — "JARVIS Gateway" (OpenClaw ka core, 2–3 din ka kaam)
1. **Channel plugins in the canonical engine**: `background/channels/` — Telegram bot
   (long-poll, no inbound port) + WhatsApp Cloud API webhook sabse pehle. Router =
   `submit_command(text, ui, bridge, source='telegram'|'whatsapp')` — **engine already
   source-aware hai**; replies `speak()` ke bajaye channel par text + optional TTS audio file.
   Pairing: pehla message → pair code → allowlist (OpenClaw `allowFrom` jaisa).
   **Loopback constraint break nahi hota** — sirf outbound connections.
2. **Sessions**: `STATE.events` already revisioned — per-channel conversation scoping
   (channel+chat-id key), `memory_context` usi scope se.
3. **Media in**: photo bhejo → existing camera/screen analysis path reuse.

### PHASE B — Skills + Automation (OpenClaw "Capabilities")
4. **`skills/` folder + loader**: har skill = ek `.md` (name, trigger phrases, steps, allowed
   bridge actions). Engine `submit_command` se pehle skill-match kare, steps ko
   `run_command` sequence mein chalaye. Pehle 5 skills: morning-briefing, focus-mode,
   meeting-prep, system-audit, study-session (KamiSensei link).
5. **Cron in-engine**: `background/scheduler.py` — "har subah 8 baje briefing suna" →
   `Documents/JARVIS/schedule.json`; delivery voice ya channel par.
   (Roadmap card "Scheduler Core — PHASE 1" yahan sach me banega.)
6. **Webhooks**: bridge par allowlisted `/hook/<name>` endpoint (origin-gated, registered
   names only) — OpenClaw webhooks jaisa, loopback pehle.

### PHASE C — Cowork-style workspace (KamiSensei ko expand karo, naya app nahi)
7. **Workbench panel**: dashboard mein chat + live markdown doc + artifacts side-by-side
   (KamiSensei artifact renderer generalize karo). "Is doc ko likh / summarize kar".
8. **Agentic browser (careful)**: Playwright `browser_agent.py` — read-only browse + extract +
   summarize pehle; destructive form-fill confirmation-gated (bridge rule jaisa hi).
   "Browser Extension Bridge" roadmap card ka engine-side version.
9. **Connectors via MCP-lite**: chhota MCP client (Gmail/Calendar type remote tools) —
   brain chain ke system prompt mein tools list inject.

### PHASE D — Multi-agent + policy (baad mein)
10. **Agent profiles**: `agents/*.json` (persona, skills, channels, memory scope) —
    OpenClaw "multi-agent routing" jaisa; ek engine process, per-agent session isolation.
11. **Policy-as-code** (OpenClaw jeetna zaroori): YAML — channel allowlists, per-skill allowed
    bridge actions, quiet hours, confirmation rules. **Tumhara sleep system iska natural
    feature hai: "stop for N minutes" = global do-not-disturb policy.**
12. Marketplace abhi nahi — skills format stable hone do.

### Kya NAHI karna (architecture rules rehte hain)
- ❌ Doosra mic/assistant/memory pipeline kabhi nahi — channels sirf `submit_command` ko feed karte hain
- ❌ HUD ko sirf naye state fields dikhane ke liye extend karo (sleep jaisa hi)
- ❌ Bridge ko non-loopback expose nahi; phone reach = channel bots (outbound), port-forward nahi

### Effort estimate
Phase A: 2–3 sessions · B: 2 sessions · C: 3–4 sessions · D: ongoing.
Phase A ke baad JARVIS = "OpenClaw with a soul" (voice + OS control jo OpenClaw mein nahi);
Cowork wala workbench Phase C se.



---

## SESSION LOG - 2026-09-23 (Part 2): Co-work surfaces + P0 power isolation + wake repair

**Shipped (all validated, no new services, no second pipeline):**

| # | Change | File | Verified by |
|---|---|---|---|
| 1 | **Co-work view** (live task / channels / schedule / skills) in the dashboard nav + panels, rendered from real core state | `src/index.tsx`, `public/static/app.js` (`renderCowork`) | `npm run build`, `node --check public/static/app.js` |
| 2 | **SYSTEM deck** in the floating HUD (4th tab, own scroll): co-work task, channels, schedule, skills revision, power lock | `background/floating_ui.pyw` (`_draw_system_view`, poll sync, click map) | `py_compile`, tab/click map aligned |
| 3 | **Voice meta-routes** (local, no LLM): status / cowork / team / task list / skills | `background/voice_engine.py` (`run_command`, after Phase-1 skills) | `tests/test_power_wake.py` |
| 4 | **HTTP surfaces**: `GET /sleep`, `GET /pulse`, `POST /sleep` (`{"seconds": N}`, 0 = until wake phrase) | `background/voice_engine.py` (`do_GET` / `do_POST`) | `py_compile`, `test:core` HTTP suite |
| 5 | **P0 power isolation in the bridge** - deny table for shutdown/restart/reboot/log-off/hibernate/OS-sleep incl. Hindi phrasings; `shutdown cancel` still works | `local-bridge/server.cjs` (`denyPowerIntent`) | `tests/test_bridge_power.cjs` |
| 6 | **Deep-sleep wake repair** - "band ho jao" / "sleep mode off" / "stop sleeping" / "uth jao" / "उठ जाओ" now actually wake JARVIS; TV noise still ignored | `background/voice_engine.py` (`_STRICT_WAKE`, `_SLEEP_EXIT_RE`, `_sleep_exit_phrase`) | `tests/test_power_wake.py`, `temp/test_sleep_system.py` (63 checks) |

**Bugs fixed (found by the new tests; all were live):**
1. `laptop band karo` / `system band karo` slipped past `power_guard` (STT sanitising turns them into "laptop band") and reached the LLM brain with the bridge `shutdown.exe` route one hop away. Now denied in both engine and bridge.
2. `uth jao` - the documented primary Hindi wake phrase - could never wake a deep-sleeping JARVIS (`uth\s*j(?:a|aa|ao\w*)` left a dangling "o" the residual gate rejected). Same for `उठ जाओ`, `जाग जाओ`, `उठो`, `get up`.
3. `_SLEEP_WAKE_RE` was dead code: "band ho jao" / "sleep mode off" / "stop sleeping" / "जाग उठ" were documented wake phrases that nothing ever consulted.
4. `_cowork_list_tasks()` read `STATE["channels"]` and printed channel ids as tasks - a fake task list. It now reads the live `STATE["cowork"]` task + steps.
5. 5 pre-existing `test:core` failures (proved at HEAD in a clean checkout): the sleep system leaked `sleep_mode` between tests and two stop-tests still asserted pre-sleep semantics. Test isolation + intent-preserving updates give **54/54 pass**.

**New regression coverage:** `tests/test_power_wake.py` (8 tests) + `tests/test_bridge_power.cjs`, wired as `npm run test:power` inside `npm test`.

**Still open (unchanged):** channel adapters (an inbound message only feeds `submit_command`), real scheduled jobs, a live `cowork` writer (the state fields exist but nothing populates a real task yet), N-version skill loader.

---

## SESSION LOG - 2026-09-23 (Part 3): skills/MCP/co-work wiring + verification

**Shipped (all validated against the required gate: `test:bridge` + `node --check` + `py_compile` + `build`):**

| # | Change | File | Verified by |
|---|---|---|---|
| 1 | **Skill loader** — N-version `SKILL.md` catalog under `skills/`, `load/revision/describe/match/get/context_for`; trigger-matched body injected into the system prompt, catalog always visible, empty folder = honest "khaali" message | `background/skill_loader.py`, `skills/*/SKILL.md` | `npm run test:skills` (15 tests) |
| 2 | **MCP client** — stdio servers spawned only from `mcp/servers.json` via an allowlisted `python tests/fixtures/*.py` resolver (no arbitrary commands, cwd must stay in-repo), `list_tools/call_tool/find_tool/describe/catalog` | `background/mcp_client.py`, `mcp/servers.json` | `npm run test:skills` incl. sandbox-escape + unknown-server cases |
| 3 | **Co-work runtime** — sequential task ledger (`start/cancel/snapshot/describe/parse_plan`), persisted to `artifacts/cowork/task.json`, interrupted tasks marked on boot, second-start refused while running, failure stops and skips the rest; thread loop now None-safe against concurrent `cancel`/test cleanup | `background/cowork_runtime.py` | `npm run test:skills` (6 tests) |
| 4 | **Voice routes** — meta-routes `skill` / `use skill X` / `mcp status` / `mcp tools` / `mcp call` / `cowork chalao|stop|status` wired into `run_command` after Phase-1; skill apply + MCP results funnel back through `brain()` (single router, single STATE) | `background/voice_engine.py` (`_skill_route`, `_mcp_route`, `_cowork_route`, `_skills_prompt_fragment`, `_mcp_prompt_fragment`) | `py_compile`, `test:power`, `test:core` |
| 5 | **HTTP surfaces** — `POST /skills`, `POST /cowork[/start|/cancel]`, `POST /mcp[/call|/refresh]` on the core (7780); dashboard Co-work panel gained task start/cancel inputs + MCP call/Run/Refresh; `bindCoworkActions()` wired into the poll loop; `skills_list` + MCP tools boxes render real state | `background/voice_engine.py`, `src/index.tsx`, `public/static/app.js` | `npm run build`, `node --check public/static/app.js` |
| 6 | **HUD SYSTEM deck extended** — skills list + MCP tool rows (`server.tool` + call/list-only tag) drawn from parsed core state; empty registries stay empty (no fake rows) | `background/floating_ui.pyw` (`_draw_system`, state parse) | `py_compile`, fields at init L168-169, parse at L507-510, draw at L882-906 |

**Bugs fixed this part:**
1. `cowork_runtime._run` crashed with `TypeError: 'NoneType' object is not subscriptable` when `_task` was cleared concurrently (test cleanup / cancel race) — loop now snapshots steps and re-reads `_task` under the lock each iteration.
2. Co-work test cleanup hit `PermissionError` unlinking `artifacts/cowork/task.json` while the runner thread still held it — `_clean()` now joins the runner first, then retries the unlink.
3. `test_handles_missing_folder` imported `skill_loader` by module name (not on `sys.path` under `unittest discover`) — now uses the already-loaded `SKILLS` module handle.

**Verification (all green, re-run end-to-end):**
`npm run test:bridge` ✅ · `npm run test:power` ✅ (27 denied + 12 allowed bridge checks, 8 wake tests) · `npm run test:skills` ✅ (15 + 6) · `node --check public/static/app.js` ✅ · `node --check local-bridge/server.cjs` ✅ · `py_compile` × 5 touched Python files ✅ · `npm run build` ✅ (219 kB worker, 266 ms).

**Confirmed carried from Part 2:** `_SLEEP_WAKE_RE` double-backslash bug is gone — the regex is now `_SLEEP_EXIT_RE` with correct single-backslash patterns (voice_engine L2117-2122) and a single `_sleep_exit_phrase()` reader; no duplicate `# ──` comment remains; `_phase1_handle` call site and `_strict_launch_target` (L3776) sit cleanly with no orphaned edit fragments; bridge `denyPowerIntent` (server.cjs L450) gates `routeAction` before every route.

**Still open:** channel adapters, real scheduled jobs, N-version skill loader hardening; MCP servers beyond the local stdio fixtures; gitignore/docs cleanup commit.

