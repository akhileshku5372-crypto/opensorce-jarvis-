﻿"""REAL execution tests for the orchestration node types added to Co-Work ->
Agents: router, parallel, merge, loop, validator, evaluator, memory, transform,
error/fallback, checkpoint, nested workflow, plus typed dataflow.

These drive the real `_walk_region` executor. Tools come from a real
ToolRegistry-shaped double registered through the SAME injection point the
voice engine uses, so `catalog()`/`validate()` see them exactly as they would
see production tools. Nothing here asserts a fabricated success: each test runs
a saved flow end to end and inspects the real node outcomes.

Run: node run_py.cjs -m unittest discover -s tests -p test_agent_flow_orchestration.py
"""
import importlib.util
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "agent_flow_orch", ROOT / "background" / "agent_flow.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


AF = _load_engine()


class _Tool:
    """A real-shaped ToolSpec.

    Mirrors the attributes `background/agent_flow.py::_tool_rows` actually reads
    (name, description, requires_confirmation, parameters) so the catalog,
    validation and executor see this exactly as they see a production tool."""

    def __init__(self, name, parameters, output, requires_confirmation=False,
                 read_only=True, destructive=False):
        self.name = name
        self.description = output
        self.output = output          # read by _run_tool_node via the registry
        self.parameters = {key: {"type": "string", "required": True}
                           for key in parameters}
        self.requires_confirmation = requires_confirmation
        self.read_only = read_only
        self.destructive = destructive
        self.category = "test"


class _Registry:
    """Real-shaped registry: get/list/execute, with a call log."""

    def __init__(self, tools):
        self._tools = {t.name: t for t in tools}
        self.calls = []
        self._lock = threading.Lock()

    def list(self):
        return list(self._tools.values())

    def get(self, name):
        return self._tools.get(name)

    def execute(self, name, args, confirm=None):
        tool = self._tools.get(name)
        with self._lock:
            self.calls.append((name, dict(args or {})))
        if tool is None:
            return {"ok": False, "error": "no such tool: %s" % name}
        if tool.requires_confirmation and callable(confirm) and not confirm(name, args):
            return {"ok": False, "denied": True, "error": "user declined %s" % name}
        return {"ok": True, "output": tool.output.format(**(args or {}))}


def _node(ntype, title, x=0, y=0, **config):
    node = AF._default_node(ntype, title)
    node["x"], node["y"] = x, y
    node["config"].update(config)
    return node


def _edge(src, dst, branch="", map_=""):
    return {"id": AF._slug("e"), "from": src["id"], "to": dst["id"],
            "label": "", "branch": branch, "map": map_}


def _agent(name, nodes, edges):
    return AF._normalize_agent({"name": name,
                                "flow": {"nodes": nodes, "edges": edges}})


class OrchestrationBase(unittest.TestCase):
    """Isolated store per test so a run never touches the user's agents."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self._orig_store = AF.STORE
        self._orig_run = AF.RUN_STORE
        AF.STORE = Path(self.tmp.name) / "agents.json"
        AF.RUN_STORE = Path(self.tmp.name) / "last_run.json"
        AF._run = None
        AF._cancel.clear()
        self.registry = _Registry([
            _Tool("echo", ["text"], "echo:{text}"),
            _Tool("slow_a", [], "branch-A-done"),
            _Tool("slow_b", [], "branch-B-done"),
            _Tool("tts_speak", ["text"], "audio.mp3 rendered for: {text}"),
        ])
        AF.configure(registry=self.registry,
                     confirm=lambda name, args: True,
                     planner=lambda prompt: "planned",
                     complete=lambda prompt: '{"score": 9, "notes": "good"}',
                     skills=None, mcp=None,
                     models=lambda: [{"id": "test-model"}],
                     cortex=None, permissions=None, memory=None)

    def tearDown(self):
        AF.STORE, AF.RUN_STORE = self._orig_store, self._orig_run
        AF._run = None
        AF._cancel.clear()
        self.tmp.cleanup()

    def run_flow(self, agent, run_input="", timeout=20.0):
        """Run a flow synchronously through the REAL executor, return the view."""
        report = AF.validate(agent)
        self.assertTrue(report["ok"], "flow should validate: %s" % report["errors"])
        AF._cancel.clear()
        AF._run = AF._empty_run(agent["id"], agent["name"], run_input)
        AF._execute_flow(agent, run_input)
        deadline = time.time() + timeout
        while time.time() < deadline:
            view = AF.current_run()
            if view.get("status") in ("done", "failed", "cancelled", "error"):
                return view
            time.sleep(0.05)
        return AF.current_run()

    def node_view(self, view, node):
        for entry in view.get("nodes") or []:
            if entry.get("id") == node["id"]:
                return entry
        self.fail("node %r not present in the run view" % node["title"])


class TestTypedDataflow(OrchestrationBase):
    """Phase 8: connections transfer real runtime data."""

    def test_output_key_publishes_typed_value_for_downstream(self):
        a = _node("tool", "Make greeting", tool="echo",
                  args_text='{"text": "hello"}', output_key="greeting")
        b = _node("transform", "Shout it", mode="upper", template="{{greeting}}")
        out = _node("output", "Final", template="RESULT:{{last}}")
        agent = _agent("dataflow", [a, b, out], [_edge(a, b), _edge(b, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual(self.node_view(view, b)["output"], "ECHO:HELLO")
        self.assertIn("RESULT:ECHO:HELLO", view["result"])

    def test_edge_map_renames_value_across_the_connection(self):
        a = _node("tool", "Source", tool="echo", args_text='{"text": "x"}',
                  output_key="src")
        b = _node("transform", "Consume", mode="upper", template="{{renamed}}")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("edge-map", [a, b, out],
                       [_edge(a, b, map_="src:renamed"), _edge(b, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual(self.node_view(view, b)["output"], "ECHO:X")


class TestRouter(OrchestrationBase):
    """Phase 4C: N-way routing."""

    def test_router_picks_the_matching_branch_and_skips_the_rest(self):
        src = _node("tool", "Classify", tool="echo", args_text='{"text": "urgent"}',
                    output_key="verdict")
        router = _node("router", "Triage", key="verdict",
                       rules_text="contains:urgent -> fast\ncontains:low -> slow",
                       default_branch="manual")
        fast = _node("tool", "Fast path", tool="slow_a")
        slow = _node("tool", "Slow path", tool="slow_b")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("router", [src, router, fast, slow, out],
                       [_edge(src, router), _edge(router, fast, branch="fast"),
                        _edge(router, slow, branch="slow"), _edge(fast, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual(self.node_view(view, fast)["status"], "done")
        self.assertEqual(self.node_view(view, slow)["status"], "skipped")
        self.assertNotIn("slow_b", [c[0] for c in self.registry.calls])

    def test_router_contains_rule(self):
        src = _node("tool", "Src", tool="echo", args_text='{"text": "disk full"}',
                    output_key="v")
        router = _node("router", "R", key="v", rules_text="contains:full -> alert",
                       default_branch="ignore")
        hit = _node("tool", "Alert", tool="slow_a")
        miss = _node("tool", "Ignore", tool="slow_b")
        out = _node("output", "Done", template="{{last}}")
        agent = _agent("router-contains", [src, router, hit, miss, out],
                       [_edge(src, router), _edge(router, hit, branch="alert"),
                        _edge(router, miss, branch="ignore"), _edge(hit, out)])
        view = self.run_flow(agent)
        self.assertEqual(self.node_view(view, hit)["status"], "done")
        self.assertEqual(self.node_view(view, miss)["status"], "skipped")


class TestParallelAndMerge(OrchestrationBase):
    """Phase 4B: real concurrent branches with a fan-in."""

    def test_parallel_branches_both_run_and_merge_collects_them(self):
        start = _node("tool", "Start", tool="echo", args_text='{"text": "go"}')
        par = _node("parallel", "Fan out", mode="all")
        left = _node("tool", "Left", tool="slow_a", output_key="left_result")
        right = _node("tool", "Right", tool="slow_b", output_key="right_result")
        merge = _node("merge", "Join", strategy="object",
                      keys_text="left_result,right_result")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("parallel", [start, par, left, right, merge, out],
                       [_edge(start, par), _edge(par, left), _edge(par, right),
                        _edge(left, merge), _edge(right, merge), _edge(merge, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual(self.node_view(view, left)["status"], "done")
        self.assertEqual(self.node_view(view, right)["status"], "done")
        payload = json.loads(self.node_view(view, merge)["output"])
        self.assertEqual(payload.get("left_result"), "branch-A-done")
        self.assertEqual(payload.get("right_result"), "branch-B-done")

    def test_validate_refuses_a_parallel_branch_with_an_unbound_tool(self):
        start = _node("tool", "Start", tool="echo", args_text='{"text": "go"}')
        par = _node("parallel", "Fan out", mode="all")
        bad = _node("tool", "Bad tool", tool="missing_tool")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("parallel-fail", [start, par, bad, out],
                       [_edge(start, par), _edge(par, bad), _edge(bad, out)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("not in the live registry" in e for e in report["errors"]))


class TestValidatorAndLoop(OrchestrationBase):
    """Phase 4H / 4J: assertion plus a bounded evaluator-optimizer loop."""

    def test_validator_fails_the_branch_when_the_assertion_is_false(self):
        src = _node("tool", "Src", tool="echo", args_text='{"text": "short"}',
                    output_key="text_value")
        check = _node("validator", "Long enough?", expression="text_value contains zz",
                      on_fail="fail", message="too short")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("validator", [src, check, out],
                       [_edge(src, check), _edge(check, out)])
        view = self.run_flow(agent)
        self.assertEqual(self.node_view(view, check)["status"], "failed")
        self.assertEqual(self.node_view(view, check)["output"], "too short")
        self.assertEqual(self.node_view(view, out)["status"], "skipped")

    def test_validator_routes_to_a_repair_branch(self):
        src = _node("tool", "Src", tool="echo", args_text='{"text": "short"}',
                    output_key="text_value")
        check = _node("validator", "Long enough?", expression="text_value contains zz",
                      on_fail="route", message="needs repair")
        repair = _node("tool", "Repair", tool="slow_b")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("validator-route", [src, check, repair, out],
                       [_edge(src, check), _edge(check, repair, branch="invalid"),
                        _edge(repair, out)])
        view = self.run_flow(agent)
        self.assertEqual(self.node_view(view, check)["status"], "done")
        self.assertEqual(self.node_view(view, repair)["status"], "done")

    def test_evaluator_scores_through_the_injected_llm_and_publishes_it(self):
        gen = _node("model", "Draft", model="test-model",
                    prompt="Write one line.", output_key="draft")
        judge = _node("evaluator", "Judge", criteria="is a real sentence",
                      threshold=7, subject_key="draft", score_key="score")
        out = _node("output", "Final", template="score={{score}}")
        agent = _agent("eval-loop", [gen, judge, out],
                       [_edge(gen, judge), _edge(judge, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertIn("score 9.0/10", self.node_view(view, judge)["output"])
        self.assertIn("score", view.get("context_keys") or [])

    def test_loop_repeats_its_body_a_bounded_number_of_times(self):
        start = _node("tool", "Start", tool="echo", args_text='{"text": "seed"}')
        body = _node("transform", "Refine", mode="template",
                     template="pass-{{iteration}}")
        loop = _node("loop", "Refine loop", body_text=body["id"], max_iterations=3)
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("loop", [start, body, loop, out],
                       [_edge(start, loop), _edge(loop, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertIn("loop ran 3/3 pass(es)", self.node_view(view, loop)["output"])


class TestMemoryCheckpointAndError(OrchestrationBase):
    """Phase 4K / 4L / Phase 14: state, resume points and honest failure."""

    def test_memory_node_stores_and_reads_workflow_state(self):
        start = _node("tool", "Start", tool="echo", args_text='{"text": "seed"}')
        store = _node("memory", "Remember", op="set", key="topic", value="{{last}}")
        load = _node("memory", "Recall", op="get", key="topic")
        out = _node("output", "Final", template="TOPIC:{{last}}")
        agent = _agent("memory", [start, store, load, out],
                       [_edge(start, store), _edge(store, load), _edge(load, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual(view["result"], "TOPIC:echo:seed")
        self.assertEqual((view.get("memory") or {}).get("topic"), "echo:seed")

    def test_checkpoint_is_persisted_into_the_run(self):
        start = _node("tool", "Start", tool="echo", args_text='{"text": "seed"}')
        cp = _node("checkpoint", "Midpoint", label="after-start")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("checkpoint", [start, cp, out],
                       [_edge(start, cp), _edge(cp, out)])
        view = self.run_flow(agent)
        self.assertEqual(view["status"], "done", view.get("reason"))
        saved = AF._read_run().get("checkpoints") or {}
        self.assertIn("after-start", saved)
        self.assertIn("last", saved["after-start"]["context"])

    def test_error_node_publishes_a_structured_fallback_payload(self):
        rescue = _node("error", "Fallback", message="worker unavailable")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("fallback", [rescue, out], [_edge(rescue, out)])
        view = self.run_flow(agent)
        payload = json.loads(self.node_view(view, rescue)["output"])
        self.assertFalse(payload["ok"])
        self.assertTrue(payload["fallback"])
        self.assertEqual(payload["reason"], "worker unavailable")


class TestNestedWorkflow(OrchestrationBase):
    """Phase 4G: one saved flow used as a capability of another."""

    def test_workflow_node_executes_a_real_saved_sub_agent(self):
        inner_tool = _node("tool", "Inner tool", tool="tts_speak",
                           args_text='{"text": "{{input}}"}')
        inner_out = _node("output", "Inner result", template="{{last}}")
        inner = _agent("inner-tts", [inner_tool, inner_out],
                       [_edge(inner_tool, inner_out)])
        ok_saved, inner_stored = AF.create_agent(inner)
        self.assertTrue(ok_saved, inner_stored)

        start = _node("tool", "Start", tool="echo", args_text='{"text": "hello"}')
        nested = _node("workflow", "Call inner", agent_id=inner_stored["id"],
                       input_key="last")
        out = _node("output", "Final", template="{{last}}")
        outer = _agent("outer", [start, nested, out],
                       [_edge(start, nested), _edge(nested, out)])
        self.assertTrue(AF.validate(outer)["ok"], AF.validate(outer)["errors"])
        view = self.run_flow(outer)
        self.assertEqual(view["status"], "done", view.get("reason"))
        # The nested run really invoked the registered TTS-shaped tool.
        self.assertIn("tts_speak", [c[0] for c in self.registry.calls])
        self.assertIn("audio.mp3", view["result"])

    def test_workflow_node_target_is_validated_before_running(self):
        # A nested agent that does not exist is caught by validate() BEFORE the
        # run starts, not halfway through with a vague error.
        start = _node("tool", "Start", tool="echo", args_text='{"text": "x"}')
        nested = _node("workflow", "Call ghost", agent_id="ag_does_not_exist")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("outer-ghost", [start, nested, out],
                       [_edge(start, nested), _edge(nested, out)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("no saved agent" in e for e in report["errors"]))
        # And run_agent() therefore refuses rather than half-executing.
        ok_saved, stored = AF.create_agent(agent)
        self.assertTrue(ok_saved, stored)
        started, message = AF.run_agent(stored["id"], "hello")
        self.assertFalse(started)
        self.assertIn("cannot run", message)


class TestCatalogAndValidation(OrchestrationBase):
    """Phase 7 / Phase 17: the registry invariant and honest refusals."""

    def test_catalog_advertises_every_new_node_type(self):
        cat = AF.catalog()
        for required in ("router", "parallel", "merge", "loop", "validator",
                         "evaluator", "memory", "transform", "http", "workflow",
                         "error", "checkpoint"):
            self.assertIn(required, cat["node_types"])
        names = {t["name"] for t in cat["tools"]}
        self.assertIn("echo", names)
        self.assertNotIn("definitely_not_a_tool", names)

    def test_validate_rejects_an_unbound_tool_node(self):
        node = _node("tool", "Ghost tool", tool="not_registered_anywhere")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("bad", [node, out], [_edge(node, out)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("not in the live registry" in e for e in report["errors"]))

    def test_http_node_is_locked_without_an_allowed_host(self):
        # The allowlist is enforced in validate(), so an unlocked http node can
        # never reach the network at all.
        node = _node("http", "Fetch", url="https://example.com/data",
                     allow_hosts_text="")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("http-locked", [node, out], [_edge(node, out)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("allowed host" in e for e in report["errors"]))

    def test_http_node_refuses_a_host_outside_the_allowlist(self):
        node = _node("http", "Fetch", url="https://evil.example/data",
                     allow_hosts_text="api.trusted.com")
        out = _node("output", "Final", template="{{last}}")
        agent = _agent("http-guard", [node, out], [_edge(node, out)])
        entry = self.node_view(self.run_flow(agent), node)
        self.assertEqual(entry["status"], "failed")
        self.assertIn("not in the allowed host list", entry["output"])


if __name__ == "__main__":
    unittest.main()
