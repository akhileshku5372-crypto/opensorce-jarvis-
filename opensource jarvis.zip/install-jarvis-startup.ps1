# Adds (or removes with -Remove) a Windows-startup entry that silently boots
# start-jarvis.ps1 at every login, so JARVIS wakes up with the machine.
param([switch]$Remove)

$startup = [Environment]::GetFolderPath('Startup')
$link = Join-Path $startup 'JARVIS Background.lnk'

if ($Remove) {
    if (Test-Path $link) { Remove-Item $link -Force; Write-Host "Removed startup entry." }
    else { Write-Host "No startup entry found." }
    exit
}

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($link)
$shortcut.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSScriptRoot\start-jarvis.ps1`" -Float"
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Description = 'Start JARVIS background assistant at login'
$shortcut.Save()
Write-Host "Installed: $link"
Write-Host 'JARVIS will now start automatically when you log into Windows.'