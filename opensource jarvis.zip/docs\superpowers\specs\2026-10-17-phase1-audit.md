# Phase 1 audit — what is actually working, proved 2026-10-17

**Method:** live browser on `http://127.0.0.1:7777`, live registry from
`GET http://127.0.0.1:7780/extensions`, and reading the code paths each claim depends on.
The blueprint marks Phase 1 as ✅ complete. **It is not.**

## Blueprint Phase 1 vs reality

| Blueprint claim | Verdict | Evidence |
|---|---|---|
| 1.1 Agent-S screen grounding + coordinate clicker | **PARTIAL** | `background/screen_agent.py` (1,243 LOC) registers `gui_locate_and_click`, `gui_type_into`, `gui_read_screen_region`, gated by the confirm engine. Voice line 2033 says "Only Sir's explicit voice command runs screen" - it exists but is not reachable in normal conversation |
| 1.2 PowerPoint builder | **PARTIAL / UNLISTED** | `background/presentation_builder.py` exists, tools registered in the plugin, `tests/test_presentation_builder.py` passes. But **the Modules page has no card for it** (`capability_registry.py` contains no `presentation-builder` id), so the "single source of truth" cannot report it |
| 1.3 Bi-directional WhatsApp | **MOSTLY NOT** | see the three failures below |
| 1.4 Floating HUD + `Ctrl+Shift+J` | **HOLDS UP** | `floating_ui.pyw` runs and the HUD spawns. My earlier claim that it "ships a fake panel" was **wrong**: `_draw_demo_view` (line 1008) is only reached when `self.view == "demo"`, i.e. after the user clicks the DEMO tab at line 1139, and the panel labels itself "CONCEPT RAIL • DEMO ONLY". Opt-in, self-labelled concept preview - not the "fake demo turns" pattern AGENTS.md forbids. No change made. |
| 1.5 Communication confirmation gate | **WORKS** | `extensions/permissions.json` = `{"communication": "ask"}`, and the send path is confirm-gated. This is the one claim that held up under testing |

## The three WhatsApp complaints, each traced to a cause

### (1) "group me Vishesh ko tag karke xyz message bhej do" → does nothing
Two independent gaps, one upstream of the other:

- **The router cannot parse it.** `_extract_whatsapp_request`
  ([voice_engine.py:6586](../background/voice_engine.py)) is deterministic regex only
  ("Deterministic only.", line 6586) and every pattern has the shape
  `<contact> ko whatsapp pe <message>` / `send message to <contact>`. No pattern accepts a
  *group* noun or a "…ko tag karke" clause, so the sentence returns `None` and falls to the
  AI - which must never execute anything (AGENTS.md). Net effect: nothing happens.
- **The capability does not exist downstream.** `whatsapp_web.send_message(contact, text)`
  ([whatsapp_web.py:322](../background/whatsapp_web.py)) takes exactly two arguments. There is
  no group parameter, and grep for `group|mention|@|tag` in `whatsapp_web.py` returns
  **zero** mentions-handling code. To @-tag in a group you must type `@`, wait for the
  mention picker, and click a row - none of that is implemented.

So this can never work by fixing the regex alone. It needs (a) group addressing and (b) a
mention flow, then (c) parser patterns for the Hindi/Hinglish word orders people actually speak.

### (2) Wrong-chat risk while we are here
`_open_chat` ([whatsapp_web.py:264](../background/whatsapp_web.py)) types the name into
WhatsApp's search box and **clicks the first result**, with no check that the opened chat is
the requested one. WhatsApp search mixes contacts, groups, and messages, so "General" can
open the wrong chat. `send_message` verifies a bubble appeared (good - no phantom send) but
verifies the *send*, not the *recipient*. A name/title assertion after opening is required
before any group send is trusted.

### (3) "abhi-abhi copy hui photo bhej do" → cannot
No clipboard-image path exists anywhere: grep for `ImageGrab`, `clipboard.*image`,
`send_image`, `attach` across `whatsapp_web.py`, `whatsapp_sender.py` and
`extensions/plugins/jarvis-modules/plugin.py` returns **nothing**. WhatsApp Web needs the
attach menu (or a paste into the composer) - unimplemented. Also no PIL/mss → temp-file
bridge from the clipboard.

### (4) "WhatsApp khud kholta hai par koi detail nahi deta"
`whatsapp_web_status`, `whatsapp_web_unread` and `whatsapp_web_read` exist as *tools*, but the
voice router's WhatsApp branch only implements the send path; after opening the app it reads
nothing back and says nothing. So the ask "whatsapp kholo aur batao" produces silence, not
because STT failed, but because no report step is wired to the open action.

## Defects found in the running dashboard (browser, 2026-10-17)

Opened `http://127.0.0.1:7777/` in a real browser - title `JARVIS — AI Command Center`,
orb renders (`[JARVIS Brain] 3D Neural Holo READY: 4200pts, 8 centroids, 36 pulses`).
Console, from one idle page load:

1. **`http://127.0.0.1:5678/healthz` → `ERR_CONNECTION_REFUSED`, retried every 8 seconds
   forever.** n8n is not running (this is why `n8n-hooks` probes BLOCKED), and the UI polls it
   unbounded. Dozens of identical errors per minute - it buries real errors in noise.
2. **`GET /api/kamisensei/files` → 503** and `[KS] Source list fetch failed: The local source
   registry is unavailable.` (`app.js:6899`, reported at `app.js:6918`) - a live panel with a
   broken backend.
3. **`POST http://127.0.0.1:7780/conversations/delete` → 400 Bad Request**, twice, without any
   click from me. A delete call is being sent with a body the core rejects.
4. `THREE.Clock is deprecated` warning (cosmetic).

## Agent-S and Playwright, in plain words

These two are constantly confused, so:

- **Playwright = a robot that uses the *browser*.** It knows the page's real structure:
  buttons, inputs, message lists. JARVIS uses it for **WhatsApp Web only** - it drives a
  persistent Chromium profile (`PROFILE_DIR`), searches a chat, types, sends, and re-reads the
  DOM to confirm the bubble appeared. Use Playwright whenever the target is a website/app
  inside a browser tab, because it can *verify* what it did.
- **Agent-S (`screen_agent.py`) = a robot that uses the *whole screen*.** It screenshots the
  desktop, asks a vision model "where is the Save button", gets back x/y, and clicks through
  the OS bridge. Nothing about the target page is known. Use it only for **desktop apps that
  have no browser and no API** (Notepad, Excel, Photoshop). It is slower, costs a vision call
  per step, and mis-clicks - which is exactly why it sits behind the confirmation gate.

Rule of thumb for him: **browser → Playwright, desktop app → Agent-S, anything with a real
API → neither; write a tool for the API.** When he says "kya kaise use karun", the honest
answer is that he should not have to choose - the router should pick by target, and today
`gui_*` tools are only reachable by explicit command.

## CORRECTION after this audit: WhatsApp Web is the wrong target for this machine

Checked what is actually installed:

- `Get-AppxPackage *hatsapp*` → **`5319275A.WhatsAppDesktop` v2.2640.100.0** (the Windows
  Store app). No classic `whatsapp.exe` App Paths entry.
- The user has **no WhatsApp Web usage** and does not want it.
- `background/whatsapp_web.py` drives `web.whatsapp.com` through a Playwright Chromium
  profile that needs its own QR-linked session. On this machine that whole module is
  therefore **unusable by design**, not broken-by-bug. Its `whatsapp_web_*` tools should
  report that honestly instead of sitting in the registry as if they were live.
- What does exist for desktop: `background/whatsapp_sender.py` opens a
  `whatsapp://send` deep link and verifies with a real foreground-window check
  (`_window_is_whatsapp`, ctypes `GetForegroundWindow`). A deep link can only **pre-fill**
  text - it cannot pick a group, cannot @mention, cannot press send, and cannot read
  anything back. That is precisely the "opens WhatsApp but tells me nothing" complaint.
- No Windows UI Automation library is installed: `pywinauto`, `uiautomation`, `comtypes`,
  `pywin32` all absent. Only `pyautogui`, `PIL`, `psutil`.

### CORRECTED by the follow-up probe — the open-chat check IS possible

My first read-only pass reported "no element names the opened chat". **That was wrong**, and
the correction is what makes a desktop driver safe. `scratch/whatsapp_header_probe.py`
(also click-free) found in the header band:

```
Button  'Comfort zone Akhilesh, Kushagra, Vivek, You'      <- group name + member list
Button  'Vivek Gautam (Ballu)'
Button  'Open chat details for Vivek Gautam (Ballu)'       <- @mention chips are named Buttons
TabItem 'Unread 7'      Text '7'                           <- unread count is readable
Edit    '\n'  rect=(1478,864)                              <- the composer (the only unnamed Edit)
Button  'Attach'                                           <- photo/document attach
DataItem 'Study In Japan 1:15 pm 1 unread message General ~Shayan Bera : 😂 😂'
DataItem 'Vishesh Yesterday then levi launcher open karlo …'
```

So every piece the user asked for is addressable: **pick a group, verify the opened chat
against the requested name, @mention a member, attach/paste an image, and report unread
counts back to him.**

**One real limit, so this is not oversold:** in-thread message *bodies* are not exposed as
UIA text - the Chromium root's `texts()` returns only the window title `(7) WhatsApp`.
What is readable is the chat-list preview (title + time + last-message snippet) and the
unread count. So "WhatsApp kholo aur batao" can honestly answer *which chats have unread and
what the last message preview says*, not "read me this whole thread". Full-thread reading
would need a different mechanism and is not promised.

**Implementation notes this forces:**
- Match on **name + control type + rectangle**, never on automation_id (`_r_e_` is generated).
- The composer is the only `Edit` whose name is blank/whitespace and whose rect sits in the
  bottom band; `Search or start a new chat` is the other `Edit` - never type into that one.
- `DataItem.invoke()` raises `NoPatternInterfaceError`; `click_input()` works.
- Dedupe by `runtime_id` (every element is mirrored ~3x by the two WebView panes).
- Chat names contain emoji and `\xa0` - normalise whitespace and force UTF-8 on stdout
  (the first spike run crashed on an emoji in a chat name).


### Spike, first pass (2026-10-17): the app is addressable at all

`pip install pywinauto` added `pywinauto 0.6.9` + `comtypes 1.4.17` + `pywin32 312` to
`.venv` (recorded in `requirements.txt`). `scratch/whatsapp_uia_spike.py` is read-only: it
lists windows and prints the tree, it never clicks or types.

- Window: `WhatsApp.Root.exe` pid 28208, class `WinUIDesktopWin32WindowClass`. The real UI
  renders inside **`msedgewebview2.exe`** (WebView2/Chromium), window title `(6) WhatsApp`
  - the `(6)` is the live unread count.
- The process runs with **no window** until launched:
  `explorer.exe shell:AppsFolder\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App`.
- Addressable elements found:

| Need | UIA element |
|---|---|
| Search a chat/group | `Edit` name=`Search or start a new chat`, automation_id `_r_e_` |
| Chat list | `DataGrid` name=`Chat list` → `DataItem` rows |
| **Read-back** | Row names already carry title + time + last message, e.g. `Comfort zone 1:03 pm You: You deleted this`, `1 unread message +91 80 4807 7722 Yesterday` |
| Buttons | `New chat`, `Send document`, `Add contact`, `Resize the chat list panel`, tab `chat-list-filters` |

- **Caveat that will bite a naive implementation:** every element appears **three times** in
  the tree (two mirrored WebView panes + the shell). Selection must be deduplicated by
  `runtime_id`, or a "click the first match" loop acts three times.
- Not yet observed: the composer (`Type a message`), the `Send` button and the `@mention`
  popup, because **no chat was open** during the dump. Opening one is the remaining spike
  step, and it has a side effect (it can mark messages read), so it needs the user's pick of
  a safe chat.
- Automation ids are unstable (`_r_e_` looks generated); match on **name + control type**,
  not on id.


### Revised Phase 1 order (desktop app, no browser) - status as of this session

| # | Item | Status |
|---|---|---|
| 0 | UIA spike | **DONE** - composer, `Attach`, `@mention` chips and the chat header were all found once a chat was opened |
| 1 | `whatsapp_desktop.py`: search → **verify the opened chat** → act | **DONE + wired.** `autosend_to`'s name path now goes through it; the 104-line blind Ctrl+F sequence is deleted. 17 driver tests |
| 2 | Group addressing + send with proof | **BUILT, not live-tested.** Proof = chat-list preview shows the message; refuses to claim success without it |
| 3 | `@mention` | **BUILT, not live-tested** (`_pick_mention` clicks the member row after `@`) |
| 4 | Clipboard image → send | **NOT DONE.** Only verified `PIL.ImageGrab.grabclipboard()` works on this machine, so no new dependency is needed |
| 5 | Read-back ("kholo aur batao") | **PARTIAL** - `unread_summary()` exists, not yet exposed as a tool or reachable by voice |
| 6 | Hindi/Hinglish router patterns ("group me … ko tag karke … bhej do") | **NOT DONE.** `_extract_whatsapp_request` (voice_engine.py:6586) still parses only `<name> ko whatsapp pe <msg>` shapes |
| 7 | Dashboard noise | **1 of 3 done and measured:** n8n `/healthz` errors went from ~5 per 45s to one per 60s (timestamps 1.3s / 61.3s / 121.3s). Still open: `conversations/delete` 400, KamiSensei `/api/kamisensei/files` 503 |
| 8 | Honesty pass | **Cards DONE:** `presentation-builder` + `proactive-sentinel` added (catalog = 52 rows) and `_module_available()` fixed - it only looked at `background/<name>.py`, so it denied that torch and python-pptx are installed while they are. **HUD claim retracted:** `_draw_demo_view` only renders behind the DEMO tab and labels itself DEMO ONLY, so it is not the forbidden fake pattern. Still open: marking `whatsapp_web_*` tools not-applicable on this machine |

Also fixed while getting the suites green: `resolve_contact` matched a **blank**
recipient to the only saved contact (`"" in "akhilesh"` is True), so an empty
recipient resolved to a real person's number. And `test_modules` pinned the card
count to exactly 50, which is how AGENTS.md drifted to "48"; it is now a floor
plus the invariant that the snapshot total equals the catalog length.

