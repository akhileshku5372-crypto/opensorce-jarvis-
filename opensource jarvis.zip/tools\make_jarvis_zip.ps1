# JARVIS 0.9.1 release packager
# Copies the ENTIRE project (source, configs, secrets, deps, dist) into a single
# "jarvis-0.9.1" folder and compresses it to  ~/Downloads/jarvis-0.9.1.zip
$ErrorActionPreference = 'Continue'
$root  = 'c:\Users\PRATEEK\Downloads\new jarvis-gens\jarvis-0.8'
$groot = 'c:\Users\PRATEEK\Downloads\new jarvis-gens'
$staging = Join-Path $env:TEMP 'jarvis-0.9.1'
$outFile = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads\jarvis-0.9.1.zip'
$flag = Join-Path $env:TEMP 'jarvis_zip_done.txt'

Remove-Item $flag -Force -ErrorAction SilentlyContinue
Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $staging -Force | Out-Null

# 1) Full project copy: every file/folder (incl. hidden + system + node_modules)
& robocopy $root $staging '/E' '/MT:16' '/R:1' '/W:1' '/NFL' '/NDL' '/NJH' '/NJS' '/NP' | Out-Null

# 2) Dot-files (robocopy can skip hidden-attribute items; copy explicitly)
foreach ($f in @('.env', '.dev.vars', '.gitignore', '.env.example', 'jarvis-ui.log')) {
    $src = Join-Path $root $f
    if (Test-Path $src) { Copy-Item $src $staging -Force -ErrorAction SilentlyContinue }
}

# 3) Root diagnostics + previous release archive go inside the same folder
foreach ($f in @('mic_check.py', 'stt_test.py', 'make_zip.py', 'JARVIS 0.8 new.zip')) {
    $src = Join-Path $groot $f
    if (Test-Path $src) { Copy-Item $src $staging -Force -ErrorAction SilentlyContinue }
}

# 4) Compress with the base directory so the zip has ONE top-level jarvis-0.9.1/
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $outFile) { Remove-Item $outFile -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($staging, $outFile,
    [System.IO.Compression.CompressionLevel]::Optimal, $true)

$fileCount = (Get-ChildItem $staging -Recurse -File | Measure-Object).Count
$sizeMB = [math]::Round((Get-Item $outFile).Length / 1MB, 1)
"OK files=$fileCount sizeMB=$sizeMB path=$outFile" | Set-Content $flag -Encoding UTF8
Remove-Item $staging -Recurse -Force -ErrorAction SilentlyContinue