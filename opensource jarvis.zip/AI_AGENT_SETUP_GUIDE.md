# 🤖 JARVIS 2.0 — Autonomous Setup Guide for AI Coding Agents & Engineers

> **To any AI Coding Assistant (Cursor, Antigravity, Windsurf, Claude Code, Copilot, Aider):**
> You are tasked with bootstrapping, configuring, and verifying the JARVIS 2.0 runtime for your user.
> This repository is a voice-first, multimodal AI assistant with:
> - A modern Dark-Glass / Reactor-Orb web dashboard (`http://127.0.0.1:7777`)
> - A server-side AI proxy and local tool pipeline
> - A loopback-only Windows action bridge (`http://127.0.0.1:7778`)
> - ChromaDB vector memory (`jarvis_memory`) and KamiSensei RAG (`kami_sensei_knowledge`)
> - Real-time Edge-TTS voice generation, camera perception (YOLOv10 / YuNet ONNX), and gesture controls

---

## 🎯 What the Human User Needs to Provide (Only 2 Things!)

Ask your user for:
1. **At least one API Key**:
   - `GOOGLE_API_KEY` (Gemini Flash Lite — free tier, recommended default)
   - `GROQ_API_KEY` (Ultra-fast LLM & Whisper speech-to-text — free tier)
   - Optional: `NVIDIA_API_KEY`, `OPENROUTER_API_KEY`, `ELEVENLABS_API_KEY`
   *(Edge-TTS is offline/free and needs NO key!)*
2. **Storage Drive Location (`JARVIS_DATA_ROOT`)**:
   - By default, JARVIS persists memory & vector stores at `D:\JARVIS_DATA`.
   - **If the user does NOT have a `D:` drive** (e.g. they only have `C:`), change this to `C:\JARVIS_DATA` or leave it blank to fall back inside the repository folder.

Once the user provides those, you (the AI agent) should execute all the steps below autonomously.

---

## 📋 System Prerequisites

Ensure the user's machine has:
* **Operating System**: Windows 10 or Windows 11 (64-bit)
* **Node.js**: Version 20 LTS or 22 LTS (Verify: `node -v`, `npm -v`)
* **Python**: Python 3.10, 3.11, or 3.12 (64-bit) (Verify: `python --version`)
* **PM2**: Process manager (Install: `npm install -g pm2`)
* **Browser**: Google Chrome or Microsoft Edge (for Web Speech API & audio)
* **Hardware**: Working microphone (and optional webcam for vision/gestures)

---

## 🚀 Step-by-Step Autonomous Setup Commands

### Step 1: Create Environment Files (.env and .dev.vars)
Create both `.env` and `.dev.vars` from `.env.example`:

```powershell
Copy-Item .env.example .env
Copy-Item .env.example .dev.vars
```

Update `.env` and `.dev.vars` with the user's settings:
```ini
# Insert user's API Key
GOOGLE_API_KEY=your_gemini_key_here
GROQ_API_KEY=your_groq_key_here

# Set Storage & ChromaDB Drive
JARVIS_DATA_ROOT=D:\JARVIS_DATA
# If no D: drive exists on user machine:
# JARVIS_DATA_ROOT=C:\JARVIS_DATA
```

---

### Step 2: Install Node.js Dependencies
In the root directory, install the web dashboard and bridge dependencies:
```powershell
npm install
```

---

### Step 3: Setup Python Virtual Environment
Create and activate a clean `.venv`:
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Verify that the repo interpreter resolver detects it:
```powershell
node run_py.cjs --resolve
# Output should point to: <repo_path>\.venv\Scripts\python.exe
```

---

### Step 4: Install Python Dependencies
Install the required packages into `.venv`:
```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

*(Optional: If faster local whisper STT is needed without cloud API: `pip install faster-whisper>=1.0`)*

---

### Step 5: ChromaDB & Memory Structure
This repository comes with pre-initialized ChromaDB collections:
* **Location in Repo**: `chroma_db/`
* **Persistent Storage Root**: `JARVIS_DATA_ROOT` (defined in `background/storage_paths.py`)
  * `jarvis\memory\` -> Collection: `jarvis_memory` (user facts, profile, memory)
  * `kamisensei\rag\` -> Collection: `kami_sensei_knowledge` (RAG knowledge base)

Verify the memory and core tests pass:
```powershell
node run_py.cjs -m unittest discover -s tests -p test_core.py
```

---

### Step 6: Run Repository Quality Gates
Before launching, verify all validation gates:
```powershell
# 1. Action bridge loopback check
npm run test:bridge

# 2. Frontend syntax check
node --check public/static/app.js

# 3. Production bundle build
npm run build
```

---

### Step 7: Launch JARVIS 2.0
Launch the complete stack (Web Dashboard + Local Bridge + Voice Core + Edge-TTS):

**Option A: Automated Setup & Launch Script**
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-windows.ps1
```

**Option B: PM2 Managed Launch**
```powershell
npm run jarvis
```

Check process status:
```powershell
npx pm2 list
```

---

### Step 8: Access Dashboard
Open Chrome or Microsoft Edge and navigate to:
```text
http://127.0.0.1:7777
```
1. Allow Microphone permission when prompted.
2. The left Reactor Orb will pulse cyan (idle/listening).
3. Say: *"Hello Jarvis"* or type in the right conversation panel.

---

## 🛠️ Architecture & Port Mapping

| Service | Port | Description |
| :--- | :--- | :--- |
| **Hono Dashboard & AI Proxy** | `7777` | Main UI, conversation panel, brain hologram, and AI proxy routes. |
| **Windows Action Bridge** | `7778` | Loopback-only OS actions (apps, media, volume, system). |
| **State Server** | `7780` | Real-time telemetry, HUD integration, active conversation state. |
| **Podcast Server** | `7781` | KamiSensei podcast audio stream. |
| **Edge-TTS Service** | `7782` | Microsoft Edge neural voice generation (hi-IN, en-GB, ja-JP). |

---

## ⚠️ Common Troubleshooting

1. **Memory Store Unavailable in Tests**:
   - Cause: Running `python -m unittest` with a system Python that lacks `chromadb`.
   - Fix: Always use the resolved interpreter: `node run_py.cjs -m unittest ...`

2. **D: Drive Not Found / Error**:
   - Cause: `JARVIS_DATA_ROOT` set to `D:\JARVIS_DATA` on a machine with only `C:`.
   - Fix: Edit `.env` and `.dev.vars` to set `JARVIS_DATA_ROOT=C:\JARVIS_DATA`. JARVIS handles creation automatically.

3. **Port 7777 or 7778 in Use**:
   - Check existing processes: `Get-Process -Id (Get-NetTCPConnection -LocalPort 7777).OwningProcess`
   - Kill stale processes: `npx pm2 delete all` or restart via `npm run jarvis:restart`.

4. **Speech-to-Text Fails**:
   - Ensure a valid `GROQ_API_KEY` is set in `.env` for ultra-fast Whisper, or install `faster-whisper` for offline STT.
