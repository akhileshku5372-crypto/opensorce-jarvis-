// Pure Web Audio API Synthesizer for Brain Relaxation, Active Study Focus (Binaural Beats + Warm Ambient Pad + Soft Rain), and Tactile UI Sounds.
// Requires ZERO external API keys and ZERO external audio files — works 100% offline inside any ZIP / Python WebView / Browser.

export type BrainSoundPreset = 'alpha-flow' | 'gamma-focus' | 'zen-sanctuary' | 'smr-study';

export interface BrainPresetInfo {
  id: BrainSoundPreset;
  name: string;
  subtitle: string;
  baseFreq: number;
  beatFreq: number;
  padFreqs: number[];
  rainGain: number;
}

export const BRAIN_SOUND_PRESETS: BrainPresetInfo[] = [
  {
    id: 'alpha-flow',
    name: 'Alpha Flow (10 Hz) · Calm Study',
    subtitle: 'Relaxes the mind while keeping reading focus effortlessly sharp',
    baseFreq: 200,
    beatFreq: 10, // 10 Hz Alpha wave for relaxed alertness
    padFreqs: [130.81, 196.0, 246.94, 293.66], // Warm Cmaj9 ambient chord
    rainGain: 0.035,
  },
  {
    id: 'gamma-focus',
    name: 'Gamma Active (40 Hz) · Deep Logic',
    subtitle: 'Boosts cognitive binding, coding focus & problem-solving clarity',
    baseFreq: 216,
    beatFreq: 40, // 40 Hz Gamma wave for active cognition
    padFreqs: [146.83, 220.0, 261.63, 329.63], // Dm9 focus harmonic pad
    rainGain: 0.025,
  },
  {
    id: 'zen-sanctuary',
    name: '432 Hz Sanctuary · Stress Relief',
    subtitle: 'Deep parasympathetic relaxation with gentle atrium rain',
    baseFreq: 144,
    beatFreq: 6.5, // Theta/Alpha border for stress dissolution
    padFreqs: [108.0, 162.0, 216.0, 270.0], // 432Hz harmonic overtones
    rainGain: 0.05,
  },
  {
    id: 'smr-study',
    name: 'Beta SMR (14 Hz) · Memory Lock',
    subtitle: 'Sensorimotor rhythm for long-session reading & retention',
    baseFreq: 180,
    beatFreq: 14, // 14 Hz SMR wave
    padFreqs: [110.0, 164.81, 220.0, 277.18], // Warm A major 7th pad
    rainGain: 0.03,
  },
];

class JarvisBrainAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private masterGain: GainNode | null = null;
  private activeNodes: AudioNode[] = [];
  private lfoTimer: number | null = null;
  private currentPreset: BrainSoundPreset = 'alpha-flow';
  private volume = 0.45;

  private ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public startStudySound(presetId: BrainSoundPreset = this.currentPreset, vol = this.volume) {
    this.stopStudySound();
    this.currentPreset = presetId;
    this.volume = vol;

    const ctx = this.ensureContext();
    const preset =
      BRAIN_SOUND_PRESETS.find((p) => p.id === presetId) || BRAIN_SOUND_PRESETS[0];

    const master = ctx.createGain();
    master.gain.setValueAtTime(0.001, ctx.currentTime);
    master.gain.exponentialRampToValueAtTime(Math.max(0.02, this.volume * 0.35), ctx.currentTime + 1.2);
    master.connect(ctx.destination);
    this.masterGain = master;

    // 1. Left & Right Ear Binaural Oscillators (Stereo Panned)
    const leftOsc = ctx.createOscillator();
    const rightOsc = ctx.createOscillator();
    const leftPan = ctx.createStereoPanner();
    const rightPan = ctx.createStereoPanner();
    const binauralGain = ctx.createGain();

    leftOsc.type = 'sine';
    rightOsc.type = 'sine';
    leftOsc.frequency.setValueAtTime(preset.baseFreq, ctx.currentTime);
    rightOsc.frequency.setValueAtTime(preset.baseFreq + preset.beatFreq, ctx.currentTime);

    leftPan.pan.setValueAtTime(-0.8, ctx.currentTime);
    rightPan.pan.setValueAtTime(0.8, ctx.currentTime);
    binauralGain.gain.setValueAtTime(0.18, ctx.currentTime);

    leftOsc.connect(leftPan);
    rightOsc.connect(rightPan);
    leftPan.connect(binauralGain);
    rightPan.connect(binauralGain);
    binauralGain.connect(master);

    leftOsc.start();
    rightOsc.start();
    this.activeNodes.push(leftOsc, rightOsc, leftPan, rightPan, binauralGain);

    // 2. Warm Breathing Ambient Pad Chord
    const padFilter = ctx.createBiquadFilter();
    padFilter.type = 'lowpass';
    padFilter.frequency.setValueAtTime(420, ctx.currentTime);
    padFilter.connect(master);
    this.activeNodes.push(padFilter);

    preset.padFreqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      // Slight detune for warm chorus lushness
      osc.detune.setValueAtTime((idx - 1.5) * 4, ctx.currentTime);
      gain.gain.setValueAtTime(0.055 / (idx * 0.4 + 1), ctx.currentTime);

      osc.connect(gain);
      gain.connect(padFilter);
      osc.start();
      this.activeNodes.push(osc, gain);
    });

    // 3. Soft Pink/Brown Atrium Rain Texture (Soothing high-cut filtered noise)
    const bufferSize = ctx.sampleRate * 3;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      output[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = output[i];
      output[i] *= 1.8; // Soft brownian warmth
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const rainFilter = ctx.createBiquadFilter();
    rainFilter.type = 'bandpass';
    rainFilter.frequency.setValueAtTime(650, ctx.currentTime);
    rainFilter.Q.setValueAtTime(0.7, ctx.currentTime);

    const rainGainNode = ctx.createGain();
    rainGainNode.gain.setValueAtTime(preset.rainGain, ctx.currentTime);

    whiteNoise.connect(rainFilter);
    rainFilter.connect(rainGainNode);
    rainGainNode.connect(master);
    whiteNoise.start();
    this.activeNodes.push(whiteNoise, rainFilter, rainGainNode);

    // Slow breathing modulation on the warm pad filter (matches calm 6-second breathing cycle)
    let phase = 0;
    this.lfoTimer = window.setInterval(() => {
      if (!this.ctx || !this.isPlaying) return;
      phase += 0.15;
      const cutoff = 380 + Math.sin(phase) * 140;
      padFilter.frequency.setTargetAtTime(cutoff, this.ctx.currentTime, 0.5);
    }, 300);

    this.isPlaying = true;
  }

  public stopStudySound() {
    if (this.lfoTimer) {
      clearInterval(this.lfoTimer);
      this.lfoTimer = null;
    }
    if (this.ctx && this.masterGain) {
      try {
        this.masterGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.15);
      } catch {
        // Ignore
      }
    }
    const nodesToClean = [...this.activeNodes];
    this.activeNodes = [];
    setTimeout(() => {
      nodesToClean.forEach((n) => {
        try {
          if ('stop' in n && typeof (n as OscillatorNode).stop === 'function') {
            (n as OscillatorNode).stop();
          }
          n.disconnect();
        } catch {
          // Ignore already stopped
        }
      });
    }, 220);
    this.isPlaying = false;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.ctx && this.masterGain && this.isPlaying) {
      this.masterGain.gain.setTargetAtTime(
        Math.max(0.01, this.volume * 0.35),
        this.ctx.currentTime,
        0.1
      );
    }
  }

  public getIsPlaying() {
    return this.isPlaying;
  }

  // Subtle soothing harmonic chime when mounting or clicking a physical book on the shelf
  public playUiChime(kind: 'select' | 'add' | 'mode' = 'select') {
    try {
      const ctx = this.ensureContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';

      const now = ctx.currentTime;
      if (kind === 'add') {
        osc.frequency.setValueAtTime(528, now);
        osc.frequency.exponentialRampToValueAtTime(792, now + 0.18);
      } else if (kind === 'mode') {
        osc.frequency.setValueAtTime(432, now);
        osc.frequency.exponentialRampToValueAtTime(540, now + 0.14);
      } else {
        osc.frequency.setValueAtTime(640, now);
        osc.frequency.exponentialRampToValueAtTime(480, now + 0.12);
      }

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.24);
    } catch {
      // Ignore if audio not yet unlocked
    }
  }
}

export const brainAudio = new JarvisBrainAudioEngine();
