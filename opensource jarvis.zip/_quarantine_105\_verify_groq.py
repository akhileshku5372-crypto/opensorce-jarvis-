# -*- coding: utf-8 -*-
"""_verify_groq.py — live-verify the configured Groq key end-to-end (no secrets printed)."""
import json, os, sys, urllib.request, urllib.error

ROOT = os.path.dirname(os.path.abspath(__file__))
ENV = [os.path.join(ROOT, '.env'), os.path.join(ROOT, '.dev.vars')]
KEY = None
for p in ENV:
    try:
        for line in open(p, encoding='utf-8'):
            line = line.strip()
            if line.startswith('GROQ_API_KEY='):
                KEY = line.split('=', 1)[1]
    except FileNotFoundError:
        continue
print('GROQ_API_KEY present:', bool(KEY), '| len:', len(KEY or ''))

def post(url, payload, key, timeout=25):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={'Authorization': 'Bearer ' + key,
                                          'Content-Type': 'application/json'},
                                 method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read(30000))
    except urllib.error.HTTPError as e:
        body = e.read(2000).decode('utf-8', 'ignore')
        return e.code, body[:300].replace('\n', ' ')
    except Exception as e:
        return None, type(e).__name__ + ' ' + str(e)[:80]

print('\n--- real chat completion with NEW key ---')
st, d = post('https://api.groq.com/openai/v1/chat/completions',
             {'model': 'gpt-oss-120b', 'messages': [{'role': 'user', 'content': 'say ODD'}]},
             KEY)
print('gpt-oss-120b   -> HTTP', st, 'reply:', (d.get('choices') or [{}])[0].get('message', {}).get('content', '') if isinstance(d, dict) else d)

print('\n--- model-list probes with NEW key (status only) ---')
for slug in ('gpt-oss-120b', 'meta-llama/llama-4-scout-17b-16e-instruct',
             'llama-3.3-70b-versatile', 'google/gemini-2.5-flash',
             'google/gemini-2.5-flash-lite', 'openai/gpt-oss-20b'):
    st, d = post('https://api.groq.com/openai/v1/models/' + slug, {}, KEY)
    print('%-38s -> HTTP %s' % (slug, st))

print('\n--- xKiro root probe (schema check) ---')
try:
    with urllib.request.urlopen('https://llm.eqium.com/v1/models', timeout=25) as r:
        body = r.read(300).replace(b'\n', b' ')
        print('https://llm.eqium.com/v1/models -> HTTP', r.status, body[:200])
except Exception as e:
    print('https://llm.eqium.com/v1/models ->', type(e).__name__, str(e)[:100])
