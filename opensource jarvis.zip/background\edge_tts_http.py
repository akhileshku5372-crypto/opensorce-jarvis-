"""Edge-TTS micro-service (port 7782): multilingual MP3 for the browser UI.

The Hono /api/tts proxy tries this service first, so the on-screen chat and
the floating HUD get the same edge-tts voices as the local assistant:
hi-IN-MadhurNeural (Hindi/Hinglish), en-GB-RyanNeural (English),
ja-JP-KeitaNeural (Japanese). The pronunciation fixes are kept in sync with
voice_engine._tts_pronunciation_fix (notebooklm -> "notebook LM").
"""
import asyncio
import io
import json
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import edge_tts

HOST = "127.0.0.1"
PORT = int(os.environ.get("EDGE_TTS_PORT", "7782"))

VOICE_BY_LANG = {
    "hi": "hi-IN-MadhurNeural",
    "hinglish": "hi-IN-MadhurNeural",
    "ja": "ja-JP-KeitaNeural",
    "en": "en-GB-RyanNeural",
}

_PRONOUNCE_MAP = {
    "notebooklm": "notebook LM",
    "notebooklms": "notebook LMs",
    "kamisensei": "Kami Sensei",
    "chatgpt": "chat GPT",
    "openai": "Open A I",
    "github": "git hub",
    "youtube": "you tube",
    "whatsapp": "whats app",
}
_COMMON_WORDS = {
    "notebook", "note", "smart", "super", "code", "data", "tech", "cloud",
    "cyber", "neo", "auto", "multi", "meta", "wiki", "type", "hyper",
}
_BAD_SUFFIXES = {
    "ing", "ed", "er", "es", "ly", "ish", "ous", "ful", "ion", "ies",
    "ate", "ise", "ize", "ify", "ant", "ent", "ary", "ory",
}
_SPLIT_PREFIXES = (
    "notebook", "note", "smart", "super", "hyper", "code", "data", "tech",
    "cloud", "cyber", "neo", "auto", "multi", "meta", "wiki", "type",
)


def _pronounce_fix(text):
    if not text:
        return text

    def _fix_token(m):
        w = m.group(0)
        lw = w.lower()
        if lw in _PRONOUNCE_MAP:
            return _PRONOUNCE_MAP[lw]
        if w.islower() and w.isalpha() and len(w) >= 6:
            if lw in _SPLIT_PREFIXES or lw in _COMMON_WORDS:
                return w
            for plen in range(len(w) - 2, 3, -1):
                suffix = w[plen:]
                if (w[:plen] in _SPLIT_PREFIXES and 2 <= len(suffix) <= 4
                        and suffix.isalpha() and suffix not in _BAD_SUFFIXES):
                    return "%s %s" % (w[:plen], suffix.upper())
        return w

    return re.sub(r"[A-Za-z]{4,}", _fix_token, text)


def _pick_voice(voice, lang):
    v = str(voice or "").strip()
    if v and re.fullmatch(r"[A-Za-z0-9_-]+", v):
        return v
    return VOICE_BY_LANG.get((lang or "").lower(), "hi-IN-MadhurNeural")


async def _synth(text, voice, rate):
    fixed = _pronounce_fix(text)
    comm = edge_tts.Communicate(fixed, voice, rate=rate)
    buf = io.BytesIO()
    async for chunk in comm.stream():
        if chunk["type"] == "audio":
            buf.write(chunk["data"])
    return buf.getvalue()


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.split("?")[0] == "/health":
            self._json(200, {"ok": True, "engine": "edge-tts"})
        else:
            self._json(404, {"error": "not_found"})

    def do_POST(self):
        if self.path.split("?")[0] != "/tts":
            self._json(404, {"error": "not_found"})
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(length) if length else b""
            data = json.loads(body.decode("utf-8", "replace"))
        except Exception:
            self._json(400, {"error": "bad_json"})
            return
        text = str(data.get("text") or "").strip()
        if not text or len(text) > 600:
            self._json(400, {"error": "text_required_or_too_long"})
            return
        voice = _pick_voice(data.get("voice"), data.get("lang"))
        rate = str(data.get("rate") or "+0%")
        if not re.fullmatch(r"[+-]\d+%", rate):
            rate = "+0%"
        try:
            mp3 = asyncio.run(_synth(text, voice, rate))
        except Exception as exc:
            self._json(500, {"error": str(exc)[:200]})
            return
        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Content-Length", str(len(mp3)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(mp3)


if __name__ == "__main__":
    print("edge-tts HTTP listening on %s:%d" % (HOST, PORT), flush=True)
    ThreadingHTTPServer((HOST, PORT), _Handler).serve_forever()
