"""Persistent conversation history (SQLite) for JARVIS and KamiSensei.

This replaces the browser-only history that used to live in
``localStorage['jarvis-chat-sessions']`` (app.js) and KamiSensei's IndexedDB
(``public/static/ks-state.js``). Both of those were per-browser and per-profile:
clearing site data, switching browser, or opening the HUD lost the history, and
neither surface could see the other's conversations. This store is on disk, so
reload, restart, and browser change all show the same history.

Design notes
------------
* **One schema, two surfaces.** The ``surface`` column (``jarvis`` |
  ``kamisensei``) keeps general chat strictly separate from study chat, so
  KamiSensei retrieval never pulls in an unrelated conversation.
* **Conversation context is NOT memory.** Rows here are the transcript. Nothing
  in this file decides what is worth remembering for later - that is
  ``conversation_memory.py``. Keeping them apart is what lets "clear chat" and
  "forget this fact" mean different things.
* **Timestamps are epoch milliseconds** (INTEGER) so ordering is exact and no
  timezone parsing can reorder two chats written in the same second.
* **Never raises.** A disk error returns an honest ``{"ok": False, ...}`` instead
  of taking down the voice loop.

API: new_conversation / list_conversations / get_conversation /
append_message / rename_conversation / delete_conversation / message_count /
recent_context / storage_status
"""

from __future__ import annotations

import sqlite3
import time
import uuid

try:  # normal import (voice core, tests)
    import storage_paths as _paths
except ImportError:  # pragma: no cover - package-style import
    from background import storage_paths as _paths

MAX_TITLE = 120
MAX_MESSAGE_CHARS = 8000

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id          TEXT PRIMARY KEY,
    surface     TEXT NOT NULL DEFAULT 'jarvis',
    title       TEXT NOT NULL DEFAULT '',
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL,
    archived    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id TEXT NOT NULL,
    role            TEXT NOT NULL,
    content         TEXT NOT NULL,
    created_at      INTEGER NOT NULL,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_conv_surface ON conversations(surface, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, id);
"""


def _db_path(surface: str):
    return _paths.kamisensei_db() if surface == "kamisensei" else _paths.jarvis_db()


def _connect(surface: str):
    """Open the DB for `surface`, creating schema on first use."""
    path = _db_path(surface)
    conn = sqlite3.connect(str(path), timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(_SCHEMA)
    return conn


def _surface_ok(surface: str) -> str:
    value = str(surface or "jarvis").strip().lower()
    return value if value in ("jarvis", "kamisensei") else "jarvis"


def _title_from(text: str) -> str:
    body = " ".join(str(text or "").split())
    return body[:MAX_TITLE] if body else "New chat"
# ── Conversations ───────────────────────────────────────────────────────────
def new_conversation(surface: str = "jarvis", title: str = "") -> dict:
    """Create an empty conversation and return its record."""
    surface = _surface_ok(surface)
    now = int(time.time() * 1000)
    cid = "conv-%s" % uuid.uuid4().hex[:16]
    try:
        with _connect(surface) as conn:
            conn.execute(
                "INSERT INTO conversations(id, surface, title, created_at, updated_at)"
                " VALUES(?,?,?,?,?)",
                (cid, surface, str(title or "")[:MAX_TITLE], now, now))
        return {"ok": True, "id": cid, "surface": surface,
                "title": title or "New chat", "created_at": now, "updated_at": now}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def list_conversations(surface: str = "jarvis", limit: int = 100) -> list:
    """Conversations for one surface, most recently updated first."""
    surface = _surface_ok(surface)
    try:
        with _connect(surface) as conn:
            rows = conn.execute(
                "SELECT c.id, c.title, c.created_at, c.updated_at,"
                " (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id)"
                "   AS message_count"
                " FROM conversations c WHERE c.surface = ? AND c.archived = 0"
                " ORDER BY c.updated_at DESC LIMIT ?",
                (surface, max(1, min(int(limit), 500)))).fetchall()
        return [{"id": r["id"], "title": r["title"] or "New chat",
                 "created_at": r["created_at"], "updated_at": r["updated_at"],
                 "message_count": int(r["message_count"] or 0)} for r in rows]
    except Exception:
        return []


def get_conversation(conversation_id: str, surface: str = "jarvis") -> dict:
    """Full transcript for one conversation, oldest message first."""
    surface = _surface_ok(surface)
    if not conversation_id:
        return {"ok": False, "error": "conversation_id required"}
    try:
        with _connect(surface) as conn:
            conv = conn.execute(
                "SELECT id, title, created_at, updated_at FROM conversations"
                " WHERE id = ?", (conversation_id,)).fetchone()
            if conv is None:
                return {"ok": False, "error": "conversation_not_found"}
            rows = conn.execute(
                "SELECT role, content, created_at FROM messages"
                " WHERE conversation_id = ? ORDER BY id ASC", (conversation_id,)).fetchall()
        return {"ok": True, "id": conv["id"], "title": conv["title"] or "New chat",
                "created_at": conv["created_at"], "updated_at": conv["updated_at"],
                "messages": [{"role": r["role"], "content": r["content"],
                              "created_at": r["created_at"]} for r in rows]}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
def append_message(conversation_id: str, role: str, content: str,
                   surface: str = "jarvis") -> dict:
    """Append one message and bump the conversation's updated_at.

    Also back-fills the title from the first user message, which is what makes
    the history list readable without asking the user to name every chat.
    """
    surface = _surface_ok(surface)
    body = str(content or "").strip()[:MAX_MESSAGE_CHARS]
    if not conversation_id:
        return {"ok": False, "error": "conversation_id required"}
    if not body:
        return {"ok": False, "error": "empty message"}
    role = role if role in ("user", "assistant", "system") else "user"
    # Quota guard: a long transcript must not be able to grow the data root
    # past its ceiling. Reported to the caller, never silently dropped.
    if not _paths.guard_write(len(body) * 2):
        return {"ok": False, "error": "storage_quota_reached",
                "detail": _paths.quota_status()}
    now = int(time.time() * 1000)
    try:
        with _connect(surface) as conn:
            conv = conn.execute("SELECT title FROM conversations WHERE id = ?",
                                (conversation_id,)).fetchone()
            if conv is None:
                return {"ok": False, "error": "conversation_not_found"}
            conn.execute(
                "INSERT INTO messages(conversation_id, role, content, created_at)"
                " VALUES(?,?,?,?)", (conversation_id, role, body, now))
            if not (conv["title"] or "").strip() and role == "user":
                conn.execute("UPDATE conversations SET title = ? WHERE id = ?",
                             (_title_from(body), conversation_id))
            # updated_at drives list ordering, so it moves on every write.
            conn.execute("UPDATE conversations SET updated_at = ? WHERE id = ?",
                         (now, conversation_id))
        return {"ok": True, "conversation_id": conversation_id, "created_at": now}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def rename_conversation(conversation_id: str, title: str,
                        surface: str = "jarvis") -> dict:
    surface = _surface_ok(surface)
    name = " ".join(str(title or "").split())[:MAX_TITLE]
    if not conversation_id:
        return {"ok": False, "error": "conversation_id required"}
    if not name:
        return {"ok": False, "error": "title required"}
    try:
        with _connect(surface) as conn:
            cur = conn.execute("UPDATE conversations SET title = ?, updated_at = ?"
                               " WHERE id = ?",
                               (name, int(time.time() * 1000), conversation_id))
            if cur.rowcount == 0:
                return {"ok": False, "error": "conversation_not_found"}
        return {"ok": True, "id": conversation_id, "title": name}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def delete_conversation(conversation_id: str, surface: str = "jarvis") -> dict:
    """Delete a conversation and its messages.

    This removes only the transcript. Long-term memory is a separate store and is
    intentionally NOT touched - deleting a chat should not silently erase facts
    the user asked JARVIS to remember.
    """
    surface = _surface_ok(surface)
    if not conversation_id:
        return {"ok": False, "error": "conversation_id required"}
    try:
        with _connect(surface) as conn:
            conn.execute("DELETE FROM messages WHERE conversation_id = ?",
                         (conversation_id,))
            cur = conn.execute("DELETE FROM conversations WHERE id = ?",
                               (conversation_id,))
            if cur.rowcount == 0:
                return {"ok": False, "error": "conversation_not_found"}
        return {"ok": True, "deleted": conversation_id}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def message_count(conversation_id: str, surface: str = "jarvis") -> int:
    surface = _surface_ok(surface)
    try:
        with _connect(surface) as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM messages"
                               " WHERE conversation_id = ?",
                               (conversation_id,)).fetchone()
        return int(row["n"] or 0)
    except Exception:
        return 0


def recent_context(conversation_id: str, surface: str = "jarvis",
                   limit: int = 10) -> list:
    """Last N messages for prompt context, oldest-first.

    This is the *conversation* window. It is bounded on purpose so a very long
    chat cannot silently blow the provider context budget.
    """
    full = get_conversation(conversation_id, surface)
    if not full.get("ok"):
        return []
    return full["messages"][-max(1, int(limit)):]


def storage_status() -> dict:
    """Where conversation data actually lives (used by the UI + tests)."""
    info = dict(_paths.status())
    out = {"root": info.get("root"), "fallback": info.get("fallback"),
           "configured": info.get("configured"), "ok": info.get("ok", True),
           # Usage + ceiling belong in the same report as the location, so one
           # call answers both "where does data live" and "how much is used".
           "quota": _paths.quota_status(),
           "surfaces": {}}
    for surface in ("jarvis", "kamisensei"):
        path = _db_path(surface)
        entry = {"path": str(path), "exists": path.exists(), "bytes": 0,
                 "conversations": 0, "messages": 0}
        try:
            if path.exists():
                entry["bytes"] = path.stat().st_size
                with _connect(surface) as conn:
                    entry["conversations"] = int(conn.execute(
                        "SELECT COUNT(*) AS n FROM conversations").fetchone()["n"])
                    entry["messages"] = int(conn.execute(
                        "SELECT COUNT(*) AS n FROM messages").fetchone()["n"])
        except Exception as exc:
            entry["error"] = "%s: %s" % (type(exc).__name__, exc)
        out["surfaces"][surface] = entry
    return out