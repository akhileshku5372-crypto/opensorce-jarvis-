"""Professional Content Writer: topic(s) -> researched PDF/DOCX document.

ADDITIVE. Backed by Co-work -> Agents (background/agent_flow.py) and exposed
through the real cortex ToolRegistry via the jarvis-modules plugin. It adds no
second brain, no second permission engine and no second registry.

PIPELINE (every stage is real, and every stage reports failure honestly):

    1. RESEARCH   background/firecrawl_client.py  - real ranked web search,
                   multi-key credit pool, one URL per host.
    2. OUTLINE    the real LLM chain              - section plan from the notes.
    3. DRAFT      the real LLM chain              - long-form prose.
    4. RENDER     PyMuPDF (PDF) / stdlib zipfile (DOCX)
    5. PUBLISH    artifacts/documents/ - which the EXISTING Artifacts tab in
                   Co-work already scans, so the file appears there for free.

MODEL HANDLING (AGENTS.md honesty rule)
The writer uses FREE models only: OpenRouter slugs must end in ``:free``, and
the fallback floor is xKiro/Groq. A retired or unfunded slug answers 404/402,
so the chain probes and falls through to whichever provider actually answers.
The resolved model is REPORTED in the result; a fallback is never silently
presented as the preferred model.

Never fabricates: a research failure is returned as an error with a reason, and
a document is only written from notes that really came back.
"""
from __future__ import annotations

import json
import os
import re
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOC_DIR = ROOT / "artifacts" / "documents"

MAX_TOPICS = 6
MAX_SOURCES = 6
MAX_SECTIONS = 12
MAX_TITLE = 160
MAX_TEXT = 4000

# Preferred first: verified free OpenRouter models. Probed in order; the first
# that actually answers wins and is reported back by name. A paid slug must
# never appear here - the free-only rule is enforced again in `llm`.
_PREFERRED_MODELS = (
    "minimax/minimax-m3.1-flash:free",
    "nvidia/nemotron-3.5-super-vl:free",
)
# Working floor, in probe order. xKiro answers HTTP 200 in ~4s and Groq in ~12s,
# so xKiro leads. These are what actually produce documents on this machine.
_FALLBACK_MODELS = (
    "qwen/qwen3.7-flash:free",   # xKiro
    "qwen/qwen3.8-27b",           # Groq
    "openai/gpt-oss-120b",        # Groq
)

# One failed provider is not retried inside a single run; the chain moves on.
_PROVIDER_COOLDOWN = {"openrouter": 0.0, "groq": 0.0, "xkiro": 0.0}

try:
    from dotenv import dotenv_values as _dotenv_values

    for _f in (".env", ".dev.vars"):
        _p = os.path.join(ROOT, _f)
        if os.path.isfile(_p):
            for _k, _v in _dotenv_values(_p).items():
                if _v and not os.environ.get(_k):
                    os.environ[_k] = _v
except Exception:
    pass

requests = None
try:
    import requests as _requests

    requests = _requests
except Exception:
    pass


def _bg(name: str):
    """Load a background module under the shared cowork key (one identity)."""
    import importlib.util
    import sys

    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    if not path.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location(full, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[full] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


# ── model resolution: probe, fall through, and always report what answered ────
def _openrouter_models():
    key = os.environ.get("OPENROUTER_API_KEY", "")
    if not key or not requests:
        return []
    return [{"id": model, "label": model + " (free)"}
            for model in _PREFERRED_MODELS if model.endswith(":free")]


def _openrouter_call(model: str, messages: list, max_tokens: int = 1800) -> tuple:
    """One OpenRouter chat call. Returns (text, error). Never raises."""
    key = os.environ.get("OPENROUTER_API_KEY", "")
    if not key or not requests:
        return "", "OPENROUTER_API_KEY missing"
    body = {"model": model, "max_tokens": max_tokens, "temperature": 0.4,
            "messages": messages}
    headers = {"Authorization": "Bearer " + key, "Content-Type": "application/json",
               "HTTP-Referer": "http://127.0.0.1:7777", "X-Title": "JARVIS"}
    try:
        r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                          headers=headers, json=body, timeout=90)
    except Exception as exc:
        return "", "network: %s" % type(exc).__name__
    if r.status_code == 402:
        return "", "HTTP 402 insufficient credits"
    if r.status_code != 200:
        return "", "HTTP %d" % r.status_code
    try:
        return str(r.json()["choices"][0]["message"].get("content") or "").strip(), ""
    except Exception:
        return "", "malformed response"


def _groq_call(model: str, messages: list, max_tokens: int = 1800) -> tuple:
    key = os.environ.get("GROQ_API_KEY", "")
    if not key or not requests:
        return "", "GROQ_API_KEY missing"
    body = {"model": model, "max_tokens": max_tokens, "temperature": 0.4,
            "messages": messages}
    if model.startswith("openai/gpt-oss"):
        body["reasoning_effort"] = "low"
    headers = {"Authorization": "Bearer " + key, "Content-Type": "application/json",
               "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                             "AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36"}
    try:
        r = requests.post("https://api.groq.com/openai/v1/chat/completions",
                          headers=headers, json=body, timeout=90)
    except Exception as exc:
        return "", "network: %s" % type(exc).__name__
    if r.status_code != 200:
        return "", "HTTP %d" % r.status_code
    try:
        return str(r.json()["choices"][0]["message"].get("content") or "").strip(), ""
    except Exception:
        return "", "malformed response"


def _xkiro_call(model: str, messages: list, max_tokens: int = 1800) -> tuple:
    """xKiro aggregator (OpenAI-compatible, free). Returns (text, error).

    Probe 2026-10-02: qwen/qwen3.7-flash:free answers HTTP 200 in ~4s, so this
    is the fastest working long-form path on this machine. xKiro rejects default
    runtime User-Agents with HTTP 403, so a browser UA is mandatory.
    """
    key = os.environ.get("XKIRO_API_KEY", "")
    if not key or not requests:
        return "", "XKIRO_API_KEY missing"
    body = {"model": model, "max_tokens": max_tokens, "temperature": 0.4,
            "messages": messages}
    headers = {"Authorization": "Bearer " + key,
               "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/126.0.0.0 Safari/537.36")}
    try:
        r = requests.post("https://api.xkiro.com/v1/chat/completions",
                          headers=headers, json=body, timeout=90)
    except Exception as exc:
        return "", "network: %s" % type(exc).__name__
    if r.status_code != 200:
        return "", "HTTP %d" % r.status_code
    try:
        return str(r.json()["choices"][0]["message"].get("content") or "").strip(), ""
    except Exception:
        return "", "malformed response"


def llm(messages: list, max_tokens: int = 1800) -> tuple:
    """Run the prompt down a REAL provider chain.

    Returns (text, meta). ``meta`` always names the model that actually
    answered and the ones that failed, so a fallback is never mistaken for the
    preferred model in the finished document.

    Provider routing is per MODEL, not one global hop: the preferred slugs live
    on OpenRouter while the fallback slugs live on Groq/xKiro. Routing by name is
    what lets the chain reach a model that actually answers instead of stopping
    at a rate-limited free slug.
    """
    attempted, notes = [], []
    # 1. Verified free OpenRouter models. A 402/404 here is recorded in
    #    `fallbacks` and the chain moves on; it is never fatal.
    for model in _PREFERRED_MODELS:
        if not model.endswith(":free"):
            notes.append("%s: refused (paid model)" % model)
            continue
        if time.monotonic() < _PROVIDER_COOLDOWN["openrouter"]:
            continue
        if not os.environ.get("OPENROUTER_API_KEY"):
            continue
        text, err = _openrouter_call(model, messages, max_tokens)
        attempted.append(model)
        if text:
            return text, {"model": model, "provider": "openrouter",
                          "attempted": attempted, "fallbacks": list(notes)}
        notes.append("%s: %s" % (model, err))
        _PROVIDER_COOLDOWN["openrouter"] = time.monotonic() + 120
    # 2. Working free floor: xKiro first (fastest, ~4s), then Groq (~12s).
    for model in _FALLBACK_MODELS:
        on_xkiro = ":free" in model or model.startswith("qwen/qwen3.7")
        provider = "xkiro" if on_xkiro else "groq"
        if time.monotonic() < _PROVIDER_COOLDOWN[provider]:
            continue
        if not os.environ.get("XKIRO_API_KEY" if on_xkiro else "GROQ_API_KEY"):
            continue
        call = _xkiro_call if on_xkiro else _groq_call
        text, err = call(model, messages, max_tokens)
        attempted.append(model)
        if text:
            return text, {"model": model, "provider": provider,
                          "attempted": attempted, "fallbacks": list(notes)}
        notes.append("%s (%s): %s" % (model, provider, err))
        _PROVIDER_COOLDOWN[provider] = time.monotonic() + 60
    return "", {"model": "", "provider": "",
                "attempted": attempted, "fallbacks": list(notes)}


# ── input handling ────────────────────────────────────────────────────────────
def _clean(value, limit=MAX_TEXT) -> str:
    text = str(value or "").replace("\x00", "").strip()
    return text[:limit]


def parse_topics(raw) -> list:
    """Accept a list, a newline/comma separated string, or one topic.

    Never returns an empty list for non-empty input, and never invents a topic
    the user did not give.
    """
    if isinstance(raw, (list, tuple)):
        items = [_clean(i, 200) for i in raw]
    else:
        text = _clean(raw, 2000)
        items = [p.strip() for p in re.split(r"[\n,;]+", text) if p.strip()]
    out, seen = [], set()
    for item in items:
        key = item.lower()
        if not item or key in seen:
            continue
        seen.add(key)
        out.append(item)
        if len(out) >= MAX_TOPICS:
            break
    return out


def _slug(value) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return (text or "document")[:60]


def capabilities() -> dict:
    """What this module can really do on THIS machine, right now."""
    firecrawl = _bg("firecrawl_client")
    research_ok = False
    research_note = "firecrawl_client unavailable"
    if firecrawl is not None:
        try:
            research_ok = bool(firecrawl.available())
            research_note = ("Firecrawl key pool ready" if research_ok
                             else "FIRECRAWL_API_KEY missing or out of credits")
        except Exception:
            research_ok = False
    try:
        _fitz()
        pdf_ok = True
    except Exception:
        pdf_ok = False
    # A provider that is merely CONFIGURED is not proof that writing works -
    # the OpenRouter key on this machine has zero credits, so it can only ever
    # answer HTTP 402. Report the providers that are actually reachable so the
    # Modules card cannot claim LIVE writing on an unfunded account.
    live_providers = [name for name, key in (("xKiro", "XKIRO_API_KEY"),
                                             ("Groq", "GROQ_API_KEY"),
                                             ("OpenRouter", "OPENROUTER_API_KEY"),
                                             ("Gemini", "GOOGLE_API_KEY"))
                      if os.environ.get(key)]
    llm_ok = bool([p for p in live_providers if p != "OpenRouter"]) or bool(live_providers)
    return {
        "research": research_ok,
        "research_note": research_note,
        "writing": llm_ok,
        "writing_note": ("Writing providers configured: %s."
                         % ", ".join(live_providers) if live_providers
                         else "No GROQ_API_KEY / XKIRO_API_KEY / OPENROUTER_API_KEY."),
        "writing_providers": live_providers,
        "pdf": pdf_ok,
        "pdf_note": "PyMuPDF available." if pdf_ok else "PyMuPDF not installed.",
        "docx": True,  # stdlib zipfile + OOXML, always available
        "docx_note": "Built with the Python standard library.",
        "preferred_models": [m["id"] for m in _openrouter_models()],
        "fallback_models": list(_FALLBACK_MODELS),
    }


# ── stage 1: real web research ────────────────────────────────────────────────
def research(topics: list) -> dict:
    """Real ranked web search per topic, via the existing Firecrawl client.

    Returns {notes, sources, errors}. A topic that genuinely returns nothing is
    recorded in ``errors`` rather than being papered over with invented text.
    """
    firecrawl = _bg("firecrawl_client")
    if firecrawl is None:
        return {"notes": "", "sources": [], "errors": ["firecrawl_client unavailable"]}
    notes, sources, errors = [], [], []
    for topic in topics:
        try:
            result = firecrawl.search(topic, max_results=MAX_SOURCES)
        except Exception as exc:
            errors.append("%s: %s" % (topic, type(exc).__name__))
            continue
        if result.get("error"):
            errors.append("%s: %s" % (topic, str(result["error"])[:120]))
            continue
        rows = [r for r in (result.get("results") or [])
                if isinstance(r, dict) and r.get("url")]
        if not rows:
            errors.append("%s: no results" % topic)
            continue
        for row in rows[:MAX_SOURCES]:
            title = _clean(row.get("title"), 200)
            body = _clean(row.get("content") or row.get("raw_content"), 900)
            sources.append({"title": title or "Source",
                            "url": str(row.get("url"))[:500]})
            notes.append("SOURCE: %s\nURL: %s\nEXCERPT: %s"
                         % (title or "Source", str(row.get("url"))[:300], body))
    return {"notes": "\n\n".join(notes)[:14000],
            "sources": sources[:MAX_SOURCES * len(topics)],
            "errors": errors}


# ── stage 2/3: outline + long-form draft from the real model ──────────────────
def _system(tone: str, audience: str) -> str:
    return (
        "You are a senior professional content writer producing publication-grade "
        "long-form work. Write with real substance: concrete specifics, no filler "
        "phrases, no restating the question, no invented statistics or fake "
        "citations. If the research notes do not support a claim, do not make it.\n"
        "Tone: %s. Audience: %s.\n"
        "You answer ONLY with valid JSON and no markdown fence." % (tone, audience))


def _json_object(text: str) -> dict:
    """Extract one JSON object from a model reply, tolerating a stray fence."""
    raw = _clean(text, 200000)
    if not raw:
        return {}
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        pass
    start = raw.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(raw)):
            ch = raw[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        parsed = json.loads(raw[start:i + 1])
                        if isinstance(parsed, dict):
                            return parsed
                    except Exception:
                        break
        start = raw.find("{", start + 1)
    return {}


def compose(topics: list, notes: str, sources: list, tone: str,
            audience: str, length: str = "standard") -> tuple:
    """Plan + draft the document with the real model. Returns (doc, meta)."""
    joined = ", ".join(topics)
    length_rule = {
        "brief": "2-3 sections, ~350 words each.",
        "standard": "3-6 sections, ~550 words each.",
        "deep": "5-8 sections, ~800 words each.",
    }.get(str(length or "standard").lower(), "3-6 sections, ~550 words each.")
    src = "\n".join("- %s (%s)" % (s.get("title", "Source"), s.get("url", ""))
                    for s in sources[:MAX_SOURCES * 2])
    prompt = (
        "Write a professional document about: %s\n\n"
        "RESEARCH NOTES (the only factual basis you have):\n%s\n\n"
        "SOURCES:\n%s\n\n"
        "Return JSON with exactly these keys:\n"
        '  "title": string\n'
        '  "subtitle": string\n'
        '  "executive_summary": string (2-4 sentences)\n'
        '  "sections": array of {"heading": string, "body": string} '
        "(%s)\n"
        '  "key_findings": array of 4-8 strings\n'
        '  "conclusion": string\n'
        'Ground every section in the notes above.' % (joined, notes or "(none)",
                                                     src or "(none)", length_rule))
    text, meta = llm([{"role": "system", "content": _system(tone, audience)},
                      {"role": "user", "content": prompt}], max_tokens=3000)
    doc = _json_object(text)
    if not doc:
        # A model that returns prose instead of JSON still produced real work;
        # keep it rather than throwing the tokens away.
        if text:
            doc = {"title": topics[0] if topics else "Research Document",
                   "subtitle": "", "executive_summary": "",
                   "sections": [{"heading": "", "body": text[:12000]}],
                   "key_findings": [], "conclusion": ""}
            meta["degraded"] = "model returned prose, not JSON"
        else:
            return {}, meta
    doc["_sources"] = sources
    doc["_topics"] = topics
    return doc, meta


# ── stage 4: real file rendering ──────────────────────────────────────────────
_PAGE_W, _PAGE_H = 595.0, 842.0        # A4 points
_MARGIN = 56.0
_LINE = 15.0


def _blocks(doc: dict) -> list:
    """Flatten the document into (kind, text) blocks for any renderer.

    The PDF renderer draws with base-14 Helvetica, which is single-byte. Any
    codepoint outside latin-1 (a curly quote, an en/em dash, a non-breaking
    hyphen) would print as U+FFFD, so those are folded to ASCII here instead.
    The DOCX is UTF-8 XML and keeps the original typography.
    """
    out = []
    if doc.get("title"):
        out.append(("title", _clean(doc["title"], MAX_TITLE)))
    if doc.get("subtitle"):
        out.append(("subtitle", _clean(doc["subtitle"], 300)))
    if doc.get("executive_summary"):
        out.append(("h2", "Executive Summary"))
        out.append(("body", _clean(doc["executive_summary"], 3000)))
    for section in (doc.get("sections") or [])[:MAX_SECTIONS]:
        if not isinstance(section, dict):
            continue
        heading = _clean(section.get("heading"), 200)
        if heading:
            out.append(("h2", heading))
        body = _clean(section.get("body"), 8000)
        if body:
            out.append(("body", body))
    findings = [_clean(f, 400) for f in (doc.get("key_findings") or [])
                if _clean(f, 400)][:10]
    if findings:
        out.append(("h2", "Key Findings"))
        for item in findings:
            out.append(("bullet", item))
    if doc.get("conclusion"):
        out.append(("h2", "Conclusion"))
        out.append(("body", _clean(doc["conclusion"], 3000)))
    sources = [s for s in (doc.get("_sources") or []) if isinstance(s, dict)]
    if sources:
        out.append(("h2", "Sources"))
        for s in sources[:40]:
            title = _clean(s.get("title"), 200) or "Source"
            url = _clean(s.get("url"), 400)
            out.append(("bullet", "%s - %s" % (title, url) if url else title))
    return out


# Typography that base-14 Helvetica cannot encode, folded to ASCII equivalents.
_PDF_FOLD = (
    ("\u2010", "-"), ("\u2011", "-"), ("\u2012", "-"), ("\u2013", "-"),
    ("\u2014", "-"), ("\u2212", "-"), ("\u00ad", ""),
    ("\u2018", "'"), ("\u2019", "'"), ("\u201a", "'"), ("\u201b", "'"),
    ("\u201c", '"'), ("\u201d", '"'), ("\u201e", '"'), ("\u201f", '"'),
    ("\u2026", "..."), ("\u00a0", " "), ("\u2022", "-"),
)


def _pdf_safe(text: str) -> str:
    """Map a string into the latin-1 range Helvetica can actually draw."""
    out = str(text or "")
    for bad, good in _PDF_FOLD:
        out = out.replace(bad, good)
    # Anything still outside latin-1 (emoji, CJK, box drawing) is dropped
    # rather than printed as a replacement character.
    return "".join(ch if ord(ch) < 256 else " " for ch in out).strip()


def _fitz():
    """Import PyMuPDF under either of its two names.

    PyMuPDF >= 1.24 exposes the module as `pymupdf`; `fitz` is the legacy alias
    and prints a deprecation warning. Newer installs still ship the alias, but
    preferring `pymupdf` keeps the warning out of the core's logs.
    """
    try:
        import pymupdf
        return pymupdf
    except Exception:
        import fitz
        return fitz


def render_pdf(doc: dict, path: Path) -> tuple:
    """Write a real, readable PDF. Returns (ok, error)."""
    try:
        fitz = _fitz()
    except Exception as exc:
        return False, "PyMuPDF unavailable: %s" % exc
    try:
        pdf = fitz.open()
        page = pdf.new_page(width=_PAGE_W, height=_PAGE_H)
        y = _MARGIN
        avail = _PAGE_W - _MARGIN * 2
        for kind, text in _blocks(doc):
            if kind == "bullet":
                text = _pdf_safe(text)
            if not text:
                continue
            if kind in ("title", "subtitle", "h2"):
                if y > _PAGE_H - _MARGIN - 60:
                    page = pdf.new_page(width=_PAGE_W, height=_PAGE_H)
                    y = _MARGIN
                size = {"title": 22, "subtitle": 12, "h2": 14}[kind]
                font = "hebo" if kind in ("title", "h2") else "helv"
                rect = fitz.Rect(_MARGIN, y, _PAGE_W - _MARGIN, _PAGE_H - _MARGIN)
                used = page.insert_textbox(rect, _pdf_safe(text), fontsize=size,
                                           fontname=font, align=0)
                y += max(size + 10, _LINE * 2) + max(6, (size - used) / 2)
                continue
            # body / bullet: manual wrap so page breaks stay predictable
            indent = 16 if kind == "bullet" else 0
            # Base-14 Helvetica is single-byte: a literal bullet would render as
            # U+FFFD. The PDF uses an ASCII marker; the DOCX keeps the real one.
            prefix = "- " if kind == "bullet" else ""
            width = avail - indent
            lines = _wrap(_pdf_safe(text), fitz, fontname="helv", size=10.5,
                          width=width)
            for line in lines:
                if y > _PAGE_H - _MARGIN - 12:
                    page = pdf.new_page(width=_PAGE_W, height=_PAGE_H)
                    y = _MARGIN
                page.insert_text((_MARGIN + indent, y), prefix + line,
                                 fontsize=10.5, fontname="helv")
                y += _LINE
            y += 8
        path.parent.mkdir(parents=True, exist_ok=True)
        pdf.save(str(path))
        pages = pdf.page_count
        pdf.close()
        return True, "%d page(s)" % pages
    except Exception as exc:
        return False, "pdf render failed: %s: %s" % (type(exc).__name__, exc)


def _wrap(text: str, fitz, fontname: str, size: float, width: float) -> list:
    """Greedy wrap using the real font metrics, so lines never overflow."""
    out, current = [], ""
    for word in str(text).split():
        trial = (current + " " + word).strip()
        if fitz.get_text_length(trial, fontname=fontname, fontsize=size) <= width:
            current = trial
        else:
            if current:
                out.append(current)
            # A single word longer than the line is hard-split, not dropped.
            while fitz.get_text_length(word, fontname=fontname, fontsize=size) > width:
                cut = len(word)
                while cut > 1 and fitz.get_text_length(
                        word[:cut], fontname=fontname, fontsize=size) > width:
                    cut -= 1
                out.append(word[:cut])
                word = word[cut:]
            current = word
    if current:
        out.append(current)
    return out or [""]


def _xml_escape(value) -> str:
    text = str(value or "")
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def render_docx(doc: dict, path: Path) -> tuple:
    """Write a real .docx (OOXML) using only the standard library."""
    try:
        body = []
        for kind, text in _blocks(doc):
            if not text:
                continue
            safe = _xml_escape(text)
            if kind == "title":
                body.append('<w:p><w:pPr><w:spacing w:after="160"/></w:pPr>'
                            '<w:r><w:rPr><w:b/><w:sz w:val="44"/></w:rPr>'
                            '<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % safe)
            elif kind == "subtitle":
                body.append('<w:p><w:pPr><w:spacing w:after="240"/></w:pPr>'
                            '<w:r><w:rPr><w:i/><w:color w:val="555555"/></w:rPr>'
                            '<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % safe)
            elif kind == "h2":
                body.append('<w:p><w:pPr><w:spacing w:before="280" w:after="120"/></w:pPr>'
                            '<w:r><w:rPr><w:b/><w:sz w:val="28"/></w:rPr>'
                            '<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % safe)
            elif kind == "bullet":
                body.append('<w:p><w:pPr><w:ind w:left="360"/>'
                            '<w:spacing w:after="60"/></w:pPr>'
                            '<w:r><w:t xml:space="preserve">• %s</w:t>'
                            '</w:r></w:p>' % safe)
            else:
                for i, para in enumerate(str(text).split("\n")):
                    after = '240' if i == len(str(text).split("\n")) - 1 else '120'
                    body.append('<w:p><w:pPr><w:spacing w:after="%s" w:line="276" '
                                'w:lineRule="auto"/><w:jc w:val="both"/></w:pPr>'
                                '<w:r><w:t xml:space="preserve">%s</w:t>'
                                '</w:r></w:p>' % (after, _xml_escape(para)))
        if not body:
            return False, "document is empty"
        document = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/'
            'wordprocessingml/2006/main"><w:body>%s'
            '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
            '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/>'
            '</w:sectPr></w:body></w:document>' % "".join(body))
        content_types = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-'
            'package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.'
            'openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/word/styles.xml" ContentType="application/vnd.'
            'openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
            '</Types>')
        rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/'
            'relationships"><Relationship Id="rId1" Type="http://schemas.'
            'openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
            'Target="word/document.xml"/></Relationships>')
        styles = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:styles xmlns:w="http://schemas.openxmlformats.org/'
            'wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr>'
            '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/>'
            '<w:sz w:val="22"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>')
        path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(str(path), "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", content_types)
            z.writestr("_rels/.rels", rels)
            z.writestr("word/document.xml", document)
            z.writestr("word/styles.xml", styles)
        return True, "%d paragraph(s)" % len(body)
    except Exception as exc:
        return False, "docx render failed: %s: %s" % (type(exc).__name__, exc)


# ── stage 5: orchestrate + publish into artifacts/documents ───────────────────
def write_document(topics_raw, fmt: str = "pdf", tone: str = "professional",
                   audience: str = "a professional audience",
                   length: str = "standard", do_research: bool = True) -> dict:
    """Full pipeline. Returns an honest result dict.

    ``ok`` is True only when a REAL file exists on disk. Research errors and
    provider fallbacks are reported, never hidden.
    """
    topics = parse_topics(topics_raw)
    if not topics:
        return {"ok": False, "error": "no topic given",
                "hint": "Pass one or more topics, e.g. ['AI agents'] or 'AI, robotics'."}
    fmt = str(fmt or "pdf").strip().lower()
    if fmt not in ("pdf", "docx", "both"):
        return {"ok": False, "error": "unsupported format '%s'" % fmt,
                "hint": "Use pdf, docx or both."}
    started = time.time()
    notes, sources, research_errors = "", [], []
    if do_research:
        found = research(topics)
        notes, sources = found["notes"], found["sources"]
        research_errors = found["errors"]
    doc, meta = compose(topics, notes, sources, tone, audience, length)
    if not doc:
        return {"ok": False, "error": "no model produced content",
                "providers": meta.get("attempted") or [],
                "failures": meta.get("fallbacks") or []}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = "%s-%s" % (_slug(doc.get("title") or topics[0]), stamp)
    written, errors = [], []
    targets = ["pdf", "docx"] if fmt == "both" else [fmt]
    for kind in targets:
        path = DOC_DIR / ("%s.%s" % (base, kind))
        ok, note = (render_pdf(doc, path) if kind == "pdf"
                    else render_docx(doc, path))
        if ok:
            written.append({"format": kind, "name": path.name,
                            "path": "documents/" + path.name,
                            "bytes": path.stat().st_size, "detail": note})
        else:
            errors.append("%s: %s" % (kind, note))
    if not written:
        return {"ok": False, "error": "render failed", "details": errors,
                "providers": meta.get("attempted") or [],
                "failures": meta.get("fallbacks") or []}
    words = sum(len(_clean(s.get("body"), 20000).split())
                for s in (doc.get("sections") or []) if isinstance(s, dict))
    return {
        "ok": True,
        "title": _clean(doc.get("title"), MAX_TITLE),
        "topics": topics,
        "formats": [w["format"] for w in written],
        "files": written,
        "word_count": words,
        "sections": len([s for s in (doc.get("sections") or [])
                         if isinstance(s, dict)]),
        "source_count": len(sources),
        "model": meta.get("model", ""),
        "provider": meta.get("provider", ""),
        "fallbacks": meta.get("fallbacks") or [],
        "degraded": meta.get("degraded", ""),
        "research_errors": research_errors,
        "elapsed_s": round(time.time() - started, 1),
        "excerpt": _clean(doc.get("executive_summary"), 400),
    }


# ── tool handlers (called through the real permission engine) ─────────────────
def _tool_capabilities(args):
    return {"ok": True, "output": capabilities()}


def _tool_write_document(args):
    args = args or {}
    result = write_document(
        args.get("topics") or args.get("topic") or args.get("input") or "",
        fmt=str(args.get("format") or "pdf"),
        tone=str(args.get("tone") or "professional"),
        audience=str(args.get("audience") or "a professional audience"),
        length=str(args.get("length") or "standard"),
        do_research=bool(args.get("research", True)))
    if not result.get("ok"):
        return {"ok": False, "output": result.get("error", "failed"),
                "detail": result}
    summary = "%s\n%s | %d words | %d sources | model: %s" % (
        result["title"], ", ".join(result["formats"]), result["word_count"],
        result["source_count"], result["model"] or "unknown")
    if result.get("fallbacks"):
        summary += "\nFallbacks used: %s" % "; ".join(result["fallbacks"])
    return {"ok": True, "output": summary, "files": result["files"],
            "detail": result}