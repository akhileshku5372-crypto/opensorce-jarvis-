// End-to-end check of the DB-backed conversation routes against the LIVE core.
// Writes a real conversation, learns from it, renames, reads it back, then
// deletes it. Uses a throwaway prompt so no personal data is stored.
const BASE = 'http://127.0.0.1:7780'
const SURFACE = process.env.CONV_SURFACE || 'jarvis'

async function post(action, body) {
  const res = await fetch(`${BASE}/conversations${action ? '/' + action : ''}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ surface: SURFACE, ...body })
  })
  return { status: res.status, body: await res.json().catch(() => null) }
}
async function get(path) {
  const res = await fetch(`${BASE}${path}`)
  return { status: res.status, body: await res.json().catch(() => null) }
}
const results = []
const check = (name, cond, detail = '') => {
  results.push({ name, ok: !!cond, detail })
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${name}${detail ? ' :: ' + detail : ''}`)
}

const created = await post('', {})
check('create conversation', created.body?.ok && created.body?.id, created.body?.id)
const id = created.body?.id

const m1 = await post('message', { id, role: 'user', content: 'Hi, my name is Testbot and my city is Zurich' })
check('append user message', m1.body?.ok)

const m2 = await post('message', { id, role: 'assistant', content: 'Noted, Testbot.' })
check('append assistant message', m2.body?.ok)

const got = await get(`/conversations/${id}?surface=${SURFACE}`)
check('read back transcript', got.body?.messages?.length === 2,
  `messages=${got.body?.messages?.length}`)
check('title back-filled from first user message',
  /Testbot/.test(got.body?.title || ''), got.body?.title)

const renamed = await post('rename', { id, title: 'Renamed by test' })
check('rename', renamed.body?.ok && renamed.body?.title === 'Renamed by test')

const listed = await get(`/conversations?surface=${SURFACE}`)
check('appears in sidebar list',
  (listed.body?.conversations || []).some((c) => c.id === id),
  `${listed.body?.conversations?.length} total`)

// Learning is JARVIS-only by design; skip on the study surface.
if (SURFACE === 'jarvis') {
  const learned = await post('learn', { id })
  check('learn from conversation', learned.body?.ok && learned.body?.learned >= 1,
    `learned=${learned.body?.learned} superseded=${learned.body?.superseded}`)
  const mem = await get('/memory/learned')
  check('memory retrievable', (mem.body?.memories || []).length > 0,
    `${mem.body?.memories?.length} memories`)
}

const del = await post('delete', { id })
check('delete', del.body?.ok)
const after = await get(`/conversations?surface=${SURFACE}`)
check('gone from list after delete',
  !(after.body?.conversations || []).some((c) => c.id === id))

const failed = results.filter((r) => !r.ok).length
console.log(`\nCONVERSATION API: ${results.length - failed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)