"""Permission Engine for the JARVIS Extension System.

One place that decides whether a capability may run, before any tool is
executed. It is an ADDITIVE layer: the existing cortex confirm gate
(`ToolSpec.requires_confirmation` + `_cortex_confirm`) stays exactly as it is,
and this engine adds categories, three-state decisions, per-category overrides
and an append-only audit trail.

Decisions are `auto` (run), `ask` (require approval) or `deny` (refuse, with
a reason). Nothing here executes anything - it only classifies, so a mistake
here can never cause a side effect by itself.

Policy file: extensions/permissions.json (git-tracked, user editable).
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
POLICY_PATH = Path(os.environ.get("JARVIS_PERMISSION_POLICY")
                   or (ROOT / "extensions" / "permissions.json"))

AUTO = "auto"
ASK = "ask"
DENY = "deny"
_VALID = (AUTO, ASK, DENY)

# Every capability category the system understands. `default` applies when the
# user has not overridden it, and mirrors the existing cortex gate: anything
# that can change the machine is `ask`, anything destructive is `deny`.
CATEGORIES = {
    "read_files": {"default": AUTO, "label": "Read files",
                   "description": "Open and read files inside the workspace."},
    "edit_files": {"default": ASK, "label": "Edit files",
                   "description": "Create or modify files in the workspace."},
    "execute_commands": {"default": ASK, "label": "Execute commands",
                         "description": "Run an allowlisted command or script."},
    "web_fetch": {"default": AUTO, "label": "Web fetch",
                  "description": "Search the web and scrape pages."},
    "mcp": {"default": ASK, "label": "MCP",
            "description": "Call a tool on an MCP connector."},
    "browser": {"default": ASK, "label": "Browser",
                "description": "Drive the real browser agent."},
    "computer_control": {"default": ASK, "label": "Computer control",
                         "description": "Mouse/keyboard and GUI automation."},
    "communication": {"default": ASK, "label": "Communication",
                      "description": "Send messages (WhatsApp, mail, etc.)."},
    "destructive": {"default": DENY, "label": "Destructive actions",
                    "description": "Delete, uninstall, format, factory reset."},
    # Camera / perception. Default ASK because it captures a live image of the
    # room; a user must approve before a frame is read. DENY stays un-overridable
    # for anything biometric because the perception plugin has no identity path.
    "camera": {"default": ASK, "label": "Camera & perception",
               "description": "Read a camera or screen frame for local object, "
                              "face and attention analysis."},
}

_lock = threading.RLock()
_overrides = {}
_audit = []
_MAX_AUDIT = 200
_loaded = False


def load(force: bool = False) -> dict:
    """Effective overrides: user choices layered over the built-in defaults."""
    global _overrides, _loaded
    with _lock:
        if _loaded and not force:
            return dict(_overrides)
        _loaded = True
        _overrides = {}
        try:
            data = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
            raw = data.get("overrides") if isinstance(data, dict) else None
            if isinstance(raw, dict):
                for key, value in raw.items():
                    name = str(key).strip().lower()
                    decision = str(value).strip().lower()
                    if name in CATEGORIES and decision in _VALID:
                        _overrides[name] = decision
        except Exception:
            pass
        return dict(_overrides)


def save_overrides(overrides: dict) -> tuple:
    """Persist user overrides. Rejects unknown categories / bad decisions."""
    global _overrides, _loaded
    clean = {}
    for key, value in (overrides or {}).items():
        name = str(key).strip().lower()
        decision = str(value).strip().lower()
        if name not in CATEGORIES:
            return (False, "unknown permission category: %s" % name)
        if decision not in _VALID:
            return (False, "invalid decision '%s' (use auto/ask/deny)" % decision)
        clean[name] = decision
    try:
        POLICY_PATH.parent.mkdir(parents=True, exist_ok=True)
        POLICY_PATH.write_text(
            json.dumps({"overrides": clean}, indent=2) + "\n", encoding="utf-8")
    except Exception as exc:
        return (False, "could not write %s: %s" % (POLICY_PATH.name, exc))
    # Only publish to memory once the file is actually written, so a failed
    # write can never leave the process believing a change took effect.
    with _lock:
        _overrides = clean
        _loaded = True
    return (True, "saved %d override(s)" % len(clean))


def decision_for(category: str) -> str:
    """Effective decision for one category. Unknown names are never guessed."""
    name = str(category or "").strip().lower()
    meta = CATEGORIES.get(name)
    if not meta:
        return DENY          # unknown capability -> most cautious choice
    return load().get(name, meta["default"])


def _record(entry: dict) -> None:
    with _lock:
        _audit.append(entry)
        del _audit[:-_MAX_AUDIT]


# ── Single-confirmation correlation ────────────────────────────────────────
# A plugin tool is guarded by TWO independent gates: the cortex confirm gate
# (the user answers "confirm") and this permission category. The handler runs on
# a worker thread, so a thread-local cannot carry the answer across. Instead the
# confirm gate records a short-lived, single-use approval for that exact tool
# name and the permission wrapper consumes it.
#
# Safety rules, in order:
#   * the record is keyed by the exact tool name and consumed once, so it can
#     never authorise a different tool or a second call;
#   * it expires quickly, so a stale approval cannot be replayed later;
#   * `check()` still ignores `approved` when the decision is DENY, so an
#     explicit deny stays un-overridable no matter what the user approved.
_APPROVAL_TTL_S = 120.0
_approvals: dict = {}


def grant_approval(tool: str) -> None:
    """Record that the user just approved this exact tool at a confirm gate."""
    name = str(tool or "").strip()
    if not name:
        return
    with _lock:
        now = time.time()
        for stale in [k for k, v in _approvals.items() if now - v > _APPROVAL_TTL_S]:
            _approvals.pop(stale, None)
        _approvals[name] = now


def take_approval(tool: str) -> bool:
    """Consume a prior approval for this tool. True at most once per grant."""
    name = str(tool or "").strip()
    if not name:
        return False
    with _lock:
        granted = _approvals.pop(name, None)
    return granted is not None and (time.time() - granted) <= _APPROVAL_TTL_S


def recent_audit(limit: int = 50) -> list:
    with _lock:
        return list(_audit[-int(limit or 50):])


def check(category: str, tool: str = "", args: dict = None,
          approved: bool = False) -> dict:
    """Decide whether a capability may run. Classification only, no side effects.

    Returns {allowed, decision, category, reason, requires_approval}.
    `approved=True` means the user already agreed (cortex confirm gate or the
    UI). Approval satisfies an `ask` but NEVER a `deny`.
    """
    name = str(category or "").strip().lower()
    meta = CATEGORIES.get(name)
    if not meta:
        result = {"allowed": False, "decision": DENY, "category": name,
                  "reason": "unknown permission category '%s' - denied" % name,
                  "requires_approval": False}
    else:
        decision = decision_for(name)
        if decision == DENY:
            result = {"allowed": False, "decision": DENY, "category": name,
                      "reason": "%s is denied by the current permission policy"
                                % meta["label"],
                      "requires_approval": False}
        elif decision == ASK and not approved:
            result = {"allowed": False, "decision": ASK, "category": name,
                      "reason": "%s needs your approval" % meta["label"],
                      "requires_approval": True}
        else:
            result = {"allowed": True,
                      "decision": AUTO if decision == AUTO else ASK,
                      "category": name,
                      "reason": "allowed (%s)" % meta["label"],
                      "requires_approval": False}

    _record({"at": time.time(), "category": name,
             "tool": str(tool or ""), "decision": result["decision"],
             "allowed": result["allowed"],
             "args_keys": sorted((args or {}).keys())[:12]})
    return result


def policy() -> dict:
    """Full policy snapshot for the UI and the voice route."""
    overrides = load()
    rows = []
    for name, meta in CATEGORIES.items():
        rows.append({
            "category": name, "label": meta["label"],
            "description": meta["description"],
            "default": meta["default"], "effective": decision_for(name),
            "overridden": name in overrides,
        })
    return {"categories": rows, "policy_path": str(POLICY_PATH)}


def describe() -> str:
    """Spoken summary for the voice route."""
    counts = {AUTO: 0, ASK: 0, DENY: 0}
    for name in CATEGORIES:
        counts[decision_for(name)] += 1
    text = ("Sir, permissions: %d auto-approve, %d needs approval, %d denied."
            % (counts[AUTO], counts[ASK], counts[DENY]))
    denied = [CATEGORIES[n]["label"] for n in CATEGORIES
              if decision_for(n) == DENY]
    if denied:
        text += " Denied: %s." % ", ".join(denied)
    return text

