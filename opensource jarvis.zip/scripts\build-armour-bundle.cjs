/* Build public/static/armour-bundle.js (Phase 5 armour studio).
 *
 * Usage:  node scripts/build-armour-bundle.cjs
 *
 * The Armour Studio needs three.js + OrbitControls + GLTFLoader. The existing
 * three-bundle.min.js (brain hologram) is a committed artifact with no build
 * script, so instead of rewriting it this bundles a second, lazily loaded file
 * that is only fetched when the Armour view opens.
 *
 * esbuild ships with Vite, so no new dependency is added.
 */
const path = require('path')
const fs = require('fs')

const ROOT = path.resolve(__dirname, '..')
const OUT = path.join(ROOT, 'public', 'static', 'armour-bundle.js')

async function main() {
  const esbuild = require('esbuild')
  await esbuild.build({
    entryPoints: [path.join(ROOT, 'scripts', 'armour-three-entry.js')],
    bundle: true,
    minify: true,
    format: 'iife',
    target: ['es2020'],
    outfile: OUT,
    legalComments: 'none',
    banner: {
      js: '/* JARVIS Armour Studio bundle - three.js (MIT) + GLTFLoader. ' +
          'Rebuild: node scripts/build-armour-bundle.cjs */'
    },
    logLevel: 'warning'
  })
  const kb = (fs.statSync(OUT).size / 1024).toFixed(0)
  const text = fs.readFileSync(OUT, 'utf8')
  for (const needle of ['GLTFLoader', 'OrbitControls', 'JARVIS_ARMOUR_THREE']) {
    if (!text.includes(needle)) throw new Error('bundle is missing ' + needle)
  }
  console.log('wrote %s (%s KB) with GLTFLoader + OrbitControls', OUT, kb)
}

main().catch((err) => {
  console.error(err.message || err)
  process.exit(1)
})