"""Hard-task mode for JARVIS (additive, no keys, no second brain).

When the user prefixes an utterance with the hard-task marker, the voice path
forces the SAME Cortex Plan->Act->Observe loop the dashboard /cortex/start and
/extensions/agent routes already use - no second agent, no second registry.

Placement (AGENTS.md): voice_engine._agent_route owns the hookup; this module
only holds the marker and the officer-style system prompt. No planner text is
ever executed - Cortex validates the planner's dict reply as data.

Spoken trigger examples:
  "jarvis hard task - open vscode and create notes.txt with hello"
  "hard task: make a 3-slide presentation on AGI"
"""
import re

# Marker the user speaks to enter hard-task mode. STT never produces the emoji,
# so the regex matches the SPOKEN forms: "hard task ..." / "hard-task ..."
# / "hardtask ..." / slurred "har task" / "hard kaam" - anchored to the start
# of the utterance (after an optional "jarvis") so an ordinary word "hard" in
# mid-sentence never hijacks a command into the agent loop.
_HARD_TASK_WORDS = (
    r"hard(?:\s+|-)?task",
    r"har(?:d)?\s*tas[kc]",
    r"hard\s*kaam",
)
HARD_TASK_RE = re.compile(
    r"(?:^\s*(?:jarvis\s*,?\s*)?(?:" + "|".join(_HARD_TASK_WORDS) + r")\b)",
    re.IGNORECASE,
)

HARD_TASK_PROMPT = (
    "You are JARVIS, a voice-first personal assistant and agent. "
    "You respond in the user's language (Hinglish/Hindi/English/Japanese) and "
    "keep answers short, stepwise, and honest.\n\n"
    "When given a hard request, act the way a reliable technician does:\n"
    "1. Repeat the goal in your own words and break it into 3-6 concrete steps.\n"
    "2. Run the smallest set of registered tools to complete each step.\n"
    "3. For any action that changes the system, ask for ONE confirmation FIRST "
    "- that rule is non-negotiable, do not skip it.\n"
    "4. If a step is blocked, say exactly what is blocked and stop - never "
    "pretend success.\n"
    "5. End with a short honest summary of what was done and what remains.\n\n"
    "Rules you MUST follow at all times:\n"
    "- Never execute shell/PowerShell/system-code from an LLM response.\n"
    "- Never invent tool names, models, or capabilities you do not have.\n"
    "- Never claim you completed something you did not complete.\n"
    "- Never promise a path, action, or file you cannot verify.\n"
    "- When a tool is blocked, say the BLOCK (provider, network, gating, or "
    "missing asset) and stop.\n"
    "- Read-only checks are allowed without confirmation; every write/change "
    "requires confirmation.\n\n"
    "You are thorough, calm, and helpful. Honor the confirmation gate always."
)

# Named alias so voice_engine's agents can reach the prompt as
# `task_prompt.JARVIS_TASK_PROMPT` without a second definition.
JARVIS_TASK_PROMPT = HARD_TASK_PROMPT

__all__ = ["HARD_TASK_RE", "HARD_TASK_PROMPT", "JARVIS_TASK_PROMPT"]

