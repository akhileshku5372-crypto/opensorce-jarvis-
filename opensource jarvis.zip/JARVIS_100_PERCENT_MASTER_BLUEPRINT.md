# J.A.R.V.I.S. 100/100 OS & CAPABILITY MASTER BLUEPRINT
**Unified Personal AI Operating System for Windows — Architecture, Upgrades, & Implementation Roadmap**

---

## 1. Executive Architecture & Core Operating Principles

J.A.R.V.I.S. (*Just A Rather Very Intelligent System*) is structured as a **local-first, multi-model, voice-driven AI operating system for Windows**. It unifies conversational reasoning, continuous memory, native desktop automation, computer vision, Android device synchronization, and 3D spatial interfaces into a single coordinated workspace.

```
                      ┌─────────────────────────────────────────────────────────────┐
                      │              J.A.R.V.I.S. DESKTOP WORKSPACE                 │
                      │   (Cyan Reactor Orb + Dark-Glass HUD + 3D Holographic UI)   │
                      └──────────────────────────────┬──────────────────────────────┘
                                                     │ HTTP / WebSockets (Loopback 127.0.0.1)
           ┌─────────────────────────────────────────┴─────────────────────────────────────────┐
           ▼                                                                                   ▼
┌───────────────────────────────────────┐                                   ┌───────────────────────────────────────┐
│     HONO / VITE EDGE UI (:7777)       │                                   │    OS ACTION BRIDGE (:7778)           │
│  - Reactive Dashboard & Panels        │                                   │  - Allowlisted Windows Actions        │
│  - Multi-Lobe Brain Hologram (ThreeJS)│                                   │  - App Launchers & File Handlers      │
│  - MediaPipe Vision / Camera Canvas   │                                   │  - PyAutoGUI / Native Input Dispatch  │
│  - Conversation & History Store       │                                   │  - Strict Loopback Security           │
└──────────────────┬────────────────────┘                                   └──────────────────┬────────────────────┘
                   │                                                                           │
                   └─────────────────────────────────┬─────────────────────────────────────────┘
                                                     │ Internal State RPC (:7780)
                                                     ▼
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                           CANONICAL VOICE & COGNITIVE CORE (background/voice_engine.py)                           │
│  - Single Voice Engine: WebSpeech + Edge-TTS + Whisper | Continuous Hands-Free Wake Window                         │
│  - Split-Brain Router: Prefrontal Cortex, Cerebrum, Hippocampus, Creative Lobe across 204 Free Models              │
│  - Multi-Provider Adapter: Google Gemini, Groq, NVIDIA NIM, OpenRouter, Ollama (Local)                            │
│  - Long-Term Vector Memory: ChromaDB Semantic Store + Persistent Conversation DB                                 │
│  - Safe Cortex Tool Registry: Gated Approvals, Destructive Action Confirmation, Single-Use Tokens                 │
│  - Floating Companion Watchdog: floating_ui.pyw (UDP 7781) + Win32 Global Hotkey (Ctrl+Shift+J)                   │
└────────────────────────────────────────────────────┬──────────────────────────────────────────────────────────────┘
                                                     │
      ┌──────────────────────────────────────────────┼──────────────────────────────────────────────┐
      ▼                                              ▼                                              ▼
┌───────────────────────────┐          ┌───────────────────────────┐          ┌───────────────────────────┐
│    DESKTOP AGENT (ACI)    │          │    ANDROID ADB BRIDGE     │          │    KNOWLEDGE & RAG CORE   │
│ - Agent-S UI Grounding    │          │ - Wireless / USB ADB Sync │          │ - ChromaDB Semantic Store │
│ - PyAutoGUI Coordinates   │          │ - App Control & Dialing   │          │ - PyMuPDF & Docx Parsers  │
│ - Local Screen OCR        │          │ - 2GB SHA-256 File Push   │          │ - Firecrawl Deep Dossier  │
│ - Window & System Controls│          │ - Clipboard & Notification│          │ - Windows Desktop Indexer │
└───────────────────────────┘          └───────────────────────────┘          └───────────────────────────┘
```

### Strict Architectural Invariants (Karpathy-Inspired):
1. **Single Canonical Voice Runtime**: [voice_engine.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/voice_engine.py) remains the sole microphone, TTS, and agent loop. No secondary mic threads or phantom engines.
2. **Strict Loopback Binding**: Every service (`:7777` UI, `:7778` Bridge, `:7780` Core, `:7781` HUD UDP) binds exclusively to `127.0.0.1`.
3. **Safety & Confirmation Gates**: Any destructive action (deleting files, executing shell commands, external outbound messages/calls) requires explicit user approval (`requires_confirmation=True`).
4. **Honest Capability Reporting**: Capabilities report strictly **LIVE** (executable now), **READY** (code exists, awaiting user trigger/key), or **BLOCKED** (missing prerequisite).

---

## 2. All 50 Catalog Capabilities: Path to 100/100 LIVE State

| # | Capability ID | Name | Category | Current Status | 100/100 Upgrade Plan & Technical Implementation | Required Packages / Dependencies |
|---|---|---|---|:---:|---|---|
| 1 | `brain_split` | Split-Brain Router | Core | **READY** | Dynamically routes queries across 204 free models by cognitive lobe: Prefrontal (reasoning: Qwen-2.5/Llama-3.3), Creative (Gemini/Mistral), Hippocampus (ChromaDB), Motor (OS Executor). Live when primary provider resolves. | `requests`, `google-genai` |
| 2 | `whatsapp-matrix` | WhatsApp Matrix | Comms | **READY** | Dual-mode: Outbound desktop URI (`whatsapp://send`) + Playwright persistent profile session ([whatsapp_web.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/whatsapp_web.py)) for unread chat listening and voice-approved replies. | `playwright` (Chromium profile) |
| 3 | `n8n-hooks` | n8n Workflow Hooks | Comms | **READY** | Trigger and monitor local or cloud n8n workflows via webhook endpoints (`/n8n/workflow`). Probe checks local port 5678 or configured `N8N_WEBHOOK_URL`. | `requests`, n8n local instance |
| 4 | `image-gen` | Local Image Gen | Media | **READY** | GPU text-to-image via Diffusers (SDXL-Turbo / SD 1.5) or Automatic1111/ComfyUI local API, with instant fallback to Google Imagen 3 via Gemini API. | `diffusers`, `torch`, or ComfyUI |
| 5 | `video-editor` | Video Auto-Editor AI | Media | **READY** | Silence cutting via FFmpeg + auto-transcription and subtitle generation via `faster-whisper` + visual scene labeling via perception model. | `ffmpeg-python`, `faster-whisper` |
| 6 | `adb-sync` | ADB Mobile Sync | Devices | **BLOCKED** | Direct Android bridge using `adb` binary: scan connected USB/Wi-Fi devices, launch phone apps, trigger calls, ring phone, and check battery. | `pure-python-adb` or `adb` CLI |
| 7 | `market-weather` | Market & Weather | Info | **READY** | Real-time weather via Open-Meteo API + financial stock tickers via `yfinance`. Spoken briefings on morning wake word. | `yfinance`, Open-Meteo (zero key) |
| 8 | `agent-flow` | Agent Flow Builder | Agents | **READY** | Visual node-based multi-agent execution graphs running on top of [cortex.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/cortex.py). State synchronized with UI canvas. | Built-in [agent_flow.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/agent_flow.py) |
| 9 | `triposr` | TripoSR 3D Generator | Media | **BLOCKED** | Single-image to 3D textured mesh generation using TripoSR / InstantMesh weights, outputting `.obj`/`.gltf` into `artifacts/3d/` for WebGL display. | `torch`, `trimesh`, `einops` |
| 10 | `calling-relay` | Calling Agent Relay | Comms | **READY** | Windows `tel:` URI trigger + Android phone ADB dialer + LiveKit / Twilio voice stream SIP connector. | Windows Shell / Android ADB |
| 11 | `mcp` | MCP & Connectors | Agents | **LIVE** | Model Context Protocol client connecting to local MCP servers (Gemini docs, Chrome DevTools, Filesystem). | Built-in `background/mcp_client.py` |
| 12 | `browser-ext` | Browser Ext Bridge | Web | **LIVE** | WebSocket bridge connecting Chrome/Edge side panel to JARVIS core for current DOM reading and tab control. | Native WebSocket server (`:7778`) |
| 13 | `snapshots` | Screenplay v2 | Vision | **LIVE** | Full multi-monitor screen capture, UI bounding box grounding, and VLM comprehension via Gemini/Qwen-VL. | `pillow`, `mss` |
| 14 | `ocr` | OCR Everywhere | Vision | **LIVE** | Dual-engine OCR: Digital PDF vector text via PyMuPDF (`fitz`) + raster screen/scanned text via `pytesseract`. | `PyMuPDF`, `pytesseract`, Tesseract |
| 15 | `alerts` | Focused Alert Engine | Info | **READY** | Windows Toast notifications (`win10toast` / PowerShell) + chime sounds + calendar priority wakeups. | `win10toast` or Windows Shell |
| 16 | `research-dossier` | Deep Research Dossier | Info | **LIVE** | Multi-source deep web search via Firecrawl API, markdown report formatting, citation verification, and auto-download. | `requests`, `FIRECRAWL_API_KEY` |
| 17 | `data-forge` | Data Forge | Data | **BLOCKED** | Structured tabular/relational dataset generation: converts unstructured files into clean `.csv`, `.parquet`, or `.jsonl` datasets using DuckDB and Polars. | `duckdb`, `polars`, `pyarrow` |
| 18 | `coding-agent` | Repo-Aware Coding | Agents | **LIVE** | Reads repository files, performs AST analysis, writes verified unified diffs, runs tests, and creates git commits. | Built-in [os_executor.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/os_executor.py) |
| 19 | `experiments` | Experimentation Env | Data | **READY** | Sandboxed execution of Python snippets, data science notebooks, and parameter benchmark loops in `scratch/`. | Built-in sandboxed runner |
| 20 | `agi-scaffold` | AGI-Oriented Scaffold | Agents | **LIVE** | Dynamic agent coordinator over extensions and plugins, delegating complex multi-domain tasks to sub-agents. | Built-in [agent_flow.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/agent_flow.py) |
| 21 | `automation` | Automation Studio | Automation | **READY** | Saved multi-step voice macros, conditional workflows, and automated cron triggers managed in [scheduler_core.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/scheduler_core.py). | Built-in [scheduler_core.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/scheduler_core.py) |
| 22 | `voice-bio` | Voice Bio Auth | Privacy | **BLOCKED** | Speaker recognition using MFCC voice embeddings (`speechbrain` or `pyAudioAnalysis`). Matches speaker against user voiceprint before privileged commands. | `speechbrain`, `torchaudio` |
| 23 | `telemetry` | Battery & Telemetry | System | **LIVE** | Real-time monitoring of CPU, RAM, battery charge/health, disk I/O, process count, and GPU temperatures. | `psutil`, `wmi` |
| 24 | `desktop-gui` | Desktop GUI Control | System | **LIVE** | Agent-S style Agent-Computer Interface: VLM screen element grounding + PyAutoGUI mouse click and keyboard input. | `pyautogui`, `screen_agent.py` |
| 25 | `deep-research` | Deep Research Mode | Info | **LIVE** | Iterative, autonomous multi-query web research loop synthesizing 10+ sources with confidence scoring. | Built-in `content_writer.py` |
| 26 | `wellness` | Wellness Coach | Health | **READY** | Posture alerts, 20-20-20 screen break reminders, hydration prompts, and ambient breathing guidance based on screen time. | Built-in `focus_analytics.py` |
| 27 | `fight-fitness` | Fight-Fitness Coach | Dream | **DREAM → LIVE** | Computer vision workout tracker: MediaPipe Pose landmark detection to count exercise reps (push-ups, squats, punches) and score form in real-time. | `mediapipe`, `opencv-python` |
| 28 | `mind-palace` | Mind Palace Knowledge | Dream | **DREAM → LIVE** | Interactive 3D spatial knowledge graph (Three.js Force Graph) visualizing concepts, connected documents, and memories as navigable nodes. | Three.js 3D Force Graph |
| 29 | `osho` | Osho Wisdom Module | Dream | **DREAM → LIVE** | Philosophical reasoning lobe trained on meditation, mindfulness, and stoic principles for reflective and grounded conversation. | Specialized system prompt & lobe |
| 30 | `soft-hard` | Soft & Hard Tracks | Data | **READY → LIVE** | Pre-authored modular curriculums for public speaking, negotiation, psychological assertiveness, and technical coding tracks. | Markdown syllabus in `skills/` |
| 31 | `reality-sandbox` | Reality Sandbox | Dream | **DREAM → LIVE** | Simulation environment: Run simulated multi-agent market, business, or scenario models with step-by-step state outcomes. | SimPy / Agent-based Python engine |
| 32 | `agent-bus` | Non-AI Agent Bus | Agents | **READY** | Standardized REST / WebSocket pub-sub bus allowing external non-AI tools (Python scripts, curl, webhooks) to invoke JARVIS actions. | Built-in state HTTP server |
| 33 | `distributed-mesh` | Distributed Mesh | Agents | **BLOCKED** | Peer-to-peer device mesh sharing compute and clipboard between multiple PCs and Android devices over local Wi-Fi. | WebRTC / ZeroMQ |
| 34 | `command-composer` | Command Composer | Automation | **READY** | Visual and voice macro builder chaining OS actions, web searches, and file edits into one-word trigger words. | Built-in [scheduler_core.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/scheduler_core.py) |
| 35 | `multi-cam` | Multi-Cam Avionics | Vision | **READY** | Dual-camera switching (e.g. front webcam + desk/overhead document camera) with synchronized video stream capture. | Browser WebRTC MediaDevices |
| 36 | `scheduler` | Scheduler Core | Automation | **LIVE** | Precision cron scheduling for delayed voice tasks, morning alarms, recurring briefs, and calendar checks. | Built-in [scheduler_core.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/scheduler_core.py) |
| 37 | `context-keeper` | Context Keeper | Agents | **READY** | Tracks active multi-step goals, unfinished tasks, and pending user decisions across app restarts. | Built-in [cowork_runtime.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/cowork_runtime.py) |
| 38 | `smart-home` | Smart Home Hooks | Devices | **BLOCKED** | Home Assistant REST / WebSocket integration controlling smart bulbs, plugs, thermostats, and scenes by voice. | `requests`, Home Assistant API |
| 39 | `clipboard-mesh` | Shared Clipboard | Devices | **READY** | Real-time clipboard sync between Windows desktop and Android phone via ADB or local LAN socket. | `pyperclip`, ADB |
| 40 | `doc-parliament` | Document Parliament | Data | **READY** | Multi-document cross-synthesis: Compare 3+ PDFs/contracts simultaneously and highlight contradictions or commonalities. | ChromaDB RAG + PyMuPDF |
| 41 | `multi-profile` | Multi-Profile | Privacy | **READY** | Distinct permission and voice profiles: "Standard", "Work/Strict", "Developer/Permissive", and "Battle Mode". | Built-in [permissions.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/permissions.py) |
| 42 | `bot-builder` | Custom Bot Builder | Agents | **BLOCKED** | Visual creation of custom agent personalities with assigned tools, system prompts, and floating desktop widget icons. | Dynamic Agent Generator |
| 43 | `dock` | Floating Dock Omni | System | **LIVE** | Cyan floating reactor orb with dark-glass console ([floating_ui.pyw](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/floating_ui.pyw)), UDP single-instance guard, and `Ctrl+Shift+J` global hotkey. | `tkinter`, Win32 `RegisterHotKey` |
| 44 | `focus-analytics` | Focus Analytics | System | **READY** | Tracks active foreground window application names and generates daily focus percentage graphs. | `win32gui`, `psutil` |
| 45 | `clip-studio` | Clip Studio Suite | Media | **READY** | Screen region snip, instant side-by-side visual difference comparison, and visual annotations. | `Pillow`, `screen_agent.py` |
| 46 | `ambient-noise` | Ambient Noise Radar | System | **READY** | Microphone RMS audio monitoring to adapt TTS volume and pause wake listening during loud ambient music. | Web Audio API / PyAudio |
| 47 | `launchpad` | Launchpad Live | System | **LIVE** | Scans Windows Start Menu, Desktop `.lnk` shortcuts, and App Paths for instant keyboard/voice application launching. | Built-in [app_index.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/app_index.py) |
| 48 | `privacy-vault` | Privacy Vault | Privacy | **READY** | Windows DPAPI encrypted credential vault storing API keys, OAuth tokens, and passwords securely on disk. | `pywin32` (`win32crypt`), `keyring` |
| 49 | `presentation-builder` | PowerPoint Generator | Media | **LIVE** | Generates fully formatted `.pptx` presentations with structured slide themes, bullet hierarchy, speaker notes, and PowerPoint launch. | `python-pptx` |
| 50 | `proactive-sentinel`| Proactive Sentinel | Core | **LIVE** | Autonomous background monitor notifying user of critical battery levels, upcoming calendar events, and memory highlights. | Background daemon thread |

---

## 3. Implementation of the J.A.R.V.I.S. Windows AI Operating System

### A. Chat with Files & Personal Knowledge (RAG Engine)
- **Vector Storage**: Uses the persistent ChromaDB collection in `background/conversation_memory.py`.
- **Supported Formats**:
  - PDF: PyMuPDF (`fitz`) for fast text and table extraction.
  - Documents: `python-docx` for `.docx` and built-in text chunking for `.txt`, `.md`, `.json`, `.csv`.
  - Code: Treesitter / regex chunker for `.py`, `.js`, `.ts`, `.cpp`, `.html`.
- **Knowledge Retrieval Workflow**:
  1. User specifies folder (e.g. `C:\Users\PRATEEK\Documents` or project directory).
  2. Recursive scanner indexes documents, generates embeddings via Gemini `text-embedding-004` or local sentence-transformers, and saves to ChromaDB.
  3. Natural language query triggers semantic top-k retrieval before generating the grounded answer with exact file/line citations.

### B. Long-Term Memory & Continuous Context
- **Memory Protocol**: [memory_protocol.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/memory_protocol.py) monitors every conversation turn.
- **Auto-Learning**: Model outputs containing key user facts (e.g., *"User prefers TypeScript over JavaScript"*, *"Project deadline is Oct 28"*) emit `[LEARN: fact]` tokens.
- **Active Recall**: Relevant past memories are dynamically injected into the model prompt when answering new queries.

### C. Hands-Free Conversational Voice System
- **Speech-to-Text (STT)**: Web Speech API (in browser) + local Whisper (`whisper-large-v3` via Groq or local `faster-whisper`).
- **Natural Text-to-Speech (TTS)**: Microsoft Edge-TTS streaming (`en-GB-RyanNeural`, the canonical JARVIS voice) on port 7782.
- **Continuous Wake Window**: Once triggered by *"JARVIS"*, a 30-second conversational window remains open so the user can speak follow-ups naturally without repeating the wake word.
- **Instant Spoken Interruption**: Speaking or clicking immediately aborts the active TTS playback thread.

### D. Windows Desktop & Multi-Step Task Automation
- **Native OS Bridge**: [local-bridge/server.cjs](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/local-bridge/server.cjs) executes allowlisted actions:
  - Application lifecycle: `launch_app`, `close_app`, `focus_window`.
  - System controls: volume up/down/mute, display brightness, lock workstation, take screenshot.
  - File management: open folder, reveal in Explorer, open document in default application.
- **Agent-S GUI Computer-Use**: [screen_agent.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/screen_agent.py) takes full desktop control for third-party software (Photoshop, Excel, VS Code, Browser):
  - `gui_locate_and_click(element)`: Locates UI buttons visually or by label and performs precise coordinate clicks.
  - `gui_type_into(field, text)`: Enters text into targeted input boxes.
  - `gui_read_screen_region(bbox)`: Reads dynamic screen text via OCR.

### E. Multi-Model Intelligence Routing
- Seamlessly switches between:
  - **Cloud Super-Models**: Google Gemini 2.5 Pro / Flash, OpenAI GPT-4o, Anthropic Claude 3.5 Sonnet (via OpenRouter), Groq Llama-3.3-70B.
  - **Local Private Models**: Local Ollama (Llama-3.2, Qwen-2.5-Coder, DeepSeek-R1) for 100% offline privacy without internet connectivity.

---

## 4. Implementation of the JARVIX Personal AI Feature Suite

### A. Jarvix Brain — Local Fast Intent Classifier
- **Fuzzy Intent Matching**: Integrated using `rapidfuzz` to evaluate user spoken commands against known patterns in <5 milliseconds before contacting any cloud LLM.
- **Synonym Recognition**: Maps commands like *"shut the music"*, *"hush"*, *"stop sound"* directly to `media_pause`.
- **Zero API Key Operation**: Base desktop actions function 100% offline without third-party API keys.

### B. Multilingual Voice & UI Localization
- **Supported Languages**: English, Hindi, Hinglish, Spanish, Portuguese, Turkish, French, German.
- **Edge-TTS Voice Matching**:
  - English: `en-GB-RyanNeural`
  - Hindi: `hi-IN-MadhurNeural` / `hi-IN-SwaraNeural`
  - Portuguese: `pt-BR-AntonioNeural`
  - Turkish: `tr-TR-AhmetNeural`
- **Dynamic Language Detection**: Spoken language is identified on the fly and matches the spoken audio response.

### C. Apps Connect — Read-Only Gmail Integration
- **OAuth2 Token Storage**: Tokens encrypted via **Windows Data Protection API (DPAPI)** using `win32crypt` (`CryptProtectData`).
- **Capabilities**:
  - Check unread email count: *"JARVIS, how many unread emails in Gmail?"*
  - Read top 5 recent subjects: *"JARVIS, read my latest email subjects."*
  - Read full latest email aloud: *"JARVIS, read the latest email from Alex."*
  - Check drafts and connection status.
- **Security**: Strictly read-only (`gmail.readonly` scope); cannot send, alter, or delete messages without user re-authorization.

### D. Windows & Android Connectivity via ADB Companion Bridge
- **Communication Layer**: Direct USB or Wireless ADB (`adb connect <ip>:5555`) using `pure-python-adb`.
- **Supported Android Controls**:
  - Launch/kill apps: `adb shell monkey -p <package> 1` or `adb shell am force-stop <package>`
  - Call contact: `adb shell am start -a android.intent.action.CALL -d tel:<number>`
  - Ring/locate phone: Triggers maximum alarm volume and sound playback.
  - Set alarms & timers: `adb shell am start -a android.intent.action.SET_ALARM`
  - Phone media controls: `adb shell input keyevent 85` (Play/Pause), `87` (Next), `88` (Previous).
  - Check battery level: `adb shell dumpsys battery`.
- **Secure File Sharing (Up to 2GB)**:
  - Single-command transfer: `adb push <local_file> /sdcard/Download/Jarvix/`
  - Integrity Verification: Local and remote SHA-256 hash calculated via `certutil` and `adb shell sha256sum`.
  - Progress tracking with desktop notification on completion.

### E. Smart Desktop App & File Access
- **Instant Desktop Indexing**: Scans `C:\Users\PRATEEK\Desktop` and Start Menu programs.
- **Direct Voice Invocation**: *"JARVIS, open Excel"*, *"JARVIS, open my project notes"* resolves exact shortcut targets (`.lnk`, `.url`, `.exe`).

### F. System Diagnostics & Real-Time Telemetry
- **Hardware Telemetry Engine**: [telemetry.py](file:///c:/Users/PRATEEK/Desktop/jarvis-2.0/background/telemetry.py) monitors:
  - CPU usage, per-core utilization, clock frequency.
  - RAM total, used, and memory leak warnings.
  - Battery charge percentage, charging status, battery health.
  - Storage drive free space across `C:` and external disks.
  - GPU load and temperature via Nvidia NVML (`pynvml`).

### G. Current Location Services
- **Location Engine**: Queries Windows Geolocation API via PowerShell `System.Device.Location.GeoCoordinateWatcher` with fallback to IP-API.
- **Use Cases**: Live local weather alerts, sunrise/sunset times, and commute estimations.

### H. Personalization, Custom Greetings & Code Red Mode
- **Custom Greetings**: Personalized greeting based on time of day (e.g. *"Good evening, Sir. All systems operational."*).
- **Code Red Battle State**:
  - Voice command: *"JARVIS, initiate Code Red"*
  - UI transformation: Ambient cyan lighting shifts to crimson red (`#FF1E27`).
  - System response: Maximizes telemetry sampling, closes non-essential background applications, and switches to high-priority alertness mode.

### I. Battle Mode & 3D Armour Exploration
- **3D Armor Studio**: Embedded WebGL Three.js interactive viewport displaying 3D Iron Man Mark armor models (`.gltf` / `.obj`).
- **Interactive Capabilities**:
  - 360-degree orbital rotation and zoom.
  - Blueprint wireframe view mode with component callouts (Arc Reactor, Repulsor, Flight Stabilizers).
  - Gesture control: MediaPipe hand tracking allows panning and rotating the 3D suit with open palm / pinch gestures in front of the webcam.

---

## 5. Technology Stack & GitHub Open Source Reference Repositories

| Domain | Open Source Reference Repository / Package | Purpose in JARVIS | License |
|---|---|---|:---:|
| **Desktop Computer Use** | [simular-ai/Agent-S](https://github.com/simular-ai/Agent-S) | VLM screen grounding, ACI interface, coordinate clicks | Apache 2.0 |
| **Presentation Generation** | [imranshiundu/Jarvis](https://github.com/imranshiundu/Jarvis) + `python-pptx` | Automated PowerPoint slide deck generation | MIT |
| **WhatsApp Automation** | [tridibsamanta/WhatsAppChatBot](https://github.com/tridibsamanta/WhatsAppChatBot) + Playwright | Persistent headless session for unread chat reading | MIT |
| **Android ADB Control** | [pure-python-adb](https://github.com/swind/pure-python-adb) | Direct Python client for USB/Wi-Fi Android phone commands | MIT |
| **Local LLM Execution** | [ollama/ollama](https://github.com/ollama/ollama) | Zero-cloud, 100% private local model inference | MIT |
| **Voice Audio Synthesis** | [rany2/edge-tts](https://github.com/rany2/edge-tts) | Real-time British neural voice streaming (`en-GB-RyanNeural`) | GPL-3.0 |
| **Document RAG & Vector DB** | [chroma-core/chroma](https://github.com/chroma-core/chroma) | Semantic embeddings and long-term memory retrieval | Apache 2.0 |
| **PDF Extraction** | [pymupdf/PyMuPDF](https://github.com/pymupdf/PyMuPDF) | High-speed PDF text, layout, and table extraction | AGPL |
| **Desktop Vision & Gestures**| [google-ai-edge/mediapipe](https://github.com/google-ai-edge/mediapipe) | Real-time hand landmark tracking and gesture recognition | Apache 2.0 |
| **Windows DPAPI Security** | `pywin32` (`win32crypt`) | Enterprise-grade encrypted credential and token storage | PSF |
| **3D Hologram & Armor UI** | [mrdoob/three.js](https://github.com/mrdoob/three.js) | WebGL rendering of neural brain and 3D armor models | MIT |

---

## 6. Comprehensive Phased Execution Roadmap

```
PHASE 1: Core Foundation & Desktop GUI (COMPLETED)
  ✅ 1.1 Agent-S screen grounding & coordinate clicker (background/screen_agent.py)
  ✅ 1.2 Automated PowerPoint builder with themes & verification (background/presentation_builder.py)
  ✅ 1.3 Bi-directional WhatsApp session manager (background/whatsapp_web.py)
  ✅ 1.4 Floating HUD watchdog with global Ctrl+Shift+J hotkey (background/floating_ui.pyw)
  ✅ 1.5 Strict communication confirmation gate enforcement (extensions/permissions.json)

PHASE 2: Document RAG & Knowledge Core (P1)
  ├── 2.1 Indexing pipeline: PyMuPDF + python-docx parser for Desktop/Documents
  ├── 2.2 Semantic search endpoint /rag/query wired to ChromaDB collection
  ├── 2.3 Citation formatter: Returns exact document name, page, and excerpt
  └── 2.4 Voice search trigger: "JARVIS, search my documents for [topic]"

PHASE 3: Android ADB Sync & File Sharing (P1)
  ├── 3.1 pure-python-adb client wrapper in background/android_sync.py
  ├── 3.2 Phone controls: launch apps, trigger calls, ring phone, check battery
  ├── 3.3 2GB high-speed file transfer with SHA-256 verification
  └── 3.4 Android notification and clipboard synchronization

PHASE 4: Apps Connect (Gmail & Calendar) (P2)
  ├── 4.1 Read-only Gmail API client with DPAPI credential encryption
  ├── 4.2 Vocal email reader: unread count, top 5 subjects, read latest message
  ├── 4.3 Google Calendar daily agenda briefing
  └── 4.4 Confirmation gate before opening or responding to any email

PHASE 5: 3D Armour Exploration & Code Red Mode (P2)
  ├── 5.1 Three.js 3D Mark VII / Mark 85 armor model viewer in dashboard
  ├── 5.2 MediaPipe gesture integration (pinch to zoom, palm to rotate armor)
  ├── 5.3 Blueprint technical view with armor subsystem breakdown
  └── 5.4 Code Red visual transformation (cyan -> crimson) with prioritized alerts

PHASE 6: 100/100 Capability Matrix Verification (P3)
  ├── 6.1 Drop soft/hard skill tracks into skills/communication-psychology/
  ├── 6.2 Wire DuckDB data-forge dataset generator (.csv / .parquet)
  ├── 6.3 MediaPipe Pose coach for fight-fitness exercise repetition counter
  └── 6.4 Validate all 50 capability cards report LIVE state in capability_registry.py
```

---
*Created and saved to workspace root as `JARVIS_100_PERCENT_MASTER_BLUEPRINT.md`.*
