// Live DOM proof for the Skill Library surface. Two rules came straight from the
// owner on 2026-10-21:
//   "ui ko niche tak expand karo"  - the archive must not leave an empty band
//                                    under it (.workspace reserves 120px for the
//                                    chat dock, which is exactly what he saw).
//   "skill library ka option remove karo, kyuki ye sirf soft and hard skill
//    ke card pe click karne pe open honi chiaye" - no sidebar entry.
// The measurement is the point: a hardcoded calc() cannot know the topbar height,
// so this test reads the real rects.
//
// Requires the running stack (vite :7777 + voice core :7780 for /modules).
// Run: node tests/test_library_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'

const UI = 'http://127.0.0.1:7777/'
const CORE = 'http://127.0.0.1:7780'
const PORT = 9227
const profile = mkdtempSync(`${tmpdir()}\\jarvis-library-ui-`)
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { }
  try { rmSync(profile, { recursive: true, force: true }) } catch { }
}
setTimeout(() => { cleanup(); process.exit(124) }, 600000).unref()

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

const CLICK_SKILL_CARD = `(() => {
  const c = [...document.querySelectorAll('.module-card-live')]
    .find((x) => (x.dataset.launch || '').includes('"view":"library"'))
  if (!c) return 'NO SKILL CARD'
  c.click()
  return c.dataset.moduleId
})()`

const PROBE = `(() => {
  const root = document.getElementById('library-root')
  const view = document.querySelector('.view[data-view-panel="library"]')
  const ws = document.querySelector('.workspace')
  const nav = document.querySelector('.nav-item[data-view="library"]')
  const bar = document.querySelector('.topbar')
  if (!root || !view) return { exists: false }
  const r = root.getBoundingClientRect()
  const b = bar ? bar.getBoundingClientRect() : { bottom: 0 }
  const cs = getComputedStyle(root)
  return {
    exists: true,
    active: view.classList.contains('active'),
    // Layout viewport, not innerWidth: innerWidth counts the 15px classic
    // scrollbar gutter, which nothing can be compared against honestly.
    clientH: document.documentElement.clientHeight,
    top: Math.round(r.top),
    bottom: Math.round(r.bottom),
    height: Math.round(r.height),
    barBottom: Math.round(b.bottom),
    gapBelow: Math.round(document.documentElement.clientHeight - r.bottom),
    workspacePad: ws ? Math.round(parseFloat(getComputedStyle(ws).paddingBottom) || 0) : -1,
    navDisplay: nav ? getComputedStyle(nav).display : 'absent',
    // The zip's own CSS tried to hijack the dashboard shell.
    bodyOverflow: getComputedStyle(document.body).overflow,
    shellScroll: document.documentElement.scrollHeight - document.documentElement.clientHeight,
    mounted: typeof window.__JARVIS_LIBRARY__ === 'object' && window.__JARVIS_LIBRARY__ !== null,
    html: (root.innerHTML || '').length,
    clock: (() => {
      const el = [...root.querySelectorAll('*')].find((x) => /^\\d{1,2}:\\d{2}$/.test((x.textContent || '').trim()) && x.childElementCount === 0)
      return el ? el.textContent.trim() : null
    })()
  }
})()`

async function main() {
  let page = null
  for (let i = 0; i < 40 && !page; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) { const j = await res.json(); if (j?.webSocketDebuggerUrl) page = j }
    } catch { }
    await wait(400)
  }
  if (!page) throw new Error('no CDP page target')

  const ws = new WebSocket(page.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
  let id = 0
  const pending = new Map()
  const problems = []
  const reqs = new Map()
  const net = {}
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      problems.push((m.params.args || []).map((a) => a.value || a.description || '').join(' '))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      problems.push([m.params.entry.url || '', m.params.entry.text].join(' '))
    }
    // Which core endpoints the desk really called, with the real status.
    if (m.method === 'Network.requestWillBeSent') {
      reqs.set(m.params.requestId, { url: m.params.request.url, method: m.params.request.method })
      const hit = /\/library\/(shelf|chapter|ask|speak)$/.exec((m.params.request.url || '').split('?')[0])
      // Record the request as soon as it leaves, so "the desk never asked" and
      // "the pool is still thinking" are two different, honest results.
      if (hit && m.params.request.method !== 'OPTIONS') net[`/library/${hit[1]}`] = { status: 0, type: '', pending: true }
    }
    if (m.method === 'Network.responseReceived') {
      const info = reqs.get(m.params.requestId) || {}
      // The CORS preflight answers 204 for the same URL; recording it would hide
      // the real POST's status.
      if (info.method === 'OPTIONS') return
      const u = m.params.response.url || info.url || ''
      const hit = /\/library\/(shelf|chapter|ask|speak)$/.exec(u.split('?')[0])
      if (hit) {
        net[`/library/${hit[1]}`] = {
          status: m.params.response.status,
          type: m.params.response.mimeType || '',
          bytes: Math.round((m.params.response.encodingLength || 0)),
          pending: false,
        }
      }
    }
  })
  const send = (method, params = {}) => new Promise((r) => {
    const mid = ++id
    pending.set(mid, r)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })
    return r.result && r.result.result ? r.result.result.value : undefined
  }

  await send('Page.enable')
  await send('Runtime.enable')
  await send('Log.enable')
  await send('Network.enable')
  await send('Page.navigate', { url: UI })
  await wait(6000)

  // 1. No sidebar entry - the archive is opened from the card and nowhere else.
  const navNote = await evaluate(`(() => {
    const nav = document.querySelector('.nav-item[data-view="library"]')
    return nav ? getComputedStyle(nav).display : 'absent'
  })()`)
  if (navNote === 'none' || navNote === 'absent') ok(`no "Skill Library" in the sidebar (${navNote})`)
  else bad(`the sidebar still shows Skill Library (display=${navNote}) - he asked to remove it`)

  // 2. The only way in: Modules & Upgrades -> Soft & Hard Skill card.
  // /modules cold-probes 52 subsystems and can take ~20s after a core restart; the
  // dashboard then honestly says "the core did not answer in 30s" and no cards
  // paint. So the harness warms the probe itself, then polls, then presses the
  // page's own Re-probe button before calling it a failure.
  for (let i = 0; i < 30; i++) {
    try {
      const r = await fetch(`${CORE}/modules`, { signal: AbortSignal.timeout(45000) })
      if (r.ok) { const j = await r.json(); if ((j.capabilities || []).length) break }
    } catch { }
    await wait(2000)
  }
  await evaluate(`document.querySelector('[data-view="modules"]')?.click()`)
  let cards = 0
  for (let i = 0; i < 40 && !cards; i++) {
    cards = await evaluate(`document.querySelectorAll('.module-card-live').length`)
    if (!cards && i === 12) await evaluate(`document.querySelector('#modules-refresh')?.click()`)
    if (!cards) await wait(2000)
  }
  if (!cards) { cleanup(); throw new Error('module cards never rendered even after Re-probe, so the card click cannot be tested') }
  const clicked = await evaluate(CLICK_SKILL_CARD)
  if (clicked === 'NO SKILL CARD') { cleanup(); throw new Error('no card launches the library view - the registry LAUNCH table lost "soft-hard"') }
  await wait(1500)
  const landed = await evaluate(`(document.querySelector('.view.active')||{}).dataset?.viewPanel || null`)
  if (landed !== 'library') bad(`card ${clicked} landed on view "${landed}" instead of the library`)
  else ok(`card ${clicked} opened the Skill Library view`)

  // 3. Wait for the lazy bundle to mount, then measure the fill.
  let p = { exists: true, mounted: false }
  for (let i = 0; i < 60 && !p.mounted; i++) {
    p = await evaluate(PROBE)
    await wait(1000)
  }
  if (!p.exists) { cleanup(); throw new Error('#library-root is missing from the DOM') }
  if (!p.mounted) bad('the library bundle never mounted window.__JARVIS_LIBRARY__')
  else ok(`bundle mounted (${p.html} chars of markup inside the card)`)

  if (p.height < 400) bad(`the archive is only ${p.height}px tall - it collapsed instead of filling`)
  else ok(`archive box height ${p.height}px (topbar ends at y=${p.barBottom})`)
  // The fix being pinned: "why empty wali jaga, kyu khali hai ui ko niche tak
  // expand karo". A band of more than 24px is the bug he pointed at.
  if (p.gapBelow > 24) bad(`${p.gapBelow}px of empty band left under the archive (bottom=${p.bottom}, viewport=${p.clientH})`)
  else ok(`archive reaches the bottom: gapBelow=${p.gapBelow}px`)
  if (p.workspacePad !== 0) bad(`.workspace still reserves ${p.workspacePad}px of dock padding under the archive`)
  else ok('.workspace dock padding released for this view')
  if (p.shellScroll > 0) bad(`page scrolls ${p.shellScroll}px - the band was pushed below the fold, not removed`)
  else ok('no page scroll, the fill is real')
  if (p.bodyOverflow === 'hidden') bad('the zip CSS hijacked body overflow again - the dashboard would freeze')
  else ok(`body overflow untouched (${p.bodyOverflow || 'visible'})`)

  // 4. The fake clock that shipped in the zip must not survive.
  if (p.clock === '16:42') bad('the hardcoded 16:42 clock from the zip is back')
  else ok(`clock reads ${p.clock || '(none in DOM)'}, not the baked-in 16:42`)

  // 5b. The build stamp must be visible ON SCREEN. Without it a stale tab is
  // invisible, and "maine bola tha, kuch nahi badla" becomes unarguable - which
  // is exactly what happened on 2026-10-22.
  // The loader lives in app.js, which is shared with another session's in-flight
  // work, so this asserts the badge only when that code is actually present.
  const appSrc = await fetch(`${UI}static/app.js`, { cache: 'no-store' }).then((r) => r.text()).catch(() => '')
  const served = await fetch(`${UI}static/library/build.json`, { cache: 'no-store' }).then((r) => r.json()).catch(() => null)
  if (!appSrc.includes('library-build-badge')) {
    ok('build badge not asserted: app.js on disk has no badge loader yet')
  } else if (!served || !served.stamp) {
    bad('build.json is missing, so a stale tab cannot be detected')
  } else {
    const badge = await evaluate(`(document.querySelector('.library-build-badge')||{}).textContent || ''`)
    if (!badge.includes(String(served.stamp))) bad(`the on-screen build badge does not match build.json (badge="${badge}", disk="${served.stamp}")`)
    else ok(`the archive shows which build it is running: ${badge.trim()}`)
  }

  // 6. The desk must be wired to the core, not to the zip's canned answer.
  // One real ask per run: it costs ~900 Radox tokens and it is the only way to
  // prove the passage, not the sample text, reached the model.
  const shelf = await fetch(`${CORE}/library/shelf`).then((r) => r.json()).catch(() => null)
  const live = ((shelf && shelf.books) || []).filter((b) => b.ok && b.readable !== false)
  const links = ((shelf && shelf.books) || []).filter((b) => b.kind === 'link')
  if (!live.length) bad('/library/shelf returned no readable volumes, so the desk cannot be tested')
  else ok(`core shelf reports ${live.length} readable volumes + ${links.length} link cards (${live[0].title.slice(0, 34)}…)`)
  // Every source he named is visible; the ones whose licence refuses storage are
  // link cards that admit it, and none of them pretend to hold text.
  if (links.length && !links.every((l) => l.readable === false && /^https?:/.test(l.url || '') && l.reason)) {
    bad('a link card is missing its readable:false flag, URL or licence reason')
  } else if (links.length) ok(`all ${links.length} link cards carry their URL and the licence reason`)

  const onScreen = await evaluate(`(() => {
    const root = document.getElementById('library-root')
    return (root && root.innerText || '').replace(/\\s+/g, ' ')
  })()`)
  const shown = live.filter((b) => onScreen.includes(String(b.title).slice(0, 18)))
  // Spines are painted on the atrium canvas, so most titles are not DOM text.
  // What must be true: the zip's "No materials yet" empty state is gone, and at
  // least one real shelf title is in the document.
  if (/no materials yet/i.test(onScreen)) bad('the shelf still shows the "No materials yet" empty state')
  else if (!shown.length) bad('no real title from /library/shelf is in the DOM')
  else ok(`real shelf titles painted: ${shown.length}/${live.length} (e.g. ${shown[0].title.slice(0, 30)})`)

  const desk = await evaluate(`(() => {
    const root = document.getElementById('library-root')
    const box = [...root.querySelectorAll('textarea, input[type=text]')]
      .find((e) => /ask|question|read the paragraph/i.test((e.placeholder || '') + ' ' + (e.getAttribute('aria-label') || '')))
    if (!box) return { sent: false, why: 'no ask box found' }
    // The descriptor must come from the element's OWN prototype: calling the
    // textarea setter on an <input> throws "Incompatible receiver".
    const proto = box.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(box, 'What should I do tomorrow, Sir?')
    box.dispatchEvent(new Event('input', { bubbles: true }))
    const btn = [...root.querySelectorAll('button')].find((b) => {
      const l = ((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '') + ' ' + (b.title || '')).toLowerCase()
      return /ask the source|send|submit/.test(l)
    })
    if (btn) { btn.click(); return { sent: true, via: 'button', typed: box.value } }
    box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
    box.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }))
    return { sent: true, via: 'enter', typed: box.value }
  })()`)
  if (!desk.sent) bad(`could not drive the ASK box (${desk.why})`)
  else ok(`question typed and submitted through the desk (${desk.via}, "${desk.typed}")`)

  let deskText = { txt: '', canned: false }
  const t0 = Date.now()
  for (let i = 0; i < 240; i++) {
    await wait(1000)
    deskText = await evaluate(`(() => {
      const root = document.getElementById('library-root')
      const txt = (root && root.innerText || '').replace(/\\s+/g, ' ')
      return { txt: txt.slice(0, 14000), canned: /here are the key insights|KEY POINT \\d/i.test(txt) }
    })()`)
    if (deskText.canned) break
    if (/[·•]\s*Radox|gpt-|not answered|ask failed/i.test(deskText.txt)) break
  }
  const waited = Math.round((Date.now() - t0) / 1000)
  if (deskText.canned) bad('the zip\'s canned "here are the key insights" answer is still painted')
  else ok('no canned insights anywhere on the desk')
  const askNet = net['/library/ask'] || null
  if (!askNet) bad('the desk never even sent a request to /library/ask')
  else if (askNet.pending) bad(`/library/ask was sent but still had not answered ${waited}s later`)
  else if (askNet.status === 200) ok(`/library/ask answered ${askNet.status} from the browser (after ${waited}s)`)
  else ok(`/library/ask answered ${askNet.status} - the desk shows the reason instead of a fake answer`)
  const cited = /[·•]\s*Radox|gpt-|Radox/i.test(deskText.txt)
  const honest = /not answered|ask failed/i.test(deskText.txt)
  if (cited) ok('the answer carries a visible citation naming the engine and the chapter')
  else if (honest) ok('the desk printed the failure reason rather than a made-up answer')
  else bad(`no citation and no failure note landed on the desk in ${waited}s: "${(deskText.txt || '').slice(-200)}"`)

  // 6. Audio goes through the core's edge-tts proxy, never speechSynthesis.
  // Proof is the network: a POST to /library/speak that answers audio/mpeg.
  const spoke = await evaluate(`(() => {
    const root = document.getElementById('library-root')
    const btn = [...root.querySelectorAll('button')].find((b) => {
      const label = ((b.getAttribute('aria-label') || '') + ' ' + (b.title || '') + ' ' + (b.textContent || '')).toLowerCase()
      return /read aloud|speak this|listen|play chapter/.test(label)
    })
    if (!btn) return { found: false }
    btn.click()
    return { found: true, label: (btn.getAttribute('aria-label') || btn.title || btn.textContent || '').trim().slice(0, 30) }
  })()`)
  if (!spoke.found) bad('no read-aloud control found on the desk, so the voice path cannot be proven')
  else {
    // The request is recorded the moment it leaves, so wait for the ANSWER.
    let speakSeen = null
    for (let i = 0; i < 60 && (!speakSeen || speakSeen.pending); i++) {
      await wait(500)
      speakSeen = net['/library/speak'] || null
    }
    if (!speakSeen) bad(`the read-aloud button ("${spoke.label}") never reached /library/speak`)
    else if (speakSeen.pending) bad('/library/speak was sent but never answered within 30s')
    else if (speakSeen.status !== 200) bad(`/library/speak answered ${speakSeen.status}, not 200`)
    else if (!/audio/.test(speakSeen.type)) bad(`/library/speak answered ${speakSeen.type}, not audio`)
    else ok(`read-aloud played real ${speakSeen.type} from the core's edge-tts proxy`)
  }

  // 7. The bundle itself must not carry the zip's fake voice or fake prose.
  const bundleSrc = await fetch(`${UI.replace(/\/$/, '')}/static/library/library-bundle.js`).then((r) => r.text()).catch(() => '')
  if (!bundleSrc) bad('the library bundle could not be fetched, so its contents cannot be checked')
  else {
    if (/speechSynthesis\.speak/.test(bundleSrc)) bad('the bundle still calls the browser speechSynthesis for audio')
    else ok('no speechSynthesis.speak anywhere in the bundle')
    if (/here are the key insights/.test(bundleSrc)) bad('the canned "key insights" answer is still compiled into the bundle')
    else ok('no canned insights compiled into the bundle')
    if (!/library\/ask/.test(bundleSrc) || !/library\/speak/.test(bundleSrc)) bad('the bundle does not call the core desk endpoints')
    else ok('bundle calls /library/ask and /library/speak')
    if (/api\/groq|groq\.com|generativelanguage\.googleapis\.com/.test(bundleSrc)) bad('the bundle reaches for a Groq or Gemini endpoint')
    else ok('no Groq or Gemini endpoint in the bundle')
  }

  // 8. Leaving the view must not leave the archive mounted over anything.
  await evaluate(`document.querySelector('[data-view="dashboard"]')?.click()`)
  await wait(500)
  const afterNav = await evaluate(`(document.querySelector('.view.active')||{}).dataset?.viewPanel || null`)
  if (afterNav !== 'dashboard') bad(`switching to Dashboard left "${afterNav}" active`)
  else ok('switching away returns to the normal dashboard')

  const real = problems.filter((x) => !/favicon|5678|speechSynthesis|autoplay/i.test(x))
  if (real.length) bad(`console was not clean (${real.length}): ${real.slice(0, 2).join(' | ')}`)
  else ok('zero console errors from this surface')
}

try { await main() } catch (err) { bad('harness threw: ' + (err && err.stack ? err.stack : err)) } finally { cleanup() }

console.log('')
console.log(`${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
