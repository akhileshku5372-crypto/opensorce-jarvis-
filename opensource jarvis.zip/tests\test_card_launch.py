"""Every Modules & Upgrades card must declare where it goes.

The owner's complaint: clicking a card did nothing, and several cards describe
something JARVIS already has under another name (the Split-Brain Router card
and the Brain view are the same subsystem; the WhatsApp card reaches a working
WhatsApp sender). So the registry - already the single source of truth for the
page - now carries the launch target for each card, and this test is what keeps
that honest:

  * every card declares a launch, no exceptions;
  * a `view` target must be a view that actually exists in src/index.tsx;
  * a `command` target must be a sentence the engine can act on (non-empty, and
    not a placeholder like "todo");
  * a `url` target must be loopback - a card never sends him to the internet;
  * a card with nothing to open says `none` WITH the reason, and it must be
    BLOCKED: a LIVE card that opens nothing is a dead end, which AGENTS.md
    forbids;
  * only n8n gets a start action, and it is a fixed command with no user input.
"""
import importlib.util
import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


REG = _load("capability_registry")

VIEWS = set(re.findall(r'data-view-panel="([a-z-]+)"',
                       (ROOT / "src" / "index.tsx").read_text(encoding="utf-8")))


class LaunchTableTest(unittest.TestCase):
    def ids(self):
        return {entry[0] for entry in REG.CATALOG}

    def test_every_card_declares_exactly_one_launch_target(self):
        missing = sorted(self.ids() - set(REG.LAUNCH))
        extra = sorted(set(REG.LAUNCH) - self.ids())
        self.assertEqual(missing, [], "cards with no declared target: %s" % missing)
        self.assertEqual(extra, [], "targets for cards that do not exist: %s" % extra)
        for cid, spec in REG.LAUNCH.items():
            kinds = [k for k in ("view", "command", "url", "none") if k in spec]
            self.assertEqual(len(kinds), 1, "%s must name exactly one of view/command/url/none, got %s" % (cid, kinds))

    def test_view_targets_point_at_real_views(self):
        for cid, spec in REG.LAUNCH.items():
            if "view" in spec:
                self.assertIn(spec["view"], VIEWS, "%s opens a view that does not exist" % cid)

    def test_command_targets_are_utterable_sentences(self):
        for cid, spec in REG.LAUNCH.items():
            cmd = spec.get("command")
            if cmd is None:
                continue
            self.assertGreaterEqual(len(str(cmd).split()), 2, "%s: %r" % (cid, cmd))
            self.assertNotIn(str(cmd).lower(), ("todo", "tbd", "coming soon", "none"))

    def test_url_targets_stay_on_loopback(self):
        for cid, spec in REG.LAUNCH.items():
            url = spec.get("url")
            if url is None:
                continue
            self.assertTrue(re.match(r"^http://(127\.0\.0\.1|localhost)(:\d+)?", url),
                            "%s: %s is not loopback" % (cid, url))

    def test_only_blocked_cards_may_open_nothing_and_they_say_why(self):
        states = {row["id"]: row["state"] for row in REG.snapshot()["capabilities"]}
        for cid, spec in REG.LAUNCH.items():
            if "none" not in spec:
                continue
            self.assertEqual(states.get(cid), "BLOCKED",
                             "%s is %s but opens nothing - a live card must lead somewhere"
                             % (cid, states.get(cid)))
            self.assertGreaterEqual(len(str(spec["none"]).split()), 3,
                                    "%s: the reason must name what is missing" % cid)

    def test_the_duplicated_surfaces_are_linked_not_reimplemented(self):
        # His example: the Split-Brain card and the Brain view are the same
        # subsystem, so the card opens the view instead of growing a second one.
        self.assertEqual(REG.LAUNCH["brain_split"], {"view": "brain"})
        self.assertEqual(REG.LAUNCH["deep-research"].get("view"), "web")
        self.assertEqual(REG.LAUNCH["research-dossier"].get("view"), "web")
        self.assertEqual(REG.LAUNCH["fight-fitness"].get("view"), "fight")
        self.assertEqual(REG.LAUNCH["doc-parliament"].get("view"), "memory")

    def test_whatsapp_and_code_red_reach_the_existing_command_path(self):
        self.assertEqual(REG.LAUNCH["whatsapp-matrix"], {"command": "open whatsapp"})
        self.assertIn("code red", REG.LAUNCH["code-red"]["command"].lower())

    def test_n8n_opens_its_own_ui_and_offers_the_one_click_start(self):
        spec = REG.LAUNCH["n8n-hooks"]
        self.assertEqual(spec["url"], "http://127.0.0.1:5678")
        self.assertEqual(spec["start"], "start n8n")
        self.assertNotIn("view", spec, "n8n has no JARVIS view - it opens its own UI")

    def test_the_snapshot_row_carries_its_launch_to_the_dashboard(self):
        rows = {r["id"]: r for r in REG.snapshot()["capabilities"]}
        self.assertEqual(rows["brain_split"]["launch"], {"view": "brain"})
        self.assertEqual(rows["image-gen"]["launch"]["none"], REG.LAUNCH["image-gen"]["none"])


class N8nStartRouteTest(unittest.TestCase):
    """`start n8n` must be honest in all three states: already up, started now,
    and could not start - and it must never build a command from user text."""

    def setUp(self):
        self.ve = _load("voice_engine")
        self.spoken = []
        self.spawn_calls = []
        self.spawn_ok = False
        self._real_spawn = self.ve._start_n8n_process
        self._real_online = self.ve._n8n_online
        self.ve._start_n8n_process = lambda: (self.spawn_calls.append("spawn"), self.spawn_ok)[1]
        self.addCleanup(setattr, self.ve, "_start_n8n_process", self._real_spawn)
        self.addCleanup(setattr, self.ve, "_n8n_online", self._real_online)

    def _reply(self, online, spawn_ok):
        self.spawn_ok = spawn_ok
        self.ve._n8n_online = lambda: online
        return self.ve._start_n8n(self.spoken.append)

    def test_reports_already_running_without_spawning(self):
        reply = self._reply(True, False)
        self.assertIn("already", reply.lower())
        self.assertEqual(self.spawn_calls, [], "must not start a second n8n")

    def test_starts_it_when_it_is_down(self):
        reply = self._reply(False, True)
        self.assertEqual(self.spawn_calls, ["spawn"])
        self.assertIn("starting", reply.lower())

    def test_a_failed_start_names_the_binary(self):
        reply = self._reply(False, False)
        self.assertIn("n8n", reply)
        self.assertNotIn("done", reply.lower())

    def test_the_phrase_parser_only_matches_n8n(self):
        self.assertTrue(self.ve._n8n_start_request("start n8n"))
        self.assertTrue(self.ve._n8n_start_request("n8n shuru karo"))
        self.assertFalse(self.ve._n8n_start_request("open notepad"))
        self.assertFalse(self.ve._n8n_start_request("stop n8n"))


if __name__ == "__main__":
    unittest.main()
