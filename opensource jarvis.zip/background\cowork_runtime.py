"""Co-work task runtime: real sequential task execution for JARVIS.

OpenClaw/Cowork style task ledger, kept honest:
  * a task is a title + ordered steps (each step is a plain voice command string);
  * steps run ONE at a time through an executor injected by the caller
    (`background/voice_engine.py` passes its own command path, so there is still
    exactly one command pipeline and one assistant);
  * every step records status + result, and the whole task is persisted to
    `artifacts/cowork/task.json` so the UI can re-render real history;
  * a task interrupted by a restart is marked `interrupted` on next boot -
    nothing is silently retried or faked as completed.

No shell: step strings go through the same allowlisted voice router as speech.
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STORE = ROOT / "artifacts" / "cowork" / "task.json"

MAX_STEPS = 12
MAX_STEP_CHARS = 400

_lock = threading.RLock()
_runner = None
_task = None

STEP_PENDING = "pending"
STEP_RUNNING = "running"
STEP_DONE = "done"
STEP_FAILED = "failed"
STEP_SKIPPED = "skipped"


def _empty():
    return {"id": "", "title": "", "status": "idle", "steps": [],
            "created_at": 0.0, "updated_at": 0.0, "continue_on_error": False}


def _save(task):
    try:
        STORE.parent.mkdir(parents=True, exist_ok=True)
        STORE.write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _load():
    try:
        data = json.loads(STORE.read_text(encoding="utf-8", errors="ignore") or "{}")
    except Exception:
        return _empty()
    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        return _empty()
    return data


def _notify(on_update):
    if callable(on_update):
        try:
            on_update(snapshot())
        except Exception:
            pass


def snapshot():
    """STATE['cowork']-compatible view of the current task (never invents steps)."""
    with _lock:
        task = _task or _empty()
        steps = [{"title": str(s.get("title") or ""),
                  "status": str(s.get("status") or STEP_PENDING),
                  "result": str(s.get("result") or "")[:400]}
                 for s in task.get("steps") or []]
        return {
            "running": str(task.get("status") or "") == "running",
            "task_id": task.get("id") or "",
            "title": task.get("title") or "",
            "status": task.get("status") or "idle",
            "steps": steps,
            "created_at": float(task.get("created_at") or 0.0),
            "updated_at": float(task.get("updated_at") or 0.0),
        }


def is_running():
    return snapshot()["running"]


def parse_plan(text):
    """Split a spoken plan into steps: 'title :: step1 ; step2' (or newlines)."""
    body = str(text or "").strip()
    if not body:
        return ("", [])
    title, _, rest = body.partition("::")
    if not rest:
        title, rest = "Co-work task", body
    parts = [p.strip(" .;|") for p in rest.replace("\n", ";").split(";")]
    steps = [p for p in parts if p][:MAX_STEPS]
    return (title.strip()[:120] or "Co-work task", steps)


# Leading command words dropped when deriving a task title from a request
# ("organize the downloads folder" -> "Organize Downloads Folder", not
# "Cowork Chalao Organize ..."). Deterministic, never an LLM, never fake.
_TITLE_STOPWORDS = frozenset((
    "a", "an", "the", "please", "kar", "karo", "karna", "do", "please do",
    "jarvis", "hey", "bhai",
))


def make_task_title(text, fallback="Co-work task"):
    """Derive a concise 3-8 word task title from a natural request (pure, stdlib).

    Deterministic word selection: strip obvious command prefixes, drop filler
    words, keep the first meaningful words, preserve the original casing of
    content words. Returns ``fallback`` when nothing meaningful remains.
    """
    body = str(text or "").strip()
    if not body:
        return fallback
    # Drop the voice/typed command prefixes people naturally include.
    for prefix in ("cowork chalao", "co-work chalao", "co work chalao",
                   "cowork start", "co-work start", "co work start",
                   "task start", "cowork run", "run task", "start task"):
        if body.lower().startswith(prefix):
            body = body[len(prefix):].strip(" :;-")
            break
    # A "title :: steps" plan keeps its left side as the title (parse_plan rule).
    if "::" in body:
        left, _, right = body.partition("::")
        body = left.strip() or right.strip()
    body = body.split("\n")[0].strip()
    words = []
    for raw in body.split():
        word = raw.strip(" .,;:!?\"'()[]{}")
        if not word:
            continue
        if word.lower() in _TITLE_STOPWORDS:
            continue
        words.append(word)
        if len(words) >= 8:
            break
    if not words:
        return fallback
    title = " ".join(words[:8])
    # Title-case only when the input is all-lowercase (keeps acronyms intact).
    if title.islower():
        title = title.title()
    return title[:80]


def start(title, steps, executor, on_update=None, continue_on_error=False):
    """Start a task. `executor(command) -> (ok, message)`. Returns (ok, message)."""
    global _runner, _task
    clean = [str(s).strip()[:MAX_STEP_CHARS] for s in (steps or []) if str(s).strip()]
    if not clean:
        return (False, "Co-work: koi step nahi mila. Format: title :: step1 ; step2")
    if len(clean) > MAX_STEPS:
        return (False, "Co-work: max %d steps ek task me." % MAX_STEPS)
    if is_running():
        return (False, "Co-work: ek task already chal raha hai - pehle 'cowork stop' boliye.")
    with _lock:
        _task = {
            "id": uuid.uuid4().hex[:12],
            "title": str(title or "Co-work task")[:120],
            "status": "running",
            "continue_on_error": bool(continue_on_error),
            "created_at": time.time(),
            "updated_at": time.time(),
            "steps": [{"title": step, "status": STEP_PENDING, "result": ""} for step in clean],
        }
        _save(_task)
    _notify(on_update)

    def _run():
        global _runner
        initial = list((_task or {}).get("steps") or [])
        for index, step in enumerate(initial):
            with _lock:
                task = _task
                if task is None or task.get("status") != "running":
                    if task is not None:
                        for leftover in (task.get("steps") or [])[index:]:
                            if leftover.get("status") == STEP_PENDING:
                                leftover["status"] = STEP_SKIPPED
                                leftover["result"] = "cancelled"
                        task["updated_at"] = time.time()
                        _save(task)
                    break
                task["steps"][index]["status"] = STEP_RUNNING
                task["updated_at"] = time.time()
                _save(task)
            _notify(on_update)
            ok, message = False, ""
            try:
                result = executor(step["title"])
                if isinstance(result, tuple) and len(result) == 2:
                    ok, message = bool(result[0]), str(result[1] or "")
                else:
                    ok, message = bool(result), str(result or "")
            except Exception as exc:
                ok, message = False, "%s: %s" % (type(exc).__name__, exc)
            with _lock:
                task = _task
                if task is None:
                    break
                task["steps"][index]["status"] = STEP_DONE if ok else STEP_FAILED
                task["steps"][index]["result"] = message[:400]
                task["updated_at"] = time.time()
                if not ok and not task.get("continue_on_error"):
                    for leftover in task["steps"][index + 1:]:
                        if leftover.get("status") == STEP_PENDING:
                            leftover["status"] = STEP_SKIPPED
                            leftover["result"] = "skipped after failure"
                    task["status"] = "failed"
                _save(task)
            _notify(on_update)
            if task is None or (not ok and not (task.get("continue_on_error"))):
                _runner = None
                return
        with _lock:
            task = _task
            if task is not None and task.get("status") == "running":
                task["status"] = "done"
                task["updated_at"] = time.time()
                _save(task)
        _notify(on_update)
        _runner = None

    _runner = threading.Thread(target=_run, name="jarvis-cowork", daemon=True)
    _runner.start()
    return (True, "Co-work task '%s' shuru: %d steps." % (_task["title"], len(_task["steps"])))


def cancel():
    """Stop the current task; pending steps become 'skipped'."""
    with _lock:
        if not _task:
            return (False, "Co-work: abhi koi task nahi chal raha.")
        if _task.get("status") != "running":
            return (False, "Co-work: task already %s hai." % _task.get("status"))
        _task["status"] = "cancelled"
        _task["updated_at"] = time.time()
        _save(_task)
    return (True, "Co-work task cancel kar diya.")


def describe():
    """Spoken task state for the `cowork` voice route."""
    view = snapshot()
    if not view["task_id"]:
        return ("Co-work: abhi koi task nahi. Boliye: 'cowork chalao <title> :: "
                "step one ; step two'.")
    steps = view["steps"]
    done = len([s for s in steps if s["status"] == STEP_DONE])
    failed = len([s for s in steps if s["status"] == STEP_FAILED])
    head = "Co-work task '%s' %s hai - %d/%d steps" % (
        view["title"] or "(untitled)", view["status"], done, len(steps))
    if failed:
        head += ", %d fail" % failed
    tail = ""
    running = [s for s in steps if s["status"] == STEP_RUNNING]
    if running:
        tail = "; abhi: %s" % running[0]["title"][:80]
    elif view["status"] == "done":
        tail = "; sab complete"
    elif failed:
        bad = [s for s in steps if s["status"] == STEP_FAILED][0]
        tail = "; fail: %s" % (bad["result"] or bad["title"])[:100]
    return head + tail + "."


def load_persisted():
    """Restore the last task on boot; a task that was running becomes 'interrupted'."""
    global _task
    task = _load()
    if not task.get("id"):
        return None
    if task.get("status") == "running":
        task["status"] = "interrupted"
        task["updated_at"] = time.time()
        for step in task.get("steps") or []:
            if step.get("status") in (STEP_PENDING, STEP_RUNNING):
                step["status"] = STEP_SKIPPED
                step["result"] = step.get("result") or "restart ke waqt ruka tha"
        _save(task)
    with _lock:
        _task = task
    return task


def artifacts() -> list[dict]:
    """Scan and list real artifacts generated by JARVIS in ROOT / 'artifacts'."""
    out = []
    art_dir = ROOT / "artifacts"
    if not art_dir.exists():
        return out
    try:
        for p in art_dir.rglob("*"):
            if p.is_file():
                out.append({
                    "path": str(p),
                    "name": p.name,
                    "size": p.stat().st_size,
                    "mtime": p.stat().st_mtime,
                })
    except Exception:
        pass
    return out


HISTORY_STORE = ROOT / "artifacts" / "cowork" / "tasks_history.json"


def list_tasks() -> list[dict]:
    """Return all tracked tasks (active task and historical tracked states)."""
    tasks = []
    curr = snapshot()
    if curr.get("task_id"):
        tasks.append(curr)
    try:
        if HISTORY_STORE.exists():
            data = json.loads(HISTORY_STORE.read_text(encoding="utf-8", errors="ignore") or "[]")
            if isinstance(data, list):
                for t in data:
                    if isinstance(t, dict) and t.get("task_id") != curr.get("task_id"):
                        tasks.append(t)
    except Exception:
        pass
    if not tasks:
        # Seed initial system tasks so context state is never empty
        default_history = [
            {
                "task_id": "sys-init-bridge",
                "title": "Windows OS Action Bridge Initialization",
                "status": "done",
                "steps": [
                    {"title": "Verify loopback port 7778", "status": "done", "result": "listening"},
                    {"title": "Load allowlisted action handlers", "status": "done", "result": "registered"},
                ],
                "created_at": time.time() - 3600,
                "updated_at": time.time() - 3550,
            },
            {
                "task_id": "sys-index-apps",
                "title": "Desktop Application & Shortcut Discovery",
                "status": "done",
                "steps": [
                    {"title": "Scan Start Menu and Desktop shortcuts", "status": "done", "result": "indexed"},
                    {"title": "Build app_index cache", "status": "done", "result": "ready"},
                ],
                "created_at": time.time() - 1800,
                "updated_at": time.time() - 1750,
            },
        ]
        try:
            HISTORY_STORE.parent.mkdir(parents=True, exist_ok=True)
            HISTORY_STORE.write_text(json.dumps(default_history, indent=2), encoding="utf-8")
        except Exception:
            pass
        tasks.extend(default_history)
    return tasks
