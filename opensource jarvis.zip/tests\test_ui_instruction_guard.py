"""Tests for the three failures from the owner's latest transcript (2026-10-19).

 1. The LLM answered a WhatsApp request with its own PLAN - "click the chat named
    Akhilesh, type 'ki', and send" - and JARVIS reported nothing sent. The owner
    asked twice and got two plans. A spoken instruction is a lie: it implies the
    action happened.
 2. "chrome pe search kare" opened Chrome and then did nothing: there was no
    browser-search route at all (intent "chat"), while the YouTube route existed.
 3. "scroll down" / "chrome neeche scroll karo" did nothing either - the
    capability (`screen_agent.gui_scroll`) existed but was never routed to.
 4. Firecrawl: three keys really are configured and all three return HTTP 402
    (verified live), so that answer was honest - but it must name WHICH keys.
"""
import importlib.util
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))


def _load(key, rel):
    spec = importlib.util.spec_from_file_location(key, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


VE = _load("voice_engine_ui", "background/voice_engine.py")


class SpokenUIInstructionTest(unittest.TestCase):
    """The reply funnel must never speak a manual UI plan."""

    LEAKS = [
        "Please run this command: click the chat named Akhilesh, type 'ki', and send",
        "Sir, click the chat named Akhilesh, type 'hello', and send.",
        "You should press Enter now",
        "Please right-click on the link",
        "Type in the search box and press enter",
        "select the chat named Vishesh and send",
    ]

    def test_every_leak_is_caught(self):
        for leak in self.LEAKS:
            out = VE._strip_ui_instructions(leak)
            self.assertNotEqual(out, leak, leak)
            self.assertIn("kuch bhi nahi kiya", out, leak)

    def test_a_normal_reply_passes_through_untouched(self):
        for good in ("Sir, aaj mausam saaf hai.",
                     "Aap kaun ho?",
                     "Notepad khul gaya.",
                     "Maine akhilesh ko message bhej diya - preview pe verify ho gaya.",
                     "Sir, ye message WhatsApp app me type nahi ho paya."):
            self.assertEqual(VE._strip_ui_instructions(good), good)

    def test_empty_input_does_not_crash(self):
        self.assertEqual(VE._strip_ui_instructions(""), "")
        self.assertEqual(VE._strip_ui_instructions(None), "")


class WhatsAppParseTest(unittest.TestCase):
    """'send message to akhilesh on whatsapp ki' must parse, not fall to chat."""

    def test_the_owner_sentence_parses(self):
        got = VE._parse_whatsapp_message("send message to akhilesh on whatsapp ki")
        self.assertIsNotNone(got, "this sentence reached the brain and leaked a plan")
        contact, body = got
        self.assertEqual(contact, "akhilesh")
        self.assertEqual(body, "ki")

    def test_a_body_after_the_app_mention_still_parses(self):
        got = VE._parse_whatsapp_message(
            "send a whatsapp message to akhilesh on whatsapp good morning")
        self.assertIsNotNone(got)
        self.assertEqual(got[0], "akhilesh")
        self.assertIn("good morning", got[1])

    def test_the_earlier_shapes_still_parse(self):
        self.assertEqual(
            VE._parse_whatsapp_message("whatsapp pe akhilesh ko hello bhejo"),
            ("akhilesh", "hello"))
        self.assertEqual(
            VE._parse_whatsapp_message("akhilesh ko hello bhejo"),
            ("akhilesh", "hello"))
        # Always (contact, message) - never the other way round.
        self.assertEqual(
            VE._parse_whatsapp_message("send hello to akhilesh"),
            ("akhilesh", "hello"))

    def test_an_apostrophe_in_the_message_is_kept(self):
        # The parser used to strip every apostrophe, so the dictated capability line
        # was sent as "I m testing my capability" instead of "I'm testing ...".
        self.assertEqual(
            VE._parse_whatsapp_message(
                "send a whatsapp message to akhilesh saying I am Jarvis and I'm testing"),
            ("akhilesh", "I am Jarvis and I'm testing"))

    def test_quoting_marks_around_the_message_are_not_sent(self):
        self.assertEqual(
            VE._parse_whatsapp_message("send 'hello' to akhilesh on whatsapp"),
            ("akhilesh", "hello"))

    def test_a_negated_request_is_still_refused(self):
        self.assertIsNone(VE._parse_whatsapp_message("mat bhejo akhilesh ko hello"))

    def test_the_owner_spoken_shape_parses_even_with_stt_spelling(self):
        # Live 2026-10-19: STT wrote "whastapp" (s/t swapped) AND the sanitizer ate
        # the trailing "hello" (a wake token, from "hello jarvis"), so the router saw
        # "whastapp pe mesage bhejna hia akhilesh ko" - nothing matched, the brain
        # produced a UI plan, and the guard answered "kuch bhi nahi kiya".
        raw = "whastapp pe mesage bhejna hia akhilesh ko hello"
        self.assertEqual(VE._sanitize_voice_command(raw), raw)
        self.assertEqual(VE._parse_whatsapp_message(raw), ("akhilesh", "hello"))

    def test_the_app_mention_may_trail_the_name(self):
        # The owner typed exactly this; the contact-at-end anchor could not get past
        # "on whatsapp", so the send route never ran.
        self.assertEqual(
            VE._parse_whatsapp_message("send hello to akhilesh on whatsapp"),
            ("akhilesh", "hello"))

    def test_the_app_mention_may_follow_the_verb(self):
        self.assertEqual(
            VE._parse_whatsapp_message("akhilesh ko hello bhejo whatsapp pe"),
            ("akhilesh", "hello"))

    def test_a_payload_word_that_is_also_a_wake_word_survives(self):
        # 'hello' is a wake token; as the message body it must survive, and the
        # contact must not swallow the leftover connector ("akhilesh saying").
        self.assertEqual(
            VE._parse_whatsapp_message("send a whatsapp message to akhilesh saying hello"),
            ("akhilesh", "hello"))

    def test_leading_and_trailing_wake_junk_still_goes(self):
        # run_command sanitizes BEFORE routing, so the parser is fed the cleaned text.
        for raw in ("jarvis akhilesh ko hello bhejo",
                    "akhilesh ko hello bhejo jarvis",
                    "jarvis akhilesh ko hello bhejo jarvis"):
            clean = VE._sanitize_voice_command(raw)
            self.assertEqual(clean, "akhilesh ko hello bhejo", raw)
            self.assertEqual(VE._parse_whatsapp_message(clean), ("akhilesh", "hello"), raw)


class BrowserSearchRouteTest(unittest.TestCase):
    """There was no browser-search route; YouTube had one and Chrome did not."""

    def test_queries_are_extracted(self):
        cases = {
            "chrome pe minecraft search karo": "minecraft",
            "chrome me search karo minecraft episode 1": "minecraft episode 1",
            "google pe search karo weather": "weather",
            "chrome pe python tutorial dhoondo": "python tutorial",
            "browser me cricket score check karo": "cricket score",
        }
        for text, want in cases.items():
            self.assertEqual(VE._browser_query(text.casefold()), want, text)

    def test_a_bare_launch_has_no_query(self):
        for text in ("chrome kholo", "chrome pe search kare", "open chrome"):
            self.assertIsNone(VE._browser_query(text.casefold()), text)

    def test_a_question_about_the_browser_is_not_a_search(self):
        self.assertIsNone(VE._browser_query("chrome kya hai"))

    def test_it_never_steals_a_send_or_a_launch(self):
        for text in ("akhilesh ko hello bhejo", "open notepad",
                     "notepad me kya likha hai"):
            self.assertIsNone(VE._browser_query(text.casefold()), text)

    def test_the_youtube_route_still_owns_youtube(self):
        self.assertEqual(VE._browser_query("youtube pe minecraft search karo"), None)
        self.assertEqual(VE._youtube_query("youtube pe minecraft search karo"),
                         "minecraft")


class ScrollRouteTest(unittest.TestCase):
    """Scroll existed as a capability but had no route to reach it."""

    def test_direction_and_amount_are_parsed(self):
        for text, want in (("scroll down", ("down", 5)),
                           ("neeche scroll karo", ("down", 5)),
                           ("chrome neeche scroll karo", ("down", 5)),
                           ("10 step neeche jao", ("down", 10)),
                           ("page down", ("down", 5)),
                           ("upar scroll karo", ("up", 5)),
                           ("scroll up", ("up", 5))):
            self.assertEqual(VE._scroll_request(text.casefold()), want, text)

    def test_unrelated_turns_are_not_scrolls(self):
        for text in ("akhilesh ko hello bhejo", "open notepad",
                     "notepad me kya likha hai",
                     "chrome pe minecraft search karo"):
            self.assertIsNone(VE._scroll_request(text.casefold()), text)


class FirecrawlHonestyTest(unittest.TestCase):
    """The keys really are spent - the answer must be checkable, not vague."""

    def test_the_pool_reports_every_slot(self):
        import firecrawl_keys as fk
        status = fk.pool_status()
        for field in ("keys", "total", "healthy", "fanout"):
            self.assertIn(field, status)
        for row in status["keys"]:
            self.assertTrue(row["slot"].startswith("fc-***"))
            self.assertNotIn("fc-0", row["slot"], "a raw key must never be exposed")

    def test_exhaustion_is_classified_but_a_500_is_not(self):
        import firecrawl_keys as fk
        fk.reset()
        with mock.patch.object(fk, "_load_keys", return_value=["fc-a", "fc-b"]):
            self.assertTrue(fk.report_failure("fc-a", "Insufficient credits (402)"))
            self.assertNotIn("fc-a", fk.healthy_keys())
            # A transient server error must NOT retire a working key, or one bad
            # afternoon would silently shrink the pool.
            self.assertFalse(fk.report_failure("fc-b", "500 Internal Server Error"))
            self.assertIn("fc-b", fk.healthy_keys())
        fk.reset()


if __name__ == "__main__":
    unittest.main()