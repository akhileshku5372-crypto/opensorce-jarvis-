"""Import the license-clear library books into skills/library/books/ and index
them by chapter, so the Soft & Hard Skill card opens a real shelf instead of a
hardcoded sample list.

Reads skills/library/sources.json (the pile) and writes, per book:

  skills/library/books/<slug>/meta.json       title, author, licence, attribution
  skills/library/books/<slug>/book.txt        the text exactly as fetched
  skills/library/books/<slug>/chapters.json   [{n, title, start, end, chars}]

Only entries with a `fetch` URL are imported. A book without a verified URL stays
in sources.json untouched - it must not appear on the shelf as if it existed.
Re-running skips a book whose text already looks complete unless --force.

Run:  python scripts/import_library_books.py [--force]
"""
import json
import os
import re
import sys
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(ROOT, "skills", "library")
BOOKS = os.path.join(LIB, "books")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# Gutenberg starters/ends are boilerplate, not the book.
_START_MARK = "*** START OF TH"
_END_MARK = "*** END OF TH"

# Chapter headings across the five titles: "CHAPTER I", "Chapter XII.", "CHAPTER 3".
# The lookahead matters: without it "chapter in which we have stated..." matched as
# chapter "I" (the I of "in"), which put a mid-sentence fragment on the shelf.
_HEADING_RE = re.compile(
    r"^[ \t]{0,30}(?:THE\s+)?CHAPTER[ \t]+(?:[IVXLCDM]{1,7}|\d{1,2})(?![A-Za-z])[ \t]*[.:—-]?[ \t]*(.{0,80})$",
    re.IGNORECASE | re.MULTILINE)
# Parts that some of these books use instead of, or before, chapters.
_PART_RE = re.compile(r"^[ \t]{0,30}(?:PREFACE|INTRODUCTION|CONCLUSION|EPILOGUE|NOTES?)"
                      r"[ \t]*[.:—-]?[ \t]*.{0,60}$", re.IGNORECASE | re.MULTILINE)


def fetch(url):
    """Fetch over curl, the same way background/radox_writer.py does.

    urllib fails on this machine with "SELF-SIGNED CERTIFICATE IN CHAIN" because
    the local proxy intercepts TLS; curl uses the Windows store and gets through.
    Verification is never disabled - that would be the wrong fix.
    """
    res = subprocess.run(
        ["curl", "-sS", "--max-time", "120", "-A", UA, "-L", url],
        capture_output=True, timeout=180)
    if res.returncode != 0 or not res.stdout:
        raise RuntimeError(f"curl exit {res.returncode}: {res.stderr.decode('utf-8', 'replace')[:160]}")
    raw = res.stdout
    for enc in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def strip_boilerplate(text):
    i = text.find(_START_MARK)
    if i != -1:
        nl = text.find("\n", i)
        text = text[nl + 1:] if nl != -1 else text
    j = text.find(_END_MARK)
    if j != -1:
        text = text[:j]
    return text.strip()


MIN_CHAPTER_CHARS = 2000


def _key_of(line):
    """The identity of a heading: "CHAPTER XXXI--MAKING CONVERSATION 372" and the
    bare body heading "CHAPTER XXXI" are the SAME chapter."""
    m = re.match(r"(?:THE\s+)?(?:CHAPTER|PART)[ \t]+([IVXLCDM]{1,7}|\d{1,2})", line, re.IGNORECASE)
    if m:
        return ("c", m.group(1).upper())
    return ("s", re.split(r"[.:—-]", line, 1)[0].strip().upper())


def _title_of(line):
    return re.sub(r"\s+\d+$", "", re.sub(r"\s+", " ", line)).strip(" .:-—")


def split_chapters(text):
    """Return [{n,title,start,end,chars,split}]. Offsets are into the stripped body.

    A plain-text Gutenberg book prints every chapter twice: once in the CONTENTS
    page ("CHAPTER I--ACQUIRING CONFIDENCE...   1", 66 chars from the next such
    line) and once in the body as a bare heading that owns thousands of chars. So
    a candidate only counts as a chapter when the text it owns is at least
    MIN_CHAPTER_CHARS long - that drops every contents line, every "as shown in
    Chapter I" cross-reference and the licence block, without needing to guess
    which occurrence is which. Of the survivors the EARLIEST wins, and the title
    comes from whichever occurrence of that number is worded richest, so the shelf
    shows a real chapter name. Fewer than two real chapters means ONE chapter
    named after the book - never a fabricated table of contents.
    """
    cand = [(m.start(), m.group(0).strip()) for m in _HEADING_RE.finditer(text)]
    if len(cand) < 3:
        cand = sorted(cand + [(m.start(), m.group(0).strip()) for m in _PART_RE.finditer(text)])
    titles = {}
    for pos, title in cand:
        k = _key_of(title)
        if len(_title_of(title)) > len(_title_of(titles.get(k, ""))):
            titles[k] = title
    heads, seen = [], set()
    for idx, (pos, title) in enumerate(cand):
        end = cand[idx + 1][0] if idx + 1 < len(cand) else len(text)
        k = _key_of(title)
        if end - pos < MIN_CHAPTER_CHARS or k in seen:
            continue
        seen.add(k)
        heads.append((pos, titles.get(k, title), end))
    heads.sort(key=lambda h: h[0])
    if len(heads) < 2:
        return [{"n": 1, "title": "Full text", "start": 0, "end": len(text),
                 "chars": len(text), "split": "whole-book"}]
    chapters = []
    for order, (pos, title, end) in enumerate(heads):
        stop = heads[order + 1][0] if order + 1 < len(heads) else len(text)
        chapters.append({"n": len(chapters) + 1, "title": _title_of(title)[:90] or "Chapter",
                         "start": pos, "end": stop, "chars": len(text[pos:stop].strip()),
                         "split": "headings"})
    return chapters
    if len(heads) < 2:
        return [{"n": 1, "title": "Full text", "start": 0, "end": len(text),
                 "chars": len(text), "split": "whole-book"}]
    chapters = []
    for pos, title, end in heads:
        clean = re.sub(r"\s+", " ", re.sub(r"\s+\d+$", "", title)).strip(" .:-—")
        chapters.append({"n": len(chapters) + 1, "title": clean[:90] or "Chapter",
                         "start": pos, "end": end, "chars": len(text[pos:end].strip()),
                         "split": "headings"})
    return chapters


def already_there(slug):
    path = os.path.join(BOOKS, slug, "book.txt")
    if not os.path.exists(path):
        return None
    try:
        if os.path.getsize(path) < 20000:
            return None
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return None


def main():
    force = "--force" in sys.argv
    with open(os.path.join(LIB, "sources.json"), "r", encoding="utf-8") as fh:
        sources = json.load(fh)
    os.makedirs(BOOKS, exist_ok=True)
    imported, skipped, waiting = [], [], []
    for book in sources.get("books_ready_to_import", []):
        slug = book["slug"]
        url = book.get("fetch")
        if not url:
            waiting.append(slug)
            print(f"  WAIT  {slug}: sources.json has no fetch URL, so nothing was imported")
            continue
        existing = None if force else already_there(slug)
        if existing:
            skipped.append(slug)
            print(f"  SKIP  {slug}: book.txt already present ({len(existing)} chars)")
            continue
        print(f"  FETCH {slug} <- {url}")
        text = strip_boilerplate(fetch(url))
        if len(text) < 20000:
            print(f"  FAIL  {slug}: only {len(text)} chars came back, nothing written")
            continue
        d = os.path.join(BOOKS, slug)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "book.txt"), "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        chapters = split_chapters(text)
        with open(os.path.join(d, "chapters.json"), "w", encoding="utf-8", newline="\n") as fh:
            json.dump(chapters, fh, indent=2, ensure_ascii=False)
        meta = {k: book.get(k) for k in ("slug", "title", "author", "stream", "aisle",
                                         "level", "license", "attribution", "source_url",
                                         "split_by")}
        meta["chars"] = len(text)
        meta["chapter_count"] = len(chapters)
        meta["split"] = chapters[0]["split"] if chapters else "none"
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8", newline="\n") as fh:
            json.dump(meta, fh, indent=2, ensure_ascii=False)
        imported.append(slug)
        print(f"  OK    {slug}: {len(text)} chars, {len(chapters)} chapters ({meta['split']})")
    print("")
    print(f"imported={len(imported)} skipped={len(skipped)} waiting_for_url={len(waiting)}")
    if imported:
        print("  " + ", ".join(imported))


if __name__ == "__main__":
    main()
