#!/usr/bin/env node
'use strict'

/**
 * fix-mojibake.js — Encoding corruption recovery for the JARVIS workspace.
 *
 * Several text layers were double-encoded (UTF-8 -> misread as Windows-1252 ->
 * re-saved as UTF-8) by external automation tools. This script surgically
 * reverses exactly those runs:
 *
 *   1. Reads the file as UTF-8 and splits each line into "runs" of characters
 *      that Windows-1252 can represent (ASCII + the special byte mappings).
 *   2. For each run it re-encodes the chars to their Windows-1252 bytes, then
 *      decodes those bytes as UTF-8. Windows that produce valid UTF-8 with no
 *      U+FFFD replacement chars and no C1 control characters are treated as the
 *      recovered original text and emitted.
 *   3. A greedy repair pass walks mixed runs (partially re-written text) so a
 *      single correct character never blocks the neighbouring corrupted text.
 *
 * Correctly encoded CJK / Cyrillic / emoji content (>U+00FF and not in the
 * Windows-1252 special range) is never part of a run and is copied through
 * unchanged, so healthy text is never damaged.
 *
 * Usage:
 *   node tools/fix-mojibake.cjs              # process the default target files
 *   node tools/fix-mojibake.cjs <file> ...   # process the listed files only
 */

const fs = require('fs')
const path = require('path')

const ROOT = path.resolve(__dirname, '..')
const DEFAULT_TARGETS = [
  'src/index.tsx',
  'src/artifacts.ts',
  'src/renderer.tsx',
  'public/static/style.css'
]

// Windows-1252 byte -> Unicode code point (WHATWG mapping).
const BYTE_TO_CP = new Map()
for (let cp = 0xa0; cp <= 0xff; cp++) BYTE_TO_CP.set(cp, cp)
const CP1252_SPECIALS = [
  0x80, 0x20ac, 0x81, 0x81, 0x82, 0x201a, 0x83, 0x192, 0x84, 0x201e, 0x85, 0x2026,
  0x86, 0x2020, 0x87, 0x2021, 0x88, 0x2c6, 0x89, 0x2030, 0x8a, 0x160, 0x8b, 0x2039,
  0x8c, 0x152, 0x8d, 0x8d, 0x8e, 0x17d, 0x8f, 0x8f, 0x90, 0x90, 0x91, 0x2018,
  0x92, 0x2019, 0x93, 0x201c, 0x94, 0x201d, 0x95, 0x2022, 0x96, 0x2013, 0x97, 0x2014,
  0x98, 0x2dc, 0x99, 0x2122, 0x9a, 0x161, 0x9b, 0x203a, 0x9c, 0x153, 0x9d, 0x9d,
  0x9e, 0x17e, 0x9f, 0x178
]
for (let i = 0; i < CP1252_SPECIALS.length; i += 2) BYTE_TO_CP.set(CP1252_SPECIALS[i], CP1252_SPECIALS[i + 1])

// Unicode code point -> Windows-1252 byte (reverse map).
const CP_TO_BYTE = new Map()
for (const [byte, cp] of BYTE_TO_CP) {
  if (!CP_TO_BYTE.has(cp)) CP_TO_BYTE.set(cp, byte)
}
for (let cp = 0x20; cp <= 0x7e; cp++) CP_TO_BYTE.set(cp, cp) // ASCII

const cpOf = (ch) => ch.codePointAt(0)

const hasMoji = (run) => {
  for (const ch of run) {
    const cp = cpOf(ch)
    if (cp > 0x7e && CP_TO_BYTE.has(cp)) return true
  }
  return false
}

// Encode a run of chars into its Windows-1252 byte sequence. Returns null when
// a character is not representable in Windows-1252.
function encodeBytes(run) {
  const bytes = new Uint8Array(run.length)
  for (let i = 0; i < run.length; i++) {
    const byte = CP_TO_BYTE.get(cpOf(run[i]))
    if (byte === undefined) return null
    bytes[i] = byte
  }
  return bytes
}

function decodeWindow(run) {
  if (!hasMoji(run)) return null
  const bytes = encodeBytes(run)
  if (!bytes) return null
  const decoded = Buffer.from(bytes).toString('utf8')
  if (decoded.includes('\uFFFD')) return null
  for (const ch of decoded) {
    const cp = ch.codePointAt(0)
    if (cp >= 0x80 && cp <= 0x9f) return null // C1 control block never belongs to user text
  }
  return decoded
}

// Greedy repair: consume the longest valid window at each position so a single
// correctly-written character inside an otherwise corrupted run is preserved.
function repairRun(run) {
  if (!hasMoji(run)) return run
  let out = ''
  let i = 0
  while (i < run.length) {
    let consumed = null
    for (let j = run.length; j > i; j--) {
      const decoded = decodeWindow(run.slice(i, j))
      if (decoded !== null) {
        consumed = decoded
        i = j
        break
      }
    }
    if (consumed !== null) {
      out += consumed
    } else {
      out += run[i]
      i++
    }
  }
  return out
}

function fixLine(line) {
  let out = ''
  let run = ''
  const flush = () => {
    if (run) {
      out += repairRun(run)
      run = ''
    }
  }
  for (const ch of line) {
    if (CP_TO_BYTE.has(cpOf(ch))) {
      run += ch
      continue
    }
    flush()
    out += ch
  }
  flush()
  return out
}

function fixFile(filePath) {
  if (!fs.existsSync(filePath)) {
    console.error(`  [skip] missing: ${filePath}`)
    return false
  }
  const original = fs.readFileSync(filePath, 'utf8')
  const lines = original.split('\n')
  let changed = false
  let changedRuns = 0
  for (let i = 0; i < lines.length; i++) {
    const fixed = fixLine(lines[i])
    if (fixed !== lines[i]) {
      changed = true
      changedRuns += 1
      lines[i] = fixed
    }
  }
  if (!changed) {
    console.log(`  [clean] ${filePath}`)
    return false
  }
  fs.writeFileSync(filePath, lines.join('\n'), 'utf8')
  console.log(`  [fixed] ${filePath} (${changedRuns} line${changedRuns === 1 ? '' : 's'} touched)`)
  return true
}

function main() {
  const targets = process.argv.slice(2).length
    ? process.argv.slice(2)
    : DEFAULT_TARGETS
  console.log('Restoring mojibake (double-encoded UTF-8/Windows-1252/UTF-8) text...')
  let fixedAny = false
  for (const relative of targets) {
    const full = path.isAbsolute(relative) ? relative : path.resolve(ROOT, relative)
    if (fixFile(full)) fixedAny = true
  }
  console.log(fixedAny
    ? 'Done. Review the restored text, then re-run the build checks.'
    : 'Done. No double-encoded runs were found in the target files.')
}

main()