"""Phase-1 skills smoke tests (stdlib only, no API keys, no network).

Run:  python tests/test_phase1.py
"""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))

import phase1_skills as s


class Phase1Test(unittest.TestCase):
    def test_time_date(self):
        out = s.time_date()
        self.assertIn("Sir", out)

    def test_notes_roundtrip(self):
        import tempfile

        orig = s._notes_dir
        try:
            tmp = Path(tempfile.mkdtemp(prefix="jarvis-notes-"))
            s._notes_dir = lambda: tmp
            self.assertIn("save", s.save_note("hello jarvis test").lower())
            self.assertIn("hello jarvis test", s.read_last_note())
        finally:
            s._notes_dir = orig

    def test_clipboard_set_returns_speech(self):
        self.assertIsInstance(s.clipboard_set("jarvis test 123"), str)

    def test_type_without_backend_returns_speech(self):
        # pyautogui absent hoye to bhi string reply aani chahiye, crash nahi.
        self.assertIsInstance(s.type_text("hello"), str)

    def test_screenshot_returns_speech(self):
        self.assertIsInstance(s.take_screenshot(), str)


if __name__ == "__main__":
    unittest.main(verbosity=2)
