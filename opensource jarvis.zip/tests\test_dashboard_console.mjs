// Live guard: the dashboard must mount with ZERO console errors/exceptions.
//
// Why this exists: `node --check public/static/app.js` passed on a file that
// threw `ReferenceError: activeViewId is not defined` on every command. The
// Extension System UI block had been spliced into the middle of
// activeViewId(), so the file stayed syntactically valid while two functions
// were never defined. A parser cannot see that; a real page load can.
//
// It also asserts the Extensions tab really binds and renders live rows, which
// is the only way to prove the core <-> dashboard wiring end to end.
//
// Run: node tests/test_dashboard_console.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const artifactsDir = path.join(root, 'artifacts', 'ui-audit', 'extensions')
mkdirSync(artifactsDir, { recursive: true })

const UI = 'http://127.0.0.1:7777/'
const wait = (ms) => new Promise((r) => setTimeout(r, ms))

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-console-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=9233', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
  '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { rmSync(profile, { recursive: true, force: true }) } catch {}
}
setTimeout(() => { cleanup(); process.exit(124) }, 110000).unref()

// Vite / favicon / devtools noise we do not own; everything else must be clean.
const IGNORE = [/favicon/i, /\[vite\]/i, /React DevTools/i, /net::ERR_/i]
const noise = []
// The prompt window is built from state.messages, which boot code can replace
// mid-request; an empty window is the bug, not the 400 it caused.
const emptyChatPosts = []
const record = (kind, text) => {
  if (IGNORE.some((re) => re.test(text))) return
  noise.push(kind + ' ' + text)
}

async function connect() {
  for (let i = 0; i < 40; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:9233/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) {
        const page = await res.json()
        if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
      }
    } catch {}
    await wait(500)
  }
  throw new Error('CDP did not come up')
}

try {
  const ws = new WebSocket(await connect())
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', reject)
  })
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails
      record('EXC', d?.exception?.description || d?.text || '?')
    }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      record('console.error', (m.params.args || []).map((a) => a.value ?? a.description ?? '').join(' '))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      // Without source+url a "Failed to load resource: 400" is undiagnosable -
      // the text alone never says which endpoint 400d.
      const e = m.params.entry
      record('ERR', [e.text, e.source || '?', e.url || '?'].join(' | '))
    }
    if (m.method === 'Network.requestWillBeSent' && /\/api\/ai\/chat/.test(m.params.request?.url || '')) {
      let parsed = null
      try { parsed = JSON.parse(m.params.request.postData || 'null') } catch { }
      if (parsed && !Array.isArray(parsed.messages)) emptyChatPosts.push('no messages array')
      else if (parsed && parsed.messages.length === 0) emptyChatPosts.push('{}')
    }
  })
  const send = (method, params = {}) => new Promise((resolve) => {
    const mid = ++id
    pending.set(mid, resolve)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    if (r.result?.exceptionDetails) {
      const d = r.result.exceptionDetails
      record('EXC', d.exception?.description || d.text || '?')
      return null
    }
    return r.result?.result?.value
  }

  await send('Runtime.enable')
  await send('Log.enable')
  await send('Page.enable')
  await send('Network.enable')
  await send('Page.navigate', { url: UI })

  let mounted = false
  for (let i = 0; i < 45; i++) {
    const v = await evaluate('({ hasLog: !!document.getElementById("chat-log") })')
    if (v?.hasLog) { mounted = true; break }
    await wait(1000)
  }
  if (!mounted) bad('dashboard did not mount')
  else ok('dashboard mounted')

  // The exact regression that motivated this test: activeViewId() is called by
  // executeCommand, so submitting through the real composer must not throw.
  const threw = await evaluate(`(() => {
    try {
      document.getElementById('chat-input').value = 'console guard probe'
      document.getElementById('chat-form').requestSubmit()
      return 'ok'
    } catch (e) { return 'threw: ' + e.message }
  })()`)
  if (threw === 'ok') ok('composer submit raised no ReferenceError')
  else bad('composer submit -> ' + threw)

  const opened = await evaluate(`(() => {
    const nav = document.querySelector('.nav-item[data-view="cowork"]');
    if (!nav) return 'no-nav';
    nav.click();
    return 'clicked';
  })()`)
  await wait(1200)
  if (opened === 'clicked') ok('co-work view opened')
  else bad('co-work view -> ' + opened)

  const tabClicked = await evaluate(`(() => {
    const tab = document.querySelector('[data-cowork-tab="extensions"]');
    if (!tab) return 'no-tab';
    tab.click();
    return 'clicked';
  })()`)
  await wait(1200)
  if (tabClicked === 'clicked') ok('Extensions tab clicked')
  else bad('Extensions tab -> ' + tabClicked)

  // Regression: every Co-work tab must leave EXACTLY ONE panel painted.
  //
  // Why: a layout rule `[data-view-panel="cowork"] [data-cowork-panel="agents"]{display:flex}`
  // outranked `.cowork-panel{display:none}`, so the Agents panel stayed painted
  // underneath the Extensions panel. The class toggle was correct; CSS refused to
  // honour it. Only computed `display` + real rects catch that, so assert on both.
  const TABS = ['chat', 'files', 'browser', 'terminal', 'artifacts', 'agents', 'extensions']
  const leaks = []
  for (const name of TABS) {
    // Re-assert the view every iteration: a Vite HMR reload can drop us back to
    // the Dashboard, and every Co-work panel would then measure 0px tall, which
    // would read as "nothing painted" instead of the real leak we care about.
    const viewReady = await evaluate(`(() => {
      const host = document.querySelector('[data-view-panel="cowork"]')
      if (host && getComputedStyle(host).display !== 'none') return 'open'
      const nav = document.querySelector('.nav-item[data-view="cowork"]')
      if (!nav) return 'no-nav'
      nav.click()
      return 'reopened'
    })()`)
    if (viewReady === 'no-nav') { leaks.push('co-work view not reachable'); break }
    if (viewReady === 'reopened') await wait(900)

    await evaluate(`(()=>{const t=document.querySelector('[data-cowork-tab=${JSON.stringify(name)}]');if(t)t.click()})()`)
    await wait(500)
    const state = await evaluate(`(() => {
      const painted = []
      document.querySelectorAll('[data-cowork-panel]').forEach((p) => {
        const cs = getComputedStyle(p)
        if (cs.display !== 'none' && p.getBoundingClientRect().height > 0) {
          painted.push({
            name: p.dataset.coworkPanel,
            active: p.classList.contains('active'),
            top: Math.round(p.getBoundingClientRect().top),
            bottom: Math.round(p.getBoundingClientRect().bottom)
          })
        }
      })
      return painted
    })()`)
    if (!Array.isArray(state)) { leaks.push(name + ': evaluate failed'); continue }
    if (state.length === 0) { leaks.push(name + ': no panel painted'); continue }
    if (state.length > 1) {
      leaks.push(name + ': ' + state.length + ' panels painted [' + state.map((p) => p.name).join(',') + ']')
      continue
    }
    if (state[0].name !== name) { leaks.push(name + ': painted "' + state[0].name + '" instead'); continue }
    if (!state[0].active) { leaks.push(name + ': painted without .active class') }
  }
  if (!leaks.length) ok('all ' + TABS.length + ' Co-work tabs paint exactly one panel')
  else {
    bad('co-work panel isolation broken:')
    leaks.forEach((l) => console.log('       ' + l))
  }

  // The first /extensions fetch does a real MCP handshake (~2-3 s cold), so poll
  // for the rendered counts instead of sleeping a fixed amount.
  let counts = ''
  for (let i = 0; i < 20; i++) {
    counts = String(await evaluate('document.getElementById("ext-counts")?.textContent || ""'))
    if (/\d+\s+plugins/.test(counts)) break
    await wait(1000)
  }
  if (/\d+\s+plugins/.test(counts)) ok('extension counts rendered: ' + counts.trim())
  else bad('extension counts missing: ' + JSON.stringify(counts))

  const rows = await evaluate('document.querySelectorAll("#ext-panel-plugins .ext-row").length')
  if (Number(rows) > 0) ok('plugin rows rendered: ' + rows)
  else bad('no plugin rows in #ext-panel-plugins')

  const permTab = await evaluate(`(() => {
    const tab = document.querySelector('[data-ext-tab="permissions"]');
    if (!tab) return 'no-perm-tab';
    tab.click();
    return 'clicked';
  })()`)
  await wait(900)
  if (permTab === 'clicked') ok('permissions tab clicked')
  else bad('permissions tab -> ' + permTab)

  const permRows = await evaluate('document.querySelectorAll("#ext-panel-permissions .ext-row").length')
  if (Number(permRows) >= 9) ok('permission rows rendered: ' + permRows)
  else bad('permission rows: ' + permRows + ' (expected the 9 categories)')

  const hidden = await evaluate(`({
    pluginsHidden: !!document.getElementById('ext-panel-plugins')?.hidden,
    permsHidden: !!document.getElementById('ext-panel-permissions')?.hidden
  })`)
  if (hidden && hidden.pluginsHidden === true && hidden.permsHidden === false) {
    ok('tab switching shows exactly one pane')
  } else bad('pane visibility wrong: ' + JSON.stringify(hidden))

  if (noise.length) {
    bad('console was not clean (' + noise.length + ')')
    noise.slice(0, 8).forEach((n) => console.log('       ' + n))
  } else ok('no console errors or uncaught exceptions')

  // ── collapsible sidebar ───────────────────────────────────────────────────
  // The rail is global chrome: if collapsing it fails to widen the workspace,
  // every module stays cramped no matter what each panel's CSS does. Assert the
  // width contract, not just that a class toggles.
  try {
    await evaluate(`(() => {
      const t = document.querySelector('[data-view-nav="dashboard"]') || document.querySelector('.nav-item[data-view="dashboard"]')
      if (t) t.click()
      localStorage.removeItem('jarvis.sidebar.collapsed')
      document.body.classList.remove('sidebar-collapsed')
      return 'ok'
    })()`)
    await wait(500)
    const wide = await evaluate(`(() => ({
      sidebar: Math.round(document.querySelector('.sidebar').getBoundingClientRect().width),
      workspace: Math.round(document.querySelector('.workspace').getBoundingClientRect().width),
      labels: [...document.querySelectorAll('.nav-item .nav-label')].filter(e => getComputedStyle(e).display !== 'none').length,
      toggle: !!document.querySelector('#sidebar-collapse')
    }))()`)
    await evaluate(`document.querySelector('#sidebar-collapse').click()`)
    await wait(600)
    const narrow = await evaluate(`(() => ({
      collapsed: document.body.classList.contains('sidebar-collapsed'),
      sidebar: Math.round(document.querySelector('.sidebar').getBoundingClientRect().width),
      workspace: Math.round(document.querySelector('.workspace').getBoundingClientRect().width),
      view: Math.round(document.querySelector('.view.active').getBoundingClientRect().width),
      labels: [...document.querySelectorAll('.nav-item .nav-label')].filter(e => getComputedStyle(e).display !== 'none').length,
      // every icon row must still name itself for hover/AT
      tips: [...document.querySelectorAll('.nav-item')].filter(e => (e.dataset.tip || '').length > 0).length,
      navTotal: document.querySelectorAll('.nav-item').length
    }))()`)
    if (!wide.toggle) bad('no #sidebar-collapse control in the sidebar')
    else if (wide.labels !== narrow.navTotal) bad('expanded rail should show every label, saw ' + wide.labels)
    else if (!narrow.collapsed) bad('collapse button did not set body.sidebar-collapsed')
    else if (!(narrow.sidebar < wide.sidebar)) bad('rail did not shrink: ' + wide.sidebar + ' -> ' + narrow.sidebar)
    else if (!(narrow.workspace > wide.workspace)) bad('workspace did not widen: ' + wide.workspace + ' -> ' + narrow.workspace)
    else if (!(narrow.view > wide.workspace)) bad('active view did not rescale with the workspace')
    else if (narrow.labels !== 0) bad('collapsed rail still renders ' + narrow.labels + ' label(s)')
    else if (narrow.tips !== narrow.navTotal) bad('collapsed rail is missing tooltips on ' + (narrow.navTotal - narrow.tips) + ' item(s)')
    else ok('sidebar collapse reclaims width and rescales the active view ('
      + wide.sidebar + '->' + narrow.sidebar + 'px, workspace ' + wide.workspace + '->' + narrow.workspace + 'px)')

    // A collapsed icon-only rail is unusable without its label, so the bubble
    // must be checked for real visibility: an element clipped by the rail's
    // scroll container can still report a correct textContent and opacity.
    await evaluate(`(() => {
      const el = document.querySelector('.nav-item[data-view="cowork"]')
      el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: false }))
      return 'ok'
    })()`)
    await wait(350)
    const tip = await evaluate(`(() => {
      const t = document.querySelector('#nav-tip')
      const r = t.getBoundingClientRect()
      const rail = document.querySelector('.sidebar').getBoundingClientRect()
      return { text: t.textContent, shown: t.classList.contains('show'),
        clearsRail: r.left >= rail.right, onScreen: r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight }
    })()`)
    if (tip.text !== 'Co-work') bad('tooltip text wrong: ' + tip.text)
    else if (!tip.shown) bad('tooltip did not show on a collapsed icon')
    else if (!tip.clearsRail) bad('tooltip is clipped behind the collapsed rail')
    else if (!tip.onScreen) bad('tooltip is drawn outside the viewport')
    else ok('collapsed rail shows an unclipped tooltip ("' + tip.text + '")')
    await evaluate(`document.querySelector('#nav-tip').classList.remove('show')`)
    await evaluate(`document.querySelector('#sidebar-collapse').click()`)
    await wait(400)
  } catch (err) {
    bad('sidebar collapse check threw: ' + err.message)
  }

  try {
    const shot = await send('Page.captureScreenshot', { format: 'png' })
    if (shot.result?.data) {
      const out = path.join(artifactsDir, 'extensions-tab-live.png')
      writeFileSync(out, Buffer.from(shot.result.data, 'base64'))
      console.log('  ok   screenshot -> ' + path.relative(root, out))
    }
  } catch (err) {
    console.log('  note  screenshot skipped: ' + err.message)
  }
  ws.close()
} catch (err) {
  bad(err.message)
} finally {
  cleanup()
}

console.log(`\nDASHBOARD CONSOLE: ${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
