"""Find a playback path that does NOT hang. Test ffplay with SDL drivers + MCI."""
import os, subprocess, sys, time, tempfile, asyncio
sys.path.insert(0, 'background')
import edge_tts

async def _syn():
    c = edge_tts.Communicate('Playback test.', 'en-GB-RyanNeural')
    fd, path = tempfile.mkstemp(suffix='.mp3'); os.close(fd)
    await c.save(path); return path

path = asyncio.run(_syn())

def try_cmd(label, cmd, env=None, timeout=8):
    e = dict(os.environ); 
    if env: e.update(env)
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=e, creationflags=0x08000000)
        out, err = p.communicate(timeout=timeout)
        print('%-28s rc=%s %.2fs err=%r' % (label, p.returncode, time.time()-t0, err[:100]))
    except subprocess.TimeoutExpired:
        p.kill()
        print('%-28s HUNG >%ss' % (label, timeout))

for drv in ['directsound','wasapi','winmm','dummy']:
    try_cmd('ffplay SDL='+drv, ['ffplay','-nodisp','-autoexit','-loglevel','error',path], {'SDL_AUDIODRIVER':drv}, timeout=8)

# Windows MCI native playback (no ffmpeg at all) via mciSendString
mci = ('Add-Type -Namespace W -Name M -MemberDefinition '
       '"[DllImport(\'\'winmm.dll\'')] public static extern int mciSendString(string c, System.Text.StringBuilder r, int l, IntPtr h);";'
       '$b=New-Object System.Text.StringBuilder 256;'
       '[W.M]::mciSendString("open \\"' + path.replace('/', '\\') + '\\" type mpegvideo alias j", $b, 256, [IntPtr]::Zero)|Out-Null;'
       '[W.M]::mciSendString("play j wait", $b, 256, [IntPtr]::Zero)|Out-Null;'
       '[W.M]::mciSendString("close j", $b, 256, [IntPtr]::Zero)|Out-Null')
t0 = time.time()
try:
    p = subprocess.Popen(['powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-WindowStyle','Hidden','-Command',mci],
                         stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=0x08000000)
    out, err = p.communicate(timeout=10)
    print('%-28s rc=%s %.2fs' % ('MCI powershell', p.returncode, time.time()-t0))
except subprocess.TimeoutExpired:
    p.kill(); print('%-28s HUNG >10s' % 'MCI powershell')
os.remove(path)
print('DONE')
