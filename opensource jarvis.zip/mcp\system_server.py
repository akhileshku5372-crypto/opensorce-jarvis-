"""Read-only local telemetry MCP server for JARVIS Co-work.

Newline-delimited JSON-RPC 2.0 over stdio. Exposes two bounded, honest tools:

  * current_time   - local date/time + timezone name
  * system_metrics - CPU load sampled from GetSystemTimes, physical memory from
                     GlobalMemoryStatusEx, and disk usage for the repo drive

No shell, no process listing/control, no file access, no network, no credentials.
On non-Windows hosts the CPU/memory fields report "unavailable" instead of fake
numbers.
"""
from __future__ import annotations

import ctypes
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOOLS = [
    {
        "name": "current_time",
        "description": "Return the local date, time and timezone (read-only).",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "system_metrics",
        "description": "Return real CPU load, physical memory and repo-drive disk usage.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {}},
    },
]

def _cpu_load():
    if sys.platform != "win32":
        return None
    class FileTime(ctypes.Structure):
        _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]

    def sample():
        idle, kernel, user = FileTime(), FileTime(), FileTime()
        ok = ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user))
        if not ok:
            raise OSError("GetSystemTimes failed")
        joined = lambda ft: (ft.high << 32) | ft.low
        return joined(idle), joined(kernel) + joined(user)

    try:
        first = sample()
        time.sleep(0.2)
        second = sample()
    except OSError:
        return None
    idle_delta = second[0] - first[0]
    busy_delta = second[1] - first[1]
    if busy_delta <= 0:
        return None
    percent = 100.0 * (busy_delta - idle_delta) / float(busy_delta)
    return round(max(0.0, min(percent, 100.0)), 1)


def _memory():
    if sys.platform != "win32":
        return None
    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_uint32), ("memory_load", ctypes.c_uint32),
                    ("total_phys", ctypes.c_uint64), ("avail_phys", ctypes.c_uint64),
                    ("total_page", ctypes.c_uint64), ("avail_page", ctypes.c_uint64),
                    ("total_virtual", ctypes.c_uint64), ("avail_virtual", ctypes.c_uint64),
                    ("avail_extended", ctypes.c_uint64)]

    status = MemoryStatus()
    status.length = ctypes.sizeof(MemoryStatus)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        return None
    return {"percent": int(status.memory_load),
            "total_mb": int(status.total_phys // (1024 * 1024)),
            "available_mb": int(status.avail_phys // (1024 * 1024))}


def _reply(request_id, result):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result}) + "\n")
    sys.stdout.flush()


def _text(request_id, message, is_error=False):
    _reply(request_id, {"content": [{"type": "text", "text": message}],
                       "isError": bool(is_error)})


def _handle(request_id, params):
    name = params.get("name")
    if name == "current_time":
        now = datetime.now(timezone.utc).astimezone()
        return _text(request_id, json.dumps({
            "iso": now.isoformat(timespec="seconds"),
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "timezone": str(now.tzname() or "local"),
            "utc_offset_minutes": int(
                (now.utcoffset() or timezone.utc.utcoffset(now)).total_seconds() // 60),
        }))
    if name == "system_metrics":
        try:
            usage = shutil.disk_usage(ROOT.anchor or ROOT)
            disk = {"total_gb": round(usage.total / (1024 ** 3), 1),
                    "used_gb": round(usage.used / (1024 ** 3), 1),
                    "free_gb": round(usage.free / (1024 ** 3), 1),
                    "drive": str(ROOT.anchor or "/")}
        except OSError:
            disk = None
        payload = {
            "cpu_load_percent": _cpu_load(),
            "memory": _memory(),
            "disk": disk,
            "sampled_at": time.time(),
            "host": {"python": sys.version.split()[0], "platform": sys.platform},
        }
        return _text(request_id, json.dumps(payload))
    return _text(request_id, "unknown tool: %s" % name, True)


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, request_id = message.get("method"), message.get("id")
        if method == "initialize":
            _reply(request_id, {"protocolVersion": "2024-11-05",
                                "capabilities": {"tools": {}},
                                "serverInfo": {"name": "jarvis-system", "version": "1.0.0"}})
        elif method == "tools/list":
            _reply(request_id, {"tools": TOOLS})
        elif method == "tools/call":
            _handle(request_id, message.get("params") or {})
        elif request_id is not None:
            _reply(request_id, {"error": {"code": -32601,
                        "message": "method not found: %s" % method}})


if __name__ == "__main__":
    main()
