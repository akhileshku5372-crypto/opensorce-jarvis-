---
name: careful-work
description: Sahi kaam karne ka tareeka - sochne ke baad hi code likho, simple rakho, sirf zaroori jagah badlo, aur har baat test se verify karo.
triggers: careful work, soch ke karo, galat mat karo, pehle socho, verify karo, kaam dhyan se, careful mode, step by step karo
---

# Careful Work

Ye skill code likhne se pehle sochne aur phir verify karne ka tareeka hai. Isko
sirf coding ya file-editing kaam par use karo — normal chat par nahi.

## 1. Pehle socho, phir likho
- Farq karke batao. "Pata nahi hai" kehna galat nahi hai — andaza lagana galat hai.
- Agar do matlab ban rahe hain, dono batao aur ek chuno. chup-chaap ek chun ke chalna mat.
- Aasan tareeka ho to bata do. Kam me zyada time lagega to seedha keh do.
- Jo cheez samajh nahi aayi, usko naam dekar ruk jao. chup-chaap guess mat karo.

## 2. Simple rakho
- Sirf utna hi code jo kaam kar jaye. Aage ki soch ka code mat likho.
- Ek hi jagah use hone wali cheez ka abstraction mat banao.
- "Baad mein kaam aayegi" wali config aur flexibility abhi mat banao.
- Agar 200 line ka kaam 50 line mein ho raha hai, to 50 wala likho.

## 3. Sirf zaroori hissa badlo
- Jo request hai sirf wahi badlo. Aas-paas ka code, comment ya formatting mat chhedo.
- Jo kaam nahi kar raha use fix mat karo. Reformat "better" ke liye mat karo.
- Baaki code ki style (quotes, spacing, naming) ko jaisa hai waisa hi rakho.
- Apne change se bekaar ho jaane wali sirf wahi cheez hatao jo tumne banayi.

## 4. Verify karo, maan mat lo
- Kaam shuru karne se pehle soch lo test kaise dikhaega ki ban gaya.
- Bug fix: pehle wo test likho jo bug dikhata hai, phir fix karo, phir test pass karo.
- Bade kaam ko chhote steps mein todo, aur har step ke saath likho ki check kya hai.
- Kaam khatam hone ke baad poora test suite chalao, sirf apna test nahi.

Rules:
- Kaam pura hone ka matlab "compile ho gaya" nahi hota — matlab test pass hona.
- Test fail kare to chup-chaap mat hatao. Wajah batao.
- Report karte waqt honest reho: kya test chala, kya pass hua, kya nahi chala, kyun.
- 70/25/10 tone rakho — seedhi baat, koi dramatics nahi.