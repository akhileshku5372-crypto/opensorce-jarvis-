# Swaps the Groq key and drops unused provider keys. Prints NAMES only.
$root = 'c:\Users\PRATEEK\Downloads\jarvis 1.0.5'
$newGroq = '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'
$drop = '^(LIVEKIT_URL|LIVEKIT_API_KEY|LIVEKIT_API_SECRET|MEM0_API_KEY|ELEVENLABS_API_KEY|ELEVENLABS_VOICE_ID)='
$enc = New-Object System.Text.UTF8Encoding($false)
foreach ($f in @('.env', '.dev.vars')) {
    $p = Join-Path $root $f
    if (-not (Test-Path $p)) { Write-Host "$f missing - skipped"; continue }
    $lines = [System.IO.File]::ReadAllLines($p)
    $out = New-Object System.Collections.Generic.List[string]
    $swapped = 0; $dropped = 0
    foreach ($line in $lines) {
        if ($line -match $drop) { $dropped++; continue }
        if ($line -match '^GROQ_API_KEY=') { $out.Add('GROQ_API_KEY=' + $newGroq); $swapped++; continue }
        $out.Add($line)
    }
    [System.IO.File]::WriteAllLines($p, $out, $enc)
    Write-Host ("{0}: groq_swapped={1} keys_removed={2}" -f $f, $swapped, $dropped)
}