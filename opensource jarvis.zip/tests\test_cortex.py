"""Cortex Plan -> Act -> Observe runtime tests (stdlib only)."""
import importlib.util
import threading
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = ROOT / "background"


def _load(name):
    spec = importlib.util.spec_from_file_location(name, BACKGROUND / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


CORTEX = _load("cortex")


class CortexRuntimeTest(unittest.TestCase):
    def setUp(self):
        self._clean()

    def tearDown(self):
        self._clean()

    def _clean(self):
        runner = getattr(CORTEX, "_runner", None)
        if runner is not None and runner.is_alive():
            runner.join(timeout=5)
        CORTEX._runner = None
        CORTEX._run = None
        CORTEX._cancel = threading.Event()
        try:
            CORTEX.STORE.unlink()
        except FileNotFoundError:
            pass

    def _wait(self, predicate, timeout=5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.02)
        return predicate()

    def test_registry_rejects_duplicates_and_unknown_tools(self):
        registry = CORTEX.ToolRegistry()
        spec = CORTEX.ToolSpec("echo", "Echo text", lambda args: args.get("text", ""))
        self.assertTrue(registry.register(spec)[0])
        self.assertFalse(registry.register(spec)[0])
        self.assertFalse(registry.execute("shell", {})["ok"])
        self.assertIn("echo", registry.catalog())

    def test_confirmation_gate_prevents_handler(self):
        called = []
        registry = CORTEX.ToolRegistry()
        registry.register(CORTEX.ToolSpec(
            "delete_item", "Delete an item", lambda args: called.append(args),
            requires_confirmation=True,
        ))
        denied = registry.execute("delete_item", {"id": "1"}, confirm=lambda *_: False)
        self.assertFalse(denied["ok"])
        self.assertTrue(denied["denied"])
        self.assertEqual(called, [])
        self.assertFalse(registry.execute("delete_item", {"id": "1"})["ok"])

    def test_completed_run_feeds_observation_back_to_planner(self):
        calls = []
        registry = CORTEX.ToolRegistry()
        registry.register(CORTEX.ToolSpec("look_up", "Look up a value", lambda args: "value=42"))

        def planner(goal, catalog, observations, skills):
            calls.append((goal, catalog, observations, skills))
            if not observations:
                return {"tool": "look_up", "args": {"key": "answer"}}
            return {"done": True, "answer": observations[-1]["output"]}

        ok, _ = CORTEX.start("find answer", planner, registry)
        self.assertTrue(ok)
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_DONE))
        view = CORTEX.snapshot()
        self.assertEqual(view["reason"], "completed")
        self.assertEqual(view["answer"], "value=42")
        self.assertEqual(view["steps"][0]["status"], "done")
        self.assertEqual(calls[1][2][0]["tool"], "look_up")

    def test_fanout_executes_independent_actions_in_parallel(self):
        registry = CORTEX.ToolRegistry()
        registry.register(CORTEX.ToolSpec("add", "Add numbers",
                                           lambda args: "5"))
        registry.register(CORTEX.ToolSpec("mult", "Multiply numbers",
                                           lambda args: "20"))

        def planner(goal, catalog, observations, skills):
            if len(observations) >= 2:
                return {"done": True, "answer": "fan-out complete"}
            return {"tool": "fan_out", "args": {},
                    "fan_out": [
                        {"tool": "add", "args": {"a": "2", "b": "3"}},
                        {"tool": "mult", "args": {"a": "4", "b": "5"}},
                    ]}

        ok, _ = CORTEX.start("parallel math", planner, registry)
        self.assertTrue(ok)
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_DONE))
        view = CORTEX.snapshot()
        self.assertEqual(view["reason"], "completed")
        self.assertEqual(len(view["steps"]), 2)
        outputs = [s["output"] for s in view["steps"]]
        self.assertIn("5", outputs)
        self.assertIn("20", outputs)
        self.assertIn("fan-out", view["summary"].get("output", ""))

    def test_identical_actions_stop_as_loop_detected(self):
        calls = []
        registry = CORTEX.ToolRegistry()
        registry.register(CORTEX.ToolSpec("poll", "Poll once", lambda args: calls.append(1) or "same"))
        CORTEX.start("poll forever", lambda *_: {"tool": "poll", "args": {}}, registry)
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_FAILED))
        self.assertEqual(CORTEX.snapshot()["reason"], "loop_detected")
        self.assertEqual(len(calls), 2)

    def test_empty_observations_stop_as_no_progress(self):
        registry = CORTEX.ToolRegistry()
        registry.register(CORTEX.ToolSpec("empty", "Return no output", lambda args: ""))
        calls = []
        def planner(*_):
            calls.append(1)
            return {"tool": "empty", "args": {"attempt": len(calls)}}
        CORTEX.start("try empty", planner, registry)
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_FAILED))
        self.assertEqual(CORTEX.snapshot()["reason"], "no_progress")
        self.assertEqual(len(CORTEX.snapshot()["steps"]), 3)

    def test_planner_error_is_terminal_and_not_executed(self):
        def planner(*_):
            raise ValueError("planner failed")
        ok, _ = CORTEX.start("bad plan", planner, CORTEX.ToolRegistry())
        self.assertTrue(ok)
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_FAILED))
        self.assertEqual(CORTEX.snapshot()["reason"], "planner_error")
        self.assertEqual(CORTEX.snapshot()["steps"], [])


    def test_cancellation_preserves_cancelled_state(self):
        started = threading.Event()
        release = threading.Event()
        registry = CORTEX.ToolRegistry()
        def handler(_):
            started.set()
            release.wait(2)
            return "late result"
        registry.register(CORTEX.ToolSpec("waiter", "Wait", handler, timeout_s=3))
        CORTEX.start("cancel me", lambda *_: {"tool": "waiter", "args": {}}, registry)
        self.assertTrue(started.wait(2))
        self.assertTrue(CORTEX.cancel()[0])
        release.set()
        self.assertTrue(self._wait(lambda: CORTEX.snapshot()["status"] == CORTEX.STATUS_CANCELLED))
        self.assertEqual(CORTEX.snapshot()["steps"][0]["status"], "cancelled")

    def test_persisted_running_run_becomes_interrupted(self):
        CORTEX.STORE.parent.mkdir(parents=True, exist_ok=True)
        CORTEX.STORE.write_text(
            '{"id":"abc","goal":"g","status":"running","reason":"","answer":"",'
            '"steps":[{"tool":"x","status":"running","output":""}],"created_at":1,"updated_at":1}',
            encoding="utf-8",
        )
        CORTEX._run = None
        view = CORTEX.load_persisted()
        self.assertEqual(view["status"], CORTEX.STATUS_INTERRUPTED)
        self.assertEqual(view["reason"], "interrupted")
        self.assertEqual(view["steps"][0]["status"], "skipped")


if __name__ == "__main__":
    unittest.main(verbosity=2)

