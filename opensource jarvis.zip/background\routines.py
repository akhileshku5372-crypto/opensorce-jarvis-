"""Routine memory (Phase 3 of self-learning) - Stark-style passive learning.

Sir does not sit JARVIS down to teach it tasks; JARVIS watches real work
happen and keeps the recipe of every task it actually completed:

  * every CONFIRMED successful action lands as (task, tool) in the routine
    store - a task is the user's own phrase for the request recorded BEFORE
    execution, a tool is the mechanism that really did it;
  * a recipe survives only where the tool keeps proving itself: successes
    strengthen it, real failures weaken and eventually retire it;
  * the brain gets the recipes in every prompt, so an unfamiliar phrasing of
    a known task is answered with the mechanism that already worked on THIS
    machine - not with an invented plan;
  * everything lives on device in artifacts/brain/routines.json, bounded,
    atomic, and strictly additive: a missing or broken module must never
    change how anything actually executes.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# A test run must never touch the owner's live store: JARVIS_ROUTINES_STORE
# redirects the file for that process (roped in by the test suites).
STORE = Path(os.environ.get(
    "JARVIS_ROUTINES_STORE",
    str(ROOT / "artifacts" / "brain" / "routines.json")))
MAX_RECIPES = 120
RETIRE_AFTER = 3      # consecutive real failures retire a recipe
PROMPT_KEEP = 6

_LOCK = threading.RLock()

# Tokens that never identify a task. Deliberately tiny: dropping meaningful
# words would merge two different tasks into one false recipe.
_STOP = {"please", "sir", "hey", "jarvis", "abhi", "fir", "phir", "toh", "to"}


def _norm(task):
    words = [w for w in "".join(
        ch if (ch.isalnum() or ch.isspace()) else " " for ch in str(task or "")).lower().split()]
    words = [w for w in words if w not in _STOP]
    return " ".join(words[:8])


def _load():
    try:
        if STORE.is_file():
            return json.loads(STORE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STORE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STORE)


def observe(task, tool, ok=True):
    """One real outcome for one task phrase. Returns (key, changes). Never raises."""
    key = _norm(task)
    tool = str(tool or "").strip()[:80]
    if not key or not tool:
        return ("", False)
    with _LOCK:
        data = _load()
        recipes = data.get("recipes") or {}
        r = recipes.get(key) or {"tool": "", "ok": 0, "fail": 0,
                                 "streak_fail": 0, "first_at": "", "last_at": ""}
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        if ok:
            # Confirmed success - the recipe keeps proving itself.
            r["tool"] = tool
            r["ok"] = int(r.get("ok") or 0) + 1
            r["streak_fail"] = 0
        else:
            r["fail"] = int(r.get("fail") or 0) + 1
            r["streak_fail"] = int(r.get("streak_fail") or 0) + 1
        r["last_at"] = now
        r.setdefault("first_at", now)
        recipes[key] = r
        if int(r.get("streak_fail") or 0) >= RETIRE_AFTER:
            recipes.pop(key, None)      # a broken recipe is not a recipe
        if len(recipes) > MAX_RECIPES:
            ordered = sorted(recipes.items(),
                             key=lambda kv: kv[1].get("last_at") or "",
                             reverse=True)
            recipes = dict(ordered[:MAX_RECIPES])
        data["recipes"] = recipes
        data["updated_at"] = time.time()
        try:
            _save(data)
        except Exception:
            return (key, False)
        return (key, True)


def best(task):
    """The learned recipe for a task: exact phrase first, then token overlap.

    An entry with zero confirmed successes is not a recipe yet, so it can
    never be recalled however many times its tool stumbled.
    """
    key = _norm(task)
    if not key:
        return None
    with _LOCK:
        data = _load()
        recipes = data.get("recipes") or {}
    recipes = {k: r for k, r in recipes.items() if int(r.get("ok") or 0)}
    if not recipes:
        return None
    if key in recipes:
        return (key, recipes[key])
    want = set(key.split())
    best_key, best_hits = None, 1
    for k, r in recipes.items():
        hits = len(want & set(k.split()))
        if hits > best_hits:
            best_key, best_hits = k, hits
    return (best_key, recipes[best_key]) if best_key else None


def prompt_line(k=PROMPT_KEEP):
    """The recipes clause for the system prompt ("" before anything was done)."""
    with _LOCK:
        data = _load()
        recipes = data.get("recipes") or {}
    ordered = sorted(recipes.items(), key=lambda kv: kv[1].get("last_at") or "",
                     reverse=True)[:max(1, int(k))]
    parts = []
    for k_, r in ordered:
        tries = int(r.get("ok") or 0)
        if tries and r.get("tool"):
            parts.append("'%s' -> %s (%dx sahi)" % (k_, r["tool"], tries))
    if not parts:
        return ""
    return (" RECIPE MEMORY (learned from real successful runs on this machine; "
            "when Sir asks for one of these, the tool listed here is the known "
            "working way; never auto-execute what needs confirmation): %s."
            % "; ".join(parts))


def readoff(k=8):
    """Audit trail, newest first."""
    with _LOCK:
        data = _load()
        recipes = data.get("recipes") or {}
    ordered = sorted(recipes.items(), key=lambda kv: kv[1].get("last_at") or "",
                     reverse=True)[:max(1, int(k))]
    return {"recipes": [{"task": k_, "tool": r.get("tool", ""),
                         "ok": int(r.get("ok") or 0),
                         "fail": int(r.get("fail") or 0)}
                        for k_, r in ordered],
            "path": str(STORE)}


def purge():
    """Test hook: forget every recipe."""
    with _LOCK:
        _save({"recipes": {}, "updated_at": time.time()})
