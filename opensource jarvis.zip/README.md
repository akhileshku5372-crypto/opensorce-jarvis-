# JARVIS v0.10.0

## Project overview

JARVIS is a voice-first AI command center for Windows. This repository continues the supplied Genspark project rather than rebuilding it from scratch. It contains:

1. A responsive Hono/Cloudflare-compatible web dashboard.
2. A loopback-only Node.js Windows bridge for allowlisted desktop actions.
3. Browser voice, camera, MediaPipe hand-landmark tracking, local memory, notes, reminders, and server-side AI provider routes.

The dashboard is intentionally minimal on the first screen; advanced functions live in the sidebar.

## Completed features

- Laptop-friendly sci-fi dashboard inspired by the supplied reference image
- Compact scrollable ChatGPT/Gemini-style conversation embedded directly in the main dashboard; commands no longer force another interface open
- Responsive sidebar: Dashboard, Voice, Web Intelligence, Automation, Vision, Gesture, System & Files, Productivity, Memory, Security, and Settings
- One canonical browser-independent Python voice runtime; the dashboard and floating HUD are visual clients of that engine
- Revisioned loopback state/event channel keeps both UIs synchronized without duplicate JARVIS engines
- Runtime UI states: standby, listening, thinking, searching, working/executing, speaking, interrupted, error, and offline
- Reference-matched two-surface desktop HUD: a separate animated cyan reactor orb on the left and a tall glass chat/status console on the right, always-on-top when Chrome is minimized or closed
- Floating console mirrors real transcripts/responses, accepts typed commands through the canonical core, and can hide, close, or reopen the dashboard without stopping voice
- Reference polish: segmented live waveform bars, reactor outer arc brackets, and divider lines between conversation turns
- Floating HUD single-instance guard prevents duplicate HUD processes; hiding or closing it never stops the engine
- Fixed floating-panel minimize behavior: minus or Escape enters a recoverable orb-only mode instead of hiding every borderless surface; clicking the reactor face or its cyan chevron restores the full panel
- Empty floating history now shows a neutral voice-link state rather than fabricated user/JARVIS demonstration turns
- English, Hindi, Hinglish, Japanese, and mixed-language conversations with automatic script detection: pure Devanagari/Hiragana/Latin text uses male specialist voices (Madhur, Keita, Ryan), while mixed-script sentences route to the multilingual Andrew voice which native code-switches English/Hindi/Japanese per phrase (Plan B edge-tts — free Microsoft Edge TTS, no API key)
- Browser STT for low latency plus Groq Whisper cloud STT for stronger multilingual recognition
- Browser voices plus optional ElevenLabs multilingual TTS with automatic Windows SAPI fallback when cloud audio cannot be played
- Barge-in cancellation now covers both active audio playback and in-flight cloud TTS requests, preventing interrupted speech from restarting via fallback
- Optional continuous “Hey JARVIS” mode after one user gesture grants browser permission
- Speech interruption cancels active browser or ElevenLabs TTS when new speech begins
- Voice-safe TTS sanitization: URLs, Markdown symbols, and code-like formatting are not spoken raw
- Duplicate-command suppression in the browser, canonical Python core, and Windows bridge; bridge dedupe is recorded only after successful execution so offline-core fallback cannot swallow commands
- Serialized canonical command execution prevents overlapping tools without launching a second engine; bounded history supports follow-up conversations
- Wake-only prompts expire after 12 seconds, live microphone energy publishes `LISTENING` immediately, and sustained high-energy speech can barge in while ordinary speaker echo is suppressed
- STT runs outside the real-time microphone loop, so AI/network latency no longer blocks passive capture; after every answer the state automatically returns to standby
- Centralized **Clear Chat**: one canonical action (`clear_chat`) behind the dashboard button, the floating-HUD button, and the voice command "clear the chat" — every live UI resyncs through a `clear_seq` bell so chat, floating history, and short-term LLM context are wiped together while memories/notes/configuration stay intact
- Structured `[CHAT]`/`[CLEAR]`/`[TTS]` diagnostics in `%TEMP%\jarvis_core_diag.log`, configurable extra wake phrases (`JARVIS_WAKE_WORD=csv` or `--wake-word`, repeatable), and a `POST /stop` endpoint with an `is_speaking()` helper for interruptible-TTS consumers
- Boot-time **live microphone auto-select**: a soft startup chirp plays through the speakers while each input is probed, so the always-on wake loop attaches to the endpoint that actually hears audio (Windows laptops often leave the default input dead/stale) — "Hey JARVIS" then works with no listening button at all
- Dashboard **HUD pill** instantly summons the floating JARVIS console (`POST /float`); the floating HUD also auto-appears when the dashboard tab is minimized, and the background engine runs independently of any browser tab
- The HUD menu now separates "Hide/Close HUD (engine keeps running)" from a **confirmed** "Exit JARVIS (stop everything)", so the always-on voice loop can never be killed by an accidental click
- Compact reference-inspired floating HUD with a dark glass shell, cyan rails, animated orb/rings/particles, real transcript/response panels, and live active-task rail
- Arbitrary Google, Bing, DuckDuckGo, and YouTube searches
- Deterministic low-latency routes for YouTube search, web search, known websites, arbitrary domains, and likely desktop commands before the LLM fallback
- Voice/text examples such as `Open YouTube and search lo-fi music` and `web pe quantum computing search karo`
- Direct opening for known sites plus typed domain names such as `open example.com`
- Modular Ollama, Groq, OpenRouter, and dual-key Gemini server-side AI provider routing
- Canonical structured action tags connect natural AI intent to browser, research, productivity, vision, and Windows tools
- Working live-answer, weather, news, timer, note, reminder, and camera-analysis action handlers
- Bounded chat context and user-approved local memory
- Local notes and reminders, including the next reminder on the dashboard
- Camera preview with real MediaPipe hand skeleton, landmark drawing, and pinch detection
- Live bridge status and CPU/RAM telemetry, including background-core bridge reconnect monitoring
- Safe local Windows actions without unrestricted shell execution
- Direct application launch with hidden/no extra CMD window
- App/folder/site opening, arbitrary domain opening, scoped file search, web/YouTube search, screenshot, volume, window switch, lock, and system-info actions
- Browser back/forward/new-tab/close-tab/in-page-find controls through the safe local bridge
- English, Hinglish/Hindi-style, and Japanese direct search/open command patterns
- Destructive actions are not exposed in the current bridge

## KamiSensei knowledge workspace

KamiSensei now preserves the existing three-panel **Sources | Chat | Studio** layout and implements the active NotebookLM-style study workflow end to end:

- Persistent filesystem source registry with PDF/TXT/MD/JSON upload, validation, deletion, SHA-256 change detection, ChromaDB indexing, and strict selected-source retrieval boundaries
- Real page-aware extraction with PyMuPDF/pypdf and optional Tesseract OCR for image-only PDFs; unextractable pages are reported instead of being replaced with invented content
- Genuine Gemini/Groq streaming chat with isolated scrolling, thinking state, bounded IndexedDB history, and citations that retain real source/page/snippet metadata
- Persistent IndexedDB artifact library with a generic Studio dashboard → full-panel artifact-view transition; Sources and Chat remain visible
- Notes, Mind Map, Reports, Flashcards, Quiz, and Data Table generation through one RAG-grounded, schema-validated pipeline with one repair attempt
- Interactive mind-map pan/zoom/fit/collapse, editable notes, document reports, keyboard-enabled flashcards with shuffle/restart, scored quiz review, and searchable/sortable tables
- Pointer-driven Studio resizing, 320 px minimum, 60% viewport maximum, persisted width, and renderer adaptation through `ResizeObserver`
- Audio Overview, Video Overview, Slide Deck, and Infographic remain disabled in the Studio UI as intentionally out of scope

Artifact envelope:

```text
{ id, type, title, createdAt, updatedAt, sourceIds, sourceCount, content, status, error }
```

## Functional URIs

| Method | URI | Description |
| --- | --- | --- |
| GET | `/` | JARVIS command center |
| GET | `/api/health` | Edge UI health, version, and supported AI providers |
| POST | `/api/ai/chat` | AI chat; accepts `messages`, `lang`, `provider`, bridge state, and optional approved `memories` |
| POST | `/api/stt` | Groq Whisper transcription for uploaded browser audio |
| POST | `/api/tts` | ElevenLabs multilingual speech audio proxy |
| POST | `/api/vision` | Camera-frame visual question answering |
| GET | `/api/answer?q=...&lang=...` | Live web snippets with a concise AI answer |
| GET | `/api/weather?city=...` | Current weather and seven-day forecast data |
| GET | `/api/news?category=...` | Current Google News RSS headlines |
| GET | `/api/kamisensei/status` | Local source/vector service status and configured model metadata |
| GET | `/api/kamisensei/files` | Persistent source registry |
| POST | `/api/kamisensei/upload` | Validated source upload and ingestion trigger |
| POST | `/api/kamisensei/delete` | Delete one source and its stale vectors |
| POST | `/api/kamisensei/query` | Source-grounded streaming chat (SSE) |
| POST | `/api/kamisensei/artifact` | Typed generation for the six enabled artifact types |
| POST | `/api/kamisensei/create-notebook` | Create a persistent local notebook descriptor |
| GET | `/static/style.css` | Dashboard styles |
| GET | `/static/app.js` | Browser runtime and command router |
| GET | `http://127.0.0.1:7778/api/status` | Local bridge status and telemetry |
| POST | `http://127.0.0.1:7778/api/action` | Allowlisted local action; body: `{ "command": "open vscode" }` |
| GET | `http://127.0.0.1:7780/state` | Canonical background-core state and recent revisioned events |
| POST | `http://127.0.0.1:7780/action` | Route typed UI input into the same canonical engine |
| POST | `http://127.0.0.1:7780/float` | Reveal the single floating HUD instance |

## Windows quick start

Requirements: Windows 10/11, Node.js 20+, Python 3.10+, npm, Chrome or Edge, microphone permission, and optional camera permission for vision/gesture features.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-windows.ps1
```

Then open `http://127.0.0.1:7777`. The setup script starts UI port 7777, bridge port 7778, background state port 7780, and the floating HUD.

For a normal local launch after setup:

```powershell
npm run jarvis
```

This starts the v0.10.0 HUD automatically. Say `Hey JARVIS`—there is no listening-button step. After JARVIS completes and speaks a task, it returns to passive wake listening by itself. Use the panel minus button or Escape for compact orb-only mode, then click the reactor face or cyan chevron to restore the conversation panel. The Windows login shortcut also starts with `-Float`, ensuring the HUD is surfaced even when a core process was already running. Use `npm run jarvis:headless` only when you intentionally do not want the overlay.

The launcher starts only missing services, checks port 7780 before launching the core, and the Python core also enforces a single-instance lock. It rejects WindowsApps execution-alias stubs and records the selected interpreter and core PID in `%TEMP%\jarvis_core_diag.log`. HUD startup, guard exits, polling failures, and crash tracebacks are recorded in `%TEMP%\jarvis_hud_diag.log`.

To tune double-clap wake against the real microphone, run:

```powershell
python .\background\jarvis_core.py --calibrate-clap
```

This prints live RMS for about 10 seconds alongside the configured `CLAP_ENERGY_THRESHOLD`. Adjust that value and `CLAP_DELTA_RATIO` in `jarvis-core/config.json` if needed. `AUTO_SPAWN_HUD` in the same file controls default HUD startup; an explicit `--no-hud` still overrides it.

The bridge binds only to `127.0.0.1:7778`. It reports compatibility mode instead of pretending actions succeeded when run on Linux/macOS.

## Windows live acceptance checklist

Static checks cannot prove that Tkinter rendered a HUD or that the Windows microphone captured audio. Run this sequence on the target Windows 10/11 machine and retain `%TEMP%\jarvis_core_diag.log` plus `%TEMP%\jarvis_hud_diag.log` (and preferably a screenshot) as evidence.

- [ ] `.\setup-windows.ps1` completes with no errors
- [ ] `npm run jarvis` starts UI (`:7777`), bridge (`:7778`), and core (`:7780`)
- [ ] `%TEMP%\jarvis_core_diag.log` shows the real interpreter chosen for the HUD (not a WindowsApps alias path) and its PID
- [ ] Floating HUD window appears within 5 seconds of core start, unprompted
- [ ] Minimizing or closing the browser dashboard does not close the HUD or stop the core
- [ ] “Hey JARVIS” wakes it from standby (the log shows the wake event)
- [ ] Double-clap wakes it as an alternative trigger (the log shows measured RMS against the calibrated threshold)
- [ ] A spoken command is transcribed correctly (the log shows non-empty STT text and provider) and answered aloud (the log shows the TTS engine used)
- [ ] Speaking while JARVIS talks stops audio immediately (barge-in)
- [ ] It returns to standby and wakes again without a restart
- [ ] The diagnostic logs have no unexplained silent gaps across the whole sequence

If any box fails, preserve the exact diagnostic trace and report the first concrete failure reason rather than treating static tests as proof of success.

## AI configuration

The supplied local project uses `.dev.vars` for the Wrangler preview and `.env` for future native modules. Both files are ignored by git. Use `.env.example` when creating a fresh installation.

```text
GROQ_API_KEY=your_fresh_key
GROQ_MODEL=your_model

# Optional fallbacks
OPENROUTER_API_KEY=your_fresh_key
OPENROUTER_MODEL=your_model
GOOGLE_API_KEY=your_fresh_key
GOOGLE_API_KEY_2=optional_second_fresh_key
GOOGLE_MODEL=gemini-flash-lite-latest

# Optional localhost model
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_MODEL=qwen3:8b
```

Never paste provider keys into `public/`, frontend JavaScript, or committed source. Credentials previously posted in chat should be considered compromised and rotated before use.

## Example commands

- `Hey JARVIS, open YouTube and search Japanese N3 grammar`
- `Web pe latest AI news search karo`
- `ユーチューブで日本語N3文法を検索して`
- `東京の天気を教えて`
- `10 minute ka timer laga do`
- `Open GitHub`
- `Open example.com`
- `Open VS Code`
- `Open Downloads`
- `Take a screenshot`
- `Volume up`
- `Mute volume`
- `Switch window`
- `Show system info`
- `Lock my PC`

Unknown OS commands are rejected by the bridge allowlist and can be answered conversationally by the AI console; they are never passed to an unrestricted shell.

## Data architecture

- **Browser localStorage:** JARVIS notes, reminders, display settings, conversation preferences, user-approved memories, and Studio width
- **Browser IndexedDB (`kamisensei`):** artifact bodies/metadata, selected sources, active artifact, and bounded KamiSensei chat history
- **Local filesystem:** source files in `knowledge_base/` and notebook descriptors in `notebooks/<uuid>/metadata.json`
- **ChromaDB:** persistent source chunks and real filename/page/chunk metadata in ignored runtime directory `chroma_db/`
- **AI providers:** server-side Groq/OpenRouter/Gemini fetch routes; keys never reach frontend code
- **Camera/gesture:** processed locally in the browser through MediaPipe; frames are not uploaded by this project
- **Desktop actions:** validated in `local-bridge/server.cjs`, then executed using fixed executables and fixed PowerShell snippets
- **Cloud persistence:** none; KamiSensei knowledge persistence is local to the Windows installation

## Security model

- No API credentials are stored in source
- Bridge listens on loopback only
- CORS allows localhost origins or one explicit `JARVIS_UI_ORIGIN`
- No arbitrary PowerShell, CMD, shell, executable path, or filesystem path from AI/user input
- Duplicate action requests within 2.5 seconds are ignored across UI, core, and bridge layers
- Only validated `http` and `https` URLs can be opened by the Python action router
- Potentially destructive file deletion, restart, shutdown, and external messaging are intentionally not implemented

## Current limitations / not yet implemented

- Always-on wake word, passive auto-resume, and guarded barge-in are implemented by the Python background runtime; final microphone/device/echo-threshold tuning must be performed on the target Windows laptop
- Full page DOM reading/summarization requires a browser extension; safe keyboard-level tab navigation is implemented
- Scoped filename search is implemented for Desktop/Documents/Downloads; semantic indexing, rename/copy/move, and arbitrary file opening still need a permission-scoped index
- Gesture-to-cursor control is not enabled; current implementation provides camera landmarks and pinch detection without taking over the mouse
- GPU temperature, battery, disk, process details, and Defender status are not yet collected by the dependency-free bridge
- Long-term cloud memory, calendar sync, Office automation, smart-home hardware, robotics, and fictional MCU hardware are outside this laptop MVP
- AI calls require fresh valid provider credentials supplied locally by the user
- The bundled 212-page image-only PDF requires Tesseract with `eng+jpn` data for full indexing. Full OCR is intentionally a local one-time operation and can take several minutes; the UI shows **Not indexed** until real chunks exist.
- Live artifact generation was not executed in the sandbox because the continuation ZIP correctly excludes `.env` and `.dev.vars`; schema, retrieval, renderer, API failure, and persistence paths were validated without fabricating a provider response.
- The Python/Tk runtime works without a browser window; optional future Tauri packaging would improve installer polish and Windows tray integration

## Recommended next steps

1. Rotate all credentials previously exposed in chat or shared files.
2. Run the ZIP on Windows and validate each allowlisted bridge action.
3. Optionally package the validated Python core, bridge, and UI with Tauri or an installer for easier distribution.
4. Add a permission-scoped Windows file index and browser extension.
5. Add end-to-end Windows tests for voice → router → action → confirmation → auto-resume.

## Development and validation

```bash
python -m py_compile background/jarvis_core.py background/floating_ui.pyw
npm test
npm run build
python background/jarvis_core.py --selftest
```

Latest sandbox validation (2026-08-30): the Vite/Hono production build passed; 32 artifact assertions, 6 KamiSensei ingestion/retrieval tests, and 32 JARVIS core regressions passed; all relevant Python/JavaScript modules compiled; static assets returned HTTP 200; `/api/health`, the compatibility-mode bridge on `:7778`, and the warmed `/api/kamisensei/status` route returned healthy responses. The cold ChromaDB status timeout was increased to cover first initialization. Browser automation could not complete because the sandbox Playwright browser closed during navigation, so visual interaction QA remains a Windows acceptance item. The continuation archive contains no git-ignored `.env` or `.dev.vars`, therefore genuine provider replies/audio were not claimed as verified. Windows-only microphone, wake-word audio, floating Tk HUD rendering, gestures, and desktop actions still require the checklist above on the target Windows machine.

## Deployment

- **Local Windows:** supported and required for OS actions
- **Cloudflare Pages/Workers:** UI and AI proxy are compatible; Windows bridge remains local
- **Production URL:** not deployed
- **Last updated:** 2026-08-30
- **Current version:** v0.10.0

## Coding-agent handoff

OpenCode and similar agents must read `AGENTS.md`, `REQUIREMENTS.md`, and `JARVIS_PRD.md` before changing the project. `setup-windows.ps1` installs dependencies, validates the bridge/browser runtime, builds the UI, and starts both canonical PM2 processes.
