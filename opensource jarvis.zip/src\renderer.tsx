import { jsxRenderer } from 'hono/jsx-renderer'

export const renderer = jsxRenderer(({ children }) => (
  <html lang="en">
    <head>
      <meta charSet="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta name="theme-color" content="#061017" />
      <meta name="description" content="JARVIS v0.8 multilingual voice-first Windows AI assistant" />
      <title>JARVIS — AI Command Center</title>
      <link rel="icon" href="/static/favicon.svg" type="image/svg+xml" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous" />
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Rajdhani:wght@500;600;700&amp;family=Orbitron:wght@500;600;700;800;900&amp;family=JetBrains+Mono:wght@400;500;600&amp;display=swap" rel="stylesheet" />
      <link href="/static/style.css" rel="stylesheet" />
      <script src="/static/three-bundle.min.js"></script>
      <script src="/static/jszip.min.js" defer></script>
      <script src="https://unpkg.com/lucide@0.468.0/dist/umd/lucide.min.js" defer></script>
      <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" defer></script>
      <script src="https://cdn.jsdelivr.net/npm/@mediapipe/pose/pose.js" defer></script>
      <script src="https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js" defer></script>
      <script src="/static/ks-notebook-store.js" defer></script>
      <script src="/static/ks-state.js" defer></script>
      <script src="/static/ks-artifacts.js" defer></script>
      <script src="/static/agent-flow.js" defer></script>
      <script src="/static/n8n-panel.js" defer></script>
      <script src="/static/brain-holo.js" defer></script>
      <script src="/static/armour-view.js" defer></script>
      <script src="/static/fight-coach.js" defer></script>
      <script src="/static/gesture-control.js" defer></script>
      <script src="/static/app.js" defer></script>
    </head>
    <body>{children}</body>
  </html>
))
