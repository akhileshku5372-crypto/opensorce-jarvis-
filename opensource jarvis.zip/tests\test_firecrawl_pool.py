"""Firecrawl multi-key credit pool: failover + disjoint fanout.

Stdlib + fakes only. No network: every HTTP call is monkeypatched, so these
tests are deterministic and cost zero credits.
"""
import importlib.util
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

KEY1 = "fc-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1"
KEY2 = "fc-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb2"
KEY3 = "fc-cccccccccccccccccccccccccccccc33"


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


KEYS = _load("firecrawl_keys")
CLIENT = _load("firecrawl_client")

# firecrawl_client resolves the pool lazily and may load its OWN copy of
# firecrawl_keys. Pin it to the instance this file drives so parking state
# (and every assertion below) is shared rather than duplicated.
CLIENT._POOL = KEYS

# Real network function, saved so each test can restore it after monkeypatching.
_ORIG_POST_ONCE = CLIENT._post_once

_ENV_VARS = ("FIRECRAWL_API_KEY", "FIRECRAWL_API_KEY_2",
             "FIRECRAWL_API_KEY_3", "FIRECRAWL_API_KEY_4")


class KeyEnvTest(unittest.TestCase):
    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        KEYS.reset()

    def tearDown(self):
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def test_single_key_backward_compatible(self):
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        self.assertEqual(KEYS.keys(), [KEY1])
        self.assertFalse(KEYS.pool_status()["fanout"])

    def test_two_keys_are_one_provider(self):
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        self.assertEqual(KEYS.keys(), [KEY1, KEY2])
        status = KEYS.pool_status()
        self.assertEqual(status["total"], 2)
        self.assertEqual(status["healthy"], 2)
        self.assertTrue(status["fanout"])

    def test_duplicate_key_is_collapsed(self):
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIERCRAWL_API_KEY_2"] = KEY1  # same key pasted twice
        self.assertEqual(KEYS.keys(), [KEY1])

    def test_comma_separated_list_is_accepted(self):
        os.environ["FIRECRAWL_API_KEY"] = "%s,%s" % (KEY1, KEY2)
        self.assertEqual(KEYS.keys(), [KEY1, KEY2])

    def test_no_keys(self):
        self.assertEqual(KEYS.keys(), [])
        self.assertEqual(KEYS.next_key(), "")
        self.assertEqual(KEYS.split_evenly([1, 2, 3]), [])

    def test_status_never_leaks_the_key(self):
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        blob = repr(KEYS.pool_status())
        self.assertNotIn(KEY1, blob)
        # Only the trailing 4 chars may ever surface, behind a mask.
        self.assertIn(KEY1[-4:], blob)


class SplitTest(unittest.TestCase):
    """The heart of the request: key 1 takes N, key 2 takes the NEXT N."""

    def test_forty_sources_split_twenty_twenty(self):
        pairs = KEYS.split_evenly(list(range(1, 41)), [KEY1, KEY2])
        self.assertEqual([len(chunk) for _, chunk in pairs], [20, 20])
        self.assertEqual(pairs[0][1], list(range(1, 21)))
        self.assertEqual(pairs[1][1], list(range(21, 41)))

    def test_slices_are_disjoint_and_lossless(self):
        items = list(range(1, 41))
        pairs = KEYS.split_evenly(items, [KEY1, KEY2])
        merged = [i for _, chunk in pairs for i in chunk]
        self.assertEqual(merged, items)
        self.assertEqual(len(merged), len(set(merged)))

    def test_three_keys(self):
        pairs = KEYS.split_evenly(list(range(30)), [KEY1, KEY2, KEY3])
        self.assertEqual([len(c) for _, c in pairs], [10, 10, 10])

    def test_remainder_goes_to_the_first_keys(self):
        pairs = KEYS.split_evenly(list(range(5)), [KEY1, KEY2])
        self.assertEqual([len(c) for _, c in pairs], [3, 2])

    def test_more_keys_than_items_never_duplicates(self):
        items = [1, 2]
        pairs = KEYS.split_evenly(items, [KEY1, KEY2, KEY3])
        merged = [i for _, chunk in pairs for i in chunk]
        self.assertEqual(sorted(merged), [1, 2])
        self.assertEqual([len(c) for _, c in pairs], [1, 1, 0])

    def test_empty_work_gives_every_key_an_empty_slice(self):
        pairs = KEYS.split_evenly([], [KEY1, KEY2])
        self.assertEqual(pairs, [(KEY1, []), (KEY2, [])])



class ExhaustionTest(unittest.TestCase):
    """Only credit/quota errors park a key. 5xx and 401 must not."""

    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        KEYS.reset()

    def tearDown(self):
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def test_credit_error_parks_the_key(self):
        self.assertTrue(KEYS.report_failure(KEY1, "Insufficient credits"))
        self.assertNotIn(KEY1, KEYS.healthy_keys())
        self.assertIn(KEY2, KEYS.healthy_keys())

    def test_402_parks_the_key(self):
        self.assertTrue(KEYS.report_failure(KEY1, "Payment Required HTTP 402"))
        self.assertNotIn(KEY1, KEYS.healthy_keys())

    def test_transient_error_does_not_park(self):
        self.assertFalse(KEYS.report_failure(KEY1, "HTTP 503 service unavailable"))
        self.assertFalse(KEYS.report_failure(KEY1, "timed out"))
        self.assertFalse(KEYS.report_failure(KEY1, "HTTP 401 unauthorized"))
        self.assertIn(KEY1, KEYS.healthy_keys())

    def test_success_unparks_a_cooled_key(self):
        KEYS.report_failure(KEY1, "out of credit")
        KEYS.report_success(KEY1)
        self.assertIn(KEY1, KEYS.healthy_keys())

    def test_next_key_skips_parked(self):
        KEYS.report_failure(KEY1, "out of credit")
        self.assertEqual(KEYS.next_key(), KEY2)
        self.assertEqual(KEYS.next_key(exclude=[KEY2]), "")

    def test_all_parked_still_lets_the_caller_try_once(self):
        KEYS.report_failure(KEY1, "out of credit")
        KEYS.report_failure(KEY2, "out of credit")
        self.assertEqual(KEYS.healthy_keys(), [])
        self.assertEqual(len(KEYS.keys()), 2)


class FailoverRequestTest(unittest.TestCase):
    """_post must roll to the next key when the first is out of credits."""

    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        KEYS.reset()
        self.calls = []

    def tearDown(self):
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def _fake_post_once(self, results):
        """results: {key: (dict, error_text)}"""
        def fake(path, payload, key, timeout):
            self.calls.append(key)
            return results[key]
        return fake

    def test_fails_over_to_second_key(self):
        CLIENT._post_once = self._fake_post_once({
            KEY1: ({"error": "credits gone"}, "Insufficient credits HTTP 402"),
            KEY2: ({"success": True, "data": {"web": []}}, ""),
        })
        try:
            res = CLIENT._post("/search", {"query": "x"})
            self.assertTrue(res.get("success"))
            self.assertEqual(self.calls, [KEY1, KEY2])
        finally:
            CLIENT._post_once = _ORIG_POST_ONCE

    def test_parked_key_is_skipped_on_the_next_call(self):
        CLIENT._post_once = self._fake_post_once({
            KEY1: ({"error": "credits gone"}, "Insufficient credits HTTP 402"),
            KEY2: ({"success": True, "data": {"web": []}}, ""),
        })
        try:
            CLIENT._post("/search", {"query": "x"})
            self.calls.clear()
            CLIENT._post("/search", {"query": "y"})
            self.assertEqual(self.calls, [KEY2])
        finally:
            CLIENT._post_once = _ORIG_POST_ONCE

    def test_transient_error_is_not_retried_on_another_key(self):
        """A 503 would fail identically on key 2 - do not waste the call."""
        CLIENT._post_once = self._fake_post_once({
            KEY1: ({"error": "boom"}, "Firecrawl HTTP 503"),
            KEY2: ({"success": True, "data": {}}, ""),
        })
        try:
            res = CLIENT._post("/search", {"query": "x"})
            self.assertIn("error", res)
            self.assertEqual(self.calls, [KEY1])
        finally:
            CLIENT._post_once = _ORIG_POST_ONCE
    def test_pinned_key_never_switches(self):
        CLIENT._post_once = self._fake_post_once({
            KEY1: ({"success": True, "data": {}}, ""),
            KEY2: ({"success": True, "data": {}}, ""),
        })
        try:
            CLIENT._post("/scrape", {"url": "u"}, key=KEY1)
            self.assertEqual(self.calls, [KEY1])
        finally:
            CLIENT._post_once = _ORIG_POST_ONCE

    def test_all_keys_exhausted_returns_a_clear_error(self):
        CLIENT._post_once = self._fake_post_once({
            KEY1: ({"error": "e1"}, "Insufficient credits"),
            KEY2: ({"error": "e2"}, "Insufficient credits"),
        })
        try:
            res = CLIENT._post("/search", {"query": "x"})
            self.assertIn("error", res)
            self.assertEqual(self.calls, [KEY1, KEY2])
        finally:
            CLIENT._post_once = _ORIG_POST_ONCE

    def test_no_key_configured(self):
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        res = CLIENT._post("/search", {"query": "x"})
        self.assertIn("not set", res.get("error", ""))


class FanoutResearchTest(unittest.TestCase):
    """Deep research must use BOTH keys, on DIFFERENT sources, at the same time."""

    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        KEYS.reset()
        self.scrape_owner = {}     # url -> key that scraped it
        self._orig_post = CLIENT._post
        self._orig_once = CLIENT._post_once
        CLIENT._post = self._fake_post

    def tearDown(self):
        CLIENT._post = self._orig_post
        CLIENT._post_once = self._orig_once
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def _fake_post(self, path, payload, key=None, timeout=None):
        """Route /search to a canned result list and /scrape to a fake page.

        NOTE: this replaces CLIENT._post, so the scrape branch must call the
        low-level _post_once directly - calling _post again would recurse into
        this very fake.
        """
        if path == "/search":
            rows = [{"url": "https://site%02d.example.com/page" % i,
                     "title": "Site %d" % i, "description": "d",
                     "markdown": "m", "metadata": {}} for i in range(1, 9)]
            return {"success": True, "data": {"web": rows}}
        url = payload.get("url")
        self.scrape_owner[url] = key
        return {"success": True, "data": {"markdown": "body of " + url}}

    def test_both_keys_are_used(self):
        res = CLIENT.research("quantum computing", per_key=4)
        self.assertEqual(res["keys_used"], 2)
        self.assertEqual(set(self.scrape_owner.values()), {KEY1, KEY2})

    def test_sources_are_split_disjointly_between_keys(self):
        CLIENT.research("quantum computing", per_key=4)
        by_key = {}
        for url, key in self.scrape_owner.items():
            by_key.setdefault(key, []).append(url)
        # No URL may be scraped by both keys - that would double-burn credits.
        all_urls = [u for urls in by_key.values() for u in urls]
        self.assertEqual(len(all_urls), len(set(all_urls)))
        self.assertEqual(len(by_key[KEY1]), 4)
        self.assertEqual(len(by_key[KEY2]), 4)

    def test_duplicate_hosts_are_never_double_scraped(self):
        def dup_search(path, payload, key=None, timeout=None):
            if path == "/search":
                # Two pages on the SAME host must collapse into one source.
                rows = [{"url": "https://a.example.com/1", "title": "A1", "markdown": "m"},
                        {"url": "https://a.example.com/2", "title": "A2", "markdown": "m"},
                        {"url": "https://b.example.com/1", "title": "B1", "markdown": "m"}]
                return {"success": True, "data": {"web": rows}}
            return self._fake_post(path, payload, key, timeout)
        CLIENT._post = dup_search
        CLIENT.research("topic", per_key=4)
        hosts = set(u.split("/")[2] for u in self.scrape_owner)
        self.assertEqual(hosts, {"a.example.com", "b.example.com"})

    def test_dead_key_does_not_shrink_the_report(self):
        """If key 1 dies mid-fanout, key 2 finishes the job."""
        def kill_key1(path, payload, key=None, timeout=None):
            if path == "/search":
                rows = [{"url": "https://s%02d.example.com/p" % i, "title": "S%d" % i,
                         "markdown": "m", "metadata": {}} for i in range(1, 7)]
                return {"success": True, "data": {"web": rows}}
            if key == KEY1:
                return {"error": "Insufficient credits"}
            url = payload.get("url")
            self.scrape_owner[url] = key
            return {"success": True, "data": {"markdown": "body"}}
        CLIENT._post = kill_key1
        res = CLIENT.research("topic", per_key=3)
        # 6 sources, key 1 dead: key 2 must still carry the whole report and
        # only key 2 may have done the scraping.
        self.assertNotIn("error", res)
        self.assertTrue(len(res.get("sources") or []) >= 3)
        self.assertEqual(set(self.scrape_owner.values()), {KEY2})

    def test_credit_failure_parks_the_key_in_the_real_path(self):
        """The production _post classifies a credit error and parks the key."""
        calls = []

        def failing_once(path, payload, key, timeout):
            calls.append(key)
            if key == KEY1:
                return ({"error": "Insufficient credits"},
                        "Insufficient credits HTTP 402")
            return ({"success": True, "data": {"markdown": "ok"}}, "")

        CLIENT._post_once = failing_once
        try:
            # setUp replaced CLIENT._post, so exercise the real one.
            self._orig_post("/scrape", {"url": "https://x.example.com"}, key=KEY1)
            self.assertEqual(calls, [KEY1])
            self.assertNotIn(KEY1, KEYS.healthy_keys())
        finally:
            CLIENT._post_once = self._orig_once

    def test_research_never_raises_without_keys(self):
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        res = CLIENT.research("topic")
        self.assertIsInstance(res, dict)
        self.assertIn("error", res)


class StatusTest(unittest.TestCase):
    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        KEYS.reset()

    def tearDown(self):
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def test_status_reports_pool_health(self):
        def probe(path, payload, key=None, timeout=None):
            return {"success": True, "data": {"web": [{}]}}
        original = CLIENT._post
        CLIENT._post = probe
        try:
            st = CLIENT.status()
        finally:
            CLIENT._post = original
        self.assertTrue(st["available"])
        self.assertEqual(st["keys_total"], 2)
        self.assertTrue(st["fanout"])
        self.assertEqual(len(st["key_slots"]), 2)
        self.assertNotIn(KEY1, repr(st))  # never expose a raw key to the UI

    def test_status_when_no_key(self):
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        st = CLIENT.status()
        self.assertFalse(st["available"])
        self.assertFalse(st["api_key_set"])


class StatusHonestyTest(unittest.TestCase):
    """status() must say WHY the probe failed, not just that it did.

    Live 2026-10-17: all three configured keys answered HTTP 402 "Insufficient
    credits", status() swallowed the probe error, and JARVIS told the user
    "Firecrawl search abhi available nahi hai, Sir. Pehle setup kijiye." - it
    blamed a missing setup for an exhausted account, so he went hunting for a
    key that was already there.
    """

    def setUp(self):
        self.saved = {v: os.environ.get(v) for v in _ENV_VARS}
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        os.environ["FIRECRAWL_API_KEY"] = KEY1
        os.environ["FIRECRAWL_API_KEY_2"] = KEY2
        KEYS.reset()
        self._orig_post = CLIENT._post

    def tearDown(self):
        CLIENT._post = self._orig_post
        for v, value in self.saved.items():
            if value is None:
                os.environ.pop(v, None)
            else:
                os.environ[v] = value
        KEYS.reset()

    def _probe(self, result=None, exc=None):
        def probe(path, payload, key=None, timeout=None):
            if exc is not None:
                raise exc
            return result
        CLIENT._post = probe

    def test_exhausted_credits_are_named_as_exhausted_credits(self):
        self._probe(result={"error": "Insufficient credits to perform this "
                                   "request. HTTP 402 (all 2 keys unavailable)"})
        st = CLIENT.status()
        self.assertFalse(st["available"])
        self.assertTrue(st["api_key_set"], "keys ARE configured; say so")
        self.assertTrue(st["out_of_credits"], st)
        self.assertIn("credit", str(st["probe_error"]).lower())
        self.assertNotIn(KEY1, repr(st))

    def test_transient_failure_is_not_blamed_on_credits(self):
        self._probe(result={"error": "upstream HTTP 503"})
        st = CLIENT.status()
        self.assertFalse(st["available"])
        self.assertFalse(st["out_of_credits"])
        self.assertIn("503", str(st["probe_error"]))

    def test_empty_probe_response_is_still_diagnosable(self):
        self._probe(result={"success": True, "data": []})
        st = CLIENT.status()
        self.assertFalse(st["available"])
        self.assertTrue(str(st["probe_error"]).strip(), st)

    def test_probe_exception_is_reported_not_swallowed(self):
        self._probe(exc=RuntimeError("socket died"))
        st = CLIENT.status()
        self.assertFalse(st["available"])
        self.assertIn("socket died", str(st["probe_error"]))

    def test_no_key_is_reported_as_not_configured(self):
        for v in _ENV_VARS:
            os.environ.pop(v, None)
        KEYS.reset()
        st = CLIENT.status()
        self.assertFalse(st["api_key_set"])
        self.assertFalse(st["out_of_credits"])


if __name__ == "__main__":
    unittest.main()