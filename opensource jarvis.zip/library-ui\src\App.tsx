import React, { useState, useEffect, useRef } from 'react';
import {
  Home,
  BookOpen,
  Search,
  FileText,
  Folder,
  Settings,
  ArrowRight,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  ChevronDown,
  Info,
  User,
  Tag,
  Download,
  Check,
  X,
  Send,
  Sparkles,
  Headphones,
  Pencil,
  Plus,
  Globe,
  StickyNote,
  FolderOpen,
} from 'lucide-react';
import {
  MaterialItem,
  SourceType,
  SkillCategory,
  SoftSubcategory,
  HardSubcategory,
  NavSection,
  WorkspaceMode,
  ChatMessage,
  NoteItem,
  CollectionItem,
  SOFT_SUBCATEGORIES,
  HARD_SUBCATEGORIES,
  JARVIS_QUOTES,
} from './data/archiveData';
import {
  JarvisTargetIcon,
  JarvisRobotAvatar,
  CpuSparkline,
  GpuSparkline,
} from './components/HudIcons';
import { AtriumBackdropCanvas } from './components/AtriumBackdropCanvas';
import { askDesk, loadChapter, loadShelf, speakDesk } from './utils/jarvisDesk';
import { shelfMaterials, unavailableNote } from './utils/shelfMaterials';
import { ShelfBookRack } from './components/ShelfBookRack';
import { AddMaterialModal } from './components/AddMaterialModal';
import { SecondaryNavDrawer } from './components/SecondaryNavDrawer';
import { ExportZipModal } from './components/ExportZipModal';
import {
  brainAudio,
  BRAIN_SOUND_PRESETS,
  BrainSoundPreset,
} from './utils/soundEngine';
import { downloadCompleteProjectZip } from './utils/exportProjectZip';

export default function App() {
  // Navigation & Workspace states — Starts with 100% Empty Shelves!
  const [activeNav, setActiveNav] = useState<NavSection>('Home');
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceMode>('EXPLORE');
  const [isOnline, setIsOnline] = useState<boolean>(false);
  const [systemStateText, setSystemStateText] = useState<string>('Idle  ·  Ready');
  const [cleanBackdrop, setCleanBackdrop] = useState<boolean>(true);

  // Brain Relaxation & Active Study Audio state
  const [isBrainSoundActive, setIsBrainSoundActive] = useState<boolean>(false);
  const [brainPreset, setBrainPreset] = useState<BrainSoundPreset>('alpha-flow');
  const [brainVolume, setBrainVolume] = useState<number>(0.5);
  const [showBrainAudioMenu, setShowBrainAudioMenu] = useState<boolean>(false);

  // Telemetry & Clock
  const [cpuLoad, setCpuLoad] = useState<number>(12);
  const [gpuLoad, setGpuLoad] = useState<number>(28);
  const [useLiveClock, setUseLiveClock] = useState<boolean>(true);  // JARVIS never shows a frozen date
  const [clockTime, setClockTime] = useState<string>('16:42');
  const [clockDate, setClockDate] = useState<string>('Oct 19, 2026');

  // Both Shelves Start 100% EMPTY (Matches Empty Reference Image 1:1!)
  // As soon as user uploads a PDF or material, it renders in 3D physical form on the golden shelf ledge!
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [softFilter, setSoftFilter] = useState<SoftSubcategory | null>(null);
  const [hardFilter, setHardFilter] = useState<HardSubcategory | null>(null);
  const [selectedSource, setSelectedSource] = useState<MaterialItem | null>(null);
  const [hoveredSourceId, setHoveredSourceId] = useState<string | null>(null);
  const [activeBeamPulse, setActiveBeamPulse] = useState<boolean>(false);
  const [isEditingInspectorTitle, setIsEditingInspectorTitle] = useState<boolean>(false);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [addModalCategory, setAddModalCategory] = useState<SkillCategory>('soft');
  const [addModalType, setAddModalType] = useState<SourceType>('PDF');
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);
  const [showSidebarZipBtn, setShowSidebarZipBtn] = useState<boolean>(true);

  // Quote & Avatar state
  const [quoteIndex, setQuoteIndex] = useState<number>(0);

  // Right Panel ("ASK THE SOURCE") states
  const [mediaTab, setMediaTab] = useState<'TEXT' | 'AUDIO'>('TEXT');
  const [selectedSourceOnly, setSelectedSourceOnly] = useState<boolean>(true);
  const [includeLinkedSources, setIncludeLinkedSources] = useState<boolean>(false);
  const [showLinkedTooltip, setShowLinkedTooltip] = useState<boolean>(false);

  // Audio / Read Aloud TTS state
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [audioProgress, setAudioProgress] = useState<number>(0);
  const [audioDurationSec, setAudioDurationSec] = useState<number>(0);
  const [audioCurrentSec, setAudioCurrentSec] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [selectedVoiceLabel, setSelectedVoiceLabel] = useState<string>('AI Voice (Male)');
  const [showVoiceMenu, setShowVoiceMenu] = useState<boolean>(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState<boolean>(false);

  // Q&A Chat & Voice Input — Starts empty
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [questionInput, setQuestionInput] = useState<string>('');
  const [isListeningMic, setIsListeningMic] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Notes & Collections
    // Notes and collections start empty. The zip shipped invented sample notes and
  // collections that looked like his own writing; nothing here may be seeded.
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [collections] = useState<CollectionItem[]>([]);

  const speedOptions = [0.75, 1.0, 1.25, 1.5, 2.0];
  const voiceOptions = [
    'AI Voice (Male)',
    'AI Voice (Female)',
    'JARVIS Tactical (UK)',
    'Archive Narrator',
  ];

  // Clock updater
  useEffect(() => {
    if (!useLiveClock) {
      setClockTime('16:42');
      setClockDate('Oct 19, 2026');
      return;
    }
    const updateClock = () => {
      const now = new Date();
      setClockTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
      setClockDate(
        now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      );
    };
    updateClock();
    const timer = setInterval(updateClock, 10000);
    return () => clearInterval(timer);
  }, [useLiveClock]);

  // Subtle CPU/GPU telemetry fluctuation when active
  useEffect(() => {
    if (!isOnline && !isPlayingAudio && !isBrainSoundActive) {
      setCpuLoad(12);
      setGpuLoad(28);
      return;
    }
    const interval = setInterval(() => {
      setCpuLoad(Math.floor(11 + Math.random() * 6));
      setGpuLoad(Math.floor(26 + Math.random() * 8));
    }, 2600);
    return () => clearInterval(interval);
  }, [isOnline, isPlayingAudio, isBrainSoundActive]);

  useEffect(() => {
    return () => {
      brainAudio.stopStudySound();
    };
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleToggleBrainSound = (presetOverride?: BrainSoundPreset) => {
    const targetPreset = presetOverride || brainPreset;
    if (presetOverride) {
      setBrainPreset(presetOverride);
      brainAudio.startStudySound(presetOverride, brainVolume);
      setIsBrainSoundActive(true);
      setSystemStateText('Study Audio  ·  Active');
      return;
    }

    if (isBrainSoundActive) {
      brainAudio.stopStudySound();
      setIsBrainSoundActive(false);
      setSystemStateText(selectedSource ? `Active  ·  ${selectedSource.type}` : 'Idle  ·  Ready');
    } else {
      brainAudio.startStudySound(targetPreset, brainVolume);
      setIsBrainSoundActive(true);
      setSystemStateText('Study Audio  ·  Active');
    }
  };

  // Audio playback progress timer
  useEffect(() => {
    if (!isPlayingAudio) return;
    const totalSec = audioDurationSec > 0 ? audioDurationSec : 45;
    if (audioDurationSec === 0) setAudioDurationSec(45);

    const interval = setInterval(() => {
      setAudioCurrentSec((prev) => {
        const next = prev + 1 * playbackSpeed;
        if (next >= totalSec) {
          setIsPlayingAudio(false);
          setSystemStateText(selectedSource ? `Active  ·  ${selectedSource.type}` : 'Idle  ·  Ready');
          setAudioProgress(100);
          return totalSec;
        }
        setAudioProgress(Math.min(100, (next / totalSec) * 100));
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlayingAudio, audioDurationSec, playbackSpeed, selectedSource]);

  // ── The real desk: shelf, chapter text, Radox answers, edge-tts voice ──────
  // The zip shipped hardcoded sample books, a canned "key insights" answer and
  // the browser's own speech engine. All three are gone: every volume, every
  // paragraph, every answer and every sound now comes off the disk or out of the
  // core, and when the core cannot answer it says so instead of reciting a sample.
  const deskAudioRef = useRef<HTMLAudioElement | null>(null);
  const deskUrlRef = useRef<string | null>(null);
  const [deskNote, setDeskNote] = useState('');

  const applyChapter = (id: string, paras: string[], label: string) => {
    setMaterials((prev) => prev.map((m) => (m.id === id ? { ...m, paragraphs: paras } : m)));
    setSelectedSource((prev) =>
      prev && prev.id === id ? { ...prev, paragraphs: paras, subtitle: label } : prev
    );
  };

  const openChapter = async (item: MaterialItem) => {
    if (!item.slug) return;
    if (item.readable === false) {
      // Nothing to fetch: the licence keeps their text out of this library.
      setDeskNote(`LINK ONLY - ${item.license || 'no licence stated'}: ${item.summary}`);
      setSystemStateText('Link card  ·  no text stored');
      return;
    }
    const n = item.chapterN || 1;
    setSystemStateText(`Opening  ·  chapter ${n}`);
    try {
      const got = await loadChapter(item.slug, n);
      const paras = got.text
        .split(/\n\s*\n/)
        .map((p) => p.replace(/\s+/g, ' ').trim())
        .filter((p) => p.length > 40)
        .slice(0, 40);
      applyChapter(item.id, paras, `${got.chapter_title || `Chapter ${n}`}  ·  ${got.chars} chars`);
      setSystemStateText(paras.length ? `Active  ·  ${item.type}` : 'Active  ·  no paragraphs');
    } catch (err) {
      setDeskNote(`Chapter could not be opened: ${(err as Error).message}`);
      setSystemStateText('Shelf  ·  read failed');
    }
  };

  // One probe, three callers (boot, the telemetry pill, the drawer). It reports
  // what the core really answered, so nothing on this desk can claim "online"
  // without the shelf proving it.
  const probeCore = () => {
    setSystemStateText('Probing  ·  Core');
    return loadShelf()
      .then((shelf) => {
        const items = shelfMaterials(shelf);
        setMaterials(items);
        setIsOnline(items.length > 0);
        setDeskNote(unavailableNote(shelf));
        // Something must be on the reader when the shelf loads, or the inspector
        // comes back as "NO MATERIAL SELECTED".
        setSelectedSource((prev) => prev || items[0] || null);
        setSystemStateText(items.length ? `Online  ·  ${items.length} volumes` : 'Online  ·  empty shelf');
        return items;
      })
      .catch((err) => {
        setIsOnline(false);
        setDeskNote(`Core not answering: ${(err as Error).message}`);
        setSystemStateText('Offline  ·  core');
        return [];
      });
  };

  useEffect(() => {
    let cancelled = false;
    probeCore().then((items) => {
      if (cancelled) return;
      if (items[0]) void openChapter(items[0]);
    });
    return () => {
      cancelled = true;
      if (deskUrlRef.current) URL.revokeObjectURL(deskUrlRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const deskLanguage = (): string => {
    const l = String(questionInput || '').toLowerCase();
    if (/[\u0900-\u097F]/.test(l) || /\b(main|kya|kaise|hai|nahi|batao)\b/.test(l)) return 'hinglish';
    if (/[\u3040-\u30FF]/.test(l)) return 'ja';
    return 'en';
  };

  const formatTime = (sec: number) => {
    const s = Math.max(0, Math.floor(sec));
    const mins = Math.floor(s / 60);
    const rem = s % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  // Read Aloud - edge-tts through the core. The browser's speechSynthesis is not
  // used: it depends on a voice pack that may not exist on this laptop, and the
  // owner asked for the assistant's own voice here.
  const triggerReadAloud = async (customText?: string) => {
    const textToRead =
      customText ||
      (messages.length > 0
        ? `${messages[messages.length - 1].text} ${
            messages[messages.length - 1].numberedPoints
              ?.map((p, i) => `${i + 1}. ${p.title}: ${p.detail}`)
              .join(' ') || ''
          }`
        : selectedSource && selectedSource.paragraphs.length
        ? `${selectedSource.title}. ${selectedSource.paragraphs.slice(0, 6).join(' ')}`
        : 'No chapter is open yet, Sir. Choose a volume from the shelf first.');

    if (isPlayingAudio && !customText) {
      deskAudioRef.current?.pause();
      setIsPlayingAudio(false);
      setSystemStateText(selectedSource ? `Active  ·  ${selectedSource.type}` : 'Idle  ·  Ready');
      return;
    }

    if (!customText && selectedSource && selectedSource.readable === false) {
      setDeskNote(`Nothing to read aloud - ${selectedSource.license || 'no licence'} source, link only.`);
      setSystemStateText('Voice  ·  link only');
      return;
    }

    setSystemStateText('Synthesizing  ·  edge-tts');
    try {
      const url = await speakDesk(textToRead, deskLanguage());
      if (deskUrlRef.current && deskUrlRef.current !== url) URL.revokeObjectURL(deskUrlRef.current);
      deskUrlRef.current = url;
      const el = deskAudioRef.current ?? new Audio();
      deskAudioRef.current = el;
      el.src = url;
      el.playbackRate = playbackSpeed;
      el.onloadedmetadata = () => {
        const secs = Math.max(5, Math.round(el.duration || 0));
        setAudioDurationSec(secs);
        setAudioCurrentSec(0);
        setAudioProgress(0);
      };
      el.onended = () => {
        setIsPlayingAudio(false);
        setAudioProgress(100);
        setSystemStateText(selectedSource ? `Active  ·  ${selectedSource.type}` : 'Idle  ·  Ready');
      };
      el.onerror = () => {
        setIsPlayingAudio(false);
        setSystemStateText('Voice  ·  edge-tts failed');
      };
      await el.play();
      setIsPlayingAudio(true);
      setSystemStateText('Reading  ·  edge-tts');
    } catch (err) {
      setIsPlayingAudio(false);
      setDeskNote(`Voice failed: ${(err as Error).message}`);
      setSystemStateText('Voice  ·  edge-tts offline');
    }
  };

  const pulseCenterBeam = () => {
    setActiveBeamPulse(true);
    setTimeout(() => setActiveBeamPulse(false), 1800);
  };

  const handleSelectSource = (item: MaterialItem) => {
    brainAudio.playUiChime('select');
    setSelectedSource(item);
    setIsEditingInspectorTitle(false);
    setAudioDurationSec(180);
    setAudioCurrentSec(0);
    setAudioProgress(0);
    setSystemStateText(`Active  ·  ${item.type}`);
    pulseCenterBeam();
    // The chapter body is read from disk on demand - a volume with no open
    // chapter shows nothing rather than the sample prose the zip carried.
    if (item.slug && (!item.paragraphs || item.paragraphs.length === 0)) void openChapter(item);
  };

  const handleAddMaterial = (item: MaterialItem, selectImmediately = true) => {
    brainAudio.playUiChime('add');
    setMaterials((prev) => {
      const exists = prev.some((p) => p.id === item.id);
      return exists ? prev : [...prev, item];
    });
    if (selectImmediately) {
      handleSelectSource(item);
    } else {
      pulseCenterBeam();
    }
  };

  const handleRenameMaterial = (id: string, newTitle: string) => {
    setMaterials((prev) =>
      prev.map((m) => (m.id === id ? { ...m, title: newTitle } : m))
    );
    setSelectedSource((prev) =>
      prev && prev.id === id ? { ...prev, title: newTitle } : prev
    );
  };

  const handleRemoveMaterial = (id: string) => {
    setMaterials((prev) => prev.filter((m) => m.id !== id));
    if (selectedSource?.id === id) {
      setSelectedSource(null);
      setMessages([]);
      setSystemStateText('Idle  ·  Ready');
    }
  };

  const handleLoadAllPresets = () => {
    // Renamed in the UI to "reload the shelf": there is no sample pack to load.
    brainAudio.playUiChime('add');
    loadShelf()
      .then((shelf) => {
        const items = shelfMaterials(shelf);
        setMaterials(items);
        setDeskNote(unavailableNote(shelf));
        if (items[0]) handleSelectSource(items[0]);
      })
      .catch((err) => setDeskNote(`Shelf unavailable: ${(err as Error).message}`));
  };

  const handleResetEmptyShelves = () => {
    deskAudioRef.current?.pause();
    setMaterials([]);
    setSelectedSource(null);
    setMessages([]);
    setSoftFilter(null);
    setHardFilter(null);
    setIsPlayingAudio(false);
    setAudioProgress(0);
    setAudioCurrentSec(0);
    setAudioDurationSec(0);
    setSystemStateText('Idle  ·  Ready');
  };

  const handleOpenAddModal = (cat: SkillCategory = 'soft', type: SourceType = 'PDF') => {
    setAddModalCategory(cat);
    setAddModalType(type);
    setIsAddModalOpen(true);
  };

  const handleAskQuestion = async (overrideQuestion?: string) => {
    const qText = (overrideQuestion ?? questionInput).trim();
    if (!qText) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text: qText,
      timestamp: clockTime,
    };
    const pendingId = `msg-${Date.now() + 1}`;
    const activeSrc = selectedSource && selectedSource.slug
      ? selectedSource
      : materials.find((m) => m.slug) || null;

    setMessages((prev) => [...prev, userMsg]);
    setQuestionInput('');

    if (!activeSrc || !activeSrc.slug) {
      setMessages((prev) => [
        ...prev,
        {
          id: pendingId,
          role: 'jarvis',
          text: 'Koi volume khula nahi hai, Sir. Shelf se ek chuno - jawab usi chapter se aayega, yaad se nahi.',
          timestamp: clockTime,
        },
      ]);
      return;
    }

    if (activeSrc.readable === false) {
      setMessages((prev) => [
        ...prev,
        {
          id: pendingId,
          role: 'jarvis',
          text: `Ye source shelf par sirf LINK hai, Sir - ${activeSrc.license || 'licence nahi batai gayi'}${activeSrc.url ? ` (${activeSrc.url})` : ''}. Unki licence hamen unka text store karne nahi deti, isliye main uske baare mein kuch quote nahi kar sakta. Jo volumes store hain, un par main padh kar jawab deta hoon.`,
          timestamp: clockTime,
          citation: 'link only',
        },
      ]);
      setSystemStateText('Refused  ·  link only');
      return;
    }

    setMessages((prev) => [
      ...prev,
      { id: pendingId, role: 'jarvis', text: 'Reading the chapter…', timestamp: clockTime },
    ]);
    setSystemStateText('Reading  ·  Radox');
    try {
      const ans = await askDesk(activeSrc.slug, activeSrc.chapterN || 1, qText);
      const answerText = ans.ok && ans.answer
        ? ans.answer
        : `(not answered) ${ans.reason || ans.error || 'the prose pool gave nothing back'}`;
      setMessages((prev) =>
        prev.map((m) =>
          m.id === pendingId
            ? {
                ...m,
                text: answerText,
                sourceTitle: activeSrc.title,
                citation: ans.ok
                  ? `${activeSrc.title}  ·  ch ${ans.chapter?.n || 1}  ·  ${ans.engine || 'Radox'}`
                    + `${ans.context ? `  ·  ${ans.context}` : ''}`
                  : `${ans.error || 'unavailable'}`,
              }
            : m
        )
      );
      setSystemStateText(ans.ok ? `Answered  ·  ${ans.engine || 'Radox'}` : 'Ask  ·  pool failed');
      if (!ans.ok) setDeskNote(`Ask failed: ${ans.reason || ans.error || 'unknown'}`);
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === pendingId
            ? { ...m, text: `(ask failed) ${(err as Error).message}`, citation: 'core' }
            : m
        )
      );
      setSystemStateText('Ask  ·  core offline');
    }
    pulseCenterBeam();
  };

  // Microphone Voice Recognition
  const handleToggleMic = () => {
    if (isListeningMic) {
      setIsListeningMic(false);
      setSystemStateText(selectedSource ? `Active  ·  ${selectedSource.type}` : 'Idle  ·  Ready');
      return;
    }

    const SpeechRecognition =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;

    setIsListeningMic(true);
    setSystemStateText('Listening  ·  Voice');

    if (SpeechRecognition) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const recognition = new (SpeechRecognition as any)();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        recognition.onresult = (event: any) => {
          const transcript = event.results?.[0]?.[0]?.transcript;
          if (transcript) {
            setQuestionInput(transcript);
            handleAskQuestion(transcript);
          }
          setIsListeningMic(false);
        };
        recognition.onerror = () => {
          setIsListeningMic(false);
          setSystemStateText('Idle  ·  Ready');
        };
        recognition.onend = () => {
          setIsListeningMic(false);
        };
        recognition.start();
        return;
      } catch {
        // Fallback below
      }
    }

    setTimeout(() => {
      const sampleCommand = selectedSource
        ? `What are the key takeaways from ${selectedSource.title}?`
        : 'What are the key techniques for building confidence in public speaking?';
      setQuestionInput(sampleCommand);
      setIsListeningMic(false);
      handleAskQuestion(sampleCommand);
    }, 1400);
  };

  const softMaterials = materials.filter(
    (m) => m.category === 'soft' && (!softFilter || m.subcategory === softFilter)
  );
  const hardMaterials = materials.filter(
    (m) => m.category === 'hard' && (!hardFilter || m.subcategory === hardFilter)
  );

  const navItems: { id: NavSection; label: string; icon: React.ReactNode }[] = [
    { id: 'Home', label: 'Home', icon: <Home className="w-4 h-4" /> },
    { id: 'Library', label: 'Library', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'Search', label: 'Search', icon: <Search className="w-4 h-4" /> },
    { id: 'Notes', label: 'Notes', icon: <FileText className="w-4 h-4" /> },
    { id: 'Collections', label: 'Collections', icon: <Folder className="w-4 h-4" /> },
    { id: 'Settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  const sourceDockTypes: SourceType[] = ['PDF', 'Book', 'Web', 'Notes', 'Course'];

  return (
    <div className="h-full w-full flex flex-col bg-[#040a12] text-slate-100 overflow-hidden select-none">
      {/* =====================================================================
          TOP HEADER BAR (Zero Overlap across all Laptop / Desktop Viewports)
      ====================================================================== */}
      <header className="h-[50px] shrink-0 px-3 lg:px-4 flex items-center justify-between gap-2 border-b border-cyan-500/20 bg-[#050d18] z-30">
        {/* Left Zone */}
        <div className="flex items-center gap-2 lg:gap-3 min-w-0 overflow-hidden">
          <button
            onClick={() => {
              setActiveNav('Home');
              pulseCenterBeam();
            }}
            className="flex items-center gap-2 group cursor-pointer focus:outline-none shrink-0"
          >
            <JarvisTargetIcon className="w-6 h-6 lg:w-7 lg:h-7 transition-transform duration-300 group-hover:scale-105" />
            <span className="font-display text-[19px] lg:text-[21px] font-bold tracking-[0.18em] text-cyan-300 group-hover:text-cyan-200 transition-colors">
              JARVIS
            </span>
          </button>

          <button
            onClick={() => setActiveNav(activeNav === 'Library' ? 'Home' : 'Library')}
            className="hidden sm:flex items-center gap-1.5 pl-1 text-[10px] lg:text-[11px] font-medium tracking-[0.22em] text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <span>RESEARCH ARCHIVE</span>
            <ArrowRight className="w-3.5 h-3.5 text-cyan-400/80" />
          </button>

          <div className="h-4 w-[1px] bg-slate-700/80 mx-1 hidden sm:block shrink-0" />

          {/* Core reachability pill. It used to be a button that flipped its own
              label and did nothing else - a lie on the telemetry bar. Now it
              reports whether /library/shelf answered, and clicking it re-probes. */}
          <button
            onClick={() => { void probeCore(); pulseCenterBeam(); }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] lg:text-[11px] font-semibold tracking-wider transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              isOnline
                ? 'border-emerald-400/60 bg-emerald-500/15 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                : 'border-cyan-500/35 bg-[#07192e] text-cyan-200 hover:border-cyan-400/70'
            }`}
            title="Re-check whether the JARVIS core answers"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]' : 'bg-cyan-400'
              }`}
            />
            <span>{isOnline ? 'ONLINE' : 'OFFLINE'}</span>
          </button>

          {/* State Indicator — Truncates gracefully so it never overlaps CPU/GPU */}
          <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-400 pl-1 min-w-0 overflow-hidden">
            <span className="shrink-0">State:</span>
            <span className="text-slate-200 font-medium truncate max-w-[140px] xl:max-w-[220px]">
              {systemStateText}
            </span>
          </div>
        </div>

        {/* Right Zone: CPU, GPU, Clock/Date, Study Sound Icon, ZIP Export & Settings Gear */}
        <div className="flex items-center gap-2.5 lg:gap-3.5 shrink-0">
          {/* CPU Telemetry */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs font-mono-tabular">
            <span className="text-slate-400">CPU</span>
            <span className="text-slate-200 font-semibold">{cpuLoad}%</span>
            <CpuSparkline />
          </div>

          <div className="h-4 w-[1px] bg-slate-700/80 hidden lg:block" />

          {/* GPU Telemetry */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs font-mono-tabular">
            <span className="text-slate-400">GPU</span>
            <span className="text-slate-200 font-semibold">{gpuLoad}%</span>
            <GpuSparkline />
          </div>

          <div className="h-4 w-[1px] bg-slate-700/80 hidden sm:block" />

          {/* Clock & Date */}
          <button
            onClick={() => setUseLiveClock(!useLiveClock)}
            className="text-left font-mono-tabular leading-tight cursor-pointer hover:opacity-80 transition-opacity"
            title="Click to toggle Screenshot Time vs Live System Clock"
          >
            <div className="text-xs font-semibold text-slate-100">{clockTime}</div>
            <div className="text-[10px] text-slate-300">{clockDate}</div>
          </button>

          {/* Discreet Brain Relaxation & Study Audio Icon + Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowBrainAudioMenu(!showBrainAudioMenu)}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isBrainSoundActive
                  ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(34,211,238,0.35)]'
                  : 'text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10'
              }`}
              title="Brain Relaxation & Active Study Audio (Alpha / Gamma / 432Hz)"
            >
              <Headphones className="w-4 h-4" />
            </button>

            {showBrainAudioMenu && (
              <div className="absolute right-0 mt-2 w-72 rounded-2xl border border-cyan-400/60 bg-[#061427]/98 backdrop-blur-xl shadow-[0_0_40px_rgba(6,182,212,0.35)] p-3.5 space-y-2.5 z-50">
                <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2">
                  <span className="text-xs font-bold text-cyan-200 flex items-center gap-1.5">
                    <Headphones className="w-3.5 h-3.5" />
                    Brain Study & Relax Audio
                  </span>
                  <button
                    onClick={() => setShowBrainAudioMenu(false)}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-1.5">
                  {BRAIN_SOUND_PRESETS.map((p) => {
                    const active = brainPreset === p.id && isBrainSoundActive;
                    return (
                      <button
                        key={p.id}
                        onClick={() => handleToggleBrainSound(p.id)}
                        className={`w-full text-left p-2 rounded-xl border transition-all cursor-pointer ${
                          active
                            ? 'border-cyan-300 bg-cyan-500/20 text-white'
                            : 'border-cyan-500/20 bg-[#081b33]/70 text-slate-300 hover:border-cyan-400/50'
                        }`}
                      >
                        <div className="text-[11px] font-semibold text-white">{p.name}</div>
                        <div className="text-[10px] text-slate-400">{p.subtitle}</div>
                      </button>
                    );
                  })}
                </div>

                <div className="pt-1 flex items-center gap-2.5">
                  <button
                    onClick={() => handleToggleBrainSound()}
                    className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 cursor-pointer"
                  >
                    {isBrainSoundActive ? (
                      <Volume2 className="w-3.5 h-3.5" />
                    ) : (
                      <VolumeX className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <input
                    type="range"
                    min={0.05}
                    max={1}
                    step={0.05}
                    value={brainVolume}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      setBrainVolume(v);
                      brainAudio.setVolume(v);
                    }}
                    className="flex-1 accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Settings Gear */}
          <button
            onClick={() => setActiveNav(activeNav === 'Settings' ? 'Home' : 'Settings')}
            className="p-1.5 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors cursor-pointer"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* =====================================================================
          MAIN 3-COLUMN WORKSPACE
      ====================================================================== */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* -------------------------------------------------------------------
            1. LEFT NAVIGATION SIDEBAR
        -------------------------------------------------------------------- */}
        <aside className="w-[136px] lg:w-[144px] shrink-0 flex flex-col justify-between p-2.5 border-r border-cyan-500/20 bg-[#050d19] z-20">
          <nav className="space-y-1.5 pt-1">
            {navItems.map((item) => {
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNav(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/25 to-cyan-600/10 border border-cyan-400/60 text-white shadow-[0_0_15px_rgba(34,211,238,0.2)]'
                      : 'text-slate-300 hover:text-white hover:bg-cyan-500/10 border border-transparent'
                  }`}
                >
                  <span className={isActive ? 'text-cyan-300' : 'text-slate-400'}>{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* 1-Click Direct Full Codebase .ZIP Download (Zero Page Error, Dismissible) */}
            {showSidebarZipBtn && (
              <div className="pt-2">
                <div className="relative rounded-xl border border-cyan-400/55 bg-gradient-to-r from-cyan-500/20 to-blue-600/15 p-2 shadow-[0_0_16px_rgba(34,211,238,0.22)]">
                  <button
                    onClick={() => setShowSidebarZipBtn(false)}
                    className="absolute top-1 right-1 text-slate-400 hover:text-white p-0.5 cursor-pointer"
                    title="Hide button"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                  <button
                    disabled={isDownloadingZip}
                    onClick={async () => {
                      setIsDownloadingZip(true);
                      try {
                        await downloadCompleteProjectZip();
                      } finally {
                        setIsDownloadingZip(false);
                      }
                    }}
                    className="w-full flex flex-col items-center justify-center gap-1 py-1 text-center cursor-pointer group"
                    title="Download the Skill Library (.zip)"
                  >
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-200 group-hover:text-white">
                      <Download className="w-3.5 h-3.5 text-cyan-300 animate-bounce" />
                      <span>{isDownloadingZip ? 'Packaging...' : '1-Click .ZIP'}</span>
                    </div>
                    <span className="text-[9px] text-slate-300 leading-tight">
                      Books + chapters + licence
                    </span>
                  </button>
                </div>
              </div>
            )}
          </nav>

          {/* Bottom JARVIS Avatar & Quote Card */}
          <div
            onClick={() => {
              const nextIdx = (quoteIndex + 1) % JARVIS_QUOTES.length;
              setQuoteIndex(nextIdx);
              triggerReadAloud(JARVIS_QUOTES[nextIdx].replace(/"/g, ''));
            }}
            className="p-3 rounded-2xl border border-cyan-500/25 bg-[#061222]/90 flex flex-col items-center text-center gap-2 cursor-pointer hover:border-cyan-400/60 transition-all group"
            title="Click to hear JARVIS speak and cycle quotes"
          >
            <JarvisRobotAvatar
              className="w-12 h-12 group-hover:scale-105 transition-transform"
              speaking={isPlayingAudio}
            />
            <div className="font-display text-sm font-bold tracking-[0.2em] text-cyan-300">
              JARVIS
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {JARVIS_QUOTES[quoteIndex]}
            </p>
          </div>
        </aside>

        {/* -------------------------------------------------------------------
            2. CENTER 3D FUTURISTIC RESEARCH ARCHIVE ATRIUM
               - Starts 100% Empty matching the Empty Shelf Reference Image!
               - As soon as user uploads a PDF or material, AtriumBackdropCanvas
                 cleanly removes "No materials yet" and renders the uploaded PDF
                 in photorealistic 3D physical form with companion book spines
                 and its name written on the side of the 3D cover!
        -------------------------------------------------------------------- */}
        <main className="relative flex-1 min-w-0 h-full overflow-hidden bg-[#040b14]">
          <AtriumBackdropCanvas
            activeBeamPulse={activeBeamPulse}
            softMaterials={softMaterials}
            hardMaterials={hardMaterials}
            selectedSourceId={selectedSource?.id}
            hoveredSourceId={hoveredSourceId}
          />

          {/* Secondary Navigation Drawer Overlay */}
          <SecondaryNavDrawer
            activeNav={activeNav}
            onCloseToHome={() => setActiveNav('Home')}
            materials={materials}
            selectedSource={selectedSource}
            onSelectSource={handleSelectSource}
            onRemoveMaterial={handleRemoveMaterial}
            onOpenAddModal={(cat) => handleOpenAddModal(cat || 'soft', 'PDF')}
            onLoadAllPresets={handleLoadAllPresets}
            onResetEmptyShelves={handleResetEmptyShelves}
            notes={notes}
            onAddNote={(n) => setNotes((prev) => [n, ...prev])}
            onDeleteNote={(id) => setNotes((prev) => prev.filter((n) => n.id !== id))}
            collections={collections}
            onLoadCollection={(col) => {
              // A collection names ids from the shelf; if those volumes are not on
              // disk the collection must not silently load sample cards.
              const items = materials.filter((m) => col.materialIds.includes(m.id));
              if (items.length) {
                setMaterials(items);
                handleSelectSource(items[0]);
              } else {
                setDeskNote(`"${col.name}" lists ${col.materialIds.length} ids that are not on this shelf.`);
              }
            }}
            isOnline={isOnline}
            onToggleOnline={() => { void probeCore(); }}
            cleanBackdrop={cleanBackdrop}
            onToggleCleanBackdrop={() => setCleanBackdrop(!cleanBackdrop)}
            onOpenExportModal={() => setIsExportModalOpen(true)}
            onSpeakText={(txt) => triggerReadAloud(txt)}
          />

          {/* 1. UPPER-LEFT "SOFT SKILLS" INTERACTIVE HOTSPOT OVERLAY */}
          <div className="absolute left-[1.7%] top-[2.9%] w-[36.1%] h-[17.7%] z-10 flex flex-col justify-between p-2">
            <button
              onClick={() => {
                setSoftFilter(null);
                handleOpenAddModal('soft', 'PDF');
              }}
              className="w-full h-[58%] rounded-xl hover:bg-cyan-400/5 transition-colors cursor-pointer focus:outline-none"
              title="Soft Skills — Click to upload or add Soft Skills material"
            />
            <div className="h-[42%] grid grid-cols-4 gap-1 items-center px-6">
              {SOFT_SUBCATEGORIES.map((sub) => {
                const active = softFilter === sub;
                return (
                  <button
                    key={sub}
                    onClick={() => {
                      setSoftFilter(active ? null : sub);
                      setSystemStateText(active ? 'Idle  ·  Ready' : `Filter  ·  ${sub}`);
                    }}
                    className={`h-full rounded-md transition-all cursor-pointer ${
                      active
                        ? 'border-b-2 border-cyan-300 bg-cyan-400/15 shadow-[0_0_12px_rgba(34,211,238,0.35)]'
                        : 'hover:bg-cyan-400/10'
                    }`}
                    title={`Filter Soft Skills by ${sub}`}
                  />
                );
              })}
            </div>
          </div>

          {/* 2. UPPER-RIGHT "HARD SKILLS" INTERACTIVE HOTSPOT OVERLAY */}
          <div className="absolute right-[1.4%] top-[2.9%] w-[33.7%] h-[17.7%] z-10 flex flex-col justify-between p-2">
            <button
              onClick={() => {
                setHardFilter(null);
                handleOpenAddModal('hard', 'PDF');
              }}
              className="w-full h-[58%] rounded-xl hover:bg-cyan-400/5 transition-colors cursor-pointer focus:outline-none"
              title="Hard Skills — Click to upload or add Hard Skills material"
            />
            <div className="h-[42%] grid grid-cols-5 gap-1 items-center px-4">
              {HARD_SUBCATEGORIES.map((sub) => {
                const active = hardFilter === sub;
                return (
                  <button
                    key={sub}
                    onClick={() => {
                      setHardFilter(active ? null : sub);
                      setSystemStateText(active ? 'Idle  ·  Ready' : `Filter  ·  ${sub}`);
                    }}
                    className={`h-full rounded-md transition-all cursor-pointer ${
                      active
                        ? 'border-b-2 border-cyan-300 bg-cyan-400/15 shadow-[0_0_12px_rgba(34,211,238,0.35)]'
                        : 'hover:bg-cyan-400/10'
                    }`}
                    title={`Filter Hard Skills by ${sub}`}
                  />
                );
              })}
            </div>
          </div>

          {/* 3. LEFT SHELF (Soft Skills):
              - Empty by default: Real 3D-perspective interactive glass bay with real "+ Add Material" button
              - Populated: Recessed 3D physical books standing inside the shelf compartment */}
          {softMaterials.length === 0 ? (
            <div className="absolute left-[4.2%] top-[23.8%] w-[31.2%] h-[19.8%] z-10 shelf-bay-left rounded-xl border border-cyan-400/20 bg-gradient-to-b from-[#071526]/75 via-[#061220]/65 to-[#050e1a]/80 backdrop-blur-[2px] flex flex-col items-center justify-center gap-1.5 p-2 shadow-[inset_0_0_24px_rgba(34,211,238,0.08)]">
              <button
                onClick={() => handleOpenAddModal('soft', 'PDF')}
                className="w-7 h-7 rounded-full border border-cyan-400/60 bg-cyan-500/10 hover:bg-cyan-500/25 hover:scale-105 text-cyan-300 flex items-center justify-center transition-all cursor-pointer shadow-[0_0_12px_rgba(34,211,238,0.3)]"
                title="Add Soft Skills Material"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <div className="text-center leading-tight">
                <div className="text-[11px] font-semibold text-slate-100">No materials yet</div>
                <div className="text-[9.5px] text-slate-300/90">
                  Add your first resource to get started
                </div>
              </div>
              <button
                onClick={() => handleOpenAddModal('soft', 'PDF')}
                className="mt-0.5 px-3.5 py-1 rounded-full border border-cyan-400/55 bg-[#07192e]/90 hover:bg-cyan-500/25 hover:border-cyan-300 text-cyan-200 text-[10px] font-medium flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_15px_rgba(34,211,238,0.2)]"
              >
                <Plus className="w-3 h-3 text-cyan-300" />
                <span>Add Material</span>
              </button>
            </div>
          ) : (
            <ShelfBookRack
              side="left"
              items={softMaterials}
              selectedSourceId={selectedSource?.id}
              onSelectBook={handleSelectSource}
              onRemoveBook={handleRemoveMaterial}
              onRenameBook={handleRenameMaterial}
              onHoverBook={setHoveredSourceId}
              onAddClick={() => handleOpenAddModal('soft', 'PDF')}
            />
          )}

          {/* 4. RIGHT SHELF (Hard Skills):
              - Empty by default: Real 3D-perspective interactive glass bay with real "+ Add Material" button
              - Populated: Recessed 3D physical books standing inside the shelf compartment */}
          {hardMaterials.length === 0 ? (
            <div className="absolute right-[3.8%] top-[23.8%] w-[29.8%] h-[19.8%] z-10 shelf-bay-right rounded-xl border border-cyan-400/20 bg-gradient-to-b from-[#071526]/75 via-[#061220]/65 to-[#050e1a]/80 backdrop-blur-[2px] flex flex-col items-center justify-center gap-1.5 p-2 shadow-[inset_0_0_24px_rgba(34,211,238,0.08)]">
              <button
                onClick={() => handleOpenAddModal('hard', 'PDF')}
                className="w-7 h-7 rounded-full border border-cyan-400/60 bg-cyan-500/10 hover:bg-cyan-500/25 hover:scale-105 text-cyan-300 flex items-center justify-center transition-all cursor-pointer shadow-[0_0_12px_rgba(34,211,238,0.3)]"
                title="Add Hard Skills Material"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <div className="text-center leading-tight">
                <div className="text-[11px] font-semibold text-slate-100">No materials yet</div>
                <div className="text-[9.5px] text-slate-300/90">
                  Add your first resource to get started
                </div>
              </div>
              <button
                onClick={() => handleOpenAddModal('hard', 'PDF')}
                className="mt-0.5 px-3.5 py-1 rounded-full border border-cyan-400/55 bg-[#07192e]/90 hover:bg-cyan-500/25 hover:border-cyan-300 text-cyan-200 text-[10px] font-medium flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_15px_rgba(34,211,238,0.2)]"
              >
                <Plus className="w-3 h-3 text-cyan-300" />
                <span>Add Material</span>
              </button>
            </div>
          ) : (
            <ShelfBookRack
              side="right"
              items={hardMaterials}
              selectedSourceId={selectedSource?.id}
              onSelectBook={handleSelectSource}
              onRemoveBook={handleRemoveMaterial}
              onRenameBook={handleRenameMaterial}
              onHoverBook={setHoveredSourceId}
              onAddClick={() => handleOpenAddModal('hard', 'PDF')}
            />
          )}

          {/* 5. CENTER "Select a source to start" REAL INTERACTIVE GLASS DOCK */}
          <div className="absolute left-1/2 -translate-x-1/2 top-[50.5%] w-[260px] sm:w-[295px] z-20 rounded-2xl border border-cyan-400/60 bg-[#051324]/92 backdrop-blur-md px-3.5 py-3 shadow-[0_0_32px_rgba(34,211,238,0.32)] flex flex-col items-center text-center">
            <div className="text-xs font-bold text-white tracking-wide">
              {selectedSource
                ? String(selectedSource.title).slice(0, 30)
                : 'Select a source to start'}
            </div>
            <div className="text-[10px] text-slate-300 mt-0.5 mb-2.5">
              {selectedSource
                ? `chapter ${selectedSource.chapterN || 1} of ${selectedSource.chapterCount || 1}${selectedSource.license ? `  ·  ${selectedSource.license}` : ''}`
                : '+ Add material from your device, web or notes'}
            </div>
            <div className="grid grid-cols-5 gap-1.5 w-full">
              {sourceDockTypes.map((type) => {
                const icon =
                  type === 'PDF' ? (
                    <FileText className="w-3.5 h-3.5 text-cyan-300" />
                  ) : type === 'Book' ? (
                    <BookOpen className="w-3.5 h-3.5 text-cyan-300" />
                  ) : type === 'Web' ? (
                    <Globe className="w-3.5 h-3.5 text-cyan-300" />
                  ) : type === 'Notes' ? (
                    <StickyNote className="w-3.5 h-3.5 text-cyan-300" />
                  ) : (
                    <FolderOpen className="w-3.5 h-3.5 text-cyan-300" />
                  );

                return (
                  <button
                    key={type}
                    onClick={() =>
                      handleOpenAddModal(
                        type === 'PDF' || type === 'Notes' ? 'soft' : 'hard',
                        type
                      )
                    }
                    className="py-1.5 px-1 rounded-xl border border-cyan-500/30 bg-[#081c33]/90 hover:bg-cyan-500/25 hover:border-cyan-300 hover:shadow-[0_0_14px_rgba(34,211,238,0.4)] flex flex-col items-center justify-center gap-1 transition-all cursor-pointer group"
                    title={`Upload or Add ${type} to Shelf`}
                  >
                    <span className="group-hover:scale-110 transition-transform">{icon}</span>
                    <span className="text-[9.5px] font-medium text-slate-200 group-hover:text-white">
                      {type}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 6. BOTTOM "EXPLORE · RESEARCH · LEARN · BUILD" REAL INTERACTIVE HEX BAR */}
          <div className="absolute left-1/2 -translate-x-1/2 bottom-[3.2%] z-20 clip-hex-bar border border-cyan-400/50 bg-[#051324]/92 backdrop-blur-md px-5 py-1.5 shadow-[0_0_24px_rgba(34,211,238,0.28)] flex items-center gap-2 sm:gap-3">
            <button
              onClick={() => setActiveNav('Search')}
              className="text-cyan-300/80 hover:text-cyan-200 transition-colors cursor-pointer p-0.5"
              title="Search Archive"
            >
              <Search className="w-3.5 h-3.5" />
            </button>
            {(['EXPLORE', 'RESEARCH', 'LEARN', 'BUILD'] as WorkspaceMode[]).map((mode, i) => {
              const isActive = workspaceMode === mode;
              return (
                <React.Fragment key={mode}>
                  {i > 0 && <span className="text-slate-500 text-[10px]">·</span>}
                  <button
                    onClick={() => {
                      brainAudio.playUiChime('mode');
                      setWorkspaceMode(mode);
                      setSystemStateText(`Mode  ·  ${mode}`);
                      pulseCenterBeam();
                    }}
                    className={`px-1.5 py-0.5 text-[10px] sm:text-[11px] font-display font-bold tracking-[0.16em] transition-all cursor-pointer ${
                      isActive
                        ? 'text-cyan-300 border-b-2 border-cyan-300 shadow-[0_4px_10px_rgba(34,211,238,0.35)]'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {mode}
                  </button>
                </React.Fragment>
              );
            })}
          </div>
        </main>

        {/* -------------------------------------------------------------------
            3. RIGHT PANEL: "ASK THE SOURCE" (Fits 100% cleanly on all screens)
        -------------------------------------------------------------------- */}
        <aside className="w-[335px] lg:w-[365px] xl:w-[390px] shrink-0 h-full flex flex-col justify-between p-3.5 border-l border-cyan-500/20 bg-[#050e1b] z-20 overflow-hidden">
          <div className="flex-1 flex flex-col min-h-0 space-y-2.5 overflow-hidden">
            {/* Panel Header — Always Pinned at Top */}
            <div className="flex items-start justify-between gap-2 shrink-0">
              <div className="flex items-center gap-2.5">
                <JarvisTargetIcon className="w-7 h-7 shrink-0" />
                <div>
                  <h2 className="font-display text-base lg:text-lg font-bold tracking-[0.1em] text-white leading-tight">
                    ASK THE SOURCE
                  </h2>
                  <p className="text-[11px] text-slate-300">
                    Get precise answers from your selected source
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (materials.length > 0) {
                    const idx = selectedSource
                      ? (materials.findIndex((m) => m.id === selectedSource.id) + 1) %
                        materials.length
                      : 0;
                    handleSelectSource(materials[idx]);
                  } else {
                    handleOpenAddModal('soft', 'PDF');
                  }
                }}
                className="p-1.5 rounded-lg text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/10 transition-colors cursor-pointer"
                title="Cycle source or add material"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Selected Source Inspector Card */}
            <div className="p-2 rounded-2xl border border-cyan-500/20 bg-[#071425]/90 shrink-0">
              <div className="p-3 rounded-xl border border-dashed border-cyan-500/25 bg-[#061120]/70">
                {!selectedSource ? (
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-xl bg-[#0c1d33] border border-cyan-500/15 flex items-center justify-center text-slate-400 shrink-0">
                      <User className="w-5 h-5 text-cyan-400/60" />
                    </div>
                    <div className="space-y-1 min-w-0">
                      <div className="text-xs font-semibold text-white">No source selected</div>
                      <p className="text-[11px] text-slate-300 leading-snug">
                        Choose a material from either shelf or add a new one.
                      </p>
                      <div className="pt-0.5 flex items-center gap-2">
                        <button
                          onClick={() => handleOpenAddModal('soft', 'PDF')}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-cyan-400/45 bg-cyan-500/10 hover:bg-cyan-500/25 text-cyan-300 text-[11px] font-medium transition-colors cursor-pointer"
                        >
                          <Tag className="w-3 h-3" />
                          <span>Browse Library</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    {/* Physical 3D Book Thumbnail matching 2nd Image */}
                    <div className="relative w-12 h-16 rounded-r-[4px] rounded-l-[2px] bg-gradient-to-br from-[#132540] via-[#0b1628] to-[#060c17] border border-cyan-300/60 p-1.5 flex flex-col justify-between shrink-0 shadow-[0_4px_12px_rgba(0,0,0,0.85)]">
                      <div className="w-1 h-full bg-rose-500 absolute left-0 top-0 bottom-0 rounded-l-[2px]" />
                      <span className="pl-1 px-1 py-0.2 rounded bg-rose-600 text-[7px] font-extrabold text-white uppercase w-fit">
                        {selectedSource.type}
                      </span>
                      <div className="pl-1 text-[8px] font-bold text-slate-100 leading-tight line-clamp-2 break-words">
                        {selectedSource.title}
                      </div>
                    </div>

                    {/* Uploaded Material Name & Live Cover Title Editor */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-1.5">
                        {isEditingInspectorTitle ? (
                          <input
                            type="text"
                            autoFocus
                            value={selectedSource.title}
                            onChange={(e) =>
                              handleRenameMaterial(selectedSource.id, e.target.value)
                            }
                            onBlur={() => setIsEditingInspectorTitle(false)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') setIsEditingInspectorTitle(false);
                            }}
                            className="flex-1 min-w-0 bg-[#040c18] border border-cyan-300 rounded px-2 py-0.5 text-xs font-bold text-white focus:outline-none"
                          />
                        ) : (
                          <div
                            onClick={() => setIsEditingInspectorTitle(true)}
                            className="text-xs sm:text-sm font-bold text-white truncate cursor-pointer hover:text-cyan-200 flex items-center gap-1.5"
                            title="Click to edit book cover title on the 3D shelf"
                          >
                            <span className="truncate">{selectedSource.title}</span>
                            <Pencil className="w-3 h-3 text-cyan-400/80 shrink-0" />
                          </div>
                        )}
                        <button
                          onClick={() => setSelectedSource(null)}
                          className="text-slate-400 hover:text-white cursor-pointer shrink-0"
                          title="Unselect source"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] text-slate-300 truncate">
                        {selectedSource.subcategory}  ·  {selectedSource.type}  ·  {selectedSource.fileSize || 'size not known'}
                      </div>

                      <div className="pt-0.5 flex items-center justify-between gap-2">
                        {selectedSource.readable === false ? (
                          <button
                            onClick={() => selectedSource.url && window.open(selectedSource.url, '_blank', 'noopener,noreferrer')}
                            className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border border-amber-400/45 bg-amber-500/12 text-amber-200 text-[10px] font-medium cursor-pointer"
                            title="Their licence keeps the text out of this library - open it in the browser"
                          >
                            <Globe className="w-2.5 h-2.5" />
                            LINK ONLY · open
                          </button>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border border-emerald-400/40 bg-emerald-500/15 text-emerald-300 text-[10px] font-medium">
                            <Sparkles className="w-2.5 h-2.5" />
                            Source Ready
                          </span>
                        )}
                        <button
                          onClick={() =>
                            handleOpenAddModal(selectedSource.category, selectedSource.type)
                          }
                          className="px-2.5 py-0.5 rounded-full border border-cyan-500/30 bg-[#091c34] hover:border-cyan-400 text-cyan-200 text-[10px] font-medium cursor-pointer"
                        >
                          + Add More
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Segmented Mode Control: TEXT | AUDIO */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl border border-cyan-500/20 bg-[#071425] shrink-0">
              <button
                onClick={() => setMediaTab('TEXT')}
                className={`flex items-center justify-center gap-2 py-1.5 rounded-lg text-xs font-display font-bold tracking-wider transition-all cursor-pointer ${
                  mediaTab === 'TEXT'
                    ? 'bg-gradient-to-b from-cyan-500/30 to-cyan-600/15 border border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.28)]'
                    : 'text-slate-300 hover:text-white border border-transparent'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-cyan-300" />
                <span>TEXT</span>
              </button>
              <button
                onClick={() => setMediaTab('AUDIO')}
                className={`flex items-center justify-center gap-2 py-1.5 rounded-lg text-xs font-display font-bold tracking-wider transition-all cursor-pointer ${
                  mediaTab === 'AUDIO'
                    ? 'bg-gradient-to-b from-cyan-500/30 to-cyan-600/15 border border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.28)]'
                    : 'text-slate-300 hover:text-white border border-transparent'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 text-cyan-300" />
                <span>AUDIO</span>
              </button>
            </div>

            {/* Read Aloud Audio Player Card (Spacious & Zero Overlap) */}
            <div className="p-3 rounded-2xl border border-cyan-500/20 bg-[#071425]/90 space-y-2 shrink-0">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-200">Read aloud</span>
                {isBrainSoundActive && (
                  <span className="text-[10px] text-cyan-300 font-mono-tabular">
                    STUDY WAVES ON
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <div className="flex flex-col items-center gap-1 shrink-0">
                  <button
                    onClick={() => triggerReadAloud()}
                    className="w-9 h-9 rounded-full border-2 border-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/25 flex items-center justify-center text-cyan-300 shadow-[0_0_14px_rgba(34,211,238,0.3)] transition-all cursor-pointer"
                    title={isPlayingAudio ? 'Pause Read Aloud' : 'Play Read Aloud'}
                  >
                    {isPlayingAudio ? (
                      <Pause className="w-3.5 h-3.5 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    )}
                  </button>
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" />
                </div>

                {/* Progress Bar & Timer — Guaranteed width so it never wraps */}
                <div className="flex-1 min-w-[78px] space-y-1">
                  <div
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const ratio = Math.max(
                        0,
                        Math.min(1, (e.clientX - rect.left) / rect.width)
                      );
                      const dur = audioDurationSec || 45;
                      setAudioDurationSec(dur);
                      setAudioCurrentSec(Math.round(ratio * dur));
                      setAudioProgress(ratio * 100);
                    }}
                    className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden cursor-pointer"
                  >
                    <div
                      className="h-full bg-gradient-to-r from-cyan-400 to-cyan-200 transition-all duration-300"
                      style={{ width: `${audioProgress}%` }}
                    />
                  </div>
                  <div className="text-[10px] font-mono-tabular text-slate-300 whitespace-nowrap">
                    {formatTime(audioCurrentSec)} / {formatTime(audioDurationSec)}
                  </div>
                </div>

                {/* Playback Speed Dropdown */}
                <div className="relative shrink-0">
                  <button
                    onClick={() => {
                      setShowSpeedMenu(!showSpeedMenu);
                      setShowVoiceMenu(false);
                    }}
                    className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-cyan-500/25 bg-[#091a30] hover:border-cyan-400 text-[11px] font-mono-tabular text-slate-200 cursor-pointer whitespace-nowrap"
                  >
                    <span>{playbackSpeed.toFixed(1)}x</span>
                    <ChevronDown className="w-3 h-3 text-slate-400" />
                  </button>
                  {showSpeedMenu && (
                    <div className="absolute right-0 mt-1 w-20 rounded-xl border border-cyan-400/50 bg-[#061427] shadow-xl py-1 z-40">
                      {speedOptions.map((spd) => (
                        <button
                          key={spd}
                          onClick={() => {
                            setPlaybackSpeed(spd);
                            setShowSpeedMenu(false);
                          }}
                          className={`w-full px-3 py-1 text-left text-xs font-mono-tabular hover:bg-cyan-500/20 cursor-pointer ${
                            playbackSpeed === spd ? 'text-cyan-300 font-bold' : 'text-slate-300'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* AI Voice Selector Dropdown */}
                <div className="relative shrink-0">
                  <button
                    onClick={() => {
                      setShowVoiceMenu(!showVoiceMenu);
                      setShowSpeedMenu(false);
                    }}
                    className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-cyan-500/25 bg-[#091a30] hover:border-cyan-400 text-[11px] text-slate-200 cursor-pointer whitespace-nowrap"
                  >
                    <span className="text-cyan-400 font-bold">||·</span>
                    <span className="max-w-[78px] truncate">{selectedVoiceLabel}</span>
                    <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
                  </button>
                  {showVoiceMenu && (
                    <div className="absolute right-0 mt-1 w-44 rounded-xl border border-cyan-400/50 bg-[#061427] shadow-xl py-1 z-40">
                      {voiceOptions.map((v) => (
                        <button
                          key={v}
                          onClick={() => {
                            setSelectedVoiceLabel(v);
                            setShowVoiceMenu(false);
                          }}
                          className={`w-full px-3 py-1.5 text-left text-xs hover:bg-cyan-500/20 cursor-pointer flex items-center justify-between ${
                            selectedVoiceLabel === v
                              ? 'text-cyan-300 font-semibold'
                              : 'text-slate-300'
                          }`}
                        >
                          <span>{v}</span>
                          {selectedVoiceLabel === v && <Check className="w-3 h-3" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* First Source Filter Toggles Row */}
            <div className="px-3 py-2 rounded-xl border border-cyan-500/20 bg-[#071425]/80 flex items-center justify-between gap-2 shrink-0 relative">
              <button
                onClick={() => setSelectedSourceOnly(!selectedSourceOnly)}
                className="flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer"
              >
                <div
                  className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                    selectedSourceOnly ? 'bg-cyan-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-3 h-3 rounded-full bg-white shadow" />
                </div>
                <span className="text-[11px] font-medium whitespace-nowrap">
                  Selected source only
                </span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIncludeLinkedSources(!includeLinkedSources)}
                  className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  <div
                    className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                      includeLinkedSources ? 'bg-cyan-400 justify-end' : 'bg-slate-700 justify-start'
                    }`}
                  >
                    <div className="w-3 h-3 rounded-full bg-slate-300 shadow" />
                  </div>
                  <span className="text-[11px] whitespace-nowrap">Include linked sources</span>
                </button>
                <button
                  onClick={() => setShowLinkedTooltip(!showLinkedTooltip)}
                  className="text-slate-400 hover:text-cyan-300 cursor-pointer"
                >
                  <Info className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Conversation / Q&A Feed Area */}
            <div className="flex-1 min-h-0 overflow-y-auto space-y-2 pr-1">
              <div className="p-3 rounded-xl border border-cyan-500/20 bg-[#071425]/85 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#0b1f38] border border-cyan-500/20 flex items-center justify-center text-cyan-300 shrink-0">
                  <User className="w-4 h-4" />
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Ask a question after selecting a source, or add a note/material to begin.
                </p>
              </div>

              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-3 rounded-xl border text-xs leading-relaxed space-y-1.5 ${
                    msg.role === 'user'
                      ? 'border-cyan-500/30 bg-[#091c34] text-white ml-4'
                      : 'border-cyan-400/50 bg-[#061527] text-slate-200 mr-2 shadow-[0_0_15px_rgba(6,182,212,0.12)]'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-cyan-300/80">
                    <span className="font-semibold uppercase tracking-wider">
                      {msg.role === 'user' ? 'You' : 'JARVIS'}
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>
                  <p className="whitespace-pre-line">{msg.text}</p>
                  {msg.citation && msg.role === 'jarvis' && (
                    <p className="text-[9px] uppercase tracking-[0.14em] text-cyan-200/45 pt-1">
                      {msg.citation}
                    </p>
                  )}
                  {msg.numberedPoints && (
                    <ol className="space-y-1 list-decimal list-inside text-slate-300">
                      {msg.numberedPoints.map((pt, idx) => (
                        <li key={idx}>
                          <strong className="text-white">{pt.title}</strong> — {pt.detail}
                        </li>
                      ))}
                    </ol>
                  )}
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Bottom Pinned Input Box & Bottom Toggles Row */}
          <div className="pt-2.5 space-y-2 shrink-0 bg-[#050e1b]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAskQuestion();
              }}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border border-cyan-500/25 bg-[#071527] focus-within:border-cyan-300 transition-all"
            >
              <input
                type="text"
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                placeholder='Ask a question or say "Read the paragraph about..."'
                className="flex-1 bg-transparent text-xs text-white placeholder:text-slate-400 focus:outline-none min-w-0"
              />
              {questionInput.trim() && (
                <button
                  type="submit"
                  className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/35 cursor-pointer"
                  title="Send Question"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                type="button"
                onClick={handleToggleMic}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isListeningMic
                    ? 'bg-rose-500/25 text-rose-300 border border-rose-400 animate-pulse'
                    : 'text-slate-300 hover:text-cyan-300 hover:bg-cyan-500/15'
                }`}
                title="Voice Input"
              >
                {isListeningMic ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </form>

            {/* Bottom Toggles Bar */}
            <div className="px-3 py-2 rounded-xl border border-cyan-500/15 bg-[#071425]/60 flex items-center justify-between gap-2">
              <button
                onClick={() => setSelectedSourceOnly(!selectedSourceOnly)}
                className="flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer"
              >
                <div
                  className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                    selectedSourceOnly ? 'bg-cyan-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-3 h-3 rounded-full bg-white shadow" />
                </div>
                <span className="text-[11px] font-medium whitespace-nowrap">
                  Selected source only
                </span>
              </button>

              <button
                onClick={() => setIncludeLinkedSources(!includeLinkedSources)}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                <div
                  className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                    includeLinkedSources ? 'bg-cyan-400 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-3 h-3 rounded-full bg-slate-300 shadow" />
                </div>
                <span className="text-[11px] whitespace-nowrap">Include linked sources</span>
              </button>
            </div>
          </div>
        </aside>
      </div>

      {/* Add / Upload Material Modal */}
      <AddMaterialModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        initialCategory={addModalCategory}
        initialType={addModalType}
        existingMaterials={materials}
        onAddMaterial={handleAddMaterial}
        onLoadAllPresets={handleLoadAllPresets}
        onSelectExisting={handleSelectSource}
      />

      {/* Export ZIP & Python/JS JARVIS Integration Modal */}
      <ExportZipModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        materials={materials}
      />
    </div>
  );
}
