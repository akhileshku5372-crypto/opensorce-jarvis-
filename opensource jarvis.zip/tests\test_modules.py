"""Tests for the honest Modules & Upgrades capability matrix.

Covers the registry contract, the new local modules, the real tool-registry
integration and the two safety gates. Stdlib + real local subsystems only:
no network, no LLM, no app launch, no camera, no ffmpeg render.
"""
from __future__ import annotations

import importlib.util
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(name: str):
    """Load a background module under the shared cowork key."""
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    spec = importlib.util.spec_from_file_location(full, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


REGISTRY = _load("capability_registry")
TELEMETRY = _load("telemetry")
SCHEDULER = _load("scheduler_core")
FOCUS = _load("focus_analytics")
OCR = _load("ocr_engine")
VIDEO = _load("video_editor")
BROWSER = _load("browser_agent")
PERMS = _load("permissions")
EXT = _load("extensions")
TOOLS = _load("cowork_tools")

VALID_STATES = {"LIVE", "READY", "BLOCKED"}


class CatalogTest(unittest.TestCase):
    def test_catalog_covers_every_capability(self):
        """A floor, not an exact count.

        Pinning this to 50 meant any honest addition (presentation-builder and
        proactive-sentinel were claimed LIVE by the blueprint with no card at all)
        broke the gate, while AGENTS.md quietly drifted to "48". The real
        invariants are the floor, unique ids, and the snapshot matching the catalog.
        """
        self.assertGreaterEqual(len(REGISTRY.CATALOG), 50,
                                "a capability card was removed")

    def test_every_card_has_a_unique_id_and_metadata(self):
        ids = [row[0] for row in REGISTRY.CATALOG]
        self.assertEqual(len(ids), len(set(ids)), "duplicate capability id")
        for cid, icon, name, desc, phase, group, probe in REGISTRY.CATALOG:
            self.assertTrue(cid and icon and name and desc, cid)
            self.assertIn(phase, {"PHASE 0", "PHASE 1", "PHASE 2", "PHASE 3",
                                  "PHASE 4", "PHASE 5", "PHASE 6", "DREAM"})
            self.assertTrue(group, cid)
            self.assertTrue(callable(probe), cid)

    def test_snapshot_reports_a_valid_state_for_every_card(self):
        snap = REGISTRY.snapshot(force=True)
        self.assertGreaterEqual(snap["total"], 50)
        self.assertEqual(snap["total"], len(REGISTRY.CATALOG),
                         "the snapshot is not reporting the whole catalog")
        self.assertEqual(snap["source"], "local")
        for row in snap["capabilities"]:
            self.assertIn(row["state"], VALID_STATES, row["id"])

    def test_counts_match_the_rows(self):
        snap = REGISTRY.snapshot(force=True)
        rows = snap["capabilities"]
        for state in VALID_STATES:
            self.assertEqual(snap["counts"][state],
                             len([r for r in rows if r["state"] == state]), state)
        self.assertEqual(sum(snap["counts"].values()), snap["total"])

    def test_every_card_carries_a_reason(self):
        """A card must never show a bare state with no explanation."""
        for row in REGISTRY.snapshot(force=True)["capabilities"]:
            self.assertTrue(str(row.get("reason") or "").strip(),
                            "%s has no reason" % row["id"])

    def test_blocked_cards_say_what_is_missing(self):
        """BLOCKED must be a specific, actionable reason - never 'coming soon'."""
        rows = REGISTRY.snapshot(force=True)["capabilities"]
        blocked = [r for r in rows if r["state"] == "BLOCKED"]
        self.assertTrue(blocked, "expected some blocked cards on this machine")
        for row in blocked:
            reason = row["reason"].lower()
            for vague in ("coming soon", "tbd", "soon", "scheduled for", "wip"):
                self.assertNotIn(vague, reason,
                                 "%s uses a vague reason" % row["id"])

    def test_dream_cards_are_never_claimed_live(self):
        for row in REGISTRY.snapshot(force=True)["capabilities"]:
            if row["phase"] == "DREAM":
                self.assertNotEqual(row["state"], "LIVE",
                                    "%s is a DREAM card claiming LIVE" % row["id"])

    def test_no_probe_claims_live_from_a_bare_import(self):
        """A probe that only proves "a module imports" must not say LIVE.

        This is the exact defect the 2026-09-29 audit found: eleven cards
        reported LIVE because a file existed or imported, which proves
        importability, not capability. AGENTS.md requires LIVE to mean the
        code path is "reachable right now", so a LIVE verdict has to be
        backed by a real observation recorded in `evidence`.

        The rule encoded here: every LIVE card must carry at least one
        non-empty evidence value. A probe that hard-codes _live() with no
        observation cannot satisfy this and will be caught here.
        """
        rows = REGISTRY.snapshot(force=True)["capabilities"]
        offenders = []
        for row in rows:
            if row["state"] != "LIVE":
                continue
            evidence = row.get("evidence") or {}
            observed = [k for k, v in evidence.items()
                        if v not in (None, "", [], {}, 0, False)]
            if not observed:
                offenders.append(row["id"])
        self.assertEqual(
            offenders, [],
            "LIVE cards with no real observation: %s. Add evidence to the "
            "probe (tool names, pids, counts) or downgrade the verdict."
            % offenders)

    def test_browser_card_cannot_be_live_without_page_control(self):
        """The 'false LIVE' regression lock.

        `browser-ext` once reported "In-page browser automation" while the only
        browser tools were Firecrawl HTTP fetches. If a real page-control tool
        is ever registered the card may go LIVE; until then it must BLOCKED and
        say why.
        """
        row = REGISTRY.get("browser-ext")
        if row["state"] == "LIVE":
            tools = set(REGISTRY._tool_names())
            page = [t for t in tools if any(
                k in t for k in ("browser", "navigate", "click", "dom_",
                                 "tab_", "page_", "playwright", "scrape"))]
            self.assertTrue(page,
                            "browser-ext is LIVE but no page-control tool exists")
        else:
            self.assertNotEqual(row["state"], "READY",
                                "browser-ext must be BLOCKED (no page control)")

    def test_video_editor_blocked_reason_says_parked_not_broken(self):
        """Owner parked the video editor; BLOCKED must not imply a defect."""
        row = REGISTRY.get("video-editor")
        self.assertEqual(row["state"], "BLOCKED")
        reason = row["reason"].lower()
        self.assertIn("parked", reason,
                      "a parked card must say it is parked")
        self.assertIn("intact", reason,
                      "parked must state the code still works, else BLOCKED "
                      "misleads the owner into thinking it is broken")

    def test_soft_hard_is_ready_until_the_syllabus_exists(self):
        """The card promises a comms/psych syllabus that has not been written."""
        row = REGISTRY.get("soft-hard")
        self.assertIn(row["state"], {"READY", "LIVE"})
        if row["state"] == "READY":
            self.assertIn("not written", row["reason"].lower())

    def test_dock_probe_checks_a_running_process_not_a_file(self):
        """A HUD file on disk is not a live hub; the probe must look at PIDs."""
        row = REGISTRY.get("dock")
        pids = REGISTRY._hud_process()
        if pids:
            self.assertEqual(row["state"], "LIVE")
        else:
            self.assertEqual(row["state"], "BLOCKED")
            self.assertIn("no hud process", row["reason"].lower())

    def test_hud_is_supervised_by_pm2_not_a_manual_launch(self):
        """The 2026-10-18 audit's defect 4: the HUD was the only long-running
        service missing from ecosystem.config.cjs, so after every reboot the
        Modules page honestly reported "on disk but not running" and the
        Ctrl+Shift+J hub was dead. Lock the supervision in."""
        text = (REGISTRY.ROOT / "ecosystem.config.cjs").read_text(
            encoding="utf-8")
        self.assertIn("jarvis-hud", text)
        self.assertIn("background/floating_ui.pyw", text)

    def test_adb_probe_never_takes_credit_for_a_bare_binary(self):
        """adb.exe on disk is a precondition, not a phone bridge.

        The probe used to answer LIVE the moment the binary existed, even
        though no code in the repo runs an adb command. It must stay BLOCKED
        until the bridge implementation actually ships, and must name what is
        missing so the card can never quietly overclaim again.
        """
        row = REGISTRY.get("adb-sync")
        bridge = REGISTRY.ROOT / "background" / "android_sync.py"
        if bridge.is_file():
            self.assertIn(row["state"], ("READY", "LIVE"))
        else:
            self.assertEqual(row["state"], "BLOCKED")
            self.assertIn("android_sync.py", row["reason"])
            self.assertFalse(row["evidence"].get("implementation"))

    def test_get_returns_one_reprobed_card(self):
        row = REGISTRY.get("telemetry")
        self.assertEqual(row["id"], "telemetry")
        self.assertIn(row["state"], VALID_STATES)

    def test_get_rejects_an_unknown_id(self):
        out = REGISTRY.get("definitely-not-a-module")
        self.assertFalse(out.get("ok"))
        self.assertIn("no capability", out.get("error", ""))

    def test_snapshot_is_cached_but_force_reprobes(self):
        REGISTRY.snapshot(force=True)
        first = REGISTRY.snapshot()
        self.assertIs(first, REGISTRY.snapshot(), "snapshot should be cached")
        self.assertIsNot(first, REGISTRY.snapshot(force=True))

    def test_describe_uses_real_counts(self):
        text = REGISTRY.describe()
        snap = REGISTRY.snapshot()
        self.assertIn(str(snap["counts"]["LIVE"]), text)
        self.assertIn("modules", text.lower())


class TelemetryTest(unittest.TestCase):
    def test_battery_is_real_or_explicitly_unavailable(self):
        bat = TELEMETRY.battery()
        self.assertIn("available", bat)
        if bat["available"]:
            self.assertIsNotNone(bat["percent"])
            self.assertGreaterEqual(bat["percent"], 0)
        else:
            # Never a fake percentage when the platform cannot supply one.
            self.assertIsNone(bat["percent"])
            self.assertTrue(bat["reason"])

    def test_cpu_and_memory_are_real_probes(self):
        cpu, mem = TELEMETRY.cpu(), TELEMETRY.memory()
        self.assertTrue(cpu.get("available"))
        self.assertTrue(mem.get("available"))
        self.assertIsInstance(cpu["cores"], list)
        self.assertIsNotNone(mem["total_gb"])

    def test_snapshot_shape(self):
        snap = TELEMETRY.system()
        self.assertEqual(snap["source"], "local")
        for key in ("host", "battery", "cpu", "memory", "disks", "processes"):
            self.assertIn(key, snap)

    def test_read_only_tools_are_not_confirm_gated(self):
        for spec in TELEMETRY.specs():
            self.assertFalse(spec.requires_confirmation, spec.name)

    def test_tool_returns_a_real_snapshot(self):
        out = TELEMETRY._tool_snapshot({})
        self.assertTrue(out["ok"])
        self.assertIn("data", out)


class SchedulerTest(unittest.TestCase):
    def test_parse_duration(self):
        cases = {"10m": 600, "2 hours": 7200, "90s": 90, "1d": 86400,
                 "30 min": 1800, "in 45 seconds": 45}
        for text, expected in cases.items():
            self.assertEqual(SCHEDULER.parse_duration(text), expected, text)

    def test_parse_duration_rejects_nonsense(self):
        for text in ("", "banana", "hello world"):
            self.assertEqual(SCHEDULER.parse_duration(text), 0.0, text)

    def test_set_timer_requires_a_command(self):
        self.assertFalse(SCHEDULER.set_timer("", seconds=5)["ok"])

    def test_state_file_never_persists_a_runtime_thread_handle(self):
        """`_timer` is a live thread; persisting it writes junk reprs to disk.

        `json.dumps(..., default=str)` would happily store
        "<Timer(Thread-82, started daemon 46336)>", which then round-trips as
        fake state and makes the on-disk file disagree with the live API.
        """
        import json
        before = len(SCHEDULER.timers())
        SCHEDULER.set_timer("noop", seconds=900, label="persist-probe")
        try:
            raw = SCHEDULER.STATE_PATH.read_text(encoding="utf-8")
            self.assertNotIn("_timer", raw,
                             "runtime thread handle leaked into state.json")
            # The persisted row must be plain JSON, not a stringified object.
            for row in json.loads(raw).get("timers") or []:
                self.assertIsInstance(row, dict)
                self.assertNotIn("_timer", row)
                self.assertNotIn("started daemon", json.dumps(row))
        finally:
            for row in SCHEDULER.timers():
                if row.get("label") == "persist-probe":
                    SCHEDULER.cancel(row["id"])
            self.assertGreaterEqual(len(SCHEDULER.timers()), before)

    def test_one_shot_timer_fires_and_removes_itself(self):
        before = len(SCHEDULER.timers())
        result = SCHEDULER.set_timer("noop", seconds=0.3)
        self.assertTrue(result["ok"])
        self.assertEqual(len(SCHEDULER.timers()), before + 1)
        time.sleep(1.2)
        self.assertEqual(len(SCHEDULER.timers()), before,
                         "one-shot timer must be removed after firing")
        self.assertIn("fired", [row["kind"] for row in SCHEDULER.history(10)])

    def test_recurring_timer_is_rejected_below_five_seconds(self):
        out = SCHEDULER.schedule_every("noop", "1s")
        self.assertFalse(out["ok"])
        self.assertIn("5 seconds", out["error"])

    def test_recurring_timer_survives_its_first_fire(self):
        out = SCHEDULER.set_timer("noop", interval_s=5)
        self.assertTrue(out["ok"])
        tid = out["timer"]["id"]
        try:
            self.assertTrue(out["timer"]["recurring"])
            SCHEDULER._timers[tid]["fire_at"] = time.time() + 0.2
            time.sleep(1.0)
            self.assertIn(tid, SCHEDULER._timers, "recurring timer must re-arm")
        finally:
            SCHEDULER.cancel(tid)

    def test_cancel_unknown_timer_fails_honestly(self):
        self.assertFalse(SCHEDULER.cancel("tmr_nope")["ok"])

    def test_schedule_at_requires_a_clock_time(self):
        self.assertFalse(SCHEDULER.schedule_at("x", "tomorrow-ish")["ok"])
        out = SCHEDULER.schedule_at("noop", "09:30")
        self.assertTrue(out["ok"])
        SCHEDULER.cancel(out["timer"]["id"])

    def test_workflow_round_trip(self):
        name = "test_flow_%d" % int(time.time() * 1000)
        self.assertFalse(SCHEDULER.save_workflow("", ["x"])["ok"])
        self.assertFalse(SCHEDULER.save_workflow(name, [])["ok"])
        saved = SCHEDULER.save_workflow(name, ["open notepad", "what is the time"])
        self.assertTrue(saved["ok"])
        self.assertEqual(saved["workflow"]["steps"],
                         ["open notepad", "what is the time"])
        try:
            run = SCHEDULER.run_workflow(name)
            self.assertTrue(run["ok"])
            self.assertEqual(run["count"], 2)
            self.assertFalse(SCHEDULER.run_workflow("no_such_flow")["ok"])
        finally:
            SCHEDULER.delete_workflow(name)

    def test_writes_are_confirm_gated_and_reads_are_not(self):
        gated = {s.name for s in SCHEDULER.specs() if s.requires_confirmation}
        free = {s.name for s in SCHEDULER.specs() if not s.requires_confirmation}
        self.assertIn("scheduler_set_timer", gated)
        self.assertIn("automation_run_workflow", gated)
        self.assertIn("scheduler_status", free)
        self.assertIn("scheduler_cancel", free)

    def test_dispatch_never_imports_a_second_voice_engine(self):
        """AGENTS.md: never a second brain / mic / memory pipeline."""
        before = len([k for k in sys.modules if "voice_engine" in k])
        SCHEDULER._dispatch({"command": "noop"})
        after = len([k for k in sys.modules if "voice_engine" in k])
        self.assertEqual(before, after, "_dispatch imported a second voice engine")


class FocusAnalyticsTest(unittest.TestCase):
    def test_snapshot_is_available_or_explains_why_not(self):
        snap = FOCUS.snapshot()
        self.assertIn("available", snap)
        if not snap["available"]:
            self.assertTrue(snap["reason"])
            self.assertEqual(snap["apps"], [])
        else:
            self.assertEqual(snap["source"], "local")

    def test_start_is_idempotent_and_never_spawns_two_samplers(self):
        import threading
        FOCUS.reset()
        FOCUS.start(1.0)
        FOCUS.start(1.0)
        FOCUS.start(1.0)
        samplers = [t for t in threading.enumerate() if t.name == "jarvis-focus"]
        try:
            self.assertLessEqual(len(samplers), 1, "focus sampler must be single")
        finally:
            FOCUS.stop()

    def test_reset_clears_measured_time(self):
        FOCUS.reset()
        self.assertEqual(FOCUS.snapshot()["apps"], [])
        self.assertEqual(FOCUS.snapshot()["tracked_seconds"], 0)

    def test_reset_is_confirm_gated(self):
        reset_specs = [s for s in FOCUS.specs() if s.name.endswith("_reset")]
        self.assertTrue(reset_specs)
        self.assertTrue(reset_specs[0].requires_confirmation)


class OcrTest(unittest.TestCase):
    def test_capabilities_report_each_path_honestly(self):
        caps = OCR.capabilities()
        self.assertEqual(caps["source"], "local")
        for key in ("digital_pdf", "scanned_pdf", "screen_ocr"):
            self.assertIn("available", caps[key])
            if not caps[key]["available"]:
                self.assertTrue(caps[key]["reason"], key)

    def test_missing_file_fails_honestly(self):
        out = OCR.read_document("definitely-missing-file.pdf")
        self.assertFalse(out["ok"])
        self.assertIn("not found", out["error"])

    def test_unsupported_extension_is_rejected(self):
        out = OCR.read_document(str(ROOT / "package.json"))
        self.assertFalse(out["ok"])
        self.assertIn("no local reader", out["error"])

    def test_screen_ocr_never_claims_tesseract_when_missing(self):
        caps = OCR.capabilities()
        if not caps["screen_ocr"]["available"]:
            out = OCR._tool_ocr_screen({})
            self.assertFalse(out["ok"])
            self.assertTrue(out["output"])


class VideoEditorTest(unittest.TestCase):
    def test_capabilities_report_each_stage_honestly(self):
        caps = VIDEO.capabilities()
        for key in ("silence_cut", "captions", "scene_labels"):
            self.assertIn("available", caps[key])
            if not caps[key]["available"]:
                self.assertTrue(caps[key]["reason"], key)

    def test_missing_video_fails_honestly(self):
        out = VIDEO.cut_silence("definitely-missing.mp4")
        self.assertFalse(out["ok"])
        self.assertIn("not found", out["error"])

    def test_silence_cut_and_caption_writes_are_confirm_gated(self):
        gated = {s.name for s in VIDEO.specs() if s.requires_confirmation}
        free = {s.name for s in VIDEO.specs() if not s.requires_confirmation}
        self.assertIn("video_cut_silence", gated)
        self.assertIn("video_caption", gated)
        self.assertIn("video_editor_status", free)
        self.assertIn("video_scene_labels", free)

    def test_srt_timestamp_format(self):
        self.assertEqual(VIDEO._srt_timestamp(0), "00:00:00,000")
        self.assertEqual(VIDEO._srt_timestamp(3661.5), "01:01:01,500")

    def test_keep_segments_is_the_complement_of_silence(self):
        keep = VIDEO._keep_segments(10.0, [{"start": 2.0, "end": 4.0},
                                            {"start": 6.0, "end": 7.0}])
        self.assertEqual(keep, [(0.0, 2.0), (4.0, 6.0), (7.0, 10.0)])

    def test_trailing_silence_is_treated_as_open_ended(self):
        keep = VIDEO._keep_segments(10.0, [{"start": 8.0, "end": None}])
        self.assertEqual(keep, [(0.0, 8.0)])


class BrowserAgentTest(unittest.TestCase):
    """Real page control (Playwright). No page is launched for the safety
    tests, and the one network test is skipped when the driver is absent."""

    @classmethod
    def setUpClass(cls):
        cls.ready = BROWSER.available()

    def test_availability_is_honest(self):
        caps = BROWSER.capabilities()
        self.assertIn("available", caps)
        if not caps["available"]:
            self.assertTrue(caps["reason"],
                            "unavailable must say why (pip / install chromium)")
        else:
            self.assertEqual(caps["driver"], "playwright/chromium")

    def test_only_http_schemes_survive(self):
        """A URL must never become a local path or a script scheme."""
        for bad in ("file:///C:/Windows/System32/cmd.exe",
                    "javascript:alert(1)", "data:text/html,<h1>x",
                    "vbscript:msgbox(1)", "about:blank", "",
                    "C:\\Windows\\System32\\cmd.exe", "\\\\server\\share"):
            self.assertEqual(BROWSER.safe_url(bad), "",
                             "safe_url accepted %r" % bad)
        self.assertEqual(BROWSER.safe_url("example.com"), "https://example.com")
        self.assertEqual(BROWSER.safe_url("https://example.com"),
                         "https://example.com")

    def test_reads_are_free_and_page_mutations_are_confirm_gated(self):
        specs = {s.name: s for s in BROWSER.specs()}
        for free in ("browser_status", "browser_navigate", "browser_read",
                     "browser_screenshot", "browser_tabs"):
            self.assertIn(free, specs)
            self.assertFalse(specs[free].requires_confirmation, free)
        for gated in ("browser_click", "browser_type"):
            self.assertIn(gated, specs)
            self.assertTrue(specs[gated].requires_confirmation, gated)

    def test_firecrawl_research_tools_are_preserved(self):
        """The rewrite must not silently drop the working research surface."""
        names = {s.name for s in BROWSER.specs()}
        for kept in ("web_research", "web_extract", "web_snapshot"):
            self.assertIn(kept, names)

    def test_status_tool_is_honest_even_without_a_driver(self):
        out = BROWSER._tool_status({})
        self.assertTrue(out["ok"])
        self.assertIn("available", out["data"])

    @unittest.skipUnless(BROWSER.available(), "chromium driver not installed")
    def test_real_navigation_reads_a_real_page(self):
        out = BROWSER.navigate("https://example.com")
        try:
            self.assertTrue(out.get("ok"), out.get("error"))
            self.assertEqual(out.get("status"), 200)
            self.assertIn("Example Domain", out.get("title", ""))
            self.assertIn("documentation", (out.get("text") or "").lower())
        finally:
            BROWSER.close()

    @unittest.skipUnless(BROWSER.available(), "chromium driver not installed")
    def test_dead_url_fails_honestly_instead_of_faking_success(self):
        out = BROWSER.navigate("http://127.0.0.1:9/definitely-not-here")
        try:
            self.assertFalse(out.get("ok"))
            self.assertTrue(out.get("error"))
        finally:
            BROWSER.close()


class PluginIntegrationTest(unittest.TestCase):
    registry = None

    @classmethod
    def setUpClass(cls):
        # One registry build for the whole class: build_default_registry() does
        # a real MCP discovery handshake, which is far too slow per-test.
        cls.registry = TOOLS.build_default_registry()
        result = EXT.register_plugin_tools(cls.registry)
        cls.assertEqual = unittest.TestCase.assertEqual
        if result["failed"]:
            raise AssertionError(result["errors"])

    def setUp(self):
        self.registry = self.__class__.registry

    def _names(self):
        return [t.name for t in self.registry.list()
                if t.name.startswith("plug_jarvis_modules_")]

    def test_jarvis_modules_plugin_is_discovered_and_enabled(self):
        plugins = {p["slug"]: p for p in EXT.plugins()}
        self.assertIn("jarvis-modules", plugins)
        self.assertTrue(plugins["jarvis-modules"]["enabled"])

    def test_all_plugin_tools_reach_the_real_registry(self):
        names = self._names()
        self.assertGreaterEqual(len(names), 18, names)
        for expected in ("plug_jarvis_modules_modules_status",
                         "plug_jarvis_modules_telemetry_snapshot",
                         "plug_jarvis_modules_scheduler_status",
                         "plug_jarvis_modules_ocr_status",
                         "plug_jarvis_modules_video_editor_status"):
            self.assertIn(expected, names)

    def test_read_only_tools_are_free_and_writes_are_gated(self):
        specs = {t.name: t for t in self.registry.list()
                 if t.name.startswith("plug_jarvis_modules_")}
        self.assertFalse(specs["plug_jarvis_modules_modules_status"].requires_confirmation)
        self.assertFalse(specs["plug_jarvis_modules_telemetry_snapshot"].requires_confirmation)
        self.assertTrue(specs["plug_jarvis_modules_video_cut_silence"].requires_confirmation)
        self.assertTrue(specs["plug_jarvis_modules_scheduler_set_timer"].requires_confirmation)

    def test_read_only_tool_executes_for_real(self):
        out = self.registry.execute("plug_jarvis_modules_modules_status", {})
        self.assertTrue(out["ok"], out)
        self.assertTrue(out.get("data", {}).get("total"))

    def test_gated_tool_is_refused_without_the_confirm_gate(self):
        out = self.registry.execute("plug_jarvis_modules_scheduler_set_timer",
                                    {"command": "noop", "seconds": 999})
        self.assertFalse(out["ok"], "a confirm-gated tool must not run unattended")

    def test_gated_tool_is_refused_when_the_user_declines(self):
        out = self.registry.execute("plug_jarvis_modules_scheduler_set_timer",
                                    {"command": "noop", "seconds": 999},
                                    confirm=lambda name, args: False)
        self.assertFalse(out["ok"])

    def test_permission_engine_can_deny_even_after_cortex_approval(self):
        saved = dict(PERMS.load())
        try:
            PERMS.save_overrides({"execute_commands": "deny"})
            out = self.registry.execute("plug_jarvis_modules_scheduler_set_timer",
                                        {"command": "noop", "seconds": 999},
                                        confirm=lambda name, args: True)
            self.assertFalse(out["ok"], "permission DENY must survive cortex approval")
        finally:
            PERMS.save_overrides(saved)

    def test_one_cortex_confirmation_also_satisfies_the_permission_ask(self):
        """The two gates must not double-prompt the user.

        A confirm-gated tool sits in an `ask` category, so before this was fixed
        the user answered "confirm" and was then blocked anyway.
        """
        self.assertEqual(PERMS.decision_for("execute_commands"), "ask")
        out = self.registry.execute("plug_jarvis_modules_scheduler_set_timer",
                                    {"command": "noop", "seconds": 999},
                                    confirm=lambda name, args: True)
        self.assertTrue(out["ok"], "one confirmation should satisfy both gates: %s" % out)

    def test_the_approval_is_single_use_and_tool_scoped(self):
        """An approval must not leak to a second call or a different tool."""
        PERMS.grant_approval("plug_jarvis_modules_scheduler_set_timer")
        self.assertTrue(PERMS.take_approval("plug_jarvis_modules_scheduler_set_timer"))
        # Consumed: the same tool cannot reuse it.
        self.assertFalse(PERMS.take_approval("plug_jarvis_modules_scheduler_set_timer"))
        # Scoped: another tool is unaffected.
        PERMS.grant_approval("plug_jarvis_modules_scheduler_set_timer")
        self.assertFalse(PERMS.take_approval("plug_jarvis_modules_scheduler_repeat"))

    def test_an_expired_approval_is_not_honoured(self):
        PERMS.grant_approval("plug_jarvis_modules_video_cut_silence")
        PERMS._APPROVAL_TTL_S = 0.0
        try:
            self.assertFalse(PERMS.take_approval("plug_jarvis_modules_video_cut_silence"))
        finally:
            PERMS._APPROVAL_TTL_S = 120.0

    def test_approval_does_not_leak_between_test_cases(self):
        self.assertFalse(PERMS.take_approval("plug_jarvis_modules_scheduler_set_timer"))


if __name__ == "__main__":
    unittest.main()


