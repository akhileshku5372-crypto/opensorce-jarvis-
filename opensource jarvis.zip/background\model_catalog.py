"""Model Catalog: ONE source of truth for every model across every API key.

JARVIS ships several free provider keys (Groq, OpenRouter, NVIDIA NIM, Google
Gemini x2, xKiro). Until now each hop hard-coded one or two model slugs, so most
of the free models a key actually grants were never used. This module fixes that
honestly and in one place:

  * It queries each provider's OWN /models endpoint and returns the REAL ids.
    Nothing here invents a model - every entry is a slug the provider itself
    just listed, so JARVIS never claims a model it cannot name.
  * Each entry is classified (chat / vision / stt / tts / embedding / guard /
    parse) from its id, so callers can pick the right pool.
  * The result is cached with a TTL so the Modules page and the brain chain can
    share one listing without re-hammering every provider on every request.

AGENTS.md constraint: this is READ-ONLY discovery + classification. It never
calls a model; it only names what exists. The brain chain (voice_engine.py) is
still the single place that actually runs a model, and it auto-switches across
`chat_models()` on any 4xx/5xx/timeout.
"""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path

import requests

# Load .env / .dev.vars exactly like content_writer / voice_engine: process env
# wins, then .env, then .dev.vars. The voice engine already loaded them before
# importing us, but the Modules page and the standalone runner do not, so we
# resolve the shared keys ourselves rather than reporting every key "missing".
ROOT = Path(__file__).resolve().parent.parent
try:
    from dotenv import dotenv_values as _dotenv_values

    for _f in (".env", ".dev.vars"):
        _p = os.path.join(ROOT, _f)
        if os.path.isfile(_p):
            for _k, _v in _dotenv_values(_p).items():
                if _v and not os.environ.get(_k):
                    os.environ[_k] = _v
except Exception:
    pass

_TTL = float(os.environ.get("JARVIS_MODEL_CATALOG_TTL", "600"))
_lock = threading.Lock()
_cache = {"at": 0.0, "data": None}

# A browser-ish UA; NVIDIA/xKiro's OpenAI-compatible fronts are picky about the
# default requests UA the same way voice_engine already learned.
_UA = os.environ.get(
    "JARVIS_HTTP_UA",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
)


def _key(*names):
    for n in names:
        v = str(os.environ.get(n) or "").strip()
        if v:
            return v
    return ""


def _get_json(url, headers, params=None, timeout=12):
    r = requests.get(url, headers=headers, params=params, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _classify(mid: str) -> str:
    """Bucket a model id so routing can pick chat vs vision vs stt vs tts.

    Order matters: an id like 'gemini-2.5-flash-preview-tts' is TTS even though
    it contains 'flash', so the audio buckets are tested before the chat
    default. Guard/safety/reward and non-text generators (music/image/video/
    transcribe/robotics) are bucketed OUT of the general chat pool so the
    brain's last-resort walk never wastes a turn on a model that can't answer
    plain text.
    """
    m = mid.lower()
    if "whisper" in m:
        return "stt"
    if "tts" in m or "orpheus" in m:
        return "tts"
    if "embed" in m:
        return "embedding"
    if ("guard" in m or "safeguard" in m or "safety" in m or "reward" in m
            or "prompt-guard" in m):
        return "guard"
    if "parse" in m:                       # nemotron-parse = document OCR
        return "parse"
    # Non-text generators: these need special params and 400 on a plain chat.
    if "lyria" in m or "music" in m:
        return "audio-gen"
    if "image" in m or "nano-banana" in m or "diffusion" in m or "video" in m:
        return "image-gen"
    if "transcribe" in m:
        return "stt"
    if "robotics" in m or "riva" in m:
        return "specialized"
    if "vision" in m or "omni" in m or "vila" in m or "-vl" in m or "vl-" in m:
        return "vision"
    return "chat"


# ── per-provider enumeration ────────────────────────────────────────────────
def _groq():
    k = _key("GROQ_API_KEY")
    if not k:
        return {"ready": False, "reason": "GROQ_API_KEY missing", "models": []}
    try:
        data = _get_json("https://api.groq.com/openai/v1/models",
                         {"Authorization": "Bearer " + k})
        ids = sorted(m["id"] for m in data.get("data", []) if m.get("id"))
        return {"ready": True, "models": [
            {"id": i, "kind": _classify(i), "free": True} for i in ids]}
    except Exception as exc:
        return {"ready": False, "reason": repr(exc), "models": []}


def _openrouter():
    k = _key("OPENROUTER_API_KEY")
    if not k:
        return {"ready": False, "reason": "OPENROUTER_API_KEY missing", "models": []}
    try:
        data = _get_json("https://openrouter.ai/api/v1/models",
                         {"Authorization": "Bearer " + k})
        out = []
        for m in data.get("data", []):
            mid = m.get("id")
            if not mid:
                continue
            pricing = m.get("pricing") or {}
            free = (str(pricing.get("prompt", "1")) in ("0", "0.0", "0.00")
                    or mid.endswith(":free"))
            out.append({"id": mid, "kind": _classify(mid), "free": bool(free)})
        return {"ready": True, "models": out}
    except Exception as exc:
        return {"ready": False, "reason": repr(exc), "models": []}


def _nvidia():
    k = _key("NVIDIA_API_KEY")
    if not k:
        return {"ready": False, "reason": "NVIDIA_API_KEY missing", "models": []}
    try:
        data = _get_json("https://integrate.api.nvidia.com/v1/models",
                         {"Authorization": "Bearer " + k, "Accept": "application/json"})
        ids = sorted(m["id"] for m in data.get("data", []) if m.get("id"))
        return {"ready": True, "models": [
            {"id": i, "kind": _classify(i), "free": True} for i in ids]}
    except Exception as exc:
        return {"ready": False, "reason": repr(exc), "models": []}


def _google(key_name):
    k = _key(key_name)
    if not k:
        return {"ready": False, "reason": key_name + " missing", "models": []}
    try:
        data = _get_json(
            "https://generativelanguage.googleapis.com/v1beta/models",
            {}, params={"key": k, "pageSize": 1000})
        out = []
        for m in data.get("models", []):
            name = (m.get("name") or "").split("/")[-1]
            methods = m.get("supportedGenerationMethods") or []
            if not name or "generateContent" not in methods:
                continue
            kind = _classify(name)
            if kind in ("embedding", "guard"):
                continue
            # JARVIS only spends the free lite tier on Google. Non-lite flash
            # and pro slugs stay listed but are never selected as free.
            out.append({"id": name, "kind": kind,
                        "free": "flash-lite" in name.lower()})
        return {"ready": True, "models": out}
    except Exception as exc:
        return {"ready": False, "reason": repr(exc), "models": []}


def _xkiro():
    k = _key("XKIRO_API_KEY")
    if not k:
        return {"ready": False, "reason": "XKIRO_API_KEY missing", "models": []}
    # xKiro is an aggregator; it exposes no reliable /models. Fall back to the
    # slugs JARVIS already configures for it - those are the models it grants.
    out = []
    for env in ("XKIRO_MODEL", "XKIRO_VISION_MODEL"):
        v = str(os.environ.get(env) or "").strip()
        if v:
            out.append({"id": v, "kind": _classify(v), "free": True})
    return {"ready": bool(out), "models": out,
            "reason": None if out else "no XKIRO model configured"}


# ── public API ──────────────────────────────────────────────────────────────
def catalog(force: bool = False, free_only: bool = False) -> dict:
    """Live catalog across every configured provider (TTL-cached).

    `free_only=True` keeps ONLY models a key grants for free: all of Groq /
    NVIDIA / Google / xKiro (free-tier keys), and OpenRouter's zero-price /
    `:free` slugs. Paid OpenRouter models (claude-opus, gpt-6-sol, ...) are
    dropped, because JARVIS only ever calls free endpoints.
    """
    with _lock:
        fresh = (not force and _cache["data"] is not None
                 and (time.time() - _cache["at"]) < _TTL)
        if fresh:
            data = _cache["data"]
        else:
            providers = {
                "groq": _groq(),
                "openrouter": _openrouter(),
                "nvidia": _nvidia(),
                "google": _google("GOOGLE_API_KEY"),
                "google_2": _google("GOOGLE_API_KEY_2"),
                "xkiro": _xkiro(),
            }
            counts, chat_pool, free_chat_pool, vision_pool, free_vision_pool = (
                {}, [], [], [], [])
            for name, info in providers.items():
                models = info.get("models", [])
                by_kind = {}
                for m in models:
                    by_kind[m["kind"]] = by_kind.get(m["kind"], 0) + 1
                    is_free = bool(m.get("free"))
                    if m["kind"] == "chat":
                        chat_pool.append((name, m["id"]))
                        if is_free:
                            free_chat_pool.append((name, m["id"]))
                    elif m["kind"] == "vision":
                        vision_pool.append((name, m["id"]))
                        if is_free:
                            free_vision_pool.append((name, m["id"]))
                counts[name] = {
                    "ready": info.get("ready", False),
                    "reason": info.get("reason"),
                    "total": len(models),
                    "by_kind": by_kind,
                }
            data = {
                "at": time.time(),
                "providers": providers,
                "counts": counts,
                "chat_pool": chat_pool,
                "vision_pool": vision_pool,
                "free_chat_pool": free_chat_pool,
                "free_vision_pool": free_vision_pool,
                "total_models": sum(len(p.get("models", [])) for p in providers.values()),
                "total_chat": len(chat_pool),
                "total_vision": len(vision_pool),
                "total_free_chat": len(free_chat_pool),
                "total_free_vision": len(free_vision_pool),
            }
            _cache["at"], _cache["data"] = time.time(), data

        if not free_only:
            return data
        # Build a filtered view (do not mutate the cached dict).
        prov = {}
        for name, info in data["providers"].items():
            prov[name] = {**info,
                          "models": [m for m in info.get("models", []) if m.get("free")]}
        total = sum(len(p["models"]) for p in prov.values())
        out = {**data, "providers": prov, "total_models": total,
               "total_chat": data["total_free_chat"],
               "total_vision": data["total_free_vision"],
               "chat_pool": data["free_chat_pool"],
               "vision_pool": data["free_vision_pool"]}
        return out


def chat_models(force: bool = False):
    return catalog(force)["chat_pool"]


def free_models(force: bool = False):
    """Every FREE model across all keys. JARVIS only ever calls these."""
    return catalog(force, free_only=True)


def free_chat_models(force: bool = False):
    """Every free text/chat model across all keys, provider order.

    The brain chain walks this on any error, so one dead model costs one hop,
    never the whole turn.
    """
    return catalog(force, free_only=True)["chat_pool"]


def free_vision_models(force: bool = False):
    return catalog(force, free_only=True)["vision_pool"]


def vision_models(force: bool = False):
    return catalog(force)["vision_pool"]


def summary(force: bool = False, free_only: bool = True) -> str:
    data = catalog(force, free_only=free_only)
    label = "FREE MODELS ACROSS ALL KEYS" if free_only else "ALL MODELS"
    lines = ["%s: %d  (chat %d / vision %d)"
             % (label, data["total_models"], data["total_chat"], data["total_vision"]), ""]
    for name, info in data["providers"].items():
        c = data["counts"][name]
        flag = "READY" if c["ready"] else ("DOWN: " + str(c["reason"]))
        n = len(info.get("models", []))
        lines.append("[%s] %s  free_total=%d" % (name.upper(), flag, n))
        for m in info.get("models", []):
            lines.append("    %-8s %s" % (m["kind"], m["id"]))
    return "\n".join(lines)



def counts(force: bool = False) -> dict:
    """Compact per-provider + per-kind counts (cheap, TTL-cached).

    This is what the Modules dashboard reads so a user can see 'kitne model
    hai' without the full id dump.
    """
    data = catalog(force)
    per_kind = {}
    per_provider = {}
    for name, info in data["providers"].items():
        per_provider[name] = {
            "ready": info.get("ready", False),
            "reason": info.get("reason"),
            "total": len(info.get("models", [])),
            "by_kind": data["counts"][name]["by_kind"],
        }
        for k, n in data["counts"][name]["by_kind"].items():
            per_kind[k] = per_kind.get(k, 0) + n
    return {
        "total_models": data["total_models"],
        "total_chat": data["total_chat"],
        "total_vision": data["total_vision"],
        "per_kind": per_kind,
        "per_provider": per_provider,
    }


if __name__ == "__main__":
    print(summary(force=True))

