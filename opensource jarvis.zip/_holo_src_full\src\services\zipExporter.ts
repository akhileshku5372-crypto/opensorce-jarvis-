/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';

export async function downloadProjectZip(onProgress?: (percent: number) => void): Promise<void> {
  const zip = new JSZip();

  // Root files
  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'jarvis-holographic-brain',
        version: '1.0.5',
        private: true,
        type: 'module',
        scripts: {
          dev: 'vite --port=3000 --host=0.0.0.0',
          build: 'vite build',
          preview: 'vite preview',
        },
        dependencies: {
          '@google/genai': '^2.4.0',
          '@tailwindcss/vite': '^4.3.3',
          '@types/three': '^0.186.0',
          '@vitejs/plugin-react': '^6.1.1',
          dotenv: '^17.2.3',
          express: '^4.21.2',
          jszip: '^3.10.1',
          'lucide-react': '^0.546.0',
          motion: '^12.23.24',
          react: '^19.0.1',
          'react-dom': '^19.0.1',
          tailwindcss: '^4.3.3',
          three: '^0.186.1',
          vite: '^8.3.0',
        },
        devDependencies: {
          '@types/node': '^22.14.0',
          '@types/react': '^19.3.0',
          '@types/react-dom': '^19.3.0',
          typescript: '^7.0.2',
        },
      },
      null,
      2
    )
  );

  zip.file(
    'README.md',
    `# JARVIS — Interactive 3D Holographic Neural Brain Explorer

A production-grade, interactive 3D holographic neural brain visualizer engineered for JARVIS.

## Features
- **3D WebGL / Three.js Holographic Brain**: Anatomical hemispheres, lobes, gyri/sulci convolutions, neural point clouds, dynamic synaptic firing pulses.
- **Full Orbit & Zoom Controls**: Mouse wheel zoom, click-drag 3D rotation, camera fit, reset, and explode view.
- **Real Architecture Mapping**: Connects Vision, Language, Memory, Planning, Audio, Tools, Coding, and Computer Use directly to JARVIS models and providers (.env).
- **HUD & Telemetry**: Live CPU/RAM/DISK/GPU gauges, real-time activity stream, and safe credential masking.
- **Audio Synthesizer**: Web Audio API sci-fi sound effects and audio-responsive pulses.

## Getting Started
\`\`\`bash
npm install
npm run dev
\`\`\`
`
  );

  zip.file(
    '.env.example',
    `# JARVIS Environment Configuration
JARVIS_GEMINI_MODEL=gemini-flash-latest
JARVIS_STT_LANGUAGE=auto
JARVIS_WHISPER_MODEL=base
JARVIS_WHISPER_COMPUTE=int8
GROQ_API_KEY=
GROQ_MODEL=openai/gpt-oss-120b
OPENROUTER_API_KEY=
OPENROUTER_MODEL=nex-agi/nex-n2.5-mini:free
GOOGLE_API_KEY=
NVIDIA_API_KEY=
NVIDIA_MODEL=meta/llama-3.1-70b-instruct
JARVIS_BRIDGE_HOST=127.0.0.1
JARVIS_BRIDGE_PORT=7778
JARVIS_STATE_PORT=7780
EDGE_TTS_PORT=7782
PORT=7777
JARVIS_DATA_ROOT=D:\\JARVIS_DATA
JARVIS_DATA_MAX_GB=10
`
  );

  onProgress?.(30);

  // Generate blob
  const content = await zip.generateAsync({ type: 'blob' }, (metadata) => {
    onProgress?.(30 + Math.floor(metadata.percent * 0.7));
  });

  // Trigger download
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'jarvis-holographic-brain.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
