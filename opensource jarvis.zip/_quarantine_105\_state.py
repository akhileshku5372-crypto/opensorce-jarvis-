# -*- coding: utf-8 -*-
"""_state.py — repo-wide inventory. No secrets printed."""
import os, subprocess, sys

ROOT = os.path.dirname(os.path.abspath(__file__))

def sh(cmd):
    return subprocess.run(['git', '-C', ROOT] + cmd, capture_output=True, text=True).stdout.strip()

print('=== git status ===')
print(sh(['status', '--short']) or '(clean)')
print('\n=== git log ===')
print(sh(['log', '--oneline', '-12']))
print('\n=== branch ===')
print(sh(['branch', '--show-current']) or '(none)')

print('\n=== .env / .dev.vars var inventory (names only; secret masked) ===')
for fn in ('.env', '.dev.vars'):
    p = os.path.join(ROOT, fn)
    if not os.path.exists(p):
        print(fn, ': MISSING')
        continue
    for i, line in enumerate(open(p, encoding='utf-8'), 1):
        line = line.rstrip('\n')
        if not line.strip() or line.strip().startswith('#'):
            continue
        if '=' not in line:
            print('%s:%d NONKVP %s' % (fn, i, line[:100]))
            continue
        k, v = line.split('=', 1)
        k, v = k.strip(), v.strip()
        if len(v) > 14:
            print('%s:%3d %-26s = %s...[%d]' % (fn, i, k, v[:12], len(v)))
        else:
            print('%s:%3d %-26s = %s' % (fn, i, k, v))

print('\n=== secret-ish occurrences in source (lines + file) ===')
for fn in sorted(os.listdir(ROOT)):
    p = os.path.join(ROOT, fn)
    if os.path.isdir(p):
        continue
    try:
        for i, line in enumerate(open(p, encoding='utf-8', errors='ignore'), 1):
            if any(s in line for s in ('gsk_', 'sk-or-', 'LIVEKIT_API_KEY', 'ELEVENLABS_API_KEY', 'MEM0_API_KEY', 'MEMORY_API_KEY', 'LIVEKIT_URL')):
                print('%s:%d %s' % (fn, i, line.strip()[:100]))
    except Exception:
        pass
