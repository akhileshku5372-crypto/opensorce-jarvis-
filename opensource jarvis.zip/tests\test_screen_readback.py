"""Live tests for background/screen_readback.py - the real on-screen text.

These open a real Notepad and type into it, because the whole point is that the
answer comes from the window and not from what JARVIS believes it sent. They are
the only tests here that touch the desktop.

Run: node run_py.cjs -m unittest discover -s tests -p test_screen_readback.py
"""
from __future__ import annotations

import subprocess
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))

import screen_readback as rb          # noqa: E402


def _close_notepads():
    import ctypes
    user32 = ctypes.windll.user32
    EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    victims = []

    def _cb(hwnd, _l):
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        if buf.value in ("Notepad", "MintNotepad"):
            victims.append(hwnd)
        return True

    user32.EnumWindows(EnumWindowsProc(_cb), 0)
    for hwnd in victims:
        user32.PostMessageW(hwnd, 0x0010, 0, 0)     # WM_CLOSE


def _open_notepad():
    subprocess.Popen(["notepad.exe"])
    time.sleep(3.0)


def _focus_notepad():
    """Put Notepad in the foreground, and verify it.

    These live tests read the FOREGROUND window, so the precondition has to be
    established rather than assumed: a fullscreen IDE on this machine steals focus
    within a second or two, which made these tests fail for a reason that had
    nothing to do with the code under test. Same attach-thread trick the WhatsApp
    driver uses, plus a wait loop that confirms the foreground really is Notepad.
    """
    import ctypes
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    target = []
    proc_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def _cb(hwnd, _l):
        cls = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, cls, 256)
        if cls.value in ("Notepad", "MintNotepad") and user32.IsWindowVisible(hwnd):
            target.append(hwnd)
        return True

    user32.EnumWindows(proc_type(_cb), 0)
    if not target:
        return False
    hwnd = target[0]
    fg = user32.GetForegroundWindow()
    current = kernel32.GetCurrentThreadId()
    target_thread = user32.GetWindowThreadProcessId(hwnd, None)
    fg_thread = user32.GetWindowThreadProcessId(fg, None)
    user32.AttachThreadInput(current, target_thread, True)
    if fg_thread and fg_thread != current:
        user32.AttachThreadInput(current, fg_thread, True)
    try:
        user32.ShowWindow(hwnd, 9)
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        user32.SetFocus(hwnd)
    finally:
        user32.AttachThreadInput(current, target_thread, False)
        if fg_thread and fg_thread != current:
            user32.AttachThreadInput(current, fg_thread, False)
    deadline = time.time() + 4.0
    while time.time() < deadline:
        if user32.GetForegroundWindow() == hwnd:
            return True
        time.sleep(0.2)
    return False


class PureLogicTest(unittest.TestCase):
    """No desktop needed: the title-echo guard is the honest part."""

    def test_a_window_title_is_not_mistaken_for_content(self):
        # An empty Notepad's Document exposes only "Untitled - Notepad". Reporting
        # that as "notepad me likha hai" would be a confident lie.
        self.assertTrue(rb._title_only("Untitled - Notepad", "Untitled - Notepad"))
        self.assertTrue(rb._title_only("*Untitled - Notepad", "Untitled - Notepad"))

    def test_real_content_is_not_treated_as_a_title_echo(self):
        self.assertFalse(rb._title_only(
            "Environment protects us from pollution", "*Environment - Notepad"))
        self.assertFalse(rb._title_only("hello", ""))

    def test_empty_text_is_never_content(self):
        self.assertTrue(rb._title_only("", "Notepad"))
        self.assertTrue(rb._title_only("   ", "Notepad"))

    def test_an_empty_window_says_so_without_apologising_twice(self):
        said = rb.spoken({"ok": False, "empty": True, "title": "Untitled - Notepad",
                          "error": "'Untitled - Notepad' abhi khaali hai - kuch "
                                   "likha nahi hai"})
        self.assertIn("khaali hai", said)
        self.assertNotIn("kuch nahi padha", said)

    def test_a_read_failure_is_reported_not_guessed(self):
        said = rb.spoken({"ok": False, "title": "X", "error": "app ne text expose "
                                                             "nahi kiya"})
        self.assertIn("kuch nahi bata raha", said)

    def test_long_text_is_truncated_and_says_so(self):
        said = rb.spoken({"ok": True, "title": "Note - Notepad",
                          "text": "x" * 500, "truncated": True})
        self.assertIn("lamba hai", said)
        self.assertLess(len(said), 400)


@unittest.skipUnless(sys.platform == "win32", "Windows-only: opens Notepad")
class LiveReadBackTest(unittest.TestCase):
    def setUp(self):
        _close_notepads()
        time.sleep(1.0)
        self.available, self.why = rb.available()
        if not self.available:
            self.skipTest(self.why)

    def tearDown(self):
        # Close AND wait: the next test opens its own Notepad, and a window that
        # is still closing steals focus, which makes the read-back read the wrong
        # window (measured: a stale Notepad made the "empty" test read old text).
        _close_notepads()
        deadline = time.time() + 5.0
        while time.time() < deadline:
            import ctypes
            buf = ctypes.create_unicode_buffer(256)
            gone = True
            EnumWindowsProc = ctypes.WINFUNCTYPE(
                ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

            def _cb(hwnd, _l):
                b = ctypes.create_unicode_buffer(256)
                ctypes.windll.user32.GetClassNameW(hwnd, b, 256)
                if b.value in ("Notepad", "MintNotepad"):
                    nonlocal gone
                    gone = False
                return True

            ctypes.windll.user32.EnumWindows(EnumWindowsProc(_cb), 0)
            if gone:
                break
            time.sleep(0.4)
        time.sleep(0.8)

    def test_real_typed_text_is_read_back_exactly(self):
        import pyautogui
        _open_notepad()
        self.assertTrue(_focus_notepad(), "Notepad did not take the foreground")
        sentence = "Environment protects us from pollution."
        pyautogui.typewrite(sentence, interval=0.01)
        time.sleep(1.5)
        self.assertTrue(_focus_notepad(), "Notepad lost the foreground after typing")
        out = rb.read_screen_text(allow_clipboard=False)
        self.assertTrue(out["ok"], out)
        self.assertIn("Environment", out["text"])
        self.assertIn("pollution", out["text"])
        self.assertIn("Environment", rb.spoken(out))

    def test_an_empty_notepad_reports_empty_not_the_title(self):
        _open_notepad()
        self.assertTrue(_focus_notepad(), "Notepad did not take the foreground")
        out = rb.read_screen_text(allow_clipboard=False)
        self.assertFalse(out["ok"])
        self.assertTrue(out.get("empty"), out)
        self.assertIn("khaali hai", rb.spoken(out))

    def test_the_answer_names_the_window_it_came_from(self):
        """The spoken answer always names its source window."""
        import pyautogui
        _open_notepad()
        self.assertTrue(_focus_notepad())
        pyautogui.typewrite("hello from jarvis", interval=0.01)
        time.sleep(1.2)
        self.assertTrue(_focus_notepad())
        out = rb.read_screen_text(allow_clipboard=False)
        self.assertIn("Notepad", str(out.get("title", "")), out)
        self.assertIn(str(out.get("title", ""))[:12], rb.spoken(out))

    def test_it_reads_whichever_window_is_actually_in_front(self):
        """Never claim Notepad while another window is focused."""
        _open_notepad()
        self.assertTrue(_focus_notepad())
        out = rb.read_screen_text(allow_clipboard=False)
        if out.get("ok"):
            self.assertIn(str(out.get("title", ""))[:8], rb.spoken(out))
        else:
            self.assertIn(out.get("error", "")[:20], rb.spoken(out))


if __name__ == "__main__":
    unittest.main()