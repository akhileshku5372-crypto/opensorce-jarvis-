'use strict'

/**
 * JARVIS Windows Bridge
 * A loopback-only, allowlisted adapter for desktop actions. It never accepts
 * arbitrary shell commands. Run on Windows with: npm run bridge
 */
const http = require('node:http')
const os = require('node:os')
const path = require('node:path')
const fs = require('node:fs')
const { spawn, execFile } = require('node:child_process')
const { promisify } = require('node:util')
const crypto = require('node:crypto')
const execFileAsync = promisify(execFile)

const HOST = process.env.JARVIS_BRIDGE_HOST || '127.0.0.1'
const PORT = Number(process.env.JARVIS_BRIDGE_PORT || 7778)
const isWindows = process.platform === 'win32'
const startedAt = Date.now()
const actionCache = new Map()
const launchStamps = []
const LAUNCH_WINDOW_MS = 60 * 1000
const LAUNCH_BURST_MAX = 4

// Apps launched by a direct, known executable (spawn with shell:false).
// Unknown app names are deliberately rejected: guessing through Windows search
// lets a bad STT transcript open Bing/Edge instead of the requested program.
const APP_ALLOWLIST = {
  notepad: 'notepad.exe', calculator: 'calc.exe', calc: 'calc.exe',
  // VS Code: spawn('Code.exe', detached) exits instantly (forwards to an
  // instance / dies detached), and cmd.exe /c code.cmd hidden also fails.
  // explorer.exe <exe> is the reliable Windows GUI-launch: it runs the target
  // in the user's interactive session, so the window actually appears.
  vscode: 'C:\\Users\\PRATEEK\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe',
  'vs code': 'C:\\Users\\PRATEEK\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe',
  code: 'C:\\Users\\PRATEEK\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe',
  'task manager': 'taskmgr.exe',
  explorer: 'explorer.exe', 'file explorer': 'explorer.exe', 'file manager': 'explorer.exe',
  'this pc': 'explorer.exe', thispc: 'explorer.exe', 'my computer': 'explorer.exe',
  chrome: 'chrome.exe', 'google chrome': 'chrome.exe',
  cmd: 'cmd.exe', 'command prompt': 'cmd.exe', powershell: 'powershell.exe', terminal: 'wt.exe',
  paint: 'mspaint.exe', 'snipping tool': 'SnippingTool.exe'
}

// GUI apps that must be handed to explorer.exe to actually show a window when
// spawned detached with stdio ignored. Everything else launches directly.
const EXPLORER_LAUNCH = new Set([
  'C:\\Users\\PRATEEK\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe'
])

// Apps opened through a fixed Windows URI (never derived from open user input).
const APP_URI_ALLOWLIST = {
  settings: 'ms-settings:', 'control panel': 'ms-settings:',
  camera: 'microsoft.windows.camera:', photos: 'ms-photos:', mail: 'mail:', clock: 'ms-clock:',
  whatsapp: 'whatsapp:'
}

const SITE_ALLOWLIST = {
  youtube: 'https://youtube.com', yt: 'https://youtube.com', google: 'https://google.com', gmail: 'https://mail.google.com',
  github: 'https://github.com', 'whatsapp web': 'https://web.whatsapp.com', spotify: 'https://open.spotify.com',
  reddit: 'https://reddit.com', netflix: 'https://netflix.com', linkedin: 'https://linkedin.com',
  'ユーチューブ': 'https://youtube.com', 'グーグル': 'https://google.com', 'ギットハブ': 'https://github.com'
}

// Multilingual app-name aliases -> canonical allowlist keys. Voice input can
// arrive in Hindi / Japanese / Urdu script; the allowlist itself stays English
// so a launch target is ALWAYS a known, fixed executable or URI.
const APP_ALIAS = {
  'नोटपैड': 'notepad', 'नोटपेड': 'notepad', 'ノートパッド': 'notepad', 'メモ帳': 'notepad',
  'कैलकुलेटर': 'calculator', 'कैलकुलेट': 'calculator', '電卓': 'calculator',
  'फाइल एक्सप्लोरर': 'file explorer', 'फ़ाइल एक्सप्लोरर': 'file explorer',
  'एक्सप्लोरर': 'file explorer', 'エクスプローラー': 'file explorer',
  'पेंट': 'paint', 'ペイント': 'paint',
  'टास्क मैनेजर': 'task manager', 'タスクマネージャー': 'task manager',
  'सेटिंग्स': 'settings', 'सेटिंग': 'settings', '設定': 'settings',
  'कमांड प्रॉम्प्ट': 'cmd', 'टर्मिनल': 'terminal', 'ターミナル': 'terminal',
  'यूट्यूब': 'youtube', 'ユーチューブ': 'youtube',
  'गूगल': 'google', 'グーグル': 'google',
  'वॉट्सऐप': 'whatsapp', 'जीमेल': 'gmail', 'जीमैल': 'gmail',
  'डाउनलोड्स': 'downloads', 'डाउनलोड': 'downloads',
  'डॉक्यूमेंट्स': 'documents', 'डॉक्यूमेंट': 'documents',
  'डेस्कटॉप': 'desktop', 'पिक्चर्स': 'pictures', 'म्यूजिक': 'music'
}

function canonAppName(name) {
  const key = String(name || '').trim()
  if (!key) return key
  return APP_ALIAS[key] || APP_ALIAS[key.toLowerCase()] || key
}

// Well-known user folders -> real path (safe allowlist of known locations).
const FOLDER_ALLOWLIST = {
  downloads: path.join(os.homedir(), 'Downloads'), desktop: path.join(os.homedir(), 'Desktop'),
  documents: path.join(os.homedir(), 'Documents'), pictures: path.join(os.homedir(), 'Pictures'),
  music: path.join(os.homedir(), 'Music'), videos: path.join(os.homedir(), 'Videos'),
  home: os.homedir()
}
const KNOWLEDGE_BASE_DIR = path.resolve(__dirname, '..', 'knowledge_base')
const CHROMA_DB_DIR = path.resolve(__dirname, '..', 'chroma_db')
const NOTEBOOKS_DIR = path.resolve(__dirname, '..', 'notebooks')

// Zero-failure boot: force-create runtime dirs synchronously at the entry point.
for (const runtimeDir of [KNOWLEDGE_BASE_DIR, CHROMA_DB_DIR, NOTEBOOKS_DIR]) {
  try { fs.mkdirSync(runtimeDir, { recursive: true }) } catch (e) { console.error(`[bridge] dir boot failed ${runtimeDir}:`, e.message) }
}

// RAG query runner: executes ingestion.py in a guarded subprocess (JSON-safe).
function runIngestionScript(args = ['--status', '--json']) {
  return new Promise((resolve) => {
    const pythonExe = process.platform === 'win32' ? 'python.exe' : 'python'
    const scriptPath = path.resolve(__dirname, '..', 'backend', 'services', 'ingestion.py')
    execFile(pythonExe, [scriptPath, ...args], { cwd: path.resolve(__dirname, '..'), timeout: 120000, maxBuffer: 32 * 1024 * 1024, windowsHide: true }, (error, stdout) => {
      if (error) return resolve({ ok: false, error: error.message })
      const raw = String(stdout || '').trim()
      try {
        const a = raw.indexOf('{')
        const b = raw.lastIndexOf('}')
        if (a !== -1 && b > a) return resolve({ ok: true, data: JSON.parse(raw.slice(a, b + 1)) })
        resolve({ ok: true, output: raw })
      } catch (e) { resolve({ ok: false, error: e.message }) }
    })
  })
}
let ksStatusCache = { at: 0, data: null }
async function getKamiSenseiStatus() {
  if (ksStatusCache.data && Date.now() - ksStatusCache.at < 30000) return ksStatusCache.data
  const result = await runIngestionScript(['--status', '--json'])
  if (result.ok && result.data) {
    ksStatusCache = { at: Date.now(), data: result.data }
    return result.data
  }
  return null
}

function listKnowledgeBaseFiles() {
  if (!fs.existsSync(KNOWLEDGE_BASE_DIR)) return []
  try {
    return fs.readdirSync(KNOWLEDGE_BASE_DIR)
      .filter((f) => /\.(pdf|txt|md|json)$/i.test(f))
      .map((name) => {
        try {
          const stat = fs.statSync(path.join(KNOWLEDGE_BASE_DIR, name))
          return { name, size_bytes: stat.size, size_display: stat.size < 1048576 ? `${(stat.size / 1024).toFixed(1)} KB` : `${(stat.size / 1048576).toFixed(1)} MB`, pages: 1, chunks: 0, indexed: true, modified_time: stat.mtimeMs, extension: path.extname(name).toLowerCase() }
        } catch { return null }
      })
      .filter(Boolean)
  } catch { return [] }
}

// Background ingestion watchdog: async, duplicate-guarded, never blocks HTTP.
let ksWatchRunning = false
let ksWatchQueued = false
function scheduleKsWatchRun() {
  ksStatusCache = { at: 0, data: null }
  if (ksWatchRunning) { ksWatchQueued = true; return }
  ksWatchRunning = true
  const pythonExe = process.platform === 'win32' ? 'python.exe' : 'python'
  const scriptPath = path.resolve(__dirname, '..', 'backend', 'services', 'ingestion.py')
  execFile(pythonExe, [scriptPath, '--ingest', '--json'], { cwd: path.resolve(__dirname, '..'), timeout: 120000, maxBuffer: 32 * 1024 * 1024, windowsHide: true }, (error, stdout) => {
    ksWatchRunning = false
    console.log('[bridge] background ingestion finished:', error ? String(error.message) : String(stdout || '').slice(0, 300))
    if (ksWatchQueued) { ksWatchQueued = false; scheduleKsWatchRun() }
  })
}

function isAllowedOrigin(origin) {
  return !origin || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin) || origin === process.env.JARVIS_UI_ORIGIN
}

// ── KamiSensei YouTube extraction (youtube_service.py runner) ───────────────
// Strict YouTube host/path allowlist: only watch / shorts / embed / live /
// youtu.be links ever reach the Python service. Never arbitrary URLs.
function isSafeYouTubeUrl(raw) {
  try {
    const parsed = new URL(String(raw || ''))
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false
    const host = (parsed.hostname || '').toLowerCase()
    if (host.endsWith('youtu.be')) return /^\/[A-Za-z0-9_-]{11}$/.test(parsed.pathname)
    if (!/^(www\.)?(youtube(-nocookie)?\.com|m\.youtube\.com|music\.youtube\.com)$/.test(host)) return false
    if (parsed.pathname === '/watch') return /^[A-Za-z0-9_-]{11}$/.test(parsed.searchParams.get('v') || '')
    return /^\/(shorts|embed|live)\/[A-Za-z0-9_-]{11}/.test(parsed.pathname)
  } catch { return false }
}

// Prefer the project virtualenv (has youtube-transcript-api + yt-dlp pinned),
// falling back to the system interpreter exactly like the ingestion runner.
function resolveProjectPython() {
  const venvPython = process.platform === 'win32'
    ? path.resolve(__dirname, '..', '.venv', 'Scripts', 'python.exe')
    : path.resolve(__dirname, '..', '.venv', 'bin', 'python')
  return fs.existsSync(venvPython) ? venvPython : (process.platform === 'win32' ? 'python.exe' : 'python')
}

function runYoutubeService(videoUrl) {
  return new Promise((resolve) => {
    const scriptPath = path.resolve(__dirname, '..', 'backend', 'services', 'youtube_service.py')
    execFile(resolveProjectPython(), [scriptPath, '--url', videoUrl, '--json'], { cwd: path.resolve(__dirname, '..'), timeout: 120000, maxBuffer: 64 * 1024 * 1024, windowsHide: true }, (error, stdout, stderr) => {
      const raw = String(stdout || '').trim()
      const a = raw.indexOf('{')
      const b = raw.lastIndexOf('}')
      if (a !== -1 && b > a) {
        try { return resolve({ ok: true, data: JSON.parse(raw.slice(a, b + 1)) }) } catch (e) { /* fall through */ }
      }
      resolve({ ok: false, error: (error && error.message) || (String(stderr || '').trim().slice(0, 500) || 'YouTube service produced no JSON output.') })
    })
  })
}

// ── KamiSensei JSON source store (backend/kamisensei_db.json) ───────────────
// Persists extracted YouTube transcripts so they survive frontend state resets.
// We invoke the tiny stdlib store module via the project Python interpreter.
const KS_JSON_STORE = path.resolve(__dirname, '..', 'backend', 'services', 'ks_json_store.py')

function runKsJsonStore(args = ['list']) {
  return new Promise((resolve) => {
    execFile(resolveProjectPython(), [KS_JSON_STORE, ...args], { cwd: path.resolve(__dirname, '..'), timeout: 30000, maxBuffer: 64 * 1024 * 1024, windowsHide: true }, (error, stdout) => {
      const raw = String(stdout || '').trim()
      const a = raw.indexOf('[')
      const brace = raw.indexOf('{')
      let start = -1
      if (a !== -1 && (brace === -1 || a <= brace)) start = a
      else if (brace !== -1) start = brace
      const end = Math.max(raw.lastIndexOf(']'), raw.lastIndexOf('}'))
      if (start !== -1 && end >= start) {
        try { return resolve({ ok: true, data: JSON.parse(raw.slice(start, end + 1)) }) } catch (e) { /* fall through */ }
      }
      resolve({ ok: false, error: (error && error.message) || 'JSON store produced no output.' })
    })
  })
}

function saveKsSource({ type = 'youtube', title = '', url = '', transcript = '', author = '' } = {}) {
  return runKsJsonStore([
    'add', '--type', String(type || 'youtube'),
    '--title', String(title || ''), '--url', String(url || ''),
    '--transcript', String(transcript || ''), '--author', String(author || ''),
  ])
}

function listKsSources() {
  return runKsJsonStore(['list'])
}


function json(res, status, payload, origin = '') {
  const allowedOrigin = origin && isAllowedOrigin(origin) ? origin : 'http://127.0.0.1:7777'
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Vary': 'Origin',
    'Cache-Control': 'no-store'
  })
  res.end(JSON.stringify(payload))
}

function launch(executable, args = [], options = {}) {
  if (!isWindows) return { ok: false, message: 'Windows action is unavailable on this operating system.' }
  try {
    const [exe, argv] = wrapCmdLauncher(executable, args)
    const hide = Boolean(options && options.windowsHide)
    const child = spawn(exe, argv, { detached: true, stdio: 'ignore', windowsHide: hide, shell: false })
    child.on('error', () => {}) // never crash the bridge on a missing executable
    child.unref()
    return { ok: true }
  } catch (error) {
    return { ok: false, message: error.message }
  }
}

// Windows cannot spawn a .cmd/.bat directly with shell:false (ENOENT). Route it
// through cmd.exe /c with a FIXED argv array - still shell:false, so no shell
// interpolation and no injection surface. Only the allowlisted launcher's own
// path reaches here; user text is never concatenated into a command string.
function wrapCmdLauncher(executable, args = []) {
  const exe = String(executable || '')
  if (/\.(cmd|bat)$/i.test(exe)) {
    return ['cmd.exe', ['/d', '/s', '/c', exe, ...args]]
  }
  if (EXPLORER_LAUNCH.has(exe)) {
    return ['explorer.exe', [exe, ...args]]
  }
  return [exe, args]
}

// Same as launch but reports whether the process actually started, so the caller
// can fall back to the app-name search when a known executable is not on PATH.
function launchAsync(executable, args = [], options = {}) {
  return new Promise((resolve) => {
    if (!isWindows) return resolve({ ok: false, message: 'Windows action is unavailable on this operating system.' })
    let settled = false
    const finish = (result) => { if (!settled) { settled = true; resolve(result) } }
    try {
      const [exe, argv] = wrapCmdLauncher(executable, args)
      const hide = Boolean(options && options.windowsHide)
      const child = spawn(exe, argv, { detached: true, stdio: 'ignore', windowsHide: hide, shell: false })
      child.unref()
      child.once('error', (error) => finish({ ok: false, message: error.message }))
      child.once('spawn', () => finish({ ok: true }))
      setTimeout(() => finish({ ok: false, message: 'Launch timed out.' }), 1500)
    } catch (error) {
      finish({ ok: false, message: error.message })
    }
  })
}

function powershell(script) {
  return launch('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', script], { windowsHide: true })
}

async function powershellOutput(script, timeout = 8000) {
  if (!isWindows) return { ok: false, message: 'Windows action is unavailable on this operating system.' }
  try {
    const { stdout } = await execFileAsync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', script], { windowsHide: true, timeout, maxBuffer: 512 * 1024 })
    return { ok: true, output: stdout.trim() }
  } catch (error) {
    return { ok: false, message: error.killed ? 'The Windows action timed out.' : error.message }
  }
}

function openUrl(url) {
  return launch('rundll32.exe', ['url.dll,FileProtocolHandler', url])
}

// Normalizes a spoken target like "the My Documents folder app" into an allowlist key.
function cleanTarget(raw) {
  const cleaned = String(raw || '')
    .replace(/^(?:the|my|a|an)\s+/i, '')
    .replace(/\s+(?:app|application|program)s?$/i, '')
    .replace(/\s+(?:folder|directory|file)s?$/i, '')
    .replace(/[.,;:]+$/i, '')
    .replace(/\s+(?:kholo?)$/i, '')
    .trim()
  // Multilingual names map onto the same allowlist keys.
  return canonAppName(cleaned)
}

// Spoken STT garbage (echo loops, multi-clause sentences) must never reach the
// expensive PowerShell Start-menu / file scans: those take 5-15s and always come
// back empty. A launch target is one short noun phrase, so anything with a
// command verb, a conjunction, or >4 words is rejected instantly.
// Devanagari/Hindi matras are combining marks, so the \p{L}\p{N} filter below
// drops them ('सा' -> 'स'). Normalize BOTH the set and the input with the same
// function, otherwise the Hindi junk entries can never match.
const normalizeJunkToken = (value) => String(value || '')
  .toLowerCase()
  .replace(/[^\p{L}\p{N}]/gu, '')

const JUNK_TARGET_WORDS = new Set([
  'and', 'or', 'then', 'please', 'again', 'also', 'now', 'just', 'but',
  'turn', 'off', 'on', 'up', 'down', 'back', 'stop', 'cancel', 'wait',
  'press', 'click', 'type', 'write', 'close', 'quit', 'exit', 'kill',
  'search', 'google', 'playing', 'pause', 'mute', 'unmute', 'volume',
  'brightness', 'screenshot', 'minimize', 'maximize', 'scroll', 'shutdown',
  'restart', 'sleep', 'lock',
  'सा', 'साब', 'साहब', 'र', 'फिर', 'करो', 'कर', 'बंद', 'चालू', 'खोलो'
].map(normalizeJunkToken))

function looksLikeJunkTarget(value) {
  const text = String(value || '').trim()
  if (!text) return true
  const words = text.split(/\s+/).filter(Boolean)
  if (words.length > 4) return true
  return words.some((word) => JUNK_TARGET_WORDS.has(normalizeJunkToken(word)))
}

function cpuUsage() {
  const cpus = os.cpus()
  let idle = 0
  let total = 0
  for (const cpu of cpus) {
    idle += cpu.times.idle
    total += Object.values(cpu.times).reduce((sum, value) => sum + value, 0)
  }
  return total ? Math.round((1 - idle / total) * 100) : 0
}

async function metrics() {
  const total = os.totalmem()
  const data = {
    cpu: cpuUsage(),
    ram: total ? Math.round((1 - os.freemem() / total) * 100) : 0,
    disk: null,
    battery: null,
    network: Object.values(os.networkInterfaces()).flat().some((item) => item && !item.internal),
    platform: `${os.platform()} ${os.release()}`,
    hostname: os.hostname(),
    activeWindow: ''
  }
  if (!isWindows) return data
  const script = `$d=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction SilentlyContinue; $b=Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1; $p=Get-Process | Where-Object {$_.MainWindowTitle} | Sort-Object CPU -Descending | Select-Object -First 1; [pscustomobject]@{disk=if($d.Size){[math]::Round((1-$d.FreeSpace/$d.Size)*100)}else{$null};battery=if($b){$b.EstimatedChargeRemaining}else{$null};activeWindow=if($p){$p.MainWindowTitle}else{''}} | ConvertTo-Json -Compress`
  const extra = await powershellOutput(script, 6000)
  if (extra.ok) {
    try {
      Object.assign(data, JSON.parse(extra.output || '{}'))
    } catch (error) {
      console.warn('[bridge] Could not parse Windows telemetry payload:', error.message)
    }
  }
  return data
}

function normalize(raw) {
  return String(raw || '').trim().toLowerCase()
    .replace(/^(?:hey\s+jarvis|(?:हे|हाय|ओके)?\s*(?:जार्विस|जारविस)|(?:ねえ|ヘイ|はい|ハイ|オーケー)?\s*(?:ジャービス|ジャーヴィス))[,.、।]?\s*/i, '')
    .replace(/\s+/g, ' ')
}

function wasRecentlyCompleted(command) {
  const previous = actionCache.get(command)
  return Boolean(previous && Date.now() - previous < 2500)
}

function rememberCompleted(command) {
  actionCache.set(command, Date.now())
  if (actionCache.size > 100) {
    for (const [key, value] of actionCache) if (Date.now() - value > 10000) actionCache.delete(key)
  }
}

// A bad STT stream can generate many slightly different "open YouTube" or
// search commands, which bypasses exact-command dedupe.  Keep this final guard
// in the bridge so it also protects the dashboard when the voice core is down.
function isLaunchIntent(command) {
  return /^(?:open|launch|start|run|kholo?)\b/i.test(command) ||
    /\b(?:youtube|web|google)\b.*\b(?:search|play)\b/i.test(command) ||
    /\b(?:search|play)\b.*\b(?:youtube|web|google)\b/i.test(command)
}

function allowLaunchAttempt(command) {
  const now = Date.now()
  while (launchStamps.length && now - launchStamps[0] > LAUNCH_WINDOW_MS) launchStamps.shift()
  if (launchStamps.length >= LAUNCH_BURST_MAX) return false
  launchStamps.push(now)
  return true
}

function stripHindiWake(cmd) {
  let s = String(cmd || '').replace(/[०१२३४५६७८९]/g, (d) => '०१२३४५६७८९'.indexOf(d))
  s = s.replace(/^(?:hey|hi|hello|हे|है|हाय|ओके)?[\s,.।]*(?:जार्विस|जारविस|जर्विस|जारू|जारो|जारों|इजार|विज)(\s+(?:विज|वॉइस))?[\s,.।]*(?:सा|साब|साहब|जी|भाई)?[\s,.।]*/i, '')
  s = s.replace(/^(?:इस|इसको)\s+/i, '')
  return s.trim()
}

// ── P0 power isolation ──────────────────────────────────────────────────────
// JARVIS never triggers OS power actions: shutdown / restart / reboot / log-off
// / sign-out / hibernate / OS-sleep / lock-workstation. Not the assistant, not
// the dashboard, not an AI suggestion — physical laptop power belongs to the
// user and Windows alone. Two exceptions stay working on purpose:
//   • "shutdown cancel" / "cancel shutdown" -> the RESCUE action that stops a
//     pending power action, so it can never be fatal.
//   • app-target verbs ("restart chrome", "log off teams") -> normal routes.
// The power handlers further down (shutdown.exe, SetSuspendState) stay in the
// file, but this gate keeps them unreachable for power verbs.
const POWER_VERB_PATTERN =
  'shut(?:\\s*down)?|shutdown|power\\s*off|poweroff|restart|re-?boot|reboot|' +
  'log\\s*off|logoff|sign\\s*out|signout|hibernate|suspend|standby|halt|' +
  'lock\\s*workstation'
const POWER_MACHINE_RE = new RegExp(
  `\\b(?:${POWER_VERB_PATTERN})\\b[\\s\\S]*?\\b(?:laptop|pc|computer|system|windows|machine|syst)\\b` +
  `|\\b(?:laptop|pc|computer|system|windows|machine|syst)\\b[\\s\\S]*?\\b(?:${POWER_VERB_PATTERN})\\b`,
  'i')
const POWER_STANDALONE_RE = new RegExp(
  `^(?:sleep|${POWER_VERB_PATTERN})(?:\\s+(?:now|please|plz|karo|kar\\s*do|kr\\s*do|theek|abhi|ab))?$`,
  'i')
// Hindi / roman machine-power phrasings the bridge used to execute directly
// ("system band karo" -> shutdown.exe, "pc sula do" -> suspend).
const POWER_MACHINE_HI_RE = new RegExp(
  `\\b(?:laptop|pc|computer|system|windows|machine|syst)\\b[\\s\\S]*?` +
  `(?:band|बंद|so\\s*jao|sula\\s*do|सो\\s*जाओ|सुला\\s*दो)`,
  'i')
const POWER_APP_TARGET_RE = /\b(?:chrome|browser|edge|firefox|brave|notepad|teams|outlook|word|excel|powerpoint|vscode|code|terminal|cmd|powershell|router|phone|tablet|app|tab|window|media|player|explorer)\b/i

// English machine-sleep phrasing ("put my laptop to sleep") — the noun+verb
// order makes it invisible to POWER_VERB_PATTERN, and the bridge would have
// been one route away from SetSuspendState.
const POWER_MACHINE_SLEEP_RE = new RegExp(
  `\\b(?:laptop|pc|computer|system|windows|machine|syst)\\b[\\s\\S]*?to\\s+sleep\\b`,
  'i')

// Explicit memory commands are never laptop/system actions - the same
// carve-out the voice core's power_guard applies (live report: a memory
// save request came back as the power-action deny). Intent prefix AND
// memory vocabulary must BOTH be present, so every real power command
// still hits the gates below unchanged.
function isMemoryRequest(text) {
  const intent = /^(?:remember\b|yaad\s+rakho|yaad\s+rakhiye|yaad\s+karo|note\s+it\s+down|memory\s+save\s+karo|save(?:\s+and\s+split)?(?:\s+this)?|split(?:\s+and\s+save)?|chunk(?:\s+by\s+chunk)?|(?:update|edit|change)\s+(?:this\s+|that\s+|the\s+|ye\s+)?memor|memory\s+update\s+karo|retrieve\s+memor|memory\s+retrieve\s+karo|memory\s+se\s+nikaalo|(?:delete|remove)\s+(?:this\s+|that\s+|the\s+)?memor|memory\s+delete\s+karo|forget\b|bhool\s+jao|bhul\s+jao|what\s+do\s+you\s+remember|explain\s+(?:what\s+you\s+remember|your\s+memor\w*|meri\s+memories)|kya\s+yaad|memories\s+(?:batao|sunao|dikhao)|meri\s+memories|memory\s+(?:list|dikhao))/i
  const vocab = /(memor\w*|rememb\w*|yaad|forget|bhool\s+jao|bhul\s+jao|long[\s-]*term)/i
  return intent.test(text) && vocab.test(text)
}

function denyPowerIntent(command) {
  const text = String(command || '').trim()
  if (!text) return false
  if (isMemoryRequest(text)) return false
  // Rescue action first: cancelling a shutdown is never a power action.
  if (/\bcancel\b/i.test(text) && /shut(?:down)?/i.test(text)) return false
  // App-target verbs belong to the normal allowlist routes.
  if (POWER_APP_TARGET_RE.test(text) &&
      !/\b(?:laptop|pc|computer|system|windows|machine)\b/i.test(text)) return false
  return POWER_STANDALONE_RE.test(text) || POWER_MACHINE_RE.test(text) ||
    POWER_MACHINE_HI_RE.test(text) || POWER_MACHINE_SLEEP_RE.test(text)
}

const POWER_DENY_MESSAGE =
  'Blocked on purpose: laptop power actions (shutdown, restart, log off, ' +
  'hibernate, OS sleep) are permanently disabled. Only you and Windows control ' +
  'laptop power — say "shutdown cancel" if a shutdown is already counting down.'

async function routeAction(rawCommand) {

  const command = stripHindiWake(normalize(rawCommand))
  if (!command) return { handled: false, message: 'A command is required.' }
  if (denyPowerIntent(command)) {
    return { handled: true, denied: true, powerDenied: true, message: POWER_DENY_MESSAGE }
  }
  if (wasRecentlyCompleted(command)) return { handled: true, duplicate: true, message: 'Duplicate command ignored.' }
  if (!isWindows) return { handled: false, message: 'Connect this bridge from a Windows device to execute OS actions.' }
  if (isLaunchIntent(command) && !allowLaunchAttempt(command)) {
    return { handled: false, message: 'Launch safety lock is active after several open/search commands. Wait one minute, then give one clear command.' }
  }

  const ytAnd = command.match(/youtube\s+and\s+(?:search(?:\s+for)?|play)\s+(.+)/i)?.[1] || command.match(/(?:search|play)\s+(.+?)\s+on\s+youtube/i)?.[1]
  if (ytAnd && ytAnd.trim()) {
    const r = openUrl(`https://www.youtube.com/results?search_query=${encodeURIComponent(ytAnd.trim())}`)
    return { handled: r.ok, message: r.ok ? `Searching YouTube for ${ytAnd.trim()}.` : r.message }
  }
  const youtube = command.match(/(?:open\s+)?youtube(?:\s+(?:and\s+)?search(?:\s+for)?|\s+(?:pe|par)\s+search(?:\s+karo)?|\s+kholo?\s+(?:aur\s+)?(?:search\s+)?)\s+(.+)|youtube\s+(?:pe|par)\s+(.+?)\s+search\s+karo|यूट्यूब\s*(?:पर|पे)\s*(.+?)\s*(?:सर्च|खोज)(?:\s*करो)?|ユーチューブで(.+?)(?:を検索|検索して)/i)
  if (youtube) {
    const query = youtube[1] || youtube[2] || youtube[3] || youtube[4]
    const result = openUrl(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`)
    return { handled: result.ok, message: result.ok ? `Searching YouTube for ${query}.` : result.message }
  }

  const web = command.match(/(?:search(?:\s+the)?\s+web\s*(?:for|par)?|google(?:\s+search)?(?:\s+for)?|web\s+(?:pe|par)\s+search\s+karo)\s+(.+)|web\s+(?:pe|par)\s+(.+?)\s+search\s+karo|(?:वेब|गूगल)\s*(?:पर|पे)\s*(.+?)\s*(?:सर्च|खोज)(?:\s*करो)?|(?:ウェブ|グーグル)で(.+?)(?:を検索|検索して)/i)
  if (web) {
    const query = web[1] || web[2] || web[3] || web[4]
    const result = openUrl(`https://www.google.com/search?q=${encodeURIComponent(query)}`)
    return { handled: result.ok, message: result.ok ? `Searching the web for ${query}.` : result.message }
  }

  const revTarget = command.match(/^(.+?)\s+(?:kholo?|khol|open|launch)(?:\s+karo)?$/i)?.[1] || command.match(/^(.+?)\s+(?:खोलो?|खोल)(?:\s+करो)?$/i)?.[1]
  if (revTarget) {
    const t = cleanTarget(revTarget)
    const HI_SITES = { 'यूट्यूब': 'youtube', 'गूगल': 'google', 'जीमेल': 'gmail', 'वॉट्सऐप': 'whatsapp' }
    const key = HI_SITES[t] || t
    if (SITE_ALLOWLIST[key]) {
      const r = openUrl(SITE_ALLOWLIST[key])
      return { handled: r.ok, message: r.ok ? `Opening ${key}.` : r.message }
    }
    if (APP_ALLOWLIST[key] && (await launchAsync(APP_ALLOWLIST[key])).ok) return { handled: true, message: `Opening ${key}.` }
    if (APP_URI_ALLOWLIST[key] && openUrl(APP_URI_ALLOWLIST[key]).ok) return { handled: true, message: `Opening ${key}.` }
    return { handled: false, message: `Unsupported local app: ${key}. It was not searched or typed into Windows.` }
  }
  const openTarget = command.match(/^(?:open|launch|start|kholo?|खोलो?)\s+(.+)$/i)?.[1] || command.match(/^(.+?)(?:を開いて|を開く)$/)?.[1]
  if (openTarget) {
    const target = cleanTarget(openTarget)

    // Known websites.
    if (SITE_ALLOWLIST[target]) {
      const result = openUrl(SITE_ALLOWLIST[target])
      return { handled: result.ok, message: result.ok ? `Opening ${target}.` : result.message }
    }

    // Known user folders (Downloads, Desktop, Documents, ...).
    if (FOLDER_ALLOWLIST[target]) {
      const result = launch('explorer.exe', [FOLDER_ALLOWLIST[target]])
      return { handled: result.ok, message: result.ok ? `Opening ${target} folder.` : result.message }
    }

    // Directly-launchable apps and fixed Windows-URI apps only.  There is no
    // Start-menu, file-name, browser-search, or keyboard-typing fallback.
    if (APP_ALLOWLIST[target] && (await launchAsync(APP_ALLOWLIST[target])).ok) {
      return { handled: true, message: `Opening ${target}.` }
    }
    if (APP_URI_ALLOWLIST[target] && openUrl(APP_URI_ALLOWLIST[target]).ok) {
      return { handled: true, message: `Opening ${target}.` }
    }

    // User-provided filesystem paths are never executed.  Add a named folder
    // to FOLDER_ALLOWLIST when a new safe shortcut is required.
    if (/^[a-zA-Z]:[\\/]|^[~.]?[\\/]/.test(target)) {
      return { handled: false, message: 'Direct filesystem paths are disabled. Use a named approved folder instead.' }
    }

    // A bare domain.
    if (/^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?::\d+)?(?:\/[^\s]*)?$/i.test(target)) {
      const result = openUrl(`https://${target}`)
      return { handled: result.ok, message: result.ok ? `Opening ${target}.` : result.message }
    }

    return { handled: false, message: `Unsupported local app: ${target}. It was not searched or typed into Windows.` }
  }

  const closeTarget = command.match(/^(?:close|quit|exit)\s+(.+)$/i)?.[1]
  if (closeTarget && APP_ALLOWLIST[canonAppName(closeTarget)]) {
    const processName = path.basename(APP_ALLOWLIST[canonAppName(closeTarget)], '.exe').replace(/[^a-z0-9_-]/gi, '')
    const result = powershell(`Stop-Process -Name '${processName}' -ErrorAction SilentlyContinue`)
    return { handled: result.ok, message: result.ok ? `Closing ${closeTarget}.` : result.message }
  }

  const fileQuery = command.match(/^(?:find|search for|file search)\s+(.+?)(?:\s+(?:file|files))?$/i)?.[1]
  if (fileQuery) {
    const cleanQuery = fileQuery.replace(/[^\p{L}\p{N} ._()-]/gu, '').trim().slice(0, 80)
    if (!cleanQuery) return { handled: false, message: 'A safe file name is required.' }
    const encoded = Buffer.from(cleanQuery, 'utf8').toString('base64')
    const script = `$q=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encoded}')); $roots=@([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('MyDocuments'),(Join-Path $HOME 'Downloads')); Get-ChildItem -Path $roots -File -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.Name -like ('*'+$q+'*')} | Select-Object -First 10 -ExpandProperty FullName | ConvertTo-Json -Compress`
    const result = await powershellOutput(script, 12000)
    if (!result.ok) return { handled: false, message: result.message }
    let files = []
    try {
      const parsed = JSON.parse(result.output || '[]')
      files = Array.isArray(parsed) ? parsed : parsed ? [parsed] : []
    } catch (error) {
      console.warn('[bridge] Could not parse file-search results:', error.message)
    }
    return { handled: true, message: files.length ? `I found ${files.length} matching files.` : `I could not find files matching ${cleanQuery}.`, data: { files } }
  }

  if (/^(?:take|capture) (?:a )?screenshot$/.test(command)) {
    const folder = path.join(os.homedir(), 'Pictures', 'JARVIS')
    fs.mkdirSync(folder, { recursive: true })
    const file = path.join(folder, `jarvis-${new Date().toISOString().replace(/[:.]/g, '-')}.png`)
    const escaped = file.replace(/'/g, "''")
    const script = `Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $i=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($i); $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size); $i.Save('${escaped}'); $g.Dispose(); $i.Dispose()`
    const result = powershell(script)
    return { handled: result.ok, message: result.ok ? 'Screenshot captured in Pictures, JARVIS.' : result.message }
  }

  if (/^(?:show|get|check) system info$|^(?:system info dikhao|システム情報(?:を)?(?:表示|教えて))$/.test(command)) {
    const data = await metrics()
    return { handled: true, message: `CPU ${data.cpu} percent. Memory ${data.ram} percent.${data.battery == null ? '' : ` Battery ${data.battery} percent.`}`, data }
  }
  if (/^(?:open )?(?:file )?explorer$/.test(command)) return { handled: launch('explorer.exe').ok, message: 'Opening File Explorer.' }
  if (/^(?:lock|lock my|lock the) (?:pc|computer|screen)$/.test(command)) return { handled: launch('rundll32.exe', ['user32.dll,LockWorkStation']).ok, message: 'Locking the computer.' }
  if (/^(?:volume up|increase volume)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]175)").ok, message: 'Volume increased.' }
  if (/^(?:volume down|decrease volume)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]174)").ok, message: 'Volume decreased.' }
  if (/^(?:mute|mute volume|unmute)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]173)").ok, message: 'Audio mute toggled.' }
  if (/^(?:switch window|next window|window switch karo|次のウィンドウ)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('%{TAB}')").ok, message: 'Switching window.' }
  if (/^(?:minimi[sz]e (?:the )?(?:current )?window|window minimi[sz]e karo|ウィンドウを最小化)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('% '); Start-Sleep -Milliseconds 100; [System.Windows.Forms.SendKeys]::SendWait('n')").ok, message: 'Minimizing the current window.' }
  if (/^(?:maximi[sz]e (?:the )?(?:current )?window|window maximi[sz]e karo|ウィンドウを最大化)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('% '); Start-Sleep -Milliseconds 100; [System.Windows.Forms.SendKeys]::SendWait('x')").ok, message: 'Maximizing the current window.' }
  if (/^(?:restore (?:the )?(?:current )?window|window restore karo|ウィンドウを元に戻す)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('% '); Start-Sleep -Milliseconds 100; [System.Windows.Forms.SendKeys]::SendWait('r')").ok, message: 'Restoring the current window.' }
  if (/^(?:show desktop|desktop dikhao|デスクトップを表示)$/.test(command)) return { handled: powershell("(New-Object -ComObject Shell.Application).ToggleDesktop()").ok, message: 'Showing the desktop.' }
  // ── Phase-1 expansion: brightness / media transport / power / windows / scroll ──
  if (/shutdown karo|shut ?down karo|(?:pc|computer|system).*?(?:बंद|band karo)/i.test(command)) {
    const r = await launchAsync('shutdown.exe', ['/s', '/t', '30'])
    return { handled: r.ok, message: r.ok ? 'Shutting down in 30 seconds. Say shutdown cancel to stop it.' : r.message }
  }
  const brightSet = command.match(/brightness[^\d]{0,12}(\d{1,3})/)?.[1] || command.match(/ब्राइटनेस[^\d]{0,12}(\d{1,3})/)?.[1]
  if (brightSet) {
    const level = Math.max(5, Math.min(100, Number(brightSet)))
    const result = await powershellOutput(`$m=Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods -ErrorAction SilentlyContinue | Select-Object -First 1; if($m){ $m.WmiSetBrightness(1, ${level}); 'SET' } else { 'NOSUPPORT' }`, 8000)
    if (result.ok && String(result.output || '').includes('SET')) return { handled: true, message: `Brightness set to ${level} percent.` }
    return { handled: true, message: result.ok ? 'Brightness control is not supported on this display. It works on most laptop screens.' : result.message }
  }
  if (/^(?:get|show|check) brightness$/.test(command)) {
    const result = await powershellOutput(`Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty CurrentBrightness`, 8000)
    const val = Number(String(result.output || '').trim())
    if (result.ok && Number.isFinite(val)) return { handled: true, message: `Brightness is ${val} percent.` }
    return { handled: true, message: 'Brightness level is unavailable on this display.' }
  }
  if (/^(play|pause|play pause|resume|play\/pause)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]179)").ok, message: 'Media play pause toggled.' }
  if (/^(next|next track|next song)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]176)").ok, message: 'Playing the next track.' }
  if (/^(previous|prev|previous track|previous song)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]177)").ok, message: 'Playing the previous track.' }
  if (/^(stop music|stop media|media stop)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait([char]178)").ok, message: 'Media stopped.' }
  if (/^(shutdown|shut down|power off)$/.test(command)) {
    const r = await launchAsync('shutdown.exe', ['/s', '/t', '30'])
    return { handled: r.ok, message: r.ok ? 'Shutting down in 30 seconds. Say shutdown cancel to stop it.' : r.message }
  }
  if (/^(shutdown cancel|cancel shutdown)$/.test(command)) {
    const r = await launchAsync('shutdown.exe', ['/a'])
    return { handled: r.ok, message: r.ok ? 'Shutdown cancelled.' : r.message }
  }
  if (/^(restart|reboot)$/.test(command)) {
    const r = await launchAsync('shutdown.exe', ['/r', '/t', '30'])
    return { handled: r.ok, message: r.ok ? 'Restarting in 30 seconds. Say shutdown cancel to stop it.' : r.message }
  }
  if (/^(sleep)$/.test(command)) return { handled: launch('rundll32.exe', ['powrprof.dll,SetSuspendState', '0', '1', '0']).ok, message: 'Putting the computer to sleep.' }
  if (/^(list windows|open windows|active windows)$/.test(command)) {
    const result = await powershellOutput(`Get-Process | Where-Object {$_.MainWindowTitle} | Select-Object -First 8 -ExpandProperty MainWindowTitle | ConvertTo-Json -Compress`, 8000)
    let titles = []
    try { const p = JSON.parse(result.output || '[]'); titles = (Array.isArray(p) ? p : [p]).map(String).filter(Boolean) } catch { /* keep empty */ }
    if (!result.ok) return { handled: false, message: result.message }
    return { handled: true, message: titles.length ? `Open windows: ${titles.slice(0, 5).join('; ')}.` : 'No open windows found.', data: { windows: titles } }
  }
  if (/^(active window|current window)$/.test(command)) {
    const result = await powershellOutput(`Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern System.IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern int GetWindowText(System.IntPtr h, System.Text.StringBuilder t, int n);' -Name FG -Namespace Win; $h=[Win.FG]::GetForegroundWindow(); $b=New-Object System.Text.StringBuilder 256; [Win.FG]::GetWindowText($h,$b,256)|Out-Null; $b.ToString()`, 8000)
    const title = String(result.output || '').trim()
    return { handled: true, message: title ? `Active window is ${title}.` : 'Could not read the active window.' }
  }
  if (/^scroll (up|down)$/.test(command)) {
    const up = command.endsWith('up')
    return { handled: powershell(`Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('${up ? '{UP 5}' : '{DOWN 5}'}')`).ok, message: up ? 'Scrolling up.' : 'Scrolling down.' }
  }
  if (/^(page up|page down)$/.test(command)) {
    const up = command === 'page up'
    return { handled: powershell(`Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('${up ? '{PGUP}' : '{PGDN}'}')`).ok, message: up ? 'Page up.' : 'Page down.' }
  }
  if (/^close (current|this) window$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('%{F4}')").ok, message: 'Closing the current window.' }
  if (/^(?:copy selection|copy this|isko copy karo|コピーして)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^c')").ok, message: 'Copied the current selection.' }
  if (/^(?:paste|paste here|yahan paste karo|貼り付けて)$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^v')").ok, message: 'Pasting from the clipboard.' }
  const clipboardText = command.match(/^(?:copy text|clipboard set|copy this text)\s+(.+)$/i)?.[1]
  if (clipboardText) {
    const encoded = Buffer.from(clipboardText.slice(0, 4000), 'utf8').toString('base64')
    const result = powershell(`$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encoded}')); Set-Clipboard -Value $t`)
    return { handled: result.ok, message: result.ok ? 'Text copied to the clipboard.' : result.message }
  }
  if (/^(?:browser )?back$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('%{LEFT}')").ok, message: 'Going back.' }
  if (/^(?:browser )?forward$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('%{RIGHT}')").ok, message: 'Going forward.' }
    if (/^(open )?new tab$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^t')").ok, message: 'Opening a new tab.' }
  if (/^(close )?(current )?tab$/.test(command)) return { handled: powershell("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^w')").ok, message: 'Closing the current tab.' }
  // Mouse control via text: "move mouse by -20 10", "move mouse to x 1920, y 1080",
  // "move mouse -20,10", "move mouse x -20, y +10". Signed offsets => relative.
  if (/^move\s+(?:the\s+)?mouse\b/i.test(command)) {
    const nums = command.match(/[+-]?\d+/g) || []
    if (nums.length >= 2) {
      const x = Number(nums[0]), y = Number(nums[1])
      const to = /\bto\b/i.test(command)
      if (to) {
        const r = await mouseCommand('move', [x, y])
        return { handled: r.ok, message: r.ok ? `Moved the cursor to ${r.x}, ${r.y}.` : `I could not move the cursor: ${r.error}` }
      }
      const r = await mouseCommand('relmove', [x, y])
      return { handled: r.ok, message: r.ok ? `Moved the cursor by ${x}, ${y}.` : `I could not move the cursor: ${r.error}` }
    }
    return { handled: false, message: 'Give me the distance, e.g. move mouse by 50 0 or move mouse to 1920 1080.' }
  }
  const findText = command.match(/^(?:find|search) (?:on (?:this )?page )?(.+)$/i)?.[1]
  if (findText && findText.length <= 120) {
    const encoded = Buffer.from(findText, 'utf8').toString('base64')
    const result = powershell(`Add-Type -AssemblyName System.Windows.Forms; $t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encoded}')); [System.Windows.Forms.SendKeys]::SendWait('^f'); Start-Sleep -Milliseconds 120; [System.Windows.Forms.SendKeys]::SendWait($t)`)
    return { handled: result.ok, message: result.ok ? `Finding ${findText} on this page.` : result.message }
  }

  return { handled: false, message: 'This action is not in the safe local allowlist.' }
}

// ── Persistent mouse-input worker (gesture control) ──────────────────
// One long-lived PowerShell process consumes `<seq> <command> ...` lines and
// injects real Windows cursor movement and buttons.
//
// The previous version joined the script with '; '. That produced
// `switch ($p[0]) {;  'move' {...}` and PowerShell refused to parse the whole
// script, so the worker died on start-up: the bridge then reported
// `{ok:true, message:'Mouse move.'}` for every request while the cursor never
// moved. Empty failures like that are worse than errors, so now:
//   * the script is built line by line and is syntax-checked by
//     tests/test_bridge_mouse.cjs with PowerShell's own parser;
//   * the worker announces `ready` on stdout and every command is answered
//     with `<seq> ok|err ...`, and the bridge awaits that answer;
//   * the worker's stderr is kept as the honest reason shown in diagnostics.
const MOUSE_ACTIONS = new Set(['move', 'relmove', 'lclick', 'rclick', 'ldown', 'lup', 'scroll', 'hscroll', 'pos', 'ping', 'bounds'])
const MOUSE_ACK_TIMEOUT = 1200
const MOUSE_QUEUE_LIMIT = 24
let mouseWorker = null
let mouseWorkerReady = false
let mouseWorkerError = ''
let mouseSeq = 0
const mousePending = new Map()

function mouseWorkerScript() {
  return [
    '$ErrorActionPreference = "Continue"',
    'Add-Type -AssemblyName System.Windows.Forms',
    "Add-Type -MemberDefinition '[DllImport(\"user32.dll\")] public static extern void mouse_event(uint f, uint dx, uint dy, int d, UIntPtr e);' -Name U -Namespace W",
    'function Invoke-JarvisMouse([string[]]$p) {',
    '  $cmd = $p[1]',
    "  if ($cmd -eq 'move') { [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point([int]$p[2], [int]$p[3]); $c = [System.Windows.Forms.Cursor]::Position; return ('ok ' + $c.X + ' ' + $c.Y) }",
    "  if ($cmd -eq 'relmove') { [W.U]::mouse_event(0x0001, [int]$p[2], [int]$p[3], 0, [UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'lclick') { [W.U]::mouse_event(2,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 40; [W.U]::mouse_event(4,0,0,0,[UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'rclick') { [W.U]::mouse_event(8,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 40; [W.U]::mouse_event(16,0,0,0,[UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'ldown') { [W.U]::mouse_event(2,0,0,0,[UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'lup') { [W.U]::mouse_event(4,0,0,0,[UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'scroll') { [W.U]::mouse_event(0x0800,0,0,[int]$p[2],[UIntPtr]::Zero); return 'ok' }",
    // 0x1000 is MOUSEEVENTF_HWHEEL. The old 0x0100 was MOUSEEVENTF_XUP and
    // would have injected a phantom extra-mouse button instead of scrolling.
    "  if ($cmd -eq 'hscroll') { [W.U]::mouse_event(0x1000,0,0,[int]$p[2],[UIntPtr]::Zero); return 'ok' }",
    "  if ($cmd -eq 'pos') { $c = [System.Windows.Forms.Cursor]::Position; return ('pos ' + $c.X + ' ' + $c.Y) }",
    "  if ($cmd -eq 'bounds') { $v = [System.Windows.Forms.SystemInformation]::VirtualScreen; return ('bounds ' + $v.Left + ' ' + $v.Top + ' ' + $v.Width + ' ' + $v.Height) }",
    "  if ($cmd -eq 'ping') { return 'pong' }",
    "  return ('err unknown ' + $cmd)",
    '}',
    '[Console]::Out.WriteLine("ready")',
    'while ($true) {',
    '  $line = [Console]::In.ReadLine()',
    '  if ($null -eq $line) { break }',
    '  $p = $line.Trim().Split(" ")',
    '  $seq = $p[0]',
    '  $out = "err empty"',
    '  try { $out = Invoke-JarvisMouse $p } catch { $out = ("err " + $_.Exception.Message) }',
    '  [Console]::Out.WriteLine(($seq + " " + $out))',
    '}',
    ''
  ].join('\n')
}

function failPendingMouse(reason) {
  for (const [seq, pending] of mousePending) {
    clearTimeout(pending.timer)
    mousePending.delete(seq)
    pending.resolve('err ' + reason)
  }
}

function getMouseWorker() {
  if (!isWindows) return null
  if (mouseWorker && !mouseWorker.killed && mouseWorkerReady) return mouseWorker
  if (mouseWorker && !mouseWorker.killed) return mouseWorker // still starting up
  try {
    mouseWorkerReady = false
    mouseWorkerError = ''
    mouseWorker = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', mouseWorkerScript()], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
    let buffer = ''
    mouseWorker.stdout.setEncoding('utf8')
    mouseWorker.stdout.on('data', (chunk) => {
      buffer += chunk
      let index = buffer.indexOf('\n')
      while (index >= 0) {
        const line = buffer.slice(0, index).trim()
        buffer = buffer.slice(index + 1)
        if (line === 'ready') mouseWorkerReady = true
        else if (line) {
          const space = line.indexOf(' ')
          const seq = Number(space === -1 ? line : line.slice(0, space))
          const pending = mousePending.get(seq)
          if (pending) {
            clearTimeout(pending.timer)
            mousePending.delete(seq)
            pending.resolve(space === -1 ? 'ok' : line.slice(space + 1))
          }
        }
        index = buffer.indexOf('\n')
      }
    })
    mouseWorker.stderr.setEncoding('utf8')
    mouseWorker.stderr.on('data', (chunk) => { mouseWorkerError = String(chunk).trim().split('\n')[0].slice(0, 300) })
    const drop = () => {
      if (mouseWorker) failPendingMouse(mouseWorkerError || 'the mouse worker stopped')
      mouseWorker = null
      mouseWorkerReady = false
    }
    mouseWorker.on('exit', drop)
    mouseWorker.on('error', (err) => { mouseWorkerError = String(err && err.message || 'spawn failed').slice(0, 300); drop() })
    mouseWorker.stdin.on('error', drop)
    return mouseWorker
  } catch (error) {
    mouseWorkerError = String(error && error.message || 'spawn failed').slice(0, 300)
    mouseWorker = null
    mouseWorkerReady = false
    return null
  }
}

// Every command is written to the worker and awaited. `move`/`relmove`/`scroll`
// answer with the cursor position they actually reached, which is the proof the
// dashboard needs: a request that never reached Windows is reported as failed.
function mouseCommand(action, args = []) {
  if (!MOUSE_ACTIONS.has(action)) return Promise.resolve({ ok: false, error: 'Unknown mouse action.' })
  if (!isWindows) return Promise.resolve({ ok: false, error: 'Windows mouse control works on Windows only.' })
  const worker = getMouseWorker()
  if (!worker) return Promise.resolve({ ok: false, error: mouseWorkerError || 'the mouse worker could not start' })
  if (mousePending.size > MOUSE_QUEUE_LIMIT) return Promise.resolve({ ok: false, error: 'the mouse worker is behind; command dropped' })
  const seq = ++mouseSeq
  const line = [seq, action, ...args.map((value) => Math.round(Number(value) || 0))].join(' ')
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      mousePending.delete(seq)
      resolve('err the mouse worker did not answer in ' + MOUSE_ACK_TIMEOUT + ' ms')
    }, MOUSE_ACK_TIMEOUT)
    mousePending.set(seq, { resolve, timer })
    try {
      worker.stdin.write(line + '\n')
    } catch (error) {
      clearTimeout(timer)
      mousePending.delete(seq)
      resolve('err ' + String(error && error.message || 'write failed'))
    }
  }).then((payload) => {
    const text = String(payload || '')
    if (text === 'pong') return { ok: true, ready: true }
    if (text.startsWith('pos ')) {
      const [x, y] = text.slice(4).split(' ').map(Number)
      return { ok: true, x, y }
    }
    if (text.startsWith('bounds ')) {
      const [left, top, width, height] = text.slice(7).split(' ').map(Number)
      return { ok: true, desktop: { left, top, width, height } }
    }
    if (text.startsWith('ok')) {
      const parts = text.slice(2).trim().split(' ').map(Number)
      if (parts.length === 2 && Number.isFinite(parts[0]) && Number.isFinite(parts[1])) return { ok: true, x: parts[0], y: parts[1] }
      return { ok: true }
    }
    return { ok: false, error: text.replace(/^err\s*/, '') || 'the mouse worker refused the command' }
  })
}

// One cached virtual-screen query: the dashboard scales hand coordinates from
// its own CSS pixels into this coordinate space, and diagnostics show it.
let desktopCache = { at: 0, value: null }
async function desktopBounds() {
  if (desktopCache.value && Date.now() - desktopCache.at < 8000) return desktopCache.value
  const result = await mouseCommand('bounds')
  if (result.ok && result.desktop) desktopCache = { at: Date.now(), value: result.desktop }
  return desktopCache.value
}

async function mouseState() {
  let ready = false
  let error = mouseWorkerError
  if (isWindows) {
    const probe = await mouseCommand('ping')
    ready = Boolean(probe.ok)
    if (!ready && probe.error && !error) error = String(probe.error)
  } else error = 'Windows only'
  return { ready, error: String(error || '').slice(0, 300), supported: isWindows }
}

// ── Semantic UI Automation (peace-sign activation + window control) ──
// The dashboard asks for exactly these allowlisted operations. The Python
// module resolves the window, refuses password fields and destructive control
// names, and never receives a command string to execute.
const UI_OPS = new Set(['status', 'snapshot', 'activate', 'windows', 'window'])
const UI_WINDOW_ACTIONS = new Set(['focus', 'minimize', 'maximize', 'restore', 'move'])
function runUiSurface(payload) {
  return new Promise((resolve) => {
    const scriptPath = path.resolve(__dirname, '..', 'background', 'ui_surface.py')
    const args = [scriptPath, '--json', '--op', String(payload.op)]
    if (payload.op === 'activate') args.push('--x', String(payload.x), '--y', String(payload.y))
    if (payload.op === 'window') {
      args.push('--action', String(payload.action), '--handle', String(payload.handle))
      if (payload.action === 'move') {
        if (payload.fraction) args.push('--fraction')
        args.push('--x', String(payload.x), '--y', String(payload.y), '--width', String(payload.width), '--height', String(payload.height))
      }
    }
    execFile(resolveProjectPython(), args, {
      cwd: path.resolve(__dirname, '..'), timeout: 20000, maxBuffer: 2 * 1024 * 1024, windowsHide: true
    }, (error, stdout, stderr) => {
      const raw = String(stdout || '').trim()
      const a = raw.indexOf('{')
      const b = raw.lastIndexOf('}')
      if (a !== -1 && b > a) {
        try { return resolve(JSON.parse(raw.slice(a, b + 1))) } catch (e) { /* fall through */ }
      }
      // Report the last real stderr line instead of Node's whole command dump.
      const detail = String(stderr || '').trim().split('\n').map((line) => line.trim()).filter(Boolean).pop() || (error && error.message) || ''
      resolve({ ok: false, error: detail.slice(0, 300) || 'UI Automation produced no JSON output.' })
    })
  })
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || ''
  if (!isAllowedOrigin(origin)) return json(res, 403, { ok: false, message: 'Origin denied.' })
  if (req.method === 'OPTIONS') return json(res, 204, {}, origin)
  if (req.method === 'GET' && req.url === '/api/status') {
    const [desktop, mouse] = await Promise.all([desktopBounds(), mouseState()])
    return json(res, 200, {
      ok: true,
      service: 'JARVIS Windows Bridge',
      version: '0.10.0',
      platformSupported: isWindows,
      uptime: Math.round((Date.now() - startedAt) / 1000),
      desktop,
      // Real readiness of the input worker, not a guess: the dashboard shows
      // "mouse input: ready" only after the worker answered a live ping.
      mouse,
      metrics: await metrics()
    }, origin)
  }
  if (req.method === 'POST' && req.url === '/api/action') {
    let body = ''
    req.on('data', (chunk) => {
      body += chunk
      if (body.length > 32768) req.destroy()
    })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const command = normalize(payload.command)
        const result = await routeAction(payload.command)
        // Cache only after a successful action. The dashboard can therefore fall
        // back to the bridge after an offline core attempt without losing the command.
        if (result.handled && !result.duplicate) rememberCompleted(command)
        json(res, result.handled ? 200 : 422, result, origin)
      } catch (error) {
        json(res, 400, { handled: false, message: 'Invalid action request.', error: error.message }, origin)
      }
    })
    return
  }
  if (req.method === 'POST' && req.url === '/api/mouse') {
    let body = ''
    req.on('data', (chunk) => {
      body += chunk
      if (body.length > 4096) req.destroy()
    })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const action = String(payload.action || '').toLowerCase()
        const args = []
        if (action === 'move') args.push(payload.x, payload.y)
        if (action === 'relmove') args.push(payload.x, payload.y)
        if (action === 'scroll' || action === 'hscroll') args.push(payload.delta)
        const result = await mouseCommand(action, args)
        json(res, result.ok ? 200 : 502, result, origin)
      } catch {
        json(res, 400, { ok: false, error: 'Invalid mouse request.' }, origin)
      }
    })
    return
  }
  if (req.method === 'POST' && req.url === '/api/ui') {
    let body = ''
    req.on('data', (chunk) => {
      body += chunk
      if (body.length > 4096) req.destroy()
    })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const op = String(payload.op || '')
        if (!UI_OPS.has(op)) return json(res, 400, { ok: false, error: 'Unsupported UI operation.' }, origin)
        const request = { op }
        if (op === 'activate') {
          const x = Number(payload.x)
          const y = Number(payload.y)
          if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x > 100000 || y > 100000) {
            return json(res, 400, { ok: false, error: 'Screen coordinates are invalid.' }, origin)
          }
          request.x = Math.round(x)
          request.y = Math.round(y)
        }
        if (op === 'window') {
          const action = String(payload.action || '')
          const handle = Number(payload.handle)
          if (!UI_WINDOW_ACTIONS.has(action)) return json(res, 400, { ok: false, error: 'Unsupported window action.' }, origin)
          if (!Number.isFinite(handle) || handle <= 0) return json(res, 400, { ok: false, error: 'A window handle is required.' }, origin)
          request.action = action
          request.handle = Math.round(handle)
          if (action === 'move') {
            // Two shapes are accepted:
            //   rect: {x,y,width,height} as 0..1 of the desktop (preferred), and
            //   absolute x/y/width/height pixels (legacy callers).
            // The fraction is resolved by the UIA process in its own pixel space,
            // because this bridge's pointer space is virtualised CSS pixels while
            // window rectangles are physical on a scaled display.
            const fractional = Boolean(payload.rect && typeof payload.rect === 'object')
            const source = fractional ? payload.rect : payload
            const x = Number(source.x)
            const y = Number(source.y)
            const width = Number(source.width)
            const height = Number(source.height)
            const inRange = (value, low, high) => Number.isFinite(value) && value >= low && value <= high
            if (fractional) {
              if (!inRange(x, 0, 1) || !inRange(y, 0, 1) || !inRange(width, 0.05, 1) || !inRange(height, 0.05, 1)) {
                return json(res, 400, { ok: false, error: 'The requested window fraction is out of range.' }, origin)
              }
              request.fraction = true
              request.x = x
              request.y = y
              request.width = width
              request.height = height
            } else {
              if (!inRange(x, -32000, 32000) || !inRange(y, -32000, 32000) || !inRange(width, 200, 20000) || !inRange(height, 120, 20000)) {
                return json(res, 400, { ok: false, error: 'The requested window rectangle is out of range.' }, origin)
              }
              request.x = Math.round(x)
              request.y = Math.round(y)
              request.width = Math.round(width)
              request.height = Math.round(height)
            }
          }
        }
        const result = await runUiSurface(request)
        json(res, 200, result, origin)
      } catch {
        json(res, 400, { ok: false, error: 'Invalid UI request.' }, origin)
      }
    })
    return
  }
  if (req.method === 'POST' && req.url === '/api/kamisensei/upload') {
    let body = ''
    req.on('data', (chunk) => {
      body += chunk
      if (body.length > 120 * 1024 * 1024) req.destroy()
    })
    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}')
        // Local path / folder intake: DIRECT fs copy (no Python, no hang).
        if (payload.path || (Array.isArray(payload.paths) && payload.paths.length)) {
          const paths = payload.paths && payload.paths.length ? payload.paths : [payload.path]
          const cleanPaths = paths.map((x) => String(x).trim()).filter(Boolean)
          if (!cleanPaths.length) return json(res, 400, { ok: false, message: 'Path is required.' }, origin)
          const copied = []
          for (const srcPath of cleanPaths) {
            try {
              const st = fs.statSync(srcPath)
              if (st.isFile()) {
                const base = path.basename(srcPath)
                if (/\.(pdf|txt|md|json)$/i.test(base)) {
                  fs.copyFileSync(srcPath, path.join(KNOWLEDGE_BASE_DIR, base))
                  copied.push(base)
                }
              } else if (st.isDirectory()) {
                for (const entry of fs.readdirSync(srcPath)) {
                  if (/\.(pdf|txt|md|json)$/i.test(entry)) {
                    fs.copyFileSync(path.join(srcPath, entry), path.join(KNOWLEDGE_BASE_DIR, entry))
                    copied.push(entry)
                  }
                }
              }
            } catch (e) { console.error('[bridge] path copy failed:', srcPath, e.message) }
          }
          if (copied.length) scheduleKsWatchRun()
          return json(res, 200, { ok: true, copied, ingestion: { status: copied.length ? 'queued' : 'skipped', mode: 'background' }, message: 'Imported ' + copied.length + ' source(s) from the given path(s).' }, origin)
        }
        // Browser upload: base64 -> DIRECT fs disk write (zero subprocess, zero hang).
        const rawName = String(payload.filename || 'japanese_material.pdf').replace(/[^\w.-]/g, '_')
        const extension = path.extname(rawName).toLowerCase()
        if (!['.pdf', '.txt', '.md', '.json'].includes(extension)) {
          return json(res, 415, { ok: false, message: 'Unsupported source type. Use PDF, TXT, MD, or JSON.' }, origin)
        }
        const base64Data = payload.data || ''
        if (!base64Data) return json(res, 400, { ok: false, message: 'File data is required.' }, origin)
        const b64payload = base64Data.includes('base64,') ? base64Data.slice(base64Data.indexOf('base64,') + 7) : base64Data
        const fileBuf = Buffer.from(b64payload, 'base64')
        if (!fileBuf.length || fileBuf.length > 50 * 1024 * 1024) {
          return json(res, 413, { ok: false, message: 'Source must be between 1 byte and 50 MB.' }, origin)
        }
        if (extension === '.pdf' && fileBuf.subarray(0, 5).toString('ascii') !== '%PDF-') {
          return json(res, 415, { ok: false, message: 'The uploaded file does not contain a valid PDF signature.' }, origin)
        }
        if (extension === '.json') {
          try { JSON.parse(fileBuf.toString('utf8')) } catch (error) {
            return json(res, 415, { ok: false, message: 'The uploaded JSON file is malformed.' }, origin)
          }
        }
        fs.writeFileSync(path.join(KNOWLEDGE_BASE_DIR, rawName), fileBuf)
        scheduleKsWatchRun()
        return json(res, 200, {
          ok: true,
          filename: rawName,
          size_bytes: fileBuf.length,
          ingestion: { status: 'queued', mode: 'background' },
          message: 'Saved ' + rawName + ' to knowledge_base. Indexing runs in background.'
        }, origin)
      } catch (err) {
        return json(res, 500, { ok: false, message: 'Upload failed.', error: err.message }, origin)
      }
    })
    return
  }
  if (req.method === 'POST' && req.url === '/api/kamisensei/ingest') {
    scheduleKsWatchRun()
    return json(res, 200, { ok: true, status: 'queued', message: 'Background ingestion scheduled.' }, origin)
  }

  if (req.method === 'POST' && (req.url === '/api/kamisensei/query_db' || req.url === '/api/kamisensai/query_db')) {
    let body = ''
    req.on('data', (chunk) => { body += chunk; if (body.length > 32768) req.destroy() })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const queryText = String(payload.query || '').trim()
        if (!queryText) return json(res, 400, { ok: false, message: 'Query is required.' }, origin)
        const args = ['--query', queryText, '--json', '--topk', String(Math.min(Math.max(parseInt(payload.top_k, 10) || 8, 1), 100))]
        if (Array.isArray(payload.sources) && payload.sources.length) {
          const clean = payload.sources.map((s) => String(s).replace(/[^\w.-]/g, '')).filter(Boolean)
          if (clean.length) args.push('--sources', clean.join(','))
        }
        const queryRes = await runIngestionScript(args)
        if (queryRes.ok && queryRes.data && Array.isArray(queryRes.data.matches)) {
          const matches = queryRes.data.matches
          const sourcesUsed = [...new Set(matches.map((m) => (m.metadata && m.metadata.source) || m.source || 'Unknown Source'))]
          return json(res, 200, {
            ok: true,
            query: queryText,
            matches,
            matches_count: matches.length,
            sources_used: sourcesUsed,
            source_count: sourcesUsed.length
          }, origin)
        }
        return json(res, 502, { ok: false, query: queryText, matches: [], matches_count: 0, sources_used: [], error: queryRes.error || 'Vector retrieval failed.' }, origin)
      } catch (err) {
        console.error('[bridge] KamiSensei query failed:', err)
        return json(res, 500, { ok: false, matches: [], matches_count: 0, sources_used: [], error: err.message }, origin)
      }
    })
    return
  }

  if (req.method === 'POST' && req.url === '/api/kamisensei/delete') {
    let body = ''
    req.on('data', (chunk) => { body += chunk; if (body.length > 4096) req.destroy() })
    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}')
        const rawName = path.basename(String(payload.filename || ''))
        const targetPath = path.join(KNOWLEDGE_BASE_DIR, rawName)
        if (fs.existsSync(targetPath)) {
          fs.unlinkSync(targetPath)
          scheduleKsWatchRun()
          return json(res, 200, { ok: true, message: `Deleted ${rawName} and scheduled reindex.` }, origin)
        }
        return json(res, 404, { ok: false, message: 'File not found.' }, origin)
      } catch (err) {
        console.error('[bridge] KamiSensei source deletion failed:', err)
        return json(res, 500, { ok: false, message: err.message }, origin)
      }
    })
    return
  }


  // ── KamiSensei: YouTube transcript extraction (youtube_service.py) ──
  if (req.method === 'POST' && (req.url === '/api/kamisensei/youtube-extract' || req.url === '/api/kamisensai/youtube-extract')) {
    let body = ''
    req.on('data', (chunk) => { body += chunk; if (body.length > 8192) req.destroy() })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const videoUrl = String(payload.url || '').trim()
        if (!videoUrl) return json(res, 400, { ok: false, status: 'error', error: 'A YouTube URL is required.' }, origin)
        if (!isSafeYouTubeUrl(videoUrl)) {
          return json(res, 400, { ok: false, status: 'error', error: 'Only youtube.com / youtu.be video links are supported.' }, origin)
        }
        const result = await runYoutubeService(videoUrl)
        const data = result.data || {}
        if (result.ok && data.status === 'success') {
          // Persist to the JSON store so the source survives page reloads and
          // renders in the Sources panel on next load (source of truth = DB).
          const saved = await saveKsSource({
            type: 'youtube',
            title: data.title || videoUrl,
            url: videoUrl,
            transcript: data.transcript || '',
            author: data.author || '',
          })
          const savedRecord = (saved && saved.ok && saved.data) ? saved.data : null
          return json(res, 200, {
            ok: true,
            status: 'success',
            id: savedRecord ? savedRecord.id : '',
            title: data.title || videoUrl,
            author: data.author || '',
            video_id: data.video_id || '',
            language: data.language || '',
            is_generated: data.is_generated,
            segment_count: data.segment_count || 0,
            duration_chars: data.duration_chars || 0,
            transcript: data.transcript || ''
          }, origin)
        }
        return json(res, 422, { ok: false, status: 'error', error: data.error || result.error || 'Transcript extraction failed.' }, origin)
      } catch (err) {
        console.error('[bridge] KamiSensei YouTube extraction failed:', err)
        return json(res, 500, { ok: false, status: 'error', error: err.message }, origin)
      }
    })
    return
  }

  // ── KamiSensei: list persisted JSON sources (kamisensei_db.json) ──
  if (req.method === 'GET' && (req.url === '/api/kamisensei/sources' || req.url === '/api/kamisensai/sources')) {
    const list = await listKsSources()
    if (list.ok && Array.isArray(list.data)) {
      return json(res, 200, { ok: true, sources: list.data, count: list.data.length }, origin)
    }
    return json(res, 500, { ok: false, sources: [], count: 0, error: list.error || 'Could not read source store.' }, origin)
  }

  // ── KamiSensei: delete a persisted JSON source ──
  if (req.method === 'DELETE' && (req.url.startsWith('/api/kamisensei/sources/') || req.url.startsWith('/api/kamisensai/sources/'))) {
    const rawId = req.url.split('/').pop() || ''
    const sourceId = decodeURIComponent(rawId).trim()
    if (!sourceId) return json(res, 400, { ok: false, deleted: false, error: 'A source id is required.' }, origin)
    const del = await runKsJsonStore(['delete', '--id', sourceId])
    if (del.ok && del.data && del.data.deleted) {
      return json(res, 200, { ok: true, deleted: true, id: sourceId }, origin)
    }
    return json(res, 404, { ok: false, deleted: false, error: 'Source not found.' }, origin)
  }

  // ── KamiSensei: delete a persisted source by URL ──
  // Used by the frontend to sync-remove the JSON-store copy when a notebook UI
  // source is deleted, so the same video can never linger/reappear as a ghost.
  if (req.method === 'POST' && (req.url === '/api/kamisensei/sources/delete-url' || req.url === '/api/kamisensai/sources/delete-url')) {
    let body = ''
    req.on('data', (chunk) => { body += chunk; if (body.length > 4096) req.destroy() })
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body || '{}')
        const url = String(payload.url || '').trim()
        if (!url) return json(res, 400, { ok: false, deleted: false, error: 'A source url is required.' }, origin)
        const del = await runKsJsonStore(['delete', '--url', url])
        if (del.ok && del.data && del.data.deleted) {
          return json(res, 200, { ok: true, deleted: true, url }, origin)
        }
        return json(res, 404, { ok: false, deleted: false, error: 'Source not found.' }, origin)
      } catch (err) {
        console.error('[bridge] KamiSensei URL source deletion failed:', err)
        return json(res, 500, { ok: false, deleted: false, error: err.message }, origin)
      }
    })
    return
  }

  // ── KamiSensei: lightweight local file-system pipeline ──
  if (req.method === 'GET' && (req.url === '/api/kamisensei/status' || req.url === '/api/kamisensai/status')) {
    const statusData = await getKamiSenseiStatus()
    if (statusData) {
      return json(res, 200, { ok: true, service: 'KamiSensei Local Vector Service', ...statusData }, origin)
    }
    const files = listKnowledgeBaseFiles().map((file) => ({ ...file, indexed: false }))
    return json(res, 503, {
      ok: false,
      service: 'KamiSensei Local Vector Service',
      is_empty: files.length === 0,
      files_count: files.length,
      files,
      chunks_count: 0,
      db_connected: false,
      knowledge_dir: KNOWLEDGE_BASE_DIR,
      chroma_dir: CHROMA_DB_DIR,
      error: 'Vector status is unavailable. Check Python dependencies and bridge logs.'
    }, origin)
  }
  if (req.method === 'GET' && (req.url === '/api/kamisensei/sources-list' || req.url === '/api/kamisensai/sources-list' || req.url === '/api/kamisensei/get-sources' || req.url === '/api/kamisensai/get-sources' || req.url === '/api/kamisensei/files' || req.url === '/api/kamisensai/files')) {
    const statusData = await getKamiSenseiStatus()
    if (statusData) {
      return json(res, 200, {
        ok: true,
        files: statusData.files || [],
        files_count: statusData.files_count || 0,
        chunks_count: statusData.chunks_count || 0,
        db_connected: statusData.db_connected === true
      }, origin)
    }
    const files = listKnowledgeBaseFiles().map((file) => ({ ...file, indexed: false }))
    return json(res, 503, { ok: false, files, files_count: files.length, chunks_count: 0, db_connected: false }, origin)
  }
  if (req.method === 'POST' && (req.url === '/api/kamisensei/create-notebook' || req.url === '/api/kamisensai/create-notebook')) {
    let body = ''
    req.on('data', (chunk) => { body += chunk; if (body.length > 4096) req.destroy() })
    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}')
        const name = String(payload.name || payload.title || 'New Notebook').trim() || 'New Notebook'
        const notebookId = crypto.randomUUID()
        const nbDir = path.join(NOTEBOOKS_DIR, notebookId)
        fs.mkdirSync(nbDir, { recursive: true })
        // Use the same metadata.json format as backend/api/notebooks.py. Older
        // config.json notebooks remain readable, but all new records now share
        // one canonical persistence shape.
        const metadataPath = path.join(nbDir, 'metadata.json')
        const metadata = { id: notebookId, name, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), sources: [], messages: [], settings: {} }
        fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2), 'utf8')
        return json(res, 200, { status: 'success', notebookId, name, createdAt: metadata.createdAt, path: nbDir, file: metadataPath }, origin)
      } catch (err) {
        console.error('[bridge] KamiSensei notebook creation failed:', err)
        return json(res, 500, { status: 'error', error: err.message }, origin)
      }
    })
    return
  }

  json(res, 404, { ok: false, message: 'Not found.' }, origin)
})

server.listen(PORT, HOST, () => {
  console.log(`JARVIS bridge listening on http://${HOST}:${PORT}`)
  console.log(isWindows ? 'Windows actions enabled.' : 'Compatibility mode: Windows actions are disabled on this OS.')
})

process.on('SIGINT', () => server.close(() => process.exit(0)))
process.on('SIGTERM', () => server.close(() => process.exit(0)))
