// Integration smoke: hit running jarvis-ui /api/tts, report chosen voice + audio size.
const cases = [
  ['mixed-hi+en+ja', { text: 'नमस्ते please こんにちは।', lang: 'auto' }],
  ['pure-hindi', { text: 'आप कैसे हैं आज', lang: 'hi' }],
  ['pure-english', { text: 'Good evening, JARVIS.', lang: 'en' }],
]
for (const [name, body] of cases) {
  const ctrl = new AbortController()
  const to = setTimeout(() => ctrl.abort(), 24000)
  try {
    const r = await fetch('http://127.0.0.1:7777/api/tts', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body), signal: ctrl.signal,
    })
    const voice = r.headers.get('x-tts-voice') || r.headers.get('X-TTS-Voice') || '(no voice hdr)'
    let size = r.headers.get('content-length') || ''
    if (!size) { try { const b = await r.blob(); size = `${Math.round(b.size / 1024)}KB` } catch { size = '?' } }
    console.log(name + ' -> HTTP ' + r.status + ' | voice: ' + voice + ' | audio: ' + size)
  } catch (e) {
    console.log(name + ' -> ERROR: ' + (e.name === 'AbortError' ? 'timeout(>24s)' : e.message))
  } finally { clearTimeout(to) }
}
