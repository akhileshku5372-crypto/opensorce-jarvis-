// Live guard for the Repos module (sidebar > Repos).
//
// Why this file exists: every Repos route is a POST to a server-side GitHub
// proxy, so nothing here can be checked with `node --check` or a unit test
// against a stub. It has to be driven through a real page: click the nav item,
// run a real search, open a real repository, read a real file, and read the
// rendered result back out of the DOM.
//
// It is also the regression test for a bug this feature actually hit: Vite's
// dev-server asset middleware answers any GET whose query string contains a
// dot-extension with a bare, body-less 404 before Hono sees it, which silently
// broke `path=README.md`. Hence the explicit README assertion below - it is the
// file that proved the routes had to become POST.
//
// Run: node tests/test_repos_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const artifactsDir = path.join(root, 'artifacts', 'ui-audit', 'repos')
mkdirSync(artifactsDir, { recursive: true })

const UI = process.env.JARVIS_UI || 'http://127.0.0.1:7777/'
const wait = (ms) => new Promise((r) => setTimeout(r, ms))

// Poll a browser-side expression until it returns truthy. GitHub search latency
// varies by seconds, so a fixed sleep is a coin flip: too short and the test
// reads a half-rendered list and fails, too long and every run pays for it.
async function waitFor(expression, { timeout = 25000, label = expression } = {}) {
  const deadline = Date.now() + timeout
  for (;;) {
    const value = await evaluate(expression)
    if (value) return value
    if (Date.now() > deadline) throw new Error('timed out waiting for: ' + label)
    await wait(400)
  }
}

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-repos-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=9234', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
  '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { rmSync(profile, { recursive: true, force: true }) } catch {}
}
// The suite drives real GitHub traffic across three repositories, so it needs
// more headroom than a unit test. This is a hang guard, not a target.
setTimeout(() => { cleanup(); process.exit(124) }, 300000).unref()

const IGNORE = [/favicon/i, /\[vite\]/i, /React DevTools/i, /net::ERR_/i]
const noise = []
// Step 11 deliberately fires malformed requests that the server is supposed to
// refuse. Chrome logs every 4xx as a console error, so counting those as
// "noise" would mean the test fails on the refusals it just asserted. The
// expectation flips only for the duration of that step.
let expectingRefusals = false
const record = (kind, text) => {
  if (IGNORE.some((re) => re.test(text))) return
  // A 4xx that arrives while a refusal is expected is the refusal working.
  if (expectingRefusals && /status of (400|404|403)/.test(text)) return
  noise.push(kind + ' ' + text)
}

async function connect() {
  for (let i = 0; i < 40; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:9234/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) {
        const page = await res.json()
        if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
      }
    } catch {}
    await wait(500)
  }
  throw new Error('CDP did not come up')
}

let send, evaluate, shoot

try {
  const ws = new WebSocket(await connect())
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', reject)
  })
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails
      record('EXC', d?.exception?.description || d?.text || '?')
    }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      record('console.error', (m.params.args || []).map((a) => a.value ?? a.description ?? '').join(' '))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      record('ERR', m.params.entry.text)
    }
  })
  send = (method, params = {}) => new Promise((resolve) => {
    const mid = ++id
    pending.set(mid, resolve)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
  evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    if (r.result?.exceptionDetails) {
      const d = r.result.exceptionDetails
      record('EXC', d.exception?.description || d.text || '?')
      return null
    }
    return r.result?.result?.value
  }
  shoot = async (name) => {
    const r = await send('Page.captureScreenshot', { format: 'png' })
    if (!r.result?.data) return
    writeFileSync(path.join(artifactsDir, name + '.png'), Buffer.from(r.result.data, 'base64'))
    console.log('  ok   screenshot -> artifacts/ui-audit/repos/' + name + '.png')
  }

  await send('Page.enable')
  await send('Runtime.enable')
  await send('Log.enable')
  await wait(2500)

  // ── 1. the nav entry exists and is reachable ──────────────────────────────
  const nav = await evaluate(`(() => {
    const item = document.querySelector('.nav-item[data-view="repos"]')
    if (!item) return null
    item.click()
    const view = document.querySelector('[data-view-panel="repos"]')
    return { label: item.querySelector('.nav-label')?.textContent, active: view?.classList.contains('active') }
  })()`)
  if (!nav) bad('sidebar has no Repos nav item')
  else if (nav.label !== 'Repos') bad('nav label is "' + nav.label + '" (expected Repos)')
  else if (!nav.active) bad('clicking Repos did not activate its view')
  else ok('sidebar Repos item opens its own view')

  // ── 2. the key is read server-side, and never rendered ────────────────────
  await wait(900)
  const keyState = await evaluate(`(() => ({
    chip: document.querySelector('#repos-key-chip')?.textContent || '',
    // If the token were ever interpolated into the page, it would show up here.
    leaked: document.documentElement.innerHTML.includes('github_pat_')
  }))()`)
  if (keyState.leaked) bad('GITHUB_API_KEY leaked into the rendered page')
  else if (!/connected/i.test(keyState.chip)) bad('key chip says "' + keyState.chip + '" (expected connected)')
  else ok('server-side key detected and not present in the DOM')

  // ── 3. a real GitHub search ───────────────────────────────────────────────
  await evaluate(`(() => {
    document.querySelector('#repos-search-input').value = 'browser-use'
    document.querySelector('#repos-search-form').requestSubmit()
  })()`)
  await wait(6000)
  const search = await evaluate(`(() => {
    const cards = [...document.querySelectorAll('#repos-results .repo-card')]
    return {
      count: cards.length,
      note: document.querySelector('#repos-search-note')?.textContent || '',
      names: cards.slice(0, 5).map((c) => c.dataset.repo)
    }
  })()`)
  if (!search.count) bad('search returned no repository cards (' + search.note + ')')
  else if (!search.names.includes('browser-use/browser-use')) {
    bad('browser-use/browser-use missing from results: ' + search.names.join(', '))
  } else ok(`search returned ${search.count} live repositories (browser-use/browser-use first)`)
  await shoot('01-search-results')

  // ── 4. open a repo as its own workspace ───────────────────────────────────
  await evaluate(`document.querySelector('#repos-results [data-open-repo="browser-use/browser-use"]').click()`)
  await wait(9000)
  const ws1 = await evaluate(`(() => ({
    visible: !document.querySelector('#repos-workspace').hidden,
    name: document.querySelector('#repos-workspace-name')?.textContent || '',
    files: document.querySelectorAll('#repos-files .repo-file').length,
    count: document.querySelector('#repos-file-count')?.textContent || '',
    readme: (document.querySelector('#repos-readme pre')?.textContent || '').slice(0, 40),
    meta: document.querySelector('#repos-workspace-meta')?.textContent || ''
  }))()`)
  if (!ws1.visible) bad('workspace stayed hidden after opening a repo')
  else if (ws1.name !== 'browser-use/browser-use') bad('workspace header shows "' + ws1.name + '"')
  else if (ws1.files < 100) bad(`file tree listed only ${ws1.files} files (${ws1.count})`)
  else ok(`workspace loaded ${ws1.count.trim()} and a live README`)
  await shoot('02-repo-workspace')

  // ── 5. read a real source file ────────────────────────────────────────────
  await evaluate(`(() => {
    const file = [...document.querySelectorAll('#repos-files .repo-file')]
      .find((f) => f.dataset.repoFile.endsWith('.py'))
    file?.click()
  })()`)
  await wait(5000)
  const code = await evaluate(`(() => ({
    shown: !document.querySelector('#repos-viewer').hidden,
    path: document.querySelector('#repos-viewer-path')?.textContent || '',
    text: (document.querySelector('#repos-code')?.textContent || '').slice(0, 120)
  }))()`)
  if (!code.shown) bad('file viewer did not open')
  else if (/not found|404|error/i.test(code.text)) bad('file viewer shows an error: ' + code.text.slice(0, 60))
  else if (code.text.trim().length < 20) bad('file viewer is empty for ' + code.path)
  else ok(`file viewer rendered ${code.path}`)
  await shoot('03-file-viewer')

  // ── 6. the file filter narrows the real tree ──────────────────────────────
  const filtered = await evaluate(`(() => {
    const input = document.querySelector('#repos-file-filter')
    const before = document.querySelectorAll('#repos-files .repo-file').length
    input.value = 'agent'
    input.dispatchEvent(new Event('input', { bubbles: true }))
    const after = document.querySelectorAll('#repos-files .repo-file').length
    const allMatch = [...document.querySelectorAll('#repos-files .repo-file')]
      .every((f) => f.dataset.repoFile.toLowerCase().includes('agent'))
    input.value = ''
    input.dispatchEvent(new Event('input', { bubbles: true }))
    return { before, after, allMatch }
  })()`)
  if (filtered.after >= filtered.before) bad(`filter did not narrow the tree (${filtered.before} -> ${filtered.after})`)
  else if (!filtered.allMatch) bad('filter left non-matching files in the list')
  else ok(`file filter narrowed ${filtered.before} -> ${filtered.after} entries`)

  // ── 7. README specifically (the Vite .md interception regression) ─────────
  const readme = await evaluate(`(async () => {
    const r = await fetch('/api/repos/file', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repo: 'browser-use/browser-use', ref: 'main', path: 'README.md' })
    })
    const d = await r.json()
    return { status: r.status, len: (d.text || '').length, binary: !!d.binary }
  })()`)
  if (readme.status !== 200) bad(`README.md read returned ${readme.status} (Vite .md interception?)`)
  else if (readme.binary || readme.len < 1000) bad(`README.md came back empty (${readme.len} bytes)`)
  else ok(`README.md read directly: ${readme.len} bytes of real content`)

  // ── 8. a second repo gets its own workspace, not an overwrite ─────────────
  await evaluate(`(() => {
    document.querySelector('#repos-search-input').value = 'openclaw'
    document.querySelector('#repos-search-form').requestSubmit()
  })()`)
  // Poll for a real result card instead of sleeping a guessed interval: GitHub
  // search takes anywhere from ~1s to ~10s, and a fixed wait either reads a
  // still-empty list or adds dead time to every run.
  await waitFor(`(() => {
    const note = document.querySelector('#repos-search-note')?.textContent || ''
    const card = document.querySelector('#repos-results [data-open-repo]')
    if (card) return card.dataset.openRepo
    // A search that actually failed will never produce a card, so surface it
    // now instead of spinning until the timeout.
    if (/failed|error/i.test(note)) return 'ERROR:' + note
    return false
  })()`, { label: 'openclaw search results' })
  const second = await evaluate(`(() => {
    const card = document.querySelector('#repos-results [data-open-repo]')
    const name = card?.dataset.openRepo
    if (!name) return { name: '' }
    card.click()
    return { name }
  })()`)
  if (second.name.startsWith('ERROR:')) bad('second search reported: ' + second.name)
  // Wait for the workspace header to actually switch, not for a fixed period.
  await waitFor(`document.querySelector('#repos-workspace-name')?.textContent === ${JSON.stringify(second.name)} && document.querySelectorAll('#repos-files .repo-file').length > 0`,
    { label: 'second workspace to load' })
  const ws2 = await evaluate(`(() => ({
    name: document.querySelector('#repos-workspace-name')?.textContent || '',
    files: document.querySelectorAll('#repos-files .repo-file').length,
    count: document.querySelector('#repos-file-count')?.textContent || '',
    open: JSON.parse(localStorage.getItem('jarvis.repos.workspaces') || '{}').order || []
  }))()`)
  if (!second.name) bad('second search produced no openable repository')
  else if (ws2.name !== second.name) bad(`workspace did not switch to ${second.name} (shows ${ws2.name})`)
  else if (ws2.files < 5) bad(`second workspace listed only ${ws2.files} files`)
  else ok(`second repo "${ws2.name}" has its own workspace with ${ws2.files} files`)
  if (ws2.open.length < 2) bad(`only ${ws2.open.length} repo(s) tracked as open (expected >= 2)`)
  else ok(`both repos tracked independently: ${ws2.open.join(', ')}`)

  // ── 8b. a 50k-file repo stays usable and honest ──────────────────────────
  // openclaw/openclaw has ~50,600 files. The tree route caps what it ships and
  // reports the true `total`; the UI must show the real number, not the capped
  // one, or the workspace would imply it listed the whole repository.
  const big = await evaluate(`(async () => {
    const res = await fetch('/api/repos/tree', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repo: 'openclaw/openclaw', ref: 'main' })
    })
    const tree = await res.json()
    return {
      status: res.status,
      files: (tree.files || []).length,
      total: Number(tree.total || 0),
      capped: Boolean(tree.capped),
      label: document.querySelector('#repos-file-count')?.textContent || '',
      rows: document.querySelectorAll('#repos-files .repo-file').length
    }
  })()`)
  if (big.status !== 200) bad('large repo tree returned ' + big.status)
  else if (big.files > 600) bad(`tree shipped ${big.files} entries (cap is 600)`)
  else if (!big.capped) bad('a 50k-file repo was not reported as capped')
  else if (big.total <= big.files) bad(`total (${big.total}) must exceed the shipped cap (${big.files})`)
  else if (!/of/.test(big.label)) bad('the capped file count is not stated in the UI: ' + big.label)
  else ok(`50k-file repo capped to ${big.files} of ${big.total}, stated as "${big.label.trim()}"`)
  await shoot('04-second-repo')

  // ── 9. the first repo still resolves on its own ───────────────────────────
  const back = await evaluate(`(async () => {
    const res = await fetch('/api/repos/tree', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repo: 'browser-use/browser-use', ref: 'main' })
    })
    const tree = await res.json()
    return { status: res.status, files: (tree.files || []).length }
  })()`)
  if (back.status !== 200) bad('re-reading the first repo tree failed: ' + back.status)
  else if (back.files < 100) bad('first repo tree returned ' + back.files + ' files on re-read')
  else ok(`first repo still resolves independently (${back.files} files)`)

  // ── 9a. a workspace switcher exists for the repos already open ────────────
  // Both repos are open at this point. Without a switcher the second repo
  // simply replaced the first on screen and the first was unreachable.
  const openRail = await evaluate(`(() => {
    const chips = [...document.querySelectorAll('#repos-open-tabs .repo-tab')]
    return {
      count: document.querySelector('#repos-open-count')?.textContent || '',
      chips: chips.map((c) => c.dataset.repoTab),
      active: chips.filter((c) => c.classList.contains('active')).map((c) => c.dataset.repoTab),
      closable: document.querySelectorAll('#repos-open-tabs [data-repo-close]').length
    }
  })()`)
  if (openRail.chips.length < 2) bad(`open-workspaces rail lists ${openRail.chips.length} repo(s), expected 2`)
  else if (openRail.count !== String(openRail.chips.length)) bad(`rail counter says "${openRail.count}" but ${openRail.chips.length} chips are rendered`)
  else if (openRail.active.length !== 1) bad(`${openRail.active.length} chips are marked active (expected exactly 1)`)
  else if (openRail.closable !== openRail.chips.length) bad('not every chip has its own remove button')
  else ok(`${openRail.chips.length} workspaces listed, switchable and individually removable: ${openRail.chips.join(', ')}`)

  // ── 9b. switching back to the first repo restores ITS workspace ───────────
  const first = openRail.chips.find((name) => name !== openRail.active[0])
  await evaluate(`document.querySelector('#repos-open-tabs [data-repo-activate="' + ${JSON.stringify(first)} + '"]').click()`)
  await waitFor(`document.querySelector('#repos-workspace-name')?.textContent === ${JSON.stringify(first)} && document.querySelectorAll('#repos-files .repo-file').length > 0`,
    { label: 'switching back to ' + first })
  const switched = await evaluate(`(() => ({
    name: document.querySelector('#repos-workspace-name')?.textContent || '',
    files: document.querySelectorAll('#repos-files .repo-file').length,
    active: [...document.querySelectorAll('#repos-open-tabs .repo-tab.active')].map((c) => c.dataset.repoTab),
    // Only meaningful when the active repo is in the CURRENT result set: the
    // grid shows the last search, so a repo from an earlier search has no card.
    cardInResults: !!document.querySelector('#repos-results [data-open-repo="' + ${JSON.stringify(first)} + '"]'),
    marked: document.querySelector('#repos-results .repo-card.is-active')?.dataset.repo || ''
  }))()`)
  if (switched.name !== first) bad(`switching the chip showed "${switched.name}" (expected ${first})`)
  else if (switched.files < 5) bad(`switched workspace listed only ${switched.files} files`)
  else if (switched.active[0] !== first) bad('the active chip did not follow the switch')
  else if (switched.cardInResults && switched.marked !== first) bad('the result card is not marked for the active repo')
  else ok(`chip switch restored ${switched.name} with ${switched.files} files`)
  await shoot('05-workspace-switcher')

  // ── 9c. back button returns to the repository list, keeping the workspaces ─
  await evaluate(`document.querySelector('#repos-back').click()`)
  const backState = await evaluate(`(() => ({
    hidden: document.querySelector('#repos-workspace').hidden,
    searchVisible: !!document.querySelector('#repos-search-panel')?.offsetParent,
    chips: document.querySelectorAll('#repos-open-tabs .repo-tab').length
  }))()`)
  if (!backState.hidden) bad('the back button did not hide the workspace')
  else if (!backState.searchVisible) bad('the back button did not return to the search panel')
  else if (backState.chips < 2) bad('going back discarded the open workspaces')
  else ok('back returns to the repository list and keeps every workspace open')
  // The same repo must be reachable again from the rail, not lost.
  await evaluate(`document.querySelector('#repos-open-tabs [data-repo-activate="' + ${JSON.stringify(first)} + '"]').click()`)
  await waitFor(`document.querySelector('#repos-workspace')?.hidden === false`, { label: 'reopening a workspace from the rail' })
  ok('a repo can be reopened from the rail after going back')

  // ── 9d. removing a repo drops only that one ──────────────────────────────
  const survivor = [...openRail.chips].find((name) => name !== first)
  await waitFor(`document.querySelectorAll('#repos-open-tabs .repo-tab').length === 2`, { label: 'both chips present' })
  await evaluate(`document.querySelector('#repos-open-tabs [data-repo-close="' + ${JSON.stringify(first)} + '"]').click()`)
  await wait(400)
  const removed = await evaluate(`(() => ({
    chips: [...document.querySelectorAll('#repos-open-tabs .repo-tab')].map((c) => c.dataset.repoTab),
    count: document.querySelector('#repos-open-count')?.textContent || '',
    stored: JSON.parse(localStorage.getItem('jarvis.repos.workspaces') || '{}'),
    // Removing the ACTIVE repo must hand the screen to the survivor, not leave
    // the deleted repo's files on display.
    name: document.querySelector('#repos-workspace-name')?.textContent || ''
  }))()`)
  if (removed.chips.includes(first)) bad('the removed repo is still listed')
  else if (removed.chips.length !== 1 || removed.chips[0] !== survivor) bad('removing one repo changed the wrong set: ' + removed.chips.join(', '))
  else if (removed.count !== '1') bad(`rail counter says "${removed.count}" after removing one of two`)
  else if ((removed.stored.order || []).includes(first)) bad('the removed repo is still persisted in localStorage')
  else if (removed.name === first) bad('the workspace is still showing the repo that was removed')
  else ok(`remove dropped only ${first}; the workspace moved on to ${survivor}`)

  // ── 9e. the header Remove button removes the active repo ─────────────────
  await evaluate(`document.querySelector('#repos-close-active').click()`)
  await wait(400)
  const emptied = await evaluate(`(() => ({
    chips: document.querySelectorAll('#repos-open-tabs .repo-tab').length,
    hidden: document.querySelector('#repos-workspace').hidden,
    note: document.querySelector('#repos-search-note')?.textContent || '',
    stored: JSON.parse(localStorage.getItem('jarvis.repos.workspaces') || '{}').order || []
  }))()`)
  if (emptied.chips !== 0) bad(`${emptied.chips} chips left after removing the last workspace`)
  else if (!emptied.hidden) bad('the workspace stayed visible with no repo open')
  else if (emptied.stored.length !== 0) bad('localStorage still lists repos after removing the last one')
  else if (!/no repositories open/i.test(emptied.note)) bad('an empty workspace state is not explained: "' + emptied.note + '"')
  else ok('removing the last repo empties the rail and says so')

  // ── 9f. workspaces survive a reload ───────────────────────────────────────
  // This is the "I added a repo and it was gone after refresh" bug: the state
  // was written to localStorage but nothing ever read it back.
  await evaluate(`(() => {
    localStorage.setItem('jarvis.repos.workspaces', JSON.stringify({
      version: 1, order: ['browser-use/browser-use'], active: 'browser-use/browser-use',
      repos: [{ full_name: 'browser-use/browser-use', description: 'restored', language: 'Python', stars: 1, forks: 0, license: 'MIT', default_branch: 'main', url: '' }]
    }))
  })()`)
  await send('Page.reload')
  await wait(1500)
  await evaluate(`document.querySelector('.nav-item[data-view="repos"]').click()`)
  await waitFor(`document.querySelectorAll('#repos-open-tabs .repo-tab').length === 1`, { label: 'restored workspace chip' })
  const restoredEntry = await evaluate(`(() => ({
    chip: document.querySelector('#repos-open-tabs .repo-tab')?.dataset.repoTab || '',
    count: document.querySelector('#repos-open-count')?.textContent || ''
  }))()`)
  if (restoredEntry.chip !== 'browser-use/browser-use') bad('the workspace list did not survive the reload: "' + restoredEntry.chip + '"')
  else if (restoredEntry.count !== '1') bad(`restored counter says "${restoredEntry.count}"`)
  else ok('an added repo is still open after a full page reload')
  // The tree is re-fetched on restore, not restored from a stale cache.
  await waitFor(`document.querySelectorAll('#repos-files .repo-file').length > 0`, { label: 'restored file tree' })
  const refetched = await evaluate(`document.querySelectorAll('#repos-files .repo-file').length`)
  if (refetched < 100) bad(`restored workspace listed only ${refetched} files`)
  else ok(`restored workspace re-fetched its live file tree (${refetched} files)`)
  await shoot('06-restored-after-reload')

  // ── 10. the collapsed rail still works with one more icon ────────────────
  const before10 = await evaluate(`(() => {
    const before = document.querySelectorAll('.nav-item').length
    document.querySelector('#sidebar-collapse').click()
    return before
  })()`)
  // The rail animates over .22s, so measuring in the same tick as the click
  // reads the pre-transition width and reports a false failure.
  await wait(600)
  const rail = await evaluate(`(() => ({
    collapsed: document.body.classList.contains('sidebar-collapsed'),
    railPx: document.querySelector('.sidebar').getBoundingClientRect().width
  }))()`)
  await evaluate(`document.querySelector('#sidebar-collapse').click()`)
  await wait(600)
  const restored = await evaluate(`document.querySelector('.sidebar').getBoundingClientRect().width`)
  if (!rail.collapsed) bad('sidebar did not collapse with the Repos item present')
  else if (rail.railPx > 70) bad('collapsed rail is ' + rail.railPx + 'px')
  else ok(`sidebar still collapses to ${rail.railPx}px with ${before10} nav items`)
  if (restored < 200) bad('sidebar did not expand again (still ' + restored + 'px)')
  else ok(`sidebar expands back to ${restored}px`)

  // ── 11. traversal and malformed input are refused by the server ───────────
  expectingRefusals = true
  const hostile = await evaluate(`(async () => {
    const call = async (route, body) => {
      const r = await fetch('/api/repos/' + route, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
      })
      return r.status
    }
    return {
      traversal: await call('file', { repo: 'browser-use/browser-use', path: '../../../etc/passwd' }),
      absolute: await call('file', { repo: 'browser-use/browser-use', path: '/etc/passwd' }),
      backslash: await call('file', { repo: 'browser-use/browser-use', path: '..\\\\..\\\\win.ini' }),
      // A name with no slash at all is malformed and must be refused locally.
      noSlash: await call('detail', { repo: 'evilcom' }),
      // A well-formed name that simply does not exist is NOT malformed: it must
      // reach GitHub and come back 404. Dots are legal in a GitHub owner, so
      // "evil.com/x" is a valid shape and asserting 400 would demand a lie.
      absent: await call('detail', { repo: 'evil.com/x' }),
      badRef: await call('tree', { repo: 'browser-use/browser-use', ref: 'a b|c;d' }),
      missing: await call('detail', { repo: 'browser-use/definitely-not-real-999' })
    }
  })()`)
  const refused = ['traversal', 'absolute', 'backslash', 'noSlash', 'badRef'].every((k) => hostile[k] === 400)
  if (!refused) bad('malformed input was not refused: ' + JSON.stringify(hostile))
  else ok('path traversal, absolute paths, bad refs and malformed repos are refused')
  if (hostile.absent !== 404) bad('a well-formed but absent repo returned ' + hostile.absent + ' (expected 404)')
  else ok('a nonexistent repository reports 404 instead of an empty success')
  // Give Chrome a moment to flush its console entries, then stop excusing 4xx
  // so any error AFTER this point still counts as real noise.
  await wait(500)
  expectingRefusals = false

  if (noise.length) bad('console/uncaught noise: ' + noise.slice(0, 5).join(' | '))
  else ok('no console errors or uncaught exceptions')

  console.log(`\nREPOS UI: ${passed} passed, ${failed} failed`)
} catch (error) {
  bad('harness error: ' + (error?.message || error))
  console.log(`\nREPOS UI: ${passed} passed, ${failed} failed`)
} finally {
  cleanup()
}
process.exit(failed ? 1 : 0)