"""Real n8n integration for the Agents panel.

n8n (v2.x, `npm i -g n8n`, run by PM2 as `jarvis-n8n`) is a SEPARATE Node
application. It owns its SQLite database, its workflow engine and its own Vue
editor. This module never re-implements any of that. It only:

  * probes n8n's public ``/healthz`` so the UI can report a truthful state,
  * turns a plain-English request into a real n8n workflow JSON, and
  * creates that workflow through n8n's own REST API.

Honesty rules that match the rest of the repo:

  * If n8n is not running, or its first-run owner setup has not been completed,
    every function returns ``ok: False`` with the reason. Nothing is faked and
    no workflow is "created" locally as a fallback.
  * Credentials are never invented. The generated starter graph is marked
    inactive so the user reviews it in n8n before it can run.
"""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request

DEFAULT_N8N_BASE = "http://127.0.0.1:5678"
TIMEOUT_S = 20
# n8n's public REST API (/api/v1/*) is closed to anonymous callers and answers
# 401 until a key is presented in the X-N8N-API-KEY header. The key is minted in
# n8n itself (Settings -> n8n API) and is a secret: it is read from the
# environment and never hardcoded, logged, or returned to the browser.
API_KEY_ENV = "N8N_API_KEY"


def _env(name, default=""):
    """Read a setting from the process, then .dev.vars/.env at call time."""
    if os.environ.get(name):
        return str(os.environ[name]).strip()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for fname in (".dev.vars", ".env"):
        try:
            with open(os.path.join(root, fname), "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith(name + "="):
                        return line.split("=", 1)[1].strip()
        except OSError:
            continue
    return default


def _api_key(explicit=None):
    """Resolve the n8n API key, preferring an explicit one.

    Read at call time rather than import time so a key added to the environment
    (or to .dev.vars) after this module was first imported still takes effect.
    """
    if explicit:
        return str(explicit).strip()
    return _env(API_KEY_ENV)


def _base():
    return _env("N8N_BASE_URL", DEFAULT_N8N_BASE).rstrip("/")

# n8n node type strings for the core nodes, deliberately conservative: anything
# needing a paid third-party credential is skipped rather than guessed at.
NODE_MANUAL = "n8n-nodes-base.manualTrigger"
NODE_SCHEDULE = "n8n-nodes-base.scheduleTrigger"
CODE_NODE = "n8n-nodes-base.code"
NODE_SET = "n8n-nodes-base.set"


def _request(method, path, payload=None, api_key=None):
    """Call n8n's REST API. Returns (status, decoded_body)."""
    url = _base() + path
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    headers = {"Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    if api_key:
        headers["X-N8N-API-KEY"] = api_key
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_S) as response:
            raw = response.read().decode("utf-8", "replace")
            status = response.status
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace")
        status = exc.code
    except Exception as exc:  # connection refused, timeout, DNS, ...
        return 0, {"error": str(exc)}
    try:
        return status, json.loads(raw) if raw else {}
    except ValueError:
        return status, {"error": raw[:400]}

def _node(node_type, name, position, parameters=None, type_version=1):
    return {
        "parameters": parameters or {},
        "id": name.lower().replace(" ", "-"),
        "name": name,
        "type": node_type,
        "typeVersion": type_version,
        "position": list(position),
    }


def _infer_intent(prompt):
    """Pick a trigger from the sentence. Conservative and explainable."""
    text = (prompt or "").lower()
    if re.search(r"\b(every (morning|hour|day|night)|daily|weekly|schedule|cron|nightly)\b", text):
        return "schedule"
    return "manual"


def build_workflow(prompt):
    """Turn a plain-English request into a real n8n workflow definition.

    This is a TRANSLATION, not an AI invention: it reads the request, picks a
    trigger, and emits a starter graph the user then edits in n8n's own canvas.
    It never claims the automation runs unattended until the user activates it.
    """
    prompt = (prompt or "").strip()
    if not prompt:
        return None, "Describe the workflow first."
    if len(prompt) > 500:
        return None, "That description is too long (500 characters max)."

    title = prompt if len(prompt) <= 60 else prompt[:57].rsplit(" ", 1)[0] + "..."
    intent = _infer_intent(prompt)

    if intent == "schedule":
        trigger = _node(NODE_SCHEDULE, "Every Run", [0, 0],
                        {"rule": {"interval": [{"field": "hours", "hoursInterval": 24}]}})
    else:
        trigger = _node(NODE_MANUAL, "When clicking Execute", [0, 0], {})

    steps = _node(CODE_NODE, "Describe the task", [220, 0],
                  {"jsCode": (
                      "// JARVIS starter step.\n"
                      "// Replace this with the real work: call an HTTP API, read a\n"
                      "// file, transform data. The trigger's output is in $json.\n"
                      "return [{ json: { request: %s, note: 'edit this node in n8n' } }];\n"
                      % json.dumps(prompt)
                  )})

    final = _node(NODE_SET, "Result", [440, 0],
                  {"assignments": {"assignments": [
                      {"id": "a1", "name": "status", "value": "draft", "type": "string"}]}},
                  type_version=3)

    nodes = [trigger, steps, final]
    connections = {
        trigger["name"]: {"main": [[{"node": steps["name"], "type": "main", "index": 0}]]},
        steps["name"]: {"main": [[{"node": final["name"], "type": "main", "index": 0}]]},
    }
    workflow = {
        "name": title,
        "nodes": nodes,
        "connections": connections,
        "settings": {"executionOrder": "v1"},
        "active": False,  # never auto-activate: the user reviews it first
        "meta": {"instanceId": "jarvis-n8n-panel"},
        "tags": [],
    }
    return workflow, None


def create_workflow(prompt, api_key=None):
    """Create the workflow in the REAL n8n instance.

    Requires n8n online and past first-run setup. When n8n refuses, its own
    message is surfaced verbatim instead of a generic failure.
    """
    probe = health()
    if not probe.get("online"):
        return None, ("n8n is not running. Start it with: "
                      "pm2 start ecosystem.config.cjs --only jarvis-n8n")

    workflow, err = build_workflow(prompt)
    if workflow is None:
        return None, err

    api_key = _api_key(api_key)
    status, created = _request("POST", "/api/v1/workflows", workflow, api_key=api_key)
    if status in (401, 403):
        if api_key:
            return None, ("n8n rejected the %s key. It may have been rotated or "
                          "revoked - mint a new one in n8n under Settings -> n8n "
                          "API and update %s." % (API_KEY_ENV, API_KEY_ENV))
        return None, ("n8n needs authentication. Its /api/v1 API is closed to "
                      "anonymous callers. Open %s, create a key under Settings -> "
                      "n8n API, then set %s in .dev.vars." % (_base(), API_KEY_ENV))
    if status == 404:
        return None, ("n8n's workflow API is not enabled yet. It only answers "
                      "/api/v1/workflows after an owner account exists.")
    if status not in (200, 201) or not isinstance(created, dict):
        detail = created.get("message") if isinstance(created, dict) else created
        return None, "n8n refused the workflow (HTTP %s): %s" % (status, detail)

    return {"id": created.get("id"),
            "name": created.get("name") or workflow["name"],
            "nodes": len(workflow["nodes"]),
            "active": bool(created.get("active"))}, None


def list_workflows(api_key=None, limit=25):
    """Real workflow list straight from n8n. Empty list when n8n is down."""
    status, body = _request("GET", "/api/v1/workflows?limit=%d" % int(limit),
                            api_key=_api_key(api_key))
    if status != 200 or not isinstance(body, dict):
        return [], "n8n workflow list unavailable (HTTP %s)" % status
    return [{"id": w.get("id"), "name": w.get("name"), "active": bool(w.get("active"))}
            for w in (body.get("data") or []) if isinstance(w, dict)], None

def health():
    """Probe n8n directly. The only source of truth for panel state."""
    status, body = _request("GET", "/healthz")
    if status != 200 or not isinstance(body, dict) or body.get("status") != "ok":
        return {"ok": False, "online": False,
                "reason": "n8n did not answer /healthz (status %s)" % status}
    # online only means the process answers. Creating workflows over the public
    # API additionally needs a key, so report that separately instead of letting
    # the panel imply "Build in n8n" will work. The key itself is never returned.
    return {"ok": True, "online": True, "base": _base(),
            "api_key_configured": bool(_api_key())}