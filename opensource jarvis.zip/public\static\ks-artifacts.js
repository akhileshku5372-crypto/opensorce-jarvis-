/* ══════════════════════════════════════════════════════════════════════════
 * KamiSensei Artifact Renderers — interactive full-panel artifact views
 * ────────────────────────────────────────────────────────────────────────────
 * Loaded AFTER ks-state.js and BEFORE app.js. Exposes `window.KSArtifacts`.
 *
 *   KSArtifacts.render(artifact, ctx) → HTMLElement
 *     ctx.onSaveContent(newContent)   — persists user edits (notes)
 *
 * Every artifact type gets a real interactive UI. Raw JSON is NEVER rendered
 * as the final artifact surface: if content cannot satisfy a renderer's schema
 * it falls back to a document/markdown view so the user's real data is still
 * readable — nothing fake is ever synthesized.
 * ══════════════════════════════════════════════════════════════════════════ */
;(() => {
  /* ── Small DOM helpers ─────────────────────────────────────────────────── */
  function el(tag, cls, text) {
    const node = document.createElement(tag)
    if (cls) node.className = cls
    if (text != null) node.textContent = text
    return node
  }

  function escapeHtml(text) {
    const div = document.createElement('div')
    div.textContent = String(text ?? '')
    return div.innerHTML
  }

  /** Minimal, safe markdown → HTML (no raw HTML passthrough from the model). */
  function mdToHtml(markdown) {
    const lines = String(markdown || '').split(/\r?\n/)
    const out = []
    let inList = false
    const closeList = () => { if (inList) { out.push('</ul>'); inList = false } }
    const inline = (s) => escapeHtml(s)
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\*([^*]+)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
    for (const line of lines) {
      const h = line.match(/^(#{1,4})\s+(.*)$/)
      if (h) { closeList(); out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`); continue }
      const li = line.match(/^\s*[-*•]\s+(.*)$/)
      if (li) { if (!inList) { out.push('<ul>'); inList = true } out.push(`<li>${inline(li[1])}</li>`); continue }
      const num = line.match(/^\s*\d+[.)]\s+(.*)$/)
      if (num) { if (!inList) { out.push('<ul>'); inList = true } out.push(`<li>${inline(num[1])}</li>`); continue }
      closeList()
      if (line.trim()) out.push(`<p>${inline(line)}</p>`)
    }
    closeList()
    return out.join('')
  }

  function iconButton(label, iconName, onClick) {
    const btn = el('button', 'ks-av-btn')
    btn.type = 'button'
    btn.title = label
    btn.innerHTML = `<i data-lucide="${iconName}"></i><span>${escapeHtml(label)}</span>`
    btn.addEventListener('click', onClick)
    return btn
  }

  function refreshIcons() { if (window.lucide) window.lucide.createIcons() }

  /* ── Fallback: document/markdown view (real data, readable form) ───────── */
  function renderMarkdownDoc(content) {
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')
    if (content && typeof content.markdown === 'string') {
      body.innerHTML = mdToHtml(content.markdown)
    } else if (isPlainObject(content) || Array.isArray(content)) {
      /* PERMANENT "[object Object]" BAN: raw objects are pretty-printed as
       * structured JSON instead of being coerced through String(). */
      const pre = el('pre', 'ks-av-json-dump', '')
      pre.textContent = JSON.stringify(content, null, 2).slice(0, 20000)
      body.appendChild(pre)
    } else {
      body.innerHTML = mdToHtml(String(content ?? ''))
    }
    wrap.appendChild(body)
    return wrap
  }

    function isPlainObject(v) { return v && typeof v === 'object' && !Array.isArray(v) }

  /* Case-fold + strip punctuation + collapse whitespace — mirrors server-side
   * normalizeLabel so client-side dedup is consistent with server-side. */
  function normalizeLabel(value) {
    return String(value ?? '')
      .toLowerCase()
      .replace(/[^\p{L}\p{N} ]/gu, '')
      .replace(/\s+/g, ' ')
      .trim()
  }

  /* Meta-level / file-statistics noise ban \u2014 mirrors the server flatten pass. */
  const META_LABEL_RE = /(study pages?|workbook|language medium|page count|book (length|size|info)|pdf|file (size|info|length)|document (info|length|stats?)|table of contents|extraction|ocr|scanned|word count|\d+\s*(pages?|sections?|chapters?|paragraphs?))/i
  function isMetaLabel(value) {
    const s = String(value ?? '').toLowerCase().trim()
    if (!s) return false
    return META_LABEL_RE.test(s)
  }
  /* ══ NOTES ═══════════════════════════════════════════════════════════════ */
  // Schema: { title, summary, sections:[{title,body}], keyPoints:[], examples:[], sources:[] }
  // Editable after generation; edits persist via ctx.onSaveContent.
  function renderNote(artifact, ctx) {
    const content = artifact.content || {}
    if (!isPlainObject(content) || (!Array.isArray(content.sections) && typeof content.markdown !== 'string')) {
      return renderMarkdownDoc(content)
    }
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')

    function drawStatic() {
      body.innerHTML = ''
      if (content.summary) body.appendChild(el('p', 'ks-av-summary', content.summary))
      ;(content.sections || []).forEach((section) => {
        if (!section) return
        const sec = el('section', 'ks-av-section')
        if (section.title) sec.appendChild(el('h3', 'ks-av-h3', section.title))
        sec.appendChild(el('p', null, section.body || ''))
        body.appendChild(sec)
      })
      if (Array.isArray(content.keyPoints) && content.keyPoints.length) {
        const sec = el('section', 'ks-av-section')
        sec.appendChild(el('h3', 'ks-av-h3', 'Key Points'))
        const ul = el('ul', 'ks-av-list')
        content.keyPoints.forEach((kp) => ul.appendChild(el('li', null, String(kp))))
        sec.appendChild(ul)
        body.appendChild(sec)
      }
      if (Array.isArray(content.examples) && content.examples.length) {
        const sec = el('section', 'ks-av-section')
        sec.appendChild(el('h3', 'ks-av-h3', 'Examples'))
        content.examples.forEach((ex) => {
          const card = el('div', 'ks-av-example')
          if (typeof ex === 'string') { card.textContent = ex }
          else {
            if (ex.japanese) card.appendChild(el('div', 'ks-jp', ex.japanese))
            if (ex.romaji) card.appendChild(el('div', 'ks-romaji', ex.romaji))
            if (ex.english) card.appendChild(el('div', 'ks-en', ex.english))
          }
          sec.appendChild(card)
        })
        body.appendChild(sec)
      }
      if (Array.isArray(content.sources) && content.sources.length) {
        const sec = el('section', 'ks-av-section')
        sec.appendChild(el('h3', 'ks-av-h3', 'Source References'))
        const ul = el('ul', 'ks-av-list muted')
        content.sources.forEach((s) => ul.appendChild(el('li', null, String(s))))
        sec.appendChild(ul)
        body.appendChild(sec)
      }
    }

    function drawEdit() {
      body.innerHTML = ''
      const summaryEd = el('textarea', 'ks-av-edit-area')
      summaryEd.value = content.summary || ''
      summaryEd.placeholder = 'Summary'
      body.appendChild(summaryEd)
      const sectionEditors = []
      ;(content.sections || []).forEach((section, idx) => {
        const sec = el('section', 'ks-av-section')
        const titleEd = el('input', 'ks-av-edit-title')
        titleEd.value = section.title || ''
        titleEd.placeholder = 'Section title'
        const bodyEd = el('textarea', 'ks-av-edit-area')
        bodyEd.value = section.body || ''
        bodyEd.placeholder = 'Section body'
        sec.appendChild(titleEd); sec.appendChild(bodyEd)
        body.appendChild(sec)
        sectionEditors.push({ idx, titleEd, bodyEd })
      })
      const toolbar = el('div', 'ks-av-edit-toolbar')
      toolbar.appendChild(iconButton('Save', 'save', async () => {
        try {
          const next = JSON.parse(JSON.stringify(content))
          next.summary = summaryEd.value
          sectionEditors.forEach(({ idx, titleEd, bodyEd }) => {
            if (next.sections && next.sections[idx]) { next.sections[idx].title = titleEd.value; next.sections[idx].body = bodyEd.value }
          })
          await ctx.onSaveContent(next)
          Object.assign(content, next)
          drawStatic()
          refreshIcons()
        } catch (err) {
          console.error('[KS] Note save failed:', err)
          alert('Saving the note failed: ' + (err && err.message ? err.message : err))
        }
      }))
      toolbar.appendChild(iconButton('Cancel', 'x', () => { drawStatic(); refreshIcons() }))
      body.appendChild(toolbar)
    }

    const actions = el('div', 'ks-av-note-actions')
    actions.appendChild(iconButton('Edit', 'pencil', () => { drawEdit(); refreshIcons() }))
    wrap.appendChild(actions)
    drawStatic()
    return wrap
  }

  /* ══ REPORT ══════════════════════════════════════════════════════════════ */
  // Schema: { title, summary, sections:[{title,body}], keyFindings:[], conclusions:[], sources:[] }
  function renderReport(artifact) {
    const content = artifact.content || {}
    if (!isPlainObject(content) || (!Array.isArray(content.sections) && typeof content.markdown !== 'string')) {
      return renderMarkdownDoc(content)
    }
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')
    if (content.summary) body.appendChild(el('p', 'ks-av-summary', content.summary))
    ;(content.sections || []).forEach((section) => {
      if (!section) return
      const sec = el('section', 'ks-av-section')
      if (section.title) sec.appendChild(el('h3', 'ks-av-h3', section.title))
      sec.appendChild(el('p', null, section.body || ''))
      body.appendChild(sec)
    })
    const listBlock = (title, items) => {
      if (!Array.isArray(items) || !items.length) return
      const sec = el('section', 'ks-av-section')
      sec.appendChild(el('h3', 'ks-av-h3', title))
      const ul = el('ul', 'ks-av-list')
      items.forEach((it) => ul.appendChild(el('li', null, String(it))))
      sec.appendChild(ul)
      body.appendChild(sec)
    }
    listBlock('Key Findings', content.keyFindings)
    listBlock('Conclusions', content.conclusions)
    listBlock('References', content.sources)
    wrap.appendChild(body)
    return wrap
  }

  /* ══ MIND MAP ════════════════════════════════════════════════════════════ */
  // Schema: { title, nodes:[{id,label,parentId,description?,type?,sourceReferences?}] }
  // OR nested: { title, root:{id,label,description,type,children:[...]} }
  // NotebookLM-style interactive knowledge graph: dynamic tree layout, pan, zoom,
  // fit-to-screen, node expand/collapse, source-backed detail card, export PNG/SVG/JSON.
  function renderMindMap(artifact) {
    let content = artifact.content || {}
    /* Safe destructure: never trust the payload shape. Tolerate wrapped
     * responses ({ data: {...} } / { artifactData: {...} }) and non-objects. */
    if (!isPlainObject(content)) content = {}
    if (!content.cards && !content.root && !content.nodes) {
      if (isPlainObject(content.data)) content = content.data
      else if (isPlainObject(content.artifactData)) content = content.artifactData
    }
    const hasCards = Array.isArray(content.cards) && content.cards.length > 0
    if (hasCards) {
      const board = renderMindMapCards(artifact)
      if (board) return board
    }
    const hasNested = isPlainObject(content.root)
    const hasFlat = Array.isArray(content.nodes) && content.nodes.length
    if (!hasNested && !hasFlat) {
      /* NEVER dump raw objects as "[object Object]" or blank screens —
       * early/async/invalid payloads get a clean blinking placeholder. */
      return renderMindMapPlaceholder(Array.isArray(content.cards)
        ? 'No valid cards in this mind map payload'
        : 'Waiting for mind map data…')
    }

    const rawNodes = []
    if (hasFlat) {
      content.nodes.forEach((n, i) => {
        rawNodes.push({
          id: mmSafeText(n && n.id, 'n' + i) || ('n' + i),
          label: mmSafeText(n && n.label, 'Untitled node'),
          parentId: n.parentId != null ? String(n.parentId) : null,
          description: n.description,
          type: n.type,
          sourceReferences: Array.isArray(n.sourceReferences) ? n.sourceReferences : []
        })
      })
    } else if (hasNested) {
      const walk = (raw, parentId) => {
        if (!raw || typeof raw !== 'object') return
        const id = String(raw.id ?? 'n' + Math.random().toString(36).slice(2, 9))
        rawNodes.push({
          id, label: String(raw.label ?? ''), parentId,
          description: raw.description, type: raw.type,
          sourceReferences: Array.isArray(raw.sourceReferences) ? raw.sourceReferences : []
        })
        if (Array.isArray(raw.children)) raw.children.forEach((c) => walk(c, id))
      }
      walk(content.root, null)
    }
        if (!rawNodes.length) return renderMarkdownDoc(content)

    /* ── Pre-render cleanup: label normalization + semantic dedup ──────────
     * Downcase, strip punctuation, and merge nodes that represent the same
     * concept (e.g., "Lesson 1 grammar" and "Lesson 1 Grammar"). The first
     * occurrence wins; children and sourceReferences are merged into it. */
    /* Deterministic meta/noise ban: file-statistics nodes ("212 Study Pages
     * Workbook", "English Language Medium") are never lesson content \u2014 drop them
     * before layout. A meta-level ROOT is relabeled from the artifact topic. */
    const ROOT_FALLBACK = mmSafeText(content.title, '')
    const filteredNodes = []
    const seenNodeIds = new Set()
    rawNodes.forEach((n) => {
      if (isMetaLabel(n.label)) {
        if (n.parentId == null && ROOT_FALLBACK && !isMetaLabel(ROOT_FALLBACK)) {
          n.label = ROOT_FALLBACK
          if (!n.type) n.type = 'root'
        } else {
          return
        }
      }
      if (seenNodeIds.has(n.id)) return
      seenNodeIds.add(n.id)
      filteredNodes.push(n)
    })
    rawNodes.length = 0
    rawNodes.push(...filteredNodes)
    const normIndex = new Map()
    const deduped = []
    rawNodes.forEach((n) => {
      const key = normalizeLabel(n.label)
      if (!key) {
        // Keep nodes with no label (edge case) — they can't be deduped.
        deduped.push(n)
        return
      }
      const existing = normIndex.get(key)
      if (existing) {
        existing.sourceReferences = [
          ...(existing.sourceReferences || []),
          ...(n.sourceReferences || [])
        ]
        if (!existing.description && n.description) existing.description = n.description
        if (!existing.type && n.type) existing.type = n.type
      } else {
        normIndex.set(key, n)
        deduped.push(n)
      }
    })
    rawNodes.length = 0
    rawNodes.push(...deduped)

    /* Root label fallback: if the root node has no label, use the artifact
     * title (e.g., "Minna no Nihongo Lesson 1"). */
    const rootNodes = hasNested
      ? [rawNodes.find((n) => !n.parentId)]
      : rawNodes.filter((n) => !n.parentId || !deduped.some((d) => d.id === n.parentId))
    rootNodes.forEach((r) => {
      if (r && !r.label && content.title) {
        r.label = mmSafeText(content.title, r.label || 'Mind Map')
        if (!r.type) r.type = 'root'
      }
    })

    const byId = new Map()
    rawNodes.forEach((n) => byId.set(n.id, { ...n, children: [], x: 0, y: 0, w: 120, h: 44 }))
    // Explicit edge-array support: some payloads ship {source,target} pairs
    // instead of parentId. Wire every target in as a child so the connector
    // renderer ALWAYS has a complete parent->child map to draw lines for.
    const wireEdge = (sourceId, targetId) => {
      if (sourceId == null || targetId == null) return
      const src = byId.get(String(sourceId))
      const tgt = byId.get(String(targetId))
      if (!src || !tgt || src === tgt) return
      if (!src.children.includes(tgt)) src.children.push(tgt)
      if (tgt.parentId == null) tgt.parentId = src.id
    }
    if (hasFlat && Array.isArray(content.edges)) {
      content.edges.forEach((e) => {
        if (!e || typeof e !== 'object') return
        wireEdge(e.source ?? e.parentId ?? e.from, e.target ?? e.childId ?? e.to)
      })
    }
    const roots = []
    byId.forEach((node) => {
      const parent = node.parentId && byId.get(node.parentId)
      if (parent && parent !== node && !parent.children.includes(node)) parent.children.push(node)
      else roots.push(node)
    })
    if (!roots.length) {
      const orphans = rawNodes.filter((n) => !n.parentId || !byId.has(n.parentId))
      roots.push(...(orphans.length ? orphans.slice(0, 1) : rawNodes.slice(0, 1)))
    }

    const MIN_W = 120, MAX_W = 280, MIN_H = 44, LINE_H = 18, H_GAP = 72, V_GAP = 52
    const estimateWidth = (text) => Math.min(MAX_W, Math.max(MIN_W, String(text || '').length * 7 + 16))
    byId.forEach((node) => {
      node.w = estimateWidth(node.label)
      if (node.description) {
        node.h = Math.max(MIN_H, MIN_H + Math.min(3, String(node.description).split('\n').length) * LINE_H)
      } else {
        node.h = MIN_H
      }
    })

    /* NotebookLM-style horizontal orthogonal tree layout.
     * Pass 1 assigns each node its depth column and records the WIDEST node
     * width in every column. Pass 2 derives column origins from those maxima
     * (origin[d] = origin[d-1] + maxWidth[d-1] + gap) so columns can NEVER
     * overlap horizontally no matter how wide a label grows.
     * Root sits at the leftmost column; children branch rightward.
     * Sibling subtrees each own a vertical band -> zero vertical overlap. */
    const depthMaxW = new Map()
    const assignDepth = (node, depth) => {
      node._depth = depth
      const cur = depthMaxW.get(depth) || 0
      if (node.w > cur) depthMaxW.set(depth, node.w)
      node.children.forEach((child) => assignDepth(child, depth + 1))
    }
    roots.forEach((r) => assignDepth(r, 0))
    const colOrigin = []
    let originX = 0
    const maxDepth = Math.max(0, ...Array.from(depthMaxW.keys()))
    for (let d = 0; d <= maxDepth; d++) {
      colOrigin.push(originX)
      originX += (depthMaxW.get(d) || MIN_W) + H_GAP
    }

    const doLayout = (node, depth, originY) => {
      node._x = colOrigin[depth] + node.w / 2
      if (!node.children.length) {
        node._y = originY + node.h / 2
        return { y: node._y, h: node.h }
      }
      let cursorY = originY
      const childResults = []
      node.children.forEach((child) => {
        const r = doLayout(child, depth + 1, cursorY)
        childResults.push(r)
        cursorY = r.y + r.h / 2 + V_GAP
      })
      const firstY = childResults[0].y
      const lastY = childResults[childResults.length - 1].y
      node._y = (firstY + lastY) / 2
      return { y: node._y, h: lastY - firstY + childResults[childResults.length - 1].h }
    }

    let cursorY = 0
    roots.forEach((r) => {
      const result = doLayout(r, 0, cursorY)
      cursorY = result.y + result.h / 2 + V_GAP
    })
    const bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity }
    byId.forEach((n) => {
      bounds.minX = Math.min(bounds.minX, n._x - n.w / 2)
      bounds.minY = Math.min(bounds.minY, n._y - n.h / 2)
      bounds.maxX = Math.max(bounds.maxX, n._x + n.w / 2)
      bounds.maxY = Math.max(bounds.maxY, n._y + n.h / 2)
    })

    const collapsed = new Set()
    const nodeElements = new Map()
    const view = { x: 0, y: 0, scale: 1 }
    let selectedNode = null

    const wrap = el('div', 'ks-mm')
    const controls = el('div', 'ks-mm-controls')
    const zoomLabel = el('span', 'ks-mm-zoom-label', '100%')
    const zoomIn = el('button', 'ks-mm-ctrl-btn', '+')
    zoomIn.type = 'button'; zoomIn.title = 'Zoom in'
    zoomIn.addEventListener('click', () => { view.scale = Math.min(view.scale * 1.2, 3); applyView() })
    const zoomOut = el('button', 'ks-mm-ctrl-btn', '−')
    zoomOut.type = 'button'; zoomOut.title = 'Zoom out'
    zoomOut.addEventListener('click', () => { view.scale = Math.max(view.scale / 1.2, 0.1); applyView() })
    const resetBtn = el('button', 'ks-mm-ctrl-btn', 'Reset')
    resetBtn.type = 'button'; resetBtn.title = 'Reset view'
    resetBtn.addEventListener('click', () => { view.scale = 1; view.x = 0; view.y = 0; applyView() })
    const fit = el('button', 'ks-mm-ctrl-btn wide', 'Fit')
    fit.type = 'button'; fit.title = 'Fit to screen'
    fit.addEventListener('click', fitToScreen)

    const exportMenu = el('div', 'ks-mm-ctrl-btn', 'Export')
    exportMenu.type = 'button'; exportMenu.title = 'Export mind map options'
    const exportDropdown = el('div', 'ks-mm-export-dropdown')
    ;['JSON', 'PNG', 'SVG'].forEach((fmt) => {
      const btn = el('button', 'ks-mm-export-opt', fmt)
      btn.type = 'button'
      btn.addEventListener('click', () => { exportGraph(fmt); exportDropdown.classList.remove('show') })
      exportDropdown.appendChild(btn)
    })
    exportMenu.addEventListener('click', (e) => { e.stopPropagation(); exportDropdown.classList.toggle('show') })
    document.addEventListener('click', () => exportDropdown.classList.remove('show'), { once: true })

    controls.appendChild(zoomIn); controls.appendChild(zoomOut); controls.appendChild(resetBtn)
    controls.appendChild(fit); controls.appendChild(exportMenu); controls.appendChild(exportDropdown)
    controls.appendChild(zoomLabel)
    wrap.appendChild(controls)

    const status = el('div', 'ks-mm-status', 'Drag to pan • Scroll to zoom • Click node for details • Double-click to collapse')
    wrap.appendChild(status)

    const viewport = el('div', 'ks-mm-viewport')
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.setAttribute('class', 'ks-mm-edges')
    svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
    // CRITICAL: default SVG overflow is hidden, so long L\u2192R connector
    // paths outside the container box would be invisible. Force it visible.
    svg.setAttribute('overflow', 'visible')
    svg.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none'
    const layer = el('div', 'ks-mm-nodes')
    viewport.appendChild(svg); viewport.appendChild(layer)
    wrap.appendChild(viewport)

    const NS = 'http://www.w3.org/2000/svg'

    function isHidden(node) {
      let cursor = node
      const visited = new Set()
      while (cursor && cursor.parentId && !visited.has(cursor.id)) {
        visited.add(cursor.id)
        if (collapsed.has(cursor.parentId)) return true
        const parent = byId.get(cursor.parentId)
        if (!parent) return true
        cursor = parent
      }
      return false
    }

    const TYPE_STYLES = {
      root: { border: '#1497d3', bg: 'linear-gradient(145deg,#062336,#041722)' },
      topic: { border: '#22c7f2', bg: 'linear-gradient(145deg,#081f2c,#04111a)' },
      subtopic: { border: '#1d6c84', bg: 'linear-gradient(145deg,#071a27,#04111a)' },
      concept: { border: '#2aa298', bg: 'linear-gradient(145deg,#081a2a,#040f1a)' },
      rule: { border: '#7c4dff', bg: 'linear-gradient(145deg,#1a1f2a,#0f111a)' },
      example: { border: '#ffd43d', bg: 'linear-gradient(145deg,#1f1a08,#1a1404)' },
      definition: { border: '#f78268', bg: 'linear-gradient(145deg,#1a081f,#1a041a)' },
      reference: { border: '#8ee8ff', bg: 'linear-gradient(145deg,#0a0a1a,#040414)' }
    }

    function drawEdges() {
      svg.innerHTML = ''
      byId.forEach((node) => {
        if (collapsed.has(node.id)) return
        node.children.forEach((child) => {
          if (isHidden(child)) return
          const path = document.createElementNS(NS, 'path')
          // Horizontal orthogonal connector: parent RIGHT edge → child LEFT edge.
          // Control points keep tangents horizontal so the graph reads left→right.
          const x1 = node._x + node.w / 2, y1 = node._y
          const x2 = child._x - child.w / 2, y2 = child._y
          const mx = (x1 + x2) / 2
          path.setAttribute('d', `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`)
          path.setAttribute('class', 'ks-mm-edge')
          path.dataset.parentId = node.id
          path.dataset.childId = child.id
          svg.appendChild(path)
        })
      })
    }

    function drawNodes() {
      layer.innerHTML = ''
      byId.forEach((node) => {
        if (isHidden(node)) return
        const cls = 'ks-mm-node' + (node.parentId == null ? ' root' : '') + (node.type ? ' type-' + node.type : '')
        const chip = el('div', cls)
        chip.style.width = node.w + 'px'
        chip.style.height = node.h + 'px'
        chip.style.minWidth = node.w + 'px'
        chip.style.left = (node._x - node.w / 2) + 'px'
        chip.style.top = (node._y - node.h / 2) + 'px'
        const style = TYPE_STYLES[node.type] || TYPE_STYLES.topic
        chip.style.background = style.bg
        chip.style.borderColor = style.border

        const labelDiv = el('div', 'ks-mm-node-label')
        labelDiv.textContent = node.label || node.id
        chip.appendChild(labelDiv)
        if (node.type && node.type !== 'root') {
          const badge = el('span', 'ks-mm-type-badge', node.type)
          chip.appendChild(badge)
        }
        if (node.children && node.children.length) {
          const marker = el('span', 'ks-mm-collapse-marker')
          marker.textContent = collapsed.has(node.id) ? '+' : '−'
          chip.appendChild(marker)
        }
        if (node.sourceReferences && node.sourceReferences.length) chip.classList.add('has-refs')
        chip.dataset.nodeId = node.id
        nodeElements.set(node.id, chip)

        /* Double-click disambiguation: a short timer delays the single-click
         * (select + detail) action. If a second click arrives first, the timer
         * is cancelled and the collapse/expand action takes over. This prevents
         * the detail card from flashing open on every collapse/expand. */
        let clickTimer = null
        chip.addEventListener('click', (event) => {
          event.stopPropagation()
          if (!node.children.length && !clickTimer) {
            layer.querySelectorAll('.ks-mm-node.selected').forEach((n) => n.classList.remove('selected'))
            chip.classList.add('selected')
            selectedNode = node
            showDetail(node)
            return
          }
          if (clickTimer) {
            clearTimeout(clickTimer)
            clickTimer = null
            if (collapsed.has(node.id)) collapsed.delete(node.id)
            else collapsed.add(node.id)
            redraw()
            status.textContent = `${node.label}: ${collapsed.has(node.id) ? 'branch collapsed' : 'branch expanded'}`
          } else {
            clickTimer = setTimeout(() => {
              clickTimer = null
              layer.querySelectorAll('.ks-mm-node.selected').forEach((n) => n.classList.remove('selected'))
              chip.classList.add('selected')
              selectedNode = node
              showDetail(node)
            }, 220)
          }
        })
        chip.addEventListener('contextmenu', (e) => { e.preventDefault(); showNodeContextMenu(node, e) })
        layer.appendChild(chip)
      })
    }

    let detailCard = null, detailTitle = null, detailBody = null, detailAbort = null, detailNode = null
    function showDetail(node) {
      if (!detailCard) {
        detailCard = el('div', 'ks-mm-detail')
        const head = el('div', 'ks-mm-detail-head')
        detailTitle = el('strong', 'ks-mm-detail-title')
        const closeBtn = el('button', 'ks-mm-detail-close', '×')
        closeBtn.type = 'button'; closeBtn.title = 'Close'
        closeBtn.addEventListener('click', (event) => { event.stopPropagation(); hideDetail() })
        head.appendChild(detailTitle); head.appendChild(closeBtn)
        detailBody = el('div', 'ks-mm-detail-body')
        const foot = el('div', 'ks-mm-detail-foot')
        detailCard.appendChild(head); detailCard.appendChild(detailBody); detailCard.appendChild(foot)
        detailCard.addEventListener('pointerdown', (event) => event.stopPropagation())
        wrap.appendChild(detailCard)
      }
      detailNode = node
      detailTitle.textContent = node.label || node.id
      let html = ''
      if (node.type) html += '<span class="ks-mm-node-type">' + node.type + '</span>'
      if (node.description) html += '<p class="ks-mm-detail-desc">' + escapeHtml(node.description) + '</p>'
      detailBody.innerHTML = html
      if (node.sourceReferences && node.sourceReferences.length) {
        const srcDiv = el('div', 'ks-mm-detail-sources')
        srcDiv.innerHTML = '<h4 style="color:#2fd6ff;margin:6px 0;font-size:11px">Sources</h4>'
        node.sourceReferences.forEach((ref) => {
          const line = el('div', 'ks-mm-detail-src-line')
          line.innerHTML = '<span class="ks-mm-src-name">' + escapeHtml(ref.source || 'Unknown') + (ref.page != null ? ' p.' + ref.page : '') + '</span> - <code class="ks-mm-src-snippet">' + escapeHtml((ref.snippet || '').slice(0, 220)) + '</code>'
          srcDiv.appendChild(line)
        })
        detailBody.appendChild(srcDiv)
      } else {
        const note = el('div', null)
        note.style.cssText = 'color:#5c8ba0;font-size:11px;margin-top:6px;'
        note.textContent = 'No direct source reference for this node.'
        detailBody.appendChild(note)
      }
      detailBody.scrollTop = 0
      detailCard.style.display = 'flex'
    }

    function hideDetail() {
      if (detailAbort) { try { detailAbort.abort() } catch (e) {} }
      detailNode = null
      if (detailCard) detailCard.style.display = 'none'
    }

    function showNodeContextMenu(node, event) {
      const menu = el('div', 'ks-mm-ctx-menu')
      menu.style.left = event.clientX + 'px'
      menu.style.top = event.clientY + 'px'
      const addAction = (label, cb) => {
        const item = el('button', 'ks-mm-ctx-item', label)
        item.type = 'button'
        item.addEventListener('click', (e) => { e.stopPropagation(); cb(); menu.remove() })
        menu.appendChild(item)
      }
      if (node.children && node.children.length) {
        addAction(collapsed.has(node.id) ? 'Expand branch' : 'Collapse branch', () => {
          if (collapsed.has(node.id)) collapsed.delete(node.id)
          else collapsed.add(node.id)
          redraw()
        })
      }
      addAction('Copy label', () => { navigator.clipboard.writeText(node.label || '') })
      addAction('Explain with KAMI-SENSEI', () => explainNode(node, null))
      document.body.appendChild(menu)
    }

    async function explainNode(node, btn) {
      if (detailAbort) { try { detailAbort.abort() } catch (e) {} }
      detailAbort = new AbortController()
      if (btn) { btn.disabled = true; btn.textContent = 'Explaining…' }
      showDetail(node)
      detailBody.innerHTML = '<p>KAMI-SENSEI is thinking…</p>'
      let reply = '', errored = ''
      const sourceIds = (artifact.requestedSourceIds || artifact.sourceIds || [])
      try {
        const response = await fetch('/api/kamisensei/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: 'From the mind map "' + artifact.title + '", explain "' + node.label + '" in 3-5 short sentences.', sourceIds: sourceIds, history: [] }),
          signal: detailAbort.signal
        })
        if (!response.ok || !response.body) throw new Error('HTTP ' + response.status)
        const reader = response.body.getReader(), decoder = new TextDecoder()
        let buffer = ''
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })
          const frames = buffer.split(/\r?\n\r?\n/)
          buffer = frames.pop() || ''
          for (const frame of frames) {
            let event = 'message', data = ''
            for (const line of frame.split(/\r?\n/)) {
              if (line.startsWith('event:')) event = line.slice(6).trim()
              else if (line.startsWith('data:')) data += line.slice(5).trim()
            }
            if (!data) continue
            try {
              const p = JSON.parse(data)
              if (event === 'token') reply += String(p.t || '')
              else if (event === 'done' && !reply) reply = String(p.reply || '')
              else if (event === 'error') errored = String(p.error || 'Stream failure')
            } catch (e) {}
          }
          if (reply) detailBody.innerHTML = '<p>' + escapeHtml(reply).replace(/\n/g, '</p><p>') + '</p>'
          if (errored) break
        }
        if (errored) throw new Error(errored)
        if (!reply.trim()) throw new Error('Empty response')
      } catch (err) {
        detailBody.innerHTML = '<p style="color:#ff7b7b">Failed: ' + escapeHtml(err && err.message ? err.message : err) + '</p>'
      } finally {
        detailAbort = null
        if (btn) { btn.disabled = false; btn.textContent = 'Explain with KAMI-SENSEI' }
      }
    }

    function applyView() {
      viewport.style.transform = 'translate(' + view.x + 'px, ' + view.y + 'px) scale(' + view.scale + ')'
      zoomLabel.textContent = Math.round(view.scale * 100) + '%'
    }

    function fitToScreen() {
      const rect = wrap.getBoundingClientRect()
      if (!rect.width || !rect.height) return requestAnimationFrame(fitToScreen)
      const bw = bounds.maxX - bounds.minX + 48
      const bh = bounds.maxY - bounds.minY + 48
      const scale = Math.min(rect.width / bw, rect.height / bh, 1.4)
      view.scale = Math.max(scale, 0.1)
      const cx = bounds.minX + (bounds.maxX - bounds.minX) / 2
      const cy = bounds.minY + (bounds.maxY - bounds.minY) / 2
      view.x = rect.width / 2 - cx * view.scale
      view.y = rect.height / 2 - cy * view.scale
      applyView()
    }

    let panning = null
    wrap.addEventListener('pointerdown', (event) => {
      if (event.target.closest('.ks-mm-node') || event.target.closest('.ks-mm-controls')) return
      if (event.target.closest('.ks-mm-ctx-menu') || (detailCard && detailCard.contains(event.target))) return
      panning = { px: event.clientX, py: event.clientY, x: view.x, y: view.y }
      wrap.classList.add('panning')
      try { wrap.setPointerCapture(event.pointerId) } catch (err) { console.warn('[KS] pointer capture failed:', err) }
    })
    wrap.addEventListener('pointermove', (event) => {
      if (!panning) return
      view.x = panning.x + (event.clientX - panning.px)
      view.y = panning.y + (event.clientY - panning.py)
      applyView()
    })
    const endPan = (event) => {
      if (!panning) return
      try { wrap.releasePointerCapture(event.pointerId) } catch (err) { console.debug('[KS] pointer already released') }
      panning = null; wrap.classList.remove('panning')
    }
    wrap.addEventListener('pointerup', endPan)
    wrap.addEventListener('pointercancel', endPan)

    wrap.addEventListener('wheel', (event) => {
      event.preventDefault()
      const rect = wrap.getBoundingClientRect()
      const cx = event.clientX - rect.left
      const cy = event.clientY - rect.top
      const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12
      const next = Math.min(Math.max(view.scale * factor, 0.1), 3)
      const ratio = next / view.scale
      view.x = cx - (cx - view.x) * ratio
      view.y = cy - (cy - view.y) * ratio
      view.scale = next
      applyView()
    }, { passive: false })

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.ks-mm-node') && !e.target.closest('.ks-mm-ctx-menu')) {
        layer.querySelectorAll('.ks-mm-node.selected').forEach((n) => n.classList.remove('selected'))
        selectedNode = null; hideDetail()
      }
    })

    function redraw() { drawEdges(); drawNodes(); applyView() }

    async function exportGraph(fmt) {
      try {
        if (fmt === 'JSON') {
          const blob = new Blob([JSON.stringify(artifact, null, 2)], { type: 'application/json' })
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url; a.download = (artifact.title || 'mind-map').replace(/[^\w.-]+/g, '_') + '.json'
          document.body.appendChild(a); a.click(); a.remove()
          setTimeout(() => URL.revokeObjectURL(url), 2000)
        } else if (fmt === 'SVG') {
          const svgW = bounds.maxX - bounds.minX + 48, svgH = bounds.maxY - bounds.minY + 48
          const out = document.createElementNS(NS, 'svg')
          out.setAttribute('xmlns', NS)
          out.setAttribute('width', svgW); out.setAttribute('height', svgH)
          out.setAttribute('viewBox', '0 0 ' + svgW + ' ' + svgH)
          const bg = document.createElementNS(NS, 'rect')
          bg.setAttribute('width', '100%'); bg.setAttribute('height', '100%'); bg.setAttribute('fill', '#04111a')
          out.appendChild(bg)
          byId.forEach((node) => {
            if (isHidden(node)) return
            node.children.forEach((child) => {
              if (isHidden(child)) return
              const p2 = document.createElementNS(NS, 'path')
              // Same horizontal orthogonal connector as the live edge renderer.
              const x1 = node._x + node.w / 2, y1 = node._y
              const x2 = child._x - child.w / 2, y2 = child._y
              const mx = (x1 + x2) / 2
              p2.setAttribute('d', 'M ' + (x1 - bounds.minX + 24) + ' ' + (y1 - bounds.minY + 24) + ' C ' + (mx - bounds.minX + 24) + ' ' + (y1 - bounds.minY + 24) + ', ' + (mx - bounds.minX + 24) + ' ' + (y2 - bounds.minY + 24) + ', ' + (x2 - bounds.minX + 24) + ' ' + (y2 - bounds.minY + 24))
              p2.setAttribute('stroke', 'rgba(41,114,147,.55)'); p2.setAttribute('stroke-width', '1.6'); p2.setAttribute('fill', 'none')
              out.appendChild(p2)
            })
          })
          byId.forEach((node) => {
            if (isHidden(node)) return
            const g = document.createElementNS(NS, 'g')
            const nx = node._x - node.w / 2 - bounds.minX + 24
            const ny = node._y - node.h / 2 - bounds.minY + 24
            const rect = document.createElementNS(NS, 'rect')
            rect.setAttribute('x', nx); rect.setAttribute('y', ny)
            rect.setAttribute('width', node.w); rect.setAttribute('height', node.h)
            rect.setAttribute('fill', '#081f2c'); rect.setAttribute('stroke', (TYPE_STYLES[node.type] || TYPE_STYLES.topic).border); rect.setAttribute('stroke-width', '1'); rect.setAttribute('rx', '9')
            g.appendChild(rect)
            const text = document.createElementNS(NS, 'text')
            text.setAttribute('x', nx + node.w / 2); text.setAttribute('y', ny + node.h / 2 + 4)
            text.setAttribute('fill', '#e5f7fc'); text.setAttribute('font-family', 'Rajdhani,sans-serif'); text.setAttribute('font-size', '11')
            text.setAttribute('text-anchor', 'middle'); text.setAttribute('dominant-baseline', 'middle')
            text.textContent = node.label || ''
            g.appendChild(text); out.appendChild(g)
          })
          const svgStr = new XMLSerializer().serializeToString(out)
          const blob = new Blob([svgStr], { type: 'image/svg+xml' })
          const url = URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url; a.download = (artifact.title || 'mind-map').replace(/[^\w.-]+/g, '_') + '.svg'
          document.body.appendChild(a); a.click(); a.remove()
          setTimeout(() => URL.revokeObjectURL(url), 2000)
        } else if (fmt === 'PNG') {
          if (window.html2canvas) {
            await window.html2canvas(viewport).then((canvas) => {
              const url = canvas.toDataURL('image/png')
              const a = document.createElement('a')
              a.href = url; a.download = (artifact.title || 'mind-map').replace(/[^\w.-]+/g, '_') + '.png'
              document.body.appendChild(a); a.click(); a.remove()
            })
          } else {
            alert('PNG export requires html2canvas. JSON and SVG are available.')
          }
        }
      } catch (err) {
        console.error('[KS] Export failed:', err)
        alert('Export failed: ' + (err && err.message ? err.message : err))
      }
      exportDropdown.classList.remove('show')
    }

    drawEdges(); drawNodes()
    requestAnimationFrame(fitToScreen)

    if ('ResizeObserver' in window) {
      let resizeFrame = 0
      const observer = new ResizeObserver(() => {
        cancelAnimationFrame(resizeFrame)
        resizeFrame = requestAnimationFrame(fitToScreen)
      })
      observer.observe(wrap)
      const cleanup = new MutationObserver(() => {
        if (!wrap.isConnected) { observer.disconnect(); cleanup.disconnect() }
      })
      cleanup.observe(document.body, { childList: true, subtree: true })
    }

    return wrap
  }
  /* ══ FLASHCARDS ══════════════════════════════════════════════════════════ */
  // Schema: { title, cards:[{front, back, explanation?, example?, source?}] }
  // Interactive deck: flip, previous/next, progress. Front = Japanese/question,
  // back = reading/romaji/meaning/explanation.
  /* ══ MIND MAP — DYNAMIC GENERATIVE CARD BOARD (schema v2) ═════════════════
   * Maps the AI-determined taxonomy contract:
   * { title, cards: [{ id, headerTitle, themeColor, iconType, bulletPoints }] }
   * No fixed category presets — every tab label, accent trim and checkbox is
   * driven by the payload. Falls back to the tree renderer when degenerate. */
  const MM_CARD_THEMES = ['pink', 'purple', 'teal', 'green', 'orange', 'amber']
  const MM_META_LABEL_RE = /(study\s*pages?|workbook|language\s*medium|\bpdf\b|file\s*size|page\s*count|\bocr\b|extraction\s*stat|word\s*count|table\s*of\s*contents|\d+\s*pages?\b)/i
  const MM_CARD_ICONS = { grammar: '\u00a7', settings: '\u2699', group: '\u2766', list: '\u2630', checklist: '\u2611', default: '\u25c6' }
  const MM_ZOOM_MIN = 0.4
  const MM_ZOOM_MAX = 2

  function mmSemanticKey(text) {
    return String(text).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim()
  }

  /* STRICT type guard — the only sanctioned path from payload values into
   * text nodes. Objects/numbers/undefined can never reach the DOM as
   * "[object Object]"; they collapse to the fallback string. */
  function mmSafeText(value, fallback) {
    if (typeof value === 'string') {
      const t = value.replace(/\s+/g, ' ').trim()
      if (t) return t
    }
    return typeof fallback === 'string' ? fallback : ''
  }

  function mmCardsStateKey(artifact) {
    return 'jarvis-mm-cards-' + mmSafeText((artifact && artifact.id) || (artifact && artifact.title) || 'board', 'board').replace(/[^a-zA-Z0-9_-]+/g, '_')
  }

  /* Clean async/empty-state placeholder — never a blank black viewport. */
  function renderMindMapPlaceholder(message) {
    const wrap = el('div', 'ks-mm ks-mm-placeholder')
    const box = el('div', 'ks-mm-placeholder-box')
    box.appendChild(el('span', 'ks-mm-placeholder-dot'))
    box.appendChild(el('span', 'ks-mm-placeholder-dot'))
    box.appendChild(el('span', 'ks-mm-placeholder-dot'))
    wrap.appendChild(box)
    wrap.appendChild(el('div', 'ks-mm-placeholder-msg', mmSafeText(message, 'Preparing mind map…')))
    return wrap
  }

  function renderMindMapCards(artifact) {
    let content = isPlainObject(artifact.content) ? artifact.content : {}
    if (!content.cards && !content.root && !content.nodes) {
      if (isPlainObject(content.data)) content = content.data
      else if (isPlainObject(content.artifactData)) content = content.artifactData
    }
    const seenCards = new Set()
    const cards = (Array.isArray(content.cards) ? content.cards : []).map((raw, i) => {
      if (!isPlainObject(raw)) return null
      const headerTitle = mmSafeText(raw.headerTitle, '')
      if (!headerTitle || MM_META_LABEL_RE.test(headerTitle)) return null
      const key = mmSemanticKey(headerTitle)
      if (!key || seenCards.has(key)) return null
      seenCards.add(key)
      const themeRaw = typeof raw.themeColor === 'string' ? raw.themeColor : ''
      const themeColor = MM_CARD_THEMES.includes(themeRaw) ? themeRaw : MM_CARD_THEMES[i % MM_CARD_THEMES.length]
      const iconRaw = typeof raw.iconType === 'string' ? raw.iconType : ''
      const iconType = MM_CARD_ICONS[iconRaw] ? iconRaw : 'default'
      const seenBullets = new Set()
      const bulletPoints = (Array.isArray(raw.bulletPoints) ? raw.bulletPoints : []).map((b) => {
        const text = isPlainObject(b)
          ? mmSafeText(b.text, '')
          : (typeof b === 'string' ? b.replace(/\s+/g, ' ').trim() : '')
        const hasCheckbox = !!(isPlainObject(b) && b.hasCheckbox === true)
        if (!text || MM_META_LABEL_RE.test(text)) return null
        const bk = mmSemanticKey(text)
        if (!bk || seenBullets.has(bk)) return null
        seenBullets.add(bk)
        return { text, hasCheckbox }
      }).filter(Boolean)
      if (!bulletPoints.length) return null
      const rawId = typeof raw.id === 'string' ? raw.id.trim().replace(/\s+/g, '_') : ''
      return { id: rawId || 'card_' + (i + 1), headerTitle, themeColor, iconType, bulletPoints }
    }).filter(Boolean)
    /* One valid card is a legitimate board — only a zero-card payload
     * falls back to the placeholder path. */
    if (!cards.length) return null

    const wrap = el('div', 'ks-mm ks-mm-cards')
    wrap.tabIndex = 0
    const stateKey = mmCardsStateKey(artifact)
    let saved = {}
    try { saved = JSON.parse(localStorage.getItem(stateKey) || '{}') || {} } catch (e) { saved = {} }
    const checkedKeys = new Set(Array.isArray(saved.checked) ? saved.checked.map(String) : [])
    function persist() {
      try { localStorage.setItem(stateKey, JSON.stringify({ zoom: Math.round(zoom * 100) / 100, checked: [...checkedKeys] })) } catch (e) { /* storage unavailable */ }
    }

    /* toolbar — + / − / Reset / Fit bound to this board's viewport hooks */
    const bar = el('div', 'ks-mm-controls')
    bar.appendChild(el('strong', 'ks-mm-title', mmSafeText(content.title, mmSafeText(artifact.title, 'Mind Map'))))
    const status = el('span', 'ks-mm-status')
    const mkBtn = (label, titleAttr, fn) => {
      const b = el('button', 'ks-mm-ctrl-btn', label)
      b.type = 'button'; b.title = titleAttr
      b.addEventListener('click', (ev) => { ev.stopPropagation(); fn() })
      return b
    }
    bar.appendChild(status)
    bar.appendChild(mkBtn('+', 'Zoom in', () => { zoom = Math.min(MM_ZOOM_MAX, zoom * 1.2); applyView(); persist() }))
    bar.appendChild(mkBtn('\u2212', 'Zoom out', () => { zoom = Math.max(MM_ZOOM_MIN, zoom / 1.2); applyView(); persist() }))
    bar.appendChild(mkBtn('Reset', 'Reset view', () => { zoom = 1; tx = 16; ty = 16; applyView(); persist() }))
    bar.appendChild(mkBtn('Fit', 'Fit to screen', fitToScreen))
    wrap.appendChild(bar)

    /* viewport + horizontally unbounded track — extra cards grid-spawn into
     * new columns forever; the track never wraps and never freezes. */
    const viewport = el('div', 'ks-mm-cards-viewport')
    const canvas = el('div', 'ks-mm-cards-track')
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
    svg.setAttribute('class', 'ks-mm-cards-edges')

    cards.forEach((card, i) => {
      const cardEl = el('div', 'ks-mm-card theme-' + card.themeColor + ' icon-' + card.iconType)
      cardEl.dataset.cardId = card.id
      const tab = el('div', 'ks-mm-card-tab')
      tab.appendChild(el('span', 'ks-mm-card-icon', MM_CARD_ICONS[card.iconType] || '\u25c6'))
      tab.appendChild(el('span', 'ks-mm-card-tab-label', card.headerTitle))
      cardEl.appendChild(tab)
      const body = el('ul', 'ks-mm-card-body')
      card.bulletPoints.forEach((b, j) => {
        const li = el('li', 'ks-mm-bullet' + (b.hasCheckbox ? ' has-checkbox' : ''))
        const key = card.id + ':' + j
        if (b.hasCheckbox) {
          const box = el('button', 'ks-mm-checkbox')
          box.type = 'button'
          const mark = el('span', 'ks-mm-checkbox-mark')
          mark.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 9 Q5 11 6.2 12.2 Q9.5 5.5 13.2 3.6" fill="none"/></svg>'
          box.appendChild(mark)
          const applyCheck = () => {
            box.classList.toggle('checked', checkedKeys.has(key))
            box.setAttribute('aria-pressed', checkedKeys.has(key) ? 'true' : 'false')
            li.classList.toggle('done', checkedKeys.has(key))
          }
          box.addEventListener('click', (ev) => {
            ev.stopPropagation()
            if (checkedKeys.has(key)) checkedKeys.delete(key); else checkedKeys.add(key)
            applyCheck(); persist()
          })
          applyCheck()
          li.appendChild(box)
        } else {
          li.appendChild(el('span', 'ks-mm-bullet-dot'))
        }
        li.appendChild(el('span', 'ks-mm-bullet-text', b.text))
        body.appendChild(li)
      })
      cardEl.appendChild(body)
      canvas.appendChild(cardEl)
    })

    canvas.insertBefore(svg, canvas.firstChild)
    viewport.appendChild(canvas)
    wrap.appendChild(viewport)

    /* curvy SVG connector arrows — parent card right edge → next card left
     * edge, stroked in the target card's theme color with matching arrowhead */
    const SVG_NS = 'http://www.w3.org/2000/svg'
    function drawEdges() {
      while (svg.firstChild) svg.removeChild(svg.firstChild)
      const defs = document.createElementNS(SVG_NS, 'defs')
      MM_CARD_THEMES.forEach((t) => {
        const marker = document.createElementNS(SVG_NS, 'marker')
        marker.setAttribute('id', 'ks-mm-arrow-' + t)
        marker.setAttribute('viewBox', '0 0 10 10')
        marker.setAttribute('refX', '9'); marker.setAttribute('refY', '5')
        marker.setAttribute('markerWidth', '7'); marker.setAttribute('markerHeight', '7')
        marker.setAttribute('orient', 'auto-start-reverse')
        const head = document.createElementNS(SVG_NS, 'path')
        head.setAttribute('d', 'M0 0 L10 5 L0 10 z')
        head.style.fill = 'var(--ks-mm-' + t + ')'
        marker.appendChild(head)
        defs.appendChild(marker)
      })
      svg.appendChild(defs)
      const w = Math.max(canvas.scrollWidth, 1)
      const h = Math.max(canvas.scrollHeight, 1)
      svg.setAttribute('width', String(w)); svg.setAttribute('height', String(h))
      svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h)
      const cardEls = canvas.querySelectorAll('.ks-mm-card')
      for (let i = 0; i + 1 < cardEls.length; i++) {
        const a = cardEls[i], b = cardEls[i + 1]
        const x1 = a.offsetLeft + a.offsetWidth, y1 = a.offsetTop + a.offsetHeight / 2
        const x2 = b.offsetLeft, y2 = b.offsetTop + b.offsetHeight / 2
        const dx = Math.max(24, (x2 - x1) * 0.55)
        const path = document.createElementNS(SVG_NS, 'path')
        path.setAttribute('class', 'ks-mm-cards-edge')
        path.setAttribute('d', 'M' + x1 + ' ' + y1 + ' C ' + (x1 + dx) + ' ' + y1 + ', ' + (x2 - dx) + ' ' + y2 + ', ' + x2 + ' ' + y2)
        path.setAttribute('marker-end', 'url(#ks-mm-arrow-' + cards[i + 1].themeColor + ')')
        path.style.stroke = 'var(--ks-mm-' + cards[i + 1].themeColor + ')'
        svg.appendChild(path)
      }
    }

    /* view engine — translate + scale on the track; zoom 0.4x–2x */
    let zoom = typeof saved.zoom === 'number' && saved.zoom >= MM_ZOOM_MIN && saved.zoom <= MM_ZOOM_MAX ? saved.zoom : 0
    let tx = 16, ty = 16
    function applyView() {
      canvas.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + zoom + ')'
      status.textContent = Math.round(zoom * 100) + '% \u00b7 ' + cards.length + ' cards'
    }
    function fitToScreen() {
      drawEdges()
      const w = Math.max(canvas.scrollWidth, 1)
      const h = Math.max(canvas.scrollHeight, 1)
      const s = Math.min((viewport.clientWidth - 32) / w, (viewport.clientHeight - 32) / h, 1.15)
      zoom = Math.max(MM_ZOOM_MIN, s)
      tx = Math.max(16, (viewport.clientWidth - w * zoom) / 2)
      ty = Math.max(16, (viewport.clientHeight - h * zoom) / 2)
      applyView(); persist()
    }
    if (!zoom) { requestAnimationFrame(fitToScreen) } else { requestAnimationFrame(applyView) }

    /* pointer-drag panning (buttons/checkboxes excluded) */
    let panning = null
    viewport.addEventListener('pointerdown', (ev) => {
      if (ev.target.closest('.ks-mm-checkbox, .ks-mm-ctrl-btn')) return
      panning = { x: ev.clientX, y: ev.clientY, tx, ty }
      viewport.classList.add('panning')
      viewport.setPointerCapture(ev.pointerId)
    })
    viewport.addEventListener('pointermove', (ev) => {
      if (!panning) return
      tx = panning.tx + (ev.clientX - panning.x)
      ty = panning.ty + (ev.clientY - panning.y)
      applyView()
    })
    const endPan = () => { if (panning) { panning = null; viewport.classList.remove('panning'); persist() } }
    viewport.addEventListener('pointerup', endPan)
    viewport.addEventListener('pointercancel', endPan)

    /* re-fit when the panel resizes — single observer, no render loops */
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(fitFrame)
      fitFrame = requestAnimationFrame(fitToScreen)
    })
    let fitFrame = 0
    observer.observe(wrap)
    const cleanup = new MutationObserver(() => {
      if (!wrap.isConnected) { observer.disconnect(); cleanup.disconnect() }
    })
    cleanup.observe(document.body, { childList: true, subtree: true })

    return wrap
  }
  /* ══ FLASHCARDS ═══════════════════════════════════════════════════════════ */
  // Schema: { title, cards:[{front, back, explanation?, example?, source?}] }
  // Interactive deck: flip, previous/next, progress. Front = Japanese/question,
  // back = reading/romaji/meaning/explanation.
  function renderFlashcards(artifact) {
    const content = artifact.content || {}
    const cards = isPlainObject(content) && Array.isArray(content.cards) ? content.cards : (Array.isArray(content) ? content : null)
    if (!cards || !cards.length) return renderMarkdownDoc(content)

    const wrap = el('div', 'ks-fc')
    wrap.tabIndex = 0
    let deck = cards.slice()
    let index = 0
    let flipped = false

    const stage = el('div', 'ks-fc-stage')
    const cardOuter = el('div', 'ks-fc-card')
    const cardInner = el('div', 'ks-fc-card-inner')
    const front = el('div', 'ks-fc-face ks-fc-front')
    const back = el('div', 'ks-fc-face ks-fc-back')
    cardInner.appendChild(front); cardInner.appendChild(back)
    cardOuter.appendChild(cardInner)
    stage.appendChild(cardOuter)
    wrap.appendChild(stage)

    const progress = el('div', 'ks-fc-progress', '')
    const controls = el('div', 'ks-fc-controls')
    const prevBtn = iconButton('Previous', 'chevron-left', () => { index = (index - 1 + deck.length) % deck.length; flipped = false; draw() })
    const flipBtn = iconButton('Flip', 'refresh-cw', () => { flipped = !flipped; draw() })
    const nextBtn = iconButton('Next', 'chevron-right', () => { index = (index + 1) % deck.length; flipped = false; draw() })
    const shuffleBtn = iconButton('Shuffle', 'shuffle', () => {
      for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[deck[i], deck[j]] = [deck[j], deck[i]]
      }
      index = 0
      flipped = false
      draw()
    })
    const restartBtn = iconButton('Restart', 'rotate-ccw', () => {
      deck = cards.slice()
      index = 0
      flipped = false
      draw()
    })
    controls.appendChild(prevBtn); controls.appendChild(flipBtn); controls.appendChild(nextBtn); controls.appendChild(shuffleBtn); controls.appendChild(restartBtn)
    wrap.appendChild(progress)
    wrap.appendChild(controls)

    // Click or press Space to flip. Keyboard handling is scoped to the focused
    // artifact so it never hijacks typing elsewhere in JARVIS.
    cardOuter.addEventListener('click', () => { wrap.focus(); flipped = !flipped; draw() })
    wrap.addEventListener('keydown', (event) => {
      if (event.key === ' ') {
        event.preventDefault()
        flipped = !flipped
        draw()
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault(); prevBtn.click()
      } else if (event.key === 'ArrowRight') {
        event.preventDefault(); nextBtn.click()
      }
    })

    function draw() {
      const card = deck[index] || {}
      front.innerHTML = ''
      back.innerHTML = ''
      const fLabel = el('span', 'ks-fc-side-label', 'Front')
      front.appendChild(fLabel)
      front.appendChild(el('div', 'ks-fc-main', String(card.front ?? '')))
      const bLabel = el('span', 'ks-fc-side-label', 'Back')
      back.appendChild(bLabel)
      back.appendChild(el('div', 'ks-fc-main', String(card.back ?? '')))
      if (card.explanation) back.appendChild(el('div', 'ks-fc-sub', String(card.explanation)))
      if (card.example) back.appendChild(el('div', 'ks-fc-sub em', String(card.example)))
      if (card.source) {
        const pageLabel = card.page ? ` • Page ${card.page}` : ''
        back.appendChild(el('div', 'ks-fc-src', 'Source: ' + String(card.source) + pageLabel))
      }
      cardInner.classList.toggle('flipped', flipped)
      progress.textContent = `${index + 1} / ${deck.length}`
      cardOuter.classList.remove('anim')
      void cardOuter.offsetWidth // restart flip animation
      cardOuter.classList.add('anim')
    }
    draw()
    return wrap
  }

  /* ══ QUIZ ════════════════════════════════════════════════════════════════ */
  // Schema: { title, questions:[{question, options[], correctAnswer, explanation}] }
  // Interactive: answer first, then reveal correctness + explanation. Score,
  // percentage, correct/incorrect counts and missed-question review at the end.
  function renderQuiz(artifact) {
    const content = artifact.content || {}
    const questions = Array.isArray(content.questions) ? content.questions : (Array.isArray(content) ? content : null)
    if (!questions || !questions.length) return renderMarkdownDoc(content)

    const normalize = (s) => String(s ?? '').trim().toLowerCase()
    const correctIndexOf = (q) => {
      const ca = q.correctAnswer
      if (typeof ca === 'number' && ca >= 0 && ca < (q.options || []).length) return ca
      if (typeof ca === 'string') {
        const opts = q.options || []
        const exact = opts.findIndex((o) => normalize(o) === normalize(ca))
        if (exact !== -1) return exact
        const asNum = Number(ca)
        if (!isNaN(asNum) && Number.isInteger(asNum) && asNum >= 0 && asNum < opts.length) return asNum
      }
      return -1
    }

    const wrap = el('div', 'ks-quiz ks-av-scroll')
    const body = el('div', 'ks-quiz-body')
    wrap.appendChild(body)

    // answers[i] = chosen index (MCQ) or { text } for short answer; null = unanswered.
    const answers = new Array(questions.length).fill(null)
    const correctArr = questions.map(correctIndexOf)
    let current = 0
    let reviewing = false

    function score() {
      let correct = 0
      questions.forEach((q, i) => { if (isCorrect(i)) correct++ })
      return { correct, total: questions.length, pct: Math.round((correct / questions.length) * 100) }
    }
    function isCorrect(i) {
      const q = questions[i]
      const a = answers[i]
      if (a == null) return false
      if (Array.isArray(q.options) && q.options.length) return a === correctArr[i]
      return typeof a === 'object' && normalize(a.text) === normalize(q.correctAnswer)
    }

    function drawQuestion() {
      body.innerHTML = ''
      const q = questions[current]
      if (!q) { drawResults(); return }
      const meta = el('div', 'ks-quiz-meta', `Question ${current + 1} of ${questions.length}`)
      body.appendChild(meta)

      const qEl = el('div', 'ks-quiz-question', String(q.question ?? ''))
      body.appendChild(qEl)

      const answered = answers[current] != null
      if (Array.isArray(q.options) && q.options.length) {
        const list = el('div', 'ks-quiz-options')
        q.options.forEach((opt, oi) => {
          const btn = el('button', 'ks-quiz-option')
          btn.type = 'button'
          btn.textContent = String(opt)
          if (answered) {
            btn.disabled = true
            if (oi === correctArr[current]) btn.classList.add('correct')
            if (oi === answers[current] && oi !== correctArr[current]) btn.classList.add('wrong')
          } else {
            btn.addEventListener('click', () => { answers[current] = oi; drawQuestion() })
          }
          list.appendChild(btn)
        })
        body.appendChild(list)
      } else {
        // Short-answer question.
        const form = el('div', 'ks-quiz-short')
        const input = el('input', 'ks-quiz-input')
        input.type = 'text'
        input.placeholder = 'Type your answer…'
        input.value = answered && typeof answers[current] === 'object' ? answers[current].text : ''
        const submit = el('button', 'ks-quiz-submit')
        submit.type = 'button'
        submit.textContent = 'Check'
        submit.addEventListener('click', () => {
          if (!input.value.trim()) return
          answers[current] = { text: input.value }
          drawQuestion()
        })
        if (answered) { input.disabled = true; submit.disabled = true }
        else input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit.click() })
        form.appendChild(input); form.appendChild(submit)
        body.appendChild(form)
      }

      if (answered) {
        const good = isCorrect(current)
        const verdict = el('div', 'ks-quiz-verdict ' + (good ? 'ok' : 'bad'), good ? '✓ Correct' : '✗ Incorrect')
        body.appendChild(verdict)
        if (!good && Array.isArray(q.options) && q.options.length) {
          body.appendChild(el('div', 'ks-quiz-answer', 'Correct answer: ' + String(q.options[correctArr[current]])))
        } else if (!good) {
          body.appendChild(el('div', 'ks-quiz-answer', 'Correct answer: ' + String(q.correctAnswer)))
        }
        if (q.explanation) body.appendChild(el('div', 'ks-quiz-explain', String(q.explanation)))
        if (q.source) {
          const pageLabel = q.page ? ` • Page ${q.page}` : ''
          body.appendChild(el('div', 'ks-quiz-src', 'Source: ' + String(q.source) + pageLabel))
        }
      }

      const nav = el('div', 'ks-quiz-nav')
      const prev = el('button', 'ks-quiz-nav-btn')
      prev.type = 'button'; prev.textContent = '← Previous'
      prev.disabled = current === 0
      prev.addEventListener('click', () => { current--; drawQuestion() })
      const next = el('button', 'ks-quiz-nav-btn primary')
      next.type = 'button'
      next.textContent = current === questions.length - 1 ? 'Finish' : 'Next →'
      if (!answered) next.disabled = true
      next.addEventListener('click', () => {
        if (current === questions.length - 1) drawResults()
        else { current++; drawQuestion() }
      })
      nav.appendChild(prev); nav.appendChild(next)
      body.appendChild(nav)
    }

    function drawResults() {
      body.innerHTML = ''
      const { correct, total, pct } = score()
      const heading = el('h3', 'ks-av-h3', 'Quiz Complete')
      body.appendChild(heading)
      const scoreEl = el('div', 'ks-quiz-score')
      scoreEl.appendChild(el('div', 'ks-quiz-pct', pct + '%'))
      scoreEl.appendChild(el('div', 'ks-quiz-counts', `${correct} correct • ${total - correct} incorrect • ${total} questions`))
      body.appendChild(scoreEl)
      const missed = []
      questions.forEach((q, i) => { if (!isCorrect(i)) missed.push(i) })
      if (missed.length) {
        const reviewTitle = el('h4', 'ks-av-h4', 'Review missed questions')
        body.appendChild(reviewTitle)
        const list = el('ul', 'ks-av-list')
        missed.forEach((i) => {
          const li = el('li', null, String(questions[i].question ?? ''))
          list.appendChild(li)
        })
        body.appendChild(list)
        const reviewBtn = el('button', 'ks-quiz-nav-btn primary')
        reviewBtn.type = 'button'
        reviewBtn.textContent = 'Review questions'
        reviewBtn.addEventListener('click', () => { current = missed[0]; drawQuestion() })
        body.appendChild(reviewBtn)
      }
      const restart = el('button', 'ks-quiz-nav-btn')
      restart.type = 'button'
      restart.textContent = 'Restart quiz'
      restart.addEventListener('click', () => {
        for (let i = 0; i < answers.length; i++) answers[i] = null
        current = 0
        drawQuestion()
      })
      body.appendChild(restart)
    }

    drawQuestion()
    return wrap
  }

  /* ══ DATA TABLE ══════════════════════════════════════════════════════════ */
  // Schema: { title, columns:[], rows:[][] }
  // Real table: sortable columns, search filter, independent scroll.
  function renderDataTable(artifact) {
    const content = artifact.content || {}
    if (!isPlainObject(content) || !Array.isArray(content.columns) || !Array.isArray(content.rows)) {
      return renderMarkdownDoc(content)
    }
    const columns = content.columns.map(String)
    const rows = content.rows.filter((r) => Array.isArray(r))

    const wrap = el('div', 'ks-table')
    const toolbar = el('div', 'ks-table-toolbar')
    const search = el('input', 'ks-table-search')
    search.type = 'search'
    search.placeholder = `Filter ${rows.length} rows…`
    const count = el('span', 'ks-table-count', `${rows.length} rows`)
    toolbar.appendChild(search); toolbar.appendChild(count)
    wrap.appendChild(toolbar)

    const scroll = el('div', 'ks-table-scroll ks-av-scroll')
    const table = el('table', 'ks-table-el')
    const thead = el('thead')
    const headRow = el('tr')
    const sortState = { col: -1, dir: 1 }
    columns.forEach((col, ci) => {
      const th = el('th', null, col)
      th.title = 'Click to sort'
      th.addEventListener('click', () => {
        if (sortState.col === ci) sortState.dir *= -1
        else { sortState.col = ci; sortState.dir = 1 }
        draw()
      })
      headRow.appendChild(th)
    })
    thead.appendChild(headRow)
    const tbody = el('tbody')
    table.appendChild(thead); table.appendChild(tbody)
    scroll.appendChild(table)
    wrap.appendChild(scroll)

    function draw() {
      const term = normalize(search.value)
      let view = rows.map((r, ri) => ({ r, ri }))
      if (term) view = view.filter(({ r }) => r.some((cell) => normalize(cell).includes(term)))
      if (sortState.col >= 0) {
        const ci = sortState.col
        view.sort((a, b) => {
          const av = a.r[ci], bv = b.r[ci]
          const an = typeof av === 'number' ? av : parseFloat(String(av))
          const bn = typeof bv === 'number' ? bv : parseFloat(String(bv))
          const bothNum = !isNaN(an) && !isNaN(bn) && String(av).trim() !== '' && String(bv).trim() !== ''
          const cmp = bothNum ? an - bn : normalize(av).localeCompare(normalize(bv))
          return cmp * sortState.dir
        })
      }
      tbody.innerHTML = ''
      view.forEach(({ r }) => {
        const tr = el('tr')
        columns.forEach((_, ci) => tr.appendChild(el('td', null, String(r[ci] ?? ''))))
        tbody.appendChild(tr)
      })
      count.textContent = `${view.length} / ${rows.length} rows`
      thead.querySelectorAll('th').forEach((th, ci) => {
        th.classList.toggle('sorted-asc', ci === sortState.col && sortState.dir === 1)
        th.classList.toggle('sorted-desc', ci === sortState.col && sortState.dir === -1)
      })
    }
    search.addEventListener('input', draw)
    draw()
    return wrap
  }

  function normalize(s) { return String(s ?? '').trim().toLowerCase() }

  /* ══ STUDY GUIDE ══════════════════════════════════════════════════════════ */
  // Schema: { title, overview, sections:[{title,body}], keyTerms:[{term,definition}],
  //           practicePrompts:[{question,answer}], sources:[string] }
  function renderStudyGuide(artifact) {
    const content = artifact.content || {}
    if (!isPlainObject(content) || (!Array.isArray(content.sections) && !Array.isArray(content.keyTerms) && typeof content.markdown !== 'string')) {
      return renderMarkdownDoc(content)
    }
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')
    if (content.title && typeof content.title === 'string') body.appendChild(el('h2', 'ks-av-doc-title', content.title))
    if (content.overview) body.appendChild(el('p', 'ks-av-summary', content.overview))
    ;(content.sections || []).forEach((section) => {
      if (!section) return
      const sec = el('section', 'ks-av-section')
      if (section.title) sec.appendChild(el('h3', 'ks-av-h3', section.title))
      sec.appendChild(el('p', null, section.body || ''))
      body.appendChild(sec)
    })
    if (Array.isArray(content.keyTerms) && content.keyTerms.length) {
      const sec = el('section', 'ks-av-section')
      sec.appendChild(el('h3', 'ks-av-h3', 'Key Terms'))
      const grid = el('div', 'ks-sg-terms')
      content.keyTerms.forEach((k) => {
        if (!k) return
        const t = el('div', 'ks-sg-term')
        t.appendChild(el('strong', null, k.term || ''))
        t.appendChild(el('span', null, k.definition || ''))
        grid.appendChild(t)
      })
      sec.appendChild(grid)
      body.appendChild(sec)
    }
    if (Array.isArray(content.practicePrompts) && content.practicePrompts.length) {
      const sec = el('section', 'ks-av-section')
      sec.appendChild(el('h3', 'ks-av-h3', 'Practice'))
      content.practicePrompts.forEach((p) => {
        if (!p) return
        const item = el('div', 'ks-av-qa')
        item.appendChild(el('strong', null, (p.question || '') + ''))
        item.appendChild(el('p', null, p.answer || ''))
        sec.appendChild(item)
      })
      body.appendChild(sec)
    }
    if (Array.isArray(content.sources) && content.sources.length) {
      const sec = el('section', 'ks-av-section')
      sec.appendChild(el('h3', 'ks-av-h3', 'References'))
      const ul = el('ul', 'ks-av-list')
      content.sources.forEach((s) => ul.appendChild(el('li', null, s)))
      sec.appendChild(ul)
      body.appendChild(sec)
    }
    wrap.appendChild(body)
    return wrap
  }

  /* ══ BRIEFING DOC ═════════════════════════════════════════════════════════ */
  // Schema: { title, overview, background:[{title,body}], keyDetails:[], actionItems:[], sources:[] }
  function renderBriefingDoc(artifact) {
    const content = artifact.content || {}
    if (!isPlainObject(content) || (!Array.isArray(content.background) && typeof content.markdown !== 'string')) {
      return renderMarkdownDoc(content)
    }
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')
    if (content.title && typeof content.title === 'string') body.appendChild(el('h2', 'ks-av-doc-title', content.title))
    if (content.overview) body.appendChild(el('p', 'ks-av-summary', content.overview))
    ;(content.background || []).forEach((bg) => {
      if (!bg) return
      const sec = el('section', 'ks-av-section')
      if (bg.title) sec.appendChild(el('h3', 'ks-av-h3', bg.title))
      sec.appendChild(el('p', null, bg.body || ''))
      body.appendChild(sec)
    })
    const listBlock = (title, items) => {
      if (!Array.isArray(items) || !items.length) return
      const sec = el('section', 'ks-av-section')
      sec.appendChild(el('h3', 'ks-av-h3', title))
      const ul = el('ul', 'ks-av-list')
      items.forEach((it) => ul.appendChild(el('li', null, String(it))))
      sec.appendChild(ul)
      body.appendChild(sec)
    }
    listBlock('Key Details', content.keyDetails)
    listBlock('Action Items', content.actionItems)
    listBlock('References', content.sources)
    wrap.appendChild(body)
    return wrap
  }

  /* ══ FAQ ══════════════════════════════════════════════════════════════════ */
  // Schema: { title, questions:[{question,answer,source?,page?}], sources:[] }
  function renderFaq(artifact) {
    const content = artifact.content || {}
    const qs = isPlainObject(content) && Array.isArray(content.questions) ? content.questions : null
    if (!qs || !qs.length) return renderMarkdownDoc(content)
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    const body = el('div', 'ks-av-doc-body')
    if (content.title && typeof content.title === 'string') body.appendChild(el('h2', 'ks-av-doc-title', content.title))
    qs.forEach((q, i) => {
      if (!q) return
      const item = el('div', 'ks-av-qa')
      item.appendChild(el('h3', 'ks-av-h3', `${i + 1}. ${q.question || ''}`))
      item.appendChild(el('p', null, q.answer || ''))
      if (q.source) item.appendChild(el('small', 'ks-av-cite', `Source: ${q.source}${q.page ? ` · Page ${q.page}` : ''}`))
      body.appendChild(item)
    })
    wrap.appendChild(body)
    return wrap
  }

  /* ══ TIMELINE ═════════════════════════════════════════════════════════════ */
  // Schema: { title, events:[{date,title,description,source?,page?}], sources:[] }
  function renderTimeline(artifact) {
    const content = artifact.content || {}
    const evs = isPlainObject(content) && Array.isArray(content.events) ? content.events : null
    if (!evs || !evs.length) return renderMarkdownDoc(content)
    const wrap = el('div', 'ks-av-doc ks-av-scroll')
    wrap.appendChild(el('h2', 'ks-av-doc-title', (content.title || 'Timeline') + ''))
    const rail = el('div', 'ks-tl')
    evs.forEach((ev) => {
      if (!ev) return
      const item = el('div', 'ks-tl-item')
      item.appendChild(el('div', 'ks-tl-dot', ''))
      const card = el('div', 'ks-tl-card')
      card.appendChild(el('span', 'ks-tl-date', ev.date || ''))
      card.appendChild(el('strong', null, ev.title || ''))
      card.appendChild(el('p', null, ev.description || ''))
      if (ev.source) card.appendChild(el('small', 'ks-av-cite', `Source: ${ev.source}${ev.page ? ` · Page ${ev.page}` : ''}`))
      item.appendChild(card)
      rail.appendChild(item)
    })
    wrap.appendChild(rail)
    return wrap
  }

  const RENDERERS = {
    note: renderNote,
    report: renderReport,
    mind_map: renderMindMap,
    flashcard_set: renderFlashcards,
    quiz: renderQuiz,
    data_table: renderDataTable,
    study_guide: renderStudyGuide,
    briefing_doc: renderBriefingDoc,
    faq: renderFaq,
    timeline: renderTimeline
  }

  /** Render an artifact into a full-panel interactive view. */
  function render(artifact, ctx = {}) {
    try {
      const renderer = RENDERERS[artifact.type]
      if (!renderer) {
        console.warn('[KS] No renderer for artifact type:', artifact.type)
        return renderMarkdownDoc(artifact.content)
      }
      return renderer(artifact, {
        onSaveContent: async (content) => {
          if (ctx.onSaveContent) return ctx.onSaveContent(content)
          if (window.KS) return window.KS.artifacts.saveContent(artifact.id, content)
          throw new Error('No persistence layer available.')
        }
      })
    } catch (err) {
      console.error('[KS] Artifact render failed:', err)
      const wrap = el('div', 'ks-av-doc ks-av-scroll')
      wrap.appendChild(el('p', 'ks-av-error', 'This artifact could not be rendered: ' + (err && err.message ? err.message : err)))
      return wrap
    }
  }

  window.KSArtifacts = { render }
})()

