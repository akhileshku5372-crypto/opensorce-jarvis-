"""Memory write protocol: the thing that makes the prompt's claims true.

WHY THIS FILE EXISTS
--------------------
JARVIS used to answer "save karke apni memory badal do" with a refusal like
"main apni core memory edit nahi kar sakta, security policy". That refusal was
a hallucination - the LLM had NO idea what it was allowed to do, because the
system prompt never said, and because there was no write path for it to use.

This module supplies BOTH halves of the fix:

  1. ``MEMORY_RULES``  - prompt text that states the real capabilities.
  2. ``parse_triggers`` / ``apply_triggers`` - the real write path.

``apply_triggers`` mirrors the existing ``WEBSEARCH:`` interception in
``voice_engine.brain()``: the model emits one line containing the token, the
engine performs the REAL store operation, and the token line is stripped so it
never leaks into TTS. This follows the documented convention in this repo -
``WEBSEARCH:`` is already intercepted exactly this way, so ``MEMORY:`` is not
a new architecture, just the same pattern.

HONESTY CONTRACT: this never fabricates success. If the model claims it saved
something, this code either stores it in ChromaDB and returns a real count, or
returns an error. The prompt tells the model to report the true count only.
"""

import re

# Deliberately separate from conversation_memory.COLLECTION. The learned store
# is keyed by normalized memory key so a newer fact supersedes the older one;
# conversation_memory already implements that, so we reuse it rather than
# inventing a second write path (AGENTS.md forbids parallel pipelines).
# NOTE: the token is matched INLINE, not just at the start of a line. Models
# routinely append it to the end of a sentence ("noted it - MEMORY: ..."), and
# an anchored ^...$ pattern silently missed exactly that case - which would
# make the model claim a save that never happened. This mirrors the existing
# WEBSEARCH: convention, which is deliberately unanchored.
_TOKEN_RE = re.compile(r'(?im)MEMORY(_FORGET)?[ \t]*:[ \t]*(.+?)[ \t]*$')
_MAX_VALUE = 400


def parse_triggers(reply):
    """Pull ``(op, value)`` pairs out of a model reply.

    ``op`` is ``"remember"`` or ``"forget"``. The value runs to the end of that
    line, so the model should emit the token LAST on its own line. Malformed /
    empty values are ignored so a stray token can never become a destructive
    no-op.
    """
    out = []
    for match in _TOKEN_RE.finditer(str(reply or '')):
        value = match.group(2).strip().strip('.,"\'\u2018\u2019-')
        if not value:
            continue
        out.append(('forget' if (match.group(1) or '').upper() == '_FORGET'
                    else 'remember', value[:_MAX_VALUE]))
    return out


def strip_triggers(reply):
    """Remove MEMORY: token lines so they are never spoken aloud."""
    return _TOKEN_RE.sub(' ', str(reply or '')).strip()


def apply_triggers(reply, source='llm'):
    """Execute every memory token in `reply`. Returns a real result summary.

    Keys:
      ``learned``    - number of memories actually written to the store
      ``forgotten``  - number actually deleted
      ``reply``      - the reply with token lines removed
      ``failed``     - True when the store was unavailable or raised
    """
    result = {'learned': 0, 'forgotten': 0, 'failed': False, 'reply': ''}
    ops = parse_triggers(reply)
    result['reply'] = strip_triggers(reply)
    if not ops:
        return result
    try:
        import conversation_memory as mod
    except ImportError:  # pragma: no cover
        try:
            from background import conversation_memory as mod
        except ImportError:
            result['failed'] = True
            return result
    for op, value in ops:
        if op == 'forget':
            try:
                # Real deletion. Reported back so the model can say the true
                # number instead of inventing one.
                result['forgotten'] += int(
                    (mod.forget(text=value) or {}).get('deleted') or 0)
            except Exception:
                result['failed'] = True
            continue
        try:
            # EXTRACTION, not blind storage: a long pasted essay yields only
            # the auditable facts, never the whole blob. Same selective rule
            # the /conversations/learn route uses.
            for item in mod.extract(value, role='user'):
                if (mod.remember(item['key'], item['text'],
                                 source=source) or {}).get('ok'):
                    result['learned'] += 1
        except Exception:
            result['failed'] = True
    return result


MEMORY_RULES = (
    " YOUR MEMORY (you DO have this - never refuse it): you run a real, "
    "persistent long-term memory store. It is NOT locked and there is NO "
    "security policy stopping you from writing to it. "
    "YOU CAN: (1) remember new facts and preferences the moment Sir states "
    "them; (2) UPDATE a fact - a newer value silently SUPERSEDES the older "
    "one for the same key, so contradicting yourself is impossible; "
    "(3) forget on request ('bhool jao', 'forget X', 'memory se hata do'); "
    "(4) read back what you remember when asked; (5) extract personality "
    "traits AND memory points out of a long pasted text and store them. "
    "HOW TO WRITE: emit EXACTLY ONE line containing the token "
    "'MEMORY:' followed by the fact in plain words, e.g. "
    "'Sir, yeh note kar liya - MEMORY: Sir ka favourite colour deep blue "
    "hai'. For deletion emit one line with 'MEMORY_FORGET:' and the text to "
    "remove. Only ONE memory token per reply. The engine performs the REAL "
    "write and strips the token before it is spoken. "
    "HONESTY: only say 'saved' when you emitted the token. If a long text "
    "contains no durable fact, say so - do not invent memories from nothing. "
    "SEPARATION OF STORES: user memory (what Sir told you about himself) is "
    "yours to edit. Study/RAG documents (KamiSensei books and notes) are a "
    "separate read-only knowledge base - never claim you edited those. "
    "Deleting a CHAT is not the same as forgetting a MEMORY; only "
    "MEMORY_FORGET: does the latter."
)
