"""Agent + Sub-Agent Flow Builder tests (stdlib only).

Covers the spec's acceptance list: create agent, create sub-agent, connect
agent -> sub-agent, sub-agent -> sub-agent, connect a tool, save/load,
natural-language generation, run, REAL tool execution, permission approval,
failure/retry and refresh persistence.

The executor is exercised against a REAL cortex.ToolRegistry with real
ToolSpec handlers, so "the flow executed" means real callables ran - not a mock
returning canned data.
"""
import importlib.util
import json
import shutil
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = ROOT / "background"


def _load(name):
    spec = importlib.util.spec_from_file_location(name, BACKGROUND / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


AF = _load("agent_flow")
CORTEX = _load("cortex")


class _FakeSkills:
    """Minimal stand-in for background/skill_loader.py (same call surface)."""

    def __init__(self, skills):
        self._skills = list(skills)

    def load(self):
        return list(self._skills)

    def get(self, name):
        for skill in self._skills:
            if str(name).lower() in (skill["name"].lower(),):
                return skill
        return None

    def context_for(self, text):
        return "SKILL CONTEXT: " + text[:80]


class _FakeMcp:
    """Records calls so the MCP node can be proven to reach the real client API."""

    def __init__(self, rows):
        self._rows = list(rows)
        self.calls = []

    def tools_snapshot(self):
        return list(self._rows)

    def call_tool(self, server, tool, arguments):
        self.calls.append((server, tool, arguments))
        return {"ok": True, "text": "%s.%s -> %s" % (server, tool, json.dumps(arguments))}


class AgentFlowTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="jarvis-agentflow-")
        self._orig = (AF.STORE_DIR, AF.STORE, AF.RUN_STORE)
        AF.STORE_DIR = Path(self.tmp)
        AF.STORE = AF.STORE_DIR / "agents.json"
        AF.RUN_STORE = AF.STORE_DIR / "last_run.json"
        AF._run = None
        AF._runner = None
        AF._cancel = threading.Event()
        AF.configure(registry=None, confirm=None, planner=None, complete=None,
                     skills=None, mcp=None, models=None, cortex=None,
                     permissions=None, memory=None)
        self.calls = []
        self.approvals = []
        self.registry = CORTEX.ToolRegistry()
        self.registry.register(CORTEX.ToolSpec(
            "test_echo", "Echo text back", self._echo))
        self.registry.register(CORTEX.ToolSpec(
            "test_write", "Write text (confirm gated)", self._write,
            requires_confirmation=True))
        self.registry.register(CORTEX.ToolSpec(
            "test_boom", "Always fails", self._boom))
        AF.configure(registry=self.registry, confirm=self._confirm,
                     skills=_FakeSkills([{"name": "demo-skill", "description": "demo",
                                          "body": "follow the demo skill",
                                          "triggers": ["demo"]}]),
                     mcp=_FakeMcp([{"server": "echo", "tool": "ping",
                                    "description": "ping the echo server",
                                    "allow_call": True, "read_only": False}]),
                     models=[{"id": "test-model", "label": "Test Model"}])

    def tearDown(self):
        runner = getattr(AF, "_runner", None)
        if runner is not None and runner.is_alive():
            AF._cancel.set()
            runner.join(timeout=5)
        AF.STORE_DIR, AF.STORE, AF.RUN_STORE = self._orig
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- fake handlers -------------------------------------------------------
    def _echo(self, args):
        self.calls.append(("test_echo", args))
        return "echo:%s" % args.get("text", "")

    def _write(self, args):
        self.calls.append(("test_write", args))
        return "wrote:%s" % args.get("text", "")

    def _boom(self, args):
        self.calls.append(("test_boom", args))
        raise RuntimeError("handler exploded")

    def _confirm(self, name, args):
        self.approvals.append((name, args))
        return name != "test_deny"

    def _wait(self, predicate, timeout=8):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.02)
        return bool(predicate())

    def _finish(self, timeout=8):
        runner = getattr(AF, "_runner", None)
        if runner is not None:
            runner.join(timeout=timeout)
        return AF.current_run()

    # -- helpers -------------------------------------------------------------
    def _agent(self, name="Tester", nodes=None, edges=None):
        payload = {"name": name}
        if nodes is not None:
            payload["flow"] = {"nodes": nodes, "edges": edges or []}
        ok, agent = AF.create_agent(payload)
        self.assertTrue(ok, agent)
        return agent

    def _node(self, ntype, title, **config):
        node = AF._default_node(ntype, title)
        node["config"].update(config)
        return node

    def _edge(self, src, dst, branch=""):
        return {"from": src["id"], "to": dst["id"], "branch": branch}


class AgentCrudTest(AgentFlowTest):
    def test_create_agent_starts_with_a_runnable_skeleton(self):
        agent = self._agent("First")
        types = [n["type"] for n in agent["flow"]["nodes"]]
        self.assertEqual(types, ["input", "agent", "output"])
        self.assertEqual(len(agent["flow"]["edges"]), 2)
        self.assertTrue(AF.validate(agent)["ok"])

    def test_names_are_user_defined_not_fixed(self):
        for name in ("Video Editing Agent", "Research Agent", "zzz-unique-name"):
            agent = self._agent(name)
            self.assertEqual(agent["name"], name)
        self.assertEqual({a["name"] for a in AF.list_agents()},
                         {"Video Editing Agent", "Research Agent", "zzz-unique-name"})

    def test_rename_delete_duplicate_and_search(self):
        agent = self._agent("Original")
        ok, renamed = AF.rename_agent(agent["id"], "Renamed")
        self.assertTrue(ok)
        self.assertEqual(renamed["name"], "Renamed")
        ok, clone = AF.duplicate_agent(agent["id"])
        self.assertTrue(ok)
        self.assertNotEqual(clone["id"], agent["id"])
        clone_ids = {n["id"] for n in clone["flow"]["nodes"]}
        self.assertEqual(len(clone_ids), 3)
        self.assertFalse(clone_ids & {n["id"] for n in renamed["flow"]["nodes"]})
        # Search is a substring match on name/description/category.
        self.assertEqual({a["name"] for a in AF.list_agents("renamed")},
                         {"Renamed", "Renamed (copy)"})
        self.assertEqual([a["name"] for a in AF.list_agents("nope")], [])
        ok, _ = AF.delete_agent(clone["id"])
        self.assertTrue(ok)
        self.assertEqual(len(AF.list_agents()), 1)

    def test_active_disabled_toggle_blocks_running(self):
        agent = self._agent()
        ok, _ = AF.set_enabled(agent["id"], False)
        self.assertTrue(ok)
        self.assertFalse(AF.get_agent(agent["id"])["enabled"])
        ok, message = AF.run_agent(agent["id"], "hi")
        self.assertFalse(ok)
        self.assertIn("disabled", message)
        AF.set_enabled(agent["id"], True)
        self.assertTrue(AF.get_agent(agent["id"])["enabled"])


class AgentConnectionTest(AgentFlowTest):
    def test_agent_to_subagent_and_subagent_to_subagent(self):
        src = self._node("input", "In")
        main = self._node("agent", "Main")
        sub_a = self._node("subagent", "Analysis", system_prompt="analyse")
        sub_b = self._node("subagent", "Research", system_prompt="research")
        out = self._node("output", "Out")
        agent = self._agent("Pipeline", [src, main, sub_a, sub_b, out],
                            [self._edge(src, main), self._edge(main, sub_a),
                             self._edge(sub_a, sub_b), self._edge(sub_b, out)])
        report = AF.validate(agent)
        self.assertTrue(report["ok"], report["errors"])
        ids = {n["title"]: n["id"] for n in agent["flow"]["nodes"]}
        edges = {(e["from"], e["to"]) for e in agent["flow"]["edges"]}
        self.assertIn((ids["Main"], ids["Analysis"]), edges)
        self.assertIn((ids["Analysis"], ids["Research"]), edges)

    def test_illegal_connection_is_reported_not_silently_saved(self):
        # src -> tool -> output is a legal pipeline, and appending out -> agent
        # is NOT a cycle, so it survives the save-time cycle stripper and must
        # still be refused by validate(): an output node is terminal and cannot
        # feed an orchestrator.
        src = self._node("input", "In")
        tool = self._node("tool", "T", tool="test_echo")
        out = self._node("output", "Out")
        main = self._node("agent", "Main")
        agent = self._agent("Bad", [src, tool, out, main],
                            [self._edge(src, tool), self._edge(tool, out),
                             self._edge(out, main)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("output -> agent" in e for e in report["errors"]),
                        report["errors"])
        ok, message = AF.run_agent(agent["id"], "x")
        self.assertFalse(ok)
        self.assertIn("cannot run", message)

    def test_unknown_tool_binding_fails_validation(self):
        src = self._node("input", "In")
        tool = self._node("tool", "Ghost", tool="does_not_exist")
        out = self._node("output", "Out")
        agent = self._agent("Ghosted", [src, tool, out],
                            [self._edge(src, tool), self._edge(tool, out)])
        report = AF.validate(agent)
        self.assertFalse(report["ok"])
def test_cycles_are_stripped_so_a_flow_can_terminate(self):
        a = self._node("tool", "A", tool="test_echo")
        b = self._node("tool", "B", tool="test_echo")
        c = self._node("tool", "C", tool="test_echo")
        agent = self._agent("Cycle", [a, b, c],
                            [self._edge(a, b), self._edge(b, c), self._edge(c, a)])
        pairs = {(e["from"], e["to"]) for e in agent["flow"]["edges"]}
        self.assertLess(len(pairs), 3)
        self.assertEqual(len(AF._order_flow(agent["flow"])), 3)


class AgentRunTest(AgentFlowTest):
    def test_run_executes_real_registered_tools_in_order(self):
        src = self._node("input", "In")
        tool = self._node("tool", "Echo", tool="test_echo",
                          args_text='{"text": "{{input}}"}')
        out = self._node("output", "Out")
        agent = self._agent("Runner", [src, tool, out],
                            [self._edge(src, tool), self._edge(tool, out)])
        ok, run = AF.run_agent(agent["id"], "hello world")
        self.assertTrue(ok, run)
        view = self._finish()
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertEqual([c[0] for c in self.calls], ["test_echo"])
        self.assertEqual(self.calls[0][1], {"text": "hello world"})
        self.assertIn("echo:hello world", view["result"])
        statuses = {n["type"]: n["status"] for n in view["nodes"]}
        self.assertEqual(statuses["tool"], "done")

    def test_mcp_node_reaches_the_real_client(self):
        src = self._node("input", "In")
        node = self._node("mcp", "Ping", server="echo", tool="ping",
                          args_text='{"q": "1"}')
        out = self._node("output", "Out")
        agent = self._agent("McpRunner", [src, node, out],
                            [self._edge(src, node), self._edge(node, out)])
        ok, run = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok, run)
        view = self._finish()
        self.assertEqual(view["status"], "done", view.get("reason"))
        client = AF._deps["mcp"]
        self.assertEqual(client.calls, [("echo", "ping", {"q": "1"})])

    def test_skill_node_loads_a_real_body_into_context(self):
        src = self._node("input", "In")
        node = self._node("skill", "Skill", skill="demo-skill")
        out = self._node("output", "Out")
        agent = self._agent("SkillRunner", [src, node, out],
                            [self._edge(src, node), self._edge(node, out)])
        ok, _ = AF.run_agent(agent["id"], "demo please")
        self.assertTrue(ok)
        view = self._finish()
        entry = [n for n in view["nodes"] if n["type"] == "skill"][0]
        self.assertEqual(entry["status"], "done")
        self.assertIn("follow the demo skill", entry["output"])

    def test_confirm_gated_tool_parks_until_approved(self):
        AF.configure(confirm=lambda name, args: False)   # user denies
        src = self._node("input", "In")
        node = self._node("tool", "Write", tool="test_write",
                          args_text='{"text": "x"}')
        out = self._node("output", "Out")
        agent = self._agent("Gated", [src, node, out],
                            [self._edge(src, node), self._edge(node, out)])
        ok, _ = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok)
        view = self._finish()
        entry = [n for n in view["nodes"] if n["type"] == "tool"][0]
        self.assertEqual(entry["status"], "failed")
        # The handler must NOT have run: the gate denied it.
        self.assertNotIn("test_write", [c[0] for c in self.calls])
        self.assertEqual(view["status"], "failed")

    def test_confirmed_tool_runs(self):
        src = self._node("input", "In")
        node = self._node("tool", "Write", tool="test_write",
                          args_text='{"text": "y"}')
        out = self._node("output", "Out")
        agent = self._agent("Approved", [src, node, out],
                            [self._edge(src, node), self._edge(node, out)])
        ok, _ = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok)
        view = self._finish()
        self.assertIn("test_write", [c[0] for c in self.calls])
        self.assertEqual(view["status"], "done")
        self.assertIn("wrote:y", view["result"])

    def test_denied_approval_stops_the_branch(self):
        src = self._node("input", "In")
        gate = self._node("approval", "Confirm", prompt="Run it?")
        node = self._node("tool", "Write", tool="test_write",
                          args_text='{"text": "z"}')
        out = self._node("output", "Out")
        agent = self._agent("Denied", [src, gate, node, out],
                            [self._edge(src, gate), self._edge(gate, node),
                             self._edge(node, out)])
        ok, _ = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok)
        self.assertTrue(self._wait(lambda: bool(AF.pending_approvals())))
        AF.approve(gate["id"], False)
        view = self._finish()
        self.assertNotIn("test_write", [c[0] for c in self.calls])
        entry = [n for n in view["nodes"] if n["type"] == "tool"][0]
        self.assertEqual(entry["status"], "skipped")


class AgentRetryConditionTest(AgentFlowTest):
    def test_failing_tool_is_retried_then_stops_its_branch(self):
        src = self._node("input", "In")
        boom = self._node("tool", "Boom", tool="test_boom")
        boom["config"]["retries"] = 2
        out = self._node("output", "Out")
        agent = self._agent("Retrying", [src, boom, out],
                            [self._edge(src, boom), self._edge(boom, out)])
        ok, _ = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok)
        view = self._finish()
        entry = [n for n in view["nodes"] if n["type"] == "tool"][0]
        self.assertEqual(entry["status"], "failed")
        self.assertEqual(entry["attempts"], 3)          # 1 try + 2 retries
        self.assertEqual(len([c for c in self.calls if c[0] == "test_boom"]), 3)
        self.assertEqual(view["status"], "failed")
        skipped = [n for n in view["nodes"] if n["type"] == "output"][0]
        self.assertEqual(skipped["status"], "skipped")

    def test_condition_routes_only_the_taken_branch(self):
        src = self._node("input", "In")
        cond = self._node("condition", "Check", expression="input contains ok")
        yes = self._node("tool", "Yes", tool="test_echo",
                         args_text='{"text": "yes"}')
        no = self._node("tool", "No", tool="test_echo",
                        args_text='{"text": "no"}')
        agent = self._agent("Router", [src, cond, yes, no],
                            [self._edge(src, cond),
                             self._edge(cond, yes, "true"),
                             self._edge(cond, no, "false")])
        ok, _ = AF.run_agent(agent["id"], "this is ok")
        self.assertTrue(ok)
        view = self._finish()
        by_title = {n["title"]: n["status"] for n in view["nodes"]}
        self.assertEqual(by_title["Yes"], "done")
        self.assertEqual(by_title["No"], "skipped")
        self.assertIn("yes", view["result"])

    def test_condition_false_branch_is_taken_inverted(self):
        src = self._node("input", "In")
        cond = self._node("condition", "Check", expression="input contains ok")
        yes = self._node("tool", "Yes", tool="test_echo",
                         args_text='{"text": "yes"}')
        no = self._node("tool", "No", tool="test_echo",
                        args_text='{"text": "no"}')
        agent = self._agent("Router2", [src, cond, yes, no],
                            [self._edge(src, cond),
                             self._edge(cond, yes, "true"),
                             self._edge(cond, no, "false")])
        AF.run_agent(agent["id"], "not matching")
        view = self._finish()
        by_title = {n["title"]: n["status"] for n in view["nodes"]}
        self.assertEqual(by_title["No"], "done")
        self.assertEqual(by_title["Yes"], "skipped")

    def test_condition_expression_is_total_and_never_evals(self):
        node = self._node("condition", "C", expression="1 == 1; drop table")
        out = AF._run_condition_node(node, {"last": "x"})
        self.assertFalse(out["ok"])
        self.assertIn("cannot parse", out["output"])

    def test_cancel_stops_a_running_flow(self):
        src = self._node("input", "In")
        gate = self._node("approval", "Confirm", prompt="Hold?")
        out = self._node("output", "Out")
        agent = self._agent("Cancellable", [src, gate, out],
                            [self._edge(src, gate), self._edge(gate, out)])
        ok, _ = AF.run_agent(agent["id"], "go")
        self.assertTrue(ok)
        self.assertTrue(self._wait(lambda: bool(AF.pending_approvals())))
        ok, message = AF.cancel_run()
        self.assertTrue(ok, message)
        view = self._finish()
        self.assertEqual(view["status"], "cancelled")


class AgentPersistenceTest(AgentFlowTest):
    def test_flow_survives_a_module_reload(self):
        src = self._node("input", "In")
        node = self._node("tool", "Echo", tool="test_echo",
                          args_text='{"text": "persisted"}')
        out = self._node("output", "Out")
        agent = self._agent("Persisted", [src, node, out],
                            [self._edge(src, node), self._edge(node, out)])
        reloaded = _load("agent_flow")
        reloaded.STORE_DIR = AF.STORE_DIR
        reloaded.STORE = AF.STORE
        reloaded.RUN_STORE = AF.RUN_STORE
        rows = reloaded.list_agents()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "Persisted")
        types = [n["type"] for n in rows[0]["flow"]["nodes"]]
        self.assertEqual(types, ["input", "tool", "output"])
        self.assertEqual(len(rows[0]["flow"]["edges"]), 2)
        self.assertEqual(rows[0]["flow"]["nodes"][1]["config"]["tool"], "test_echo")

    def test_corrupt_store_is_reported_not_silently_wiped(self):
        AF.STORE_DIR.mkdir(parents=True, exist_ok=True)
        AF.STORE.write_text("{not json", encoding="utf-8")
        status = AF.store_status()
        self.assertEqual(status["agents"], 0)
        self.assertIn("unreadable", status["error"])

    def test_oversized_graph_is_bounded(self):
        nodes = [self._node("tool", "T%d" % i, tool="test_echo")
                 for i in range(AF.MAX_NODES + 25)]
        agent = self._agent("Huge", nodes, [])
        self.assertLessEqual(len(agent["flow"]["nodes"]), AF.MAX_NODES)

    def test_hostile_payload_cannot_smuggle_a_handler(self):
        agent = self._agent("Hostile")
        ok, saved = AF.save_agent(agent["id"], {
            "flow": {"nodes": [{"id": "x", "type": "tool", "title": "t" * 500,
                                "x": 10 ** 9, "y": -(10 ** 9), "w": 99999,
                                "config": {"tool": "os_run_command",
                                           "args_text": "rm -rf /"}}],
                     "edges": []}})
        self.assertTrue(ok)
        node = saved["flow"]["nodes"][0]
        self.assertLessEqual(len(node["title"]), AF.MAX_NAME)
        self.assertLessEqual(node["w"], AF.NODE_W_MAX)
        self.assertLessEqual(node["h"], AF.NODE_H_MAX)
        self.assertLessEqual(node["x"], 20000)
        self.assertFalse(AF.validate(saved)["ok"])   # not registered in this registry


class AgentEmptyInputTest(AgentFlowTest):
    """An input node with nothing to say must FAIL, never fake a result.

    Regression cover for the run that reported status "done" while its
    payload was the model's conversational reply to the literal string
    "no input supplied". Silence is not a result.
    """

    def test_empty_run_fails_instead_of_publishing_a_placeholder(self):
        src = self._node("input", "Task")
        out = self._node("output", "Out")
        agent = self._agent("NoInput", [src, out], [self._edge(src, out)])
        ok, message = AF.run_agent(agent["id"], "")
        self.assertTrue(ok, message)
        run = self._finish()
        self.assertEqual(run["status"], "failed", run.get("reason"))
        self.assertNotIn("no input supplied", json.dumps(run))

    def test_a_configured_placeholder_is_still_an_author_default(self):
        src = self._node("input", "Topic", placeholder="default topic")
        out = self._node("output", "Out")
        agent = self._agent("Defaulted", [src, out], [self._edge(src, out)])
        AF.run_agent(agent["id"], "")
        run = self._finish()
        self.assertEqual(run["status"], "done", run.get("reason"))
        self.assertEqual(run["result"], "default topic")

    def test_real_input_still_flows_through(self):
        src = self._node("input", "Task")
        out = self._node("output", "Out")
        agent = self._agent("Real", [src, out], [self._edge(src, out)])
        AF.run_agent(agent["id"], "write about otters")
        run = self._finish()
        self.assertEqual(run["status"], "done", run.get("reason"))
        self.assertEqual(run["result"], "write about otters")


class AgentStaleRunTest(AgentFlowTest):
    """A dead runner thread must not wedge the builder forever."""

    def test_dead_thread_does_not_refuse_the_next_run(self):
        # A tool flow, not the default skeleton: the skeleton contains an
        # `agent` node that needs cortex, which setUp leaves as None. This
        # test is about the run SLOT, not about node execution.
        src = self._node("input", "Task")
        tool = self._node("tool", "Echo", tool="test_echo",
                          args_text='{"text": "hi"}')
        out = self._node("output", "Out")
        agent = self._agent("Wedged", [src, tool, out],
                            [self._edge(src, tool), self._edge(tool, out)])
        AF.run_agent(agent["id"], "first")
        self._finish()
        # Simulate the crashy case: state says running, but nothing executes.
        with AF._lock:
            AF._run["status"] = "running"
        ok, message = AF.run_agent(agent["id"], "second")
        self.assertTrue(ok, message)
        run = self._finish()
        self.assertEqual(run["status"], "done", run.get("reason"))

    def test_a_live_thread_is_still_refused(self):
        src = self._node("input", "Task")
        tool = self._node("tool", "Echo", tool="test_echo",
                          args_text='{"text": "hi"}')
        out = self._node("output", "Out")
        agent = self._agent("Busy", [src, tool, out],
                            [self._edge(src, tool), self._edge(tool, out)])
        gate = threading.Event()

        def _slow(*_a, **_k):
            gate.wait(5.0)
            return "echo:slow"

        self.registry.get("test_echo").handler = _slow
        AF.run_agent(agent["id"], "first")
        self.assertTrue(self._wait(lambda: getattr(AF._runner, "is_alive", lambda: False)()))
        ok, message = AF.run_agent(agent["id"], "second")
        gate.set()
        self._finish()
        self.assertFalse(ok)
        self.assertIn("already running", message)


class AgentTemplateFastPathTest(AgentFlowTest):
    """The template path needs no model and must not be gated behind one."""

    def test_writer_intent_builds_the_real_graph_without_any_provider(self):
        # complete=None in setUp: a deterministic template must still work.
        ok, draft = AF.draft_from_text(
            "create a highly professional content writer that does web search "
            "and gives me a pdf or doc at the end")
        self.assertTrue(ok, draft)
        self.assertEqual(draft["name"], "Content Writer")
        types = [n["type"] for n in draft["flow"]["nodes"]]
        self.assertEqual(types, ["input", "tool", "output"])
        self.assertIn("template match", draft["source"])

    def test_unrelated_request_still_needs_a_provider(self):
        ok, message = AF.draft_from_text("do something completely unrelated")
        self.assertFalse(ok)
        self.assertIn("provider", message)


class AgentNaturalLanguageTest(AgentFlowTest):
    """The NL builder must produce an EDITABLE draft, never execute anything."""

    def test_instruction_becomes_a_real_editable_draft(self):
        reply = json.dumps({
            "name": "Video Editing Agent",
            "description": "Edits videos.",
            "nodes": [
                {"id": "a", "type": "input", "title": "Task", "config": {}},
                {"id": "b", "type": "agent", "title": "Main",
                 "config": {"system_prompt": "orchestrate"}},
                {"id": "c", "type": "subagent", "title": "Analysis",
                 "config": {"system_prompt": "analyse the video",
                            "tools": ["test_echo"]}},
                {"id": "d", "type": "subagent", "title": "Research",
                 "config": {"system_prompt": "research the topic",
                            "tools": ["test_echo"]}},
                {"id": "e", "type": "tool", "title": "Video Editor",
                 "config": {"tool": "test_echo", "args_text": "{}"}},
                {"id": "f", "type": "output", "title": "Final", "config": {}},
            ],
            "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "c"},
                      {"from": "c", "to": "d"}, {"from": "c", "to": "e"},
                      {"from": "d", "to": "e"}, {"from": "e", "to": "f"}]})
        AF.configure(complete=lambda prompt: reply)
        ok, draft = AF.draft_from_text(
            "Create an agent that edits videos. Make a video-analysis sub-agent, "
            "connect it to a research sub-agent, then connect both to the video "
            "editor tool and final output.")
        self.assertTrue(ok, draft)
        self.assertEqual(draft["name"], "Video Editing Agent")
        self.assertEqual(draft["source"], "natural-language draft")
        titles = [n["title"] for n in draft["flow"]["nodes"]]
        self.assertIn("Analysis", titles)
        self.assertIn("Research", titles)
        self.assertIn("Final", titles)
        self.assertTrue(draft["validation"]["ok"], draft["validation"]["errors"])
        # Nothing executed while drafting.
        self.assertEqual(self.calls, [])

    def test_draft_is_saved_as_a_normal_agent(self):
        reply = json.dumps({
            "name": "Generated",
            "nodes": [{"id": "a", "type": "input", "title": "In", "config": {}},
                      {"id": "b", "type": "agent", "title": "Main", "config": {}},
                      {"id": "c", "type": "output", "title": "Out", "config": {}}],
            "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "c"}]})
        AF.configure(complete=lambda prompt: reply)
        ok, draft = AF.draft_from_text("make a trivial agent")
        self.assertTrue(ok)
        ok, saved = AF.create_agent(draft)
        self.assertTrue(ok)
        self.assertEqual(saved["name"], "Generated")
        self.assertIn(saved["id"], [a["id"] for a in AF.list_agents()])


    def test_invented_tool_and_bad_node_type_are_neutralised(self):
        reply = json.dumps({
            "name": "Hallucinated",
            "nodes": [{"id": "a", "type": "input", "title": "In", "config": {}},
                      {"id": "b", "type": "agent", "title": "Main", "config": {}},
                      {"id": "c", "type": "delete_everything", "title": "Bad",
                       "config": {}},
                      {"id": "d", "type": "tool", "title": "Ghost",
                       "config": {"tool": "definitely_not_a_real_tool"}},
                      {"id": "e", "type": "output", "title": "Out", "config": {}}],
            "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "d"},
                      {"from": "d", "to": "e"}]})
        AF.configure(complete=lambda prompt: reply)
        ok, draft = AF.draft_from_text("do something impossible")
        self.assertTrue(ok)
        types = [n["type"] for n in draft["flow"]["nodes"]]
        self.assertNotIn("delete_everything", types)
        self.assertFalse(draft["validation"]["ok"])
        self.assertTrue(any("not in the live registry"
                            in e for e in draft["validation"]["errors"]))

    def test_non_json_reply_fails_honestly(self):
        AF.configure(complete=lambda prompt: "I cannot help with that.")
        ok, message = AF.draft_from_text("make an agent")
        self.assertFalse(ok)
        self.assertIn("workflow JSON", message)

    def test_provider_failure_is_reported_not_faked(self):
        def boom(prompt):
            raise RuntimeError("provider offline")
        AF.configure(complete=boom)
        ok, message = AF.draft_from_text("make an agent")
        self.assertFalse(ok)
        self.assertIn("provider offline", message)

    def test_without_a_provider_the_builder_says_so(self):
        AF.configure(complete=None)
        ok, message = AF.draft_from_text("make an agent")
        self.assertFalse(ok)
        self.assertIn("no AI provider", message)


class AgentCatalogTest(AgentFlowTest):
    def test_catalog_only_lists_real_capabilities(self):
        cat = AF.catalog()
        self.assertEqual({t["name"] for t in cat["tools"]},
                         {"test_echo", "test_write", "test_boom"})
        self.assertEqual([s["name"] for s in cat["skills"]], ["demo-skill"])
        self.assertEqual([(m["server"], m["tool"]) for m in cat["mcp"]],
                         [("echo", "ping")])
        self.assertEqual([m["id"] for m in cat["models"]], ["test-model"])

    def test_gated_tools_are_flagged_not_hidden(self):
        tools = {t["name"]: t for t in AF.catalog()["tools"]}
        self.assertTrue(tools["test_write"]["gated"])
        self.assertFalse(tools["test_echo"]["gated"])

    def test_capability_report_reflects_injection(self):
        report = AF.capability_report()
        self.assertTrue(report["available"]["tool"])
class AgentStoreRoundTripTest(AgentFlowTest):
    """The store round-trips exactly what the builder sends."""

    def test_full_lifecycle_through_the_module_api(self):
        # create -> edit graph -> save -> reload -> run -> result
        agent = self._agent("Lifecycle")
        src = agent["flow"]["nodes"][0]
        out = agent["flow"]["nodes"][-1]
        tool = AF._default_node("tool", "Echo")
        tool["config"].update({"tool": "test_echo",
                               "args_text": '{"text": "{{input}}"}'})
        nodes = [src, tool, out]
        edges = [{"from": src["id"], "to": tool["id"], "branch": ""},
                 {"from": tool["id"], "to": out["id"], "branch": ""}]
        ok, saved = AF.save_agent(agent["id"],
                                  {"flow": {"nodes": nodes, "edges": edges}})
        self.assertTrue(ok, saved)
        self.assertTrue(AF.validate(saved)["ok"], AF.validate(saved)["errors"])
        ok, run = AF.run_agent(saved["id"], "round trip")
        self.assertTrue(ok, run)
        view = self._finish()
        self.assertEqual(view["status"], "done", view.get("reason"))
        self.assertIn("echo:round trip", view["result"])
        self.assertTrue(any(e["event"] == "run_started" for e in view["events"]))
        self.assertTrue(any(e["event"] == "run_finished" for e in view["events"]))

    def test_viewport_and_node_geometry_persist(self):
        agent = self._agent("Viewport")
        node = agent["flow"]["nodes"][0]
        ok, saved = AF.save_agent(agent["id"], {"flow": {
            "nodes": [dict(node, x=321, y=654, w=300, h=150)],
            "edges": [], "viewport": {"x": -120, "y": 45, "zoom": 1.75}}})
        self.assertTrue(ok)
        reloaded = AF._read_store()["agents"][0]
        geo = reloaded["flow"]["nodes"][0]
        self.assertEqual((geo["x"], geo["y"], geo["w"], geo["h"]), (321, 654, 300, 150))
        self.assertEqual(reloaded["flow"]["viewport"],
                         {"x": -120, "y": 45, "zoom": 1.75})

    def test_out_of_range_zoom_is_clamped(self):
        agent = self._agent("Zoom")
        ok, saved = AF.save_agent(agent["id"], {"flow": {
            "nodes": saved_nodes(agent), "edges": [],
            "viewport": {"zoom": 99}}})
        self.assertTrue(ok)
        self.assertEqual(saved["flow"]["viewport"]["zoom"], 2.5)
        ok, saved = AF.save_agent(agent["id"], {"flow": {
            "nodes": saved_nodes(agent), "edges": [],
            "viewport": {"zoom": 0.01}}})
        self.assertEqual(saved["flow"]["viewport"]["zoom"], 0.25)

    def test_subagent_config_is_preserved_and_bounded(self):
        agent = self._agent("Sub")
        sub = AF._default_node("subagent", "Worker")
        sub["config"].update({
            "name": "Video Analysis", "system_prompt": "analyse frames",
            "tools": ["test_echo", "test_write"], "skills": ["demo-skill"],
            "permissions": "ask", "memory": "session", "max_steps": 5,
            "retries": 2, "on_failure": "stop",
            "input_schema": "x" * 2000, "output_schema": "y" * 2000})
        src, out = agent["flow"]["nodes"][0], agent["flow"]["nodes"][-1]
        ok, saved = AF.save_agent(agent["id"], {"flow": {
            "nodes": [src, sub, out],
            "edges": [{"from": src["id"], "to": sub["id"], "branch": ""},
                      {"from": sub["id"], "to": out["id"], "branch": ""}]}})
        self.assertTrue(ok)
        cfg = saved["flow"]["nodes"][1]["config"]
        self.assertEqual(cfg["name"], "Video Analysis")
        self.assertEqual(cfg["tools"], ["test_echo", "test_write"])
        self.assertEqual(cfg["permissions"], "ask")
        self.assertEqual(cfg["memory"], "session")
        self.assertEqual(cfg["max_steps"], 5)
        self.assertEqual(cfg["retries"], 2)
        self.assertEqual(cfg["on_failure"], "stop")
        self.assertLessEqual(len(cfg["input_schema"]), 800)
        self.assertLessEqual(len(cfg["output_schema"]), 800)

    def test_subagent_with_max_steps_out_of_range_is_clamped(self):
        agent = self._agent("Clamp")
        sub = AF._default_node("subagent", "W")
        sub["config"].update({"max_steps": 9999, "retries": 9999})
        src, out = agent["flow"]["nodes"][0], agent["flow"]["nodes"][-1]
        ok, saved = AF.save_agent(agent["id"], {"flow": {
            "nodes": [src, sub, out],
            "edges": [{"from": src["id"], "to": sub["id"], "branch": ""},
                      {"from": sub["id"], "to": out["id"], "branch": ""}]}})
        self.assertEqual(saved["flow"]["nodes"][1]["config"]["max_steps"], 8)
        self.assertEqual(saved["flow"]["nodes"][1]["config"]["retries"], 3)


def saved_nodes(agent):
    return agent["flow"]["nodes"]


class AgentRouteTest(unittest.TestCase):
    """The real voice_engine StateHandler, exercised over a real HTTP server.

    This proves the routes exist, marshal JSON correctly, and that the flow
    builder talks to background/agent_flow.py rather than a stand-in.
    """

    @classmethod
    def setUpClass(cls):
        cls.engine = _load("voice_engine")
        cls.af = _load("agent_flow")
        cls.tmp = tempfile.mkdtemp(prefix="jarvis-agentroute-")
        cls.orig = (cls.af.STORE_DIR, cls.af.STORE, cls.af.RUN_STORE)
        cls.af.STORE_DIR = Path(cls.tmp)
        cls.af.STORE = cls.af.STORE_DIR / "agents.json"
        cls.af.RUN_STORE = cls.af.STORE_DIR / "last_run.json"
        cls.af._run = None
        cls.af._runner = None
        cls.af._cancel = threading.Event()
        # The routes deliberately run against the REAL engine registry:
        # _agent_flow() re-injects _cortex_registry on every call, which is the
        # behaviour the registry invariant depends on.
        cls.af.configure(confirm=lambda n, a: True, complete=lambda p: "{}")
        # The engine must resolve the SAME module object, else the routes would
        # write to a different store than the tests read.
        cls.engine._AGENT_FLOW_MOD = cls.af
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), cls.engine.StateHandler)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.af.STORE_DIR, cls.af.STORE, cls.af.RUN_STORE = cls.orig
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def _get(self, path):
        url = "http://127.0.0.1:%d%s" % (self.port, path)
        request = urllib.request.Request(url,
                                         headers={"Host": "127.0.0.1:%d" % self.port})
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status, json.loads(response.read().decode("utf-8"))

    def _post(self, path, payload):
        url = "http://127.0.0.1:%d%s" % (self.port, path)
        request = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                         method="POST", headers={
                                             "Host": "127.0.0.1:%d" % self.port,
                                             "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=15) as response:
                return response.status, json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode("utf-8"))

    def _wait_run(self, timeout=12):
        deadline = time.monotonic() + timeout
        view = {}
        while time.monotonic() < deadline:
            _status, view = self._get("/agents/run")
            run = view.get("run") or {}
            if run.get("id") and run.get("status") not in ("running", "pending"):
                return view
            time.sleep(0.05)
        return view

    def _wait_approvals(self, timeout=12):
        deadline = time.monotonic() + timeout
        view = {}
        while time.monotonic() < deadline:
            _status, view = self._get("/agents/run")
            if view.get("approvals"):
                return view
            time.sleep(0.05)
        return view

    def test_templates_route_serves_the_starter_cards(self):
        """POST /agents/templates must answer 200 with the real card list.

        This endpoint answered 404 on a running core: the route existed in
        source but the live process predated it, so the Agents panel silently
        rendered no template cards. Asserted over real HTTP so a regression in
        the dispatcher (not just in agent_flow) is caught.
        """
        status, payload = self._post("/agents/templates", {})
        self.assertEqual(status, 200, payload)
        self.assertTrue(payload.get("ok"), payload)
        cards = payload.get("templates")
        self.assertTrue(isinstance(cards, list) and cards, payload)
        ids = [str(c.get("id") or "") for c in cards]
        self.assertIn("content-writer", ids)
        for card in cards:
            self.assertTrue(str(card.get("name") or "").strip())
            self.assertTrue(str(card.get("description") or "").strip())

    def test_create_from_template_builds_a_runnable_graph_over_http(self):
        """The one-click path: template id in, runnable content-writer out."""
        status, payload = self._post("/agents/create", {"template": "content-writer"})
        self.assertEqual(status, 200, payload)
        agent = payload["agent"]
        types = [n["type"] for n in agent["flow"]["nodes"]]
        self.assertEqual(types, ["input", "tool", "output"])
        # The write node must bind to a real registered tool, not a literal.
        tool_node = agent["flow"]["nodes"][1]
        self.assertTrue(tool_node["config"]["tool"])
        self.assertIn("{{ topic }}", tool_node["config"]["args_text"])

    def test_run_with_empty_input_reports_failed_not_done(self):
        """End-to-end guard on the fabricated-success bug, over real HTTP."""
        status, created = self._post("/agents/create", {
            "name": "EmptyInput",
            "flow": {"nodes": [
                {"id": "i", "type": "input", "title": "Task", "config": {}},
                {"id": "o", "type": "output", "title": "Out", "config": {}}],
                "edges": [{"from": "i", "to": "o"}]}})
        self.assertEqual(status, 200, created)
        agent_id = created["agent"]["id"]
        status, started = self._post("/agents/run", {"id": agent_id, "input": ""})
        self.assertEqual(status, 200, started)
        view = self._wait_run()
        run = view.get("run") or {}
        self.assertEqual(run.get("status"), "failed", run.get("reason"))
        self.assertNotIn("no input supplied", json.dumps(run))

    def test_create_list_and_persist_over_http(self):
        status, payload = self._post("/agents/create", {"name": "HTTP Agent"})
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"], payload)
        agent_id = payload["agent"]["id"]
        self.assertEqual(payload["agent"]["name"], "HTTP Agent")
        self.assertTrue(self.af.STORE.exists())
        status, listing = self._get("/agents")
        self.assertEqual(status, 200)
        self.assertIn("HTTP Agent", [a["name"] for a in listing["agents"]])
        self._post("/agents/delete", {"id": agent_id})

    def test_catalog_route_reports_real_registry(self):
        status, payload = self._get("/agents/catalog")
        self.assertEqual(status, 200)
        names = {t["name"] for t in payload["catalog"]["tools"]}
        # _agent_flow() re-injects the REAL engine registry on every call, so
        # this route must report real registered tools, not the test double.
        self.assertIn("os_list_files", names)
        self.assertTrue(any(n.startswith("plug_") for n in names),
                        "plugin tools must reach the same catalog")
        self.assertIn("node_types", payload["catalog"])
        self.assertIn("available", payload["capabilities"])

    def test_save_run_and_read_run_over_http(self):
        _status, created = self._post("/agents/create", {"name": "Runner"})
        agent_id = created["agent"]["id"]
        src = created["agent"]["flow"]["nodes"][0]
        out = created["agent"]["flow"]["nodes"][-1]
        tool = self.af._default_node("tool", "List files")
        # A REAL, read-only, allowlisted tool from the live registry - this is
        # the whole point of the route test: no stand-in capability.
        tool["config"].update({"tool": "os_list_files", "args_text": '{"path": "."}'})
        status, saved = self._post("/agents/save", {
            "id": agent_id,
            "agent": {"flow": {"nodes": [src, tool, out], "edges": [
                {"from": src["id"], "to": tool["id"], "branch": ""},
                {"from": tool["id"], "to": out["id"], "branch": ""}]}}})
        self.assertEqual(status, 200)
        self.assertTrue(saved["validation"]["ok"], saved["validation"]["errors"])
        status, run = self._post("/agents/run", {"id": agent_id, "input": "http-hello"})
        self.assertEqual(status, 200)
        self.assertTrue(run["ok"], run)
        view = self._wait_run()
        self.assertEqual(view["run"]["status"], "done", view["run"].get("reason"))
        self.assertTrue(view["run"]["result"].strip(),
                        view["run"]["result"])
        
        self._post("/agents/delete", {"id": agent_id})

    def test_run_refuses_an_unrunnable_flow(self):
        _status, created = self._post("/agents/create", {"name": "Broken"})
        agent_id = created["agent"]["id"]
        src = created["agent"]["flow"]["nodes"][0]
        out = created["agent"]["flow"]["nodes"][-1]
        tool = self.af._default_node("tool", "Ghost")
        tool["config"]["tool"] = "not_a_real_tool"
        self._post("/agents/save", {"id": agent_id, "agent": {"flow": {
            "nodes": [src, tool, out],
            "edges": [{"from": src["id"], "to": tool["id"], "branch": ""},
                      {"from": tool["id"], "to": out["id"], "branch": ""}]}}})
        status, payload = self._post("/agents/run", {"id": agent_id, "input": "x"})
        self.assertEqual(status, 409)
        self.assertFalse(payload["ok"])
        self.assertIn("cannot run", payload["error"])
        self._post("/agents/delete", {"id": agent_id})

    def test_rename_duplicate_toggle_delete_over_http(self):
        _s, created = self._post("/agents/create", {"name": "Original"})
        agent_id = created["agent"]["id"]
        status, renamed = self._post("/agents/rename", {"id": agent_id, "name": "Renamed"})
        self.assertEqual(status, 200)
        self.assertEqual(renamed["agent"]["name"], "Renamed")
        status, clone = self._post("/agents/duplicate", {"id": agent_id})
        self.assertEqual(status, 200)
        clone_id = clone["agent"]["id"]
        self.assertEqual(len(clone["agent"]["flow"]["nodes"]), 3)
        _status, toggled = self._post("/agents/toggle", {"id": agent_id, "enabled": False})
        self.assertFalse(toggled["agent"]["enabled"])
        status, blocked = self._post("/agents/run", {"id": agent_id, "input": "x"})
        self.assertEqual(status, 409)
        self.assertIn("disabled", blocked["error"])
        status, _deleted = self._post("/agents/delete", {"id": clone_id})
        self.assertEqual(status, 200)
        status, _still = self._get("/agents/" + agent_id)
        self.assertEqual(status, 200)
        self._post("/agents/delete", {"id": agent_id})

    def test_validate_route_and_unknown_agent(self):
        _s, created = self._post("/agents/create", {"name": "Validated"})
        status, payload = self._post("/agents/validate", {"id": created["agent"]["id"]})
        self.assertEqual(status, 200)
        self.assertTrue(payload["validation"]["ok"])
        self._post("/agents/delete", {"id": created["agent"]["id"]})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self._get("/agents/does_not_exist")
        self.assertEqual(ctx.exception.code, 404)

    def test_nl_prompt_demands_config_binding_keys(self):
        """Regression: the NL prompt must name the config BINDING keys.

        The prompt used to say only "use real tool names". The model then
        emitted an empty `config` for tool/mcp/skill/model nodes, so a drafted
        agent rendered "No tool selected" and failed validation with
        'no tool selected' even though the node title named a real
        capability. A title is not a binding. Assert every binding key the
        normalizer reads is spelled out in the prompt.
        """
        prompt = self.af._NL_SYSTEM
        self.assertIn("BINDING RULES", prompt)
        # Exact JSON keys _normalize_config() reads back off a node.
        for key in ("tool", "server", "skill", "model", "prompt", "expression"):
            self.assertIn('"%s"' % key, prompt,
                          "prompt never mentions the %r binding key" % key)
        # And it must tell the model not to leave config empty.
        self.assertIn("Never leave config empty", prompt)

    def test_validate_flags_a_tool_node_with_no_binding(self):
        """An unbound tool node must be an ERROR, not a warning."""
        agent = {
            "name": "Unbound",
            "enabled": True,
            "flow": {
                "nodes": [
                    {"id": "n1", "type": "input", "title": "Task input", "config": {}},
                    {"id": "n2", "type": "tool", "title": "Invoke Edge TTS",
                     "config": {"tool": ""}},
                    {"id": "n3", "type": "output", "title": "Done", "config": {}},
                ],
                "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}],
            },
        }
        report = self.af.validate(agent)
        self.assertFalse(report["ok"])
        self.assertTrue(any("no tool selected" in e for e in report["errors"]),
                        "unbound tool node was not reported: %r" % report["errors"])

    def test_approval_route_releases_a_parked_node(self):
        _s, created = self._post("/agents/create", {"name": "Gate"})
        agent_id = created["agent"]["id"]
        src = created["agent"]["flow"]["nodes"][0]
        out = created["agent"]["flow"]["nodes"][-1]
        gate = self.af._default_node("approval", "Confirm")
        gate["config"]["prompt"] = "Proceed?"
        tool = self.af._default_node("tool", "List files")
        tool["config"].update({"tool": "os_list_files", "args_text": '{"path": "."}'})
        self._post("/agents/save", {"id": agent_id, "agent": {"flow": {
            "nodes": [src, gate, tool, out],
            "edges": [{"from": src["id"], "to": gate["id"], "branch": ""},
                      {"from": gate["id"], "to": tool["id"], "branch": ""},
                      {"from": tool["id"], "to": out["id"], "branch": ""}]}}})
        status, started = self._post("/agents/run", {"id": agent_id, "input": "go"})
        self.assertEqual(status, 200)
        view = self._wait_approvals()
        pending = view.get("approvals") or []
        self.assertTrue(pending, "the flow never parked on the approval node")
        self.assertEqual(pending[0]["prompt"], "Proceed?")
        status, approved = self._post("/agents/approve",
                                      {"node": pending[0]["node"], "approve": True})
        self.assertEqual(status, 200)
        self.assertTrue(approved["ok"])
        final = self._wait_run()
        self.assertEqual(final["run"]["status"], "done", final["run"].get("reason"))
        self._post("/agents/delete", {"id": agent_id})

    def test_cancel_route_stops_a_parked_flow(self):
        _s, created = self._post("/agents/create", {"name": "Cancellable"})
        agent_id = created["agent"]["id"]
        src = created["agent"]["flow"]["nodes"][0]
        out = created["agent"]["flow"]["nodes"][-1]
        gate = self.af._default_node("approval", "Hold")
        self._post("/agents/save", {"id": agent_id, "agent": {"flow": {
            "nodes": [src, gate, out],
            "edges": [{"from": src["id"], "to": gate["id"], "branch": ""},
                      {"from": gate["id"], "to": out["id"], "branch": ""}]}}})
        self._post("/agents/run", {"id": agent_id, "input": "go"})
        self._wait_approvals()
        status, cancelled = self._post("/agents/cancel", {})
        self.assertEqual(status, 200)
        self.assertTrue(cancelled["ok"])
        _s, view = self._get("/agents/run")
        self.assertEqual(view["run"]["status"], "cancelled")
        self._post("/agents/delete", {"id": agent_id})


if __name__ == "__main__":
    unittest.main()
