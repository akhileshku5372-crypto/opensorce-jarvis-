# -*- coding: utf-8 -*-
"""_or_free.py — list OpenRouter free models cleanly (full parse, no truncation)."""
import json, urllib.request

def get(url, timeout=20):
    req = urllib.request.Request(url, headers={'User-Agent': 'Jarvis-probe/1.0'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except Exception as e:
        return None, str(type(e).__name__) + ' ' + str(e)[:90]

st, body = get('https://openrouter.ai/api/v1/models?params={"free":true}')
print('HTTP', st, 'body_bytes', len(body or b''))
if st == 200:
    try:
        data = json.loads(body)
        rows = []
        for m in data.get('data', [])[:20]:
            pr = (m.get('pricing') or {})
            rows.append((m['id'], pr.get('prompt', {}).get('currency'),
                         pr.get('completion', {}).get('currency'),
                         'image' if (m.get('architecture') or {}).get('modality','').startswith('text+image') else '-'))
        for r in rows:
            print(r)
    except Exception as e:
        print('parse err:', e)
        print(body[:4000])
