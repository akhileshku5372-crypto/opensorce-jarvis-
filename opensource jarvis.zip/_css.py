import pathlib
p=pathlib.Path("public/static/style.css")
s=p.read_text(encoding="utf-8", errors="replace")
# Find and replace the brain hub block
old = """.brain-hub{overflow:hidden}
.brain-holo-mount{position:absolute;inset:0;z-index:1}
.brain-holo-mount canvas{width:100%;height:100%;display:block}
.brain-hub #brain-canvas{position:absolute;inset:0;z-index:1}"""
new = """.brain-hub{overflow:hidden;position:relative;min-height:520px;display:block}
.brain-holo-mount{position:absolute;inset:0;z-index:2;display:block;width:100%;height:100%}
.brain-holo-mount canvas{width:100% !important;height:100% !important;display:block !important}
.brain-hub #brain-canvas{position:absolute;inset:0;z-index:1}"""
if old in s:
    s=s.replace(old,new)
    print("css patched mount")
else:
    print("css mount miss")
    print("found", s.count(".brain-hub"))
    # try flexible
    import re
    m=re.search(r"\.brain-hub\{overflow:hidden\}.*?\.brain-hub #brain-canvas\{position:absolute.*?\}", s, re.S)
    if m:
        print("regex found", repr(m.group(0)[:300]))
        s=s.replace(m.group(0), new)
        print("regex replaced")
# Also ensure brain-holo-ready hides old wires but keeps mount visible
# currently: .brain-holo-ready .brain-wires{display:none} and #brain-canvas hidden - OK
# Need to ensure .brain-canvas-wrap--3d has min-height
old2 = ".brain-canvas-wrap{position:relative;background:radial-gradient"
if old2 in s:
    s=s.replace(old2, ".brain-canvas-wrap{position:relative;display:block;min-height:520px;background:radial-gradient")
    print("patched canvas-wrap min-height")
# Ensure brain-caps still z-index 3 over mount 2
if ".brain-caps{position:absolute;inset:0;z-index:3}" in s:
    print("caps z-index OK")
else:
    print("caps z-index check miss")
p.write_text(s, encoding="utf-8")
import pathlib as pl
dp=pl.Path("dist/static/style.css")
if dp.parent.exists():
    dp.write_text(s, encoding="utf-8")
    print("copied to dist")
print("done len", len(s))
