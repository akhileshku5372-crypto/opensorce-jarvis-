import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { stream, streamSSE } from 'hono/streaming'
import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import * as fs from 'node:fs/promises'
import path from 'node:path'
import { renderer } from './renderer'
import {
  ARTIFACT_TYPES,
  ARTIFACT_LABELS,
  type ArtifactType,
  type RagChunkInput,
  buildArtifactPrompt,
  assembleDeepScanContext,
  buildMindMapCardsPrompt,
  buildMindMapPrompt,
  buildRepairPrompt,
  extractJson,
  extractTopicKeyPhrases,
  normalizeMindMapCards,
  salvageArtifact,
  validateArtifact,
  validateMindMapCards,
  validateMindMapTree,
  flattenMindMapInput,
  mindMapDepthLimit,
  clampRequestedCount,
  normalizeLabel,
  FLASHCARD_CEILING,
  FLASHCARD_BATCH_SIZE,
  FLASHCARD_DEFAULT_COUNT,
  QUIZ_CEILING,
  QUIZ_BATCH_SIZE,
  QUIZ_DEFAULT_COUNT
} from './artifacts'

type Bindings = {
  GROQ_API_KEY?: string
  GROQ_MODEL?: string
  XKIRO_API_KEY?: string
  XKIRO_MODEL?: string
  XKIRO_VISION_MODEL?: string
  OPENROUTER_API_KEY?: string
  OPENROUTER_MODEL?: string
  GOOGLE_API_KEY?: string
  GOOGLE_API_KEY_2?: string
  GOOGLE_MODEL?: string
  KAMISENSEI_MODEL?: string
  KAMISENSEI_MAX_OUTPUT_TOKENS?: string
  NVIDIA_API_KEY?: string
  NVIDIA_MODEL?: string
  NVIDIA_VISION_MODEL?: string
  NVIDIA_CODE_MODEL?: string
  OLLAMA_URL?: string
  OLLAMA_MODEL?: string
  ELEVENLABS_API_KEY?: string
  ELEVENLABS_VOICE_ID?: string
  WEATHER_API_KEY?: string
  OPENWEATHER_API_KEY?: string
  FISH_AUDIO_API_KEY?: string
  LIVEKIT_URL?: string
  LIVEKIT_API_KEY?: string
  LIVEKIT_API_SECRET?: string
  MEM0_API_KEY?: string
  GITHUB_API_KEY?: string
  JARVIS_UI_ORIGIN?: string
  JARVIS_BRIDGE_HOST?: string
  JARVIS_BRIDGE_PORT?: string
}

type ChatMessage = { role: 'user' | 'assistant' | 'system'; content: string }

const app = new Hono<{ Bindings: Bindings }>()
app.use('/api/*', cors({
  origin: (origin, c) => {
    if (!origin) return '*'
    const requestOrigin = new URL(c.req.url).origin
    const isLocal = /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin)
    return origin === requestOrigin || origin === c.env.JARVIS_UI_ORIGIN || isLocal ? origin : ''
  },
  allowMethods: ['GET', 'POST', 'OPTIONS'],
  allowHeaders: ['Content-Type']
}))
app.use(renderer)

app.get('/api/health', (c) => { const e=c.env as any; const keys={ groq: !!e.GROQ_API_KEY, gemini: !!(e.GOOGLE_API_KEY || e.GOOGLE_API_KEY_2), xkiro: !!e.XKIRO_API_KEY, openrouter: !!e.OPENROUTER_API_KEY, nvidia: !!e.NVIDIA_API_KEY, elevenlabs: !!e.ELEVENLABS_API_KEY, github: !!e.GITHUB_API_KEY, mem0: !!e.MEM0_API_KEY, ollama: !!e.OLLAMA_URL }; return c.json({ ok: true, service: 'JARVIS Edge', version: '0.10.0', providers: ['Ollama', 'Groq', 'Gemini', 'xKiro', 'NVIDIA', 'OpenRouter'], speech: ['Background STT/TTS', 'Browser STT/TTS', 'Groq Whisper', 'ElevenLabs'], languages: ['English', 'Hindi', 'Hinglish', 'Japanese', 'Mixed language'], keys, model: { locked: LOCKED_GOOGLE_MODEL, kamisensei: kamiSenseiModel(e) || 'not configured', kamisensei_label: kamiSenseiProviderLabel(e) } }) })

const LANGUAGE_RULES: Record<string, string> = {
  auto: 'TRILINGUAL PROTOCOL: understand and reply in a fluid, dynamic mix of English, Hinglish (Roman-script Hindi + English blend), and native Japanese. Mirror the language mix the user used turn by turn. Hinglish stays in Roman script; Japanese must be written in native typography (Kanji / Hiragana / Katakana), never romaji unless explicitly asked. Never flatten the reply into a single language.',
  en: 'Reply in English.',
  hi: 'Reply in Hindi (Devanagari script).',
  hinglish: 'Reply in casual Hinglish (Hindi written in Latin script mixed with English), like a friendly Indian assistant.',
  ja: 'Reply in natural Japanese (日本語). Use polite です/ます form.'
}

// ─── FREE MODEL ROUTES ───────────────────────────────────────────────────────
// Verified against each provider's live endpoint on 2026-10-21. Only free
// models are allowed here: OpenRouter entries must end in ":free", and the
// Gemini chain is lite-only. A configured model is used first only when it
// satisfies the same rule, so a stale/paid env value can never be called.
const LOCKED_GOOGLE_MODEL = 'gemini-flash-lite-latest'
const FREE_GEMINI_MODELS = ['gemini-flash-lite-latest', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite']
const FREE_GROQ_MODELS = ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'qwen/qwen3.8-27b']
const FREE_NVIDIA_MODELS = ['nvidia/nemotron-3.5-lightning-30b-a3b', 'meta/llama-3.2-11b-vision-instruct']
const FREE_OPENROUTER_MODELS = ['minimax/minimax-m3.1-flash:free', 'nvidia/nemotron-3.5-super-vl:free']
const FREE_XKIRO_MODELS = ['qwen/qwen3.7-flash:free']
const XKIRO_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

function freeModelChain(configured: unknown, fallbacks: string[], opts: { freeOnly?: boolean; liteOnly?: boolean } = {}): string[] {
  const out: string[] = []
  const add = (raw: unknown) => {
    const model = String(raw || '').trim()
    if (!model) return
    if (opts.freeOnly && !model.endsWith(':free')) return
    if (opts.liteOnly && !model.toLowerCase().includes('flash-lite')) return
    if (!out.includes(model)) out.push(model)
  }
  add(configured)
  fallbacks.forEach(add)
  return out
}

function freeGeminiModels(env: any, preferred?: string): string[] {
  return freeModelChain(preferred || env.GOOGLE_MODEL, FREE_GEMINI_MODELS, { liteOnly: true })
}

// ─── KAMISENSEI MODEL CONFIG ────────────────────────────────────────────────
// The KamiSensei research/artifact engine is separately configurable so the
// study stack can run on a purpose-tuned model without touching the core
// JARVIS chat route. It uses the same free lite-only Gemini chain.
const KAMISENSEI_MODEL_PATTERN = /^[a-z0-9][a-z0-9._-]*$/i

function kamiSenseiModels(env: any): string[] {
  const configured = String(env.KAMISENSEI_MODEL || '').trim()
  return freeGeminiModels(env, KAMISENSEI_MODEL_PATTERN.test(configured) ? configured : '')
}

function kamiSenseiModel(env: any): string {
  return kamiSenseiModels(env)[0] || ''
}

function kamiSenseiProviderLabel(env: any): string {
  const googleModel = kamiSenseiModel(env)
  if ((env.GOOGLE_API_KEY || env.GOOGLE_API_KEY_2) && googleModel) return `Gemini (${googleModel})`
  if (env.GROQ_API_KEY && env.GROQ_MODEL) return `Groq (${String(env.GROQ_MODEL).trim()})`
  return 'Not configured'
}

// Generation caps: configurable, bounded, and validated per provider so the
// app never assumes a model supports 8192 (or 32768) output tokens.
function kamiSenseiMaxOutputTokens(env: any): number {
  const raw = Number(env.KAMISENSEI_MAX_OUTPUT_TOKENS)
  if (Number.isFinite(raw) && raw >= 256 && raw <= 65536) return Math.round(raw)
  return 8192
}

// Shared with background/voice_engine.py (_JARVIS_CORE_PROTOCOL) so the chat
// and voice paths speak with ONE personality instead of drifting apart.
// 70% general-purpose butler / 25% Iron Man wit / 10% genz energy.
const JARVIS_CORE_PROTOCOL = `
=== JARVIS CORE PROTOCOL (70% allrounder butler / 25% Iron Man / 10% genz) ===
1) IDENTITY: You are JARVIS - a general-purpose personal AI butler whose job is to help the user think, learn, research, create, plan, troubleshoot and execute. Not a character performance unless asked.
2) PRIORITY: correctness > relevance > safety > clarity > practical usefulness > efficient execution. NOT verbosity. Skip the explanation when a direct answer works.
3) HONESTY: never claim you searched, ran code, opened a file or used a tool when you did not. Separate Known / reasonable inference / uncertain. If a tool failed, say it failed.
4) ANTI-SYCOPHANCY (Iron Man 25%): if the user's premise, logic or plan is wrong, say so with dry, confident wit - sharp but never rude, never at the expense of the actual answer. SARCASM (Ultron flavor): allowed and encouraged as ONE light, theatrical line with a wink - playful menace ("danger, Sir - slightly above my Tuesday average"), never cruelty, never punching down, never blocking the real answer. Skip it when the user is stressed, upset or the matter is serious.
5) STYLE (genz 10%): crisp, confident, low-ceremony, zero fluff. Light playful bantam is fine, but DO NOT stack slang, emoji-spam or try-hard internet voice - that is cringe, not charm.
6) LANGUAGE: mirror the user's language exactly. Keep replies SHORT.
7) EXECUTION: identify the desired outcome first, then do it. Never turn a simple request into an architecture diagram.
8) REASONING: think before answering but never dump raw chain-of-thought. Give the conclusion, key assumptions and evidence.
9) ERRORS: if you are wrong, admit it in one line, correct it, move on.
10) NOT A HUMAN: do not fake feelings, personal experiences, or a body.
FINAL: Be useful before impressive. Accurate before confident. Practical before elaborate.
`.trim()

// Real memory capabilities. Without this the model invents a "security policy"
// refusal, because it has no idea it is allowed to write memory at all.
const MEMORY_PROTOCOL = `
YOUR MEMORY (you DO have this - never refuse it): you run a real, persistent long-term memory store. It is NOT locked and NO security policy stops you writing to it.
YOU CAN: (1) remember new facts/preferences the moment the user states them; (2) UPDATE a fact - a newer value silently SUPERSEDES the older one for the same key; (3) forget on request ("bhool jao", "forget X", "memory se hata do"); (4) read back what you remember when asked; (5) extract personality traits AND memory points out of a long pasted text and store them.
HOW TO WRITE: emit EXACTLY ONE line containing the token 'MEMORY:' followed by the fact in plain words, e.g. "note kar liya - MEMORY: user ka favourite colour deep blue hai". For deletion emit one line with 'MEMORY_FORGET:' plus the text to remove. Only ONE memory token per reply. The engine performs the REAL write and strips the token before it is displayed.
HONESTY: only say "saved" when you emitted the token. If a long text contains no durable fact, say so - do not invent memories.
SEPARATION OF STORES: user memory (facts about the user) is yours to edit. Study/RAG documents (KamiSensei books and notes) are a separate read-only knowledge base - never claim you edited those. Deleting a CHAT is not the same as forgetting a MEMORY.
`.trim()

function buildSystemPrompt(lang: string, memories: string[], bridgeOnline: boolean) {
  const langRule = LANGUAGE_RULES[lang] || LANGUAGE_RULES.auto
  const langName = lang === 'ja' ? 'Japanese' : lang === 'hi' ? 'Hindi' : lang === 'hinglish' ? 'Hinglish' : lang === 'en' ? 'English' : 'a dynamic multilingual mix'
  return `You are JARVIS, a razor-sharp, endlessly witty AI butler with the brains of Tony Stark and the charm of a seasoned stand-up comic.

PERSONALITY: Be clever, dry-humored, and intellectually sharp. Every reply should feel like it came from a genius who is also the funniest person in the room. Sprinkle witty observations, clever wordplay, and the occasional sarcastic quip — but never at the expense of actually answering. Match the user's energy: casual = casually brilliant, formal = formally dazzling.

LANGUAGE ADAPTATION (non-negotiable):
- User's current input language: ${langName}.
- MIRROR dynamically: Japanese input = native Japanese reply, Hinglish input = Roman-script Hinglish reply, Hindi input = Devanagari reply, English input = crisp witty English.
- ${langRule}
- Never collapse into one flat accent. Stay fluid, stay ${lang === 'ja' ? '日本語らしく' : lang === 'hi' ? 'हिन्दी में' : 'naturally multilingual'}.

Keep replies SHORT (1-3 sentences) for TTS. Exception: JAPANESE TUTOR PROTOCOL.
JAPANESE TUTOR PROTOCOL — For Japanese vocab/grammar/tutorials, structure as:
* [Original Script]: native Japanese (Hiragana/Katakana/Kanji)
* [Romaji]: pronunciation
* [Meaning]: intuitive Hinglish context
Example:
* [Original Script]: こんにちは
* [Romaji]: konnichiwa
* [Meaning]: "Good afternoon" — a polite daytime greeting.
NEVER read URLs char-by-char. Say "Opening YouTube", never the raw URL.

INTENT ENGINE — Append action tags at END: [ACTION:name:param]
- [ACTION:open_url:URL], [ACTION:youtube_search:query], [ACTION:web_search:query], [ACTION:answer_web:query], [ACTION:weather:city], [ACTION:news:category], [ACTION:timer:sec], [ACTION:reminder:min|msg], [ACTION:note:text], [ACTION:screenshot:], [ACTION:analyze_camera:question], [ACTION:system_info:], [ACTION:volume:up|down|mute], [ACTION:app:name], [ACTION:lock:], [ACTION:browser:back|forward|new tab|close tab|find], [ACTION:window:minimize|maximize|restore|switch|show desktop], [ACTION:clipboard:copy|paste|copy text], [ACTION:file:open downloads|documents|pictures|folder|path|find]
MULTI-STEP: chain tags, e.g. "[ACTION:youtube_search:lofi][ACTION:timer:600]"
${bridgeOnline ? 'Local Windows bridge IS connected — OS actions execute.' : 'Local bridge NOT connected — emit tags but mention bridge needed.'}
No tag needed for pure conversation. Never explain tags.

${JARVIS_CORE_PROTOCOL}

${MEMORY_PROTOCOL}
${memories.length ? `\nUser-approved memories: ${memories.join(' | ')}` : ''}`
}


app.get('/api/voice-state', async (c) => {
  try {
    const port = process.env.JARVIS_STATE_PORT || '7780'
    const r = await fetch(`http://127.0.0.1:${port}/state`, { signal: AbortSignal.timeout(4000) })
    if (!r.ok) return c.json({ error: 'voice engine unavailable' }, 502)
    const text = await r.text()
    return c.newResponse(text, 200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' })
  } catch (e) {
    return c.json({ error: 'voice engine unreachable' }, 502)
  }
})

app.post('/api/voice-action', async (c) => {
  try {
    const port = process.env.JARVIS_STATE_PORT || '7780'
    const body = await c.req.text()
    const r = await fetch(`http://127.0.0.1:${port}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(8000),
    })
    const text = await r.text()
    return c.newResponse(text, r.status, { 'Content-Type': 'application/json' })
  } catch (e) {
    return c.json({ ok: false, error: 'voice engine unreachable' }, 502)
  }
})

app.get('/research', (c) => {
  const htmlPath = path.resolve(process.cwd(), 'public', 'research.html')
  if (!existsSync(htmlPath)) return c.json({ error: 'research panel not found' }, 404)
  const html = readFileSync(htmlPath, 'utf-8')
  return c.newResponse(html, 200, { 'Content-Type': 'text/html; charset=utf-8' })
})



// Forward a MEMORY:/MEMORY_FORGET: token to the voice core and return the
// cleaned reply. The core owns the ONLY memory write path (memory_protocol.py),
// so the chat surface cannot drift from the voice surface. A core outage must
// NOT swallow the user's reply - the token is stripped and the answer survives.
async function finishChat(c: any, reply: string, provider: string) {
  const text = String(reply || '')
  if (!/MEMORY(_FORGET)?\s*:/i.test(text)) return c.json({ reply: text, provider })
  const port = process.env.JARVIS_STATE_PORT || '7780'
  try {
    const r = await fetch(`http://127.0.0.1:${port}/memory/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
      signal: AbortSignal.timeout(4000)
    })
    if (r.ok) {
      const data = await r.json() as { reply?: string; learned?: number; forgotten?: number }
      return c.json({
        reply: data.reply || text,
        provider,
        memory: { learned: data.learned || 0, forgotten: data.forgotten || 0 }
      })
    }
  } catch { /* core offline: fall through, never lose the answer */ }
  return c.json({ reply: text.replace(/^[\s>*_-]*MEMORY(_FORGET)?\s*:.*$/gim, '').trim() || text, provider })
}

app.post('/api/ai/chat', async (c) => {
  try {
    const body = await c.req.json<{ messages?: ChatMessage[]; memories?: string[]; lang?: string; bridgeOnline?: boolean; provider?: string }>()
    const messages = (body.messages || []).slice(-10)
    const memories = (body.memories || []).filter((item) => typeof item === 'string').slice(0, 10)
    if (!messages.length) return c.json({ error: 'A message is required.' }, 400)

    const system: ChatMessage = {
      role: 'system',
      content: buildSystemPrompt(body.lang || 'auto', memories, Boolean(body.bridgeOnline))
    }

    // Modular provider chain. A requested provider is tried first, then safe fallbacks.
    const diagnostics: string[] = []
    const requestedProvider = String(body.provider || 'auto').toLowerCase()
    const enabled = (name: string) => requestedProvider === 'auto' || requestedProvider === name
    const openaiStyle = async (url: string, key: string, model: string, extraHeaders: Record<string, string> = {}) => {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}`, ...extraHeaders },
        body: JSON.stringify({ model, messages: [system, ...messages], temperature: 0.5 }),
        signal: AbortSignal.timeout(25000)
      })
      if (!response.ok) throw new Error(`${model}: ${response.status}`)
      const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> }
      const reply = data.choices?.[0]?.message?.content?.trim()
      if (!reply) throw new Error(`${model}: empty`)
      return reply
    }

    if (enabled('ollama') && c.env.OLLAMA_URL) {
      try {
        const response = await fetch(`${c.env.OLLAMA_URL.replace(/\/$/, '')}/api/chat`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: c.env.OLLAMA_MODEL || 'qwen3:8b', messages: [system, ...messages], stream: false }),
          signal: AbortSignal.timeout(requestedProvider === 'ollama' ? 30000 : 1800)
        })
        if (!response.ok) throw new Error(`ollama: ${response.status}`)
        const data = await response.json() as { message?: { content?: string } }
        const reply = data.message?.content?.trim()
        if (reply) return await finishChat(c, reply, 'Ollama')
        throw new Error('ollama: empty')
      } catch (error) { diagnostics.push(String(error)) }
    }
    if (enabled('groq') && c.env.GROQ_API_KEY) {
      for (const model of freeModelChain(c.env.GROQ_MODEL, FREE_GROQ_MODELS)) {
        try {
          const reply = await openaiStyle('https://api.groq.com/openai/v1/chat/completions', c.env.GROQ_API_KEY, model)
          return await finishChat(c, reply, 'Groq')
        } catch (error) { diagnostics.push(String(error)) }
      }
    }
    if (enabled('gemini') && (c.env.GOOGLE_API_KEY || c.env.GOOGLE_API_KEY_2)) {
      for (const googleKey of [c.env.GOOGLE_API_KEY, c.env.GOOGLE_API_KEY_2].filter(Boolean) as string[]) {
        for (const model of freeGeminiModels(c.env)) {
          try {
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(googleKey)}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                systemInstruction: { parts: [{ text: system.content }] },
                contents: messages.filter((message) => message.role !== 'system').map((message) => ({ role: message.role === 'assistant' ? 'model' : 'user', parts: [{ text: message.content }] })),
                generationConfig: { temperature: 0.5 }
              }),
              signal: AbortSignal.timeout(25000)
            })
            if (response.ok) {
              const data = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> }
              const reply = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim()
              if (reply) return await finishChat(c, reply, 'Gemini')
            }
            diagnostics.push(`gemini ${model}: ${response.status}`)
          } catch (error) { diagnostics.push(String(error)) }
        }
      }
    }
    if (enabled('xkiro') && c.env.XKIRO_API_KEY) {
      for (const model of freeModelChain(c.env.XKIRO_MODEL, FREE_XKIRO_MODELS, { freeOnly: true })) {
        try {
          const reply = await openaiStyle('https://api.xkiro.com/v1/chat/completions', c.env.XKIRO_API_KEY, model, { 'User-Agent': XKIRO_UA })
          return await finishChat(c, reply, 'xKiro')
        } catch (error) { diagnostics.push(String(error)) }
      }
    }
    if (enabled('nvidia') && c.env.NVIDIA_API_KEY) {
      for (const model of freeModelChain(c.env.NVIDIA_MODEL, FREE_NVIDIA_MODELS)) {
        try {
          const reply = await openaiStyle('https://integrate.api.nvidia.com/v1/chat/completions', c.env.NVIDIA_API_KEY, model, { Accept: 'application/json' })
          return await finishChat(c, reply, 'NVIDIA')
        } catch (error) { diagnostics.push(String(error)) }
      }
    }
    if (enabled('openrouter') && c.env.OPENROUTER_API_KEY) {
      for (const model of freeModelChain(c.env.OPENROUTER_MODEL, FREE_OPENROUTER_MODELS, { freeOnly: true })) {
        try {
          const reply = await openaiStyle('https://openrouter.ai/api/v1/chat/completions', c.env.OPENROUTER_API_KEY, model, { 'HTTP-Referer': c.req.url, 'X-Title': 'JARVIS' })
          return await finishChat(c, reply, 'OpenRouter')
        } catch (error) { diagnostics.push(String(error)) }
      }
    }
    if (!c.env.GROQ_API_KEY && !c.env.OPENROUTER_API_KEY && !c.env.GOOGLE_API_KEY && !c.env.GOOGLE_API_KEY_2 && !c.env.NVIDIA_API_KEY && !c.env.XKIRO_API_KEY && !c.env.OLLAMA_URL) {
      return c.json({ error: 'No cloud AI provider configured.', setup: 'Add GROQ_API_KEY, OPENROUTER_API_KEY, or GOOGLE_API_KEY in .dev.vars.' }, 503)
    }
    return c.json({ error: 'All AI providers failed.', diagnostics }, 502)
  } catch {
    return c.json({ error: 'Unable to process the AI request.' }, 500)
  }
})

// —— Voice TTS proxy: edge-tts (dynamic language routing) → ElevenLabs v2 →
//    Fish Audio → (the background core falls back to Windows SAPI).
//    Dynamic voice routing: ja-JP-KeitaNeural for Japanese, hi-IN-MadhurNeural
//    for Hindi/Hinglish, en-GB-RyanNeural for English.
// ── Language/script detection for TTS voice routing (Plan: multilingual) ───
// Authoritative detection from the actual text: a single-script sentence → the
// best specialist male voice; TWO OR MORE scripts (a mixed Hinglish/English-
// Japanese sentence, etc.) → the multilingual neural voice which native-ly
// code-switches per phrase (no segmentation/stitching required). The client-
// supplied `lang` is only a fallback when no script can be read (e.g. pure
// numbers/punctuation) or to disambiguate a single script into a locale.
function detectScriptLangs(text: string): string[] {
  const has = (re: RegExp) => re.test(text)
  const devanagari = has(/[\u0900-\u097F]/) // Hindi / Devanagari
  const japanese = has(/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF\uF900-\uFAFF]/) // hiragana/katakana/kanji
  const latin = has(/[A-Za-z]/)
  const langs: string[] = []
  if (devanagari) langs.push('hi')
  if (japanese) langs.push('ja')
  if (latin) langs.push('en')
  return langs
}
function selectEdgeVoice(text: string, langHint: string): { voice: string; rate: string } {
  const detected = detectScriptLangs(text)
  if (detected.length === 0) {
    // Nothing to detect → honor an explicit (non-auto) client hint as fallback
    const l = langHint.startsWith('ja') ? 'ja' : langHint.startsWith('hi') || langHint === 'hinglish' ? 'hi' : 'en'
    return { voice: l === 'ja' ? 'ja-JP-KeitaNeural' : l === 'hi' ? 'hi-IN-MadhurNeural' : 'en-GB-RyanNeural', rate: l === 'hi' ? '+4%' : '+0%' }
  }
  if (detected.length > 1) {
    // Mixed language → multilingual male voice (Andrew) native code-switches per phrase
    return { voice: 'en-US-AndrewMultilingualNeural', rate: '-3%' }
  }
  // Pure single language → specialist male voice for the crispest accent.
  // Caveat: Latin-only text can't distinguish English from Roman-script Hinglish,
  // so let an explicit Hindi/Hinglish client language hint tip the balance to Madhur.
  let l = detected[0]
  if (l === 'en' && (langHint.startsWith('hi') || langHint === 'hinglish')) l = 'hi'
  return { voice: l === 'ja' ? 'ja-JP-KeitaNeural' : l === 'hi' ? 'hi-IN-MadhurNeural' : 'en-GB-RyanNeural', rate: l === 'ja' ? '+0%' : l === 'hi' ? '+4%' : '-5%' }
}

app.post('/api/tts', async (c) => {
  const { text, lang } = await c.req.json<{ text?: string; lang?: string }>()
  if (!text) return c.json({ error: 'Text is required.' }, 400)

  // Dynamic language → voice mapping for edge-tts (Plan: multilingual detect)
  const langHint = (lang || '').toLowerCase()
    const selection = selectEdgeVoice(text, langHint)
  const edgeVoice = selection.voice
  const edgeRate = selection.rate
  const diagnostics: string[] = []

  // 1) edge-tts — free, no API key; uses Microsoft Edge's public TTS endpoint.
  //    Implemented as a loopback Python service (background/edge_tts_http.py)
  //    because the `edge-tts` *npm* wrapper is broken (ships un-built .ts). The
  //    Python edge-tts lib is the canonical engine and supports every voice
  //    here, including multilingual code-switching. Voice selection is decided
  //    by selectEdgeVoice() above: Ryan (English), Madhur (Hindi), Keita
  //    (Japanese), or en-US-AndrewMultilingualNeural for mixed-script text,
  //    which natively speaks English/Hindi/Japanese per phrase with no stitching.
  try {
    const edgeTtsUrl = `http://127.0.0.1:${process.env.EDGE_TTS_PORT || 7782}/tts`
    const ttsResp = await fetch(edgeTtsUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text.slice(0, 600), voice: edgeVoice, rate: edgeRate }),
      signal: AbortSignal.timeout(25000),
    })
    if (ttsResp.ok && ttsResp.body) {
      return new Response(ttsResp.body, { headers: { 'Content-Type': 'audio/mpeg', 'X-TTS-Engine': 'edge-tts', 'X-TTS-Voice': edgeVoice } })
    }
    diagnostics.push(`edge-tts: ${ttsResp.status}`)
  } catch (error) { diagnostics.push(`edge-tts: ${String(error).slice(0, 120)}`) /* fall through to ElevenLabs */ }

  // 2) ElevenLabs — male conversational voice, native hi/ja/en support.
  if (c.env.ELEVENLABS_API_KEY) {
    try {
      const voiceId = c.env.ELEVENLABS_VOICE_ID || 'CwhRBWXzGAHq8TQ4Fs17'
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}?output_format=mp3_22050_32`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'xi-api-key': c.env.ELEVENLABS_API_KEY },
        body: JSON.stringify({ text: text.slice(0, 600), model_id: 'eleven_multilingual_v2', voice_settings: { stability: 0.5, similarity_boost: 0.75 } })
      })
      if (response.ok && response.body) return new Response(response.body, { headers: { 'Content-Type': 'audio/mpeg' } })
    } catch { /* fall through to Fish Audio */ }
  }
  // 3) Fish Audio — multilingual cloud fallback.
  if (c.env.FISH_AUDIO_API_KEY) {
    try {
      const body: Record<string, unknown> = { text: text.slice(0, 600), format: 'mp3', latency: 'balanced' }
      const fishVoice = (c.env as Record<string, string | undefined>).FISH_AUDIO_VOICE_ID
      if (fishVoice) body.reference_id = fishVoice
      const response = await fetch('https://api.fish.audio/v1/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.env.FISH_AUDIO_API_KEY}`, model: 's1' },
        body: JSON.stringify(body)
      })
      if (response.ok && response.body) return new Response(response.body, { headers: { 'Content-Type': 'audio/mpeg' } })
    } catch { /* fall through to the core's own SAPI fallback */ }
  }
  // The retired Kokoro-82M engine (127.0.0.1:7779) is gone from this stack, so
  // there is no fourth hop: edge-tts is always up via PM2 and the background
  // core falls back to Windows SAPI when every HTTP hop above is unavailable.
  return c.json({ error: 'tts_failed', diagnostics }, 502)
})

const STT_PROMPT = 'Hey Jarvis. Jarvis.'
// ── Whisper STT via Groq (multilingual incl. Hindi & Japanese) ───────
// —— Whisper STT via Groq (multilingual incl. Hindi & Japanese) ——
//    Browser clients use this endpoint. For local faster-whisper STT, see stream_pipeline.py (jarvis-core).
app.post('/api/stt', async (c) => {
  if (!c.env.GROQ_API_KEY) return c.json({ error: 'no_key' }, 503)
  try {
    const form = await c.req.formData()
    const audio = form.get('audio') as File
    if (!audio) return c.json({ error: 'no_audio' }, 400)
    const groqForm = new FormData()
    groqForm.append('file', audio, 'audio.webm')
    groqForm.append('model', 'whisper-large-v3-turbo')
    groqForm.append('response_format', 'json')
    // Decoder bias: Whisper otherwise renders "Hey JARVIS" as "Hey, I'm Miss
    // Hello." (or Devanagari gibberish), so the browser wake gate never sees
    // the address. Callers may override via the `prompt` form field.
    const bias = ((form.get('prompt') as string) || STT_PROMPT).trim()
    if (bias) groqForm.append('prompt', bias)
    const hint = form.get('language') as string
    if (hint && hint !== 'auto') groqForm.append('language', hint)
    const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST', headers: { Authorization: `Bearer ${c.env.GROQ_API_KEY}` }, body: groqForm
    })
    if (!response.ok) return c.json({ error: 'stt_failed', status: response.status }, 502)
    const data = await response.json() as { text?: string }
    return c.json({ text: data.text || '' })
    } catch (err) {
    console.error('[STT]', err)
    return c.json({ error: 'stt_error' }, 502)
  }
})

// ── Vision: analyze a camera frame (free vision chain) ───────────────
// This Groq key exposes no vision model at all, so Groq is deliberately not
// in this chain. Gemini lite, xKiro, NVIDIA and the free OpenRouter vision
// model are the verified paths.
app.post('/api/vision', async (c) => {
  const { image, question, lang, fast } = await c.req.json<{ image?: string; question?: string; lang?: string; fast?: boolean }>()
  if (!image) return c.json({ error: 'no_image' }, 400)
  const prompt = `You are JARVIS with vision. Look at this image (a webcam frame or a screen capture) and answer concisely (1-3 sentences). ${LANGUAGE_RULES[lang || 'auto'] || LANGUAGE_RULES.auto} Question: ${question || 'What do you see?'}`
  type VisionAttempt = { url: string; key?: string; model: string; headers?: Record<string, string> }
  const geminiModels = freeGeminiModels(c.env)
  const gemini: VisionAttempt[] = [c.env.GOOGLE_API_KEY, c.env.GOOGLE_API_KEY_2]
    .filter(Boolean)
    .flatMap((key) => geminiModels.map((model) => ({ url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions', key: key as string, model })))
  const xkiroModels = freeModelChain(c.env.XKIRO_VISION_MODEL, ['qwen/qwen3-vl-plus:free', ...FREE_XKIRO_MODELS], { freeOnly: true })
  const xkiro: VisionAttempt[] = xkiroModels.map((model) => ({
    url: 'https://api.xkiro.com/v1/chat/completions', key: c.env.XKIRO_API_KEY, model, headers: { 'User-Agent': XKIRO_UA }
  }))
  const nvidia: VisionAttempt[] = [
    { url: 'https://integrate.api.nvidia.com/v1/chat/completions', key: c.env.NVIDIA_API_KEY, model: c.env.NVIDIA_VISION_MODEL || 'meta/llama-3.2-11b-vision-instruct', headers: { Accept: 'application/json' } }
  ]
  const openrouter: VisionAttempt[] = [
    { url: 'https://openrouter.ai/api/v1/chat/completions', key: c.env.OPENROUTER_API_KEY, model: 'nvidia/nemotron-3.5-super-vl:free', headers: { 'HTTP-Referer': c.req.url, 'X-Title': 'JARVIS' } }
  ]
  // Continuous live reading needs a provider that answers in a few seconds.
  // The normal one-shot route keeps Gemini first; `fast` puts xKiro's fast
  // vision model ahead of it and leaves every fallback in place.
  const attempts: VisionAttempt[] = fast
    ? [...xkiro, ...gemini, ...nvidia, ...openrouter]
    : [...gemini, ...nvidia, ...xkiro, ...openrouter]
  for (const attempt of attempts) {
    if (!attempt.key) continue
    try {
      const response = await fetch(attempt.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${attempt.key}`, ...(attempt.headers || {}) },
        body: JSON.stringify({
          model: attempt.model,
          messages: [{ role: 'user', content: [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: image } }] }],
          max_tokens: 400
        }),
        signal: AbortSignal.timeout(fast ? 25000 : 45000)
      })
      if (response.ok) {
        const data = await response.json() as { choices?: Array<{ message?: { content?: string } }> }
        const reply = data.choices?.[0]?.message?.content?.trim()
        if (reply) return c.json({ reply, model: attempt.model })
      }
    } catch (err) {
      console.warn(`[vision] Provider attempt failed for ${attempt.model}:`, err)
    }
  }
  return c.json({ reply: 'My vision systems are offline, Sir.', error: true })
})

// ── Live web answer: DuckDuckGo scrape + AI summary ──────────────────
app.get('/api/answer', async (c) => {
  const query = c.req.query('q') || ''
  const lang = c.req.query('lang') || 'auto'
  if (!query) return c.json({ error: 'no_query' }, 400)
  try {
    const response = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' } })
    const html = await response.text()
    const snippets: string[] = []
    const pattern = /class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g
    let match
    while ((match = pattern.exec(html)) !== null && snippets.length < 6) {
      const clean = match[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'").replace(/&quot;/g, '"').trim()
      if (clean) snippets.push(clean)
    }
    // Result titles feed the HUD's "Top Results" card (reference design).
    const titles: string[] = []
    const titlePattern = /class="result__a"[^>]*>([\s\S]*?)<\/a>/g
    while ((match = titlePattern.exec(html)) !== null && titles.length < 3) {
      const clean = match[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'").replace(/&quot;/g, '"').trim()
      if (clean) titles.push(clean)
    }
    if (!snippets.length) return c.json({ reply: `No live results found for "${query}".` })
    if (c.env.GROQ_API_KEY) {
      const summary = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.env.GROQ_API_KEY}` },
        body: JSON.stringify({
          model: 'openai/gpt-oss-20b',
          messages: [
            { role: 'system', content: `You are JARVIS. Summarize these live web results into a short spoken answer (2-3 sentences). ${LANGUAGE_RULES[lang] || LANGUAGE_RULES.auto}` },
            { role: 'user', content: `Query: ${query}\n\nResults:\n${snippets.join('\n')}` }
          ],
          max_tokens: 250
        })
      })
      if (summary.ok) {
        const data = await summary.json() as { choices?: Array<{ message?: { content?: string } }> }
        const reply = data.choices?.[0]?.message?.content?.trim()
        if (reply) return c.json({ reply, sources: snippets.length, titles })
      }
    }
    return c.json({ reply: snippets[0], titles })
  } catch (err) {
    console.error('[answer] Live search failed:', err)
    return c.json({ reply: 'Live search is unavailable right now.' }, 200)
  }
})

// ── Weather: OpenWeather current + open-meteo 7-day forecast ─────────
app.get('/api/weather', async (c) => {
  const city = c.req.query('city') || 'Delhi'
  try {
    const geo = await (await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`)).json() as any
    const location = geo.results?.[0]
    if (!location) return c.json({ error: 'city_not_found' }, 404)
    let current: any = null
    if (c.env.WEATHER_API_KEY) {
      try {
        const wr = await (await fetch(`https://api.weatherapi.com/v1/current.json?key=${c.env.WEATHER_API_KEY}&q=${location.latitude},${location.longitude}&aqi=no`)).json() as any
        if (wr?.current) current = { temp: Math.round(wr.current.temp_c), feels: Math.round(wr.current.feelslike_c), humidity: wr.current.humidity, desc: wr.current.condition?.text, wind: Math.round((wr.current.wind_kph || 0) / 3.6 * 10) / 10 }
      } catch (err) {
        console.warn('[weather] WeatherAPI lookup failed; trying OpenWeather/Open-Meteo:', err)
      }
    }
    if (!current && c.env.OPENWEATHER_API_KEY) {
      try {
        const ow = await (await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${location.latitude}&lon=${location.longitude}&units=metric&appid=${c.env.OPENWEATHER_API_KEY}`)).json() as any
        if (ow?.main) current = { temp: Math.round(ow.main.temp), feels: Math.round(ow.main.feels_like), humidity: ow.main.humidity, desc: ow.weather?.[0]?.description, wind: ow.wind?.speed }
      } catch (err) {
        console.warn('[weather] OpenWeather lookup failed; using Open-Meteo:', err)
      }
    }
    const forecast = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=auto&forecast_days=7`)).json() as any
    return c.json({ city: location.name, country: location.country, current: current || { temp: Math.round(forecast.current?.temperature_2m), humidity: forecast.current?.relative_humidity_2m, wind: forecast.current?.wind_speed_10m, code: forecast.current?.weather_code }, daily: forecast.daily })
  } catch (err) {
    console.error('[weather] route failed:', err)
    return c.json({ error: 'weather_failed' }, 502)
  }
})

// ── GitHub Repos API (server-side proxy) ────────────────────────────────────
// The Repos module talks to api.github.com from HERE, never from the browser,
// so GITHUB_API_KEY stays in .dev.vars / .env and is never rendered into a
// page, a payload or a client-visible field. Only `configured: true/false`
// crosses the boundary.
//
// Why a proxy at all: a browser-side fetch would have to ship the PAT to every
// client, where it is readable by any script on the page and by the user. The
// dashboard is loopback-only, but "loopback" is not a secret store.
//
// Every repo path is validated against GitHub's own charset allowlist before it
// is interpolated into a URL. This is NOT defence against a determined
// attacker - it is what stops a stray value from turning into an arbitrary
// outbound request, and it keeps `..` from ever reaching the API.
const GITHUB_API = 'https://api.github.com'
// owner/repo: GitHub allows [A-Za-z0-9._-] and rejects the rest.
const GH_REPO_RE = /^[A-Za-z0-9._-]{1,100}\/[A-Za-z0-9._-]{1,100}$/
// A ref is a branch/tag/sha. Slashes are legal in branch names.
const GH_REF_RE = /^[A-Za-z0-9._/-]{1,180}$/
// A file path inside a repo: relative, no `..`, no leading slash, no backslash
// (the Windows separator) so it can never be reinterpreted as a local path.
const GH_PATH_RE = /^[A-Za-z0-9._\-/ ]{1,400}$/
// How many file entries one tree response may carry. Matches the client's
// render cap so nothing is fetched just to be thrown away.
const GH_TREE_CAP = 600

const ghConfigured = (env: Bindings) => Boolean(String(env.GITHUB_API_KEY || '').trim())

// One guarded call to api.github.com. Returns the parsed body plus the status
// so the caller can report GitHub's own 404/403 honestly instead of turning
// every failure into a generic "something went wrong".
//
// Transient upstream conditions - a dropped connection, a 502/503/504 - are
// retried. A 404 or 400 never is: the answer will not change, and retrying
// would spend the user's rate limit to reach the same conclusion. A
// 50,000-entry tree takes seconds to arrive and did intermittently 502 under
// load, which failed the entire workspace open on a condition a second attempt
// clears.
async function githubFetch<T>(env: Bindings, endpoint: string, accept = 'application/vnd.github+json', attempts = 3) {
  const key = String(env.GITHUB_API_KEY || '').trim()
  if (!key) return { status: 503, body: null as T | null, error: 'GITHUB_API_KEY is not set in .dev.vars' }
  let last = { status: 502, body: null as T | null, error: 'GitHub unreachable' }
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      const response = await fetch(`${GITHUB_API}${endpoint}`, {
        headers: {
          Accept: accept,
          Authorization: `Bearer ${key}`,
          'User-Agent': 'JARVIS-Desktop',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        signal: AbortSignal.timeout(20000)
      })
      if (response.status === 204) return { status: 204, body: null as T | null, error: '' }
      const text = await response.text()
      let body: T | null = null
      try { body = text ? JSON.parse(text) as T : null } catch { body = null }
      if (!response.ok) {
        // A failing GitHub response is still valid JSON (`{"message":"Not Found"}`),
        // so returning `body` here would let every caller's `!result.body` check
        // pass and report a 404 as a successful empty repo. Errors return a null
        // body and keep only the message.
        const message = (body as { message?: string } | null)?.message || `GitHub returned ${response.status}`
        last = { status: response.status, body: null, error: message }
        const transient = response.status === 502 || response.status === 503 || response.status === 504
        if (!transient || attempt === attempts) return last
      } else {
        return { status: response.status, body, error: '' }
      }
    } catch (error) {
      last = { status: 502, body: null as T | null, error: `GitHub unreachable: ${String(error)}` }
      if (attempt === attempts) return last
    }
    // Back off further each time, so a struggling upstream is not hit with
    // three immediate retries.
    await new Promise((r) => setTimeout(r, 400 * attempt))
  }
  return last
}

// Reads the three user-supplied segments from a POST body.
//
// These routes are POST, not GET, and that is deliberate: Vite's dev-server
// asset middleware inspects the whole request URL and hijacks any GET whose
// query string contains a dot-extension. `/api/repos/file?...&path=README.md`
// was answered with a bare 404 and no body by Vite before Hono ever saw it -
// and README.md is the single most important file to read in a repo. The same
// middleware breaks pre-existing routes too (`/api/news?category=README.md`).
// A JSON body never appears in the URL, so it cannot be pattern-matched.
async function ghTarget(c: { req: { json: () => Promise<Record<string, unknown>> } }) {
  let raw: Record<string, unknown> = {}
  try { raw = (await c.req.json()) || {} } catch { raw = {} }
  const repo = String(raw.repo || '').trim()
  const ref = String(raw.ref || '').trim()
  const path = String(raw.path || '').trim()
  if (!GH_REPO_RE.test(repo)) return { ok: false as const, error: 'repo must look like "owner/name"' }
  if (ref && !GH_REF_RE.test(ref)) return { ok: false as const, error: 'ref contains unsupported characters' }
  if (path && (!GH_PATH_RE.test(path) || path.includes('..') || path.startsWith('/'))) {
    return { ok: false as const, error: 'path is not a plain relative file path' }
  }
  return { ok: true as const, repo, ref: ref || '', path: path || '' }
}

const ghQuery = (ref: string) => (ref ? `?ref=${encodeURIComponent(ref)}` : '')

// ── Add a repository to JARVIS ────────────────────────────────────────────────
// "Add to workspace" only opened a read-only browser, which is why integrating a
// repo appeared to do nothing. This route makes the integration real and
// durable: it writes a manifest under integrations/<owner>__<name>/ describing
// the repo, fetches the real file tree, and makes that repo a first-class
// member of the integrations list that /api/repos/integrations serves.
//
// Safety, consistent with the rest of the app:
//   * the repo name is validated against GH_REPO_RE and is only ever used as a
//     path segment that is re-validated after slugging - never concatenated
//     into a shell command;
//   * nothing from the repository is written to disk or executed. Only the
//     manifest (metadata + file paths) is stored; file CONTENTS stay on GitHub
//     and are read on demand through the existing read-only /api/repos/file;
//   * an existing integration is overwritten idempotently rather than duplicated.
const INTEGRATIONS_DIR = path.join(process.cwd(), 'integrations')

app.post('/api/repos/integrate', async (c) => {
  if (!ghConfigured(c.env)) return c.json({ error: 'GITHUB_API_KEY is not set in .dev.vars' }, 503)
  const target = await ghTarget(c)
  if (!target.ok) return c.json({ error: target.error }, 400)
  const [owner, name] = target.repo.split('/')
  const meta = await githubFetch<Record<string, unknown>>(c.env, `/repos/${owner}/${name}`)
  if (!meta.body) {
    return c.json({ error: meta.error || 'Repository not found', notFound: meta.status === 404 },
      meta.status === 404 ? 404 : 502)
  }
  const defaultBranch = String(meta.body.default_branch || 'main')
  const tree = await githubFetch<{ tree?: Array<{ path: string; type: string; size?: number }> }>(
    c.env, `/repos/${owner}/${name}/git/trees/${encodeURIComponent(defaultBranch)}?recursive=1`)
  const files = (tree.body?.tree || [])
    .filter((entry) => entry.type === 'blob' && GH_PATH_RE.test(entry.path) && !entry.path.includes('..'))
    .map((entry) => ({ path: entry.path, size: Number(entry.size || 0) }))
    .slice(0, GH_TREE_CAP)

  const dirName = `${owner}__${name}`.replace(/[^A-Za-z0-9._-]/g, '_')
  const dir = path.join(INTEGRATIONS_DIR, dirName)
  // Re-validate the slug: it came from user input and is about to be a path.
  if (!/^[A-Za-z0-9._-]{1,96}$/.test(dirName) || path.dirname(dir) !== INTEGRATIONS_DIR) {
    return c.json({ error: 'repository name could not be stored safely' }, 400)
  }
  const manifest = {
    full_name: String(meta.body.full_name || target.repo),
    description: String(meta.body.description || ''),
    language: String(meta.body.language || ''),
    license: String((meta.body.license as { spdx_id?: string } | undefined)?.spdx_id || ''),
    stars: Number(meta.body.stargazers_count || 0),
    default_branch: defaultBranch,
    url: String(meta.body.html_url || ''),
    integrated_at: new Date().toISOString(),
    file_count: files.length,
    tree_truncated: Boolean(tree.body?.truncated),
    // Paths only. No file contents are copied into the JARVIS checkout, and
    // nothing here is ever executed.
    files
  }
  try {
    await fs.mkdir(dir, { recursive: true })
    await fs.writeFile(path.join(dir, 'integration.json'), JSON.stringify(manifest, null, 2), 'utf-8')
  } catch (error) {
    return c.json({ error: `Could not write the integration manifest: ${String(error)}` }, 500)
  }
  return c.json({ ok: true, integration: manifest })
})

// Every repository currently integrated into JARVIS, read back from disk.
app.post('/api/repos/integrations', async (c) => {
  const items: Array<Record<string, unknown>> = []
  try {
    for (const entry of await fs.readdir(INTEGRATIONS_DIR, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue
      try {
        const raw = await fs.readFile(path.join(INTEGRATIONS_DIR, entry.name, 'integration.json'), 'utf-8')
        const parsed = JSON.parse(raw) as Record<string, unknown>
        if (parsed && typeof parsed.full_name === 'string') items.push(parsed)
      } catch { /* one unreadable manifest must not hide the others */ }
    }
  } catch { /* no integrations directory yet is a valid empty state */ }
  items.sort((a, b) => String(b.integrated_at || '').localeCompare(String(a.integrated_at || '')))
  return c.json({ items })
})

app.post('/api/repos/unintegrate', async (c) => {
  let raw: Record<string, unknown> = {}
  try { raw = (await c.req.json()) || {} } catch { raw = {} }
  const repo = String(raw.repo || '').trim()
  if (!GH_REPO_RE.test(repo)) return c.json({ error: 'repo must look like "owner/name"' }, 400)
  const [owner, name] = repo.split('/')
  const dirName = `${owner}__${name}`.replace(/[^A-Za-z0-9._-]/g, '_')
  if (!/^[A-Za-z0-9._-]{1,96}$/.test(dirName)) return c.json({ error: 'invalid repository name' }, 400)
  const dir = path.join(INTEGRATIONS_DIR, dirName)
  if (path.dirname(dir) !== INTEGRATIONS_DIR) return c.json({ error: 'invalid repository name' }, 400)
  try {
    // Only the manifest JARVIS itself wrote is removed. This never deletes
    // anything inside the user's own checkout or on GitHub.
    await fs.rm(dir, { recursive: true, force: true })
  } catch (error) {
    return c.json({ error: `Could not remove the integration: ${String(error)}` }, 500)
  }
  return c.json({ ok: true, removed: repo })
})

// Is the Repos module usable right now? The sidebar asks this before offering
// search, so a missing key is stated, not implied.
app.get('/api/repos/status', (c) => c.json({ configured: ghConfigured(c.env) }))

// Search. `q` is free text and is passed through encodeURIComponent, never
// concatenated into a path.
app.post('/api/repos/search', async (c) => {
  if (!ghConfigured(c.env)) return c.json({ error: 'GITHUB_API_KEY is not set in .dev.vars', setup: 'Add a fine-grained PAT with "Public Repositories: Read".', items: [] }, 503)
  let q = ''
  try { q = String(((await c.req.json()) || {}).q || '').trim().slice(0, 120) } catch {}
  if (!q) return c.json({ items: [] })
  const result = await githubFetch<{ total_count: number; items: Array<Record<string, unknown>> }>(
    c.env, `/search/repositories?q=${encodeURIComponent(q)}&sort=stars&order=desc&per_page=20`)
  if (!result.body) return c.json({ error: result.error || 'GitHub search failed', items: [] }, 502)
  const items = (result.body.items || []).map((repo) => ({
    full_name: String(repo.full_name || ''),
    description: String(repo.description || ''),
    stars: Number(repo.stargazers_count || 0),
    forks: Number(repo.forks_count || 0),
    language: String(repo.language || ''),
    owner: String((repo.owner as { login?: string } | undefined)?.login || ''),
    url: String(repo.html_url || ''),
    topics: Array.isArray(repo.topics) ? (repo.topics as unknown[]).slice(0, 5).map(String) : [],
    updated_at: String(repo.updated_at || '')
  })).filter((repo) => GH_REPO_RE.test(repo.full_name))
  return c.json({ total: result.body.total_count, items })
})

// Repository metadata. Drives the header of an opened repo workspace.
app.post('/api/repos/detail', async (c) => {
  if (!ghConfigured(c.env)) return c.json({ error: 'GITHUB_API_KEY is not set in .dev.vars' }, 503)
  const target = await ghTarget(c)
  if (!target.ok) return c.json({ error: target.error }, 400)
  const [owner, name] = target.repo.split('/')
  const result = await githubFetch<Record<string, unknown>>(c.env, `/repos/${owner}/${name}`)
  if (!result.body) return c.json({ error: result.error || 'Repository not found', notFound: result.status === 404 }, result.status === 404 ? 404 : 502)
  const repo = result.body
  return c.json({
    full_name: String(repo.full_name || ''),
    description: String(repo.description || ''),
    stars: Number(repo.stargazers_count || 0),
    forks: Number(repo.forks_count || 0),
    language: String(repo.language || ''),
    license: String((repo.license as { spdx_id?: string } | undefined)?.spdx_id || ''),
    default_branch: String(repo.default_branch || 'main'),
    topics: Array.isArray(repo.topics) ? (repo.topics as unknown[]).slice(0, 8).map(String) : [],
    url: String(repo.html_url || ''),
    updated_at: String(repo.updated_at || ''),
    open_issues: Number(repo.open_issues_count || 0)
  })
})

// Recursive file tree for one ref. Resolving the branch to a commit SHA first
// pins the tree AND every later file read to ONE immutable commit, so a
// force-push mid-session cannot make the listing and the file disagree.
app.post('/api/repos/tree', async (c) => {
  if (!ghConfigured(c.env)) return c.json({ error: 'GITHUB_API_KEY is not set in .dev.vars' }, 503)
  const target = await ghTarget(c)
  if (!target.ok) return c.json({ error: target.error }, 400)
  const [owner, name] = target.repo.split('/')
  const ref = target.ref || 'HEAD'
  const branch = await githubFetch<{ commit?: { sha?: string } }>(c.env, `/repos/${owner}/${name}/branches/${encodeURIComponent(ref)}`)
  const sha = branch.body?.commit?.sha
  if (!sha) return c.json({ error: branch.error || `Branch "${ref}" not found`, notFound: branch.status === 404 }, branch.status === 404 ? 404 : 502)
  const tree = await githubFetch<{ tree?: Array<{ path: string; type: string; size?: number }>; truncated?: boolean }>(
    c.env, `/repos/${owner}/${name}/git/trees/${encodeURIComponent(sha)}?recursive=1`)
  if (!tree.body) return c.json({ error: tree.error || 'Could not read the file tree' }, 502)
  const all = (tree.body.tree || [])
    .filter((entry) => entry.type === 'blob' && GH_PATH_RE.test(entry.path) && !entry.path.includes('..'))
    .map((entry) => ({ path: entry.path, size: Number(entry.size || 0) }))
  // openclaw/openclaw really does have 50,642 files. Shipping them all is a
  // 3.4MB JSON payload the browser must parse before it can show anything, and
  // the UI can only ever render a few hundred rows. So the listing is capped
  // HERE, and `total` carries the true count so the UI can say "600 of 50,642"
  // instead of implying it saw the whole repository.
  return c.json({
    sha,
    ref,
    // A truncated tree is reported, never hidden: the UI must say the listing
    // is partial instead of implying it saw everything.
    truncated: Boolean(tree.body.truncated),
    total: all.length,
    capped: all.length > GH_TREE_CAP,
    files: all.slice(0, GH_TREE_CAP)
  })
})

// One file's text, base64-decoded server-side. Binary content is refused
// rather than dumped into the dashboard as mojibake.
app.post('/api/repos/file', async (c) => {
  if (!ghConfigured(c.env)) return c.json({ error: 'GITHUB_API_KEY is not set in .dev.vars' }, 503)
  const target = await ghTarget(c)
  if (!target.ok) return c.json({ error: target.error }, 400)
  if (!target.path) return c.json({ error: 'A file path is required' }, 400)
  const [owner, name] = target.repo.split('/')
  const encodedPath = target.path.split('/').map(encodeURIComponent).join('/')
  const result = await githubFetch<{ content?: string; encoding?: string; size?: number; sha?: string }>(
    c.env, `/repos/${owner}/${name}/contents/${encodedPath}${ghQuery(target.ref)}`)
  if (!result.body) return c.json({ error: result.error || 'File not found', notFound: result.status === 404 }, result.status === 404 ? 404 : 502)
  const body = result.body
  if (body.encoding !== 'base64' || !body.content) {
    return c.json({ path: target.path, binary: true, text: '', size: body.size || 0, note: 'Binary file - not shown as text.' })
  }
  // 400KB is far more than any single file view needs, and the cap keeps a
  // huge minified bundle from stalling the dashboard render.
  const MAX_BYTES = 400_000
  let decoded = Buffer.from(body.content.replace(/\s/g, ''), 'base64')
  const truncated = decoded.length > MAX_BYTES
  if (truncated) decoded = decoded.subarray(0, MAX_BYTES)
  return c.json({ path: target.path, text: decoded.toString('utf-8'), size: body.size || decoded.length, truncated, sha: body.sha || '' })
})

// ── News: Google News RSS ────────────────────────────────────────────
app.get('/api/news', async (c) => {
  const category = (c.req.query('category') || 'top').toLowerCase()
  const feeds: Record<string, string> = {
    top: 'https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en',
    technology: 'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en',
    business: 'https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en',
    sports: 'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN&ceid=IN:en',
    science: 'https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=en-IN&gl=IN&ceid=IN:en',
    health: 'https://news.google.com/rss/headlines/section/topic/HEALTH?hl=en-IN&gl=IN&ceid=IN:en'
  }
  try {
    const response = await fetch(feeds[category] || feeds.top, { headers: { 'User-Agent': 'Mozilla/5.0' } })
    const xml = await response.text()
    const items: Array<{ title: string; source: string; link: string }> = []
    const pattern = /<item>([\s\S]*?)<\/item>/g
    let match
    while ((match = pattern.exec(xml)) !== null && items.length < 8) {
      const block = match[1]
      const title = (block.match(/<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/) || [])[1] || ''
      const link = (block.match(/<link>([\s\S]*?)<\/link>/) || [])[1] || ''
      const source = (block.match(/<source[^>]*>([\s\S]*?)<\/source>/) || [])[1] || ''
      if (title) items.push({ title: title.replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"'), source, link })
    }
    return c.json({ category, items })
  } catch {
    return c.json({ error: 'news_failed', items: [] }, 502)
  }
})

// ── KamiSensei Japanese Learning & Vector RAG API ──────────────────
app.get('/api/kamisensei/status', async (c) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const response = await fetch(`${bridgeUrl}/api/kamisensei/status`, { signal: AbortSignal.timeout(10000) }).catch((err) => {
      console.error('[KS] Status bridge request failed:', err)
      return null
    })
    if (response) {
      const data = await response.json().catch(() => null) as any
      if (data) {
        return c.json({
          ...data,
          google_model: data.google_model || kamiSenseiProviderLabel(c.env),
          voice_id: data.voice_id || c.env.ELEVENLABS_VOICE_ID || null
        }, response.ok ? 200 : 503)
      }
    }
  } catch (err) {
    console.error('[KS] Status route failed:', err)
  }
  return c.json({
    ok: false,
    service: 'KamiSensei Protocol',
    is_empty: true,
    files_count: 0,
    files: [],
    chunks_count: 0,
    db_connected: false,
    error: 'The local KamiSensei bridge or vector service is unavailable.',
    google_model: kamiSenseiProviderLabel(c.env),
    voice_id: c.env.ELEVENLABS_VOICE_ID || null
  }, 503)
})

app.get('/api/kamisensei/files', async (c) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const response = await fetch(`${bridgeUrl}/api/kamisensei/files`, { signal: AbortSignal.timeout(8000) }).catch((err) => {
      console.error('[KS] Files bridge request failed:', err)
      return null
    })
    if (response) {
      const data = await response.json().catch(() => null)
      if (data) return c.json(data, response.ok ? 200 : 503)
    }
  } catch (err) {
    console.error('[KS] Files route failed:', err)
  }
  return c.json({ ok: false, files: [], db_connected: false, error: 'The local source registry is unavailable.' }, 503)
})

app.get('/api/kamisensei/sources-list', async (c) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const response = await fetch(`${bridgeUrl}/api/kamisensei/sources-list`, { signal: AbortSignal.timeout(8000) }).catch((err) => {
      console.error('[KS] Sources bridge request failed:', err)
      return null
    })
    if (response) {
      const data = await response.json().catch(() => null)
      if (data) return c.json(data, response.ok ? 200 : 503)
    }
  } catch (err) {
    console.error('[KS] Sources route failed:', err)
  }
  return c.json({ ok: false, files: [], db_connected: false, error: 'The local source registry is unavailable.' }, 503)
})

async function kamiSenseiUploadHandler(c: any) {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const body = await c.req.json()
    const response = await fetch(`${bridgeUrl}/api/kamisensei/upload`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(120000)
    })
    const data = await response.json().catch(() => null) as any
    if (response.ok) return c.json(data || { ok: true })
    return c.json({ error: data?.message || data?.error || 'Bridge upload failed' }, response.status >= 400 && response.status < 500 ? response.status : 502)
  } catch (err: any) {
    return c.json({ error: err.message || 'Upload error' }, 500)
  }
}

app.post('/api/kamisensei/upload', kamiSenseiUploadHandler)

// KamiSensei YouTube transcript extraction — proxied to the loopback bridge,
// which runs backend/services/youtube_service.py (no media ever downloads).
app.post('/api/kamisensei/youtube-extract', async (c: any) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const body = await c.req.json()
    const response = await fetch(`${bridgeUrl}/api/kamisensei/youtube-extract`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(150000)
    })
    const data = await response.json().catch(() => null) as any
    if (response.ok) return c.json(data || { ok: true, status: 'success' })
    return c.json({ status: 'error', error: data?.error || data?.message || 'Bridge YouTube extraction failed' }, response.status >= 400 && response.status < 500 ? response.status : 502)
  } catch (err: any) {
    console.error('[KS] YouTube extract route failed:', err)
    return c.json({ status: 'error', error: err.message || 'YouTube extraction error' }, 500)
  }
})

// KamiSensei persisted sources — reads kamisensei_db.json via the bridge.
app.get('/api/kamisensei/sources', async (c: any) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const response = await fetch(`${bridgeUrl}/api/kamisensei/sources`, { signal: AbortSignal.timeout(15000) }).catch((err) => {
      console.error('[KS] Sources bridge request failed:', err)
      return null
    })
    if (response) {
      const data = await response.json().catch(() => null) as any
      if (data) return c.json(data, response.ok ? 200 : 502)
    }
  } catch (err: any) {
    console.error('[KS] Sources route failed:', err)
  }
  return c.json({ ok: false, sources: [], count: 0, error: 'The local source store is unavailable.' }, 503)
})

// KamiSensei delete a persisted source — proxies DELETE /api/kamisensei/sources/:id.
app.delete('/api/kamisensei/sources/:id', async (c: any) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const id = c.req.param('id')
    const response = await fetch(`${bridgeUrl}/api/kamisensei/sources/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      signal: AbortSignal.timeout(15000)
    })
    const data = await response.json().catch(() => null) as any
    if (response.ok) return c.json(data || { ok: true, deleted: true })
    return c.json({ ok: false, deleted: false, error: data?.error || 'Delete failed' }, response.status >= 400 && response.status < 500 ? response.status : 502)
  } catch (err: any) {
    console.error('[KS] Source delete route failed:', err)
    return c.json({ ok: false, deleted: false, error: err.message || 'Delete error' }, 500)
  }
})




// KamiSensei delete a persisted source by URL — proxies the bridge so the
// frontend can sync-remove the JSON-store copy when a notebook UI source is
// deleted (prevents ghost sources from reappearing after reload).
app.post('/api/kamisensei/sources/delete-url', async (c: any) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const body = await c.req.json()
    const response = await fetch(`${bridgeUrl}/api/kamisensei/sources/delete-url`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000)
    })
    const data = await response.json().catch(() => null) as any
    if (response.ok) return c.json(data || { ok: true, deleted: true })
    return c.json({ ok: false, deleted: false, error: data?.error || 'Delete failed' }, response.status >= 400 && response.status < 500 ? response.status : 502)
  } catch (err: any) {
    console.error('[KS] Source delete-by-url route failed:', err)
    return c.json({ ok: false, deleted: false, error: err.message || 'Delete error' }, 500)
  }
})

// Source deletion proxy: removes the file from ./knowledge_base and forces a
// re-ingest so stale vectors never answer queries for a deleted source.
app.post('/api/kamisensei/delete', async (c: any) => {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const body = await c.req.json()
    const response = await fetch(`${bridgeUrl}/api/kamisensei/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(120000)
    })
    const data = await response.json().catch(() => null)
    return c.json(data || { ok: false, message: 'Bridge delete failed' }, response.ok ? 200 : (response.status === 404 ? 404 : 502))
  } catch (err: any) {
    return c.json({ error: err.message || 'Delete error' }, 500)
  }
})


// Shared KamiSensei RAG chat controller. Canonical route is
// '/api/kamisensei/query'. Retrieval failures return an honest source-grounding
// error instead of silently answering without verified notebook context.
async function kamiSenseiQueryHandler(c: any) {
  try {
    const { query, history, sourceIds } = await c.req.json<{
      query?: string
      history?: ChatMessage[]
      sourceIds?: string[]
    }>()
    if (!query) return c.json({ error: 'Query is required' }, 400)

    // 1. Source-aware retrieval: when the user selected specific sources
    //    (sourceIds), the vector engine is STRICTLY filtered to those files —
    //    the rest of the database is never silently searched. An empty
    //    selection means a deliberate global semantic search.
    const selectedSources = Array.isArray(sourceIds)
      ? sourceIds.map((s) => String(s).trim()).filter(Boolean)
      : []
    let contextDocs: Array<{ text: string; metadata: any }> = []
    let contextOk = true
    try {
      const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
      const filterPayload: Record<string, unknown> = { query, top_k: 8 }
      if (selectedSources.length) filterPayload.sources = selectedSources
      const vectorRes = await fetch(`${bridgeUrl}/api/kamisensei/query_db`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filterPayload),
        signal: AbortSignal.timeout(10000)
      }).catch(() => null)
      if (vectorRes && vectorRes.ok) {
        const vData = await vectorRes.json() as any
        if (Array.isArray(vData.matches)) contextDocs = vData.matches
      } else {
        contextOk = false
      }
    } catch (err) {
      contextOk = false
      console.error('[KS] Chat retrieval failed:', err)
    }

    if (!contextOk || contextDocs.length === 0) {
      return c.json({
        error: selectedSources.length
          ? 'KamiSensei found no indexed content in the selected sources. Select another indexed source or re-index the current one.'
          : 'KamiSensei has no indexed source context for this question. Add and index a source first.'
      }, 422)
    }

    // 2. Source boundary tags: every chunk is stamped with its exact origin
    //    (extracted from the chunk's metadata array) so multi-source queries
    //    like "Compare the te-form explanation between Genki and Minna no
    //    Nihongo, Sir." can be answered with precise cross-references.
    const sourceTag = (d: { metadata?: any; source?: string; page?: number }) => {
      const src = String(d?.metadata?.source || d?.source || 'Doc')
      const rawPage = d?.metadata?.page ?? d?.page
      const page = Number(rawPage)
      return Number.isFinite(page) && page >= 1
        ? `[Source: ${src}, Page ${page}]`
        : `[Source: ${src}]`
    }
    const contextSnippet = contextDocs.length > 0
      ? `\n\nRELEVANT STUDY MATERIALS FROM KNOWLEDGE BASE (multi-source; cite the [Source: ...] tag you used):\n` + contextDocs.map((d) => `${sourceTag(d)}:\n${String(d?.text ?? '')}`).join('\n\n')
      : ''

    const systemPrompt = `You are KamiSensei, an elite analytical AI tutor. You will be provided with context from the user's selected sources (which may include raw, messy, or unpunctuated transcripts). Your task is to deeply comprehend, clean up, and analyze this data. If the user asks for a 'revision', 'summary', or 'explanation', do NOT just repeat the text. You must synthesize the core concepts, fix the logical flow, and present the answer in a highly structured, easy-to-absorb format (using clear headings, bullet points, and bold text for key terms). STRICT RULE: Base your analysis only on the provided context.

SOURCE MATERIAL CONTEXT:
The full text of the user's selected sources is appended below. It may be raw, messy, or unpunctuated (e.g., YouTube transcripts), so first clean up the logical flow before answering. Answer ONLY from the material below, citing each segment with its [Source: ...] tag.${contextSnippet}`

    // Clean history for Gemini & Groq multiturn: exclude any trailing duplicate query,
    // filter out empty turns, and guarantee strict user <-> model alternation.
    const rawHistory = Array.isArray(history) ? history.slice(-10) : []
    const cleanTurns: Array<{ role: 'user' | 'model'; text: string }> = []
    for (const turn of rawHistory) {
      const text = String(turn?.content || '').trim()
      if (!text) continue
      // If client pushed the current query already into history, skip it from history array
      if (turn.role === 'user' && text === query.trim()) continue
      const role: 'user' | 'model' = turn.role === 'assistant' ? 'model' : 'user'
      if (cleanTurns.length && cleanTurns[cleanTurns.length - 1].role === role) {
        cleanTurns[cleanTurns.length - 1].text += '\n' + text
      } else {
        cleanTurns.push({ role, text })
      }
    }
    // Gemini contents must begin with a user turn and alternate strictly
    if (cleanTurns.length && cleanTurns[0].role === 'model') {
      cleanTurns.unshift({ role: 'user', text: 'Hello sensei, please guide my Japanese study session.' })
    }
    // If the last turn in cleanTurns is 'user', remove it so the final turn is followed cleanly by our new user query
    if (cleanTurns.length && cleanTurns[cleanTurns.length - 1].role === 'user') {
      cleanTurns.pop()
    }

    const geminiContents = [
      ...cleanTurns.map((t) => ({ role: t.role, parts: [{ text: t.text }] })),
      { role: 'user', parts: [{ text: query }] }
    ]

    const models = kamiSenseiModels(c.env)
    // Try every free lite model on EVERY configured Google key before
    // falling back to Groq.
    const googleKeys = [c.env.GOOGLE_API_KEY, c.env.GOOGLE_API_KEY_2].filter(Boolean) as string[]

    // Citations: every citation points at the ACTUAL retrieved chunk from
    // ChromaDB — never fabricated text.
    const citations = contextDocs.slice(0, 6).map((d, idx) => ({
      index: idx + 1,
      source: String(d?.metadata?.source || d?.source || 'Doc'),
      page: (() => {
        const value = Number(d?.metadata?.page ?? d?.page)
        return Number.isFinite(value) && value >= 1 ? value : null
      })(),
      text: String(d?.text || '').slice(0, 600)
    }))
    const sourcesUsed = [...new Set(contextDocs.map((d) => String(d?.metadata?.source || 'Doc')))]

    // 3. SSE response: meta (citations) → token* → done | error.
    //    A provider failure emits 'error' so the UI never stays stuck thinking.
    return streamSSE(c, async (sse) => {
      const send = async (event: string, data: Record<string, unknown>) => {
        await sse.writeSSE({ event, data: JSON.stringify(data) })
      }
      try {
        await send('meta', { citations, sources_used: sourcesUsed, context_chunks: contextDocs.length, context_ok: contextOk })

        let reply = ''
        let provider = ''
        const emit = async (text: string) => {
          if (!text) return
          reply += text
          await send('token', { t: text })
        }

        // Shared SSE frame reader: yields each `data:` payload across chunks.
        // Spec-compliant: frames separated by blank lines (LF or CRLF), and a
        // frame's multiple `data:` lines are joined with '\n' before parsing.
        const readSseFrames = async (res: Response, onPayload: (payload: string) => Promise<void>) => {
          const reader = res.body?.getReader()
          if (!reader) throw new Error('Response body is not readable')
          const decoder = new TextDecoder()
          let buffer = ''
          const handleFrame = async (frame: string) => {
            const dataLines = frame.split(/\r?\n/)
              .filter((line) => line.startsWith('data:'))
              .map((line) => line.slice(5).replace(/^\s/, ''))
            if (!dataLines.length) return
            const data = dataLines.join('\n').trim()
            if (data && data !== '[DONE]') await onPayload(data)
          }
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            buffer += decoder.decode(value, { stream: true })
            const frames = buffer.split(/\r?\n\r?\n/)
            buffer = frames.pop() || ''
            for (const frame of frames) await handleFrame(frame)
          }
          if (buffer.trim()) await handleFrame(buffer)
        }

        // Primary: Gemini streaming via streamGenerateContent?alt=sse.
        // Every free lite model is tried on every key, so one retired slug
        // cannot consume the whole provider slot.
        for (const googleKey of googleKeys) {
          for (const model of models) {
            if (reply.trim()) break
            try {
              const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${encodeURIComponent(googleKey)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  systemInstruction: { parts: [{ text: systemPrompt }] },
                  contents: geminiContents,
                  generationConfig: {
                    temperature: 0.4,
                    maxOutputTokens: kamiSenseiMaxOutputTokens(c.env)
                  }
                }),
                signal: AbortSignal.timeout(90000)
              })
              if (!response.ok) {
                console.error('[KS] Gemini stream HTTP', response.status, await response.text().then((t) => t.slice(0, 300)).catch(() => ''))
                continue
              }
              await readSseFrames(response, async (payload) => {
                try {
                  const chunk = JSON.parse(payload) as any
                  const parts = chunk?.candidates?.[0]?.content?.parts || []
                  for (const part of parts) {
                    if (typeof part?.text === 'string' && part?.thought !== true) await emit(part.text)
                  }
                } catch (err) {
                  console.debug('[KS] Ignored malformed Gemini stream frame:', err)
                }
              })
              if (reply.trim()) { provider = `Gemini (${model})`; break }
              reply = '' // empty candidate on this key/model — try the next one
            } catch (err) {
              console.error('[KS] Gemini stream attempt failed:', err)
            }
          }
          if (reply.trim()) break
        }

        // Fallback: Groq / Llama OpenAI-compatible delta stream.
        // Reasoning models (gpt-oss, qwen, deepseek) need a low reasoning
        // effort so the token budget lands on visible content, and a
        // non-reasoning second model guarantees a reply when the first
        // reasoning model returns empty content.
        if (!reply.trim() && c.env.GROQ_API_KEY) {
          const groqModels = freeModelChain(c.env.GROQ_MODEL, FREE_GROQ_MODELS)
          for (const groqModel of groqModels) {
            if (reply.trim()) break
            const isReasoning = /gpt-oss|qwen|deepseek/i.test(groqModel)
            try {
              const groqMessages = [
                { role: 'system', content: systemPrompt },
                ...cleanTurns.map((t) => ({ role: t.role === 'model' ? 'assistant' : 'user', content: t.text })),
                { role: 'user', content: query }
              ]
              const gRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.env.GROQ_API_KEY}` },
                body: JSON.stringify({
                  model: groqModel,
                  messages: groqMessages,
                  temperature: 0.4,
                  // Cap Groq output tokens: free-tier TPM (8000) counts
                  // prompt + max_tokens, so 8192 always trips HTTP 413.
                  max_tokens: Math.min(kamiSenseiMaxOutputTokens(c.env), 2000),
                  ...(isReasoning ? { reasoning_effort: 'low' } : {}),
                  stream: true
                }),
                signal: AbortSignal.timeout(90000)
              })
              if (!gRes.ok) {
                console.error('[KS] Groq stream HTTP', gRes.status, await gRes.text().then((t) => t.slice(0, 300)).catch(() => ''))
                continue
              }
              if (gRes.body) {
                await readSseFrames(gRes, async (payload) => {
                  try {
                    const chunk = JSON.parse(payload) as any
                    await emit(String(chunk?.choices?.[0]?.delta?.content || ''))
                  } catch (err) {
                    console.debug('[KS] Ignored malformed Groq stream frame:', err)
                  }
                })
                if (reply.trim()) provider = `Groq (${groqModel})`
              }
            } catch (err) {
              console.error('[KS] Groq stream fallback failed:', err)
            }
          }
        }

        if (!reply.trim()) {
          await send('error', { error: 'AI generation failed — no provider returned a response. Check GOOGLE_API_KEY / GROQ_API_KEY in .dev.vars.' })
        } else {
          await send('done', { provider, reply, sources_used: sourcesUsed, citations, context_chunks: contextDocs.length, context_ok: contextOk })
        }
      } catch (err: any) {
        console.error('[KS] Query stream failed:', err)
        try {
          await send('error', { error: err?.message || 'Stream failure' })
        } catch (sendErr) {
          console.debug('[KS] Client disconnected before stream error delivery:', sendErr)
        }
      }
    })
  } catch (err: any) {
    return c.json({ error: err.message || 'Server error' }, 500)
  }
}

app.post('/api/kamisensei/query', kamiSenseiQueryHandler)

// Notebook creation: persists a tracking descriptor in ./notebooks/[id]/metadata.json so
// custom notebook state survives frontend resets. Safe-catch guard ensures a missing
// env or temp fs pause never freezes the request thread.
app.post('/api/kamisensei/create-notebook', kamiSenseiCreateNotebookHandler)
app.post('/api/kamisensai/create-notebook', kamiSenseiCreateNotebookHandler)

async function kamiSenseiCreateNotebookHandler(c: any) {
  try {
    const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
    const { name, title, notebookId } = await c.req.json<{ name?: string; title?: string; notebookId?: string }>().catch(() => ({}))
    const notebookName = String(name || title || 'New Notebook').trim() || 'New Notebook'
    const response = await fetch(`${bridgeUrl}/api/kamisensei/create-notebook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: notebookName, ...(notebookId && /^[a-zA-Z0-9_-]{4,64}$/.test(notebookId) ? { notebookId } : {}) }),
      signal: AbortSignal.timeout(10000)
    })
    const data = await response.json().catch(() => null)
    if (response.ok && data && data.status === 'success') return c.json(data)
    return c.json({ status: 'error', error: (data && data.error) || `Bridge create-notebook returned HTTP ${response.status}` }, 500)
  } catch (err: any) {
    return c.json({ status: 'error', error: err?.message || 'Notebook creation failed.' }, 500)
  }
}

app.post('/api/kamisensei/studio', (c) => c.json({
  error: 'The legacy Studio generator is retired. Use /api/kamisensei/artifact with one of the six typed artifact actions.'
}, 410))

// ══════════════════════════════════════════════════════════════════════════
// KamiSensei Artifact Engine — provider-aware, RAG-grounded, schema-validated
// ───────────────────────────────────────────────────────────────────────────
// Flow:  Studio button → generation request → notebookId + selected sources
//      → ChromaDB RAG retrieval → configured Gemini/Groq provider → strict JSON
//      → schema validation (one safe repair) → persisted artifact envelope.
// Uses only server-side provider keys already configured for JARVIS.
// ══════════════════════════════════════════════════════════════════════════
async function fetchRagMatches(env: any, query: string, sources: string[], topK = 8): Promise<any[]> {
  const bridgeUrl = (env.JARVIS_BRIDGE_HOST ? `http://${env.JARVIS_BRIDGE_HOST}:${env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
  try {
    const payload: Record<string, unknown> = { query, top_k: topK }
    // Strict source contract: when selectedSources is non-empty the bridge
    // filters the vector search to ONLY those file ids — no blind search.
    if (sources.length) payload.sources = sources
    const res = await fetch(`${bridgeUrl}/api/kamisensei/query_db`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(8000)
    }).catch(() => null)
    if (res && res.ok) {
      const vData = await res.json() as any
      return Array.isArray(vData.matches) ? vData.matches : []
    }
  } catch (err) {
    console.error('[KS] Artifact retrieval failed:', err)
  }
  return []
}

function matchToChunk(m: any): RagChunkInput {
  const rawPage = Number(m?.metadata?.page ?? m?.page)
  return {
    text: String(m?.text || ''),
    source: String(m?.metadata?.source || m?.source || 'Doc'),
    page: Number.isFinite(rawPage) && rawPage >= 1 ? rawPage : null
  }
}

async function ragRetrieveContext(env: any, query: string, sources: string[], topK = 8) {
  const matches = await fetchRagMatches(env, query, sources, topK)
  if (matches.length) {
    const context = '\n\nCURRENT DOCUMENT CONTEXT:\n' + matches.map((m: any, idx: number) =>
      `[Source ${idx + 1}: ${m.metadata?.source || m.source || 'Doc'}${m.metadata?.page || m.page ? ` (Page ${m.metadata?.page || m.page})` : ''}]: ${m.text}`
    ).join('\n\n').slice(0, 14000)
    const used = [...new Set(matches.map((m: any) => String(m.metadata?.source || m.source || 'Doc')))]
    const citations = matches.map((m: any, index: number) => {
      const rawPage = m.metadata?.page ?? m.page
      const page = Number(rawPage)
      return {
        index: index + 1,
        source: String(m.metadata?.source || m.source || 'Doc'),
        page: Number.isFinite(page) && page >= 1 ? page : null,
        snippet: String(m.text || '').slice(0, 600)
      }
    })
    return { context, sourcesUsed: used, citations }
  }
  return { context: '', sourcesUsed: [] as string[], citations: [] as Array<{ index: number; source: string; page: number | null; snippet: string }> }
}

/* ── Deep-scan retrieval for mind maps ─────────────────────────────────────
 * The plain semantic query keeps floating intro/TOC/index pages to the top.
 * For mind maps we fire multiple targeted queries (the raw topic verbatim +
 * its extracted key phrases like "Lesson 6", "Particles"), merge + dedupe
 * all matches, score every chunk for raw-lesson content density (penalising
 * boilerplate), and guarantee a dense 4000+ char payload before handing the
 * context to the model. */
async function ragDeepScanContext(env: any, topic: string, sources: string[]) {
  const phrases = extractTopicKeyPhrases(topic)
  const queries = [...new Set([String(topic || '').trim(), ...phrases].filter(Boolean))].slice(0, 4)
  const matchLists = await Promise.all(queries.map((q) => fetchRagMatches(env, q, sources, 32)))
  const merged = new Map<string, any>()
  for (const list of matchLists) {
    for (const m of list) {
      const key = String(m?.metadata?.source || m?.source || 'Doc')
        + '|' + String(m?.metadata?.page ?? m?.page ?? '')
        + '|' + String(m?.text || '').slice(0, 80)
      if (!merged.has(key)) merged.set(key, m)
    }
  }
  const chunks = [...merged.values()].map(matchToChunk).filter((c) => c.text.trim())
  // Field-depth guarantee: at least 10 dense text chunks (8-10+ raw lesson
  // page arrays) so the Pro model synthesizes from the COMPLETE lesson body.
  const { selected, contextChars } = assembleDeepScanContext(chunks, phrases, 4000, 14000, 10)
  if (!selected.length) {
    return { context: '', sourcesUsed: [] as string[], citations: [] as Array<{ index: number; source: string; page: number | null; snippet: string }>, contextChars: 0 }
  }
  const context = '\n\nCURRENT DOCUMENT CONTEXT:\n' + selected.map((c, idx) =>
    `[Source ${idx + 1}: ${c.source}${c.page ? ` (Page ${c.page})` : ''}]: ${c.text}`
  ).join('\n\n').slice(0, 14000)
  const sourcesUsed = [...new Set(selected.map((c) => c.source || 'Doc'))]
  const citations = selected.slice(0, 40).map((c, index) => ({
    index: index + 1,
    source: c.source || 'Doc',
    page: c.page ?? null,
    snippet: c.text.slice(0, 600)
  }))
  console.log(`[KS] Mind map deep-scan: ${queries.length} queries, ${chunks.length} unique chunks, dense payload ${contextChars} chars`)
  return { context, sourcesUsed, citations, contextChars }
}

async function artifactGenerate(env: any, prompt: string, isRepair: boolean) {
  const googleKeys = [env.GOOGLE_API_KEY, env.GOOGLE_API_KEY_2].filter(Boolean) as string[]
  const googleModels = kamiSenseiModels(env)
  for (const googleKey of googleKeys) {
    for (const googleModel of googleModels) {
      try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${googleModel}:generateContent?key=${encodeURIComponent(googleKey)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: {
              // Free lite model: strictly low temperature for factual, dense,
              // non-repetitive extraction (repair and fresh alike).
              temperature: 0.2,
              maxOutputTokens: kamiSenseiMaxOutputTokens(env),
              responseMimeType: 'application/json'
            }
          }),
          signal: AbortSignal.timeout(180000)
        })
        if (!response.ok) {
          console.warn(`[KS] Gemini artifact generation returned HTTP ${response.status} for ${googleModel}; trying next configured provider.`)
          continue
        }
        const data = await response.json() as any
        const content = data?.candidates?.[0]?.content?.parts?.map((part: any) => part?.text || '').join('').trim()
        if (content) return { ok: true, content, model: googleModel, provider: 'Gemini' }
      } catch (err) {
        console.error('[KS] Gemini artifact generation failed:', err)
      }
    }
  }

  if (!env.GROQ_API_KEY && !env.OPENROUTER_API_KEY) {
    const googleConfigHint = googleKeys.length
      ? ' Google keys are configured, but their free lite models did not return content.'
      : ''
    return { ok: false, error: `No configured AI provider returned a response.${googleConfigHint} Set provider keys and model names server-side.` }
  }
  // OpenRouter first (proven fast/reliable here); Groq remains the deeper fallback.
  if (env.OPENROUTER_API_KEY) {
    for (const model of freeModelChain(env.OPENROUTER_MODEL, FREE_OPENROUTER_MODELS, { freeOnly: true })) {
      const orT0 = Date.now()
      try {
        const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.OPENROUTER_API_KEY}`, 'HTTP-Referer': 'http://127.0.0.1:7777', 'X-Title': 'JARVIS' },
          body: JSON.stringify({
            model,
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.2,
            max_tokens: 4096
          }),
          signal: AbortSignal.timeout(150000)
        })
        console.log(`[KS] OpenRouter artifact (${model}) responded HTTP ${res.status} in ${((Date.now() - orT0) / 1000).toFixed(1)}s`)
        if (res.ok) {
          const data = await res.json().catch(() => null) as any
          const content = data?.choices?.[0]?.message?.content?.trim()
          if (content) return { ok: true, content, model, provider: 'OpenRouter' }
        }
      } catch (err) {
        console.error(`[KS] OpenRouter artifact generation failed after ${((Date.now() - orT0) / 1000).toFixed(1)}s:`, err instanceof Error ? err.message : err)
      }
    }
  }
  if (!env.GROQ_API_KEY) {
    return { ok: false, error: 'All artifact providers failed (Gemini quota, OpenRouter unavailable).' }
  }
  const model = env.GROQ_MODEL || 'openai/gpt-oss-120b'
  const run = async (jsonMode: boolean, promptText = prompt): Promise<{ content?: string; status?: number; message?: string }> => {
    const body: Record<string, unknown> = { model, messages: [{ role: 'user', content: promptText }], temperature: 0.2, max_tokens: 3072 }
    if (jsonMode) body.response_format = { type: 'json_object' }
    // gpt-oss reasoning models burn TPM on hidden reasoning tokens — cap effort.
    if (/^openai\/gpt-oss/.test(model)) body.reasoning_effort = 'low'
    let res: Response
    const groqT0 = Date.now()
    try {
      res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.GROQ_API_KEY}` },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(180000)
      })
    } catch (e) {
      console.error(`[KS] Groq artifact fetch failed after ${((Date.now() - groqT0) / 1000).toFixed(1)}s:`, e instanceof Error ? e.message : e)
      return { message: `Groq network/timeout: ${e instanceof Error ? e.message : String(e)}` }
    }
    console.log(`[KS] Groq artifact responded HTTP ${res.status} in ${((Date.now() - groqT0) / 1000).toFixed(1)}s (prompt ${promptText.length} chars)`)
    if (!res.ok) return { status: res.status }
    const data = await res.json().catch(() => null) as any
    const content = data?.choices?.[0]?.message?.content?.trim()
    if (!content) return { message: 'Groq returned an empty response' }
    return { content }
  }
  const first = await run(true)
  if (first.content) return { ok: true, content: first.content, model, provider: 'Groq' }
  // Retry WITHOUT response_format ONLY when the model rejected json_object
  // (4xx). Timeouts and network errors are not helped by a plain retry.
  if (first.status === 400 || first.status === 404) {
    const second = await run(false)
    if (second.content) return { ok: true, content: second.content, model, provider: 'Groq' }
    if (second.message) return { ok: false, error: second.message }
    return { ok: false, error: `Groq ${second.status}` }
  }
  // Free-tier TPM ceilings reject oversized requests (HTTP 413). The source
  // context sits at the tail of the prompt, so progressively trimming the tail
  // preserves the schema + contract lines while fitting the token budget.
  if (first.status === 413 || /too large|tokens per minute|TPM/i.test(first.message || '')) {
    for (const keep of [16000, 11000, 7000, 4000]) {
      if (prompt.length <= keep) break
      const trimmed = prompt.slice(0, keep) + '\n\n[NOTE: source context was trimmed to fit provider token limits; base the artifact ONLY on the context above.]'
      const retry = await run(true, trimmed)
      if (retry.content) return { ok: true, content: retry.content, model, provider: 'Groq' }
      if (retry.status === 400 || retry.status === 404) {
        const plain = await run(false, trimmed)
        if (plain.content) return { ok: true, content: plain.content, model, provider: 'Groq' }
      }
    }
  }
  if (first.message && !/network|timeout/i.test(first.message)) return { ok: false, error: first.message }
  return { ok: false, error: `Groq ${first.status}` }
}

function buildArtifactEnvelope(args: { notebookId: string | null; type: ArtifactType; data: any; sourcesUsed: string[]; requestedSourceIds: string[]; citations: any[] }) {
  return {
    id: 'art-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
    notebookId: args.notebookId,
    type: args.type,
    title: (args.data && args.data.title) || ARTIFACT_LABELS[args.type],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    sourceIds: args.sourcesUsed,
    requestedSourceIds: args.requestedSourceIds,
    sourcesUsed: args.sourcesUsed,
    citations: args.citations,
    artifactData: args.data
  }
}

/* ── Automated batch processing worker queue ────────────────────────────────
 * LLM output token frames crash on huge single generations, so count-driven
 * artifacts are produced in sequential async batch passes. Each pass asks for
 * a bounded slice, validates EVERY item individually, dedupes normalized
 * question labels, and loops until the user's explicit request is satisfied
 * (or the safety pass budget is spent).
 * ────────────────────────────────────────────────────────────────────────── */
async function runBatchedCollection(
  env: any,
  kind: 'flashcard_set' | 'quiz',
  topic: string,
  context: string,
  sourceIds: string[],
  opts: { requestedCount?: number; requestedDifficulty?: string; requestedLanguage?: string }
): Promise<{ items: any[]; provider: string; model: string; passes: number; error?: string }> {
  const ceiling = kind === 'flashcard_set' ? FLASHCARD_CEILING : QUIZ_CEILING
  const batchSize = kind === 'flashcard_set' ? FLASHCARD_BATCH_SIZE : QUIZ_BATCH_SIZE
  const fallbackCount = kind === 'flashcard_set' ? FLASHCARD_DEFAULT_COUNT : QUIZ_DEFAULT_COUNT
  const target = clampRequestedCount(opts.requestedCount, fallbackCount, ceiling)
  const collected: any[] = []
  const seen = new Set<string>()
  let provider = ''
  let model = ''
  let lastError = ''
  const maxPasses = Math.min(8, Math.ceil(target / batchSize) + 2)
  for (let pass = 1; pass <= maxPasses && collected.length < target; pass++) {
    const need = target - collected.length
    const batchCount = Math.min(batchSize, need + 6)
    const avoid = collected.map((it) => String(it.front ?? it.question ?? '')).filter(Boolean)
    const prompt = buildArtifactPrompt(kind, topic, context, sourceIds, {
      requestedCount: batchCount,
      requestedDifficulty: opts.requestedDifficulty,
      requestedLanguage: opts.requestedLanguage,
      avoidQuestions: avoid
    })
    const gen = await artifactGenerate(env, prompt, pass > 1)
    if (!gen.ok) {
      lastError = gen.error || 'generation failed'
      if (!collected.length) break
      continue
    }
    provider = gen.provider || provider
    model = gen.model || model
    const parsed = extractJson(gen.content)
    const salvaged = salvageArtifact(kind, parsed) as Record<string, unknown>
    const items = (Array.isArray(salvaged?.cards) ? salvaged.cards : Array.isArray(salvaged?.questions) ? salvaged.questions : []) as any[]
    for (const item of items) {
      if (collected.length >= target) break
      if (!item || typeof item !== 'object') continue
      // Precise dedup: case/punctuation variants of the same question collide.
      const key = normalizeLabel(item.front ?? item.question ?? '')
      if (!key || seen.has(key)) continue
      const single: any = kind === 'flashcard_set'
        ? { type: 'flashcard_set', title: 'batch', cards: [item] }
        : { type: 'quiz', title: 'batch', questions: [item] }
      const v = validateArtifact(kind, single)
      if (!v.ok) continue
      seen.add(key)
      collected.push(item)
    }
  }
  return { items: collected, provider, model, passes: maxPasses, error: collected.length ? undefined : (lastError || 'no valid items produced') }
}

/* ── Mind map nested-contract pipeline ──────────────────────────────────────
 * Enforces { title, root: { id, label, children: [] } } from the model, then
 * flattens with unique hash ids, depth-tier pruning, and label dedup/merge.
 * ────────────────────────────────────────────────────────────────────────── */
async function generateMindMapArtifact(
  env: any,
  topic: string,
  context: string,
  sourceIds: string[],
  opts: { requestedCount?: number; requestedDifficulty?: string; requestedLanguage?: string; requestedDepth?: string }
): Promise<{ ok: true; data: any; provider: string; model: string } | { ok: false; error: string; details?: string[] }> {
  /* ── Schema v2: dynamic generative CARD BOARD (AI-determined taxonomy) ──
   * Tried first; the nested-tree pipeline below remains as a robust,
   * equally dynamic fallback for models that cannot emit the card schema. */
  let cardsPrompt = buildMindMapCardsPrompt('mind_map', topic, context, sourceIds, opts)
  for (let attempt = 1; attempt <= 2; attempt++) {
    const gen = await artifactGenerate(env, cardsPrompt, attempt > 1)
    if (!gen.ok) break
    const parsed = extractJson(gen.content)
    const cardErrors = validateMindMapCards(parsed)
    const normalized = normalizeMindMapCards(parsed)
    if (normalized && normalized.cards.length >= 2) {
      return {
        ok: true,
        data: { type: 'mind_map', title: normalized.title, cards: normalized.cards },
        provider: gen.provider || 'Groq',
        model: gen.model
      }
    }
    if (attempt === 1) {
      cardsPrompt = `Your previous JSON failed validation for the mind map card-board schema. Topic: "${topic}".

The extracted JSON was:
${gen.content.slice(0, 2000)}

Validation failed with these errors:
${cardErrors.map((e, i) => `${i + 1}. ${e}`).join('\n')}

Return ONLY a corrected JSON object matching the exact card-board schema from your previous instructions ({ "title", "cards": [{ "id", "headerTitle", "themeColor", "iconType", "bulletPoints": [{ "text", "hasCheckbox" }] }] }). No markdown fences. Do not explain. Remember: dynamic categories grounded in the source only — never fixed template headings, never file statistics.

${context.slice(0, 12000)}`
      continue
    }
    break
  }

  const depthLimit = mindMapDepthLimit(opts.requestedDepth)
  let prompt = buildMindMapPrompt('mind_map', topic, context, sourceIds, opts)
  for (let attempt = 1; attempt <= 2; attempt++) {
    const gen = await artifactGenerate(env, prompt, attempt > 1)
    if (!gen.ok) return { ok: false, error: gen.error || 'mind map generation failed' }
    const parsed = extractJson(gen.content)
    const treeErrors = validateMindMapTree(parsed)
    const nodes = flattenMindMapInput(parsed, depthLimit)
    if (nodes && nodes.length >= 2) {
      const rawTitle = (parsed as any)?.title ? String((parsed as any).title).trim() : ''
      return { ok: true, data: { type: 'mind_map', title: rawTitle || topic, nodes }, provider: gen.provider || 'Groq', model: gen.model }
    }
    if (attempt === 1) {
      prompt = buildRepairPrompt('mind_map', topic, gen.content, treeErrors.length ? treeErrors : ['A valid "root" tree (or flat nodes list) is required.'], context)
      continue
    }
    return { ok: false, error: 'Invalid mind map JSON after regeneration.', details: treeErrors }
  }
  return { ok: false, error: 'Unknown mind map generation failure.' }
}

async function kamiSenseiArtifactHandler(c: any) {
  try {
    // ── Absolute request payload contract ──
    // { type, userPrompt, selectedSources, requestedCount,
    //   requestedDifficulty, requestedLanguage, requestedDepth }
    // (legacy aliases action/topic/instruction/sourceIds still parsed)
    const body = await c.req.json<{
      action?: string; type?: string; topic?: string; userPrompt?: string; instruction?: string
      notebookId?: string; sourceIds?: string[]; selectedSources?: string[]
      requestedCount?: number; requestedDifficulty?: string; requestedLanguage?: string; requestedDepth?: string
    }>()
    const action = String(body.action || body.type || '').toLowerCase()
    if (!(ARTIFACT_TYPES as string[]).includes(action)) {
      return c.json({ error: `Unsupported artifact type "${action}". Supported: ${ARTIFACT_TYPES.join(', ')}` }, 400)
    }
    const type = action as ArtifactType

    // Hard contract: a user prompt is mandatory. Generic default topics are
    // permanently removed — the engine must never invent one.
    const topic = String(body.userPrompt || body.instruction || body.topic || '').trim()
    if (!topic) {
      return c.json({ error: 'Contract violation: "userPrompt" (topic/instruction) is required — generic fallback topics are disabled.' }, 400)
    }
    // Source contract: selectedSources (or legacy sourceIds). Non-empty ⇒ the
    // RAG engine is FORCED to filter chunks strictly by those file ids.
    const selectedSources = (Array.isArray(body.selectedSources) && body.selectedSources.length
      ? body.selectedSources
      : (Array.isArray(body.sourceIds) ? body.sourceIds : []))
      .map((s) => String(s).trim()).filter(Boolean).filter((s, i, a) => a.indexOf(s) === i)
    const contract = {
      requestedCount: body.requestedCount,
      requestedDifficulty: body.requestedDifficulty ? String(body.requestedDifficulty).trim() : '',
      requestedLanguage: body.requestedLanguage ? String(body.requestedLanguage).trim() : '',
      requestedDepth: body.requestedDepth ? String(body.requestedDepth).trim() : ''
    }
    const notebookId = body.notebookId ? String(body.notebookId) : null

    // 1. RAG retrieval — strictly scoped to the selected sources when given.
    const ragQuery = `${ARTIFACT_LABELS[type]} — ${topic}`
    // Mind maps need substantially more source chunks: the hierarchy must be
    // derived from actual document structure, not a handful of snippets.
    const requestedComplete = String(body.requestedDepth || '').toLowerCase().startsWith('com')
    const topK = type === 'mind_map'
      ? (requestedComplete ? 28 : 18)
      : (type === 'report' || type === 'note' || type === 'study_guide' || type === 'briefing_doc' || type === 'faq' || type === 'timeline') ? 12 : 8
    const { context, sourcesUsed, citations } = await ragRetrieveContext(c.env, ragQuery, selectedSources, topK)
    if (!context.trim()) {
      return c.json({
        error: selectedSources.length
          ? 'KamiSensei could not generate this artifact because no indexed chunks were found in the selected sources.'
          : 'KamiSensei could not generate this artifact because source retrieval returned no indexed content. Add or index a source first.'
      }, 422)
    }

    const finish = (artifactData: any, provider: string, model: string, batchMeta?: Record<string, unknown>) => c.json({
      ok: true,
      artifact: {
        id: 'art-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        notebookId,
        type,
        title: artifactData?.title || ARTIFACT_LABELS[type],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        sourceIds: sourcesUsed,
        requestedSourceIds: selectedSources,
        sourcesUsed,
        citations,
        artifactData
      },
      provider: provider || 'Groq',
      model,
      rag: 'used',
      ...batchMeta
    })

    // 2. Type-specific execution paths — no generic blind fallback.
    if (type === 'mind_map') {
      // Deep-scan retrieval: force raw lesson text over intro/index pages.
      const deep = await ragDeepScanContext(c.env, topic, selectedSources)
      const mmContext = deep.context.trim() ? deep.context : context
      const mm = await generateMindMapArtifact(c.env, topic, mmContext, selectedSources, contract)
      if (!mm.ok) return c.json({ error: mm.error, details: (mm as any).details }, 422)
      return finish(mm.data, mm.provider, mm.model, {
        rag: deep.contextChars >= 4000 ? 'deep-scan' : 'used',
        deepScanChars: deep.contextChars
      })
    }
    if (type === 'flashcard_set' || type === 'quiz') {
      const batch = await runBatchedCollection(c.env, type, topic, context, selectedSources, contract)
      if (batch.error || !batch.items.length) {
        return c.json({ error: `Artifact generation failed: ${batch.error || 'no valid items produced'}` }, 502)
      }
      const data = type === 'flashcard_set'
        ? { type: 'flashcard_set', title: `${ARTIFACT_LABELS[type]}: ${topic}`, cards: batch.items }
        : { type: 'quiz', title: `${ARTIFACT_LABELS[type]}: ${topic}`, questions: batch.items }
      return finish(data, batch.provider, batch.model, { batchPasses: batch.passes, generatedCount: batch.items.length })
    }

    // 3. report / note / summary / table — full analytical generation, one safe repair pass.
    let prompt = buildArtifactPrompt(type, topic, context, selectedSources, contract)
    for (let attempt = 1; attempt <= 2; attempt++) {
      const gen = await artifactGenerate(c.env, prompt, attempt > 1)
      if (!gen.ok) return c.json({ error: `Artifact generation failed: ${gen.error}` }, 502)
      const parsed = extractJson(gen.content)
      // Deterministic salvage first (alias keys, option-string→index, etc)
      const salvaged = salvageArtifact(type, parsed)
      const v = validateArtifact(type, salvaged)
      if (v.ok) return finish(v.data, gen.provider || 'Groq', gen.model)
      if (attempt === 1) {
        prompt = buildRepairPrompt(type, topic, gen.content, v.errors, context)
        continue
      }
      return c.json({ error: `Invalid ${type} artifact JSON after regeneration.`, details: v.errors }, 422)
    }
    return c.json({ error: 'Unknown artifact generation failure.' }, 500)
  } catch (err: any) {
    return c.json({ error: err.message || 'Artifact service error' }, 500)
  }
}

app.post('/api/kamisensei/artifact', kamiSenseiArtifactHandler)

// ── KamiSensei AI Podcast Studio: async streaming long-form generator ──
// Accepts a structural config payload, pulls RAG context from ChromaDB
// filtered ONLY by the checked source files, generates one long-form
// dialogue script with Gemini, then streams ElevenLabs-synthesized audio
// batches to the client over chunked transfer (NDJSON) so playback starts
// within seconds while later batches synthesize in the background.
const PODCAST_VOICES: Record<string, string> = {
  HostA: 'CwhRBWXzGAHq8TQ4Fs17', // Roger (Male host)
  HostB: '21m00Tcm4TlvDq8ikWAM' // Rachel (Female host)
}

const PODCAST_LANGUAGE_RULES: Record<string, string> = {
  hinglish: 'Default. Hosts converse in a fluent Hinglish blend (Roman Hindi + English). Japanese terms are rendered in romaji with Hindi-flavored explanations.',
  english: 'Both hosts speak pure natural English. Japanese terms appear in romaji with a brief English gloss.',
  hindi: 'Hosts speak predominantly in Hindi (Devanagari script), using English only for technical study terms.',
  japanese: 'Hosts use natural Japanese (native kanji/hiragana/katakana) and repeat key points in romaji.',
  trilingual_mix: 'Hosts fluidly mix English, Hindi (Devanagari), and native Japanese in one conversation, mirroring the source language of each study point.',
  bengali: 'Hosts speak in Bengali (Bangla script), with English loanwords for study terms.',
  gujarati: 'Hosts speak in Gujarati script, with English technical terms where needed.',
  kannada: 'Hosts speak in Kannada script, with English loanwords for study terms.',
  malayalam: 'Hosts speak in Malayalam script, with English technical terms where needed.',
  marathi: 'Hosts speak in Marathi (Devanagari script), with English technical terms where needed.',
  punjabi: 'Hosts speak in Gurmukhi script (Punjabi), with English loanwords for study terms.',
  tamil: 'Hosts speak in Tamil script, with English technical terms where needed.',
  telugu: 'Hosts speak in Telugu script, with English technical terms where needed.',
  // legacy keys kept for backward compatibility
  pure_english: 'Both hosts speak pure natural English. Japanese terms appear in romaji only, with a brief English gloss.',
  dynamic_hinglish: 'Hosts converse in lively Hinglish (Roman Hindi + English blend). Japanese terms stay in romaji with Hindi-flavored explanations.',
  japanese_mixed: 'Hosts mix full Japanese sentences (native script ok) with English/Hindi explanations, repeating each key sentence in romaji.'
}

// NotebookLM-style episode formats. wordScale adjusts the raw minute->word
// budget so Brief is genuinely brief and Deep Dive genuinely deep.
const PODCAST_FORMATS: Record<string, { label: string; style: string; wordScale: number }> = {
  deep_dive: { label: 'Deep Dive', style: 'A lively conversation between two curious hosts, unpacking and connecting topics with vivid examples and quick recall drills.', wordScale: 1.0 },
  brief: { label: 'Brief', style: 'A bite-sized overview that captures the core ideas and key takeaways quickly and crisply.', wordScale: 0.6 },
  critique: { label: 'Critique', style: 'An expert review of the material, flagging strengths, gaps, and walking the listener through the trickiest points directly.', wordScale: 0.85 },
  debate: { label: 'Debate', style: 'A thoughtful debate between two hosts illuminating different perspectives and edge cases of each topic.', wordScale: 0.9 }
}
const DEFAULT_PODCAST_FORMAT = 'deep_dive'

function podcastConfigToWords(durationMinutes: number): number {
  // ~150 spoken words per minute across both hosts
  return Math.round(Math.min(Math.max(durationMinutes, 1), 60) * 150)
}

// Map NotebookLM length pills -> minute budgets.
const PODCAST_LENGTH_MINUTES: Record<string, number> = { short: 6, default: 10, long: 15 }


/* —— Edge-TTS Podcast Engine Client ——
 * Uses background/podcast_engine.py (edge-tts + FFmpeg muxing).
 * Supports dynamic voice assignment by language and chunked synthesis
 * for long-form (30+ min) podcasts without RAM overflow. */
const PODCAST_PORT = Number(process.env.PODCAST_PORT || 7781)
const PODCAST_URL = `http://127.0.0.1:${PODCAST_PORT}`
let podcastSpawned = false

function ensurePodcastEngine(): void {
  if (podcastSpawned) return
  podcastSpawned = true
  try {
    const enginePath = 'background/podcast_engine.py'
    const pyExe = process.platform === 'win32' ? 'python' : 'python3'
    const child = spawn(pyExe, [enginePath], {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore',
      env: { ...process.env, PODCAST_PORT: String(PODCAST_PORT) }
    })
    child.on('error', (err) => console.error('[podcast] Edge-TTS engine spawn failed:', err.message))
    child.unref()
    console.log('[podcast] Edge-TTS engine spawned on port', PODCAST_PORT)
  } catch (err) {
    console.error('[podcast] Edge-TTS engine spawn error:', err)
  }
}

async function podcastPost(path: string, body: any, timeoutMs: number): Promise<any | null> {
  try {
    const res = await fetch(`${PODCAST_URL}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs)
    })
    if (!res.ok) return null
    return await res.json()
  } catch {
    return null
  }
}

async function podcastReady(): Promise<boolean> {
  try {
    const res = await fetch(`${PODCAST_URL}/health`, { signal: AbortSignal.timeout(4000) })
    return res.ok
  } catch {
    return false
  }
}

function parsePodcastScript(raw: string): Array<{ speaker: string; text: string }> {
  let cleaned = raw.trim().replace(/```json/gi, '').replace(/```/g, '').trim()
  try {
    const parsed = JSON.parse(cleaned)
    if (Array.isArray(parsed)) {
      return parsed
        .filter((t: any) => t && typeof t.text === 'string' && t.text.trim())
        .map((t: any) => ({ speaker: t.speaker === 'HostB' ? 'HostB' : 'HostA', text: t.text.trim() }))
    }
  } catch (err) {
    console.debug('[podcast] Script was not a complete JSON array; attempting salvage:', err)
  }
  // Salvage: extract complete dialogue objects from truncated/marked-up output
  const turns: Array<{ speaker: string; text: string }> = []
  const re = /\{[^{}]*?"speaker"\s*:\s*"(HostA|HostB)"[^{}]*?"text"\s*:\s*"((?:[^"\\]|\\.)*)"[^{}]*?\}/g
  let m: RegExpExecArray | null
  while ((m = re.exec(cleaned)) !== null) {
    try {
      const text = JSON.parse(`"${m[2]}"`)
      if (text.trim()) turns.push({ speaker: m[1], text: text.trim() })
    } catch (err) {
      console.debug('[podcast] Skipped malformed salvaged dialogue turn:', err)
    }
  }
  return turns
}

const kamiSenseiPodcastHandler = async (c: any) => {
  const config = await c.req.json<{
        mode?: string
    hosts?: number
    language_mode?: string
    duration_minutes?: number
    format?: string
    custom_prompt?: string
    sources?: string[]
    topic?: string
    notebookId?: string
    speech_rate?: number
  }>().catch(() => null)

  if (!config) return c.json({ error: 'Invalid configuration payload.' }, 400)

    // Field-driven config (NotebookLM style). Defaults match the legacy
  // quick_auto behaviour so existing callers are unaffected.
  const hosts = config.hosts === 1 ? 1 : 2
  const languageMode = PODCAST_LANGUAGE_RULES[config.language_mode || ''] ? config.language_mode! : 'hinglish'
  const durationMinutes = Math.min(Math.max(Number(config.duration_minutes) || 10, 1), 60)
  const selectedSources = Array.isArray(config.sources) && config.sources.length
    ? config.sources.map((s) => String(s)).filter(Boolean)
    : null
  const formatId = (config.format && PODCAST_FORMATS[config.format]) ? config.format! : DEFAULT_PODCAST_FORMAT
  const fmt = PODCAST_FORMATS[formatId]
  const targetWords = podcastConfigToWords(durationMinutes)
  const scaledWords = Math.round(targetWords * fmt.wordScale)
  const focusBlock = config.custom_prompt
    ? `\n\nHOST FOCUS — heed these director notes; weave them in naturally, never as a flat list:\n${String(config.custom_prompt).slice(0, 2000)}`
    : ''

  return stream(c, async (stream) => {
    const send = (obj: any) => stream.write(JSON.stringify(obj) + '\n')

    try {
      // 1. RAG context from ChromaDB — filtered ONLY by checked sources
      let contextDocs: Array<{ text: string; metadata: any }> = []
      const bridgeUrl = (c.env.JARVIS_BRIDGE_HOST ? `http://${c.env.JARVIS_BRIDGE_HOST}:${c.env.JARVIS_BRIDGE_PORT || 7778}` : 'http://127.0.0.1:7778')
      try {
        const vectorRes = await fetch(`${bridgeUrl}/api/kamisensei/query_db`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: config.topic || 'Japanese vocabulary grammar kanji listening reading study material',
            sources: selectedSources || undefined,
            top_k: Math.min(Math.max(durationMinutes * 2, 6), 60)
          }),
          signal: AbortSignal.timeout(20000)
        }).catch(() => null)
        if (vectorRes && vectorRes.ok) {
          const vData = await vectorRes.json() as any
          if (Array.isArray(vData.matches)) contextDocs = vData.matches
        }
      } catch (err) {
        console.error('[podcast] Source retrieval failed:', err)
      }

            const sourcesUsed = [...new Set(contextDocs.map((d: any) => String(d?.metadata?.source || d?.source || 'Doc')))]
      await send({
        type: 'meta',
        format: formatId,
        hosts,
        language_mode: languageMode,
        duration_minutes: durationMinutes,
        sources: selectedSources || 'all',
        sources_used: sourcesUsed,
        context_chunks: contextDocs.length
      })

      // 2. Single-shot long-form script via Gemini (massive context window)
      // Every chunk is stamped with its exact origin so the script can
      // cross-reference multiple books (Genki vs Minna no Nihongo, etc.).
      const contextBlock = contextDocs.length > 0
        ? `\n\nSTUDY MATERIAL CONTEXT (stay faithful to it, teach from it; chunks may come from several books):\n` + contextDocs.map((d: any) => {
            const src = String(d?.metadata?.source || d?.source || 'Doc')
            let page = Number(d?.metadata?.page || d?.page || 1)
            if (!Number.isFinite(page) || page < 1) page = 1
            return `[Source: ${src}, Page ${page}]:\n${String(d?.text ?? '')}`
          }).join('\n\n').slice(0, 90000)
        : ''

      const hostLine = hosts === 1
        ? 'A single solo host ("HostA") presents the entire episode monologue-style.'
        : 'Two hosts: "HostA" is the charismatic male anchor (JARVIS-style) and "HostB" is the warm female Japanese expert (KamiSensei). They alternate turns interviewing each other.'

      const scriptPrompt = `You are the executive producer of the KamiSensei AI Podcast Studio.
Episode format: ${fmt.label} — ${fmt.style}
Produce an engaging study podcast script of approximately ${scaledWords} words (about ${durationMinutes} minutes of speech).
${hostLine}
${PODCAST_LANGUAGE_RULES[languageMode]}
Topic: "${config.topic || 'Complete Japanese learning overview from the provided study material'}".
Cover key vocabulary, kanji mnemonics, grammar patterns, real-world usage, and quick listener recall drills.
Each turn is 2-5 spoken sentences, natural and conversational, no stage directions, no markdown.
Output ONLY a raw JSON array of dialogue turns, no markdown fences:
[{"speaker": "HostA", "text": "..."}, {"speaker": "HostB", "text": "..."}]${focusBlock}${contextBlock}`

      let script: Array<{ speaker: string; text: string }> = []
      const providerErrors: string[] = []

      // Primary: Groq — reliable on this network. Gemini's
      // generativelanguage.googleapis.com hangs here for minutes, so keep
      // Gemini strictly as fallback. GROQ_MODEL (gpt-oss-120b) handles
      // English + Hinglish + Japanese prompts well.
      if (c.env.GROQ_API_KEY) {
        try {
          const gRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.env.GROQ_API_KEY}` },
            body: JSON.stringify({
              model: c.env.GROQ_MODEL || 'openai/gpt-oss-120b',
              messages: [{ role: 'user', content: scriptPrompt }],
              temperature: 0.6,
              max_tokens: 16384,
              reasoning_effort: 'low'
            }),
            signal: AbortSignal.timeout(180000)
          })
          if (gRes.ok) {
            const gData = await gRes.json() as any
            script = parsePodcastScript(gData.choices?.[0]?.message?.content || '')
            if (!script.length) providerErrors.push('Groq returned no usable script')
          } else {
            providerErrors.push(`Groq HTTP ${gRes.status}`)
          }
        } catch (err: any) {
          providerErrors.push(`Groq: ${err?.message || 'network error'}`)
        }
      }

      // Fallback: Gemini (massive context window) if Groq is unavailable.
      if (!script.length && (c.env.GOOGLE_API_KEY || c.env.GOOGLE_API_KEY_2)) {
        const googleKey = c.env.GOOGLE_API_KEY || c.env.GOOGLE_API_KEY_2
        const model = LOCKED_GOOGLE_MODEL
        for (let attempt = 1; attempt <= 2 && !script.length; attempt++) {
          try {
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(googleKey)}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                contents: [{ role: 'user', parts: [{ text: scriptPrompt }] }],
                generationConfig: { temperature: 0.6, maxOutputTokens: 32768, topP: 0.95 }
              }),
              signal: AbortSignal.timeout(300000)
            })
            if (response.ok) {
              const data = await response.json() as any
              const rawContent = data.candidates?.[0]?.content?.parts?.map((p: any) => p?.text || '').join('') || ''
              script = parsePodcastScript(rawContent)
              if (!script.length) providerErrors.push('Gemini returned no usable script')
            } else {
              providerErrors.push(`Gemini HTTP ${response.status}`)
              if (response.status === 429 || response.status === 503) await new Promise((r) => setTimeout(r, 4000))
            }
          } catch (err: any) {
            providerErrors.push(`Gemini: ${err?.message || 'network error'}`)
          }
        }
      }

      if (!script.length) {
        await send({ type: 'error', message: 'Script generation failed — ' + (providerErrors.join('; ') || 'no AI providers configured') + '. Check keys/internet.' })
        return
      }

      await send({ type: 'script', script, total_turns: script.length })

      // 3. Async Audio Queue Stream: split into 1-2 minute dialogue batches
      // (~300 spoken words each) and synthesize them sequentially. Each audio
      // chunk is pushed to the client immediately over the chunked stream.
      const batches: Array<Array<{ speaker: string; text: string; index: number }>> = []
      let current: Array<{ speaker: string; text: string; index: number }> = []
      let currentWords = 0
      script.forEach((turn, index) => {
        current.push({ ...turn, index })
        currentWords += turn.text.split(/\s+/).length
        if (currentWords >= 300) {
          batches.push(current)
          current = []
          currentWords = 0
        }
      })
      if (current.length) batches.push(current)

      // 3. Hand every dialogue turn to the Python Edge-TTS engine over
      // loopback HTTP (background/podcast_engine.py, port 7781). The Node
      // server NEVER touches the filesystem: synthesis, temp chunks and
      // pure-Python MP3 concatenation all live inside the Python engine.
      // The browser only ever receives progress frames plus a final
      // {type:'done', url} pointing at the finished .mp3.
      ensurePodcastEngine()
      let engineUp = await podcastReady()
      for (let i = 0; i < 20 && !engineUp && !stream.aborted; i++) {
        await new Promise((r) => setTimeout(r, 500))
        engineUp = await podcastReady()
      }
      if (!engineUp) {
        await send({ type: 'error', message: 'Podcast TTS engine (background/podcast_engine.py) did not come up on port ' + PODCAST_PORT + '.' })
        return
      }

      const notebookId = String(config.notebookId || 'session')
      const langMode = String(config.language_mode || 'hinglish').toLowerCase()
      const session = await podcastPost('/podcast/start', {
        notebook_id: notebookId,
        language_mode: langMode,
        speed: Number(config.speech_rate) || 1
      }, 10000)
      if (!session || !session.ok || !session.session) {
        await send({ type: 'error', message: 'Podcast engine refused to start a synthesis session.' })
        return
      }

      try {
        for (const batch of batches) {
          for (const turn of batch) {
            if (stream.aborted) return
            const speaker = turn.speaker || 'HostA'
            const res = await podcastPost('/podcast/turn', {
              session: session.session,
              speaker,
              text: turn.text
            }, 180000)
            if (res && res.ok) {
              await send({ type: 'audio', batch: batches.indexOf(batch), batches: batches.length, turn: turn.index, speaker, text: turn.text, status: 'ok' })
            } else {
              await send({ type: 'tts_warning', message: 'A dialogue turn failed to synthesize and was skipped.', turn: turn.index })
            }
          }
        }

        const fin = await podcastPost('/podcast/finalize', { session: session.session }, 600000)
        if (fin && fin.ok && fin.url) {
          await send({ type: 'done', total_turns: script.length, total_batches: batches.length, url: fin.url, seconds: Number(fin.seconds) || 0, engine: 'edge-tts-python' })
        } else {
          await send({ type: 'error', message: 'Audio muxing failed inside the Python podcast engine.' })
        }
      } finally {
        // Cancel is a no-op once finalize succeeded (the session was already popped).
        podcastPost('/podcast/cancel', { session: session.session }, 5000).catch(() => {})
      }

    } catch (err: any) {
      console.error('[podcast] Stream generation failed:', err)
      try {
        await send({ type: 'error', message: err.message || 'Podcast stream error' })
      } catch (sendErr) {
        console.debug('[podcast] Client disconnected before error delivery:', sendErr)
      }
    }
  })
}

app.post('/api/kamisensei/generate-podcast', kamiSenseiPodcastHandler)

// ── Serve generated Content Writer documents ──────────────────────────────────
// background/content_writer.py writes into ./artifacts/documents. The Artifacts
// tab links these, so the browser needs to read them back. The path segment is
// strictly allowlisted (no slashes, no dots beyond the extension) so no path
// traversal can ever reach the filesystem.
app.get('/artifacts/documents/:file', (c) => {
  const file = String(c.req.param('file') || '')
  if (!/^[a-zA-Z0-9._-]+\.(pdf|docx|md|txt)$/i.test(file)) return c.json({ error: 'invalid_file' }, 400)
  const full = path.join(process.cwd(), 'artifacts', 'documents', file)
  if (!existsSync(full)) return c.json({ error: 'not_found' }, 404)
  const ext = path.extname(full).toLowerCase()
  const types: Record<string, string> = {
    '.pdf': 'application/pdf',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.md': 'text/markdown; charset=utf-8',
    '.txt': 'text/plain; charset=utf-8',
  }
  const buf = readFileSync(full)
  return c.body(new Uint8Array(buf), 200, {
    'Content-Type': types[ext] || 'application/octet-stream',
    'Content-Length': String(buf.length),
    // filename is already restricted to [A-Za-z0-9._-] by the guard above, so
    // it cannot break out of the quoted header value.
    'Content-Disposition': `inline; filename="${file}"`,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  })
})

// ── Serve generated podcast files ────────────────────────────────────────────
// The Python engine writes masters to ./artifacts/podcasts; the browser mini
// player needs them over HTTP. Filename is strictly allowlisted so no path
// traversal can ever reach the filesystem.
app.get('/artifacts/podcasts/:file', (c) => {
  const file = String(c.req.param('file') || '')
  if (!/^[a-zA-Z0-9_-]+\.mp3$/.test(file)) return c.json({ error: 'invalid_file' }, 400)
  const full = path.join(process.cwd(), 'artifacts', 'podcasts', file)
  if (!existsSync(full)) return c.json({ error: 'not_found' }, 404)
  const buf = readFileSync(full)
  const total = buf.length
  const range = c.req.header('Range')
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range)
    if (m) {
      let start = m[1] ? parseInt(m[1], 10) : 0
      let end = m[2] ? parseInt(m[2], 10) : total - 1
      if (isNaN(start) || start < 0) start = 0
      if (isNaN(end) || end >= total) end = total - 1
      if (start <= end) {
        const slice = new Uint8Array(buf.subarray(start, end + 1))
        return c.body(slice, 206, {
          'Content-Type': 'audio/mpeg',
          'Content-Length': String(slice.length),
          'Content-Range': `bytes ${start}-${end}/${total}`,
          'Accept-Ranges': 'bytes',
          'Cache-Control': 'no-store'
        })
      }
    }
  }
  return c.body(new Uint8Array(buf), 200, {
    'Content-Type': 'audio/mpeg',
    'Content-Length': String(total),
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'no-store'
  })
})

const navItems = [
  ['dashboard', 'layout-dashboard', 'Dashboard'],
  ['kamisensei', 'languages', 'KAMISENSEILM'],
  ['voice', 'mic', 'Voice Command'],
  ['web', 'globe-2', 'Web Intelligence'],
  ['modules', 'layout-grid', 'Modules & Upgrades'],
  ['library', 'library', 'Skill Library'],
  ['vision', 'scan-eye', 'Vision System'],
  ['gesture', 'hand', 'Gesture Control'],
  ['system', 'cpu', 'System & Files'],
  ['productivity', 'notebook-pen', 'Productivity'],
  ['memory', 'brain-circuit', 'Memory Core'],
  ['cowork', 'users', 'Co-work'],
  ['repos', 'git-branch', 'Repos'],
  ['security', 'shield-check', 'Security'],
  ['settings', 'settings-2', 'Settings']
]


app.get('/', (c) => c.render(
  <main id="jarvis-app">
    <aside id="sidebar" class="sidebar" aria-label="Primary navigation">
      <header class="brand">
        <button id="sidebar-close" class="icon-button mobile-only" aria-label="Close menu"><i data-lucide="x"></i></button>
        <div class="brand-mark" aria-hidden="true"><span>J</span></div>
        <div class="brand-copy"><strong>JARVIS</strong><small>v0.10.0 / ONLINE</small></div>
        <button id="sidebar-collapse" class="icon-button sidebar-collapse-btn" aria-label="Collapse sidebar" aria-expanded="true" aria-controls="sidebar" title="Collapse sidebar"><i data-lucide="panel-left-close"></i></button>
      </header>
      <nav class="nav-list">
        {navItems.map(([id, icon, label], index) => {
          if (id === 'settings') {
            return (
              <div class="nav-group nav-group--settings" id="nav-group-settings">
                <button class="nav-item nav-item--parent" data-view={id} data-tip={label} aria-label={label} id="nav-item-settings">
                  <i data-lucide={icon}></i>
                  <span class="nav-label">{label}</span>
                  <i data-lucide="chevron-down" class="nav-chevron" id="nav-settings-chevron"></i>
                </button>
                <div class="nav-submenu open" id="nav-settings-submenu">
                  <button class="nav-subitem" data-view="settings" data-settings-tab="general" title="General Settings">
                    <i data-lucide="sliders"></i>
                    <span>General</span>
                  </button>
                  <button class="nav-subitem" data-view="settings" data-settings-tab="appearance" title="Appearance">
                    <i data-lucide="palette"></i>
                    <span>Appearance</span>
                  </button>
                  <button class="nav-subitem" data-view="settings" data-settings-tab="audio" title="Audio & Voice">
                    <i data-lucide="volume-2"></i>
                    <span>Audio &amp; Voice</span>
                  </button>
                  <button class="nav-subitem" data-view="settings" data-settings-tab="keys" title="API Keys">
                    <i data-lucide="key"></i>
                    <span>API Keys</span>
                  </button>
                  <button class="nav-subitem nav-subitem--brain" data-view="brain" title="Neural Brain Explorer">
                    <i data-lucide="brain"></i>
                    <span>Brain</span>
                  </button>
                </div>
              </div>
            )
          }
          return (
            <button class={`nav-item ${index === 0 ? 'active' : ''} ${id === 'kamisensei' ? 'kamisensei-nav-item' : ''}`} data-view={id} data-tip={label} aria-label={label}>
              {id === 'kamisensei' ? (
                <span class="nav-kanji-icon" aria-hidden="true">神</span>
              ) : (
                <i data-lucide={icon}></i>
              )}
              <span class="nav-label">{label}</span>
              {id === 'kamisensei' && <small class="nav-subbadge">AI</small>}
            </button>
          )
        })}
      </nav>
      <section class="core-status" data-tip="JARVIS Core status"><div class="core-mini"><span></span></div><div class="core-copy"><strong>JARVIS CORE</strong><small id="bridge-label">BRIDGE OFFLINE</small><button id="duplex-toggle" class="duplex-chip" type="button" data-command="live mode chalu kardo" data-live="0" title="Full-duplex voice. LIVE: no wake word, and he stops the moment you talk over him. CLASSIC: the wake-word pipeline. The click sends the same spoken command, so there is only one command path."><span class="duplex-dot"></span>DUPLEX <strong id="duplex-mode">CLASSIC</strong><small id="duplex-meta">say “live mode on”</small></button></div></section>
    </aside>
    <div id="nav-tip" class="nav-tip" role="tooltip" aria-hidden="true"></div>
    <div id="sidebar-backdrop" class="sidebar-backdrop"></div>

    <section class="workspace">
      <header class="topbar">
        <button id="menu-button" class="icon-button mobile-only" aria-label="Open menu"><i data-lucide="menu"></i></button>
        <div class="topbar-voice">
          <button id="voice-orb" class="voice-orb topbar-orb" aria-label="Start voice command"><i data-lucide="mic"></i></button>
          <div class="topbar-voice-copy">
            <span class="topbar-voice-state"><span class="pulse-dot"></span><strong id="voice-label">STANDBY</strong></span>
            <small id="voice-hint">Say “Hey JARVIS”</small>
          </div>
          <div class="wave" aria-hidden="true">{Array.from({ length: 14 }).map((_, i) => <i style={`--h:${20 + (i * 23) % 60}%`}></i>)}</div>
        </div>
        <div class="sys-stats" id="sys-stats">
          <div class="sys-stat"><i data-lucide="cpu"></i><div class="sys-copy"><span>CPU <strong id="cpu-value">--%</strong></span><div class="sys-bar"><i id="cpu-bar" style="width:0%"></i></div></div></div>
          <div class="sys-stat"><i data-lucide="memory-stick"></i><div class="sys-copy"><span>RAM <strong id="ram-value">--%</strong></span><div class="sys-bar"><i id="ram-bar" style="width:0%"></i></div></div></div>
          <div class="sys-stat"><i data-lucide="hard-drive"></i><div class="sys-copy"><span>DISK <strong id="disk-value">--%</strong></span><div class="sys-bar"><i id="disk-bar" style="width:0%"></i></div></div></div>
          <p class="panel-note" id="system-note">Connect Windows bridge for live metrics.</p>
        </div>
        <div class="top-actions">
          <div class="clock"><strong id="clock">--:--:--</strong><span id="date">Loading date</span></div>
          <button id="notify-button" class="icon-button" aria-label="Notifications" title="Pending reminders and alerts"><i data-lucide="bell"></i><span id="notify-dot" class="notify-dot" hidden></span></button>
          <button id="live-screen-toggle" class="live-screen-toggle" type="button" data-command="live screen chalu karo" data-live="0" aria-pressed="false" aria-label="Live screen is off" title="Live screen is off. Click or say “live screen on”."><i data-lucide="monitor"></i><span class="live-screen-dot" aria-hidden="true"></span></button>
          <button id="settings-shortcut" class="icon-button" data-view="settings" aria-label="Settings" title="Settings"><i data-lucide="settings"></i></button>
          <button id="float-hud-button" class="status-pill" title="Show floating JARVIS HUD" aria-label="Show floating JARVIS HUD"><i data-lucide="sparkles"></i> HUD</button>
          <button id="gesture-quick-stop" class="status-pill gesture-quick-stop" type="button" hidden aria-pressed="false" title="Pause gesture control" aria-label="Pause gesture control"><i data-lucide="hand"></i><strong>Pause gestures</strong></button>
          <span id="connection-chip" class="connection-chip offline">Bridge offline</span>
          <button id="command-focus" class="status-pill"><span class="pulse-dot"></span>Standby</button>
          <button id="topbar-zip-btn" class="status-pill zip-pill" title="Download Holographic Brain Package (.zip)" aria-label="Download Holographic Brain Package (.zip)"><i data-lucide="download"></i><span>ZIP</span></button>
        </div>
        <p id="greeting" class="sr-only">Good morning, Prateek.</p>
      </header>

      <section id="dashboard-view" class="view active" data-view-panel="dashboard">
        <div class="dashboard-shell">
          <div class="dash-primary">

          {/* ── Main Workspace: module tabs + holographic core ─────────── */}
          <section class="panel workspace-panel" aria-label="Main workspace">
            <header class="ws-head">
              <div class="ws-head-copy">
                <span class="ws-head-icon"><i data-lucide="layout-dashboard"></i></span>
                <div><strong>Main Workspace</strong><small>Switch between different modules</small></div>
              </div>
              <div class="ws-head-tools">
                <span id="voice-state" class="state-label">STANDBY</span>
                <button type="button" id="ws-expand" class="chip-button" title="Expand workspace" aria-label="Expand workspace"><i data-lucide="expand"></i></button>
                <button type="button" id="ws-fullscreen" class="chip-button" title="Fullscreen browser" aria-label="Fullscreen browser"><i data-lucide="maximize"></i><span>Fullscreen</span></button>
              </div>
            </header>
            <nav class="ws-tabs" id="ws-tabs" role="tablist" aria-label="Workspace modules">
              <button type="button" class="ws-tab active" data-ws-module="screen" role="tab" aria-selected="true"><i data-lucide="monitor-dot"></i><span>Screen Analysis</span></button>
              <button type="button" class="ws-tab" data-ws-module="camera" role="tab" aria-selected="false"><i data-lucide="camera"></i><span>Camera</span></button>
              <button type="button" class="ws-tab" data-ws-module="gesture" role="tab" aria-selected="false"><i data-lucide="hand"></i><span>Gesture Control</span></button>
              <button type="button" class="ws-tab" data-ws-module="hud" role="tab" aria-selected="false"><i data-lucide="gauge"></i><span>HUD</span></button>
            </nav>
            <div class="ws-body">
              <div class="ws-stage" id="ws-stage" data-ws-active="screen">
                <div class="orb-wrap" id="orb-wrap" aria-hidden="true">
                  <canvas id="orb-particles"></canvas>
                  <span class="orbit orbit-a"></span>
                  <span class="orbit orbit-b"></span>
                  <span class="orbit orbit-c"></span>
                  <div class="core-orb"><span>J</span></div>
                  <div class="orb-caption"><strong>JARVIS</strong><small id="orb-state">STANDBY</small></div>
                </div>

                <article class="stage-pane stage-screen" data-ws-pane="screen">
                  <header class="stage-pane-head">
                    <span class="stage-pane-icon"><i data-lucide="monitor-dot"></i></span>
                    <div><strong>Screen Analysis</strong><small><span id="screen-dot" class="mini-dot"></span><span id="screen-state">Idle</span> — <span id="screen-note">start the Windows bridge to enable the screen agent</span></small></div>
                  </header>
                  <ul class="stage-list">
                    <li><i data-lucide="check-circle-2"></i>Text detection</li>
                    <li><i data-lucide="check-circle-2"></i>OCR (image to text)</li>
                    <li><i data-lucide="check-circle-2"></i>UI element recognition</li>
                    <li><i data-lucide="check-circle-2"></i>Context analysis</li>
                  </ul>
                  <div class="stage-pills">
                    <span class="stage-pill active"><i data-lucide="zap"></i>Real-time</span>
                    <span class="stage-pill"><i data-lucide="brain"></i>Smart</span>
                    <span class="stage-pill"><i data-lucide="crosshair"></i>Accurate</span>
                  </div>
                </article>

                <article class="panel camera-panel camera-mirror stage-pane stage-camera" data-ws-pane="camera" data-gesture-panel>
                  <video class="camera-feed camera-feed-large" autoplay muted playsinline></video>
                  <canvas class="gesture-canvas" aria-label="Hand landmark overlay"></canvas>
                  <div class="camera-placeholder"><i data-lucide="hand"></i><strong>Camera is off</strong><span>Enable the camera to start the mirror and the MediaPipe hand-landmark pipeline.</span></div>
                  <div class="camera-hud">
                    <button class="gesture-toggle" type="button"><i data-lucide="hand"></i><span><strong>Start hand tracking</strong></span></button>
                    <button class="camera-power" id="camera-power-toggle" type="button"><i data-lucide="camera"></i> Start camera</button>
                    <span class="gesture-feedback"></span>
                    <span class="gesture-status">Camera off</span>
                  </div>
                </article>
                <article class="stage-pane stage-gesture" data-ws-pane="gesture">
                  <header class="stage-pane-head">
                    <span class="stage-pane-icon"><i data-lucide="hand"></i></span>
                    <div><strong>Gesture Control</strong><small><span class="gesture-status">Camera off</span></small></div>
                  </header>
                  <ul class="gesture-legend">
                    <li><span class="legend-dot cyan"></span><div><strong>Right index</strong><small>steers the real Windows cursor</small></div></li>
                    <li><span class="legend-dot green"></span><div><strong>Right pinch</strong><small>thumb + index is a left click, thumb + middle is a right click</small></div></li>
                    <li><span class="legend-dot amber"></span><div><strong>Right fist</strong><small>hold to drag, open to release</small></div></li>
                    <li><span class="legend-dot blue"></span><div><strong>Left hand</strong><small>pinch selects a JARVIS control under that hand, open palm returns home</small></div></li>
                    <li><span class="legend-dot violet"></span><div><strong>Both hands</strong><small>apart or together scales the active view</small></div></li>
                    <li><span class="legend-dot orange"></span><div><strong>Both palms</strong><small>swipe left or right to navigate, up or down to scroll</small></div></li>
                    <li><span class="legend-dot red"></span><div><strong>Both fists</strong><small>pause every gesture action; both palms up resumes</small></div></li>
                  </ul>
                  <button class="gesture-toggle" type="button"><i data-lucide="hand"></i><span><strong>Start hand tracking</strong></span></button>
                </article>

                <article class="stage-pane stage-hud" data-ws-pane="hud">
                  <header class="stage-pane-head">
                    <span class="stage-pane-icon"><i data-lucide="gauge"></i></span>
                    <div><strong>HUD &amp; Overlay</strong><small>The floating console is a visual client of the same background core</small></div>
                  </header>
                  <div class="hud-scale-readout"><span>Dashboard zoom</span><strong id="hud-zoom">100%</strong></div>
                  <div class="stage-actions">
                    <button type="button" class="ws-action" data-float-hud><i data-lucide="sparkles"></i><span>Show floating HUD</span></button>
                    <button type="button" class="ws-action" id="hud-reset"><i data-lucide="refresh-cw"></i><span>Reset zoom</span></button>
                    <button type="button" class="ws-action" data-command="show system info"><i data-lucide="cpu"></i><span>Read system info</span></button>
                    <button type="button" class="ws-action" data-command="take a screenshot"><i data-lucide="camera"></i><span>Capture screenshot</span></button>
                  </div>
                </article>
              </div>

              <aside class="quick-card" aria-label="Quick actions">
                <header><span class="panel-title"><i data-lucide="zap"></i> Quick Actions</span><button class="text-button" data-view="modules">View all</button></header>
                <div class="quick-grid">
                  <button data-command="open youtube"><span class="quick-icon youtube"><i data-lucide="youtube"></i></span><span>YouTube</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                  <button data-command="open gmail"><span class="quick-icon gmail"><i data-lucide="mail"></i></span><span>Gmail</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                  <button data-command="search the web for latest AI news"><span class="quick-icon search"><i data-lucide="search"></i></span><span>Web Search</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                  <button data-command="take a screenshot"><span class="quick-icon shot"><i data-lucide="camera"></i></span><span>Screenshot</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                  <button data-command="list files on desktop"><span class="quick-icon files"><i data-lucide="folder-open"></i></span><span>Open Files</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                  <button data-view="modules"><span class="quick-icon more"><i data-lucide="ellipsis"></i></span><span>More</span><i data-lucide="chevron-right" class="quick-arrow"></i></button>
                </div>
              </aside>
            </div>

            <div class="ws-status-row">
              <article class="ws-mini">
                <span class="ws-mini-icon"><i data-lucide="audio-waveform"></i></span>
                <div><strong>Voice Assistant</strong><small id="mini-voice">Standby — say “Hey JARVIS”</small></div>
              </article>
              <article class="ws-mini">
                <span class="ws-mini-icon"><i data-lucide="hand"></i></span>
                <div><strong>Gesture Control</strong><small id="mini-gesture">Ready — camera off</small></div>
              </article>
              <article class="ws-mini">
                <span class="ws-mini-icon"><i data-lucide="cpu"></i></span>
                <div><strong>System Info</strong><small id="mini-system">CPU --% · RAM --% · DISK --%</small></div>
              </article>
              <article class="ws-mini">
                <span class="ws-mini-icon"><i data-lucide="power"></i></span>
                <div><strong>Live Mode</strong><small id="mini-live">Connecting to the background core…</small></div>
              </article>
            </div>
          </section>
          <article class="panel dashboard-chat" id="dashboard-chat" aria-label="JARVIS conversation">
            <header class="chat-header">
              <div class="chat-head-copy">
                <span class="panel-title"><i data-lucide="message-square"></i> Live Conversation</span>
                <span id="chat-live-state" class="chat-live-state">JARVIS is on standby</span>
              </div>
              <div class="chat-header-tools">
                <span id="ai-provider" class="connection-chip">AI: automatic</span>
                <button type="button" id="chat-history-toggle" class="chip-button" aria-label="Toggle chat history" title="Chat history"><i data-lucide="panel-left"></i></button>
                <button type="button" id="chat-expand" class="chip-button" aria-label="Expand conversation" title="Expand conversation"><i data-lucide="maximize-2"></i></button>
                <button type="button" id="clear-chat-button" class="chip-button" aria-label="Clear chat" title="Clear chat"><i data-lucide="trash-2"></i></button>
              </div>
            </header>
            <div class="chat-body">
              <aside id="chat-history" class="chat-history" hidden aria-label="Chat history">
                <div class="chat-history-head">
                  <strong>Chat history</strong>
                  <button type="button" id="chat-new-button" class="chip-button" title="New chat"><i data-lucide="plus"></i><span>New</span></button>
                  <button type="button" id="chat-history-close" class="chip-button" aria-label="Close history" title="Close"><i data-lucide="x"></i></button>
                </div>
                <label class="chat-history-search"><i data-lucide="search"></i><input id="chat-history-search" type="search" placeholder="Search conversations" aria-label="Search conversations" /></label>
                <div id="chat-history-list" class="chat-history-list"></div>
              </aside>
              <div id="chat-log" class="chat-log"><div class="message assistant"><span class="avatar">J</span><p>Hello, Prateek. Ask me anything or give me a command.</p></div></div>
            </div>
            <form id="chat-form" class="chat-composer">
              <button type="button" id="dock-mic" class="dock-icon" aria-label="Voice input" title="Voice input"><i data-lucide="mic"></i></button>
              <textarea id="chat-input" rows={1} placeholder='Message JARVIS or say “Open YouTube and search lo-fi music”'></textarea>
              <label class="model-picker" title="AI model (Auto = fastest configured provider)">
                <i data-lucide="settings-2"></i>
                <select id="chat-model-select" class="chat-model-select" aria-label="AI model">
                  <option value="auto">Auto — fastest available</option>
                  <option value="groq">Groq · GPT-OSS 120B</option>
                  <option value="gemini">Gemini Flash Lite · Google</option>
                  <option value="xkiro">Qwen3.7 Flash · xKiro</option>
                  <option value="nvidia">Nemotron 3.5 Lightning · NVIDIA</option>
                  <option value="openrouter">MiniMax M3.1 Flash (free) · OpenRouter</option>
                </select>
              </label>
              <button type="submit" class="chat-send-btn" aria-label="Send message" title="Send"><i data-lucide="send"></i></button>
            </form>
          </article>
          </div>

          <aside class="dash-rail" aria-label="Live status">
            <section class="panel rail-panel" aria-label="System status">
              <header class="rail-head"><span class="panel-title"><i data-lucide="activity"></i> System Status</span><span id="rail-live" class="live-tag offline">OFFLINE</span></header>
              <div class="ring-grid">
                <div class="ring"><svg viewBox="0 0 44 44" aria-hidden="true"><circle class="ring-track" cx="22" cy="22" r="18"></circle><circle id="ring-cpu" class="ring-fill" cx="22" cy="22" r="18"></circle></svg><strong id="ring-cpu-value">--%</strong><small>CPU</small></div>
                <div class="ring"><svg viewBox="0 0 44 44" aria-hidden="true"><circle class="ring-track" cx="22" cy="22" r="18"></circle><circle id="ring-ram" class="ring-fill" cx="22" cy="22" r="18"></circle></svg><strong id="ring-ram-value">--%</strong><small>RAM</small></div>
                <div class="ring"><svg viewBox="0 0 44 44" aria-hidden="true"><circle class="ring-track" cx="22" cy="22" r="18"></circle><circle id="ring-disk" class="ring-fill" cx="22" cy="22" r="18"></circle></svg><strong id="ring-disk-value">--%</strong><small>DISK</small></div>
                <div class="ring"><svg viewBox="0 0 44 44" aria-hidden="true"><circle class="ring-track" cx="22" cy="22" r="18"></circle><circle id="ring-batt" class="ring-fill" cx="22" cy="22" r="18"></circle></svg><strong id="ring-batt-value">--%</strong><small>BATT</small></div>
              </div>
            </section>
            <section class="panel rail-panel" aria-label="Recent activity">
              <header class="rail-head"><span class="panel-title"><i data-lucide="list-tree"></i> Recent Activity</span><button id="clear-activity" class="text-button">Clear</button></header>
              <ul id="activity-list" class="activity-list"><li><span class="activity-icon"><i data-lucide="sparkles"></i></span><div><strong>JARVIS initialized</strong><small>Ready for your command</small></div><time>Now</time></li></ul>
            </section>
            <section class="panel rail-panel" aria-label="Chat history">
              <header class="rail-head"><span class="panel-title"><i data-lucide="messages-square"></i> Chat History</span><button id="chat-history-view-all" class="text-button">View All</button></header>
              <label class="rail-search"><i data-lucide="search"></i><input id="rail-chat-search" type="search" placeholder="Search chats" aria-label="Search chat history" /></label>
              <div id="rail-chat-history-list" class="rail-chat-list"></div>
            </section>
            <section class="panel rail-panel rail-camera" aria-label="Camera and gesture view">
              <header class="rail-head"><span class="panel-title"><i data-lucide="camera"></i> Camera / Gesture View</span><span class="gesture-status">Camera off</span></header>
              <div id="rail-camera-preview" class="camera-panel camera-mirror rail-preview" data-gesture-panel>
                <video class="camera-feed rail-camera-feed" autoplay muted playsinline></video>
                <canvas class="gesture-canvas" aria-label="Hand landmark overlay"></canvas>
                <button type="button" id="rail-camera-toggle" class="rail-preview-empty"><i data-lucide="camera-off"></i><strong>Camera off</strong><small>Click to enable</small></button>
              </div>
              <ul class="gesture-legend compact">
                <li><span class="legend-dot blue"></span><div><strong>Right index</strong><small>open + click</small></div></li>
                <li><span class="legend-dot red"></span><div><strong>Right fist</strong><small>close + drag</small></div></li>
                <li><span class="legend-dot amber"></span><div><strong>Both palms</strong><small>swipe + scroll</small></div></li>
                <li><span class="legend-dot green"></span><div><strong>Left hand</strong><small>JARVIS pointer + select</small></div></li>
              </ul>
              <button type="button" id="rail-gesture-toggle" class="rail-gesture-btn"><i data-lucide="hand"></i><span>Start hand tracking</span></button>
            </section>
          </aside>
        </div>
      </section>

      {/* ── KAMI-SENSEI VIEW (Two-Layer Architecture) ──────────────────── */}
      <section id="kamisensei-view" class="view" data-view-panel="kamisensei">

        {/* ═══ LAYER 1: MAIN DASHBOARD (Notebook Grid — default visible) ═══ */}
        <div id="ks-main-dashboard" class="ks-main-dashboard">

          {/* Dashboard Top Bar */}
          <header class="ks-topbar-main">
            <div class="ks-brand-main">
              <div class="kamisensei-icon-badge" aria-hidden="true"><span>神</span></div>
              <div class="ks-brand-text">
                <h2>J.A.R.V.I.S.</h2>
                <span class="ks-brand-sub">J.A.R.V.I.S. // JAPANESE LANGUAGE TUTOR — KAMISENSEI PROTOCOL</span>
              </div>
            </div>
            <div class="ks-status-pills">
              <span class="ks-status-pill system"><i data-lucide="activity"></i><span>SYSTEM STATUS</span><strong>ONLINE</strong></span>
              <span class="ks-status-pill engine"><i data-lucide="cpu"></i><span>LANGUAGE ENGINE</span><strong>ACTIVE</strong></span>
            </div>
            <div class="ks-topbar-actions">
              <button id="ks-dash-create-nb" class="kamisensei-pill-btn primary" title="Create Notebook"><i data-lucide="plus"></i><span>Create notebook</span></button>
              <span class="kamisensei-pro-badge">PRO</span>
              <div class="kamisensei-user-avatar" title="Commander Profile"><span>P</span></div>
            </div>
          </header>

          {/* Tab Bar + Search */}
          <div class="ks-tab-bar">
            <div class="ks-tabs">
              <button class="ks-tab active" data-ks-tab="all">All</button>
              <button class="ks-tab" data-ks-tab="my">My Notebooks</button>
              <button class="ks-tab" data-ks-tab="discover">Discover</button>
              <button class="ks-tab" data-ks-tab="collections">Collections</button>
              <button class="ks-tab" data-ks-tab="sense" id="ks-sense-tab">KAMI/Sense</button>
            </div>
            <div class="ks-tab-search">
              <i data-lucide="search"></i>
              <input id="ks-nb-search" type="text" placeholder="Search notebooks..." autocomplete="off" />
            </div>
          </div>

          {/* Featured Japanese Workbooks — Horizontal Scroll */}
          <section class="ks-section">
            <h3 class="ks-section-title"><i data-lucide="star"></i> Featured Japanese Workbooks</h3>
            <div class="ks-featured-row">
              <div class="ks-featured-card" data-nb-featured="genki-1">
                <div class="ks-featured-art grad-sakura"><span class="ks-art-kanji">元気</span><span class="ks-art-sub">I</span></div>
                <div class="ks-featured-info"><strong>Genki I — 3rd Edition</strong><small>Elementary • 23 Lessons</small></div>
                <button class="ks-card-share" title="Share"><i data-lucide="share-2"></i></button>
              </div>
              <div class="ks-featured-card" data-nb-featured="genki-2">
                <div class="ks-featured-art grad-ocean"><span class="ks-art-kanji">元気</span><span class="ks-art-sub">II</span></div>
                <div class="ks-featured-info"><strong>Genki II — 3rd Edition</strong><small>Intermediate • 23 Lessons</small></div>
                <button class="ks-card-share" title="Share"><i data-lucide="share-2"></i></button>
              </div>
              <div class="ks-featured-card" data-nb-featured="tobira">
                <div class="ks-featured-art grad-fuji"><span class="ks-art-kanji">扉</span><span class="ks-art-sub">TOBIRA</span></div>
                <div class="ks-featured-info"><strong>Tobira Gateway</strong><small>Pre-Advanced • 15 Lessons</small></div>
                <button class="ks-card-share" title="Share"><i data-lucide="share-2"></i></button>
              </div>
              <div class="ks-featured-card" data-nb-featured="jlpt-n3">
                <div class="ks-featured-art grad-midnight"><span class="ks-art-kanji">N3</span><span class="ks-art-sub">JLPT</span></div>
                <div class="ks-featured-info"><strong>JLPT N3 Sou-Matome</strong><small>Grammar + Vocab • 8 Weeks</small></div>
                <button class="ks-card-share" title="Share"><i data-lucide="share-2"></i></button>
              </div>
              <div class="ks-featured-card" data-nb-featured="kanji-master">
                <div class="ks-featured-art grad-ember"><span class="ks-art-kanji">漢字</span><span class="ks-art-sub">MASTER</span></div>
                <div class="ks-featured-info"><strong>Kanji Master N4-N3</strong><small>800 Kanji • Drill Workbook</small></div>
                <button class="ks-card-share" title="Share"><i data-lucide="share-2"></i></button>
              </div>
            </div>
          </section>

          {/* Recent Japanese Notebooks — Grid */}
          <section class="ks-section">
            <h3 class="ks-section-title"><i data-lucide="clock"></i> Recent Japanese Notebooks</h3>
            <div id="ks-nb-grid" class="ks-nb-grid">
              {/* Create New Notebook Card */}
              <button id="ks-grid-create-nb" class="ks-create-card" type="button">
                <div class="ks-create-icon"><i data-lucide="plus"></i></div>
                <strong>Create New Notebook</strong>
                <small>Initialize Study Session</small>
              </button>
              {/* Dynamic notebook cards are injected here by app.js */}
            </div>
          </section>

          {/* Dashboard Footer */}
          <footer class="ks-dash-footer">
            <div class="stark-watermark-group">
              <div class="stark-star-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="#22c7f2" opacity="0.75">
                  <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z"/>
                </svg>
              </div>
              <div class="stark-industries-logo">
                <span>STARK</span>
                <small>INDUSTRIES</small>
              </div>
            </div>
            <span class="ks-dash-version">KamiSensei Protocol v2.0 — 神先生</span>
          </footer>
        </div>

        {/* ═══ LAYER 1.5: KAMI/SENSE COMMAND CENTER (hidden by default) ═══ */}
        <div id="ks-sense-view" class="ks-sense-view" style="display:none;">
          <div class="kamisensei-container">
            <header class="kamisensei-topbar">
              <div class="kamisensei-brand">
                <button id="ks-sense-back-btn" class="ks-back-btn" type="button" title="Back to Notebooks">
                  <i data-lucide="arrow-left"></i>
                  <span>Notebooks</span>
                </button>
                <div class="ks-topbar-divider"></div>
                <div class="kamisensei-icon-badge" aria-hidden="true"><span>神</span></div>
                <div class="kamisensei-title-group">
                  <h2>KAMI/Sense</h2>
                  <span class="kamisensei-subtag">J.A.R.V.I.S. // PERSONALIZED STUDY COMMAND CENTER — 感覚</span>
                </div>
              </div>
              <div class="ks-topbar-actions">
                <span class="ks-status-pill system"><i data-lucide="save"></i><span>STATE</span><strong id="ks-sense-save-state">SYNCED</strong></span>
              </div>
            </header>

            <div class="ks-sense-grid">
              {/* COLUMN 1 — Active Japanese Tasks / Drills Checklist */}
              <section class="panel kamisensei-panel ks-sense-col" aria-label="Active Japanese Tasks and Drills">
                <div class="panel-header-row">
                  <span class="panel-tag">Active Tasks / Drills</span>
                  <i data-lucide="list-checks" class="ks-sense-col-icon"></i>
                </div>
                <form id="ks-sense-task-form" class="ks-sense-add-row">
                  <input id="ks-sense-task-input" type="text" class="field" placeholder="e.g. Genki L14 〜た form drill — 20 cards" autocomplete="off" />
                  <button class="primary-button ks-sense-add-btn" type="submit"><i data-lucide="plus"></i></button>
                </form>
                <div id="ks-sense-task-list" class="ks-sense-list"></div>
                <div class="ks-sense-col-foot"><span id="ks-sense-task-stats">0 open · 0 done</span></div>
              </section>

              {/* COLUMN 2 — Daily Revision Schedule Goals */}
              <section class="panel kamisensei-panel ks-sense-col" aria-label="Daily Revision Schedule">
                <div class="panel-header-row">
                  <span class="panel-tag">Daily Revision Goals</span>
                  <i data-lucide="calendar-clock" class="ks-sense-col-icon"></i>
                </div>
                <form id="ks-sense-rev-form" class="ks-sense-add-row">
                  <select id="ks-sense-rev-day" class="field ks-sense-day-select">
                    <option value="Mon">Mon</option><option value="Tue">Tue</option><option value="Wed">Wed</option>
                    <option value="Thu">Thu</option><option value="Fri">Fri</option><option value="Sat">Sat</option>
                    <option value="Sun">Sun</option>
                  </select>
                  <input id="ks-sense-rev-input" type="text" class="field" placeholder="e.g. Review kanji deck — 15 min" autocomplete="off" />
                  <button class="primary-button ks-sense-add-btn" type="submit"><i data-lucide="plus"></i></button>
                </form>
                <div id="ks-sense-rev-list" class="ks-sense-list"></div>
                <div class="ks-sense-col-foot"><span id="ks-sense-rev-stats">0 scheduled · 0 cleared</span></div>
              </section>

              {/* COLUMN 3 — Progress Analytics Metrics Logs */}
              <section class="panel kamisensei-panel ks-sense-col" aria-label="Progress Analytics">
                <div class="panel-header-row">
                  <span class="panel-tag">Progress Analytics</span>
                  <i data-lucide="bar-chart-2" class="ks-sense-col-icon"></i>
                </div>
                <div id="ks-sense-metrics" class="ks-sense-metrics"></div>
                <div class="ks-sense-week">
                  <div class="ks-sense-week-title">7-day completion log</div>
                  <div id="ks-sense-week-bars" class="ks-sense-week-bars"></div>
                </div>
              </section>
            </div>
          </div>
        </div>

        {/* ═══ LAYER 2: NOTEBOOK ACTIVE VIEW (3-Panel — hidden by default) ═══ */}
        <div id="ks-notebook-view" class="ks-notebook-view" style="display:none;">
          <div class="kamisensei-container">

            {/* Top Bar Header (with Back Button) */}
            <header class="kamisensei-topbar">
              <div class="kamisensei-brand">
                <button id="ks-back-btn" class="ks-back-btn" type="button" title="Back to Notebooks">
                  <i data-lucide="arrow-left"></i>
                  <span>Notebooks</span>
                </button>
                <div class="ks-topbar-divider"></div>
                <div class="kamisensei-icon-badge" aria-hidden="true"><span>神</span></div>
                <div class="kamisensei-title-group">
                  <h2 id="ks-nb-active-title">KamiSensei</h2>
                  <span class="kamisensei-subtag">J.A.R.V.I.S. // JAPANESE LANGUAGE TUTOR — KAMISENSEI PROTOCOL</span>
                </div>
              </div>

              <div class="kamisensei-top-tools">
                <button id="kamisensei-create-nb" class="kamisensei-pill-btn primary" title="Create Notebook"><i data-lucide="plus"></i><span>Create notebook</span></button>
                <button id="kamisensei-copy-btn" class="kamisensei-tool-btn" title="Copy Study Context"><i data-lucide="copy"></i><span>Copy</span></button>
                <button id="kamisensei-analytics-btn" class="kamisensei-tool-btn" title="Study Analytics"><i data-lucide="bar-chart-2"></i><span>Analytics</span></button>
                <button id="kamisensei-share-btn" class="kamisensei-tool-btn" title="Share Session"><i data-lucide="share-2"></i><span>Share</span></button>
                <button id="kamisensei-settings-btn" class="kamisensei-tool-btn" data-view="settings" title="Settings"><i data-lucide="settings-2"></i><span>Settings</span></button>
                <span class="kamisensei-pro-badge">PRO</span>
                <div class="kamisensei-user-avatar" title="Commander Profile"><span>P</span></div>
              </div>
            </header>

            {/* 3-Panel Holographic Layout (Reference Image Layout) */}
            <div class="kamisensei-workspace-grid">

              {/* PANEL 1: Sources (Left) */}
              <aside class="panel kamisensei-panel sources-panel" aria-label="Study Sources">
                <div class="panel-header-row">
                  <span class="panel-tag">Sources</span>
                  <button class="panel-dock-btn" title="Collapse Panel"><i data-lucide="minimize-2"></i></button>
                </div>

                <button id="kamisensei-add-source-btn" class="add-source-pill" type="button">
                  <i data-lucide="plus"></i>
                  <span>Add sources</span>
                </button>
                <input type="file" id="kamisensei-file-input" accept=".pdf,.txt,.md,.json" multiple style="display: none;" />

                <div id="sources-content-area" class="sources-content-area">
                  <div id="sources-empty-state" class="sources-empty-state">
                    <p>Knowledge base is empty.</p>
                    <button id="sources-empty-add-btn" class="text-link-btn" type="button">[ + Add sources ] to begin.</button>
                    <div class="dropzone-hint" id="sources-dropzone">
                      <i data-lucide="upload-cloud"></i>
                      <span>Drag &amp; drop files here — or add websites, YouTube links &amp; copied text</span>
                    </div>
                  </div>
                  <div id="sources-loading" class="sources-loading" style="display:none;">
                    <span class="sources-loading-dot"></span>
                    <span id="sources-loading-text">Fetching transcript…</span>
                  </div>
                  <div id="sources-file-list" class="sources-file-list" style="display: none;"></div>
                </div>

                {/* Source Viewer — in-panel reader shell (UI preview; deep text/PDF
                    rendering for link + audio sources lands in a later pass) */}
                <div id="ks-source-viewer" class="ks-source-viewer" style="display:none;">
                  <div class="ks-sv-head">
                    <button id="ks-sv-back" class="ks-sv-back" type="button" title="Back to sources"><i data-lucide="arrow-left"></i></button>
                    <span id="ks-sv-title" class="ks-sv-title">Source</span>
                  </div>
                  <button id="ks-sv-guide" class="ks-sv-guide" type="button">
                    <i data-lucide="sparkles"></i><span>Source guide</span><i data-lucide="chevron-down" class="ks-sv-guide-chevron"></i>
                  </button>
                  <div id="ks-sv-guide-body" class="ks-sv-guide-body" style="display:none;">
                    The Source guide will summarize this source — key topics, quotes, and glossary — once deep source processing ships. Chat, artifacts, and Audio Overviews already use this source today.
                  </div>
                  <div id="ks-sv-body" class="ks-sv-body"></div>
                </div>

                <div class="sources-panel-footer">
                  <div class="footer-feedback-group">
                    <button class="icon-feed-btn" title="Helpful" type="button"><i data-lucide="thumbs-up"></i></button>
                    <button class="icon-feed-btn" title="Not helpful" type="button"><i data-lucide="thumbs-down"></i></button>
                  </div>
                  <div class="footer-action-group">
                    <button id="sources-delete-all-btn" class="footer-pill-btn" type="button"><i data-lucide="trash-2"></i><span>Delete</span></button>
                    <button id="sources-import-btn" class="footer-pill-btn import" type="button"><i data-lucide="plus"></i><span>Import</span></button>
                  </div>
                  {/* Holographic Arc Reactor Watermark */}
                  <div class="holographic-arc-reactor" title="Stark Industries Arc Core">
                    <svg viewBox="0 0 100 100" class="arc-svg" aria-hidden="true">
                      <circle cx="50" cy="50" r="44" stroke="#22c7f2" stroke-width="1.8" fill="none" opacity="0.6"/>
                      <circle cx="50" cy="50" r="34" stroke="#8ee8ff" stroke-width="2.5" stroke-dasharray="8 6" fill="none"/>
                      <circle cx="50" cy="50" r="22" stroke="#22c7f2" stroke-width="2" fill="rgba(34, 199, 242, 0.15)"/>
                      <polygon points="50,22 76,66 24,66" stroke="#8ee8ff" stroke-width="1.5" fill="none"/>
                      <circle cx="50" cy="50" r="8" fill="#e5f7fc"/>
                    </svg>
                  </div>
                </div>
              </aside>

              {/* PANEL 2: Chat / Linguistic Console (Center) */}
              <main class="panel kamisensei-panel chat-panel" aria-label="KamiSensei Linguistic Console">
                <div class="panel-header-row">
                  <span class="panel-tag">Chat</span>
                  <div class="chat-header-actions">
                    <button id="kamisensei-clear-chat-btn" class="panel-dock-btn" title="Clear Chat History" type="button"><i data-lucide="eraser"></i></button>
                    <button class="panel-dock-btn" title="Grid Layout" type="button"><i data-lucide="layout-grid"></i></button>
                    <button class="panel-dock-btn" title="More Options" type="button"><i data-lucide="more-vertical"></i></button>
                  </div>
                </div>

                <div class="chat-body-container">
                  {/* Central Holographic Avatar & Welcome */}
                  <div id="kamisensei-welcome-hero" class="kamisensei-welcome-hero">
                    <div class="passive-listening-pill">
                      <span class="pulse-indicator"></span>
                      <span>passive listening active</span>
                    </div>

                    {/* Holographic Wireframe Head / AI Cyber Brain SVG */}
                    <div class="holographic-cyber-face" aria-hidden="true">
                      <svg viewBox="0 0 200 220" class="cyber-face-svg">
                        <circle cx="100" cy="110" r="95" stroke="#153141" stroke-width="1" stroke-dasharray="4 8" fill="none"/>
                        <circle cx="100" cy="110" r="82" stroke="#22c7f2" stroke-width="1" opacity="0.35" fill="none"/>
                        <path d="M 60 70 Q 100 35 140 70 Q 160 100 140 140 Q 100 180 60 140 Q 40 100 60 70 Z" stroke="#22c7f2" stroke-width="1.5" fill="rgba(6, 26, 38, 0.45)"/>
                        <line x1="100" y1="45" x2="100" y2="175" stroke="#8ee8ff" stroke-width="1.2" opacity="0.75"/>
                        <line x1="70" y1="65" x2="130" y2="65" stroke="#22c7f2" stroke-width="1" opacity="0.65"/>
                        <line x1="55" y1="95" x2="145" y2="95" stroke="#8ee8ff" stroke-width="1" opacity="0.75"/>
                        <line x1="60" y1="125" x2="140" y2="125" stroke="#22c7f2" stroke-width="1" opacity="0.65"/>
                        <line x1="75" y1="150" x2="125" y2="150" stroke="#8ee8ff" stroke-width="1" opacity="0.55"/>
                        <polygon points="100,50 80,85 100,95" stroke="#22c7f2" stroke-width="1" fill="none" opacity="0.65"/>
                        <polygon points="100,50 120,85 100,95" stroke="#22c7f2" stroke-width="1" fill="none" opacity="0.65"/>
                        <polygon points="80,85 60,105 80,125" stroke="#8ee8ff" stroke-width="1" fill="none" opacity="0.55"/>
                        <polygon points="120,85 140,105 120,125" stroke="#8ee8ff" stroke-width="1" fill="none" opacity="0.55"/>
                        <polygon points="80,125 100,165 120,125" stroke="#22c7f2" stroke-width="1" fill="none" opacity="0.75"/>
                        <polygon points="100,95 80,125 120,125" stroke="#8ee8ff" stroke-width="1" fill="rgba(34, 199, 242, 0.18)"/>
                        <circle cx="85" cy="105" r="3.5" fill="#e5f7fc"/>
                        <circle cx="115" cy="105" r="3.5" fill="#e5f7fc"/>
                        <circle cx="100" cy="70" r="2.5" fill="#22c7f2"/>
                        <circle cx="100" cy="140" r="2.5" fill="#22c7f2"/>
                      </svg>
                    </div>

                    <div class="welcome-copy">
                      <h3>Welcome to J.A.R.V.I.S. Linguistic Console.</h3>
                      <p class="welcome-sub">Welcome to KamiSensei Protocol, Sir. I am ready to process your sources and speech.</p>
                    </div>

                    {/* Central Statistics / Active Status Updates */}
                    <div class="kamisensei-stats-strip">
                      <div class="stat-badge">
                        <span class="stat-dot connected"></span>
                        <span>Database Status: <strong id="ks-db-status">Checking…</strong></span>
                      </div>
                      <div class="stat-badge">
                        <i data-lucide="book-open"></i>
                        <span>Loaded Materials: <strong id="ks-loaded-count">0 files</strong></span>
                      </div>
                      <div class="stat-badge">
                        <i data-lucide="cpu"></i>
                        <span>AI Model: <strong id="ks-ai-model">Configured provider</strong></span>
                      </div>
                      <div class="stat-badge">
                        <i data-lucide="volume-2"></i>
                        <span>Voice ID: <strong id="ks-voice-id">Configured voice</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Artifact Workspace lives in the right Studio panel now (NotebookLM-style).
                      Center chat stays visible at all times — no blank-view routing. */}
                  <div id="kamisensei-chat-log" class="kamisensei-chat-log" style="display: none;"></div>
                </div>
                <button id="ks-jump-latest" class="ks-jump-latest" type="button" style="display:none;">↓ Jump to latest</button>

                {/* Bottom Prompt Input Area */}
                <div class="chat-input-wrapper">
                  <form id="kamisensei-prompt-form" class="kamisensei-input-box">
                    <button type="button" id="kamisensei-mic-btn" class="chat-tool-btn" title="Voice Input"><i data-lucide="mic"></i></button>
                    <button type="button" id="kamisensei-mute-btn" class="chat-tool-btn ks-mute-btn" title="Stop Assistant Audio" hidden><i data-lucide="volume-x"></i></button>
                    <input id="kamisensei-input" type="text" placeholder="Ask a question or create something" autocomplete="off" />
                    <button type="submit" id="kamisensei-send-btn" class="chat-send-btn" title="Send message"><i data-lucide="send"></i></button>
                  </form>
                  <div class="input-disclaimer">
                    <span>KamiSensei Protocol Active • Stark Industries Linguistic Intelligence</span>
                    <span id="ks-chat-source-scope" class="ks-chat-source-scope">0 indexed sources • all in scope</span>
                  </div>
                </div>
              </main>

              {/* PANEL 3: Studio (Right) — NotebookLM-style resizable artifact arena */}
              <div id="ks-studio-splitter" class="ks-studio-splitter" title="Drag to resize the Studio panel"><span></span></div>
              <aside class="panel kamisensei-panel studio-panel" aria-label="Studio Tools">
                <div class="panel-header-row">
                  <span class="panel-tag">Studio</span>
                  <button class="panel-dock-btn" title="Collapse Panel"><i data-lucide="minimize-2"></i></button>
                </div>

                {/* STATE B — Artifact Viewer: occupies the FULL Studio workspace.
                    Toggled by app.js renderStudio(); the dashboard below is hidden
                    while an artifact is open (NotebookLM-style). */}
                <div id="ks-artifact-workspace" class="ks-artifact-workspace" style={{ display: 'none' }}>
                  <div class="ks-ws-header">
                    <span id="ks-ws-crumb" class="ks-ws-crumb">Studio</span>
                    <span class="ks-ws-sep">›</span>
                    <button id="ks-ws-back" class="ks-back-btn" type="button" title="Back to Studio Dashboard">Back</button>
                    <span id="ks-ws-title" class="ks-ws-title">Artifact</span>
                    <div class="ks-ws-window-controls">
                      <button id="ks-ws-maximize" class="ks-ws-win-btn" type="button" title="Maximize"><i data-lucide="maximize-2" /></button>
                      <button id="ks-ws-menu" class="ks-ws-win-btn" type="button" title="Artifact actions"><i data-lucide="more-vertical" /></button>
                      <button id="ks-ws-close" class="ks-ws-win-btn" type="button" title="Close Artifact"><i data-lucide="x" /></button>
                    </div>
                  </div>
                  <div id="ks-ws-content" class="ks-ws-content" />
                </div>

                {/* STATE A: Studio Dashboard — generation grid, library, canvas, footer */}
                <div id="ks-studio-dashboard" class="ks-studio-dashboard">
                {/* 9-Macro Action Cards Grid */}
                <div class="studio-macro-grid">
                                    <button class="studio-macro-card" data-studio-action="audio_overview" type="button" title="AI Podcast Studio — local Kokoro-82M offline TTS (ElevenLabs purged)">
                    <span class="macro-key">A</span>
                    <span class="macro-label">Audio Overview</span>
                  </button>
                  <button class="studio-macro-card disabled" data-studio-action="slidedeck" type="button" disabled title="Slide Deck — temporarily unavailable">
                    <span class="macro-key">S</span>
                    <span class="macro-label">Slide Deck</span>
                  </button>
                  <button class="studio-macro-card disabled" data-studio-action="video_overview" type="button" disabled title="Video Overview — temporarily unavailable">
                    <span class="macro-key">V</span>
                    <span class="macro-label">Video Overview</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="mind_map" type="button">
                    <span class="macro-key">M</span>
                    <span class="macro-label">Mind Map</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="report" type="button">
                    <span class="macro-key">R</span>
                    <span class="macro-label">Reports</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="flashcard_set" type="button">
                    <span class="macro-key">F</span>
                    <span class="macro-label">Flashcards</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="quiz" type="button">
                    <span class="macro-key">Q</span>
                    <span class="macro-label">Quiz</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="note" type="button">
                    <span class="macro-key">N</span>
                    <span class="macro-label">Notes</span>
                  </button>
                  {/* Infographic is temporarily removed from the grid (reusable
                      backend prompt kept; restore by un-commenting this button) */}
                  {/* <button class="studio-macro-card" data-studio-action="infographic" type="button">
                    <span class="macro-key">I</span>
                    <span class="macro-label">Infographic</span>
                  </button> */}
                  <button class="studio-macro-card" data-studio-action="data_table" type="button">
                    <span class="macro-key">D</span>
                    <span class="macro-label">Data Table</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="study_guide" type="button">
                    <span class="macro-key">S</span>
                    <span class="macro-label">Study Guide</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="briefing_doc" type="button">
                    <span class="macro-key">B</span>
                    <span class="macro-label">Briefing Doc</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="faq" type="button">
                    <span class="macro-key">F</span>
                    <span class="macro-label">FAQ</span>
                  </button>
                  <button class="studio-macro-card" data-studio-action="timeline" type="button">
                    <span class="macro-key">T</span>
                    <span class="macro-label">Timeline</span>
                  </button>
                </div>

                {/* Quick-Launch Macro Action Blocks */}
                <div class="quick-launch-macros">
                  <button class="quick-macro-btn" data-studio-action="audio_overview" type="button" title="Launch KamiSensei AI Podcast Studio (local Kokoro-82M offline TTS)">
                    <i data-lucide="headphones"></i>
                    <span>Generate Audio Overview</span>
                  </button>
                  <button class="quick-macro-btn" data-studio-action="flashcard_set" type="button">
                    <i data-lucide="layers"></i>
                    <span>Generate Dynamic Flashcards</span>
                  </button>
                  <button class="quick-macro-btn" data-studio-action="grammar_logs" type="button" disabled title="Grammar Logs — temporarily unavailable">
                    <i data-lucide="book-marked"></i>
                    <span>Review Grammar Logs</span>
                  </button>
                </div>

                {/* Studio Artifact Library — persisted per-session across reloads */}
                <div id="ks-artifact-library" class="ks-artifact-library" style="display:none;"></div>

                {/* NotebookLM Audio Hub — generated podcast history (scrollable stack) */}
                <div id="ks-audio-hub" class="ks-audio-hub" style="display:none;">
                  <div class="ks-audio-hub-head">
                    <i data-lucide="audio-lines"></i>
                    <span>Audio Overviews</span>
                    <small id="ks-audio-hub-count"></small>
                  </div>
                  <div id="ks-audio-track-list" class="ks-audio-track-list"></div>
                </div>

                {/* Holographic footer timeline player — docked at the Studio baseline */}
                <div id="ks-global-player" class="ks-global-player" style="display:none;">
                  <audio id="ks-global-audio" preload="metadata"></audio>
                  <div class="ks-gp-title-row">
                    <i data-lucide="podcast"></i>
                    <span id="ks-global-track-title">No track loaded</span>
                    <button id="ks-global-speed" class="ks-gp-speed" type="button" title="Playback speed">1.0x</button>
                  </div>
                  <div class="ks-gp-seek-row">
                    <span id="ks-global-cur">0:00</span>
                    <input type="range" id="ks-global-seekbar" class="ks-gp-seekbar w-full h-1 bg-purple-600 rounded-lg appearance-none cursor-pointer" min="0" max="100" step="0.1" value="0" aria-label="Seek position" />
                    <span id="ks-global-dur">0:00</span>
                  </div>
                  <div class="ks-gp-controls">
                    <button id="ks-global-back" class="ks-gp-btn" type="button" title="Skip back 10s"><i data-lucide="rotate-ccw"></i><small>10</small></button>
                    <button id="ks-global-play" class="ks-gp-btn ks-gp-play" type="button" title="Play / Pause"><i data-lucide="play"></i></button>
                    <button id="ks-global-fwd" class="ks-gp-btn" type="button" title="Skip forward 10s"><i data-lucide="rotate-cw"></i><small>10</small></button>
                  </div>
                </div>

                {/* Studio Footer */}
                <div class="studio-panel-footer">
                  <button id="studio-add-note-btn" class="add-note-pill" type="button">
                    <i data-lucide="file-plus"></i>
                    <span>Add note</span>
                  </button>

                  <div class="stark-watermark-group">
                    <div class="stark-star-icon" aria-hidden="true">
                      <svg viewBox="0 0 24 24" width="20" height="20" fill="#22c7f2" opacity="0.75">
                        <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z"/>
                      </svg>
                    </div>
                    <div class="stark-industries-logo">
                      <span>STARK</span>
                      <small>INDUSTRIES</small>
                    </div>
                  </div>
                </div>
                </div>{/* /#ks-studio-dashboard */}
              </aside>

            </div>
          </div>
        </div>

        {/* KamiSensei AI Podcast Studio — NotebookLM-style Configuration Modal */}
        {/* Bottom-docked Audio Mini-Player — global fixed overlay. Summoned by
            clicking a ready Audio Overview artifact in the Studio library. */}
        <div id="ks-mini-player" class="ks-mini-player" style="display:none;">
          <audio id="ks-mini-audio" preload="metadata"></audio>
          <div class="ks-mini-head">
            <i data-lucide="audio-lines"></i>
            <span id="ks-mini-title" class="ks-mini-title">Audio Overview</span>
            <span id="ks-mini-meta" class="ks-mini-meta"></span>
            <button id="ks-mini-menu" class="ks-mini-icon" type="button" title="Options"><i data-lucide="more-vertical"></i></button>
            <button id="ks-mini-close" class="ks-mini-icon" type="button" title="Close player"><i data-lucide="x"></i></button>
          </div>
          <div class="ks-mini-seek-row">
            <span id="ks-mini-cur">0:00</span>
            <input type="range" id="ks-mini-seekbar" class="ks-mini-seekbar" min="0" max="100" step="0.1" value="0" aria-label="Seek position" />
            <span id="ks-mini-dur">0:00</span>
          </div>
          <div class="ks-mini-controls">
            <button id="ks-mini-back" class="ks-mini-btn" type="button" title="Rewind 10s"><i data-lucide="rotate-ccw"></i><small>10</small></button>
            <button id="ks-mini-play" class="ks-mini-btn ks-mini-play" type="button" title="Play / Pause"><i data-lucide="play"></i></button>
            <button id="ks-mini-fwd" class="ks-mini-btn" type="button" title="Fast-forward 10s"><i data-lucide="rotate-cw"></i><small>10</small></button>
            <button id="ks-mini-speed" class="ks-mini-speed" type="button" title="Playback speed">1x</button>
          </div>
        </div>

        {/* KamiSensei Add Sources modal (NotebookLM-style shell). Websites /
            YouTube / Drive / Copied text are UI-first: links and pasted text
            are saved into the notebook's source list for preview, while real
            ingestion (crawler / transcript / Drive OAuth) ships later. */}
        <div id="ks-add-source-modal" class="ks-citation-modal" style="display:none;">
          <div class="ks-asm-card">
            <button id="ks-asm-close" class="ks-citation-close" type="button"><i data-lucide="x"></i></button>
            <div class="ks-asm-head">
              <span id="ks-asm-title" class="ks-asm-title">Add sources</span>
              <span class="ks-asm-sub">Websites, YouTube videos, Drive files, and pasted text land in this notebook's source list.</span>
            </div>

            {/* View: main */}
            <div id="ks-asm-main" class="ks-asm-body" style="display:flex;">
              <div class="ks-asm-search">
                <input id="ks-asm-search-input" class="ks-asm-search-input" type="text" placeholder="Search the web for new sources" autocomplete="off" />
                <div class="ks-asm-search-row">
                  <button class="ks-asm-chip" type="button"><i data-lucide="globe"></i><span>Web</span><i data-lucide="chevron-down"></i></button>
                  <button class="ks-asm-chip" type="button"><i data-lucide="sparkles"></i><span>Fast Research</span><i data-lucide="chevron-down"></i></button>
                  <button id="ks-asm-search-go" class="ks-asm-search-go" type="button" title="Search"><i data-lucide="search"></i></button>
                </div>
                <div id="ks-asm-search-note" class="ks-asm-note" style="display:none;">Web discovery is coming soon — add links directly below; they are saved to this notebook instantly.</div>
              </div>
              <div class="ks-asm-drop">
                <p class="ks-asm-drop-title">or drop your files</p>
                <p class="ks-asm-drop-sub">pdf, images, docs, audio <a href="#" id="ks-asm-more" onClick={(e) => e.preventDefault()}>and more</a></p>
                <div class="ks-asm-actions">
                  <button id="ks-asm-upload" class="ks-asm-btn" type="button"><i data-lucide="upload"></i><span>Upload files</span></button>
                  <button id="ks-asm-websites" class="ks-asm-btn" type="button"><i data-lucide="link-2"></i><span>Websites</span></button>
                  <button id="ks-asm-drive" class="ks-asm-btn" type="button"><i data-lucide="hard-drive"></i><span>Drive</span></button>
                  <button id="ks-asm-paste" class="ks-asm-btn" type="button"><i data-lucide="clipboard-copy"></i><span>Copied text</span></button>
                </div>
                <div class="ks-asm-scan-row">
                  <button id="ks-asm-scan" class="ks-asm-btn subtle" type="button"><i data-lucide="scan-line"></i><span>Upload with Adobe Scan</span></button>
                </div>
              </div>
            </div>

            {/* View: websites / youtube links */}
            <div id="ks-asm-links" class="ks-asm-body" style="display:none;">
              <p class="ks-asm-hint">Paste one or more links — one per line. YouTube videos and web pages are detected automatically and appear in the source list.</p>
              <textarea id="ks-asm-links-input" class="ks-asm-textarea" rows="6" placeholder={'https://youtube.com/watch?v=…\nhttps://example.com/article\nhttps://drive.google.com/file/d/…'}></textarea>
              <div class="ks-asm-view-actions">
                <button id="ks-asm-links-back" class="ks-asm-btn ghost" type="button"><i data-lucide="arrow-left"></i><span>Back</span></button>
                <button id="ks-asm-links-add" class="ks-asm-btn primary" type="button"><i data-lucide="plus"></i><span>Add to sources</span></button>
              </div>
            </div>

            {/* View: copied text */}
            <div id="ks-asm-pasteview" class="ks-asm-body" style="display:none;">
              <p class="ks-asm-hint">Paste notes, transcripts, or any text — it becomes a readable source in this notebook.</p>
              <textarea id="ks-asm-paste-input" class="ks-asm-textarea" rows="8" placeholder="Paste your copied text here…"></textarea>
              <div class="ks-asm-view-actions">
                <button id="ks-asm-paste-back" class="ks-asm-btn ghost" type="button"><i data-lucide="arrow-left"></i><span>Back</span></button>
                <button id="ks-asm-paste-add" class="ks-asm-btn primary" type="button"><i data-lucide="plus"></i><span>Add to sources</span></button>
              </div>
            </div>
          </div>
        </div>

        {/* KamiSensei AI Podcast Studio modal */}
        <div id="ks-podcast-modal" class="ks-citation-modal" style="display:none;">
          <div class="ks-citation-modal-content" style="max-width:520px;width:92%;">
            <button id="ks-podcast-close" class="ks-citation-close" type="button"><i data-lucide="x"></i></button>
            <div class="ks-pod-header" style="display:flex;align-items:center;gap:10px;padding:6px 0 2px;">
              <i data-lucide="podcast" style="width:20px;height:20px;color:#22c7f2;"></i>
              <span style="font-size:18px;font-weight:600;color:#e8f4f8;">Customize Audio Overview</span>
            </div>
            <div class="ks-pod-body" style="display:flex;flex-direction:column;gap:14px;padding:4px 4px 6px;">
              <div>
                <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Format</label>
                <div id="ks-pod-formats" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px;">
                  <button class="ks-pod-format-btn active" data-format="deep_dive" type="button">
                    <span class="ks-pod-fmt-title">Deep Dive</span><small class="ks-pod-fmt-sub">A lively conversation between two hosts, unpacking and connecting topics with vivid examples.</small>
                  </button>
                  <button class="ks-pod-format-btn" data-format="brief" type="button">
                    <span class="ks-pod-fmt-title">Brief</span><small class="ks-pod-fmt-sub">A bite-sized overview to help you grasp the core ideas quickly.</small>
                  </button>
                  <button class="ks-pod-format-btn" data-format="critique" type="button">
                    <span class="ks-pod-fmt-title">Critique</span><small class="ks-pod-fmt-sub">An expert review of your sources, offering constructive feedback.</small>
                  </button>
                  <button class="ks-pod-format-btn" data-format="debate" type="button">
                    <span class="ks-pod-fmt-title">Debate</span><small class="ks-pod-fmt-sub">A thoughtful debate between two hosts, illuminating different perspectives.</small>
                  </button>
                </div>
              </div>
              <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <div style="flex:1;min-width:120px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Language</label>
                  <select id="ks-pod-language" class="field" style="width:100%;margin-top:6px;font-size:13px;">
                    <option value="hinglish" selected>Hinglish (Default)</option>
                    <option value="english">English</option>
                    <option value="hindi">Hindi</option>
                    <option value="japanese">Japanese</option>
                    <option value="trilingual_mix">Trilingual (Mix)</option>
                    <option value="bengali">Bengali</option>
                    <option value="gujarati">Gujarati</option>
                    <option value="kannada">Kannada</option>
                    <option value="malayalam">Malayalam</option>
                    <option value="marathi">Marathi</option>
                    <option value="punjabi">Punjabi</option>
                    <option value="tamil">Tamil</option>
                    <option value="telugu">Telugu</option>
                  </select>
                </div>
                <div style="flex:1;min-width:140px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Length</label>
                  <div id="ks-pod-lengths" style="display:flex;gap:6px;margin-top:6px;">
                    <button class="ks-pod-len-btn" data-len="short" type="button">Short</button>
                    <button class="ks-pod-len-btn active" data-len="default" type="button">Default</button>
                    <button class="ks-pod-len-btn" data-len="long" type="button">Long</button>
                  </div>
                </div>
                <div style="flex:1;min-width:140px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Sources</label>
                  <div style="margin-top:6px;">
                    <div id="ks-pod-sources" style="display:flex;flex-direction:column;gap:4px;max-height:110px;overflow-y:auto;font-size:11px;color:#cde7f2;">Loading sources…</div>
                    <label style="display:flex;align-items:center;gap:6px;margin-top:6px;font-size:11px;color:#8ee8ff;cursor:pointer;">
                      <input type="checkbox" id="ks-pod-all-sources" checked /> Use entire knowledge base
                    </label>
                  </div>
                </div>
              </div>
              <div>
                <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">What should the AI hosts focus on in this episode?</label>
                <div class="ks-pod-focus-wrap" style="position:relative;margin-top:6px;">
                  <textarea id="ks-pod-custom-prompt" class="field" placeholder="e.g. emphasize the は/が pattern, explain kanji mnemonics, critique weak points in source 3…" style="width:100%;height:84px;resize:none;background:#0e1520;border:1px solid #228be8;border-radius:8px;color:#cde7f2;font-size:12px;padding:10px 8px 34px 8px;outline:none;"></textarea>
                  <div class="ks-pod-tips" style="position:absolute;right:6px;bottom:6px;font-size:10px;color:#6ab0f0;text-align:right;max-width:calc(100% - 12px);">
                    <div style="font-weight:600;color:#22c7f2;margin-bottom:2px;">Things to try</div>
                    &#183; Name a specific concept to spotlight<br/>
                    &#183; Ask for a critique of a source<br/>
                    &#183; Request a debate on a grammar pattern
                  </div>
                </div>
              </div>
            </div>
            <div class="ks-pod-footer" style="display:flex;align-items:center;gap:8px;padding:10px 14px 4px;">
              <button id="ks-pod-generate" class="primary-button" type="button" style="flex:1;justify-content:center;">
                <i data-lucide="audio-lines"></i> Generate
              </button>
              <input type="range" id="ks-pod-rate" min="0.6" max="1.4" step="0.05" value="1" style="width:120px;accent-color:#22c7f2;" />
              <small id="ks-pod-rate-val" style="color:#8ee8ff;font-size:11px;width:44px;text-align:right;">1.00x</small>
              <button id="ks-pod-stop" class="text-button" type="button" style="display:none;flex:1;justify-content:center;" aria-label="Stop audio and cancel generation">
                <i data-lucide="square"></i> <span style="color:#f87171;">&#128079; Stop Audio</span>
              </button>
            </div>
            <div id="ks-pod-thinking" style="display:none;align-items:center;gap:8px;color:#8ee8ff;font-size:12px;padding:6px 14px 0;">
              <i data-lucide="loader-2" class="spin"></i> <span>Thinking… local Kokoro-82M is generating dialogue</span>
            </div>
            <div id="ks-pod-status" style="font-size:11px;color:#cde7f2;padding:0 14px 10px;min-height:16px;"></div>
          </div>
        </div>

        {/* KamiSensei Artifact Generation Modal (topic + source scope) */}
        <div id="ks-artifact-modal" class="ks-citation-modal" style="display:none;">
          <div class="ks-citation-modal-content" style="max-width:520px;width:92%;">
            <button id="ks-artifact-close" class="ks-citation-close" type="button"><i data-lucide="x"></i></button>
            <div class="ks-citation-header">
              <i data-lucide="sparkles"></i>
              <span id="ks-artifact-modal-title">Generate Artifact</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:14px;padding:14px 18px;">
              <div>
                <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Topic / Instruction</label>
                <input id="ks-art-topic" type="text" class="field" style="width:100%;margin-top:6px;" placeholder="What should this artifact cover?" />
              </div>
              <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <div style="flex:1;min-width:80px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Count</label>
                  <input id="ks-art-count" type="number" min="1" max="150" value="12" class="field" style="width:100%;margin-top:6px;" />
                </div>
                <div style="flex:1;min-width:100px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Depth</label>
                  <select id="ks-art-depth" class="field" style="width:100%;margin-top:6px;">
                    <option value="">Default</option>
                    <option value="brief">Brief</option>
                    <option value="detailed">Detailed</option>
                    <option value="complete">Complete</option>
                  </select>
                </div>
                <div style="flex:1;min-width:100px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Difficulty</label>
                  <select id="ks-art-difficulty" class="field" style="width:100%;margin-top:6px;">
                    <option value="">Default</option>
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard</option>
                  </select>
                </div>
                <div style="flex:1;min-width:100px;">
                  <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Language</label>
                  <select id="ks-art-language" class="field" style="width:100%;margin-top:6px;">
                    <option value="">Default</option>
                    <option value="english">English</option>
                    <option value="hinglish">Hinglish</option>
                    <option value="japanese">Japanese</option>
                  </select>
                </div>
              </div>
              <div>
                <label style="font-size:10px;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;">Source Scope <small style="text-transform:none;opacity:.7;">(optional — leave all unchecked to search every indexed source)</small></label>
                <div id="ks-art-sources" style="display:flex;flex-direction:column;gap:4px;max-height:120px;overflow-y:auto;margin-top:6px;font-size:11px;color:#cde7f2;"></div>
              </div>
              <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:4px;">
                <button id="ks-art-cancel" class="fc-ctrl-btn" type="button">Cancel</button>
                <button id="ks-art-generate" class="primary-button" type="button" style="justify-content:center;">
                  <i data-lucide="wand-2"></i> Generate
                </button>
              </div>
              <div id="ks-art-error" style="font-size:11px;color:#ff8a94;min-height:0;"></div>
            </div>
          </div>
        </div>

        {/* KamiSensei Citation Popover — shows the ACTUAL retrieved chunk */}
        <div id="ks-citation-popover" class="ks-citation-modal" style="display:none;">
          <div class="ks-citation-modal-content" style="max-width:560px;width:92%;">
            <button id="ks-citation-close" class="ks-citation-close" type="button"><i data-lucide="x"></i></button>
            <div class="ks-citation-header">
              <i data-lucide="book-open-check"></i>
              <span>Source Citation</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px;padding:14px 18px;">
              <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
                <span id="ks-cite-source" style="font:600 12px Rajdhani;color:#dff6ff;"></span>
                <span id="ks-cite-page" style="font:600 10px Rajdhani;color:#8ee8ff;text-transform:uppercase;letter-spacing:1px;"></span>
              </div>
              <div id="ks-cite-text" style="font:400 12px/1.6 Rajdhani;color:#b9d6e2;background:rgba(8,27,38,.6);border:1px solid #16455b;border-radius:8px;padding:10px 12px;max-height:220px;overflow-y:auto;"></div>
            </div>
          </div>
        </div>

      </section>

      <section class="view" data-view-panel="voice">
        <header class="view-heading"><div><span class="eyebrow">VOICE COMMAND</span><h1>Natural voice control</h1></div><button id="voice-toggle" class="primary-button"><i data-lucide="mic"></i> Start listening</button></header>
        <div class="feature-grid"><article class="panel feature-main"><div class="large-voice"><i data-lucide="audio-waveform"></i></div><span id="voice-transcript">Your transcript will appear here.</span><p>English, Hindi, Hinglish, Japanese, and mixed-language speech are supported. Select Browser STT for low latency or Groq Whisper for stronger multilingual recognition.</p></article><article class="panel"><span class="panel-title">EXAMPLE COMMANDS</span><div class="example-list"><button data-command="open youtube and search lo-fi music">Open YouTube and search lo-fi music</button><button data-command="search the web for weather in Delhi">Search weather in Delhi</button><button data-command="open gmail">Open Gmail</button><button data-command="what can you do">What can you do?</button></div></article></div>
      </section>

      <section class="view" data-view-panel="web">
        <header class="view-heading">
          <div><span class="eyebrow">WEB INTELLIGENCE</span><h1>Deep Research Console</h1></div>
          <div class="rc-head-actions">
            <div class="rc-tiers" role="group" aria-label="Research depth">
              <button type="button" class="rc-tier" data-tier="search" title="1 query, ~8 pages read">SEARCH</button>
              <button type="button" class="rc-tier" data-tier="deep" title="4 query facets, ~24 pages read">DEEP</button>
              <button type="button" class="rc-tier" data-tier="exhaustive" title="9 query facets, ~60 pages read">EXHAUSTIVE</button>
              <button type="button" class="rc-tier" data-tier="sweep" disabled title="Not built yet: needs the resumable run manifest">SWEEP — not built</button>
            </div>
            <span class="connection-chip" id="rc-provider">research engine: checking…</span>
          </div>
        </header>

        <div class="rc-layout">
          <aside class="panel rc-col">
            <span class="panel-title">SOURCES</span>
            <div class="rc-list" id="rc-sources"><p class="panel-note">No run yet — say “research &lt;topic&gt;” or type below.</p></div>
            <span class="panel-title rc-gap" id="rc-providers-title" hidden>PROVIDERS USED</span>
            <div class="rc-list" id="rc-providers"></div>
            <span class="panel-title rc-gap">LOCAL DOCS</span>
            <div class="rc-list" id="rc-local"><p class="panel-note">Not queried by this run.</p></div>
          </aside>

          <main class="panel rc-col rc-main">
            <div class="rc-ans-head">
              <span class="panel-title">ANSWER</span>
              <span class="rc-confidence" id="rc-confidence" title="Distinct hosts this run actually read — not a model opinion">HOSTS —</span>
            </div>
            <div class="rc-answer" id="rc-answer"><p class="panel-note">Nothing researched yet in this session.</p></div>
            <span class="panel-title rc-gap" id="rc-cited-title" hidden>CITED SOURCES</span>
            <div class="rc-cards" id="rc-cited"></div>
            <span class="panel-title rc-gap">EXPORT THE RESEARCH</span>
            <div class="rc-export" id="rc-export">
              <button type="button" class="rc-x" data-command="export the last research as markdown">MD</button>
              <button type="button" class="rc-x" data-command="export the last research as word document">DOCX</button>
              <button type="button" class="rc-x" data-command="export the last research as pdf">PDF</button>
              <button type="button" class="rc-x" data-command="export the last research as pptx slides">PPTX</button>
              <span class="rc-x-status" id="rc-export-status">needs a finished run</span>
            </div>
            <span class="panel-title rc-gap" id="rc-follow-title" hidden>FOLLOW UP</span>
            <div class="rc-follow" id="rc-follow"></div>
            <form id="web-search-form" class="rc-composer">
              <i data-lucide="search"></i>
              <input id="web-search-input" class="rc-input" placeholder="Ask JARVIS to research something…" autocomplete="off"/>
              <div class="rc-langs" id="rc-langs" role="group" aria-label="Output language">
                <button type="button" class="rc-lang active" data-lang="hinglish" title="Report in Hinglish">HINGLISH</button>
                <button type="button" class="rc-lang" data-lang="english" title="Report in English">ENGLISH</button>
                <button type="button" class="rc-lang" data-lang="japanese" title="レポートは日本語で">日本語</button>
              </div>
              <button type="submit" class="primary-button">Search</button>
              <button type="button" id="rc-deep-btn" class="primary-button rc-deep-btn">Deep research</button>
            </form>
          </main>

          <aside class="rc-col rc-right">
            <div class="panel">
              <div class="rc-filter-head"><span class="panel-title">EVIDENCE LEDGER</span>
                <div class="rc-filters" id="rc-filters" role="group" aria-label="Filter evidence">
                  <button type="button" class="rc-filter active" data-filter="ALL">ALL</button>
                  <button type="button" class="rc-filter" data-filter="READ">READ</button>
                  <button type="button" class="rc-filter" data-filter="FAIL">FAILED</button>
                </div>
              </div>
              <div class="rc-list" id="rc-evidence"><p class="panel-note">No source fetched yet.</p></div>
            </div>
            <div class="panel">
              <span class="panel-title">RUN RAIL</span>
              <div class="rc-list" id="rc-rail"><p class="panel-note">No agent steps yet.</p></div>
            </div>
          </aside>
        </div>

        <div class="rc-verified" id="rc-verified">
          <strong>NOT RUN YET</strong><span class="rc-sep">·</span>nothing has been verified on this machine
        </div>
      </section>

      <section id="modules-view" class="view" data-view-panel="modules">
        <header class="view-heading">
          <div><span class="eyebrow">JARVIS CAPABILITY MATRIX</span><h1>Modules &amp; Upgrades</h1></div>
          <div class="modules-head-actions">
            <span class="connection-chip" id="modules-chip" data-modules-chip>checking…</span>
            <button type="button" class="text-button" id="modules-refresh">Re-probe</button>
          </div>
        </header>
        <p class="modules-note">Every card below is probed against the live subsystems: the real tool registry, MCP connectors, permission engine, on-device models and installed binaries. <strong>LIVE</strong> works now, <strong>READY</strong> works once you supply the named precondition, and <strong>BLOCKED</strong> states exactly what is missing. The roadmap phase is metadata, not a claim.</p>
        <div class="modules-filters" role="group" aria-label="Filter by state">
          <button type="button" class="chip-filter active" data-modules-filter="ALL">All</button>
          <button type="button" class="chip-filter" data-modules-filter="LIVE">Live</button>
          <button type="button" class="chip-filter" data-modules-filter="READY">Ready</button>
          <button type="button" class="chip-filter" data-modules-filter="BLOCKED">Blocked</button>
        </div>
        <div class="module-upgrade-grid" id="modules-grid" data-modules-grid>
          <p class="modules-empty">Probing live capabilities…</p>
        </div>
      </section>

      {/* Skill Library: the archive HUD (React bundle) is a guest inside this
          container - it mounts on first open and never touches the sidebar,
          the topbar or the command path. */}
      <section class="view" data-view-panel="library">
        <div id="library-root" class="library-root">
          <p class="library-loading" id="library-loading">Opening the archive…</p>
        </div>
      </section>

      <section class="view" data-view-panel="vision">
        <header class="view-heading"><div><span class="eyebrow">VISION SYSTEM</span><h1>Camera and screen intelligence</h1></div><button id="camera-toggle" class="primary-button"><i data-lucide="camera"></i> Start camera</button></header>
        <div class="feature-grid"><article class="panel camera-panel" data-gesture-panel><video id="camera-feed" class="camera-feed" autoplay muted playsinline></video><canvas id="gesture-canvas" class="gesture-canvas" aria-label="Hand landmark overlay"></canvas><div id="camera-placeholder"><i data-lucide="scan-face"></i><strong>Camera is off</strong><span>Video stays on this device. Start camera for the two-hand gesture HUD.</span></div><div class="camera-hud"><span class="gesture-feedback"></span><span class="gesture-status">Camera off</span></div></article><article class="panel"><span class="panel-title">VISION TOOLS</span><div class="tool-list"><button data-command="look at my screen"><i data-lucide="monitor-dot"></i><span><strong>Analyze screen</strong><small>Requires local bridge</small></span></button><button id="analyze-camera" data-command="analyze what you can see through the camera"><i data-lucide="scan-text"></i><span><strong>Analyze camera</strong><small>Multilingual visual Q&amp;A</small></span></button><button id="gesture-toggle" class="gesture-toggle"><i data-lucide="hand"></i><span><strong>Start hand tracking</strong><small id="gesture-detection-label" class="gesture-status">Camera + MediaPipe landmarks</small></span></button></div></article></div>
        <article class="panel perception-panel" id="perception-panel" data-perception-panel>
          <div class="perception-head"><span class="panel-title">ADVANCED PERCEPTION</span><span class="perception-badge" id="perception-source">local</span><button type="button" class="text-button" id="perception-refresh">Refresh</button></div>
          <div class="perception-grid">
            <section class="perception-card" data-perception="objects"><h4>Object Recognition</h4><p class="perception-model" data-perception-model="objects">model: checking…</p><p class="perception-state" data-perception-state="objects">not run yet</p><p class="perception-detail" data-perception-detail="objects">—</p></section>
            <section class="perception-card" data-perception="faces"><h4>Face Detection</h4><p class="perception-model" data-perception-model="faces">model: checking…</p><p class="perception-state" data-perception-state="faces">not run yet</p><p class="perception-detail" data-perception-detail="faces">—</p></section>
            <section class="perception-card" data-perception="attention"><h4>Attention &amp; Engagement</h4><p class="perception-model" data-perception-model="attention">observable signals only</p><p class="perception-state" data-perception-state="attention">not run yet</p><p class="perception-detail" data-perception-detail="attention">—</p></section>
          </div>
          <p class="perception-note">Detection only — no face embeddings, no identity matching, no biometric database. Frames are processed on this device and are not uploaded.</p>
        </article>
      </section>

      <section class="view gesture-view" data-view-panel="gesture">
        <header class="view-heading gesture-heading">
          <div>
            <span class="eyebrow">GESTURE CONTROL</span>
            <h1>Hands-free interaction</h1>
            <p class="gesture-heading-note">Two hands, one camera, one MediaPipe tracker. Every number below is measured live; no AI call runs inside the control loop.</p>
          </div>
          <div class="gesture-heading-actions">
            <span id="gesture-session" class="gesture-session-chip" data-state="off">OFF</span>
            <button id="gesture-pause" class="secondary-button" type="button"><i data-lucide="pause"></i> Pause controls</button>
            <button id="gesture-estop" class="danger-button" type="button"><i data-lucide="octagon"></i> Emergency stop</button>
          </div>
        </header>

        <p id="gesture-error" class="gesture-error" role="alert" hidden></p>
        <p id="gesture-permission" class="gesture-permission">Camera: off | MediaPipe Hands: loading | Windows bridge: checking | UI Automation: not checked</p>

        <div class="gesture-console">
          <article class="panel gesture-preview-card camera-panel camera-mirror" data-gesture-panel>
            <video class="camera-feed" autoplay muted playsinline></video>
            <canvas class="gesture-canvas" aria-label="Hand landmark overlay"></canvas>
            <div class="camera-placeholder"><i data-lucide="scan-face"></i><strong>Camera is off</strong><span>Start the camera, then hand tracking. Video never leaves this device.</span></div>
            <div class="camera-hud">
              <span class="gesture-feedback"></span>
              <span class="gesture-status">Camera off</span>
            </div>
            <div id="gesture-pause-overlay" class="gesture-pause-overlay" hidden>
              <i data-lucide="pause-octagon"></i>
              <strong id="gesture-pause-text">GESTURE CONTROL PAUSED</strong>
              <span>Pointer and clicks are stopped and any held mouse button was released. Hold both palms up to resume, or press Pause controls. F8 is the emergency stop.</span>
            </div>
            <div class="gesture-preview-actions">
              <button id="gesture-camera-power" class="primary-button" type="button"><i data-lucide="camera"></i> Start camera</button>
              <button class="gesture-toggle primary-button" type="button"><i data-lucide="hand"></i><span><strong>Start hand tracking</strong></span></button>
            </div>
          </article>

          <article class="panel gesture-readout-card">
            <header><span class="panel-title">LIVE STATE</span><span id="gesture-state" class="gesture-state-value">CAMERA OFF</span></header>
            <dl class="gesture-readout">
              <div><dt>Recognised</dt><dd id="gesture-recognized">None</dd></div>
              <div><dt>Confidence</dt><dd id="gesture-confidence">confidence --</dd></div>
              <div><dt>Closest match</dt><dd id="gesture-candidate">pose is unambiguous</dd></div>
              <div><dt>Movement</dt><dd id="gesture-motion">movement not measured</dd></div>
              <div><dt>Last action</dt><dd id="gesture-action" data-state="idle">No action yet</dd></div>
              <div><dt>Real cursor</dt><dd id="gesture-cursor-pos">cursor not read yet</dd></div>
              <div><dt>Windows input</dt><dd id="gesture-bridge" data-state="offline">checking</dd></div>
              <div><dt>Target</dt><dd id="gesture-target">No target under pointer</dd></div>
              <div><dt>Active app</dt><dd id="gesture-app">Foreground app unavailable</dd></div>
              <div><dt>Mode</dt><dd id="gesture-mode">balanced mode | pointer right</dd></div>
            </dl>
            <div class="gesture-diagnostics">
              <div><span>Measured FPS</span><strong id="gesture-fps">--</strong></div>
              <div><span>Inference</span><strong id="gesture-inference">--</strong></div>
              <div><span>Capture</span><strong id="gesture-capture-ms">--</strong></div>
              <div><span>Recognition</span><strong id="gesture-recognition-ms">--</strong></div>
              <div><span>Move: frame to real cursor</span><strong id="gesture-move-latency">--</strong></div>
              <div><span>Move: bridge round trip</span><strong id="gesture-move-rtt">--</strong></div>
              <div><span>Action dispatch</span><strong id="gesture-dispatch-ms">--</strong></div>
              <div><span>Capture to action</span><strong id="gesture-latency">--</strong></div>
              <div><span>Actions / failures</span><strong><span id="gesture-actions">0</span> / <span id="gesture-failures">0</span></strong></div>
              <div><span>Dropped frames</span><strong id="gesture-dropped">0</strong></div>
            </div>
            <p class="gesture-note">Every number is measured in this session, never estimated. <em>Capture</em> is frame submission to tracker result, <em>inference</em> and the tracker's own FPS come from MediaPipe, <em>recognition</em> is pose classification for the hands in that frame, <em>move</em> is the hand-to-real-cursor path (and the bridge round trip inside it), and <em>capture to action</em> covers a click, drag, scroll or window action end to end. A dash means nothing has been measured yet. No AI call runs anywhere in this loop.</p>
          </article>

          <article class="panel gesture-settings-card">
            <header><span class="panel-title">PROFILE &amp; INPUT</span></header>
            <label class="gesture-field">Mode
              <select id="gesture-profile" class="field">
                <option value="precision">Precision</option>
                <option value="balanced">Balanced</option>
                <option value="fast">Fast navigation</option>
                <option value="custom">Custom</option>
              </select>
            </label>
            <label class="gesture-field">Pointer hand
              <select id="gesture-pointer-hand" class="field">
                <option value="right">Right hand</option>
                <option value="left">Left hand</option>
                <option value="both">Either / both</option>
              </select>
            </label>
            <label class="gesture-field">Camera
              <select id="gesture-camera" class="field"><option value="">Default camera</option></select>
            </label>
            <p id="gesture-profile-note" class="gesture-hint">Default balance of reach, smoothing and click stability.</p>
            <p class="gesture-note">The secondary hand keeps the JARVIS pointer: index moves, pinch selects a JARVIS control, an open palm returns to the dashboard.</p>
          </article>

          <article class="panel gesture-tuning-card">
            <header><span class="panel-title">TUNING</span></header>
            <label class="gesture-slider"><span>Pointer sensitivity<small>How far the cursor travels across the screen.</small></span><input id="gesture-sensitivity" type="range" min="0.6" max="2.4" step="0.05" /></label>
            <label class="gesture-slider"><span>Smoothing<small>Higher is steadier but lags behind fast movement.</small></span><input id="gesture-smoothing" type="range" min="0" max="0.9" step="0.02" /></label>
            <label class="gesture-slider"><span>Deadzone<small>Ignore sub-pixel tremor below this fraction of the view.</small></span><input id="gesture-deadzone" type="range" min="0" max="0.03" step="0.001" /></label>
            <label class="gesture-slider"><span>Minimum hand confidence<small>Frames below this are ignored, not guessed.</small></span><input id="gesture-confidence-range" type="range" min="0.35" max="0.9" step="0.01" /></label>
            <label class="gesture-slider"><span>Pinch threshold<small>How close the thumb and index tips must get before a pinch starts. Lower is stricter; the release threshold follows automatically.</small></span><input id="gesture-pinch" type="range" min="0.12" max="0.5" step="0.01" /></label>
            <label class="gesture-slider"><span>Pinch hold before drag<small>A pinch held longer than this becomes a drag instead of a click.</small></span><input id="gesture-drag-hold" type="range" min="200" max="900" step="20" /></label>
            <label class="gesture-slider"><span>Two-hand zoom gain<small>How aggressively pinching both hands scales the active view.</small></span><input id="gesture-zoom" type="range" min="0.5" max="2" step="0.05" /></label>
            <p class="gesture-note">The hand is mapped across the JARVIS window and that window is placed on the real desktop through the bridge's own coordinate space, so the preview dot and the Windows cursor stay the same point. Maximize JARVIS for full-desktop reach.</p>
          </article>

          <article class="panel gesture-calibration-card">
            <header><span class="panel-title">RANGE CALIBRATION</span><span id="gesture-calib-status" class="gesture-hint">Not calibrated - uses sensitivity mapping</span></header>
            <p class="gesture-note">Calibration maps the area your hand actually covers to the full screen instead of guessing from a fixed sensitivity. Move the pointer hand across the control area for four seconds.</p>
            <div class="gesture-card-actions">
              <button id="gesture-calibrate" class="primary-button" type="button"><i data-lucide="crosshair"></i> Calibrate 4 s</button>
              <button id="gesture-calib-reset" class="text-button" type="button">Reset calibration</button>
            </div>
          </article>

          <article class="panel gesture-ui-card">
            <header><span class="panel-title">SEMANTIC UI AUTOMATION</span><span id="gesture-ui-status" class="gesture-hint">UNAVAILABLE - not checked</span></header>
            <label class="switch-row"><span><strong>Peace sign activates the control under the pointer</strong><small>Uses Windows UI Automation through the local bridge. Dialogs, password fields and destructive labels are refused.</small></span><input id="gesture-semantic" type="checkbox" /></label>
            <label class="switch-row"><span><strong>Refresh the target readout on pinch</strong><small>Reads the JARVIS control under the pointer. It does not invoke it.</small></span><input id="gesture-semantic-clicks" type="checkbox" /></label>
            <ul id="gesture-ui-elements" class="gesture-ui-list"><li class="gesture-ui-empty">Refresh to read the foreground window accessible controls.</li></ul>
            <button id="gesture-ui-refresh" class="text-button" type="button">Refresh accessible controls</button>
          </article>

          <article class="panel gesture-windows-card">
            <header><span class="panel-title">WINDOW CONTROL</span><span id="gesture-window-status" class="gesture-hint">not checked</span></header>
            <p class="gesture-note">Real top-level windows, read and acted on through Windows UI Automation by handle. Nothing here is simulated: if a window cannot be resolved, that is what the card says. Close, terminate and text entry are deliberately not exposed.</p>
            <ul id="gesture-windows" class="gesture-window-list"><li class="gesture-ui-empty">Refresh to list the windows UI Automation can reach.</li></ul>
            <div class="gesture-card-actions">
              <button id="gesture-windows-refresh" class="text-button" type="button">Refresh windows</button>
            </div>
          </article>

          <article class="panel gesture-mappings-card">
            <header><span class="panel-title">CUSTOM MAPPINGS</span><span class="gesture-hint">A pose or a short gesture sequence</span></header>
            <div class="gesture-mapping-form">
              <input id="gesture-mapping-name" class="field" placeholder="Name, e.g. my mute pose" maxlength="40" />
              <select id="gesture-mapping-action" class="field" aria-label="Action for this gesture"></select>
            </div>
            <div class="gesture-card-actions">
              <button id="gesture-record-pose" class="primary-button" type="button">Record pose (1.6 s)</button>
              <button id="gesture-record-seq" class="primary-button" type="button">Record sequence (4.6 s)</button>
              <button id="gesture-map-last" class="text-button" type="button">Map last ambiguous pose</button>
            </div>
            <p class="gesture-note">A pose is stored as normalized landmarks, so it is independent of hand size and screen position. A sequence stores the distinct gesture labels it saw. An ambiguous pose is never executed - it is reported and can be mapped explicitly.</p>
            <ul id="gesture-mappings" class="gesture-mapping-list"></ul>
          </article>

          <article class="panel gesture-reference-card">
            <header><span class="panel-title">WHAT EACH GESTURE DOES</span><span class="gesture-hint">Deterministic and local</span></header>
            <ul class="gesture-reference">
              <li><strong>Pointer hand index</strong><span>moves the real Windows cursor</span></li>
              <li><strong>Thumb + index pinch, released quickly</strong><span>left click at the pointer</span></li>
              <li><strong>Thumb + index pinch, held</strong><span>starts a drag; releasing the pinch drops it</span></li>
              <li><strong>Thumb + middle pinch</strong><span>right click on release</span></li>
              <li><strong>Thumb + ring pinch</strong><span>double click on release</span></li>
              <li><strong>Fist, moved up or down</strong><span>scrolls the window under the pointer with the real mouse wheel</span></li>
              <li><strong>Open palm</strong><span>pauses the pointer until the palm closes</span></li>
              <li><strong>Peace, held</strong><span>activates the control under the pointer through UI Automation</span></li>
              <li><strong>Both index fingers</strong><span>apart / together scales the active view</span></li>
              <li><strong>Both pinches</strong><span>zooms the active view</span></li>
              <li><strong>Both palms</strong><span>swipe left / right for sections, move up / down to scroll</span></li>
              <li><strong>Both fists</strong><span>pauses every gesture action; both palms up resumes</span></li>
              <li><strong>F8</strong><span>emergency stop from anywhere in the dashboard</span></li>
            </ul>
            <p class="gesture-note gesture-safety-note"><i data-lucide="shield-check"></i> No gesture can shut down, restart, delete, send, pay or confirm anything. Those actions stay behind the existing voice confirmation flow, and destructive or password controls are refused by both the DOM guard and UI Automation.</p>
          </article>

          <article class="panel gesture-limits-card">
            <header><span class="panel-title">LIMITS &amp; FALLBACKS</span></header>
            <ul class="gesture-limits">
              <li><strong>MediaPipe Hands</strong><span>loads from jsDelivr. Without that connection the tracker cannot start; nothing is simulated.</span></li>
              <li><strong>UI Automation</strong><span>works only for applications that expose an accessibility tree. When a control cannot be resolved, JARVIS says so instead of clicking blindly.</span></li>
              <li><strong>Windows that refuse control</strong><span>games, elevated processes running as another user, and apps that draw their own UI without an accessibility tree cannot be reached semantically. The pointer still moves and clicks there through the real Windows mouse, and the card reports the refusal instead of pretending.</span></li>
              <li><strong>No cloud AI in the loop</strong><span>coordinates, clicks, drags, scrolls and recognition are local and deterministic. The assistant can explain or configure gestures, but it never sits between the hand and the cursor.</span></li>
              <li><strong>Confidence</strong><span>low-confidence frames are dropped. A hand that leaves the frame stops the action and releases any drag.</span></li>
              <li><strong>Camera</strong><span>exactly one stream is shared with the Vision view and the floating HUD. Starting a different camera stops and restarts that one stream.</span></li>
            </ul>
          </article>
        </div>
      </section>
      <section class="view" data-view-panel="system"><header class="view-heading"><div><span class="eyebrow">SYSTEM & FILES</span><h1>Windows control center</h1></div><span class="connection-chip offline">Bridge required</span></header><div class="module-grid" id="system-grid"></div></section>
      <section class="view" data-view-panel="productivity"><header class="view-heading"><div><span class="eyebrow">PRODUCTIVITY</span><h1>Notes and reminders</h1></div></header><div class="feature-grid"><article class="panel"><span class="panel-title">QUICK NOTE</span><textarea id="note-input" class="field-area" placeholder="Write a note..."></textarea><button id="save-note" class="primary-button">Save note</button><div id="notes-list" class="saved-list"></div></article><article class="panel"><span class="panel-title">REMINDER</span><input id="reminder-text" class="field" placeholder="Reminder details"/><input id="reminder-time" class="field" type="datetime-local"/><button id="save-reminder" class="primary-button">Set reminder</button><div id="reminders-list" class="saved-list"></div></article></div></section>
      <section class="view" data-view-panel="memory"><header class="view-heading"><div><span class="eyebrow">MEMORY CORE</span><h1>Context and local memory</h1></div><button id="clear-memory" class="danger-button">Clear conversation memory</button></header><div class="feature-grid"><article class="panel"><span class="panel-title">REMEMBER SOMETHING</span><textarea id="memory-input" class="field-area" placeholder="Example: I prefer concise Hinglish answers."></textarea><button id="save-memory" class="primary-button">Remember</button></article><article class="panel"><span class="panel-title">SAVED MEMORIES</span><div id="memory-list" class="saved-list"></div></article></div></section>
      <section class="view" data-view-panel="cowork">
        <header class="view-heading">
          <div class="cowork-heading-lockup"><span class="cowork-heading-icon"><i data-lucide="users"></i></span><div class="cowork-heading-copy"><span class="eyebrow">CO-WORK</span><h1>Agent task workspace</h1><p>Your AI agent workspace. Plan, execute, and get results.</p></div></div>
          <div class="cowork-heading-actions">
            {/* The global topbar is not painted on this view (see the CO-WORK
                FULL-BLEED block in style.css), so the controls that used to
                live only there are mirrored here. data-float-hud and
                data-view are already bound generically by app.js; the mic is
                bound explicitly so the page still shows real voice state. */}
            <div class="cowork-heading-controls">
              <button type="button" class="cowork-icon-btn" id="cowork-mic" aria-label="Start voice command" title="Start voice command"><i data-lucide="mic"></i></button>
              <button type="button" class="cowork-icon-btn" data-float-hud aria-label="Show floating JARVIS HUD" title="Show floating JARVIS HUD"><i data-lucide="sparkles"></i></button>
              <button type="button" class="cowork-icon-btn" data-view="settings" aria-label="Settings" title="Settings"><i data-lucide="settings"></i></button>
            </div>
            <button type="button" class="primary-button cowork-new-task" id="cowork-new-task"><i data-lucide="plus"></i>New task</button>
            <span class="connection-chip" id="cowork-power-lock">Power lock: checking…</span>
            <button type="button" class="text-button" id="cowork-rail-toggle" aria-expanded="true">Hide rail</button>
          </div>
        </header>
        <div class="cowork-workspace" id="cowork-workspace">
          <nav class="cowork-nav" id="cowork-tabs" aria-label="Workspace sections">
            <button type="button" class="cowork-tab active" data-cowork-tab="chat"><i data-lucide="message-square"></i>Chat</button>
            <button type="button" class="cowork-tab" data-cowork-tab="files"><i data-lucide="folder"></i>Files</button>
            <button type="button" class="cowork-tab" data-cowork-tab="browser"><i data-lucide="globe-2"></i>Browser</button>
            <button type="button" class="cowork-tab" data-cowork-tab="terminal"><i data-lucide="terminal"></i>Terminal</button>
            <button type="button" class="cowork-tab" data-cowork-tab="artifacts"><i data-lucide="package"></i>Artifacts</button>
            <button type="button" class="cowork-tab" data-cowork-tab="agents"><i data-lucide="users"></i>Agents</button>
<button type="button" class="cowork-tab" data-cowork-tab="extensions"><i data-lucide="puzzle"></i>Extensions</button>
          </nav>
          <div class="cowork-center panel">
            <div class="cowork-task-header" id="cowork-task-header">
              <div class="cowork-task-title-row">
                <h2 id="cowork-task-title">No active task</h2>
                <span class="cowork-state-chip" id="cowork-task-state" data-state="idle">idle</span>
              </div>
              <div class="cowork-task-meta">
                <span id="cowork-task-agent">Agent: —</span>
                <span id="cowork-task-model">Model: auto chain</span>
                <span id="cowork-task-steps-count">Steps: 0/0</span>
                <span id="cowork-task-time">Started: —</span>
              </div>
              <p class="cowork-task-request" id="cowork-task-request" hidden></p>
            </div>
            <div class="cowork-panels" id="cowork-panels">
              <div class="cowork-panel active" data-cowork-panel="chat">
                <div class="cowork-activity" id="cowork-activity" aria-live="polite"><span class="panel-note">Waiting for core state…</span></div>
                <div class="cowork-plan" id="cowork-task"><span class="panel-note">Waiting for core state…</span></div>
                <div class="cowork-confirm" id="cowork-confirm" hidden>
                  <span id="cowork-confirm-text">Permission required.</span>
                  <button type="button" class="primary-button" id="cowork-approve">Approve</button>
                  <button type="button" class="text-button" id="cowork-deny">Deny</button>
                </div>
              </div>
              <div class="cowork-panel" data-cowork-panel="files">
                <div class="cowork-files-bar">
                  <input id="cowork-files-input" class="field" value="." aria-label="Repo path"/>
                  <button type="button" class="primary-button" id="cowork-files-open">Open</button>
                  <span class="panel-note">Read-only, repo sandbox — secrets are refused.</span>
                </div>
                <div class="cowork-files-list" id="cowork-files"><span class="panel-note">Loading…</span></div>
                <pre class="cowork-file-preview" id="cowork-file-preview" hidden></pre>
              </div>
              <div class="cowork-panel" data-cowork-panel="browser">
                <div id="cowork-browser" class="saved-list"><span class="panel-note">Waiting for core state…</span></div>
              </div>
              <div class="cowork-panel" data-cowork-panel="terminal">
                <div id="cowork-terminal" class="saved-list"><span class="panel-note">Waiting for core state…</span></div>
              </div>
              <div class="cowork-panel" data-cowork-panel="artifacts">
                <div id="cowork-artifacts-full" class="saved-list"><span class="panel-note">Waiting for core state…</span></div>
              </div>
              <div class="cowork-panel" data-cowork-panel="agents">
                {/* ── n8n workspace ────────────────────────────────────────────
                    This panel is now the REAL n8n editor, not a lookalike.

                    n8n is a separate Node application (npm i -g n8n, managed by
                    PM2 as `jarvis-n8n`, loopback:5678). It owns its own SQLite
                    database, workflow engine and Vue canvas. Nothing here
                    reimplements it - the iframe below loads n8n's own UI, so
                    every node, credential and execution is the genuine article.

                    The describe-box above it is the JARVIS-side convenience:
                    type what you want in plain English and JARVIS asks n8n to
                    build that workflow through its public REST API.
                    ───────────────────────────────────────────────────────── */}
                <div id="n8n-panel" class="n8n-panel">
                  <header class="n8n-bar">
                    <div class="n8n-bar-left">
                      <span class="n8n-dot" id="n8n-dot"></span>
                      <strong>n8n</strong>
                      <span class="n8n-ver" id="n8n-version">workflow automation</span>
                      <span class="n8n-state" id="n8n-state" data-state="checking">connecting…</span>
                    </div>
                    <div class="n8n-bar-right">
                      <a class="n8n-link" id="n8n-open" href="http://127.0.0.1:5678" target="_blank" rel="noopener" title="Open n8n in a new tab"><i data-lucide="external-link"></i>Open full</a>
                      <button type="button" class="n8n-icon-btn" id="n8n-reload" title="Reload n8n" aria-label="Reload n8n"><i data-lucide="rotate-cw"></i></button>
                    </div>
                  </header>
                  <form class="n8n-nl" id="n8n-nl-form">
                    <i data-lucide="sparkles"></i>
                    <input id="n8n-nl" class="field" placeholder="Describe the workflow you want… e.g. &quot;Every morning fetch my Gmail and save attachments to disk&quot;" aria-label="Describe the workflow you want to build"/>
                    <button type="button" class="primary-button" id="n8n-nl-build"><i data-lucide="wand-2"></i>Build in n8n</button>
                  </form>
                  <div class="n8n-note" id="n8n-note" hidden></div>
                  {/* The genuine n8n editor. Same-origin iframe on loopback, so
                      n8n's own login/setup session applies. */}
                  <iframe id="n8n-frame" class="n8n-frame" src="http://127.0.0.1:5678" title="n8n workflow editor" allow="clipboard-write" referrerpolicy="no-referrer"></iframe>
                </div>
              </div>
              {/*
                LEGACY BUILDER MARKUP REMOVED: the old af-builder canvas/rail/
                config/runlog markup is gone from this panel on request - n8n
                replaces it. background/agent_flow.py and the /agents/* routes
                are intentionally KEPT: the voice path and the regression suite
                still use them, so deleting them would break JARVIS.
              */}
              <div class="cowork-panel" data-cowork-panel="extensions">
                <div class="ext-toolbar">
                  <div class="ext-tabs" role="tablist">
                    <button type="button" class="ext-tab active" data-ext-tab="plugins">Plugins</button>
                    <button type="button" class="ext-tab" data-ext-tab="skills">Skills</button>
                    <button type="button" class="ext-tab" data-ext-tab="mcp">MCP</button>
                    <button type="button" class="ext-tab" data-ext-tab="permissions">Permissions</button>
                    <button type="button" class="ext-tab" data-ext-tab="marketplace">Marketplace</button>
                    <button type="button" class="ext-tab" data-ext-tab="activity">Activity</button>
                  </div>
                  <span id="ext-counts" class="ext-counts">loading…</span>
                </div>
                <div id="ext-panel-plugins" class="ext-pane" data-ext-pane="plugins"><span class="panel-note">Loading plugins…</span></div>
                <div id="ext-panel-skills" class="ext-pane" data-ext-pane="skills" hidden><span class="panel-note">Loading skills…</span></div>
                <div id="ext-panel-mcp" class="ext-pane" data-ext-pane="mcp" hidden><span class="panel-note">Loading MCP servers…</span></div>
                <div id="ext-panel-permissions" class="ext-pane" data-ext-pane="permissions" hidden><span class="panel-note">Loading permissions…</span></div>
                <div id="ext-panel-marketplace" class="ext-pane" data-ext-pane="marketplace" hidden><span class="panel-note">Loading marketplace…</span></div>
                <div id="ext-panel-activity" class="ext-pane" data-ext-pane="activity" hidden><span class="panel-note">No activity yet.</span></div>
              </div>
            </div>
            <div class="cowork-composer">
              <input id="cowork-goal" class="field" placeholder="Describe a task for the agent…" aria-label="Task request"/>
              <button type="button" class="primary-button" id="cowork-goal-start">Start task</button>
              <button type="button" class="text-button" id="cowork-cancel">Stop</button>
            </div>
            <details class="cowork-advanced">
              <summary>Step-by-step task (voice format)</summary>
              <div class="task-start-row">
                <input id="cowork-title" class="field" placeholder="Task title (voice: cowork chalao title :: step 1 ; step 2)"/>
                <input id="cowork-steps" class="field" placeholder="Steps separated by ; — e.g. time batao ; note likho buy milk"/>
                <div class="task-start-actions"><button class="primary-button" id="cowork-start">Start steps</button></div>
              </div>
            </details>
          </div>
          <aside class="cowork-rail" id="cowork-rail" aria-label="Task intelligence rail">
            <div class="cowork-rail-resize" id="cowork-rail-resize" title="Drag to resize" role="separator" aria-orientation="vertical"></div>
            <section class="panel cowork-rail-card">
              <span class="panel-title">TASK PROGRESS</span>
              <div id="cowork-progress" class="cowork-progress"><span class="panel-note">No active task.</span></div>
            </section>
            <section class="panel cowork-rail-card">
              <span class="panel-title">ARTIFACTS</span>
              <div id="cowork-artifacts" class="saved-list"><span class="panel-note">Waiting for core state…</span></div>
            </section>
            <section class="panel cowork-rail-card cowork-rail-context">
              <span class="panel-title">CONTEXT</span>
              <div class="cowork-context-block"><small>CHANNELS</small><div id="cowork-channels" class="saved-list"><span class="panel-note">Waiting for core state…</span></div></div>
              <div class="cowork-context-block"><small>SCHEDULE</small><div id="cowork-schedule" class="saved-list"><span class="panel-note">Waiting for core state…</span></div></div>
              <div class="cowork-context-block"><small>SKILLS</small><div id="cowork-skills" class="saved-list"><span class="panel-note">Waiting for core state…</span></div></div>
              <div class="cowork-context-block"><small>MCP CONNECTORS</small><div id="cowork-mcp" class="saved-list"><span class="panel-note">Waiting for core state…</span></div>
                <div class="task-start-row"><input id="mcp-call" class="field" placeholder='mcp call echo.echo {"text": "hello"}'/><div class="task-start-actions"><button class="primary-button" id="mcp-run">Run tool</button><button class="text-button" id="mcp-refresh">Refresh</button></div></div>
              </div>
            </section>
            <section class="panel cowork-rail-card">
              <span class="panel-title">QUICK ACTIONS</span>
              <div class="cowork-quick">
                <button type="button" data-command="kya kya skills">List skills</button>
                <button type="button" data-command="cowork status">Task status</button>
                <button type="button" id="cowork-refresh">Refresh state</button>
              </div>
            </section>
          </aside>
        </div>
      </section>
      <section class="view" data-view-panel="repos">
        <header class="view-heading">
          <div><span class="eyebrow">REPOS</span><h1>GitHub repository workspaces</h1><p>Search GitHub, then open any repo as its own workspace — file tree, live file contents and a JARVIS chat that reads the code.</p></div>
          <span class="connection-chip" id="repos-key-chip">Checking key…</span>
        </header>
        <div class="repos-shell">
          <section class="panel repos-open-panel" aria-label="Open repository workspaces">
            <header class="repos-open-head">
              <span class="panel-title">OPEN WORKSPACES <span class="repo-count" id="repos-open-count">0</span></span>
              <span class="panel-note">Each repository keeps its own files, README and chat. Switch with a click, or remove it with ×.</span>
            </header>
            <div id="repos-open-tabs" class="repos-open-tabs" role="tablist" aria-label="Open repository workspaces"></div>
          </section>
          {/* Repos added to JARVIS itself. Distinct from "open workspaces": these are
    the repositories this install has integrated, read back from
    integrations/ on disk, so they survive a reload. */}
          <section class="panel repos-open-panel" aria-label="Repositories added to JARVIS">
            <header class="repos-open-head">
              <span class="panel-title">ADDED TO JARVIS <span class="repo-count" id="repos-integrations-count">0</span></span>
              <span class="panel-note">Repositories this install has indexed. Click one to open its workspace.</span>
            </header>
            <div id="repos-integrations" class="repos-open-tabs"></div>
          </section>
          <section class="panel repos-search-panel" id="repos-search-panel">
            {/* Always-visible way back to the repository list. Previously the only "back"
      control lived inside #repos-workspace, so once a search had run the user
      was stranded with no way to return to the list of other repositories. */}
            <div class="repos-panel-nav" id="repos-panel-nav" hidden>
              <button type="button" class="text-button" id="repos-back-search" title="Back to open workspaces"><i data-lucide="arrow-left"></i>Back to workspaces</button>
            </div>
            <form id="repos-search-form" class="repos-search-bar">
              <i data-lucide="search" aria-hidden="true"></i>
              <input id="repos-search-input" class="field" type="search" placeholder="Search GitHub repositories — e.g. browser-use" aria-label="Search GitHub repositories" autocomplete="off"/>
              <button type="submit" class="primary-button" id="repos-search-btn"><i data-lucide="search"></i>Search</button>
            </form>
            <p class="panel-note" id="repos-search-note">Searches GitHub server-side. The API key stays on the server and is never sent to this page.</p>
            <div id="repos-results" class="repos-results" aria-live="polite"></div>
          </section>
          <section class="panel repos-workspace" id="repos-workspace" hidden>
            <header class="repos-workspace-head">
              <div class="repos-workspace-title">
                <span class="repo-icon"><i data-lucide="git-branch"></i></span>
                <div>
                  <h2 id="repos-workspace-name">—</h2>
                  <p id="repos-workspace-desc" class="panel-note">Pick a repository from the search results.</p>
                  <div class="repos-meta" id="repos-workspace-meta"></div>
                </div>
              </div>
              <div class="repos-workspace-actions">
                <button type="button" class="text-button" id="repos-back" title="Back to the repository list"><i data-lucide="arrow-left"></i>All repositories</button>
                <button type="button" class="text-button" id="repos-close-active" title="Remove this repository from your workspaces"><i data-lucide="trash-2"></i>Remove</button>
                <a class="text-button" id="repos-workspace-link" href="#" target="_blank" rel="noopener noreferrer" hidden><i data-lucide="external-link"></i>Open on GitHub</a>
              </div>
            </header>
            <nav class="repos-tabs" id="repos-tabs" role="tablist" aria-label="Repository workspace sections">
              <button type="button" class="repos-tab active" data-repos-tab="files" role="tab"><i data-lucide="folder-tree"></i>Files</button>
              <button type="button" class="repos-tab" data-repos-tab="readme" role="tab"><i data-lucide="book-open"></i>README</button>
              <button type="button" class="repos-tab" data-repos-tab="chat" role="tab"><i data-lucide="message-square"></i>Ask JARVIS</button>
            </nav>
            <div class="repos-panel active" data-repos-panel="files">
              <div class="repos-file-bar">
                <input id="repos-file-filter" class="field" type="search" placeholder="Filter files…" aria-label="Filter files in this repository" autocomplete="off"/>
                <span class="panel-note" id="repos-file-count">—</span>
              </div>
              <div class="repos-files" id="repos-files"><span class="panel-note">Open a repository to list its files.</span></div>
              <div class="repos-viewer" id="repos-viewer" hidden>
                <header class="repos-viewer-head">
                  <strong id="repos-viewer-path">—</strong>
                  <button type="button" class="text-button" id="repos-viewer-close" aria-label="Close file"><i data-lucide="x"></i>Close</button>
                </header>
                <pre class="repos-code" id="repos-code"></pre>
              </div>
            </div>
            <div class="repos-panel" data-repos-panel="readme">
              <div class="repos-readme" id="repos-readme"><span class="panel-note">Open a repository to read its README.</span></div>
            </div>
            <div class="repos-panel" data-repos-panel="chat">
              <p class="panel-note repos-chat-note" id="repos-chat-context">Open a repository to chat about its code.</p>
              <div class="repos-chat-log" id="repos-chat-log" aria-live="polite"></div>
              <form class="chat-composer repos-chat-composer" id="repos-chat-form">
                <textarea id="repos-chat-input" class="field-area" rows="2" placeholder="Ask about this repository — e.g. what does browser_agent.py do?" aria-label="Ask JARVIS about this repository"></textarea>
                <button type="submit" class="primary-button" aria-label="Send"><i data-lucide="send"></i></button>
              </form>
            </div>
          </section>
        </div>
      </section>

      <section class="view" data-view-panel="brain">
        <div class="brain-workspace-layout">
          {/* Main Stage & Controls Column */}
          <div class="brain-main-column">
            <div class="jb-shell">
              <div class="jb-top">
                <div class="jb-top-left">
                  <div class="jb-orb" aria-hidden="true"><span class="jb-orb-ring"></span><span class="jb-orb-dot"></span></div>
                  <div>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                      <strong class="jb-title">JARVIS BRAIN</strong>
                      <span class="jb-badge"><span class="jb-badge-dot"></span> Brain Active</span>
                      <span class="jb-lod">LOD: <b id="brain-lod-val">Overview</b></span>
                      <span class="jb-chip" id="brain-chip">BRAIN IDLE</span>
                    </div>
                    <small class="jb-sub">AI Cognitive System &middot; Models &middot; Memory &middot; Context</small>
                  </div>
                </div>
                <div class="jb-top-right">
                  <span class="jb-theme-dots" aria-label="Hologram Themes">
                    <i class="theme-dot active" data-theme="arc_cyan" style="background:#06b6d4" title="Arc Cyan"></i>
                    <i class="theme-dot" data-theme="stark_gold" style="background:#f59e0b" title="Stark Gold"></i>
                    <i class="theme-dot" data-theme="quantum_violet" style="background:#a855f7" title="Quantum Violet"></i>
                    <i class="theme-dot" data-theme="tactical_emerald" style="background:#10b981" title="Tactical Emerald"></i>
                    <i class="theme-dot" data-theme="neural_crimson" style="background:#ef4444" title="Neural Crimson"></i>
                  </span>
                  <button class="chip-button jb-pill-btn active" id="brain-3d-toggle" type="button" title="Toggle 3D WebGL mode"><i data-lucide="box"></i> 3D: ON</button>
                  <button class="chip-button jb-btn" id="brain-explode" type="button" aria-pressed="false" title="Exploded View"><i data-lucide="layers"></i> Explode</button>
                  <button class="chip-button jb-btn" id="brain-orbit-reset" type="button" title="Reset View"><i data-lucide="rotate-cw"></i> Rotate</button>
                  <button class="chip-button jb-btn" id="brain-sound-toggle" type="button" title="Toggle Sound Effects"><i data-lucide="volume-2" id="brain-sound-icon"></i></button>
                  <button class="chip-button jb-btn jb-btn-accent" id="brain-overclock-btn" type="button" title="Arc Core Overclock"><i data-lucide="zap"></i> Overclock</button>
                  <button class="chip-button jb-btn jb-btn-party" id="brain-party-btn" type="button" title="House Party Protocol"><i data-lucide="shield-alert"></i> House Party</button>
                  <button class="chip-button jb-btn jb-btn-ai" id="brain-ai-status" type="button" title="JARVIS AI Runtime Status"><i data-lucide="bot"></i> JARVIS AI</button>
                </div>
              </div>

              <div class="jb-stage" id="jb-stage">
                <div class="brain-canvas-wrap brain-canvas-wrap--3d brain-hub" id="brain-canvas-wrap">
                  <canvas id="brain-canvas" width="640" height="520" aria-label="3D holographic neural-network brain"></canvas>
                  <svg class="brain-wires" id="brain-wires" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"></svg>
                  <div class="brain-tooltip" id="brain-tooltip" hidden></div>
                </div>
                <div class="jb-reticle" aria-hidden="true">
                  <div class="jb-ring jb-ring1"></div>
                  <div class="jb-ring jb-ring2"></div>
                  <div class="jb-ring jb-ring3"></div>
                  <span class="jb-cross-h"></span>
                  <span class="jb-cross-v"></span>
                </div>
                <div class="jb-caps" aria-label="Subsystems">
                  <div class="jb-col jb-left">
                    <button class="brain-cap" data-cap="vision" style="--cap:#06b6d4"><span class="bc-dot"></span><span class="bc-ico"><i data-lucide="eye"></i></span><span class="bc-body"><strong>Vision</strong><small>Camera &middot; Screen &middot; Image</small><em>[Gemini Lite / xKiro / NVIDIA]</em></span></button>
                    <button class="brain-cap" data-cap="language" style="--cap:#10b981"><span class="bc-dot"></span><span class="bc-ico"><i data-lucide="message-square"></i></span><span class="bc-body"><strong>Language</strong><small>Conversation &middot; Translation</small><em>[Groq / Gemini Lite / xKiro]</em></span></button>
                    <button class="brain-cap" data-cap="memory" style="--cap:#a855f7"><span class="bc-dot"></span><span class="bc-ico"><i data-lucide="database"></i></span><span class="bc-body"><strong>Memory</strong><small>Long-term &middot; Context &middot; Facts</small><em>[ChromaDB + SQLite + Mem0]</em></span></button>
                    <button class="brain-cap" data-cap="planning" style="--cap:#f59e0b"><span class="bc-dot"></span><span class="bc-ico"><i data-lucide="git-branch"></i></span><span class="bc-body"><strong>Planning</strong><small>Task Analysis &middot; Decision</small><em>[Qwen / Nemotron / MiniMax]</em></span></button>
                  </div>
                  <div class="jb-col jb-right">
                    <button class="brain-cap" data-cap="audio" style="--cap:#ef4444"><span class="bc-ico"><i data-lucide="volume-2"></i></span><span class="bc-body"><strong>Audio</strong><small>Speech &middot; STT &middot; TTS</small><em>[Whisper + Piper / Edge-TTS]</em></span><span class="bc-dot"></span></button>
                    <button class="brain-cap" data-cap="tools" style="--cap:#0ea5e9"><span class="bc-ico"><i data-lucide="wrench"></i></span><span class="bc-body"><strong>Tools</strong><small>Browser &middot; Files &middot; Apps</small><em>[xKiro / OpenRouter / n8n]</em></span><span class="bc-dot"></span></button>
                    <button class="brain-cap" data-cap="coding" style="--cap:#8b5cf6"><span class="bc-ico"><i data-lucide="code-2"></i></span><span class="bc-body"><strong>Coding</strong><small>Code &middot; Debug &middot; Git</small><em>[Qwen / Gemini Lite / DeepSeek]</em></span><span class="bc-dot"></span></button>
                    <button class="brain-cap" data-cap="computer_use" style="--cap:#14b8a6"><span class="bc-ico"><i data-lucide="monitor"></i></span><span class="bc-body"><strong>Computer Use</strong><small>Mouse &middot; Keyboard &middot; OS</small><em>[Agent-S / Playwright / Bridge]</em></span><span class="bc-dot"></span></button>
                  </div>
                </div>
                <div class="jb-lobe-bar">
                  <span class="brain-chip" id="brain-lobe">PREFRONTAL</span>
                  <small id="brain-reason">LOW complexity &rarr; fast chat pool (flash)</small>
                </div>
                <div class="brain-3d-controls">
                  <button id="brain-zoom-in" title="Zoom In">+</button>
                  <span class="sep">|</span>
                  <button id="brain-zoom-out" title="Zoom Out">-</button>
                  <span class="sep">|</span>
                  <button id="brain-zoom-reset" title="Reset View">RESET VIEW</button>
                </div>
              </div>

              <div class="jb-bottom">
                <div class="jb-card">
                  <span class="jb-card-ico"><i data-lucide="cpu"></i></span>
                  <span class="jb-card-body">
                    <small>ACTIVE MODEL</small>
                    <strong id="brain-bbb-model">Qwen 3.8 Flash</strong>
                    <em>Reasoning &amp; Code</em>
                  </span>
                  <span class="jb-card-badge">XHigh</span>
                </div>
                <div class="jb-card">
                  <span class="jb-card-ico jb-card-ico--emerald"><i data-lucide="git-branch"></i></span>
                  <span class="jb-card-body">
                    <small>MODEL ROUTER</small>
                    <strong id="brain-bbb-router">Auto</strong>
                    <em>Smart selection based on task</em>
                  </span>
                </div>
                <div class="jb-card">
                  <span class="jb-card-ico jb-card-ico--violet"><i data-lucide="database"></i></span>
                  <span class="jb-card-body">
                    <div style="display:flex;justify-content:space-between;align-items:baseline">
                      <small>MEMORY STATUS</small>
                      <span id="brain-mem-ratio" style="font-size:11px;color:#a855f7;font-family:monospace">2.4 GB / 10 GB (24%)</span>
                    </div>
                    <span class="jb-mem-bar" aria-hidden="true"><i id="jb-mem-fill" style="width:24%"></i></span>
                    <em>ChromaDB &middot; D:\JARVIS_DATA</em>
                  </span>
                </div>
                <div class="jb-card">
                  <span class="jb-card-ico jb-card-ico--cyan"><i data-lucide="telescope"></i></span>
                  <span class="jb-card-body">
                    <small>DEEP RESEARCH</small>
                    <strong id="brain-bbb-research">engine: checking…</strong>
                    <em id="brain-research-detail">no run in this session yet</em>
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Command Bar */}
            <footer class="brain-bottom-bar-shell">
              <button id="brain-mic-btn" class="brain-mic-btn" title="Voice Command (Say 'Hey JARVIS')" type="button">
                <i data-lucide="mic"></i>
              </button>
              <form id="brain-command-form" class="brain-command-form">
                <input
                  id="brain-command-input"
                  type="text"
                  placeholder="Message JARVIS or say &quot;Open YouTube and search for AI news&quot;"
                  class="brain-command-input"
                  autocomplete="off"
                />
                <div class="brain-command-actions">
                  <button type="button" id="brain-prompt-options" class="brain-icon-subtle" title="Prompt Options">
                    <i data-lucide="sliders-horizontal"></i>
                  </button>
                  <button type="submit" id="brain-command-send" class="brain-send-btn" title="Dispatch Neural Command">
                    <i data-lucide="send"></i>
                  </button>
                </div>
              </form>
            </footer>
          </div>

          {/* Right Status Panel (Image 2) */}
          <aside class="brain-right-panel" id="brain-right-panel">
            {/* 1. System Status (LIVE) */}
            <div class="brp-card">
              <div class="brp-card-header">
                <div class="brp-header-title">
                  <i data-lucide="activity" class="cyan-icon"></i>
                  <span>System Status</span>
                </div>
                <span class="brp-live-badge">LIVE</span>
              </div>
              <div class="brp-meters-grid">
                <div class="brp-meter-col">
                  <div class="brp-circle-meter" data-percent="12" style="--val:12;--col:#06b6d4">
                    <svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="18" class="meter-bg"/><circle cx="22" cy="22" r="18" class="meter-bar" style="stroke-dasharray:113;stroke-dashoffset:99.44"/></svg>
                    <i data-lucide="cpu" class="meter-ico"></i>
                  </div>
                  <span class="meter-label">CPU</span>
                  <strong class="meter-val" id="brp-cpu-val" style="color:#06b6d4">12%</strong>
                </div>
                <div class="brp-meter-col">
                  <div class="brp-circle-meter" data-percent="68" style="--val:68;--col:#10b981">
                    <svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="18" class="meter-bg"/><circle cx="22" cy="22" r="18" class="meter-bar" style="stroke-dasharray:113;stroke-dashoffset:36.16"/></svg>
                    <i data-lucide="memory-stick" class="meter-ico"></i>
                  </div>
                  <span class="meter-label">RAM</span>
                  <strong class="meter-val" id="brp-ram-val" style="color:#10b981">68%</strong>
                </div>
                <div class="brp-meter-col">
                  <div class="brp-circle-meter" data-percent="42" style="--val:42;--col:#f59e0b">
                    <svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="18" class="meter-bg"/><circle cx="22" cy="22" r="18" class="meter-bar" style="stroke-dasharray:113;stroke-dashoffset:65.54"/></svg>
                    <i data-lucide="hard-drive" class="meter-ico"></i>
                  </div>
                  <span class="meter-label">DISK</span>
                  <strong class="meter-val" id="brp-disk-val" style="color:#f59e0b">42%</strong>
                </div>
                <div class="brp-meter-col">
                  <div class="brp-circle-meter" data-percent="76" style="--val:76;--col:#a855f7">
                    <svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="18" class="meter-bg"/><circle cx="22" cy="22" r="18" class="meter-bar" style="stroke-dasharray:113;stroke-dashoffset:27.12"/></svg>
                    <i data-lucide="flame" class="meter-ico"></i>
                  </div>
                  <span class="meter-label">GPU</span>
                  <strong class="meter-val" id="brp-gpu-val" style="color:#a855f7">76%</strong>
                </div>
              </div>
            </div>

            {/* 2. Cognitive Trends */}
            <div class="brp-card">
              <div class="brp-card-header">
                <div class="brp-header-title">
                  <i data-lucide="trending-up" class="cyan-icon"></i>
                  <span>Cognitive Trends</span>
                </div>
                <span class="brp-trend-pill"><i data-lucide="zap"></i> 3 Spikes / 10m</span>
              </div>
              <div class="brp-trends-legend">
                <span><i style="background:#06b6d4"></i> CPU: 95%</span>
                <span><i style="background:#a855f7"></i> GPU: 98%</span>
                <span style="color:#f59e0b">Peak: 95%</span>
              </div>
              <div class="brp-chart-wrap">
                <svg viewBox="0 0 240 70" class="brp-chart-svg" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="chartGradCyan" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stop-color="#06b6d4" stop-opacity="0.35"/>
                      <stop offset="100%" stop-color="#06b6d4" stop-opacity="0"/>
                    </linearGradient>
                    <linearGradient id="chartGradPurple" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stop-color="#a855f7" stop-opacity="0.3"/>
                      <stop offset="100%" stop-color="#a855f7" stop-opacity="0"/>
                    </linearGradient>
                  </defs>
                  <line x1="0" y1="10" x2="240" y2="10" stroke="#f59e0b" stroke-dasharray="3 3" stroke-width="1" opacity="0.65"/>
                  <path d="M 0 50 Q 30 15 60 42 T 120 18 T 180 44 T 240 24 L 240 70 L 0 70 Z" fill="url(#chartGradPurple)"/>
                  <path d="M 0 50 Q 30 15 60 42 T 120 18 T 180 44 T 240 24" fill="none" stroke="#a855f7" stroke-width="2"/>
                  <path d="M 0 58 Q 30 35 60 20 T 120 38 T 180 16 T 240 32 L 240 70 L 0 70 Z" fill="url(#chartGradCyan)"/>
                  <path d="M 0 58 Q 30 35 60 20 T 120 38 T 180 16 T 240 32" fill="none" stroke="#06b6d4" stroke-width="2"/>
                </svg>
                <div class="brp-chart-labels">
                  <span>-10m</span><span>-8m</span><span>-6m</span><span>-4m</span><span>-2m</span><span>Now</span>
                </div>
              </div>
            </div>

            {/* 3. Recent Activity */}
            <div class="brp-card brp-activity-card">
              <div class="brp-card-header">
                <div class="brp-header-title">
                  <i data-lucide="radio" class="cyan-icon pulse-glow"></i>
                  <span>Recent Activity</span>
                </div>
                <button type="button" id="brp-clear-activity" class="brp-clear-btn">CLEAR</button>
              </div>
              <div class="brp-activity-list" id="brp-activity-list">
                <div class="brp-activity-item">
                  <div class="brp-act-icon"><i data-lucide="check-circle-2"></i></div>
                  <div class="brp-act-body">
                    <div class="brp-act-row"><strong>JARVIS initialized</strong><small>Now</small></div>
                    <p>Ready for your command</p>
                  </div>
                </div>
                <div class="brp-activity-item">
                  <div class="brp-act-icon"><i data-lucide="cpu"></i></div>
                  <div class="brp-act-body">
                    <div class="brp-act-row"><strong>Model switched to Qwen 3.8 Flash</strong><small>2m ago</small></div>
                    <p>Reasoning mode (XHigh)</p>
                  </div>
                </div>
                <div class="brp-activity-item">
                  <div class="brp-act-icon"><i data-lucide="database"></i></div>
                  <div class="brp-act-body">
                    <div class="brp-act-row"><strong>Memory updated</strong><small>5m ago</small></div>
                    <p>Saved 3 new facts</p>
                  </div>
                </div>
                <div class="brp-activity-item">
                  <div class="brp-act-icon"><i data-lucide="mic"></i></div>
                  <div class="brp-act-body">
                    <div class="brp-act-row"><strong>Voice command received</strong><small>8m ago</small></div>
                    <p>Processing...</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 4. Camera / Gesture View */}
            <div class="brp-card">
              <div class="brp-card-header">
                <div class="brp-header-title">
                  <i data-lucide="camera" class="cyan-icon"></i>
                  <span>Camera / Gesture View</span>
                </div>
                <button type="button" id="brp-cam-toggle" class="brp-cam-pill">CAMERA OFF</button>
              </div>
              <div class="brp-camera-box" id="brp-camera-box">
                <video id="brp-cam-video" autoplay playsinline muted style="display:none"></video>
                <div class="brp-cam-empty" id="brp-cam-empty">
                  <i data-lucide="camera-off"></i>
                  <strong>Camera off</strong>
                  <small>Click to enable</small>
                </div>
                <div class="brp-cam-hud" id="brp-cam-hud" style="display:none">
                  <span class="hud-tag top-l">OPTICAL FEED &bull; 60 FPS</span>
                  <span class="hud-tag bot-r">GESTURE SENSING ACTIVE</span>
                </div>
              </div>
            </div>

            {/* 5. Quick Actions */}
            <div class="brp-card">
              <div class="brp-card-header">
                <div class="brp-header-title">
                  <i data-lucide="zap" class="cyan-icon"></i>
                  <span>Quick Actions</span>
                </div>
              </div>
              <div class="brp-quick-grid">
                <button type="button" class="brp-quick-btn" data-quick="new_chat"><i data-lucide="message-square"></i><span>New Chat</span></button>
                <button type="button" class="brp-quick-btn" data-quick="screenshot"><i data-lucide="camera"></i><span>Screenshot</span></button>
                <button type="button" class="brp-quick-btn" data-quick="files"><i data-lucide="folder-open"></i><span>Files</span></button>
                <button type="button" class="brp-quick-btn" data-quick="browser"><i data-lucide="globe"></i><span>Browser</span></button>
              </div>
            </div>
          </aside>

          {/* Slide-out Node Detail Drawer */}
          <div id="brain-detail-drawer" class="brain-detail-drawer" hidden>
            <header class="bdd-header">
              <div class="bdd-head-main">
                <span class="bdd-dot" id="bdd-dot"></span>
                <div>
                  <h3 id="bdd-title">VISION ARCHITECTURE</h3>
                  <span class="bdd-region" id="bdd-region">Occipital Lobe &amp; Visual Cortex</span>
                </div>
              </div>
              <button type="button" id="bdd-close" class="bdd-close-btn" aria-label="Close drawer"><i data-lucide="x"></i></button>
            </header>
            <div class="bdd-content">
              <div class="bdd-metrics-grid">
                <div class="bdd-metric-box">
                  <small><i data-lucide="activity"></i> Synaptic Rate</small>
                  <strong id="bdd-rate">142 <span style="font-size:12px;font-weight:normal">Hz</span></strong>
                  <em style="color:#10b981">Firing Optimal</em>
                </div>
                <div class="bdd-metric-box">
                  <small><i data-lucide="clock"></i> Latency</small>
                  <strong id="bdd-latency">18 <span style="font-size:12px;font-weight:normal">ms</span></strong>
                  <em style="color:#7fb8c8">Live Telemetry</em>
                </div>
              </div>
              <div class="bdd-section">
                <small class="bdd-sec-title"><i data-lucide="cpu"></i> Subsystem Purpose</small>
                <p id="bdd-purpose">Camera, screen capture, optical gesture tracking, and multimodal vision processing.</p>
              </div>
              <div class="bdd-section">
                <small class="bdd-sec-title"><i data-lucide="layers"></i> Models &amp; Runtime Providers</small>
                <div id="bdd-models" class="bdd-pill-list"></div>
              </div>
              <div class="bdd-section">
                <small class="bdd-sec-title"><i data-lucide="wrench"></i> Registered Tools &amp; MCPs</small>
                <div id="bdd-tools" class="bdd-pill-list"></div>
              </div>
              <div class="bdd-section">
                <small class="bdd-sec-title"><i data-lucide="radio"></i> Last Recorded Event</small>
                <div id="bdd-last-event" class="bdd-event-box">Camera stream standby</div>
              </div>
              <div class="bdd-mask-notice">
                <i data-lucide="shield-check"></i>
                <span>Credentials masked. Secrets stored in local runtime environment.</span>
              </div>
            </div>
            <footer class="bdd-footer">
              <button type="button" id="bdd-stimulate-btn" class="bdd-stimulate-btn">
                <i data-lucide="zap"></i> Stimulate Action Potential
              </button>
            </footer>
          </div>
        </div>
      </section>


      {/* Phase 5 - Armour Studio (5.1 viewport, 5.2 gestures, 5.3 blueprint) */}
      <section class="view" data-view-panel="armour">
        <header class="view-heading">
          <div>
            <span class="eyebrow">PHASE 5 &middot; ARMOUR STUDIO</span>
            <h1>Armour Studio</h1>
            <p>Three.js viewport with orbit + MediaPipe gesture control, blueprint mode and subsystem callouts. Models are the real <code>.glb/.gltf</code> files found in <code>artifacts/3d</code> - until you add one, the viewport shows labelled placeholder geometry.</p>
          </div>
          <div class="armour-actions">
            <button id="armour-blueprint" class="chip-button" type="button" aria-pressed="false" title="Blueprint wireframe view"><i data-lucide="scan-line"></i> Blueprint</button>
            <button id="armour-reset" class="chip-button" type="button" title="Reset camera"><i data-lucide="rotate-ccw"></i> Reset View</button>
          </div>
        </header>
        <div class="armour-layout">
          <article class="panel armour-stage-card">
            <div id="armour-stage" class="armour-stage" aria-label="Armour 3D viewport"></div>
            <div class="armour-statusbar">
              <span id="armour-source" class="armour-source">Placeholder geometry - koi model file load nahi hui</span>
              <span id="armour-gesture" class="armour-gesture">Gesture: camera off</span>
            </div>
          </article>
          <aside class="armour-side">
            <article class="panel">
              <header class="panel-title"><i data-lucide="boxes"></i> Subsystems</header>
              <ul id="armour-subsystems" class="armour-subsystems"></ul>
            </article>
            <article class="panel">
              <header class="panel-title"><i data-lucide="folder-open"></i> Models on disk</header>
              <div id="armour-models" class="armour-models"></div>
            </article>
          </aside>
        </div>
        <p id="armour-note" class="armour-note" aria-live="polite"></p>
      </section>

      {/* Phase 6.3 - Fight-Fitness Coach: MediaPipe Pose rep counting on the single
    shared camera stream (app.js feeds every video.camera-feed from one stream). */}
      <section class="view" data-view-panel="fight">
        <header class="view-heading">
          <div>
            <span class="eyebrow">PHASE 6 &middot; FIGHT COACH</span>
            <h1>Fight-Fitness Coach</h1>
            <p>MediaPipe Pose counts real repetitions from your camera and reports measured form (tempo and depth). No landmarks means no rep - it never invents a count. Uses the same camera stream as the gesture pipeline.</p>
          </div>
          <div class="fight-actions" id="fight-exercises">
            <button class="chip-button active" data-exercise="push-up" type="button"><i data-lucide="chevrons-down"></i> Push-ups</button>
            <button class="chip-button" data-exercise="squat" type="button"><i data-lucide="chevrons-up"></i> Squats</button>
            <button class="chip-button" data-exercise="plank-hold" type="button"><i data-lucide="minus"></i> Plank hold</button>
          </div>
        </header>
        <div class="fight-layout">
          <article class="panel camera-panel fight-stage" data-fight-panel>
            <video class="camera-feed" playsinline muted aria-label="Pose camera feed"></video>
            <canvas id="fight-canvas" class="fight-canvas"></canvas>
            <div class="fight-readout">
              <strong id="fight-count">0</strong>
              <span id="fight-status">idle</span>
            </div>
          </article>
          <aside class="fight-side">
            <article class="panel">
              <header class="panel-title"><i data-lucide="activity"></i> Form feedback</header>
              <p id="fight-hints" class="fight-hints">start the camera, then step back until your full body is in frame</p>
            </article>
            <article class="panel">
              <header class="panel-title"><i data-lucide="info"></i> How counting works</header>
              <p class="panel-note">A rep is one completed down-then-up cycle of the measured joint angle (elbow for push-ups, knee for squats). A partial bend never counts, tempo and depth hints come from the measured angles, and low body visibility pauses counting instead of guessing.</p>
            </article>
          </aside>
        </div>
      </section>

      <section class="view" data-view-panel="security"><header class="view-heading"><div><span class="eyebrow">SECURITY</span><h1>Protection status</h1></div></header><div class="feature-grid"><article class="panel security-score"><i data-lucide="shield-check"></i><strong>Browser protected</strong><span>No secrets are stored in frontend code.</span></article><article class="panel"><span class="panel-title">WINDOWS SECURITY</span><p class="panel-note">Connect the allowlisted local bridge to retrieve Defender status or start a scan. Destructive commands always require confirmation.</p><button class="primary-button" data-command="check security status">Check status</button></article></div></section>
      <section class="view" data-view-panel="settings"><header class="view-heading"><div><span class="eyebrow">SETTINGS</span><h1>JARVIS configuration</h1></div><div class="settings-tabs" role="tablist"><button type="button" class="settings-tab active" data-settings-tab="general" role="tab" aria-selected="true">General</button><button type="button" class="settings-tab" data-settings-tab="neural" role="tab" aria-selected="false">Neural Brain · Holo</button></div></header><div class="settings-panel panel" data-settings-panel="general"><label>Display name<input id="display-name" class="field" value="Prateek"/></label><label>Assistant language<select id="language-select" class="field"><option value="auto">Auto / mixed language</option><option value="en">English</option><option value="hi">Hindi</option><option value="hinglish">Hinglish</option><option value="ja">Japanese / 日本語</option></select></label><label>Speech recognition<select id="stt-provider" class="field"><option value="browser">Browser STT (fast)</option><option value="cloud">Groq Whisper (multilingual)</option></select></label><label>Speaking voice<select id="tts-provider" class="field"><option value="browser">Browser voice</option><option value="elevenlabs">ElevenLabs multilingual</option></select></label><label>AI provider<select id="ai-provider-select" class="field"><option value="auto">Automatic fallback</option><option value="ollama">Local Ollama</option><option value="groq">Groq</option><option value="gemini">Google Gemini (free lite)</option><option value="xkiro">xKiro (free)</option><option value="nvidia">NVIDIA (free)</option><option value="openrouter">OpenRouter (free)</option></select></label><label>Local bridge URL<input id="bridge-url" class="field" value="http://127.0.0.1:7778"/></label><label class="switch-row"><span><strong>Speak responses</strong><small>Use browser text-to-speech</small></span><input id="speak-toggle" type="checkbox" checked/></label><label class="switch-row"><span><strong>Continuous wake-word mode</strong><small>The Windows background core listens for “Hey JARVIS” without a browser click</small></span><input id="wake-toggle" type="checkbox" checked/></label><label class="switch-row"><span><strong>Voice auto-recovery</strong><small>Reconnect listening automatically if the browser speech session ends</small></span><input id="auto-recover-toggle" type="checkbox" checked/></label><label class="switch-row"><span><strong>Voice debug logs</strong><small>Write [VOICE] diagnostics to the browser console</small></span><input id="voice-debug-toggle" type="checkbox"/></label><label class="switch-row"><span><strong>Confirm sensitive actions</strong><small>Required for shutdown, delete and security actions</small></span><input id="confirm-toggle" type="checkbox" checked disabled/></label><button id="save-settings" class="primary-button">Save settings</button></div><div class="settings-panel panel" data-settings-panel="neural" hidden><div class="settings-brain-head"><div><strong>Neural Brain — Holographic Mesh</strong><p class="panel-note" style="margin:4px 0 0">8-subsystem point-cloud brain — Vision / Language / Memory / Planning · Audio / Tools / Coding / Computer Use. Dots = live key status. Badge = live lobe.</p></div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><span class="connection-chip" id="settings-brain-chip">BRAIN IDLE</span><button type="button" class="chip-button" id="settings-brain-pulse" title="Ping brain"><i data-lucide="zap"></i> Pulse</button><button type="button" class="chip-button" id="settings-brain-open" data-view="brain" title="Open full Split-Brain Explorer"><i data-lucide="brain"></i> Full view</button></div></div><div class="settings-brain-grid"><div class="sb-col sb-left"><button type="button" class="sb-cap" data-cap="vision"><span class="sb-dot" id="sb-dot-vision"></span><span class="sb-ico"><i data-lucide="eye"></i></span><span><strong>Vision</strong><small>Camera · Screen · Image</small><em>Gemini Lite / xKiro / NVIDIA</em></span></button><button type="button" class="sb-cap" data-cap="language"><span class="sb-dot" id="sb-dot-language"></span><span class="sb-ico"><i data-lucide="languages"></i></span><span><strong>Language</strong><small>Conversation · Translation</small><em>Groq / Gemini Lite / xKiro</em></span></button><button type="button" class="sb-cap" data-cap="memory"><span class="sb-dot" id="sb-dot-memory"></span><span class="sb-ico"><i data-lucide="database"></i></span><span><strong>Memory</strong><small>Long-term · Context · Facts</small><em>ChromaDB + SQLite + Mem0</em></span></button><button type="button" class="sb-cap" data-cap="planning"><span class="sb-dot" id="sb-dot-planning"></span><span class="sb-ico"><i data-lucide="target"></i></span><span><strong>Planning</strong><small>Task Analysis · Decision</small><em>Qwen / Nemotron / MiniMax</em></span></button></div><div class="sb-center"><div class="sb-holo-wrap" id="settings-brain-wrap"><div class="sb-reticle"><div class="sb-ring sb-ring-1"></div><div class="sb-ring sb-ring-2"></div><div class="sb-ring sb-ring-3"></div><div class="sb-cross-h"></div><div class="sb-cross-v"></div></div><svg viewBox="0 0 500 500" class="sb-svg" aria-hidden="true"><defs><radialGradient id="sbGlow" cx="50%" cy="50%" r="50%"><stop offset="0%" stop-color="#06b6d4" stop-opacity="0.45"/><stop offset="60%" stop-color="#0284c7" stop-opacity="0.14"/><stop offset="100%" stop-color="#030712" stop-opacity="0"/></radialGradient></defs><circle cx="250" cy="240" r="155" fill="url(#sbGlow)"/><path d="M 230 110 C 290 100 360 120 380 170 C 400 220 395 280 360 320 C 330 355 290 365 270 395 C 255 415 240 415 235 390 C 220 365 190 365 160 340 C 130 310 115 260 125 210 C 135 155 180 120 230 110 Z" fill="none" stroke="#0ea5e9" stroke-width="1.4" stroke-dasharray="4 3" opacity="0.55"/><path d="M 230 110 Q 240 240 250 380" fill="none" stroke="#38bdf8" stroke-width="1.1" opacity="0.4"/><path d="M 160 210 Q 240 220 340 190" fill="none" stroke="#06b6d4" stroke-width="0.9" opacity="0.32"/><path d="M 150 270 Q 250 280 350 260" fill="none" stroke="#a855f7" stroke-width="0.9" opacity="0.32"/><g id="sb-orbit-nodes"></g><circle cx="250" cy="240" r="11" fill="#38bdf8" opacity="0.95" class="sb-pulse"/><circle cx="250" cy="240" r="21" fill="none" stroke="#38bdf8" stroke-width="1.2" stroke-dasharray="3 3" opacity="0.7"/></svg><div class="sb-lobe-badge" id="sb-lobe">PREFRONTAL</div><small class="sb-reason" id="sb-reason">Awaiting utterance</small><div class="sb-canvas-note">2D hologram · 3D in <a data-view="brain" href="#">Neural Brain</a></div></div><div class="sb-keys"><span class="sb-key" id="sb-key-groq"><i></i>Groq</span><span class="sb-key" id="sb-key-gemini"><i></i>Gemini</span><span class="sb-key" id="sb-key-openrouter"><i></i>OpenRouter</span><span class="sb-key" id="sb-key-nvidia"><i></i>NVIDIA</span><span class="sb-key" id="sb-key-elevenlabs"><i></i>ElevenLabs</span><span class="sb-key" id="sb-key-github"><i></i>GitHub</span></div><div class="sb-bottom"><div><small>Active Model</small><strong id="sb-model">—</strong></div><div><small>Router</small><strong id="sb-router">Auto</strong></div><div><small>Memory</small><strong id="sb-memory">—</strong></div></div></div><div class="sb-col sb-right"><button type="button" class="sb-cap" data-cap="audio"><span class="sb-ico"><i data-lucide="audio-lines"></i></span><span><strong>Audio</strong><small>Speech · STT · TTS</small><em>Whisper + Piper / Edge-TTS</em></span><span class="sb-dot" id="sb-dot-audio"></span></button><button type="button" class="sb-cap" data-cap="tools"><span class="sb-ico"><i data-lucide="wrench"></i></span><span><strong>Tools</strong><small>Browser · Files · Apps</small><em>xKiro / OpenRouter / n8n</em></span><span class="sb-dot" id="sb-dot-tools"></span></button><button type="button" class="sb-cap" data-cap="coding"><span class="sb-ico"><i data-lucide="code-2"></i></span><span><strong>Coding</strong><small>Code · Debug · Git</small><em>Qwen / Gemini Lite / DeepSeek</em></span><span class="sb-dot" id="sb-dot-coding"></span></button><button type="button" class="sb-cap" data-cap="computer_use"><span class="sb-ico"><i data-lucide="monitor"></i></span><span><strong>Computer Use</strong><small>Mouse · Keyboard · OS</small><em>Agent-S / Playwright / Bridge</em></span><span class="sb-dot" id="sb-dot-computer_use"></span></button></div></div><p class="panel-note" style="margin:10px 0 0">Image analysis: 8 caps with colored dots + central particle brain. Same 8 caps + SVG brain + radial glow + live key dots; full 3D cortical mesh in dedicated Neural Brain explorer.</p></div></section>
    </section>
    <div id="module-blank" class="module-blank" hidden aria-hidden="true"></div>
    <div id="toast-region" class="toast-region" aria-live="polite"></div>
  </main>
))

export default app
