# Web Intelligence → Deep Research Console — text UI reference

Status: **SPEC ONLY. Nothing here is built yet.** This file is the layout contract;
the code follows it line for line. No HTML mockup, no prototype page — the real
thing gets built in the real view at `127.0.0.1:7777`.

## 0. What this replaces

Today the `web` view is three elements and a card list:

- `src/index.tsx:3508-3512` — `data-view-panel="web"`, heading "Search, open, and research",
  `#web-search-form` (input + Google/YouTube/Bing/DDG `<select>`), empty `#web-grid`.
- `public/static/app.js:37` — the 4 static cards (Arbitrary web search / YouTube discovery /
  Current news / Research assistant) that only pre-fill a command string.
- `public/static/app.js:2308` — the submit handler.
- `src/index.tsx:227-229` + `public/research.html` — a separate `/research` window (FAB at
  `app.js:8078-8110`) that renders one search card **or** one report card, polled every 2 s.

The console **absorbs `/research` into the `web` view**. One surface, side by side with the
Co-work rail. `/research` stays as a route (the FAB keeps working) but stops being the place
where research is read.

Why the current page is not enough: it shows the *answer* and nothing about *how* it was
obtained — no plan, no per-source fetch outcome, no idea which claim came from one page
versus three, and it cannot tell "0 sources" apart from "provider has no credits".

## 1. Layout

Three columns, laptop-sized (1280+), no horizontal scroll. Matches the existing dark-glass
reference composition (left reactor orb stays where it is; this panel is the right-side
conversation analogue).

```
┌─ WEB INTELLIGENCE ── DEEP RESEARCH CONSOLE ─────────────────────────────────┐
│ [ topic input ...................... ] [RESEARCH] [STOP]   provider chip:   │
│                                                              ● firecrawl 402 │
├──────────────────────┬───────────────────────────┬──────────────────────────┤
│ 1  BRIEF             │ 2  RUN RAIL               │ 3  FINDINGS              │
│                      │                           │                          │
│ Goal (verbatim)      │ ▸ step 1  plan            │ ┌──────────────────────┐ │
│                      │   os_find_apps   412ms ✓  │ │ Claim text…          │ │
│ Sub-questions        │ ▸ step 2  search          │ │ [2 sources] [S1][S2] │ │
│  □ q1  (3 sources)   │   web_search      1.2s ✓  │ └──────────────────────┘ │
│  □ q2  (2 sources)   │ ▸ step 3  fetch           │                          │
│  □ q3  (0 sources) ✗ │   fetch_sources  8.4s ◐   │ Cross-checked 7          │
│                      │   … 4 running, 11 done    │ Single-source 2          │
│ Local grounding      │                           │ Uncited 1  ← red bar     │
│  doc_index: 3 hits   │ ┌ SOURCE LEDGER ────────┐ │                          │
│  (your PDFs/notes)   │ │ arxiv.org  ok  12.4kb │ │ [ full report ▾ ]        │
│                      │ │ reddit.com  402 ✗     │ │ [ citations ▾ ]          │
│                      │ │ key slot A parked     │ │ [ save → PPT / MD ]      │
│                      │ └───────────────────────┘ │                          │
├──────────────────────┴───────────────────────────┴──────────────────────────┤
│ VERIFIED 9/12 sources read · 1 key healthy of 3 · finished 14:32:07          │
└─────────────────────────────────────────────────────────────────────────────┘
```

Zone order is deliberate: **what was asked → what actually happened → what may be believed.**
Zone 3 is never shown without zone 2's ledger having been populated. If the ledger is empty,
findings render the blocked state, not a report.

## 2. Zone behaviour, state by state

### Zone 1 — BRIEF (planner output, not a chat box)
| Field | Source | Rendering |
|---|---|---|
| Goal, verbatim | `STATE.cortex.goal` | plain text, never rewritten |
| Sub-questions | planner step whose tool produced the query list | one row each: `□ q — n sources`; box fills `✓` when ≥1 source was *read*, stays `✗` red when 0 |
| Local grounding | `doc_index` hits for the topic (count + 2 names) | shows `no local docs indexed` honestly; never hidden |

States: `idle` (three example topics, all real commands), `planning` (skeleton rows, no spinner
that lies — the row count comes from the plan), `planned`, `failed` (reason text from
`STATE.cortex.reason`).

### Zone 2 — RUN RAIL (the step ledger; this is the honesty core)
One row per cortex step. Row = `index · stage label · tool name · duration · outcome` where
outcome ∈ `running / ok / empty / denied / error`. **The tool string is shown, not hidden** —
he reads it to know whether a window was raised or only a text response came back.

Below the steps, the **SOURCE LEDGER** — one row per URL attempted:
`host · ok/err · bytes read · which key slot read it`. Deduped by host (the same host twice is
one row, marked `×2`). Parked key slots render as `key A parked (402)` — that is the exact
truth the three Firecrawl keys need today, and it is already available
(`research_provider.key_slots`, `parked_keys`, `probe_error`).

`denied` is a separate colour from `error`: a refused action is Sir's decision, not a bug, and
must never be retried by the UI into a resend.

### Zone 3 — FINDINGS (claim-level, not one blob of markdown)
The report is split into claim cards. Each card carries:
- the claim text,
- **source count badge**: `CROSS-CHECKED (n≥2)` cyan, `SINGLE SOURCE (n=1)` amber,
  `UNCITED` red — computed, never asserted by the model,
- chips linking each source into the ledger row that read it.

Controls: full report ▾, citations ▾ (ordered list, host + URL + what was read),
`save → MD` and `save → PPT` (both call the existing `presentation_builder`; if it is not
reachable, the button is disabled with the reason, never a toast).

### Footer — VERIFIED strip (always visible, never removable)
`VERIFIED n/m sources read · keys healthy k/total · finished HH:MM:SS` plus, when the run was
cut short, `INCOMPLETE: <reason>` in the same place as the number. This strip is what stops a
green-looking page from implying a completed task.

## 3. Data contract — real fields only

Every value above must come from one of these. If a field is not here, it does not render.

| Field | Where it is produced today |
|---|---|
| `STATE.research` | `voice_engine.py:322`, set by `_push_research()` `:664-670` |
| `STATE.research_seq` | `:324`, bumped in the same call — the UI's only "new result" signal |
| `STATE.research_provider` | `_refresh_research_status()` `:638-661`: `available, provider, keys_total, keys_healthy, fanout, key_slots, parked_keys, api_key_set, out_of_credits, probe_error` |
| search shape | `firecrawl_client.search()` `:204` → `{type:"search", query, results:[{title,url,content,raw_content,score}], answer, provider}` or `{type:"search",query,error}` |
| research shape | `firecrawl_client.research()` `:286` → `{type:"research", topic, report, sources[], provider, keys_used, scraped}` or `{type:"research",topic,error}` |
| step rail | `STATE.cortex` `:343-344` `{run_id, goal, status, reason, answer, steps[], created_at, updated_at}`, `cortex_revision` `:345`, `cortex_confirm` `:346`, synced by `_sync_cortex_state()` `:6170` |
| transport | `GET /api/voice-state` — the same endpoint `public/research.html` polls (`STATE_URL` `:103`, `poll()` `:183`) |

**Backend delta this UI requires (small, additive — he said backend comes first):**
`research()` must return per-source rows, not one `sources[]` list. Minimum:
`sources: [{url, host, ok, bytes, ms, key_slot, error}]` and keep the flat list for the old
panel. Everything in zone 2's ledger depends on this; without it the ledger can only show the
final count, and the whole point of the screen is lost.

## 4. Non-negotiable honesty rules

1. **Nothing renders as success that was not observed.** A source row is `ok` only when bytes
   were read. `scraped: 0` is drawn as zero, not as an empty report.
2. **No report without a ledger.** `report` text with `sources: []` → findings pane shows
   "0 sources read — this text has no citations" and the model's words are visually demoted,
   not styled as an answer.
3. **Provider-unavailable ≠ 0 results.** Three distinct chips: not configured
   (`api_key_set=false`) / configured but out of credits (`out_of_credits=true`, show
   `probe_error` verbatim, redacted already) / configured and answering. Today's `app.js`
   research panel already splits these; the console keeps that split.
4. **`keys_healthy 1 of 3` is printed.** Credits are per account, not per key — the failover
   pool is not redundancy, and the UI must not imply it is.
5. **Sub-question rows that got 0 sources stay visibly unchecked at the end of the run.**
   Partial coverage is the answer, and it is shown as partial.
6. **No fake turns, no demo data, no seeded examples.** Empty states say "not run yet".
   (AGENTS.md: real runtime states, no fake demo turns.)

## 5. Voice-first interactions

He does not type into this page; he talks to JARVIS and this page follows.

- "research <topic>" → engine starts, `STATE.status = "searching"`, console switches to the
  `web` view on its own using the existing `open_view` / `open_view_seq` handshake
  (`voice_engine.py:334-335`). No click needed to *see* it.
- Typing in the input and hitting `RESEARCH` submits the literal sentence
  `"research " + q` through `/api/voice-action` — the same path `research.html:178`
  (`triggerResearch`) uses. One command path, never two.
- `STOP` maps to the existing stop verb; it must abort the run and leave the ledger as it is
  (partial truth), not clear the panel.
- Sidebar `Web Intelligence` entry (`index.tsx:2401`) unchanged. `DEEP_RESEARCH_PANEL` in the
  intent router (`app.js:1532`) now points at the console, not at the form.

## 6. Explicitly out of scope

- No second research pipeline, no second mic, no second agent loop. The console is a *visual
  client* of `voice_engine` + `cortex` exactly as the HUD is a client of `jarvis_core`.
- No new framework (no LangGraph/CrewAI rewrite) — `cortex.py` is already the loop.
- No new API key requirement in the UI copy. If Tavily (1 000 free searches/mo) is added as a
  provider, the chip shows whichever provider actually answered, and both stay honest.
- No `getUserMedia`, no Playwright assumption, no browser-automation claim.
- Do not touch Modules & Upgrades. This lives in `web` only.

## 7. Build order (each step ends with a check, not a claim)

| # | Step | Verify |
|---|---|---|
| 1 | `research()` returns per-source rows; `search()` keeps its shape | `node run_py.cjs --resolve` interpreter, then `unittest` on the client; assert a 402 row has `ok=false` + `error` |
| 2 | Markup: replace `index.tsx:3508-3512` with the three-zone skeleton, static text only | `npm run build`, `node --check public/static/app.js` |
| 3 | CSS: tokens only (existing `--cyan/--orange/--danger`, glass panel class) | screenshot the real page at 1280 and at 1024 |
| 4 | Wire zone 2 + footer to `cortex` / `research_provider` | live `/api/voice-state` dump matches the pixels — prove it, do not assert it |
| 5 | Wire zone 3 claim cards + source-count badges | one real run, count how many cards say CROSS-CHECKED and confirm two URLs actually back them |
| 6 | Voice handoff (`open_view`, `research_seq`) | say "research X", watch the panel switch and fill **on his screen** |
| 7 | Blocked/credit states | with keys still 402, the page must show `out of credits` + `probe_error`, and 0 sources — not a spinner |

Gate before any "done": `npm run test:bridge`, `node --check public/static/app.js`,
`npm run build`, then the Python suite under the resolved interpreter, then
`npx pm2 restart jarvis-voice --update-env` and read `build` from `/state` to prove the live
engine has the new code.

## 8. Known dependency risk

All three Firecrawl keys return **HTTP 402** right now. Built as-is, this console is a
beautiful, perfectly honest empty machine. It becomes useful the moment one working provider
is behind it. That is a backend/key decision, not a UI one — but it decides whether step 5 can
be verified with real bytes or only with synthetic rows.
