/* Build public/static/library/library-bundle.{js,css} from library-ui/.
 *
 * Usage:  node scripts/build-library-bundle.cjs
 *
 * The JARVIS Research Archive UI (the owner's zip) is React 19 + Tailwind v4,
 * while the dashboard itself is vanilla - so it is compiled into one lazily
 * fetched pair, the same way armour-bundle.js works, and never loaded unless
 * the Skill Library view is opened. vite is ESM-only, hence the dynamic import.
 */
const path = require('path')
const fs = require('fs')

const ROOT = path.resolve(__dirname, '..')
const OUT = path.join(ROOT, 'public', 'static', 'library')

async function main() {
  const { build } = await import('vite')
  await build({
    configFile: path.join(ROOT, 'library-ui', 'vite.config.mjs'),
    logLevel: 'warning',
  })

  const js = path.join(OUT, 'library-bundle.js')
  const css = path.join(OUT, 'library-bundle.css')
  for (const f of [js, css]) {
    if (!fs.existsSync(f)) throw new Error('build produced no ' + path.basename(f))
  }
  // app.js starts the UI through this handle; a bundle without it is dead weight.
  const text = fs.readFileSync(js, 'utf8')
  if (!text.includes('__JARVIS_LIBRARY__')) {
    throw new Error('bundle is missing the __JARVIS_LIBRARY__ mount handle')
  }
  // The zip's stylesheet hid the page scrollbar and killed text selection on
  // <body>; if that ever comes back it would break the whole dashboard.
  const sheet = fs.readFileSync(css, 'utf8')
  if (/(^|\})\s*body\s*\{[^}]*overflow:\s*hidden/.test(sheet)) {
    throw new Error('library css still sets body{overflow:hidden} - it would freeze the dashboard')
  }
  // A stamp the dashboard can request and compare against. Without it an open
  // tab keeps running whatever bundle it first loaded, and the owner reads a
  // rebuild as "nothing changed" - which is exactly what happened on 2026-10-21.
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 16)
  fs.writeFileSync(path.join(OUT, 'build.json'), JSON.stringify({
    stamp, js: fs.statSync(js).size, css: fs.statSync(css).size,
  }))
  console.log('wrote library-bundle.js (%s KB) + library-bundle.css (%s KB), build %s',
    (fs.statSync(js).size / 1024).toFixed(0), (fs.statSync(css).size / 1024).toFixed(0), stamp)
}

main().catch((err) => { console.error(String(err && err.message || err)); process.exit(1) })
