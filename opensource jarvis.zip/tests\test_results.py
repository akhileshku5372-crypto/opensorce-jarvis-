"""Self-learning P2: the result ledger keeps honest per-tool scorecards.

Contract: every executed tool (cortex funnel) AND every direct WhatsApp send
lands in ONE bounded on-device ledger; the brain prompt gets the live verdicts
(working/flaky/broken from the rolling window - never an invented claim); and
the ledger is purely additive - a recording failure never breaks the tool.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


# Every test run targets a THROWAWAY ledger/recipes store - the owner's live
# artifacts/brain/*.json must never be written or wiped by a test process.
import os as _os, tempfile as _tempfile
_os.environ.setdefault("JARVIS_RESULTS_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_results.json"))
_os.environ.setdefault("JARVIS_ROUTINES_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_routines.json"))


def _load(name, sub="background"):
    # Sub-package test-support loader mirrors the route-test harness: each
    # module gets its own island, exactly like runtime imports resolve.
    spec = importlib.util.spec_from_file_location(
        name, ROOT / sub / ("%s.py" % name))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


RESULTS = _load("results")
ENGINE = _load("voice_engine")

# Reuse the correction-learner harness defaults. The results ledger must be
# empty before every test so counters never bleed across cases.
RESULTS.purge()
ENGINE._WA_PENDING.clear()
ENGINE._WA_MEDIA_PENDING.clear()


class RecordAndStatsTest(unittest.TestCase):
    def setUp(self):
        RESULTS.purge()
        self.addCleanup(RESULTS.purge)

    def test_a_success_then_more_successes_is_working(self):
        for _ in range(3):
            RESULTS.record("os_launch_app", True)
        self.assertEqual(RESULTS.stats("os_launch_app")["status"], "working")

    def test_a_recent_failure_is_broken_until_it_succeeds(self):
        RESULTS.record("browser_tabs", True)
        RESULTS.record("browser_tabs", True)
        RESULTS.record("browser_tabs", False, "driver not running")
        self.assertEqual(RESULTS.stats("browser_tabs")["status"], "broken")
        RESULTS.record("browser_tabs", True)
        self.assertEqual(RESULTS.stats("browser_tabs")["status"], "flaky")
        RESULTS.record("browser_tabs", True)
        self.assertEqual(RESULTS.stats("browser_tabs")["status"], "working")

    def test_never_recorded_is_idle_never_a_claim(self):
        stats = RESULTS.stats("unknown_tool")
        self.assertEqual(stats["status"], "idle")
        self.assertEqual(RESULTS.prompt_line(), "")

    def test_denied_runs_count_as_neither_succeeded_nor_failed(self):
        RESULTS.record("gui_type_into", False, denied=True)
        self.assertEqual(RESULTS.rollup(5)[0]["denied"], 1)
        self.assertEqual(RESULTS.rollup(5)[0]["total"], 0)

    def test_record_refuses_an_empty_name(self):
        ok, _total = RESULTS.record("   ", True)
        self.assertFalse(ok)

    def test_prompt_line_names_failing_tools_with_numbers(self):
        RESULTS.record("whatsapp_send", False, "no chat found")
        RESULTS.record("browser_navigate", True)
        line = RESULTS.prompt_line()
        self.assertIn("whatsapp_send", line)
        self.assertIn("FAILING", line)
        self.assertIn("browser_navigate", line)

    def test_rollup_orders_by_most_recent(self):
        import time as _time
        RESULTS.record("tool_a", True)
        _time.sleep(1.1)          # the ledger's clock is second-resolution
        RESULTS.record("tool_b", True)
        rows = RESULTS.rollup(5)
        self.assertEqual(rows[0]["tool"], "tool_b")

    def test_ledger_is_bounded(self):
        for i in range(500):
            RESULTS.record("spam_tool", bool(i % 2))
        data = RESULTS._load()
        self.assertLessEqual(len(data.get("events") or []), 400)
        self.assertLessEqual(len(data.get("scores") or {}), 60)


class ProfileModuleRecordTest(unittest.TestCase):
    def setUp(self):
        RESULTS.purge()
        self.addCleanup(RESULTS.purge)

    def test_wa_send_outcomes_reach_the_same_ledger(self):
        ENGINE._results_record("whatsapp_send", True, "Sir, akhilesh ko bhej diya")
        ENGINE._results_record("whatsapp_send", False, "koi chat nahi mili")
        rows = RESULTS.rollup(5)
        self.assertEqual(rows[0]["tool"], "whatsapp_send")
        self.assertEqual(rows[0]["ok"], 1)
        self.assertEqual(rows[0]["fail"], 1)

    def test_a_results_module_failure_never_breaks_the_send(self):
        import unittest.mock
        saved = RESULTS.record
        try:
            RESULTS.record = lambda *a, **k: (_ for _ in ()).throw(OSError("disk full"))
            # _results_record swallows everything; the send flow must go on.
            ENGINE._results_record("whatsapp_send", True, "x")
        finally:
            RESULTS.record = saved


import unittest.mock  # noqa: E402  (kept here for the file-local import order rule)

CORTEX = unittest.mock.MagicMock() if False else _load("cortex")


class CortexFunnelTest(unittest.TestCase):
    """Every tool that runs through the REAL cortex registry is scored."""

    def setUp(self):
        RESULTS.purge()
        self.addCleanup(RESULTS.purge)
        self.registry = CORTEX.ToolRegistry()

    def test_a_pure_success_is_scored_working(self):
        spec = CORTEX.ToolSpec(
            name="scored_tool",
            description="a fixture tool",
            handler=lambda args: {"ok": True, "output": "done"},
            requires_confirmation=False, timeout_s=4)
        ok, _why = self.registry.register(spec)
        self.assertTrue(ok)
        result = self.registry.execute("scored_tool", {})
        self.assertTrue(result.get("ok"))
        rows = RESULTS.rollup(5)
        self.assertEqual(rows[0]["tool"], "scored_tool")
        self.assertEqual(rows[0]["ok"], 1)
        self.assertEqual(RESULTS.stats("scored_tool")["status"], "working")

    def test_a_failing_tool_is_scored_broken(self):
        def bad(args):
            raise RuntimeError("nope")

        spec = CORTEX.ToolSpec(
            name="scored_bad", description="always fails", handler=bad,
            requires_confirmation=False, timeout_s=4)
        self.assertTrue(self.registry.register(spec)[0])
        self.registry.execute("scored_bad", {})
        self.assertEqual(RESULTS.stats("scored_bad")["status"], "broken")

    def test_a_refused_confirmation_is_scored_denied(self):
        spec = CORTEX.ToolSpec(
            name="scored_gated", description="needs confirm",
            handler=lambda args: {"ok": True, "output": ""},
            requires_confirmation=True, timeout_s=4)
        self.assertTrue(self.registry.register(spec)[0])
        result = self.registry.execute("scored_gated", {}, confirm=None)
        self.assertFalse(result.get("ok"))
        row = RESULTS.rollup(5)[0]
        self.assertEqual(row["tool"], "scored_gated")
        self.assertEqual(row["denied"], 1)


class ScorecardRouteTest(unittest.TestCase):
    """'results batao' reads the SAME ledger back, deterministically."""

    def setUp(self):
        self.spoken = []
        self.agent = unittest.mock.MagicMock()
        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: None
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        RESULTS.purge()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_results_batao_reports_the_real_counts(self):
        RESULTS.record("os_launch_app", True)
        RESULTS.record("os_launch_app", True)
        RESULTS.record("whatsapp_send", False, "no chat")
        handled, said = self._route("results batao")
        self.assertTrue(handled)
        self.assertIn("os_launch_app", said)
        self.assertIn("2/2", said)
        self.assertIn("whatsapp_send", said)
        self.assertIn("0/1", said)

    def test_scorecard_all_empty_is_honest_about_it(self):
        handled, said = self._route("results batao")
        self.assertTrue(handled)
        self.assertIn("record nahi bana", said)


if __name__ == "__main__":
    unittest.main()
