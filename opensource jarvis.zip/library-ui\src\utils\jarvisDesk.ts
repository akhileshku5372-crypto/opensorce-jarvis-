// The library desk talks to the JARVIS core, not to a browser API.
//
//  - text  -> POST /library/ask  -> the Radox prose pool ONLY
//  - audio -> POST /library/speak -> the loopback edge-tts service (no key)
//
// The owner's rule for this desk: "radox ke models and audio ke liye koi bhi api
// keys ya tool use karlena, but groq and gemini ki api key ko use mat karna text
// aur audio ke liye". Nothing here can reach either of those, because the core
// only routes this desk to radox_writer and background/edge_tts_http.py.
export const CORE_URL = 'http://127.0.0.1:7780';

export type DeskChapter = { n: number; title: string; chars: number };

export type DeskBook = {
  slug: string;
  ok: boolean;
  kind?: string;
  readable?: boolean;
  url?: string;
  reason?: string;
  title: string;
  author?: string;
  stream?: string;
  aisle?: string;
  level?: string;
  license?: string;
  attribution?: string;
  source_url?: string;
  chars?: number;
  split?: string;
  chapters: DeskChapter[];
  reason?: string;
};

export type DeskShelf = {
  ok: boolean;
  books: DeskBook[];
  unavailable: { slug: string; title: string; stream?: string; reason: string }[];
  counts: { live: number; listed: number; unavailable: number };
  error?: string;
  reason?: string;
};

export type DeskAnswer = {
  ok: boolean;
  answer?: string;
  engine?: string;
  model?: string;
  ms?: number;
  context?: string;
  attribution?: string;
  chapter?: { slug: string; n: number; title: string; chars: number };
  error?: string;
  reason?: string;
};

async function json(url: string, init?: RequestInit): Promise<any> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const res = await fetch(url, { signal: AbortSignal.timeout(180000), ...init });
  const text = await res.text();
  let body: any = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`${new URL(url).pathname} replied ${res.status}, not JSON`);
  }
  if (!body) throw new Error(`${new URL(url).pathname} replied ${res.status} with an empty body`);
  return body;
}

export async function loadShelf(): Promise<DeskShelf> {
  const shelf = await json(`${CORE_URL}/library/shelf`);
  if (!shelf || shelf.ok !== true) {
    throw new Error(shelf?.error || 'the core could not read the shelf');
  }
  return shelf as DeskShelf;
}

export async function loadChapter(slug: string, n: number): Promise<{ text: string; chapter_title: string; chars: number }> {
  const got = await json(`${CORE_URL}/library/chapter?slug=${encodeURIComponent(slug)}&n=${encodeURIComponent(String(n))}`);
  if (!got?.ok) throw new Error(got?.reason || `chapter ${n} of ${slug} could not be opened`);
  return got;
}

export async function askDesk(slug: string, n: number, question: string): Promise<DeskAnswer> {
  return json(`${CORE_URL}/library/ask`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ slug, n, question }),
  }) as Promise<DeskAnswer>;
}

// Returns a blob URL for an <audio> element. The MP3 comes from edge-tts, so the
// voice is the same one the assistant uses elsewhere in JARVIS.
export async function speakDesk(text: string, lang = 'en'): Promise<string> {
  const res = await fetch(`${CORE_URL}/library/speak`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, lang }),
    signal: AbortSignal.timeout(120000),
  });
  if (!res.ok) {
    let why = `edge-tts replied ${res.status}`;
    try {
      const body = await res.json();
      why = body.reason || body.error || why;
    } catch {
      /* the status line is already honest enough */
    }
    throw new Error(why);
  }
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}
