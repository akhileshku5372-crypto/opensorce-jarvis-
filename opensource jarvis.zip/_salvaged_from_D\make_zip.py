import os
import zipfile

ROOT = r"c:\Users\PRATEEK\Downloads\new jarvis-gens\jarvis-0.8"
OUT = r"c:\Users\PRATEEK\Downloads\new jarvis-gens\JARVIS 0.8 new.zip"
PREFIX = "JARVIS 0.8 new/"
SKIP_DIRS = {"node_modules", ".wrangler", "__pycache__", "dist", ".git", ".vscode", ".idea"}
SKIP_EXT = {".log", ".pyc"}

count = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in files:
            if os.path.splitext(name)[1].lower() in SKIP_EXT:
                continue
            full = os.path.join(base, name)
            rel = os.path.relpath(full, ROOT)
            zf.write(full, PREFIX + rel.replace("\\", "/"))
            count += 1
print("files:", count)
print("size:", os.path.getsize(OUT), "bytes")
