"""Kokoro-82M dependency probe for KamiSensei Podcast Studio.

Exit code 0  ->  kokoro, soundfile, misaki (+ fugashi/unidic-lite) import OK.
Exit code 1  ->  a required dependency is missing (run _install_kokoro.ps1).

Run:  python background/_probe_kokoro.py
"""
import importlib
import importlib.util
import sys


def _check(module_name, attr=None):
    try:
        mod = importlib.import_module(module_name)
        if attr:
            if not hasattr(mod, attr):
                return False, f"{module_name}.{attr} missing"
        return True, "ok"
    except Exception as exc:  # noqa: BLE001 - deliberate broad probe
        return False, f"{module_name}: {exc.__class__.__name__}: {exc}"


def main() -> int:
    checks = [
        ("kokoro", "KPipeline"),
        ("soundfile", None),
        ("misaki", None),
        ("fugashi", None),
        ("unidic_lite", None),
    ]
    failed = []
    for name, attr in checks:
        ok, detail = _check(name, attr)
        print(f"  {'OK ' if ok else 'MISS'}  {name}{('.' + attr) if attr else ''}  ({detail})")
        if not ok:
            failed.append(name)

    if failed:
        print("PROBE FAIL: missing -> " + ", ".join(failed))
        print("Run:  powershell -NoProfile -ExecutionPolicy Bypass -File background/_install_kokoro.ps1")
        return 1
    print("PROBE OK: kokoro-82m-local engine dependencies are installed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
