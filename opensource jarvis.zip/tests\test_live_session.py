"""Tests for the Gemini Live duplex session: wire format, frame parsing, barge-in.

No network, no microphone, no speaker. Live behaviour itself is proven by
`background/live_session.py --smoke`, which needs real audio.
"""
import base64
import importlib.util
import queue
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


LS = _load("live_session")


class WireFormatTest(unittest.TestCase):
    def setUp(self):
        self.s = LS.LiveSession()

    def test_setup_asks_for_audio_and_uses_the_accepted_shape(self):
        setup = self.s.setup_frame()["setup"]
        self.assertEqual(setup["model"], "models/" + LS.MODEL_DEFAULT)
        gen = setup["generationConfig"]
        self.assertEqual(gen["responseModalities"], ["AUDIO"])
        # Voice belongs inside generationConfig.speechConfig. At setup level the
        # endpoint closes the socket (bisected 2026-10-17).
        self.assertEqual(
            gen["speechConfig"]["voiceConfig"]["prebuiltVoiceConfig"]["voiceName"],
            LS.VOICE_DEFAULT)
        self.assertIn("text", setup["systemInstruction"]["parts"][0])
        # Server VAD owns turns. Low start sensitivity keeps JARVIS's own
        # speaker output from starting a turn; high end sensitivity keeps the
        # reply prompt. Measured accepted on gemini-3.8-live 2026-10-20.
        vad = setup["realtimeInputConfig"]["automaticActivityDetection"]
        self.assertEqual(vad["startOfSpeechSensitivity"], "START_SENSITIVITY_LOW")
        self.assertEqual(vad["endOfSpeechSensitivity"], "END_SENSITIVITY_HIGH")
        self.assertNotIn("speechConfig", setup)
        self.assertTrue(setup["inputAudioTranscription"] is not None)
        self.assertTrue(setup["outputAudioTranscription"] is not None)

    def test_audio_frame_uses_the_field_the_endpoint_reads(self):
        payload = base64.b64encode(b"\x01\x02").decode()
        chunk = self.s.audio_frame(b"\x01\x02")["realtimeInput"]["audio"]
        self.assertEqual(chunk["mimeType"], "audio/pcm;rate=16000")
        self.assertEqual(chunk["data"], payload)
        # mediaChunks is documented first everywhere but this endpoint ignores it
        # (measured 2026-10-17: zero frames back). Guard against re-adding it.
        self.assertNotIn("mediaChunks", self.s.audio_frame(b"\x01\x02")["realtimeInput"])
        self.assertNotIn("setup", self.s.audio_frame(b"\x01\x02"))

    def test_setup_omits_tools_and_resumption_when_not_used(self):
        setup = self.s.setup_frame()["setup"]
        self.assertNotIn("tools", setup)
        self.assertNotIn("sessionResumption", setup)

    def test_setup_carries_function_declarations_when_given(self):
        decls = [{"name": "jarvis_command",
                  "description": "run it",
                  "parameters": {"type": "OBJECT", "properties": {
                      "command": {"type": "STRING"}}, "required": ["command"]}}]
        s = LS.LiveSession(tools=decls)
        setup = s.setup_frame()["setup"]
        self.assertEqual(setup["tools"],
                         [{"functionDeclarations": decls}])

    def test_setup_resumes_with_the_latest_handle(self):
        self.s._resume_handle = "handle-123"
        self.assertEqual(self.s.setup_frame()["setup"]["sessionResumption"],
                         {"handle": "handle-123"})

    def test_tool_response_frame_matches_the_endpoint_contract(self):
        frame = self.s.tool_response_frame("call_1", "jarvis_command",
                                           {"ok": True, "result": "dispatched"})
        response = frame["toolResponse"]["functionResponses"][0]
        self.assertEqual(response["id"], "call_1")
        self.assertEqual(response["name"], "jarvis_command")
        self.assertEqual(response["response"], {"ok": True, "result": "dispatched"})

    def test_a_string_tool_result_is_wrapped_not_sent_bare(self):
        frame = self.s.tool_response_frame("call_2", "recall_memory", "nothing")
        self.assertEqual(frame["toolResponse"]["functionResponses"][0]["response"],
                         {"result": "nothing"})

    def test_text_frame_is_a_complete_turn(self):
        f = self.s.text_frame("hello")
        self.assertTrue(f["clientContent"]["turnComplete"])
        self.assertEqual(f["clientContent"]["turns"][0]["parts"][0]["text"], "hello")

    def test_ipv4_pin_is_idempotent(self):
        import socket
        before = socket.getaddrinfo
        LS._pin_ipv4()
        wrapped = socket.getaddrinfo
        LS._pin_ipv4()
        self.assertIs(socket.getaddrinfo, wrapped,
                      "second call must not re-wrap an already patched resolver")
        if wrapped is not before:
            self.assertTrue(getattr(wrapped, "_jarvis_ipv4", False),
                            "the patched resolver must mark itself so it is not doubled")


class FrameParsingTest(unittest.TestCase):
    def setUp(self):
        self.s = LS.LiveSession()

    def test_native_audio_is_read_from_model_turn(self):
        frame = {"serverContent": {"modelTurn": {"parts": [
            {"inlineData": {"mimeType": "audio/pcm;rate=24000",
                            "data": base64.b64encode(b"\x00" * 320).decode()}}]}}}
        audio, itext, otext, interrupted, complete = self.s.intake(frame)
        self.assertEqual(len(audio), 320)
        self.assertFalse(interrupted)

    def test_both_transcriptions_are_separated(self):
        frame = {"serverContent": {
            "inputTranscription": {"parts": [{"text": "kya haal hai"}]},
            "outputTranscription": {"parts": [{"text": "Functional, sir."}]},
            "turnComplete": True}}
        audio, itext, otext, interrupted, complete = self.s.intake(frame)
        self.assertEqual(itext, "kya haal hai")
        self.assertEqual(otext, "Functional, sir.")
        self.assertTrue(complete)
        self.assertEqual(audio, b"")

    def test_the_real_endpoint_sends_transcription_as_a_bare_text_field(self):
        # Recorded 2026-10-20 from a live duplex turn, verbatim apart from the
        # base64 audio. `parts` is the documented shape and the test above uses
        # it - but the wire sends {"text": ...}, so reading only `parts` left
        # JARVIS's own words out of the chat history and out of /state.
        frame = {"serverContent": {
            "modelTurn": {"parts": [{"inlineData": {
                "mimeType": "audio/pcm;rate=24000",
                "data": base64.b64encode(b"\x00" * 64).decode()}}], "role": "model"},
            "outputTranscription": {"text": "Loud and "}}}
        audio, itext, otext, _interrupted, _complete = self.s.intake(frame)
        self.assertEqual(otext, "Loud and ")
        self.assertEqual(len(audio), 64)

    def test_a_bare_text_input_transcription_reaches_the_command_path(self):
        # The bridge submits on the user's transcript: if that field is read as
        # `parts` only, no spoken command ever becomes an action.
        frame = {"serverContent": {"inputTranscription": {"text": "open youtube"}}}
        self.assertEqual(self.s.intake(frame)[1], "open youtube")

    def test_interrupted_flag_survives_parsing(self):
        frame = {"serverContent": {"interrupted": True}}
        self.assertTrue(self.s.intake(frame)[3])

    def test_chunks_shape_also_yields_audio(self):
        frame = {"serverContent": {"chunks": [{"parts": [
            {"inlineData": {"data": base64.b64encode(b"abc").decode()}}]}]}}
        self.assertEqual(self.s.intake(frame)[0], b"abc")

    def test_empty_and_unknown_frames_do_not_raise(self):
        for frame in ({}, {"serverContent": {}}, {"goAway": {"timeReceived": "x"}},
                      {"error": {"code": 400}}):
            self.s.intake(frame)


class BargeInTest(unittest.TestCase):
    def test_flush_drops_every_queued_chunk(self):
        p = LS.Pcm24kPlayer()
        for _ in range(5):
            p._q.put(object())
        self.assertEqual(p.flush(), 5, "barge-in must discard the whole queue")
        self.assertTrue(p._q.empty())
        self.assertFalse(p.speaking)

    def test_flush_on_empty_queue_is_harmless(self):
        self.assertEqual(LS.Pcm24kPlayer().flush(), 0)

    def test_output_rate_is_what_the_api_returns(self):
        # Probe 2026-07 measured mimeType audio/pcm;rate=24000 downstream.
        self.assertEqual(LS.RATE_OUT, 24000)
        self.assertEqual(LS.RATE_IN, 16000)


class NoKeyBehaviourTest(unittest.TestCase):
    def test_open_without_key_reports_error_state_instead_of_raising(self):
        seen = {}
        s = LS.LiveSession(on_state=lambda **kw: seen.update(kw))
        orig = LS.api_key
        LS.api_key = lambda: ""
        try:
            self.assertFalse(s.open())
        finally:
            LS.api_key = orig
        self.assertEqual(seen.get("stage"), "live_error")
        self.assertIn("GOOGLE_API_KEY", seen.get("last_error", ""))


if __name__ == "__main__":
    unittest.main()
