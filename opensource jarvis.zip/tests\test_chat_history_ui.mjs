// Proves the chat history sidebar is REAL database-backed history, not
// localStorage. Drives headless Chrome over CDP against the running stack.
//
// The decisive checks:
//   1. open the drawer -> rows come back from the core's SQLite store
//   2. a chat created by POSTing to the core APPEARS in the sidebar
//   3. reload the page -> the SAME conversation is still there
//   4. deleting removes it from the core, not just from the screen
//
// Read-mostly: it creates and then deletes its own throwaway conversation.
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const out = path.join(root, 'artifacts', 'ui-audit', 'chat-history')
mkdirSync(out, { recursive: true })

const UI = 'http://127.0.0.1:7777'
const CORE = 'http://127.0.0.1:7780'
const MARKER = 'persisted-by-ui-test'

// Seed a conversation straight into the core so the sidebar has something real
// to display. This is the same path the browser uses.
const seeded = await (await fetch(`${CORE}/conversations`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ surface: 'jarvis' })
})).json()
await fetch(`${CORE}/conversations/message`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ surface: 'jarvis', id: seeded.id, role: 'user', content: MARKER })
})

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-history-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking', 'about:blank',
], { stdio: ['ignore', 'ignore', 'pipe'] })
setTimeout(() => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  process.exit(124)
}, 240000).unref()

const wait = ms => new Promise(r => setTimeout(r, ms))
let ws, seq = 0
const pending = new Map()
const endpoint = new Promise((resolve, reject) => {
  let log = ''
  const timer = setTimeout(() => reject(new Error('Chrome startup timed out')), 20000)
  chrome.stderr.on('data', d => {
    log += d
    const m = log.match(/DevTools listening on (ws:\/\/[^\s]+)/)
    if (m) { clearTimeout(timer); resolve(m[1]) }
  })
  chrome.on('error', reject)
})
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++seq
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' timeout')) }, 20000)
    pending.set(id, { resolve, reject, timer })
    ws.send(JSON.stringify({ id, method, params }))
  })
}
async function evaluate(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails))
  return r.result.value
}
const results = []
const check = (name, cond, detail = '') => {
  results.push({ name, ok: !!cond })
  console.log(`  ${cond ? 'ok  ' : 'FAIL'} ${name}${detail ? ' :: ' + detail : ''}`)
}
try {
  const browserUrl = await endpoint
  const origin = new URL(browserUrl).origin.replace('ws:', 'http:')
  const targets = await (await fetch(origin + '/json/list')).json()
  const target = targets.find(t => t.type === 'page') || targets[0]
  ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((res, rej) => {
    ws.addEventListener('open', res, { once: true })
    ws.addEventListener('error', rej, { once: true })
  })
  ws.addEventListener('message', e => {
    const m = JSON.parse(String(e.data))
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); clearTimeout(p.timer); pending.delete(m.id)
      if (m.error) p.reject(new Error(JSON.stringify(m.error))); else p.resolve(m.result)
    }
  })
  await send('Page.enable'); await send('Runtime.enable')
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 950, deviceScaleFactor: 1, mobile: false })
  await send('Page.navigate', { url: UI })
  await wait(9000)

  // Wait for the dashboard, not a fixed sleep.
  let mounted = false
  for (let i = 0; i < 45; i++) {
    const v = await evaluate(`(() => ({ log: !!document.querySelector('#chat-log'), nav: !!document.querySelector('.nav-item[data-view="dashboard"]') }))()`)
    if (v?.log && v?.nav) { mounted = true; break }
    await wait(1000)
  }
  check('dashboard mounted', mounted)

  await evaluate(`document.querySelector('#chat-history-toggle')?.click(), 1`)
  await wait(1500)

  const rows = await evaluate(`(() => [...document.querySelectorAll('#chat-history-list [data-chat-session]')]
    .map(e => e.dataset.chatSession))()`)
  check('sidebar lists DB conversations', Array.isArray(rows) && rows.length > 0,
    `${rows?.length} row(s)`)
  check('seeded conversation appears in sidebar', (rows || []).includes(seeded.id), seeded.id)

  // The row must be backed by the core, not localStorage.
  const storageState = await evaluate(`(() => ({
    ls: localStorage.getItem('jarvis-chat-sessions') || '',
    active: localStorage.getItem('jarvis-chat-active') || ''
  }))()`)
  check('no localStorage session blob in use', !storageState.ls,
    storageState.ls ? 'legacy blob still written' : 'clean')

  await evaluate(`document.querySelector('[data-chat-session="${seeded.id}"]')?.click(), 1`)
  await wait(1800)
  const restored = await evaluate(`(() => ({
    text: document.querySelector('#chat-log')?.textContent || '',
    active: localStorage.getItem('jarvis-chat-active') || ''
  }))()`)
  check('clicking restores the exact conversation', restored.text.includes(MARKER))
  check('active id persisted', restored.active === seeded.id, restored.active)

  await send('Page.reload', { ignoreCache: false })
  await wait(10000)
  // Re-check once more: the first read can land before the boot-restore fetch
  // resolves, which would be a test-timing artefact rather than a real bug.
  let afterReload = await evaluate(`(() => ({
    text: document.querySelector('#chat-log')?.textContent || '',
    active: localStorage.getItem('jarvis-chat-active') || ''
  }))()`)
  if (!afterReload.text.includes(MARKER)) {
    await wait(6000)
    afterReload = await evaluate(`(() => ({
      text: document.querySelector('#chat-log')?.textContent || '',
      active: localStorage.getItem('jarvis-chat-active') || ''
    }))()`)
  }
  check('conversation survives a page reload', afterReload.text.includes(MARKER),
    `active=${afterReload.active} len=${afterReload.text.length}`)

  const shot = await send('Page.captureScreenshot', { format: 'png' })
  if (shot?.data) writeFileSync(path.join(out, 'chat-history-drawer.png'), Buffer.from(shot.data, 'base64'))

  await fetch(`${CORE}/conversations/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ surface: 'jarvis', id: seeded.id })
  })
  const gone = await (await fetch(`${CORE}/conversations/${seeded.id}?surface=jarvis`)).json()
  check('deleted conversation is gone from the database', gone.ok === false)
} finally {
  try { if (ws) ws.close() } catch {}
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { chrome.kill() } catch {}
  await wait(600)
  try { rmSync(profile, { recursive: true, force: true, maxRetries: 3 }) } catch {}
}

const failed = results.filter((r) => !r.ok).length
console.log(`\nCHAT HISTORY UI: ${results.length - failed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)