"""
Tavily CLI client for JARVIS.

Wraps the `tvly` CLI (search, extract, crawl, map, research) and returns
structured data the UI can render. Never raises: returns {'error': ...} on
any failure so the voice pipeline stays alive.
"""
import json
import os
import shutil
import subprocess
import sys
import time

def _cli():
    """Resolve the tvly executable path, or None if not installed."""
    # Prefer an explicit env override, then PATH lookup, then the uv default.
    env_path = os.environ.get("TAVILY_CLI")
    if env_path and os.path.isfile(env_path):
        return env_path
    found = shutil.which("tvly")
    if found:
        return found
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(home, ".local", "bin", "tvly.exe"),
        os.path.join(home, ".local", "bin", "tvly"),
        os.path.join(home, "AppData", "Roaming", "uv", "tools", "tavily-cli", "bin", "tvly.exe"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def available():
    return _cli() is not None


def _run(args, timeout=60):
    """Run tvly with args, return (ok, parsed_json_or_error_dict)."""
    cli = _cli()
    if not cli:
        return False, {"error": "Tavily CLI not found. Install: uv tool install tavily-cli"}
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    try:
        proc = subprocess.run(
            [cli] + args,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
    except subprocess.TimeoutExpired:
        return False, {"error": f"Tavily timed out after {timeout}s"}
    except Exception as exc:
        return False, {"error": f"Tavily failed: {type(exc).__name__}: {exc}"}
    if proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "unknown error").strip()
        return False, {"error": msg}
    # tvly --json returns JSON; plain text otherwise. Try JSON first.
    out = (proc.stdout or "").strip()
    if not out:
        return False, {"error": "Tavily returned empty output"}
    try:
        return True, json.loads(out)
    except Exception:
        return True, {"output": out}


def search(query, max_results=5):
    """Web search. Returns dict with 'results' list."""
    ok, data = _run(["search", query, "--max-results", str(max_results), "--json"], timeout=45)
    if not ok:
        return data
    results = data.get("results", []) if isinstance(data, dict) else []
    return {
        "type": "search",
        "query": query,
        "results": results,
        "took": data.get("took") if isinstance(data, dict) else None,
    }


def research(topic):
    """Deep multi-source research report. Returns dict with 'report' and sources."""
    ok, data = _run(["research", topic, "--json"], timeout=180)
    if not ok:
        return data
    # tvly research returns a report string or a structured object
    if isinstance(data, dict):
        report = data.get("report") or data.get("output") or data.get("answer") or ""
        sources = data.get("sources") or data.get("results") or data.get("urls") or []
        return {"type": "research", "topic": topic, "report": report, "sources": sources, "raw": data}
    return {"type": "research", "topic": topic, "report": str(data), "sources": []}


def extract(url):
    """Extract readable content from a URL."""
    ok, data = _run(["extract", url, "--json"], timeout=60)
    if not ok:
        return data
    if isinstance(data, dict):
        return {"type": "extract", "url": url, "content": data.get("content") or data.get("output") or "", "raw": data}
    return {"type": "extract", "url": url, "content": str(data)}


def status():
    return {"available": available(), "cli": _cli()}
