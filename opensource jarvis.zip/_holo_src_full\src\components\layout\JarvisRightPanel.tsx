/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Activity,
  Camera,
  CameraOff,
  MessageSquare,
  FileText,
  FolderOpen,
  Globe,
  Trash2,
  Cpu,
  Database,
  HardDrive,
  Flame,
  Radio,
} from 'lucide-react';
import { JarvisEvent, SystemTelemetry } from '../../types/jarvis';
import { soundFx } from '../../services/soundEffects';

interface JarvisRightPanelProps {
  telemetry: SystemTelemetry;
  events: JarvisEvent[];
  onClearEvents: () => void;
  onQuickAction: (action: string) => void;
}

export const JarvisRightPanel: React.FC<JarvisRightPanelProps> = ({
  telemetry,
  events,
  onClearEvents,
  onQuickAction,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const toggleCamera = async () => {
    soundFx.playSelect();
    if (cameraActive) {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((t) => t.stop());
        videoRef.current.srcObject = null;
      }
      setCameraActive(false);
    } else {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { width: 640, height: 360 },
          });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(() => {});
          }
          setCameraActive(true);
        } else {
          // Simulated optical mode
          setCameraActive(true);
        }
      } catch {
        // Fallback to simulated optical HUD
        setCameraActive(true);
      }
    }
  };

  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  return (
    <aside className="w-72 lg:w-80 bg-slate-950/85 border-l border-cyan-500/20 flex flex-col justify-between shrink-0 select-none overflow-y-auto backdrop-blur-md p-3 space-y-3 font-rajdhani">
      {/* 1. System Status (LIVE) */}
      <div className="bg-slate-950/70 border border-cyan-500/25 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-orbitron font-semibold text-white tracking-wider">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>System Status</span>
          </div>
          <span className="text-[10px] font-rajdhani font-semibold text-emerald-400 px-1.5 py-0.2 rounded bg-emerald-950/60 border border-emerald-500/30">
            LIVE
          </span>
        </div>

        {/* 4 Radial Circular Meters */}
        <div className="grid grid-cols-4 gap-2 text-center">
          {/* CPU */}
          <div className="flex flex-col items-center">
            <CircularMeter
              percent={telemetry.cpuUsage}
              color="#06b6d4"
              size={50}
              stroke={4}
            />
            <span className="text-[10px] text-slate-400 font-semibold mt-1 uppercase">CPU</span>
            <span className="text-xs font-mono-code text-cyan-300 font-bold leading-none">
              {telemetry.cpuUsage}%
            </span>
          </div>

          {/* RAM */}
          <div className="flex flex-col items-center">
            <CircularMeter
              percent={telemetry.ramUsage}
              color="#10b981"
              size={50}
              stroke={4}
            />
            <span className="text-[10px] text-slate-400 font-semibold mt-1 uppercase">RAM</span>
            <span className="text-xs font-mono-code text-emerald-300 font-bold leading-none">
              {telemetry.ramUsage}%
            </span>
          </div>

          {/* DISK */}
          <div className="flex flex-col items-center">
            <CircularMeter
              percent={telemetry.diskUsage}
              color="#f59e0b"
              size={50}
              stroke={4}
            />
            <span className="text-[10px] text-slate-400 font-semibold mt-1 uppercase">DISK</span>
            <span className="text-xs font-mono-code text-amber-300 font-bold leading-none">
              {telemetry.diskUsage}%
            </span>
          </div>

          {/* GPU */}
          <div className="flex flex-col items-center">
            <CircularMeter
              percent={telemetry.gpuUsage}
              color="#a855f7"
              size={50}
              stroke={4}
            />
            <span className="text-[10px] text-slate-400 font-semibold mt-1 uppercase">GPU</span>
            <span className="text-xs font-mono-code text-purple-300 font-bold leading-none">
              {telemetry.gpuUsage}%
            </span>
          </div>
        </div>
      </div>

      {/* 2. Recent Activity */}
      <div className="flex-1 bg-slate-950/70 border border-cyan-500/25 rounded-xl p-3 flex flex-col min-h-[170px]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-orbitron font-semibold text-white tracking-wider">
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>Recent Activity</span>
          </div>
          <button
            onClick={() => {
              onClearEvents();
              soundFx.playChirp();
            }}
            className="text-[10px] text-slate-500 hover:text-slate-300 transition-colors uppercase font-semibold"
          >
            Clear
          </button>
        </div>

        {/* Activity List */}
        <div className="flex-1 space-y-2 overflow-y-auto pr-1 max-h-48 text-xs">
          {events.length === 0 ? (
            <div className="text-center text-slate-500 text-xs py-4">No recent activity</div>
          ) : (
            events.map((evt) => (
              <div
                key={evt.id}
                className="flex items-start gap-2.5 p-2 rounded-lg bg-black/40 border border-slate-800/80 hover:border-cyan-500/30 transition-all"
              >
                <div className="w-5 h-5 rounded-full bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center shrink-0 mt-0.5 text-cyan-400">
                  <Activity className="w-3 h-3" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200 text-xs truncate">
                      {evt.title}
                    </span>
                    <span className="text-[10px] font-mono-code text-slate-500 shrink-0 ml-1">
                      {evt.timeAgo}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-sans truncate leading-tight mt-0.5">
                    {evt.description}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 3. Camera / Gesture View */}
      <div className="bg-slate-950/70 border border-cyan-500/25 rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-orbitron font-semibold text-white tracking-wider">
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span>Camera / Gesture View</span>
          </div>
          <span
            className={`text-[9px] font-mono-code px-1.5 py-0.2 rounded font-semibold ${
              cameraActive
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                : 'bg-slate-900 text-slate-500 border border-slate-700'
            }`}
          >
            {cameraActive ? 'CAMERA ON' : 'CAMERA OFF'}
          </span>
        </div>

        {/* Video Box */}
        <div
          onClick={toggleCamera}
          className="relative w-full h-24 rounded-lg bg-black/80 border border-cyan-500/20 flex flex-col items-center justify-center cursor-pointer hover:border-cyan-400/50 transition-all overflow-hidden group"
        >
          {cameraActive ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 scanlines-overlay pointer-events-none" />
              <div className="absolute top-2 left-2 text-[9px] font-mono-code text-cyan-400 bg-black/60 px-1 rounded">
                OPTICAL FEED • 60 FPS
              </div>
              <div className="absolute bottom-2 right-2 text-[9px] font-mono-code text-emerald-400 bg-black/60 px-1 rounded">
                GESTURE SENSING ACTIVE
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center text-slate-500 group-hover:text-cyan-400 transition-colors">
              <CameraOff className="w-6 h-6 mb-1" />
              <span className="text-xs font-semibold">Camera off</span>
              <span className="text-[10px] text-slate-600">Click to enable</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. Quick Actions */}
      <div className="bg-slate-950/70 border border-cyan-500/25 rounded-xl p-3">
        <div className="text-xs font-orbitron font-semibold text-white tracking-wider mb-2">
          Quick Actions
        </div>
        <div className="grid grid-cols-4 gap-1.5 text-center">
          <button
            onClick={() => onQuickAction('new_chat')}
            className="flex flex-col items-center justify-center p-2 rounded-lg bg-black/40 border border-slate-800 hover:border-cyan-500/40 hover:bg-cyan-950/30 text-slate-300 hover:text-cyan-300 transition-all text-xs"
          >
            <MessageSquare className="w-4 h-4 mb-1" />
            <span className="text-[10px] truncate w-full">New Chat</span>
          </button>

          <button
            onClick={() => onQuickAction('screenshot')}
            className="flex flex-col items-center justify-center p-2 rounded-lg bg-black/40 border border-slate-800 hover:border-cyan-500/40 hover:bg-cyan-950/30 text-slate-300 hover:text-cyan-300 transition-all text-xs"
          >
            <Camera className="w-4 h-4 mb-1" />
            <span className="text-[10px] truncate w-full">Screenshot</span>
          </button>

          <button
            onClick={() => onQuickAction('files')}
            className="flex flex-col items-center justify-center p-2 rounded-lg bg-black/40 border border-slate-800 hover:border-cyan-500/40 hover:bg-cyan-950/30 text-slate-300 hover:text-cyan-300 transition-all text-xs"
          >
            <FolderOpen className="w-4 h-4 mb-1" />
            <span className="text-[10px] truncate w-full">Files</span>
          </button>

          <button
            onClick={() => onQuickAction('browser')}
            className="flex flex-col items-center justify-center p-2 rounded-lg bg-black/40 border border-slate-800 hover:border-cyan-500/40 hover:bg-cyan-950/30 text-slate-300 hover:text-cyan-300 transition-all text-xs"
          >
            <Globe className="w-4 h-4 mb-1" />
            <span className="text-[10px] truncate w-full">Browser</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

// SVG Circular Progress Meter Component
function CircularMeter({
  percent,
  color,
  size,
  stroke,
}: {
  percent: number;
  color: string;
  size: number;
  stroke: number;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percent / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#1e293b"
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          fill="none"
          style={{ transition: 'stroke-dashoffset 0.5s ease' }}
        />
      </svg>
      {/* Subtle center glow */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          boxShadow: `0 0 10px ${color}20`,
        }}
      />
    </div>
  );
}
