/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from 'react';
import {
  SubsystemId,
  SubsystemInfo,
  BrainNode,
  HologramTheme,
  ZoomLevel,
  JarvisEvent,
  SystemTelemetry,
} from './types/jarvis';
import {
  INITIAL_SUBSYSTEMS,
  INITIAL_EVENTS,
  INITIAL_TELEMETRY,
} from './services/jarvisConfig';
import { JarvisHeader } from './components/layout/JarvisHeader';
import { JarvisSidebar, ActiveModule } from './components/layout/JarvisSidebar';
import { JarvisRightPanel } from './components/layout/JarvisRightPanel';
import { JarvisBottomBar } from './components/layout/JarvisBottomBar';
import { BrainCanvas } from './components/brain3d/BrainCanvas';
import { CentralHologramDiagram } from './components/brain3d/CentralHologramDiagram';
import { BrainHUDOverlay } from './components/brain3d/BrainHUDOverlay';
import { NodeDetailDrawer } from './components/brain3d/NodeDetailDrawer';
import { OtherModulesView } from './components/modules/OtherModulesView';
import { soundFx } from './services/soundEffects';

export default function App() {
  // Navigation: Starts directly on 'brain' to show the user the requested Holographic Brain
  const [activeModule, setActiveModule] = useState<ActiveModule>('brain');

  // Subsystems & 3D state
  const [subsystems, setSubsystems] = useState<Record<SubsystemId, SubsystemInfo>>(INITIAL_SUBSYSTEMS);
  const [selectedSubsystemId, setSelectedSubsystemId] = useState<SubsystemId | null>(null);
  const [selectedNode, setSelectedNode] = useState<BrainNode | null>(null);
  const [hologramTheme, setHologramTheme] = useState<HologramTheme>('arc_cyan');
  const [show3dCanvas, setShow3dCanvas] = useState<boolean>(false);
  const [isExploded, setIsExploded] = useState<boolean>(false);
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<ZoomLevel>('overview');
  const [pulseTrigger, setPulseTrigger] = useState<number>(0);

  // Telemetry & Event stream
  const [telemetry, setTelemetry] = useState<SystemTelemetry>(INITIAL_TELEMETRY);
  const [events, setEvents] = useState<JarvisEvent[]>(INITIAL_EVENTS);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Subsystem selection handler
  const handleSelectSubsystem = useCallback(
    (id: SubsystemId) => {
      setSelectedSubsystemId(id);
      const sub = subsystems[id];
      if (sub) {
        setSelectedNode({
          id: `node-${id}-centroid`,
          label: sub.title,
          subsystemId: id,
          position: sub.clusterPosition,
          color: sub.color,
          size: 0.16,
          activityLevel: 0.95,
          isCentroid: true,
          connections: [],
        });
      }
    },
    [subsystems]
  );

  // Node selection handler
  const handleSelectNode = useCallback(
    (node: BrainNode | null) => {
      setSelectedNode(node);
      if (node) {
        setSelectedSubsystemId(node.subsystemId);
      }
    },
    []
  );

  // Stimulate Action Potential from Drawer
  const handleStimulateNode = () => {
    setPulseTrigger((prev) => prev + 1);
    if (selectedSubsystemId) {
      const sub = subsystems[selectedSubsystemId];
      // Increment synaptic rate
      setSubsystems((prev) => ({
        ...prev,
        [selectedSubsystemId]: {
          ...prev[selectedSubsystemId],
          synapticRateHz: Math.min(180, prev[selectedSubsystemId].synapticRateHz + 15),
          recentAction: `Direct neural stimulus injected into ${sub.lobeRegion}`,
        },
      }));

      // Add live event
      const newEvt: JarvisEvent = {
        id: `evt-${Date.now()}`,
        title: `Synaptic stimulus: ${sub.title}`,
        description: `Action potential spike injected into ${sub.lobeRegion}`,
        timestamp: new Date().toLocaleTimeString(),
        timeAgo: 'Now',
        subsystemId: selectedSubsystemId,
        type: 'system',
        status: 'active',
        isLive: true,
      };
      setEvents((prev) => [newEvt, ...prev.slice(0, 19)]);
    }
  };

  // Command submission handler (from voice or input)
  const handleSendMessage = (message: string) => {
    setIsProcessing(true);
    setPulseTrigger((prev) => prev + 1);

    // Map command context to subsystem for realistic routing
    let targetSubId: SubsystemId = 'language';
    const lower = message.toLowerCase();
    if (lower.includes('see') || lower.includes('look') || lower.includes('screen') || lower.includes('vision') || lower.includes('camera')) {
      targetSubId = 'vision';
    } else if (lower.includes('remember') || lower.includes('memory') || lower.includes('chromadb') || lower.includes('fact')) {
      targetSubId = 'memory';
    } else if (lower.includes('plan') || lower.includes('task') || lower.includes('decide') || lower.includes('reason')) {
      targetSubId = 'planning';
    } else if (lower.includes('voice') || lower.includes('speak') || lower.includes('audio') || lower.includes('hear')) {
      targetSubId = 'audio';
    } else if (lower.includes('code') || lower.includes('git') || lower.includes('debug') || lower.includes('syntax')) {
      targetSubId = 'coding';
    } else if (lower.includes('click') || lower.includes('window') || lower.includes('mouse') || lower.includes('keyboard')) {
      targetSubId = 'computer_use';
    } else if (lower.includes('search') || lower.includes('browser') || lower.includes('web') || lower.includes('file')) {
      targetSubId = 'tools';
    }

    const targetSub = subsystems[targetSubId];

    // Add immediate incoming query event
    const userEvt: JarvisEvent = {
      id: `evt-${Date.now()}`,
      title: 'Voice command received',
      description: `"${message.length > 40 ? message.substring(0, 40) + '...' : message}"`,
      timestamp: new Date().toLocaleTimeString(),
      timeAgo: 'Now',
      type: 'voice',
      subsystemId: targetSubId,
      status: 'active',
      isLive: true,
    };
    setEvents((prev) => [userEvt, ...prev]);

    // Simulate JARVIS thinking & response
    setTimeout(() => {
      setIsProcessing(false);
      setPulseTrigger((prev) => prev + 1);

      const respEvt: JarvisEvent = {
        id: `evt-${Date.now() + 1}`,
        title: `JARVIS executed via ${targetSub.title}`,
        description: `Rerouted cognitive pathway to ${targetSub.lobeRegion}`,
        timestamp: new Date().toLocaleTimeString(),
        timeAgo: 'Now',
        type: 'model',
        subsystemId: targetSubId,
        status: 'success',
        isLive: true,
      };
      setEvents((prev) => [respEvt, ...prev.slice(0, 19)]);

      // Update telemetry slightly
      setTelemetry((prev) => ({
        ...prev,
        cpuUsage: Math.min(95, Math.max(12, prev.cpuUsage + (Math.random() > 0.5 ? 4 : -3))),
        gpuUsage: Math.min(98, Math.max(40, prev.gpuUsage + (Math.random() > 0.5 ? 5 : -4))),
      }));

      // Focus that subsystem
      setSelectedSubsystemId(targetSubId);
      soundFx.playAlert();
    }, 600);
  };

  // Quick Action handler
  const handleQuickAction = (action: string) => {
    soundFx.playSelect();
    const actionNames: Record<string, string> = {
      new_chat: 'New Chat Session started',
      screenshot: 'Screen capture dispatched to Vision subsystem',
      files: 'Local D:\\JARVIS_DATA files indexed',
      browser: 'Firecrawl headless browser initialized',
    };
    const title = actionNames[action] || 'Action dispatched';
    const newEvt: JarvisEvent = {
      id: `evt-${Date.now()}`,
      title,
      description: `Executed via JARVIS Core bridge`,
      timestamp: new Date().toLocaleTimeString(),
      timeAgo: 'Now',
      type: 'tool',
      status: 'info',
      isLive: true,
    };
    setEvents((prev) => [newEvt, ...prev.slice(0, 19)]);
    setPulseTrigger((prev) => prev + 1);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 select-none">
      {/* 1. Top Header */}
      <JarvisHeader telemetry={telemetry} />

      {/* 2. Main Middle Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Navigation Sidebar */}
        <JarvisSidebar
          activeModule={activeModule}
          onSelectModule={(mod) => {
            setActiveModule(mod);
            if (mod !== 'brain') {
              setSelectedSubsystemId(null);
              setSelectedNode(null);
            }
          }}
        />

        {/* Center Canvas or Module View */}
        <main className="flex-1 relative overflow-hidden flex flex-col bg-slate-950">
          {activeModule === 'brain' ? (
            <div className="relative w-full h-full">
              {/* Central Holographic Visualizer: 3D Three.js WebGL (if toggled on) or 2D Hologram Diagram */}
              {show3dCanvas ? (
                <BrainCanvas
                  subsystems={subsystems}
                  selectedSubsystemId={selectedSubsystemId}
                  onSelectSubsystem={handleSelectSubsystem}
                  onSelectNode={handleSelectNode}
                  hologramTheme={hologramTheme}
                  isExploded={isExploded}
                  isRotating={isRotating}
                  onZoomLevelChange={setZoomLevel}
                  pulseTrigger={pulseTrigger}
                />
              ) : (
                <CentralHologramDiagram
                  subsystems={subsystems}
                  selectedSubsystemId={selectedSubsystemId}
                  onSelectSubsystem={handleSelectSubsystem}
                />
              )}

              {/* HUD Overlay with Flanking Cards & Telemetry Strip */}
              <BrainHUDOverlay
                subsystems={subsystems}
                selectedSubsystemId={selectedSubsystemId}
                onSelectSubsystem={handleSelectSubsystem}
                hologramTheme={hologramTheme}
                onChangeTheme={setHologramTheme}
                isExploded={isExploded}
                onToggleExplode={() => setIsExploded(!isExploded)}
                isRotating={isRotating}
                onToggleRotate={() => setIsRotating(!isRotating)}
                zoomLevel={zoomLevel}
                telemetry={telemetry}
                show3dCanvas={show3dCanvas}
                onToggle3dCanvas={() => setShow3dCanvas(!show3dCanvas)}
              />

              {/* Node / Subsystem Inspection Drawer */}
              {selectedSubsystemId && (
                <NodeDetailDrawer
                  subsystem={subsystems[selectedSubsystemId]}
                  node={selectedNode}
                  onClose={() => {
                    setSelectedSubsystemId(null);
                    setSelectedNode(null);
                  }}
                  onStimulateNode={handleStimulateNode}
                />
              )}
            </div>
          ) : (
            <OtherModulesView
              module={activeModule}
              onOpenBrain={() => setActiveModule('brain')}
            />
          )}
        </main>

        {/* Right Telemetry & Status Panel */}
        <JarvisRightPanel
          telemetry={telemetry}
          events={events}
          onClearEvents={() => setEvents([])}
          onQuickAction={handleQuickAction}
        />
      </div>

      {/* 3. Bottom Command Bar */}
      <JarvisBottomBar
        onSendMessage={handleSendMessage}
        isProcessing={isProcessing}
      />
    </div>
  );
}
