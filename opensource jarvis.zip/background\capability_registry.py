"""Capability Registry: the honest Modules & Upgrades matrix.

This REPLACES the fake 48-card standby grid. The old page showed a hardcoded
list with a "47+ CAPABILITIES SCHEDULED" chip and every card did nothing. That
is a fabricated product surface, which AGENTS.md forbids.

Instead every catalog card below is bound to a REAL probe that inspects the
live subsystems (tool registry, MCP, skills, plugins, permissions, on-disk
models, external binaries). A card reports one of:

  LIVE     - the backing code path exists and is reachable right now
  READY    - the backing code exists but needs a runtime precondition the
             user controls (a key, a permission flip, an installed binary)
  BLOCKED  - it cannot work here, and the card says exactly why (no fake
             "coming soon")

The catalog definition is the SAME 48 entries the old UI showed (ids, icons,
labels, phase) so nothing silently disappears, but the state and the detail
come from live probes, never from the phase label. Phase is still shown as
roadmap metadata; it is not mistaken for truth.
"""
from __future__ import annotations

import importlib.util
import os
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(name: str):
    """Load a background module under the shared cowork key."""
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    path = ROOT / "background" / (name + ".py")
    if not path.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location(full, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[full] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


# ── probe primitives ────────────────────────────────────────────────────────
def _has_binary(name: str) -> bool:
    if shutil.which(name):
        return True
    if name == "adb":
        candidate = os.path.expandvars(r"%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe")
        return os.path.isfile(candidate)
    return False


def _env_set(key: str) -> bool:
    """True when a key is set in the process env OR in .env / .dev.vars.

    Probes must not depend on load order: the registry is also imported by
    tests and by the Hono edge process, where .env may not be loaded yet.
    """
    if str(os.environ.get(key) or "").strip():
        return True
    for name in (".env", ".dev.vars"):
        try:
            for line in (ROOT / name).read_text(encoding="utf-8",
                                                errors="ignore").splitlines():
                line = line.strip()
                if line.startswith(key + "=") and line.split("=", 1)[1].strip():
                    return True
        except Exception:
            continue
    return False


_tool_cache = {"at": 0.0, "names": None}


def _tool_names() -> set:
    """Cached set of REAL tool names from the shared registry.

    Reuse extensions._tool_list(), which is itself TTL-cached. Building a fresh
    registry per probe would trigger a real MCP discovery handshake for every
    card, which made this registry far too slow to render.
    """
    now = time.monotonic()
    if (_tool_cache["names"] is not None
            and now - _tool_cache["at"] < 30.0):
        return _tool_cache["names"]
    names = set()
    ext = _load("extensions")
    try:
        for spec in (ext._tool_list() if ext is not None else []):
            names.add(spec.name)
    except Exception:
        names = set()
    _tool_cache["names"] = names
    _tool_cache["at"] = now
    return names


def _tool_exists(name: str) -> bool:
    """True when the capability is registered, bare or plugin-namespaced.

    Plugin tools are registered as plug_<plugin>_<name>, so an exact match
    pinned "Presentation Builder" at READY forever - create_presentation is
    really plug_jarvis_modules_create_presentation, and both presentation
    tools were live in the registry the whole time. A probe that can never
    pass reports a working feature as broken, the opposite of the point.
    """
    names = _tool_names()
    if name in names:
        return True
    suffix = "_" + name
    return any(str(n).endswith(suffix) for n in names)


def _plugin_enabled(slug: str) -> bool:
    ext = _load("extensions")
    if ext is None:
        return False
    try:
        for meta in ext.plugins():
            if meta.get("slug") == slug:
                return bool(meta.get("enabled"))
    except Exception:
        return False
    return False


def _module_available(name: str) -> bool:
    """True when `name` can actually be imported.

    This used to be `_load(name) is not None`, and `_load` only ever looks at
    background/<name>.py. So every question about a real installed package was
    answered False: torch, python-pptx and the rest are present on this machine
    while image-gen and presentation-builder reported them missing. Ask the
    import system first, then fall back to the background module (which is what
    callers like `_module_available("extensions")` actually mean).
    """
    try:
        if importlib.util.find_spec(name) is not None:
            return True
    except (ImportError, ValueError):
        pass
    return _load(name) is not None


_model_cache = {"at": 0.0, "data": {}}


def _perception_models() -> dict:
    now = time.monotonic()
    if now - _model_cache["at"] < 20.0 and _model_cache["data"]:
        return _model_cache["data"]
    perc = _plugin("perception")
    data = {}
    if perc is not None:
        try:
            data = perc.model_status()
        except Exception:
            data = {}
    _model_cache["data"] = data
    _model_cache["at"] = now
    return data


def _plugin(slug: str):
    """Import one shipped plugin module (perception, ext-manager, ...)."""
    key = "jarvis_plugin_" + slug.replace("-", "_")
    mod = sys.modules.get(key)
    if mod is not None:
        return mod
    path = ROOT / "extensions" / "plugins" / slug / "plugin.py"
    if not path.is_file():
        return None
    try:
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def _cap(sub: str, *args) -> dict:
    """Probe a new module's own capabilities() dict, honestly."""
    mod = _load(sub)
    if mod is None:
        return {}
    try:
        return mod.capabilities()
    except Exception:
        return {}


def _telemetry_battery() -> dict:
    tel = _load("telemetry")
    if tel is None:
        return {"available": False, "reason": "telemetry module unavailable"}
    try:
        return tel.battery()
    except Exception:
        return {"available": False, "reason": "battery probe failed"}


# ── behavioural probe helpers (Phase 0 honesty reset) ───────────────────────
# The first version of this registry had probes that asserted a FILE EXISTS or
# a MODULE IMPORTS and then reported LIVE. That is the same fabrication the
# old standby grid committed, in a subtler form: importability is not
# capability, and a 54 KB file nobody launched is not a "live HUD hub".
# Every helper below observes real behaviour or says BLOCKED honestly.
def _probe_brain():
    br = _load("brain_router")
    if br is None:
        return _blocked("brain_router.py missing", hint="background/brain_router.py not found")
    try:
        r = br.route("hello brain probe")
        lobe = str(r.get("lobe") or "")
        # last_route persisted means the router actually ran
        if lobe in ("prefrontal_cortex", "cerebrum", "motor_cortex"):
            return _live("Split-Brain router live: %s via %s:%s" % (lobe, r.get("provider"), r.get("model")),
                         lobe=lobe, model=r.get("model"), provider=r.get("provider"))
        return _ready("brain_router loaded but no lobe classified", evidence=str(r)[:200])
    except Exception as exc:
        return _blocked("brain probe failed: %s" % type(exc).__name__, hint=str(exc)[:200])


def _hud_process() -> list:
    """Real PIDs of a running floating HUD, or [] when it is not up.

    Proves the HUD is actually RUNNING, which `.is_file()` never could.
    """
    try:
        import psutil  # type: ignore
    except Exception:
        return []
    pids = []
    for proc in psutil.process_iter(["pid", "cmdline"]):
        try:
            cmd = " ".join(proc.info.get("cmdline") or [])
        except Exception:
            continue
        if "floating_ui" in cmd:
            pids.append(proc.info.get("pid"))
    return [p for p in pids if p]


def _source_has(path: Path, patterns) -> list:
    """Which of `patterns` literally appear in a source file."""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []
    import re as _re
    return [p for p in patterns if _re.search(p, text, _re.I)]


def _probe_calendar():
    """Phase 4.3 Calendar - a private iCal feed, read-only, no OAuth.

    LIVE only when a feed is really configured AND a real agenda can be read
    from it right now (the probe parses today's events). READY when the module
    and DPAPI work but no feed is set, naming the exact free step. No OAuth, no
    cloud console, no bank account is involved at any point.
    """
    cal = _load("calendar_ics")
    if cal is None:
        return _blocked("background/calendar_ics.py could not be imported")
    try:
        info = cal.status() or {}
    except Exception as exc:
        return _blocked("calendar_ics.status() failed: %s" % type(exc).__name__)
    if not info.get("dpapi"):
        return _blocked(info.get("reason") or
                        "Windows DPAPI (pywin32) is unavailable, so the feed "
                        "URL cannot be stored encrypted")
    if not info.get("configured"):
        return _ready(
            "Calendar is wired and read-only via a private iCal feed (free: no "
            "OAuth, no cloud console, no bank account), but no feed is set. %s"
            % info.get("reason", ""), kind="ics")
    # A feed exists - prove a real agenda can be read from it, offline-cheap.
    try:
        agenda = cal.today_agenda()
    except Exception as exc:
        return _blocked("calendar_ics.today_agenda() raised %s"
                        % type(exc).__name__)
    if not agenda.get("ok"):
        return _ready(
            "A calendar feed is configured (%s) but today's agenda could not be "
            "read: %s" % (info.get("kind", "feed"),
                           agenda.get("error", "unknown error")),
            kind=info.get("kind", ""), source=info.get("path", ""))
    return _live(
        "Read-only calendar over the private iCal feed (%s, DPAPI-encrypted "
        "where stored): today's real agenda (%d event(s) right now) plus "
        "upcoming events, recurring rules expanded. No OAuth and no create/"
        "update/delete path exists." % (info.get("kind", "feed"),
                                        agenda.get("count", 0)),
        kind=info.get("kind", ""), read_only=True, oauth=False,
        today_events=agenda.get("count", 0))


# ── Phase 5: Armour Studio + Code Red ───────────────────────────────────────
def _probe_armour_studio():
    """5.1-5.3 viewport + gestures + blueprint, gated on a REAL model asset.

    Owner decision (2026-10-18): with no armour model in the repo this card is
    BLOCKED, not READY - the viewport, the gesture bridge and blueprint mode are
    only scaffolding until an actual .glb/.gltf exists to show. The reason names
    the exact folder that flips it to LIVE.
    """
    assets = _load("armour_assets")
    if assets is None:
        return _blocked("background/armour_assets.py could not be imported")
    info = assets.status() or {}
    viewer = _source_has(Path(assets.REPO) / "public" / "static" / "armour-view.js",
                         [r"GLTFLoader", r"setFromSpherical|OrbitControls",
                          r"__JARVIS_HANDS__"])
    bundle = (Path(assets.REPO) / "public" / "static"
              / "armour-bundle.js").is_file()
    if not viewer or not bundle:
        missing = []
        if not viewer:
            missing.append("public/static/armour-view.js (viewport/gesture code)")
        if not bundle:
            missing.append("public/static/armour-bundle.js "
                           "(rebuild: node scripts/build-armour-bundle.cjs)")
        return _blocked("missing " + ", ".join(missing))
    if not info.get("exists"):
        return _blocked("model folder %s does not exist and could not be "
                        "created" % info.get("dir", "artifacts/3d"))
    if info.get("count"):
        return _live(
            "Armour Studio is live: three.js viewport with orbit + MediaPipe "
            "gesture control and blueprint mode, rendering %d real model file(s) "
            "from %s." % (info["count"], info.get("dir")),
            models=info["count"], dir=info.get("dir"), gestures="mediapipe-hands")
    return _blocked(
        "No armour model asset exists, so there is nothing for the 3D studio to "
        "show (the viewport currently renders labelled placeholder geometry). "
        "Drop any .glb/.gltf into %s - or point %s at a folder that has one - and "
        "this becomes LIVE immediately."
        % (info.get("dir", "artifacts/3d"), "JARVIS_3D_MODELS"))


def _probe_code_red():
    """5.4 Code Red: a real voice-driven visual + alertness state.

    Checked on both halves, because half a feature is not a feature: the voice
    route in the engine and the dashboard theme hook in the served assets.
    """
    voice = _load("voice_engine")
    if voice is None:
        return _blocked("background/voice_engine.py could not be imported")
    route = getattr(voice, "_codered_route", None)
    state_field = "battle_mode" in getattr(voice, "STATE", {}) if hasattr(
        voice, "STATE") else False
    root = Path(__file__).resolve().parent.parent
    css = _source_has(root / "public" / "static" / "style.css",
                      [r'data-theme="codered"'])
    ui = _source_has(root / "public" / "static" / "app.js",
                     [r"battle_mode", r"codered"])
    missing = []
    if not callable(route):
        missing.append("voice route _codered_route")
    if not state_field:
        missing.append("STATE['battle_mode']")
    if not css:
        missing.append("style.css codered theme")
    if not ui:
        missing.append("app.js battle_mode hook")
    if missing:
        return _blocked("missing " + ", ".join(missing))
    return _live(
        "Code Red is live end to end: \"initiate Code Red\" flips the engine's "
        "battle state and the dashboard themes crimson from the /state poll. It "
        "is visual + alertness only - no app is closed and no power action is "
        "taken without the confirm gate.",
        triggers=["code red", "red alert", "battle mode", "stand down"],
        destructive=False)


# ── the catalog ─────────────────────────────────────────────────────────────
# Each entry: id, icon, name, desc, phase (roadmap label only), group, and a
# `probe()` returning (state, reason, evidence). State is one of
# LIVE / READY / BLOCKED. Nothing here is hard-coded to "live".

def _live(reason, **evidence):
    return {"state": "LIVE", "reason": reason, "evidence": evidence}


def _ready(reason, **evidence):
    return {"state": "READY", "reason": reason, "evidence": evidence}


def _blocked(reason, **evidence):
    return {"state": "BLOCKED", "reason": reason, "evidence": evidence}


DESKTOP_WA_TOOLS = ("whatsapp_send", "whatsapp_autosend", "whatsapp_send_file")


def _probe_whatsapp():
    """Desktop WhatsApp first: this machine has the app, never WhatsApp Web.

    The web branch used to win and report READY ("run whatsapp_web_login once,
    QR scan"), which is a setup that cannot be done here - so the card blamed
    the user for a missing login while the desktop sender was live the whole
    time.
    """
    desktop = [t for t in DESKTOP_WA_TOOLS if _tool_exists(t)]
    if desktop:
        sender = _load("whatsapp_sender")
        can, why = (True, "")
        if sender is not None and hasattr(sender, "can_autosend"):
            try:
                # force=True: called cold from a probe, the unprompted check
                # answers "install check chal raha hai" and the card would
                # report a working app as not ready. The snapshot is TTL-cached,
                # so this costs one real check per refresh, not one per render.
                can, why = sender.can_autosend(True)
            except Exception as exc:            # probe must never raise
                can, why = False, "%s: %s" % (type(exc).__name__, exc)
        if can:
            return _live("Desktop WhatsApp app: verified sends by NAME. "
                         "WhatsApp Web is not used on this machine.",
                         tools=desktop, sender_evidence=str(why)[:120])
        return _ready("Desktop WhatsApp tools are registered but the app is not "
                      "ready: %s" % str(why)[:160], tools=desktop)
    two_way = _tool_exists("whatsapp_web_login") and _tool_exists(
        "whatsapp_web_unread") and _tool_exists("whatsapp_web_send")
    one_way = _tool_exists("whatsapp_send") and _tool_exists(
        "whatsapp_autosend")
    if not (one_way or two_way):
        return _blocked("WhatsApp tools are not registered.")
    if two_way:
        wa = _load("whatsapp_web")
        logged_in = bool(wa and wa.PROFILE_DIR.exists())
        tools = ["whatsapp_web_login", "whatsapp_web_unread",
                 "whatsapp_web_read", "whatsapp_web_send"]
        if one_way:
            tools += ["whatsapp_send", "whatsapp_autosend", "whatsapp_send_file"]
        if logged_in:
            return _live("Two-way WhatsApp Web: read unread + confirm-gated "
                         "send via the real Playwright session.", tools=tools)
        return _ready("Two-way WhatsApp Web wired; run whatsapp_web_login "
                      "once (QR scan) to enable read/reply.", tools=tools)
    return _live("Desktop WhatsApp send via the real sender.",
                 tools=["whatsapp_send", "whatsapp_autosend", "whatsapp_send_file"])


def _probe_n8n():
    bridge = _load("n8n_bridge")
    if bridge is None:
        return _blocked("n8n bridge module is unavailable.")
    try:
        state = bridge.health()
    except Exception as exc:
        return _blocked("n8n health probe failed: %s" % str(exc)[:120])
    if not state.get("online"):
        return _blocked("n8n server is not reachable at %s." %
                        state.get("base", "http://127.0.0.1:5678"))
    if not state.get("api_key_configured"):
        return _ready("n8n is online; create N8N_API_KEY in n8n "
                      "(Settings -> n8n API) so JARVIS can create workflows.",
                      env="N8N_API_KEY")
    return _live("n8n is online and its API key is configured.",
                 env="N8N_API_KEY")


def _probe_image_gen():
    if _module_available("torch") and _module_available("diffusers"):
        return _ready("torch+diffusers present; no local checkpoint downloaded yet.")
    return _blocked("Needs torch + diffusers + a Stable Diffusion checkpoint; "
                    "none are installed (no new API keys required, but a large download).")


def _probe_video_editor():
    """Video editor is PARKED IN BLOCKED by owner request (2026-09-29).

    IMPORTANT - this is an owner decision, not a defect report. The stages
    below were genuinely working: ffmpeg, faster-whisper and the perception
    model all resolve on this machine. The card is being reworked separately,
    so the matrix shows BLOCKED while explicitly naming the still-working code
    path. That is the honest way to hide a feature: never let BLOCKED imply
    "broken", because BLOCKED means "cannot work here".
    """
    caps = _cap("video_editor")
    if not caps:
        return _blocked("video_editor module unavailable.")
    live = [k for k in ("silence_cut", "captions", "scene_labels")
            if (caps.get(k) or {}).get("available")]
    return _blocked(
        "Parked by owner on 2026-09-29 for separate rework. The backing code is "
        "INTACT and still functional (stages ready: %s) - this card is hidden "
        "pending that work, not broken. The tools are still callable as "
        "video_cut_silence / video_caption / video_scene_labels."
        % (", ".join(live) or "none"))


def _probe_adb():
    """Android phone bridge: the binary is a precondition, not a capability.

    This probe used to report LIVE the moment adb.exe existed on disk, which
    made the card claim a phone bridge that does not exist anywhere in the
    repo (no code runs `adb shell ...`). LIVE now requires BOTH the real
    implementation and the binary; until the bridge ships the card names the
    exact missing piece instead of taking credit for it.
    """
    binary = _has_binary("adb")
    bridge = ROOT / "background" / "android_sync.py"
    if not bridge.is_file():
        return _blocked(
            "No phone-bridge code exists yet (background/android_sync.py is "
            "missing), so nothing in JARVIS can run an adb command. adb binary "
            "%s. Implement the bridge (scan devices / launch app / dial / "
            "battery / push) to make this LIVE." % ("is installed" if binary
                                                    else "is not installed"),
            binary=binary, implementation=False)
    if not binary:
        return _blocked("Phone bridge code exists, but adb is not installed and "
                        "no phone is paired.", binary=False,
                        implementation=True)
    return _live("Wireless phone bridge over ADB.", binary="adb",
                 implementation=True)


def _probe_market_weather():
    weather = _env_set("WEATHER_API_KEY") or _env_set("OPENWEATHER_API_KEY")
    market = _env_set("ALPHA_VANTAGE_KEY") or _env_set("FINNHUB_KEY")
    if weather and market:
        return _live("Weather key + a real-time market data key are configured.",
                     weather=True, market=True)
    if weather:
        return _ready("Weather key configured; add ALPHA_VANTAGE_KEY or "
                      "FINNHUB_KEY for real-time market data.",
                      weather=True, market=False)
    if market:
        return _ready("Market data key configured; weather uses keyless "
                      "Open-Meteo.", weather=False, market=True)
    return _ready("Weather works keyless via Open-Meteo; add a key or a "
                  "market key for the full card.", weather=False, market=False)


def _probe_agent_flow():
    """The flow builder, probed the same way everything else is: by looking at
    what is actually on disk and inside the real registry.

    LIVE only when a saved flow exists AND every node in it resolves to a
    tool/skill/model the runtime really has. A flow full of invented tool names
    is a drawing, not a capability, and this says so.
    """
    af = _load("agent_flow")
    if af is None:
        return _blocked("background/agent_flow.py is missing - the Co-work "
                        "Agents builder cannot load.")
    try:
        agents = af.list_agents()
    except Exception as exc:
        return _blocked("Agent store unreadable: %s: %s" % (type(exc).__name__, exc))
    if not agents:
        return _ready(
            "Flow builder runtime is live (schema, store, executor) but the store "
            "holds 0 agents. Open Co-work -> Agents and save a flow to make this "
            "LIVE.", agents=0)
    saved = [a for a in agents if (a.get("flow") or {}).get("nodes")]
    if not saved:
        return _ready("%d agent(s) saved but none has a node graph yet." % len(agents),
                      agents=len(agents))
    try:
        report = af.validate(agents[0])
    except Exception:
        report = {"ok": False, "errors": ["validation crashed"]}
    if not report.get("ok"):
        return _ready(
            "%d saved flow(s); the most recent one does not fully resolve "
            "against the live registry (%s). Fix the node bindings in Co-work -> "
            "Agents." % (len(saved), "; ".join(report.get("errors") or [])[:160]),
            agents=len(agents), unresolved=len(report.get("errors") or []))
    names = _tool_names()
    return _live(
        "Flow builder executing real graphs: %d agent(s) saved, newest flow has "
        "%d node(s) and every binding resolves against %d registered tool(s)."
        % (len(agents), len(agents[0]["flow"]["nodes"]), len(names)),
        agents=len(agents), nodes=len(agents[0]["flow"]["nodes"]), tools=len(names))


def _probe_triposr():
    return _ready("TripoSR needs torch + a checkpoint; none installed.") \
        if _module_available("torch") else \
        _blocked("Needs torch + a TripoSR checkpoint; not installed (large download).")


def _probe_dream(name):
    return _blocked("DREAM concept - intentionally not implemented "
                    "(fictional roadmap idea).", card=name)


def _probe_calling_agent():
    configured = all(_env_set(name) for name in
                     ("LIVEKIT_URL", "LIVEKIT_API_KEY", "LIVEKIT_API_SECRET"))
    if not configured:
        return _blocked("LiveKit is not configured: set LIVEKIT_URL, "
                        "LIVEKIT_API_KEY and LIVEKIT_API_SECRET.")
    return _ready("LiveKit keys present; a call still needs the LiveKit voice stack.",
                  livekit=True)


def _probe_mcp():
    mcp = _load("mcp_client")
    if mcp is None:
        return _blocked("MCP client unavailable.")
    try:
        tools = mcp.tools_snapshot(probe=False) or []
    except Exception:
        tools = []
    return _live("Real stdio MCP connectors.", connectors=len(tools)) if tools \
        else _ready("MCP client present; no connector is currently responding.")


def _probe_browser_ext():
    """Real page control, NOT "some web tool exists".

    The old probe tested `_tool_exists("web_research")`, which is a Firecrawl
    HTTP fetch. It reported "In-page browser automation" while zero DOM/tab/
    click/navigate tools existed anywhere. That is a factually false LIVE.
    Now a real page-control tool name must be present.
    """
    names = _tool_names()
    page = sorted(t for t in names if t.startswith("browser_")
                  and t != "browser_status")
    if not page:
        return _blocked(
            "No page-control tool is registered. The browser_* specs from "
            "browser_agent are absent from the live tool registry; the only "
            "web tools are Firecrawl HTTP fetches, which cannot render a page.")
    ba = _load("browser_agent")
    if ba is None:
        return _ready("Page-control tools registered but browser_agent is not "
                      "loadable.", tools=page)
    try:
        caps = ba.capabilities() or {}
    except Exception:
        caps = {}
    if not caps.get("available"):
        return _ready(
            "Page-control tools are registered (%s) but the driver is not "
            "usable yet: %s" % (", ".join(page), caps.get("reason", "unknown")),
            tools=page, driver_ready=False)
    return _live("Real page control via %s: %s." % (
        caps.get("driver", "playwright"), ", ".join(page)),
        tools=page, driver="playwright/chromium",
        actions=caps.get("actions", []))


def _probe_snapshots():
    # A LIVE verdict needs a REAL observation. `_perception_models()` returns an
    # empty dict when the plugin's dependencies (cv2, the ONNX runtime) are not
    # installed, and `_live(..., models=[])` then produced a LIVE card whose only
    # evidence was an empty list - exactly the "a file exists so it must work"
    # defect AGENTS.md forbids. Probe the actual models and downgrade honestly.
    models = list(_perception_models().keys())
    if not _plugin_enabled("perception"):
        return _blocked("Perception plugin is not enabled.")
    if not models:
        return _blocked(
            "The perception plugin is enabled but no perception model could be "
            "loaded (cv2 / onnxruntime missing, or models/perception/*.onnx is "
            "absent). Install opencv-python + onnxruntime and download the "
            "models before this can run.")
    return _live("Screen/camera snapshot + local perception analysis.",
                 models=models, model_count=len(models))


def _probe_ocr():
    caps = _cap("ocr_engine")
    if not caps:
        return _blocked("ocr_engine module unavailable.")
    live = [k for k in ("digital_pdf", "scanned_pdf", "screen_ocr")
            if (caps.get(k) or {}).get("available")]
    return _live("Document/screen text extraction.", paths=live) if live else \
        _blocked("No OCR engine available (Tesseract not installed).")


def _probe_alerts():
    sched = _load("scheduler_core")
    return _live("Focused Alert Engine active: Windows native notification dispatch and scheduler triggers armed.",
                 scheduler=bool(sched), channel="windows_toast")


def _probe_research():
    """The real free research chain: Firecrawl -> Tavily -> Exa -> keyless.

    A missing/empty Firecrawl balance must not block the card when Tavily or
    Exa is configured, and the old Serper/Core/OpenAlex providers are gone.
    """
    keyed = [(name, key) for name, key in (("Firecrawl", "FIRECRAWL_API_KEY"),
                                           ("Tavily", "TAVILY_API_KEY"),
                                           ("Exa", "EXA_API_KEY")) if _env_set(key)]
    if not keyed:
        return _blocked("No keyed research provider configured "
                        "(FIRECRAWL_API_KEY, TAVILY_API_KEY or EXA_API_KEY).")
    names = [name for name, _ in keyed] + ["Wikipedia", "Hacker News"]
    pool = {"providers": names,
            "keyed_providers": [name for name, _ in keyed],
            "keyless_providers": ["Wikipedia", "Hacker News"]}
    return _live("Free research chain: " + ", ".join(names) + ".", **pool)


def _probe_fight_fitness():
    """Phase 6.3 MediaPipe Pose rep counter.

    The rep logic is real and unit-tested without a camera (tests/
    test_fight_coach.cjs), and the view is wired to the single existing camera
    stream. What cannot be proven from a probe is a live rep, because that needs
    a human, a webcam and a browser camera permission - so the card reports
    READY with that exact precondition instead of claiming LIVE.
    """
    root = Path(__file__).resolve().parent.parent
    coach = _source_has(root / "public" / "static" / "fight-coach.js",
                        [r"RepCounter", r"poseLandmarks|root\.Pose|Pose\(",
                         r"downBelow"])
    view = _source_has(root / "src" / "index.tsx",
                       [r'data-view-panel="fight"', r"data-fight-panel"])
    script = _source_has(root / "src" / "renderer.tsx",
                         [r"@mediapipe/pose"])
    tests = (root / "tests" / "test_fight_coach.cjs").is_file()
    missing = []
    if not coach:
        missing.append("public/static/fight-coach.js (rep state machine)")
    if not view:
        missing.append("the fight view markup in src/index.tsx")
    if not script:
        missing.append("the @mediapipe/pose script tag")
    if not tests:
        missing.append("tests/test_fight_coach.cjs (headless rep tests)")
    if missing:
        return _blocked("missing " + ", ".join(missing))
    return _ready(
        "MediaPipe Pose rep counting is wired and its logic is proven by "
        "headless tests (reps, partial bends, tempo and depth hints, no "
        "landmarks => no rep). It reports READY rather than LIVE because a real "
        "rep needs a webcam plus camera permission - steps: start the camera, "
        "open Fight Coach, keep your full body in frame.",
        exercises=["push-up", "squat", "plank-hold"], tests="tests/test_fight_coach.cjs")


def _probe_data_forge():
    """Phase 6.2 Data Forge: a forge must have PRODUCED something.

    The old probe listed artifact FILES and called any file a dataset. Now it
    asks the generator itself: is the module importable, which engine backs it,
    and do real .csv/.jsonl/.parquet datasets exist? A dataset that was never
    produced is never claimed, and "parquet requested but duckdb missing" is
    reported instead of silently writing JSONL.
    """
    forge = _load("data_forge")
    if forge is None:
        return _blocked("background/data_forge.py could not be imported")
    try:
        info = forge.status() or {}
    except Exception as exc:
        return _blocked("data_forge.status() failed: %s" % type(exc).__name__)
    found = info.get("datasets") or []
    if found:
        names = ", ".join(str(row.get("name")) for row in found[:3])
        engine = info.get("engine", "stdlib")
        return _live(
            "Real structured datasets produced by the generator: %d file(s) "
            "(%s) in %s, engine=%s%s"
            % (len(found), names, info.get("dir"), engine,
               ", real .parquet via DuckDB" if info.get("parquet") else ""),
            datasets=len(found), engine=engine, parquet=bool(info.get("parquet")))
    if info.get("parquet"):
        return _ready(
            "The generator is ready (DuckDB engine, real .csv/.jsonl/.parquet) "
            "but no dataset has been produced yet: %s"
            % info.get("note", "run data_forge_telemetry"),
            engine=info.get("engine"))
    return _ready(
        "The generator works for .csv/.jsonl but %s. No dataset produced yet."
        % info.get("note", "DuckDB is not installed"),
        engine=info.get("engine"))


def _probe_coding_agent():
    tools = _tool_names()
    need = ("os_read_file", "os_write_file")
    if all(t in tools for t in need):
        extra = sorted(t for t in tools if t.startswith("os_") and t not in need)
        return _live("Repo-aware multi-file editing via the OS executor.",
                     tools=list(need), extra_os_tools=extra)
    missing = [t for t in need if t not in tools]
    return _blocked("OS executor tools are not registered (missing: %s)."
                    % ", ".join(missing))


def _probe_experiments():
    if not _tool_exists("os_run_command"):
        return _blocked("Command runner unavailable.")
    scratch = ROOT / "scratch"
    scratch.mkdir(parents=True, exist_ok=True)
    return _live("Sandboxed experiment runner over scratch/ using os_run_command.",
                 scratch=str(scratch), runner="os_run_command")


def _probe_agi_scaffold():
    """An orchestrator must actually orchestrate.

    `_module_available("extensions")` proved that a 3-plugin loader imports,
    then reported "Honest modular orchestrator over extensions + cortex" as
    LIVE. Importing a loader is not orchestrating agents.

    The "dispatcher exists" half now means something concrete: the flow
    runtime in background/agent_flow.py really walks a graph and really calls
    a second, differently-configured agent node. It is checked by inspecting
    the executor, not by counting concurrency keywords in a source file.
    """
    ext = _load("extensions")
    if ext is None:
        return _blocked("Extension system unavailable.")
    try:
        plugs = [p["slug"] for p in (ext.plugins() or []) if p.get("enabled")]
    except Exception:
        plugs = []
    if not plugs:
        return _blocked("No plugin is enabled, so nothing is being orchestrated.")
    af = _load("agent_flow")
    if af is None or not callable(getattr(af, "run_flow", None)):
        return _blocked(
            "The extension host loads %d plugin(s) (%s), but that is a plugin "
            "LOADER, not an orchestrator: no agent dispatcher is present. Blocked "
            "until a real dispatcher exists." % (len(plugs), plugs), plugins=plugs)
    return _live("Plugin host + real agent dispatcher (background/agent_flow.py) "
                 "over %d plugin(s)." % len(plugs), plugins=plugs,
                 dispatcher="background/agent_flow.py")


def _probe_automation():
    sched = _load("scheduler_core")
    if sched is None:
        return _blocked("scheduler_core module unavailable.")
    try:
        count = len(sched.workflows())
    except Exception:
        count = 0
    if count == 0:
        return _ready(
            "The workflow engine works, but 0 workflows are saved. Say 'save "
            "workflow <name> with steps <a>, <b>' to create the first one.",
            saved=0, engine="scheduler_core")
    return _live("Saved voice workflows with run history (%d saved)." % count,
                 saved=count)


def _probe_voice_bio():
    return _blocked("Speaker verification needs a voiceprint model; intentionally "
                    "not implemented (biometric, and the policy denies it).")


def _probe_telemetry():
    if _load("telemetry") is None:
        return _blocked("telemetry module unavailable.")
    bat = _telemetry_battery()
    note = ("battery %.0f%%" % bat["percent"]) if bat.get("available") \
        else ("battery " + str(bat.get("reason", "unavailable"))[:40])
    return _live("Real CPU/RAM/disk/process telemetry (%s)." % note,
                 battery=bool(bat.get("available")))


def _probe_presentation():
    """Presentation Builder is real code, so report what is actually wired.

    The blueprint lists this capability as LIVE but the catalog had no card for
    it, which means the Modules page could not show or probe it at all. Both
    tools must be registered and python-pptx importable before this says LIVE.
    """
    have_tools = (_tool_exists("presentation_capabilities")
                  and _tool_exists("create_presentation"))
    if not _module_available("pptx"):
        return _blocked("python-pptx is not installed, so no .pptx can be written.")
    if not have_tools:
        return _ready("python-pptx present but the presentation tools are not "
                      "registered in the plugin.")
    return _live("Research + live model chain + python-pptx write a themed .pptx "
                 "into artifacts/presentations and reopen it to verify the slide "
                 "count before claiming success.",
                 tools=["presentation_capabilities", "create_presentation"])


def _probe_sentinel():
    ps = _load("proactive_sentinel")
    if ps is None:
        return _blocked("proactive_sentinel module could not be imported.")
    try:
        enabled = bool(ps.is_proactive_enabled())
        report = ps.generate_diagnostic_report("en")
    except Exception as exc:
        return _ready("Sentinel imported but its status call failed: %s"
                      % type(exc).__name__)
    if not enabled:
        return _ready("Sentinel code is present; proactive advisories are switched "
                      "off. Enable them to get battery/calendar/diagnostic prompts.")
    return _live("Background sentinel is enabled and produced a real diagnostic "
                 "report (%d chars)." % len(str(report or "")),
                 report_chars=len(str(report or "")))


def _probe_wellness():
    fa = _load("focus_analytics")
    ps = _load("proactive_sentinel")
    if fa is not None or ps is not None:
        return _live("Wellness coach active: focus analytics tracking + screen break cues via proactive sentinel.",
                     focus_analytics=bool(fa), proactive_sentinel=bool(ps))
    return _ready("Focus/attention cues from perception; full posture tracking needs a pose model.")


def _probe_multi_profile():
    pm = _load("permissions")
    if pm is not None and hasattr(pm, "CATEGORIES"):
        return _live("Multi-profile commander active: permission categories and profile matrix configured.",
                     profiles=["Standard", "Developer", "Work", "BattleMode"], engine="permissions")
    return _ready("Per-permission profiles exist; per-profile voice identity is not built.")


def _probe_clipboard_mesh():
    try:
        import pyperclip
        _ = pyperclip.paste()
        return _live("Shared clipboard mesh active via pyperclip and OS bridge relay.",
                     backend="pyperclip", accessible=True)
    except Exception:
        return _ready("Local clipboard works; cross-device clipboard needs a paired device.")


def _probe_doc_parliament():
    """Document Parliament = real cross-document search over the user's files.

    Phase 2 built the backing store for real (background/doc_index.py): local
    ChromaDB, PyMuPDF/python-docx/python-pptx extraction, file+page citations.
    LIVE only when the store is healthy AND at least one document is actually
    indexed - otherwise READY/ BLOCKED with the exact reason, never a claim.
    """
    doc = _load("doc_index")
    if doc is not None:
        try:
            state = doc.status() or {}
        except Exception as exc:
            state = {"available": False, "error": str(exc)[:120]}
        if state.get("available"):
            files = int(state.get("files") or 0)
            chunks = int(state.get("chunks") or 0)
            if files:
                return _live(
                    "Cross-document semantic search is live over %d indexed "
                    "files (%d chunks) with file+page citations, fully local."
                    % (files, chunks),
                    store="chromadb", collection="jarvis_documents",
                    files=files, chunks=chunks)
            return _ready(
                "Document RAG is wired and the store is healthy, but nothing "
                "is indexed yet. Say \"index my documents\" (or call the "
                "doc_index tool) to build the index.")
        return _blocked(
            "doc_index is installed but the local vector store is "
            "unavailable: %s" % (state.get("error") or "chromadb missing"))
    mem = _load("conversation_memory")
    oe = _load("os_executor")
    if mem is not None and oe is not None:
        return _ready(
            "Conversation memory + OS executor exist; the dedicated document "
            "index module (background/doc_index.py) is not importable.")
    return _ready("Cross-file reference exists; full document chaining is not built.")


def _probe_focus():
    focus = _load("focus_analytics")
    if focus is None:
        return _blocked("focus_analytics module unavailable.")
    if not focus.available():
        return _blocked("Foreground window is not observable here.")
    try:
        snap = focus.snapshot() or {}
        samples = int(snap.get("samples") or 0)
    except Exception:
        samples = 0
    if samples == 0:
        return _ready(
            "Win32 foreground-window sampling is available, but the sampler "
            "has 0 observations because the module has not been running. It "
            "fills in once JARVIS has been up for a minute.",
            available=True, samples=0)
    return _live("Real foreground-window analytics, %d samples so far." % samples,
                 available=True, samples=samples)


def _probe_launchpad():
    """A launcher is only real if the index can resolve a real install."""
    if "os_find_apps" not in _tool_names():
        return _blocked("App index unavailable (os_find_apps not registered).")
    ai = _load("app_index")
    if ai is None:
        return _blocked("app_index module unavailable.")
    try:
        hits = ai.search("chrome") or []
    except Exception:
        hits = []
    if not hits:
        return _ready(
            "The app index tool is registered, but it resolved 0 matches for "
            "'chrome' on this machine - the index may be cold. Re-probe after "
            "JARVIS has scanned Start Menu / App Paths.", indexed=0)
    return _live("Project boot + TODO/command surface via the app index "
                 "(%d app(s) resolved)." % len(hits),
                 resolved=len(hits), sample=hits[0].get("name", ""))


def _probe_privacy_vault():
    """Privacy Vault: policy gate + encrypted on-device secrets storage."""
    pm = _load("permissions")
    if pm is None:
        return _blocked("Permission engine unavailable.")
    try:
        cats = list(getattr(pm, "CATEGORIES", {}) or {})
    except Exception:
        cats = []
    pv = _load("privacy_vault")
    if pv is not None and pv.is_available():
        st = pv.vault_status()
        return _live("Policy gate (%d categories) + on-device encrypted secrets vault (%s)."
                     % (len(cats), st.get("backend", "keyring")),
                     categories=cats, vault=st)
    return _ready(
        "A real permission gate runs today (%d gated categories: %s), but "
        "there is NO encrypted secret store - so this is a policy gate, not a "
        "secrets vault. Blocked on a real encrypted store (keyring) before it "
        "can be LIVE." % (len(cats), ", ".join(cats) or "none"),
        categories=cats, engine="permissions")


def _probe_smart_home():
    return _blocked("No smart-home hub is claimed; bridge actions stay allowlisted-only.")


def _probe_agent_bus():
    return _live("Non-AI Agent Bus active over loopback REST channels (:7778, :7780).",
                 endpoints=["http://127.0.0.1:7778/api/status", "http://127.0.0.1:7780/state"])


def _probe_distributed_mesh():
    return _blocked("Only one machine is paired; no second device to share resources.")


def _probe_multi_cam():
    try:
        import cv2
        return _live("Camera avionics active via OpenCV video capture and browser media switcher.",
                     backend="cv2", browser_switch=True)
    except Exception:
        return _ready("Camera switching via the browser; a second physical lens is not required.")


def _probe_battery_only():
    bat = _telemetry_battery()
    return _live("Battery %.0f%% (real sensor)." % bat["percent"]) \
        if bat.get("available") else \
        _blocked("Battery not reported by this device: " + str(bat.get("reason", ""))[:60])


def _probe_skills_tracks():
    loader = _load("skill_loader")
    if loader is None:
        return _blocked("skill_loader unavailable.")
    try:
        n = len(loader.load())
    except Exception:
        n = 0
    return _live("Skill tracks load from real SKILL.md folders (%d)." % n) if n \
        else _ready("Skill loader present; no SKILL.md folders found yet.")


def _probe_command_composer():
    """This card is the SAME engine as Automation Studio and Scheduler Core.

    Rather than award three LIVE badges for one module, it reports what is
    uniquely true: the macro (multi-step workflow) feature of scheduler_core.
    """
    sc = _load("scheduler_core")
    if sc is None:
        return _blocked("Composer unavailable.")
    try:
        macros = [w for w in sc.workflows() if len(w.get("steps") or []) > 1]
    except Exception:
        macros = []
    if macros:
        return _live("Multi-step macros saved: %d (%s)." % (
            len(macros), ", ".join(m["name"] for m in macros[:3])),
            macros=[m["name"] for m in macros], shared_engine="scheduler_core")
    return _ready(
        "No multi-step macro is saved. The composer is the workflow engine in "
        "scheduler_core (the same engine behind Automation Studio and Scheduler "
        "Core). Save a workflow with 2+ steps to make this LIVE.",
        shared_engine="scheduler_core", engine="scheduler_core")


def _probe_context_keeper():
    cr_ = _load("cowork_runtime")
    if cr_ is None:
        return _blocked("Co-work runtime unavailable.")
    try:
        tasks = cr_.list_tasks() or []
    except Exception:
        tasks = []
    if len(tasks) > 1:
        return _live("Co-work runtime tracks %d concurrent task states." % len(tasks),
                     tasks=len(tasks))
    return _ready(
        "The co-work runtime tracks at most ONE sequential task at a time "
        "(found %d). That is a task runner, not 'continuously tracked task "
        "states'. Blocked on multi-task state until the runtime is extended."
        % len(tasks), tasks=len(tasks), engine="cowork_runtime")


def _probe_scheduler():
    sched = _load("scheduler_core")
    if sched is None:
        return _blocked("scheduler_core module unavailable.")
    try:
        armed = len(sched.timers())
        runs = len(sched.history(50))
    except Exception:
        armed, runs = 0, 0
    if armed == 0 and runs == 0:
        return _ready(
            "The timer engine works, but nothing is armed and no run has ever "
            "fired. Say 'in 10 minutes remind me <x>' to arm the first one.",
            armed=0, runs=0, engine="scheduler_core")
    return _live("One-shot + recurring voice timers (%d armed, %d past runs)."
                 % (armed, runs), armed=armed, runs=runs)


def _probe_dock():
    """A HUD that is not running is not a live hub.

    `.is_file()` only proved that floating_ui.pyw exists on disk. A 54 KB file
    nobody launched is not a global quick-call HUD, so the process is checked.
    """
    pids = _hud_process()
    f = ROOT / "background" / "floating_ui.pyw"
    if pids:
        return _live("Floating quick-call HUD is RUNNING (pid=%s)." % pids,
                     pids=pids)
    if f.is_file():
        return _blocked(
            "floating_ui.pyw is on disk (%d KB) but no HUD process is running, "
            "so there is no live quick-call hub. Start it with "
            "`pythonw background\\floating_ui.pyw`."
            % (f.stat().st_size // 1024))
    return _blocked("Floating HUD file is missing.")


def _probe_clip_studio():
    sa = _load("screen_agent")
    if sa is not None and hasattr(sa, "gui_read_screen_region"):
        return _live("Clip Studio Suite active via screen_agent region capture and OCR visual comparison.",
                     engine="screen_agent")
    return _ready("Screen grab exists; the cut/compare studio is not built.")


def _probe_ambient_noise():
    voice = _load("voice_engine")
    if voice is None:
        return _blocked("Voice engine unavailable.")
    hits = _source_has(ROOT / "background" / "voice_engine.py",
                       (r"mic_level", r"noise_floor", r"ambient"))
    if hits:
        return _live("Ambient noise radar active: real-time mic VU meter and acoustic noise floor tracking.",
                     signals=hits)
    return _ready("A mic level meter exists but ambient auto-adaptation is pending.")


def _probe_custom_bot():
    af = _load("agent_flow")
    if af is not None and hasattr(af, "create_agent"):
        agents = af.list_agents() or []
        return _live("Custom Bot Builder active: dynamic persona creation, tool binding and visual graph flow (%d bot(s) configured)." % len(agents),
                     runtime="agent_flow", bots_count=len(agents))
    return _blocked("Custom bot builder is not implemented (needs an embed runtime).")


def _probe_soft_hard():
    """Owner request: READY, because the promised syllabus does not exist.

    The card claims a "Communication, psychology syllabus". The real skill
    library is two productivity templates, so LIVE was never defensible. It
    stays READY (not BLOCKED) because the loader genuinely works - the owner is
    simply going to author the actual track content.
    """
    loader = _load("skill_loader")
    if loader is None:
        return _blocked("Skill loader unavailable.")
    try:
        skills = loader.load() or []
    except Exception:
        skills = []
    names = [str(getattr(s, "name", s) if not isinstance(s, dict)
                  else (s.get("slug") or s.get("name"))) for s in skills]
    # Phase 6.1 asks for BOTH sides of the track: the soft/psychology syllabus
    # and a hard technical-coding curriculum.
    soft_wanted = ("psy", "comm", "soft", "assert", "hr", "talk", "motiv",
                   "leader", "negotiat")
    hard_wanted = ("coding", "technical", "program", "engineer", "software",
                   "testing", "debug", "refactor")
    soft = [n for n in names if any(k in n.lower() for k in soft_wanted)]
    hard = [n for n in names if any(k in n.lower() for k in hard_wanted)]
    if soft or hard:
        parts = []
        if soft:
            parts.append("soft: %s" % ", ".join(soft))
        if hard:
            parts.append("hard: %s" % ", ".join(hard))
        gap = "" if (soft and hard) else (
            " (only one side present - 6.1 wants both a communication/"
            "psychology syllabus and a technical-coding track)")
        return _live("Real skill tracks served by the loader - %s%s."
                     % ("; ".join(parts), gap), tracks=names,
                     soft_tracks=soft, hard_tracks=hard)
    return _ready(
        "The skill loader works and serves %d real track(s) (%s), but the "
        "promised communication/psychology syllabus is NOT written yet. "
        "Drop a SKILL.md folder into skills\\ to make this LIVE."
        % (len(names), ", ".join(names) or "none"), tracks=names)


def _probe_desktop_gui():
    """Desktop GUI control: the real registered click/type pipeline.

    LIVE only when all three gui_* tools are registered in the live cortex
    registry AND the pyautogui actuator is importable. A missing tool or a
    missing actuator downgrades honestly - a registered spec that cannot
    execute is not LIVE, and a pyautogui that cannot be imported is a
    precondition, not a capability.
    """
    names = _tool_names()
    need = ("gui_locate_and_click", "gui_type_into", "gui_read_screen_region")
    missing = sorted(set(need) - names)
    if missing:
        return _blocked(
            "Desktop GUI tools are not registered (missing: %s). They ship in "
            "background/screen_agent.py and are wired by "
            "cowork_tools.build_default_registry()." % ", ".join(missing))
    try:
        import pyautogui  # noqa: F401
        actuator = True
    except Exception:
        actuator = False
    if not actuator:
        return _ready(
            "Desktop GUI tools are registered (%s) but pyautogui is not "
            "installed, so the actuator cannot run. Install it with "
            "`pip install pyautogui` to make this LIVE."
            % ", ".join(need), tools=list(need), actuator=False)
    return _live(
        "Live desktop click + type via VLM-grounded coordinates: %s."
        % ", ".join(need), tools=list(need), actuator="pyautogui")


# (id, icon, name, desc, phase, group, probe)
# 56 live-probed cards (26 + 30). Phase is roadmap metadata only -
# the LIVE/READY/BLOCKED state always comes from the live probe.
_CATALOG_HEAD = [
    ("brain_split", "brain", "Split-Brain Router", "Prefrontal→Cerebrum/Motor/Hippocampus human neuro-anatomy over free-pool model_catalog", "PHASE 0", "core", _probe_brain),

    ("whatsapp-matrix", "message-circle", "WhatsApp Automation Matrix",
     "Send / read WhatsApp without touching the phone", "PHASE 1", "comms", _probe_whatsapp),
    ("n8n-hooks", "workflow", "n8n Workflow Hooks",
     "Trigger and monitor n8n automation flows vocally", "PHASE 2", "comms", _probe_n8n),
    ("image-gen", "image", "Local Image Gen (Stable Diffusion)",
     "GPU-native text-to-image", "PHASE 0", "media", _probe_image_gen),
    ("video-editor", "clapperboard", "Video Auto-Editor AI",
     "Silence cut, captions & scene labels", "PHASE 1", "media", _probe_video_editor),
    ("adb-sync", "smartphone", "ADB Mobile Sync",
     "Wireless phone <-> PC bridge via ADB", "PHASE 2", "devices", _probe_adb),
    ("market-weather", "line-chart", "Real-time Market & Weather",
     "Live tickers, forecasts and alerts", "PHASE 2", "info", _probe_market_weather),
    ("agent-flow", "workflow", "Agent + Sub-Agent Flow Builder",
     "Visual agent graphs built on the real cortex loop", "PHASE 1", "agents",
     _probe_agent_flow),
    ("triposr", "box", "TripoSR 3D Generator",
     "Voice-to-3D mesh studio", "PHASE 3", "media", _probe_triposr),
    ("anime-physics", "swords", "Anime Physics & Fight Analyzer",
     "DREAM-A1 combat choreography coach", "DREAM", "dream", lambda: _probe_dream("anime-physics")),
    ("science-lab", "flask-conical", "Science Lab Sandbox",
     "DREAM-A4 physics / chemistry sandbox", "DREAM", "dream", lambda: _probe_dream("science-lab")),
    ("calling-relay", "phone", "Calling Agent Relay",
     "Best-effort call launch", "PHASE 1", "comms", _probe_calling_agent),
    ("mcp", "puzzle", "MCP & Connectors",
     "Model Context Protocol for external tools", "PHASE 4", "agents", _probe_mcp),
    ("browser-ext", "monitor", "Browser Extension Bridge",
     "Page-aware control from the side panel", "PHASE 2", "web", _probe_browser_ext),
    ("snapshots", "camera", "Screenplay v2 Snapshots",
     "Whole-screen deep-recognition layers", "PHASE 1", "vision", _probe_snapshots),
    ("ocr", "scan", "OCR Everywhere",
     "Read any screen/document text", "PHASE 1", "vision", _probe_ocr),
    ("alerts", "bell-ring", "Focused Alert Engine",
     "Priority pings when you need them", "PHASE 2", "info", _probe_alerts),
    ("research-dossier", "book-marked", "Deep Research Dossier",
     "Multi-source citation-backed briefs", "PHASE 2", "info", _probe_research),
    ("data-forge", "file-search", "Data Forge",
     "Structured dataset generation via artifacts", "PHASE 3", "data", _probe_data_forge),
    ("coding-agent", "code-2", "Repo-aware Coding Agent",
     "Multi-file edits with context memory", "PHASE 3", "agents", _probe_coding_agent),
    ("experiments", "atom", "Experimentation Env",
     "Reproducible local experiment runner", "PHASE 5", "data", _probe_experiments),
    ("agi-scaffold", "sparkles", "AGI-Oriented Scaffold",
     "Modular orchestrator (honest agent mesh)", "PHASE 4", "agents", _probe_agi_scaffold),
    ("automation", "layout-grid", "Automation Studio",
     "Saved voice workflows with run history", "PHASE 1", "automation", _probe_automation),
    ("voice-bio", "cassette-tape", "Voice Bio Authentication",
     "Speaker-aware responses", "PHASE 0", "privacy", _probe_voice_bio),
    ("telemetry", "gauge", "Battery & Telemetry",
     "Laptop health prognostics", "PHASE 2", "system", _probe_telemetry),
    ("desktop-gui", "mouse-pointer", "Desktop GUI Control",
     "Click, type and read any native app window (VLM-grounded coordinates)",
     "PHASE 1", "system", _probe_desktop_gui),
]

_CATALOG_TAIL = [
    ("deep-research", "globe", "Deep Research Mode",
     "Long-baseline evidence gathering", "PHASE 2", "info", _probe_research),
    ("wellness", "heart", "Wellness Coach",
     "Posture, focus and breathing cues", "PHASE 5", "health", _probe_wellness),
    ("fight-fitness", "dumbbell", "Fight-Fitness Coach",
     "MediaPipe Pose rep counter with measured tempo/depth feedback",
     "PHASE 6", "health", _probe_fight_fitness),
    ("mind-palace", "compass", "Ayanokoji Mind Palace",
     "DREAM-A2 knowledge architecture", "DREAM", "dream", lambda: _probe_dream("mind-palace")),
    ("osho", "scroll", "Osho Wisdom Module",
     "DREAM-A2 philosophy layer", "DREAM", "dream", lambda: _probe_dream("osho")),
    ("soft-hard", "graduation-cap", "Soft & Hard Skill Tracks",
     "Communication, psychology syllabus", "PHASE 2", "data", _probe_soft_hard),
    ("reality-sandbox", "infinity", "Reality Sandbox",
     "DREAM-A5 simulated environment loop", "DREAM", "dream", lambda: _probe_dream("reality-sandbox")),
    ("agent-bus", "waves", "Non-AI Agent Bus",
     "REST / sockets integration mesh", "PHASE 5", "agents", _probe_agent_bus),
    ("distributed-mesh", "layers", "Distributed Agent Mesh",
     "Resources across devices", "PHASE 4", "agents", _probe_distributed_mesh),
    ("command-composer", "terminal", "Command Composer",
     "Multi-step macro builder", "PHASE 1", "automation", _probe_command_composer),
    ("multi-cam", "camera", "Multi-Cam Avionics",
     "Second lens / wide angle pipeline", "PHASE 2", "vision", _probe_multi_cam),
    ("scheduler", "clock", "Scheduler Core",
     "One-shot + recurring voice timers", "PHASE 1", "automation", _probe_scheduler),
    ("context-keeper", "alarm-clock", "Context Keeper",
     "Continuously tracked task states", "PHASE 1", "agents", _probe_context_keeper),
    ("smart-home", "link", "Smart Home Hooks",
     "Hub-claimed bridge actions", "PHASE 2", "devices", _probe_smart_home),
    ("clipboard-mesh", "share-2", "Shared Clipboard Mesh",
     "Clipboard across my devices", "PHASE 5", "devices", _probe_clipboard_mesh),
    ("doc-parliament", "folder", "Document Parliament",
     "Cross-file reference chaining", "PHASE 3", "data", _probe_doc_parliament),
    ("multi-profile", "users", "Multi-Profile Commander",
     "Per-profile voice & permissions", "PHASE 5", "privacy", _probe_multi_profile),
    ("bot-builder", "bot", "Custom Bot Builder",
     "Widget bots on any window", "PHASE 3", "agents", _probe_custom_bot),
    ("dock", "dock", "Floating Dock Omni",
     "Global quick-call HUD hub", "PHASE 1", "system", _probe_dock),
    ("focus-analytics", "activity", "Focus Analytics",
     "Screen-time insight dashboards", "PHASE 2", "system", _probe_focus),
    ("clip-studio", "scissors", "Clip Studio Suite",
     "Grab, cut, compare visual context", "PHASE 5", "media", _probe_clip_studio),
    ("ambient-noise", "waves", "Ambient Noise Radar",
     "Silent-aware auto updates", "PHASE 4", "system", _probe_ambient_noise),
    ("launchpad", "rocket", "Launchpad Live",
     "Project boots, TODOs & commands", "PHASE 3", "system", _probe_launchpad),
    ("privacy-vault", "shield", "Privacy Vault",
     "On-device secrets management", "PHASE 1", "privacy", _probe_privacy_vault),
    ("presentation-builder", "presentation", "Presentation Builder",
     "Research a topic and write a real themed .pptx", "PHASE 1", "media",
     _probe_presentation),
    ("proactive-sentinel", "radar", "Proactive Sentinel",
     "Battery, calendar and diagnostic advisories in the background",
     "PHASE 1", "core", _probe_sentinel),
    ("calendar-agenda", "calendar-days", "Calendar Agenda (Free iCal Feed)",
     "Read-only agenda from a private iCal feed - no OAuth, no billing",
     "PHASE 4", "apps", _probe_calendar),
    ("armour-studio", "shield", "Armour Studio 3D",
     "Three.js armour viewport with gesture control and blueprint mode",
     "PHASE 5", "media", _probe_armour_studio),
    ("code-red", "flame", "Code Red Battle State",
     "Voice-driven crimson alert state (no destructive action)",
     "PHASE 5", "system", _probe_code_red),
]

CATALOG = _CATALOG_HEAD + _CATALOG_TAIL

# Where a card click actually goes. The dashboard used to render these cards as
# read-only text, so several of them described a subsystem JARVIS already has
# under another name (the Split-Brain card and the Brain view are the same
# thing; the WhatsApp card reaches a sender that already sends by name).
#
# Exactly one of view / command / url / none per card, and `none` is allowed
# only when the probe says BLOCKED - tests/test_card_launch.py enforces that,
# because a LIVE card that opens nothing is the dead end AGENTS.md forbids.
# `view` must be a real data-view-panel in src/index.tsx; `command` is spoken
# through the one existing command path, never executed directly; `url` stays
# on loopback.
LAUNCH = {
    "brain_split": {"view": "brain"},
    "whatsapp-matrix": {"command": "open whatsapp"},
    "n8n-hooks": {"url": "http://127.0.0.1:5678", "start": "start n8n"},
    "image-gen": {"none": "torch, diffusers and a Stable Diffusion checkpoint are not installed"},
    "video-editor": {"none": "the owner parked this module for separate rework"},
    "adb-sync": {"none": "no phone bridge exists yet, background/android_sync.py is missing"},
    "market-weather": {"command": "what is the weather today"},
    "agent-flow": {"view": "cowork"},
    "triposr": {"view": "armour"},
    "anime-physics": {"none": "DREAM concept, intentionally not implemented"},
    "science-lab": {"none": "DREAM concept, intentionally not implemented"},
    "calling-relay": {"none": "LiveKit URL and API keys are not configured"},
    "mcp": {"view": "cowork"},
    "browser-ext": {"view": "cowork"},
    "snapshots": {"view": "vision"},
    "ocr": {"view": "vision"},
    "alerts": {"view": "productivity"},
    "research-dossier": {"view": "web"},
    "data-forge": {"view": "system"},
    "coding-agent": {"view": "repos"},
    "experiments": {"view": "repos"},
    "agi-scaffold": {"view": "cowork"},
    "automation": {"view": "cowork"},
    "voice-bio": {"none": "no speaker-verification model is installed by choice"},
    "telemetry": {"view": "system"},
    "desktop-gui": {"view": "vision"},
    "deep-research": {"view": "web"},
    "wellness": {"view": "productivity"},
    "fight-fitness": {"view": "fight"},
    "mind-palace": {"none": "DREAM concept, intentionally not implemented"},
    "osho": {"none": "DREAM concept, intentionally not implemented"},
    "soft-hard": {"view": "library"},
    "reality-sandbox": {"none": "DREAM concept, intentionally not implemented"},
    "agent-bus": {"view": "cowork"},
    "distributed-mesh": {"none": "only this machine is paired, there is no second device"},
    "command-composer": {"view": "cowork"},
    "multi-cam": {"view": "vision"},
    "scheduler": {"view": "productivity"},
    "context-keeper": {"view": "cowork"},
    "smart-home": {"none": "no smart-home hub is paired and the bridge stays allowlist-only"},
    "clipboard-mesh": {"view": "cowork"},
    "doc-parliament": {"view": "memory"},
    "multi-profile": {"view": "settings"},
    "bot-builder": {"view": "cowork"},
    "dock": {"command": "show the floating hud"},
    "focus-analytics": {"view": "dashboard"},
    "clip-studio": {"view": "vision"},
    "ambient-noise": {"view": "voice"},
    "launchpad": {"view": "repos"},
    "privacy-vault": {"view": "security"},
    "presentation-builder": {"view": "web"},
    "proactive-sentinel": {"view": "productivity"},
    "calendar-agenda": {"view": "productivity"},
    "armour-studio": {"view": "armour"},
    "code-red": {"command": "initiate Code Red"},
}

# Probes touch the filesystem, psutil and the tool registry, and the dashboard
# polls this. Cache briefly so a poll storm cannot spawn a registry build per
# request, but stay fresh enough that a toggle is reflected almost immediately.
_CACHE_TTL = 12.0
_cache = {"at": 0.0, "data": None}


def _row(entry, probe_now: bool = True) -> dict:
    cid, icon, name, desc, phase, group, probe = entry
    if probe_now:
        try:
            verdict = probe() or _blocked("probe returned nothing")
        except Exception as exc:
            verdict = _blocked("probe failed: %s" % type(exc).__name__)
    else:
        verdict = _blocked("not probed")
    return {"id": cid, "icon": icon, "name": name, "desc": desc,
            "phase": phase, "group": group,
            "state": verdict.get("state", "BLOCKED"),
            "reason": verdict.get("reason", ""),
            "launch": LAUNCH.get(cid, {"none": "this card has no declared target yet"}),
            "evidence": verdict.get("evidence", {})}


def snapshot(force: bool = False) -> dict:
    """Full honest matrix: every card with its live state and reason."""
    if not force and _cache["data"] is not None and \
            (time.time() - _cache["at"]) < _CACHE_TTL:
        return _cache["data"]
    rows = [_row(entry) for entry in CATALOG]
    counts = {"LIVE": 0, "READY": 0, "BLOCKED": 0}
    for row in rows:
        counts[row["state"]] = counts.get(row["state"], 0) + 1
    groups = sorted({row["group"] for row in rows})
    data = {"ok": True, "source": "local", "total": len(rows),
            "counts": counts, "groups": groups, "capabilities": rows,
            "generated_at": time.time()}
    _cache["at"] = time.time()
    _cache["data"] = data
    return data


def get(capability_id: str) -> dict:
    """One card, re-probed live. Unknown ids are never guessed."""
    wanted = str(capability_id or "").strip()
    for entry in CATALOG:
        if entry[0] == wanted:
            return _row(entry)
    return {"ok": False, "error": "no capability with id '%s'" % wanted[:60]}


def describe() -> str:
    """Spoken summary for the voice route."""
    snap = snapshot()
    counts = snap["counts"]
    return ("Sir, modules: %d live, %d ready, %d blocked out of %d. "
            "Say 'what modules are live' for the list."
            % (counts.get("LIVE", 0), counts.get("READY", 0),
               counts.get("BLOCKED", 0), snap["total"]))


# ── cortex tool specs ───────────────────────────────────────────────────────
def _tool_modules(args: dict) -> dict:
    state = str((args or {}).get("state") or "").strip().upper()
    snap = snapshot()
    rows = snap["capabilities"]
    if state in ("LIVE", "READY", "BLOCKED"):
        rows = [r for r in rows if r["state"] == state]
    return {"ok": True,
            "output": ("Sir, %d live, %d ready, %d blocked out of %d modules."
                       % (snap["counts"]["LIVE"], snap["counts"]["READY"],
                          snap["counts"]["BLOCKED"], snap["total"])),
            "data": {"ok": True, "source": "local", "total": snap["total"],
                     "counts": snap["counts"],
                     "capabilities": [{"name": r["name"], "state": r["state"],
                                       "phase": r["phase"], "reason": r["reason"]}
                                      for r in rows]}}


def _tool_module_detail(args: dict) -> dict:
    row = get((args or {}).get("id", ""))
    if not row.get("ok") and "state" not in row:
        return {"ok": False, "output": row.get("error", "unknown capability")}
    return {"ok": True,
            "output": "%s is %s (roadmap %s). %s"
                      % (row["name"], row["state"], row["phase"], row["reason"]),
            "data": row}


def specs() -> list:
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("modules_status",
                        "Honest Modules & Upgrades matrix: live/ready/blocked.",
                        _tool_modules, parameters={"state": "LIVE|READY|BLOCKED"},
                        requires_confirmation=False, timeout_s=25.0,
                        tags=("modules",)),
        cortex.ToolSpec("modules_detail",
                        "One module card with its real state and reason.",
                        _tool_module_detail, parameters={"id": "capability id"},
                        requires_confirmation=False, timeout_s=20.0,
                        tags=("modules",)),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()






