"""Floating HUD close/summon semantics, locked without a GUI.

Live 2026-10-19: clicking "Close HUD" killed the process, PM2 restarted it
instantly, and the HUD popped right back up - an unclosable window. The close
now hides BOTH surfaces and parks the process (supervision must not fight the
owner); only EXPLICIT asks (dashboard HUD pill, hotkey, second launcher)
reopen it; the tab-hidden heartbeat only 'peek's, and is ignored while the
HUD is manually closed; boot bring-up resurrects the PM2 family so the HUD
appears after a laptop restart.

The .pyw is never imported here (tkinter would open a GUI in the runner):
every assertion parses the AST of the real files.
"""
import ast
import importlib.util
import io
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HUD = ROOT / "background" / "floating_ui.pyw"
ENGINE = ROOT / "background" / "voice_engine.py"
BOOT = ROOT / "scripts" / "windows-boot.cmd"


def _source(path: Path) -> str:
    return io.open(path, "r", encoding="utf-8", newline="").read()


def _tree(path: Path):
    return ast.parse(_source(path))


def _method(tree, name):
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
    return None


def _calls(node):
    """Every callable symbol invoked inside `node` (bare + attribute names)."""
    names = []
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            fn = sub.func
            if isinstance(fn, ast.Attribute):
                names.append(fn.attr)
                fn = fn.value
            names.append(getattr(fn, "id", getattr(fn, "attr", "")))
    return names


def _strings(node):
    out = []
    for sub in ast.walk(node):
        if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
            out.append(sub.value)
    return out


class CloseHudBehaviorTest(unittest.TestCase):
    HUD_TREE = _tree(HUD)

    def test_close_hud_never_exits_never_destroys_just_hides_both(self):
        close = _method(self.HUD_TREE, "close_hud")
        self.assertIsNotNone(close)
        calls = _calls(close)
        self.assertNotIn("_exit", calls, "close must not kill the supervised process")
        self.assertNotIn("destroy", calls)
        self.assertIn("withdraw", calls)

    def test_the_guard_loop_respects_a_manual_close_for_peek(self):
        loop = _method(self.HUD_TREE, "_guard_loop")
        self.assertIsNotNone(loop)
        dump = ast.dump(loop)
        self.assertIn("closed_manually", dump)
        self.assertIn("peek", dump)
        self.assertIn("show", dump)

    def test_an_explicit_reopen_revokes_the_manual_close(self):
        expand = _method(self.HUD_TREE, "expand_panel")
        self.assertIsNotNone(expand)
        self.assertIn("closed_manually", ast.dump(expand))

    def test_second_launcher_peeks_when_it_was_an_auto_spawn(self):
        self.assertIn("--from-auto", _strings(_method(_tree(HUD), "parse")),
                      "the flag must exist on the CLI so spawn_hud can mark it")
        main = _method(_tree(HUD), "main")
        self.assertIsNotNone(main)
        dump = ast.dump(main)
        self.assertIn("'peek'", dump)
        self.assertIn("from_auto", dump)

    def test_spawn_hud_only_peeks_for_auto_and_plumbs_the_flag(self):
        tree = _tree(ENGINE)
        spawn = _method(tree, "spawn_hud")
        self.assertIsNotNone(spawn)
        dump = ast.dump(spawn)
        self.assertIn("'peek'", dump)
        self.assertIn("'show'", dump)
        self.assertIn("auto", dump)
        self.assertIn("--from-auto", dump)
        self.assertIn("Popen", _calls(spawn))

    def test_the_boot_script_resurrects_the_pm2_family(self):
        self.assertTrue(BOOT.is_file())
        text = BOOT.read_text(encoding="utf-8", errors="replace")
        self.assertIn("pm2 resurrect", text)

    def test_the_startup_folder_invokes_the_boot_script(self):
        startup = (Path.home() / "AppData" / "Roaming" /
                   "Microsoft" / "Windows" / "Start Menu" / "Programs" /
                   "Startup" / "jarvis-boot.cmd")
        self.assertTrue(startup.is_file(),
                        "login bring-up must be wired into the Startup folder")
        self.assertIn("windows-boot.cmd", startup.read_text(encoding="utf-8",
                                                            errors="replace"))

    def test_appjs_heartbeat_marks_itself_auto(self):
        appjs = (ROOT / "public" / "static" / "app.js")
        text = appjs.read_text(encoding="utf-8", errors="replace")
        i = text.index("ensureFloatingUI")
        block = text[i:i + 700]
        self.assertIn('"auto":true', block,
                      "tab-hidden summon must be auto so a manual close wins")


class ScreenScanBehaviorTest(unittest.TestCase):
    HUD_TREE = _tree(HUD)

    def test_real_screen_watch_state_drives_the_layer(self):
        apply_state = _method(self.HUD_TREE, "_apply_state")
        self.assertIsNotNone(apply_state)
        dump = ast.dump(apply_state)
        self.assertIn("'screen_watch'", dump)
        self.assertIn("_set_scan_enabled", dump)

    def test_closing_the_panel_does_not_hide_the_scan_layer(self):
        sync = _method(self.HUD_TREE, "_sync_scan_overlay")
        self.assertIsNotNone(sync)
        self.assertNotIn("'hidden'", ast.dump(sync),
                         "the scan layer must follow screen_watch, not panel visibility")
        self.assertIn("_show_scan_overlay", _calls(sync))
        close = _method(self.HUD_TREE, "close_hud")
        self.assertIn("_sync_scan_overlay", _calls(close))

    def test_layer_is_clickthrough_and_excluded_from_capture(self):
        make = _method(self.HUD_TREE, "_make_scan_overlay_clickthrough")
        self.assertIsNotNone(make)
        dump = ast.dump(make)
        for symbol in ("WS_EX_TRANSPARENT", "WS_EX_LAYERED", "WS_EX_NOACTIVATE",
                       "WDA_EXCLUDEFROMCAPTURE", "SetWindowDisplayAffinity"):
            self.assertIn(symbol, dump)

    def test_animation_tick_draws_while_visible(self):
        tick = _method(self.HUD_TREE, "_scan_tick")
        self.assertIsNotNone(tick)
        self.assertIn("_draw_scan_overlay", _calls(tick))


spawn_src_decor = ""    # removed: leftover placeholder from the draft


if __name__ == "__main__":
    unittest.main()
