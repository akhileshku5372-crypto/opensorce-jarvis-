---
name: meeting-notes
description: Rough meeting transcript ko structured notes + action items me badlo.
triggers: meeting notes, meeting ke notes, minutes banao, notes banao meeting, transcript se notes
---

# Meeting Notes

Turn whatever the user pasted/spoke (a rough transcript, voice memo, or bullet
dump) into structured notes. Follow these steps and keep the output short enough
to be read aloud:

1. **Header** - one line: meeting title if present, else `Meeting notes`.
2. **Decisions** - bullets, each starting with a verb ("Ship X on Friday").
3. **Action items** - `owner - task - due` when the owner/due date is stated.
   Never invent an owner or a date: write `unassigned` / `no date` instead.
4. **Open questions** - only real unresolved items from the transcript.
5. **Save it** - offer to save with the local notes skill
   (`note likho <notes>`), and mention the file name after saving.

Rules: no filler, no invented attendees, no summarising things that were not
said. If the transcript is too short to structure, say so and ask for more.
