/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  SubsystemId,
  SubsystemInfo,
  HologramTheme,
  ZoomLevel,
  SystemTelemetry,
} from '../../types/jarvis';
import {
  Eye,
  MessageSquare,
  Database,
  GitBranch,
  Volume2,
  Wrench,
  Code,
  Monitor,
  Cpu,
  Layers,
  RotateCw,
  Maximize2,
  VolumeX,
} from 'lucide-react';
import { soundFx } from '../../services/soundEffects';

interface BrainHUDOverlayProps {
  subsystems: Record<SubsystemId, SubsystemInfo>;
  selectedSubsystemId: SubsystemId | null;
  onSelectSubsystem: (id: SubsystemId) => void;
  hologramTheme: HologramTheme;
  onChangeTheme: (theme: HologramTheme) => void;
  isExploded: boolean;
  onToggleExplode: () => void;
  isRotating: boolean;
  onToggleRotate: () => void;
  zoomLevel: ZoomLevel;
  telemetry: SystemTelemetry;
  show3dCanvas?: boolean;
  onToggle3dCanvas?: () => void;
}

export const BrainHUDOverlay: React.FC<BrainHUDOverlayProps> = ({
  subsystems,
  selectedSubsystemId,
  onSelectSubsystem,
  hologramTheme,
  onChangeTheme,
  isExploded,
  onToggleExplode,
  isRotating,
  onToggleRotate,
  zoomLevel,
  telemetry,
  show3dCanvas = false,
  onToggle3dCanvas,
}) => {
  const [isMuted, setIsMuted] = React.useState(soundFx.getMuted());

  const handleToggleSound = () => {
    const muted = soundFx.toggleMute();
    setIsMuted(muted);
    if (!muted) soundFx.playSelect();
  };

  const getSubsystemIcon = (id: SubsystemId) => {
    switch (id) {
      case 'vision':
        return <Eye className="w-5 h-5" />;
      case 'language':
        return <MessageSquare className="w-5 h-5" />;
      case 'memory':
        return <Database className="w-5 h-5" />;
      case 'planning':
        return <GitBranch className="w-5 h-5" />;
      case 'audio':
        return <Volume2 className="w-5 h-5" />;
      case 'tools':
        return <Wrench className="w-5 h-5" />;
      case 'coding':
        return <Code className="w-5 h-5" />;
      case 'computer_use':
        return <Monitor className="w-5 h-5" />;
    }
  };

  const leftSubsystems: SubsystemId[] = ['vision', 'language', 'memory', 'planning'];
  const rightSubsystems: SubsystemId[] = ['audio', 'tools', 'coding', 'computer_use'];

  const memoryPercent = Math.round((telemetry.memoryUsedGB / telemetry.memoryMaxGB) * 100);

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3.5 z-10">
      {/* Top Header of the Brain Module */}
      <div className="pointer-events-auto flex items-center justify-between bg-slate-950/70 border border-cyan-500/25 rounded-xl px-4 py-2.5 backdrop-blur-md">
        <div className="flex items-center gap-3">
          {/* Animated Glowing Arc Reactor Mini */}
          <div className="relative w-8 h-8 rounded-full border border-cyan-400/60 flex items-center justify-center bg-cyan-950/40 shadow-[0_0_12px_rgba(6,182,212,0.4)]">
            <div className="w-4 h-4 rounded-full border border-dashed border-cyan-300 animate-arc-rotate" />
            <div className="absolute w-1.5 h-1.5 rounded-full bg-cyan-400" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-orbitron font-bold text-base text-white tracking-wider">
                JARVIS BRAIN
              </h2>
              <div className="flex items-center gap-1.5 text-[10px] font-rajdhani text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Brain Active
              </div>
            </div>
            <p className="text-[11px] text-cyan-300/70 font-rajdhani tracking-wide">
              AI Cognitive System • Models • Memory • Context
            </p>
          </div>
        </div>

        {/* Brain HUD Controls & Zoom Level Indicator */}
        <div className="flex items-center gap-2 font-rajdhani text-xs">
          {/* Zoom Level Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900/80 border border-cyan-500/20 text-slate-400 text-[11px]">
            <span className="text-cyan-400 font-medium">LOD:</span>
            <span className="text-white font-mono-code capitalize">{zoomLevel}</span>
          </div>

          {/* Hologram Theme Selector */}
          <div className="flex items-center gap-1 px-1.5 py-1 rounded bg-slate-900/80 border border-cyan-500/20">
            {(
              [
                { id: 'arc_cyan', color: 'bg-cyan-500', name: 'Arc' },
                { id: 'stark_gold', color: 'bg-amber-500', name: 'Gold' },
                { id: 'quantum_violet', color: 'bg-purple-500', name: 'Violet' },
                { id: 'tactical_emerald', color: 'bg-emerald-500', name: 'Emerald' },
                { id: 'neural_crimson', color: 'bg-red-500', name: 'Crimson' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  onChangeTheme(t.id);
                  soundFx.playChirp();
                }}
                title={`Theme: ${t.name}`}
                className={`w-3.5 h-3.5 rounded-full ${t.color} transition-all ${
                  hologramTheme === t.id
                    ? 'ring-2 ring-white scale-110 shadow-sm shadow-white'
                    : 'opacity-50 hover:opacity-100'
                }`}
              />
            ))}
          </div>

          {/* 3D WebGL Canvas Toggle */}
          {onToggle3dCanvas && (
            <button
              onClick={() => {
                onToggle3dCanvas();
                soundFx.playSelect();
              }}
              title={show3dCanvas ? "Switch to 2D Hologram" : "Switch to 3D WebGL Orbit"}
              className={`flex items-center gap-1 px-2.5 py-1 rounded border transition-all ${
                show3dCanvas
                  ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.35)]'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-cyan-300'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>{show3dCanvas ? '3D: ON' : '3D: OFF'}</span>
            </button>
          )}

          {/* Exploded View Toggle */}
          {show3dCanvas && (
            <button
              onClick={() => {
                onToggleExplode();
                soundFx.playSelect();
              }}
              title="Exploded Anatomical Lobe View"
              className={`flex items-center gap-1 px-2.5 py-1 rounded border transition-all ${
                isExploded
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-cyan-300'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Explode</span>
            </button>
          )}

          {/* Auto Rotate Toggle */}
          {show3dCanvas && (
            <button
              onClick={() => {
                onToggleRotate();
                soundFx.playChirp();
              }}
              title="Auto-rotate Brain"
              className={`flex items-center gap-1 px-2.5 py-1 rounded border transition-all ${
                isRotating
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-slate-900/80 border-slate-700/60 text-slate-400 hover:text-cyan-300'
              }`}
            >
              <RotateCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Rotate</span>
            </button>
          )}

          {/* SFX Mute/Unmute */}
          <button
            onClick={handleToggleSound}
            title={isMuted ? 'Unmute Audio Feedback' : 'Mute Audio Feedback'}
            className="p-1 rounded bg-slate-900/80 border border-slate-700/60 text-slate-400 hover:text-cyan-300 transition-colors"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-slate-500" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Flanking Subsystem Cards (Left & Right) */}
      <div className="flex-1 relative flex items-center justify-between my-2 overflow-hidden pointer-events-none">
        {/* Left Side Subsystem Cards */}
        <div className="pointer-events-auto flex flex-col gap-2.5 w-60 sm:w-64 max-h-full overflow-y-auto pr-1">
          {leftSubsystems.map((subId) => {
            const sub = subsystems[subId];
            const isSelected = selectedSubsystemId === subId;
            return (
              <div
                key={subId}
                onClick={() => {
                  onSelectSubsystem(subId);
                  soundFx.playSelect();
                }}
                className={`group relative flex items-center gap-3 p-2.5 rounded-xl border backdrop-blur-md transition-all cursor-pointer ${
                  isSelected
                    ? 'border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.35)] translate-x-1.5'
                    : 'border-slate-800/80 hover:border-slate-700 hover:translate-x-1'
                }`}
                style={{
                  background: isSelected ? sub.accentBg : 'rgba(3, 11, 26, 0.72)',
                  borderColor: isSelected ? sub.color : undefined,
                }}
              >
                {/* Icon Capsule */}
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 border transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: sub.accentBg,
                    borderColor: sub.color,
                    color: sub.color,
                  }}
                >
                  {getSubsystemIcon(subId)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-orbitron font-semibold text-xs text-white truncate">
                      {sub.title}
                    </span>
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{
                        backgroundColor: sub.color,
                        boxShadow: `0 0 8px ${sub.color}`,
                      }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 font-rajdhani truncate leading-tight">
                    {sub.subtitle}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono-code truncate mt-0.5">
                    ({sub.providers})
                  </div>
                </div>

                {/* Connecting Node Pointer Beam */}
                <div
                  className={`absolute -right-3 top-1/2 -translate-y-1/2 w-3 h-0.5 transition-all ${
                    isSelected ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
                  }`}
                  style={{ backgroundColor: sub.color, boxShadow: `0 0 6px ${sub.color}` }}
                />
              </div>
            );
          })}
        </div>

        {/* Right Side Subsystem Cards */}
        <div className="pointer-events-auto flex flex-col gap-2.5 w-60 sm:w-64 max-h-full overflow-y-auto pl-1">
          {rightSubsystems.map((subId) => {
            const sub = subsystems[subId];
            const isSelected = selectedSubsystemId === subId;
            return (
              <div
                key={subId}
                onClick={() => {
                  onSelectSubsystem(subId);
                  soundFx.playSelect();
                }}
                className={`group relative flex items-center gap-3 p-2.5 rounded-xl border backdrop-blur-md transition-all cursor-pointer ${
                  isSelected
                    ? 'border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.35)] -translate-x-1.5'
                    : 'border-slate-800/80 hover:border-slate-700 hover:-translate-x-1'
                }`}
                style={{
                  background: isSelected ? sub.accentBg : 'rgba(3, 11, 26, 0.72)',
                  borderColor: isSelected ? sub.color : undefined,
                }}
              >
                {/* Connecting Node Pointer Beam Left */}
                <div
                  className={`absolute -left-3 top-1/2 -translate-y-1/2 w-3 h-0.5 transition-all ${
                    isSelected ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
                  }`}
                  style={{ backgroundColor: sub.color, boxShadow: `0 0 6px ${sub.color}` }}
                />

                {/* Icon Capsule */}
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 border transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: sub.accentBg,
                    borderColor: sub.color,
                    color: sub.color,
                  }}
                >
                  {getSubsystemIcon(subId)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-orbitron font-semibold text-xs text-white truncate">
                      {sub.title}
                    </span>
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{
                        backgroundColor: sub.color,
                        boxShadow: `0 0 8px ${sub.color}`,
                      }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 font-rajdhani truncate leading-tight">
                    {sub.subtitle}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono-code truncate mt-0.5">
                    ({sub.providers})
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Telemetry Cards Strip (Matching Reference Image) */}
      <div className="pointer-events-auto grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-950/75 border border-cyan-500/25 rounded-xl p-3 backdrop-blur-md">
        {/* Card 1: Active Model */}
        <div className="flex items-center gap-3 px-2 py-1">
          <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Cpu className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] text-slate-400 font-rajdhani uppercase tracking-wider">
              Active Model
            </div>
            <div className="flex items-center gap-2">
              <span className="font-orbitron font-bold text-xs text-white truncate">
                {telemetry.activeModel}
              </span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-mono-code bg-cyan-950 border border-cyan-400/50 text-cyan-300 font-semibold">
                {telemetry.modelBadge}
              </span>
            </div>
            <div className="text-[10px] text-slate-500 font-rajdhani">
              Reasoning & Code
            </div>
          </div>
        </div>

        {/* Card 2: Model Router */}
        <div className="flex items-center gap-3 px-2 py-1 border-t md:border-t-0 md:border-l border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
            <GitBranch className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] text-slate-400 font-rajdhani uppercase tracking-wider">
              Model Router
            </div>
            <div className="font-orbitron font-bold text-xs text-emerald-300">
              {telemetry.routerMode}
            </div>
            <div className="text-[10px] text-slate-500 font-rajdhani">
              Smart selection based on task
            </div>
          </div>
        </div>

        {/* Card 3: Memory Status (D:\JARVIS_DATA) */}
        <div className="flex items-center gap-3 px-2 py-1 border-t md:border-t-0 md:border-l border-slate-800/80">
          <div className="w-8 h-8 rounded-lg bg-purple-950/60 border border-purple-500/40 flex items-center justify-center text-purple-400 shrink-0">
            <Database className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[10px] font-rajdhani">
              <span className="text-slate-400 uppercase tracking-wider">Memory Status</span>
              <span className="text-purple-300 font-mono-code">
                {telemetry.memoryUsedGB} GB / {telemetry.memoryMaxGB} GB ({memoryPercent}%)
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mt-1.5 border border-purple-500/20">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-cyan-400 rounded-full transition-all duration-500"
                style={{ width: `${memoryPercent}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-500 font-rajdhani mt-0.5 truncate">
              ChromaDB • D:\JARVIS_DATA
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
