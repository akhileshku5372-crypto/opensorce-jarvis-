"""KamiSensei backend API service package.

Contains the canonical local file-system controllers for notebook lifecycle
(backend.api.notebooks) and knowledge-base ingestion (backend.api.upload).

These modules are the authoritative disk-execution layer invoked by the
loopback bridge (local-bridge/server.cjs). Everything here uses only the
Python standard library so it boots with zero third-party requirements.
"""