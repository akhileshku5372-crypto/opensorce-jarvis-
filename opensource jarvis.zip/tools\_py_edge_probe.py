import asyncio, edge_tts

async def synth(text, voice, rate='+0%'):
    c = edge_tts.Communicate(text, voice=voice, rate=rate)
    out = b''
    async for ch in c.stream():
        if ch['type'] == 'audio':
            out += ch['data']
    return out

async def main():
    cases = [
        ('English', 'Hello JARVIS, status report', 'en-GB-RyanNeural', '-5%'),
        ('Hindi', 'नमस्ते आप कैसे हैं', 'hi-IN-MadhurNeural', '+4%'),
        ('Japanese', 'こんにちは、元気ですか。', 'ja-JP-KeitaNeural', '+0%'),
        ('MIXED', 'नमस्ते please こんにちは।', 'en-US-AndrewMultilingualNeural', '-3%'),
    ]
    for name, text, voice, rate in cases:
        try:
            b = await asyncio.wait_for(synth(text, voice, rate), timeout=25)
            magic = b[:4].hex()
            kind = 'MP3' if (b[:1] == b'\xff' or b[:3] == b'ID3') else ('WAV' if b[:4] == b'RIFF' else 'OTHER')
            print(f'{name:8} -> voice={voice} | bytes={len(b)} | {kind} (head={magic})')
        except Exception as e:
            print(f'{name:8} -> ERROR: {type(e).__name__}: {e}')

asyncio.run(main())
