"""Phase 4.3 - Google Calendar daily agenda, read-only.

"JARVIS, aaj ka calendar batao" / "agenda kya hai" is answered from the real
calendar through the Google Calendar v3 API with the ``calendar.readonly``
scope. Like Gmail, there is no create/update/delete path here: the capability is
absent by construction, not by a switch somebody could forget.

Honesty rules
-------------
* Returns ``{"ok": False, "error": ...}`` with a reason instead of raising.
* An empty day is answered as "koi event nahi", never as a silent success.
* Event times are converted to the machine's local timezone and spoken the way a
  person would say them; all-day events are reported as all-day, not 00:00.
"""

from __future__ import annotations

import datetime as _dt

try:
    import oauth_bridge as _oauth
    import storage_paths as _paths
except ImportError:                                  # pragma: no cover
    from background import oauth_bridge as _oauth
    from background import storage_paths as _paths

API = "https://www.googleapis.com/calendar/v3"
SCOPE = "https://www.googleapis.com/auth/calendar.readonly"
MAX_EVENTS = 25


def token_path():
    return _paths.jarvis_apps_dir() / "calendar.token"


def _svc():
    return _oauth.Service("calendar", [SCOPE], token_path(),
                          "CALENDAR_CLIENT_ID", "CALENDAR_CLIENT_SECRET")


def authorize_url() -> dict:
    return _svc().authorize_url()


def connect(code: str) -> dict:
    return _svc().exchange_code(code)


def status() -> dict:
    info = _svc().status()
    info["scope"] = SCOPE
    info["read_only"] = True
    return info


def _fail(res: dict) -> dict:
    return {"ok": False, "error": res.get("reason") or res.get("error")
            or "unknown error", "status": res.get("status", 0)}


def _when(raw: dict) -> str:
    """Local-time label for a Google event start/end object."""
    if not isinstance(raw, dict):
        return ""
    if raw.get("dateTime"):
        try:
            stamp = _dt.datetime.fromisoformat(
                str(raw["dateTime"]).replace("Z", "+00:00"))
        except ValueError:
            return str(raw["dateTime"])
        local = stamp.astimezone()
        today = _dt.date.today()
        if local.date() == today:
            return "aaj %s" % local.strftime("%I:%M %p").lstrip("0")
        if local.date() == today + _dt.timedelta(days=1):
            return "kal %s" % local.strftime("%I:%M %p").lstrip("0")
        return local.strftime("%d %b %I:%M %p").lstrip("0")
    if raw.get("date"):
        return "poora din"
    return ""


def _end_when(raw: dict) -> str:
    if isinstance(raw, dict) and raw.get("dateTime"):
        try:
            stamp = _dt.datetime.fromisoformat(
                str(raw["dateTime"]).replace("Z", "+00:00"))
            return stamp.astimezone().strftime("%I:%M %p").lstrip("0")
        except ValueError:
            return ""
    return ""


def _rows(payload: dict) -> list:
    rows = []
    for item in (payload or {}).get("items", []) or []:
        if item.get("status") == "cancelled":
            continue
        start = item.get("start", {}) or {}
        end = item.get("end", {}) or {}
        rows.append({
            "id": item.get("id", ""),
            "summary": item.get("summary") or "(no title)",
            "when": _when(start),
            "until": _end_when(end),
            "all_day": bool(start.get("date") and not start.get("dateTime")),
            "location": (item.get("location") or "").strip(),
            "link": item.get("htmlLink", ""),
        })
    return rows[:MAX_EVENTS]


def _window_events(start: _dt.datetime, end: _dt.datetime, max_results: int) -> dict:
    svc = _svc()
    res = svc.get("%s/calendars/primary/events" % API, params={
        "timeMin": start.astimezone(_dt.timezone.utc).isoformat(),
        "timeMax": end.astimezone(_dt.timezone.utc).isoformat(),
        "singleEvents": "true",
        "orderBy": "startTime",
        "maxResults": max_results,
    })
    if not res["ok"]:
        return _fail(res)
    rows = _rows(res["data"] or {})
    return {"ok": True, "count": len(rows), "results": rows,
            "window": "%s -> %s" % (start.isoformat(), end.isoformat())}


def today_agenda(max_results: int = MAX_EVENTS) -> dict:
    """Every remaining event of today in the machine's local timezone."""
    now = _dt.datetime.now().astimezone()
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + _dt.timedelta(days=1)
    return _window_events(start, end, max_results)


def upcoming(n: int = 5) -> dict:
    """The next `n` events from now."""
    try:
        n = max(1, min(int(n or 5), MAX_EVENTS))
    except (TypeError, ValueError):
        n = 5
    now = _dt.datetime.now().astimezone()
    return _window_events(now, now + _dt.timedelta(days=60), n)


def spoken_today(out: dict) -> str:
    if not out.get("ok"):
        return ("Calendar nahi padh saka: %s" % out.get("error", "unknown error"))
    rows = out.get("results") or []
    if not rows:
        return "Sir, aaj ka calendar khaali hai, koi meeting nahi."
    parts = ["Sir, aaj %d event%s hain:" % (len(rows), "" if len(rows) == 1
                                              else "s")]
    for idx, row in enumerate(rows, 1):
        line = "%d. %s - %s" % (idx, row.get("when", ""), row.get("summary", ""))
        if row.get("all_day"):
            line = "%d. %s (poora din)" % (idx, row.get("summary", ""))
        if row.get("location"):
            line += ", %s" % row["location"]
        parts.append(line)
    return " ".join(parts) + "."


def spoken_upcoming(out: dict) -> str:
    if not out.get("ok"):
        return "Agenda nahi mila: %s" % out.get("error", "unknown error")
    rows = out.get("results") or []
    if not rows:
        return "Sir, aage koi scheduled event nahi hai."
    parts = ["Sir, aage %d event%s:" % (len(rows), "" if len(rows) == 1
                                         else "s")]
    for idx, row in enumerate(rows, 1):
        parts.append("%d. %s, %s" % (idx, row.get("when", ""),
                                     row.get("summary", "")))
    return " ".join(parts) + "."


# ── registry tool wrappers (real ToolRegistry, see plugin.py) ──────────────


def _tool_calendar_today(args=None):
    return today_agenda()


def _tool_calendar_upcoming(args=None):
    args = args or {}
    return upcoming(args.get("n", 5))


def _tool_calendar_status(args=None):
    return status()


def _tool_calendar_authorize_url(args=None):
    return authorize_url()


def _tool_calendar_connect(args=None):
    args = args or {}
    return connect(args.get("code", ""))