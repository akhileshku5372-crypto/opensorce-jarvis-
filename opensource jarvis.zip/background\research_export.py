"""Export a finished deep-research payload to MD / DOCX / PDF / PPTX.

Nothing here calls a model. The prose already exists (the writer pool produced
it, in the language the console chose), so an export is a formatting job - which
also means exporting costs zero tokens from any provider.

The honesty rule carries into the files: every export prints what was actually
read, and lists the sources that FAILED. A deck must never look more confident
than the run that produced it.
"""

import json
import os
import re
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "artifacts", "research")
FORMATS = ("md", "docx", "pdf", "pptx")

# What the user says -> the format key
_ALIASES = {
    "md": "md", "markdown": "md",
    "docx": "docx", "doc": "docx", "word": "docx", "document": "docx",
    "pdf": "pdf",
    "pptx": "pptx", "ppt": "pptx", "powerpoint": "pptx", "slide": "pptx",
    "slides": "pptx", "deck": "pptx", "presentation": "pptx",
}


def _clean(value, limit=4000):
    return re.sub(r"[ \t]+", " ", str(value or "")).strip()[:limit]


def _slug(value):
    slug = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return slug[:60] or "research"


def usable(payload):
    """True when a payload has real content to export."""
    return bool(isinstance(payload, dict) and not payload.get("error")
                and (payload.get("report") or payload.get("sections")))


def _blocks(report):
    """Split the report into (heading, [lines]) blocks for every renderer."""
    # 40,000 chars is above any report this engine can produce (compose caps at
    # 4,500, the dossier at ~11,000), so a file never silently loses the run.
    text = _clean(report, 40000).replace(chr(13) + chr(10), chr(10))
    blocks, heading, lines = [], "", []
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        bullet = re.match(r"^([•\-*]|\d+[.)])\s+(.*)$", line)
        if bullet and not heading:
            heading = "Findings"
        is_heading = (not bullet and len(line) <= 60 and not re.search(r"[.;:!?]$", line)
                      and re.match(r"^[A-Z0-9(]", line))
        if is_heading:
            if lines or heading:
                blocks.append((heading, lines))
            heading, lines = line, []
            continue
        lines.append(line)
    if heading or lines:
        blocks.append((heading, lines))
    return [(h or "Report", ls) for h, ls in blocks if ls or h]


def _stats(payload):
    detail = payload.get("sources_detail") or []
    return [
        "tier: %s" % _clean(payload.get("tier") or "deep", 20),
        "pages read: %s of %s attempted" % (payload.get("scraped", 0), payload.get("attempted", len(detail))),
        "distinct hosts: %s" % payload.get("hosts", len({d.get("host") for d in detail if d.get("ok")})),
        "claims: %s cross-checked, %s single-source" % (payload.get("cross_checked", 0),
                                                        payload.get("single_source", 0)),
        "results: %s found -> %s unique (%s collapsed)" % (payload.get("found", 0),
                                                           payload.get("unique", 0),
                                                           payload.get("collapsed", 0)),
        "providers answered: %s of %s" % (payload.get("answered", "?"), payload.get("chain_size", "?")),
        "written by: %s" % _clean(payload.get("written_by") or "dossier", 40),
        "elapsed: %.0fs" % ((int(payload.get("ms") or 0)) / 1000.0),
    ]


def _source_rows(payload):
    detail = payload.get("sources_detail") or []
    rows = []
    for item in detail:
        rows.append({
            "host": _clean(item.get("host") or "", 60),
            "url": _clean(item.get("url") or "", 220),
            "ok": bool(item.get("ok")),
            "note": ("read %s" % ("%.1f KB" % (item.get("bytes", 0) / 1024.0))
                     if item.get("ok") else _clean(item.get("error") or "failed", 60)),
        })
    if not rows:
        for url in (payload.get("sources") or []):
            rows.append({"host": _clean(str(url).split("/")[2] if "//" in str(url) else str(url), 60),
                         "url": _clean(url, 220), "ok": True, "note": "listed"})
    return rows


def _signature(payload):
    """What the file will contain - so an unchanged re-export is not rewritten."""
    import hashlib
    core = "%s|%s|%s" % (payload.get("topic"), payload.get("tier"),
                         _clean(payload.get("report"), 20000))
    return hashlib.sha1(core.encode("utf-8")).hexdigest()[:12]


def _base_name(payload, fmt):
    # NO timestamp: "research X" exported to PDF twice must be ONE file that gets
    # refreshed, not a new file every minute (Sir's storage complaint, live).
    return os.path.join(OUT_DIR, "%s.%s" % (_slug(payload.get("topic")), fmt))


def _write_md(payload, path):
    topic = _clean(payload.get("topic") or "Research", 200)
    out = ["# %s" % topic, "", "_JARVIS deep research · %s_" % time.strftime("%Y-%m-%d %H:%M"), ""]
    out += ["## Verification", ""] + ["- %s" % s for s in _stats(payload)] + [""]
    for heading, lines in _blocks(payload.get("report")):
        out += ["## %s" % heading, ""]
        for line in lines:
            out.append("- %s" % line)
        out.append("")
    rows = _source_rows(payload)
    if rows:
        out += ["## Sources (%d attempted)" % len(rows), ""]
        out += ["%d. %s — %s — %s" % (i + 1, r["url"], r["host"], "READ" if r["ok"] else "FAILED: " + r["note"])
                for i, r in enumerate(rows)]
        out.append("")
    failed = [r for r in rows if not r["ok"]]
    if failed:
        out += ["## Sources that could NOT be read (%d)" % len(failed), ""]
        out += ["- %s — %s" % (r["url"], r["note"]) for r in failed] + [""]
    body = "\n".join(out)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body)
    return {"chars": len(body)}


def _write_docx(payload, path):
    from docx import Document
    from docx.shared import Pt

    topic = _clean(payload.get("topic") or "Research", 200)
    doc = Document()
    doc.add_heading(topic, level=0)
    p = doc.add_paragraph("JARVIS deep research · %s" % time.strftime("%Y-%m-%d %H:%M"))
    p.runs[0].font.size = Pt(9)
    doc.add_heading("Verification", level=1)
    for line in _stats(payload):
        doc.add_paragraph(line, style="List Bullet")
    for heading, lines in _blocks(payload.get("report")):
        doc.add_heading(heading, level=1)
        for line in lines:
            doc.add_paragraph(re.sub(r"^\d+[.)]\s+", "", line), style="List Bullet")
    rows = _source_rows(payload)
    if rows:
        doc.add_heading("Sources (%d attempted)" % len(rows), level=1)
        table = doc.add_table(rows=1, cols=3)
        hdr = table.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text = "Source", "Host", "Status"
        for r in rows:
            cells = table.add_row().cells
            cells[0].text = r["url"][:180]
            cells[1].text = r["host"]
            cells[2].text = ("READ · " + r["note"]) if r["ok"] else ("FAILED · " + r["note"])
    doc.save(path)
    return {"paragraphs": len(doc.paragraphs), "sources": len(rows)}


def _write_pdf(payload, path):
    """Hand-laid-out PDF: deterministic pagination, no HTML engine guessing.

    Measured on pymupdf 1.28.2: Story.write's rectfn wants 3 return values and
    insert_htmlbox in a loop duplicated the document on every page, so the text
    is wrapped and placed line by line instead. CJK lines switch to the built-in
    'japan' font; Latin/Hinglish uses Helvetica.
    """
    import pymupdf

    latin, cjk = "helv", "japan"
    _cjk = re.compile(r"[\u3000-\u9fff\uac00-\ud7af]")

    def font_for(text):
        return cjk if _cjk.search(text) else latin

    def width_of(text, font, size):
        return pymupdf.get_text_length(text, fontname=font, fontsize=size)

    def wrap(text, font, size, limit):
        lines, cur = [], ""
        for word in str(text).split():
            trial = (cur + " " + word).strip()
            if not cur or width_of(trial, font, size) <= limit:
                cur = trial
                continue
            lines.append(cur)
            cur = word
        if cur:
            lines.append(cur)
        return lines or [""]

    doc = pymupdf.open()
    page = None
    state = {"y": 0.0, "pages": 0}
    left, right, top, bottom = 48.0, 547.0, 56.0, 790.0

    def new_page():
        page = doc.new_page(width=595, height=842)
        state["pages"] += 1
        state["y"] = top
        state["page"] = page
        return page

    def emit(text, size=10.5, bold=False, gap=4.0, color=(0.12, 0.16, 0.19), indent=0.0):
        text = re.sub(r"\s+", " ", str(text or "")).strip()
        if not text:
            return
        font = font_for(text)
        # The CJK built-ins have no bold variant - asking for one raises.
        weight_font = ("hebo" if bold else "helv") if font == latin else font
        limit = right - left - indent
        for line in wrap(text, weight_font, size, limit):
            if state["y"] + size + gap > bottom:
                new_page()
            state["page"].insert_text(
                (left + indent, state["y"] + size), line, fontsize=size,
                fontname=weight_font, color=color)
            state["y"] += size + gap

    def heading(text, size=13.0):
        state["y"] += 8
        emit(text, size=size, bold=True, gap=5.0, color=(0.09, 0.55, 0.72))
        state["y"] += 2

    new_page()
    heading(_clean(payload.get("topic") or "Research", 160), size=17)
    emit("JARVIS deep research · %s" % time.strftime("%Y-%m-%d %H:%M"),
         size=8.5, color=(0.44, 0.57, 0.63))
    heading("Verification", size=12)
    for stat in _stats(payload):
        emit(stat, size=9.5, gap=3.0, indent=10)
    for title, lines in _blocks(payload.get("report")):
        heading(title, size=12)
        for line in lines:
            emit("•  " + re.sub(r"^\d+[.)]\s+", "", line), size=10.5, gap=4.5, indent=6)
    rows = _source_rows(payload)
    if rows:
        heading("Sources (%d attempted)" % len(rows), size=12)
        for index, row in enumerate(rows, 1):
            mark = "read" if row["ok"] else "FAILED"
            emit("%d. %s  [%s]  %s" % (index, row["url"], mark, row["note"]),
                 size=9, gap=3.0, indent=6,
                 color=(0.12, 0.16, 0.19) if row["ok"] else (0.75, 0.24, 0.28))
    doc.save(path, deflate=True, garbage=3)
    pages = state["pages"]
    doc.close()
    if not pages:
        raise RuntimeError("pdf writer produced no pages")
    return {"pages": pages}


def _deck(payload):
    """Build the slide deck from the payload alone - no model, no new prose."""
    slides = []
    for heading, lines in _blocks(payload.get("report")):
        bullets, notes = [], []
        for line in lines:
            text = re.sub(r"^\d+[.)]\s+", "", line)
            (bullets if len(bullets) < 6 else notes).append(text)
        slides.append({"heading": heading, "bullets": bullets,
                       "speaker_notes": " ".join(notes)[:600]})
        if len(slides) >= 9:
            break
    stats = _stats(payload)
    slides.append({"heading": "How this was verified", "bullets": stats[:7],
                   "speaker_notes": "Generated by JARVIS deep research. Counts are what the "
                                    "run actually read, not an estimate."})
    rows = _source_rows(payload)
    for i in range(0, min(len(rows), 24), 5):
        chunk = rows[i:i + 5]
        slides.append({
            "heading": "Sources %d-%d" % (i + 1, i + len(chunk)),
            # The URL goes on the slide: a deck whose citations cannot be traced
            # is decoration. ASCII separators only - the theme font renders
            # "·" and "—" as boxes in PowerPoint.
            "bullets": ["%s - %s - %s" % (r["host"], ("READ" if r["ok"] else "FAILED: " + r["note"]),
                                          r["url"][:90]) for r in chunk],
            "speaker_notes": " | ".join(r["url"] for r in chunk)[:900]})
    return {"title": _clean(payload.get("topic") or "Deep research", 90),
            "subtitle": "JARVIS | tier %s | %s/%s pages read | %s hosts" % (
                payload.get("tier") or "deep", payload.get("scraped", 0),
                payload.get("attempted", len(rows)), payload.get("hosts", 0)),
            "slides": slides}


def _write_pptx(payload, path):
    builder = _load_sibling("presentation_builder")
    if builder is None:
        raise RuntimeError("presentation_builder not importable")
    deck = _deck(payload)
    ok, detail = builder.render_pptx(deck, __import__("pathlib").Path(path), "jarvis")
    if not ok:
        raise RuntimeError(str(detail))
    return {"slides": len(deck["slides"]), "detail": str(detail)[:120]}


def _load_sibling(name):
    key = "jarvis_research_export_" + name
    import sys
    if key in sys.modules:
        return sys.modules[key]
    try:
        import importlib.util
        mod_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), name + ".py")
        spec = importlib.util.spec_from_file_location(key, mod_path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def export(fmt, payload):
    """Write one file for the payload. Returns (path, meta) - path None on failure."""
    fmt = str(fmt or "").lower().strip()
    if fmt == "document":
        fmt = "docx"
    if fmt not in FORMATS:
        return None, {"error": "unknown format %r (use: %s)" % (fmt, ", ".join(FORMATS))}
    if not usable(payload):
        return None, {"error": "koi exportable research nahi hai - pehle research karo"}
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
        path = _base_name(payload, fmt)
        started = time.time()
        sig = _signature(payload)
        previous = ((payload.get("export") or {}).get(fmt) or {})
        if (previous.get("signature") == sig and os.path.exists(previous.get("path") or path)
                and os.path.abspath(previous.get("path") or path) == os.path.abspath(path)):
            return previous["path"], {"format": fmt, "topic": _clean(payload.get("topic"), 120),
                                      "path": previous["path"], "bytes": os.path.getsize(previous["path"]),
                                      "signature": sig, "already": True, "ms": 0}
        meta = {"format": fmt, "topic": _clean(payload.get("topic"), 120), "signature": sig}
        for key, fn in (("md", _write_md), ("docx", _write_docx), ("pdf", _write_pdf), ("pptx", _write_pptx)):
            if fmt == key:
                meta.update(fn(payload, path))
        if not os.path.exists(path):
            return None, {"error": "writer ne file nahi banayi"}
        meta.update({"path": path, "bytes": os.path.getsize(path),
                     "ms": int((time.time() - started) * 1000)})
        return path, meta
    except Exception as exc:
        return None, {"error": "%s: %s" % (type(exc).__name__, str(exc)[:200])}


def formats_for(text):
    """Map a spoken/written request to a format key, or None."""
    found = None
    for word in re.findall(r"[a-z]+", str(text or "").lower()):
        if word in _ALIASES:
            found = _ALIASES[word]
    return found


if __name__ == "__main__":
    import sys
    sample = {"type": "research", "topic": "test export", "tier": "deep",
              "report": "Overview\nSomething was found.\n\nKey findings\n- Fact one 42 percent\n- Fact two",
              "scraped": 2, "attempted": 3, "hosts": 2, "cross_checked": 1, "single_source": 1,
              "found": 9, "unique": 6, "collapsed": 3, "answered": 4, "chain_size": 8,
              "written_by": "free-writer", "ms": 33000,
              "sources_detail": [{"host": "a.com", "url": "https://a.com/1", "ok": True, "bytes": 9012},
                                 {"host": "b.com", "url": "https://b.com/2", "ok": False, "error": "HTTP 403"}]}
    for f in FORMATS:
        p, m = export(f, sample)
        print(f, "->", p or m.get("error"), json.dumps({k: v for k, v in m.items() if k != "path"}))
    sys.exit(0)
