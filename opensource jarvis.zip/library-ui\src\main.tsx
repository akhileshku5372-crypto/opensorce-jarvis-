import { createRoot, type Root } from 'react-dom/client'
import App from './App'
import './index.css'

/* The archive UI is a client of JARVIS, not a page of its own: it mounts into
 * the #library-root container inside the Skill Library view, so the dashboard
 * sidebar, topbar and the one command path stay the only chrome. The zip's own
 * top telemetry bar and left drawer were dropped for that reason.
 */
let root: Root | null = null

declare global {
  interface Window {
    __JARVIS_LIBRARY__?: { mount(el: HTMLElement): void; unmount(): void }
  }
}

window.__JARVIS_LIBRARY__ = {
  mount(el: HTMLElement) {
    if (!root) root = createRoot(el)
    root.render(<App />)
  },
  unmount() {
    root?.unmount()
    root = null
  },
}
