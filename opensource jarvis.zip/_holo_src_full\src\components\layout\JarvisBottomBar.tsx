/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mic, Send, SlidersHorizontal, Sparkles } from 'lucide-react';
import { soundFx } from '../../services/soundEffects';

interface JarvisBottomBarProps {
  onSendMessage: (text: string) => void;
  isProcessing: boolean;
}

export const JarvisBottomBar: React.FC<JarvisBottomBarProps> = ({
  onSendMessage,
  isProcessing,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim() || isProcessing) return;
    soundFx.playPulse();
    onSendMessage(inputVal.trim());
    setInputVal('');
  };

  const handleMicToggle = () => {
    soundFx.playSelect();
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      try {
        const SpeechRecognition =
          (window as unknown as { SpeechRecognition: any; webkitSpeechRecognition: any }).SpeechRecognition ||
          (window as unknown as { webkitSpeechRecognition: any }).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        recognition.continuous = false;
        recognition.interimResults = false;

        recognition.onstart = () => setIsListening(true);
        recognition.onend = () => setIsListening(false);
        recognition.onresult = (event: any) => {
          const text = event.results[0][0].transcript;
          if (text) {
            setInputVal(text);
            onSendMessage(text);
          }
        };
        recognition.start();
      } catch {
        setIsListening(false);
      }
    } else {
      // Fallback: cycle mock voice prompt
      const prompts = [
        "Analyze cognitive workload in prefrontal cortex",
        "Scan episodic memory vectors in ChromaDB",
        "Simulate action potential surge in occipital lobe",
        "Verify Windows Bridge and Agent-S automation",
      ];
      const randomPrompt = prompts[Math.floor(Math.random() * prompts.length)];
      setInputVal(randomPrompt);
    }
  };

  return (
    <footer className="h-16 border-t border-cyan-500/20 bg-slate-950/90 backdrop-blur-md px-4 flex items-center gap-3 select-none z-30 shrink-0 font-rajdhani">
      {/* Microphone Button */}
      <button
        onClick={handleMicToggle}
        title="Voice Command (Say 'Hey JARVIS')"
        className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all ${
          isListening
            ? 'bg-red-500/20 border-red-500 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-pulse'
            : 'bg-cyan-950/40 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/20 hover:border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
        }`}
      >
        <Mic className="w-5 h-5" />
      </button>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex-1 relative flex items-center">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Message JARVIS or say 'Open YouTube and search for AI news'"
          className="w-full h-11 bg-slate-900/90 border border-cyan-500/25 rounded-xl pl-4 pr-24 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 shadow-inner font-sans transition-all"
        />

        <div className="absolute right-2 flex items-center gap-1.5">
          <button
            type="button"
            title="Prompt Options"
            className="p-1.5 text-slate-400 hover:text-cyan-300 transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>

          <button
            type="submit"
            disabled={!inputVal.trim() || isProcessing}
            title="Dispatch Neural Command"
            className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
              inputVal.trim() && !isProcessing
                ? 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.5)]'
                : 'bg-slate-800 text-slate-600 cursor-not-allowed'
            }`}
          >
            {isProcessing ? (
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </div>
      </form>
    </footer>
  );
};
