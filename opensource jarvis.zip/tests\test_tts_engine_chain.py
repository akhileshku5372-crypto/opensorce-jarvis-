"""Regression: JARVIS answering with text and silence when one TTS engine fails.

The live failure measured 2026-10-16: `gemini-3.8-flash-lite-tts` returned
HTTP 429 (quota) and later a 170s response. The chain that day was Gemini
first, then two fallbacks each hidden behind an env flag nobody had set, so
_gemini_synthesize() returned None and speak() produced no audio at all - the
reply appeared on screen and JARVIS never opened its mouth.

Stdlib + fakes only: no audio, no network, no mic.
"""
import importlib.util
import sys
import threading
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load("voice_engine")

TEXT = "All systems operational, sir."


class EngineChainTest(unittest.TestCase):
    """A dead primary engine must fall through to the next one, always."""

    def setUp(self):
        self.engine = ENGINE
        self.calls = []
        ENGINE._TTS_DOWN_UNTIL.clear()
        ENGINE._TTS_FAILS.clear()
        self.addCleanup(self._reset)

    def _reset(self):
        ENGINE._TTS_DOWN_UNTIL.clear()
        ENGINE._TTS_FAILS.clear()
        ENGINE._SPEAKING.clear()

    def _fake(self, name, path):
        def synth(*_a, **_kw):
            self.calls.append(name)
            return path
        return synth

    def _speak(self, edge, gemini):
        """Run one speak() turn with the synths stubbed; return what played."""
        with mock.patch.object(ENGINE, "_edge_synthesize", side_effect=edge), \
             mock.patch.object(ENGINE, "_gemini_synthesize", side_effect=gemini), \
             mock.patch.object(ENGINE, "_play_mp3",
                               side_effect=lambda p, g: self.calls.append("play:" + p) or True):
            thread = ENGINE.speak(TEXT, "test-ui")
            self.assertIsNotNone(thread, "speak() did not start a worker")
            thread.join(timeout=20)
        self.assertFalse(thread.is_alive(), "tts worker never finished")

    def test_gemini_failure_still_gets_audio(self):
        """The original bug: gemini None used to mean total silence."""
        self._speak(edge=self._fake("edge", "e.mp3"),
                    gemini=self._fake("gemini", None))
        self.assertIn("edge", self.calls, "edge-tts was never attempted")
        self.assertIn("play:e.mp3", self.calls,
                      "edge audio was produced but not played: %s" % self.calls)

    def test_default_order_prefers_the_fast_engine(self):
        """edge-tts measured 2.0s, Gemini 3.4-170s - edge must be first."""
        self.assertEqual(ENGINE._TTS_ORDER[0], "edge",
                         "default order is %s" % ENGINE._TTS_ORDER)
        self._speak(edge=self._fake("edge", "e.mp3"),
                    gemini=self._fake("gemini", "g.wav"))
        self.assertEqual(self.calls[:2], ["edge", "play:e.mp3"],
                         "a working Gemini must not be paid for when edge spoke")

    def test_second_engine_used_when_first_is_dead(self):
        self._speak(edge=self._fake("edge", None),
                    gemini=self._fake("gemini", "g.wav"))
        self.assertEqual(self.calls[:2], ["edge", "gemini"],
                         "chain did not advance past the failed engine")
        self.assertIn("play:g.wav", self.calls)

    def test_engine_skipped_after_repeated_failures(self):
        """A 403 edge must cost one short attempt, not a timeout every turn."""
        dead = self._fake("edge", None)
        for _ in range(ENGINE._TTS_SKIP_AFTER):
            self._speak(edge=dead, gemini=self._fake("gemini", "g.wav"))
        self.assertTrue(ENGINE._tts_engine_ready("gemini"))
        self.assertFalse(ENGINE._tts_engine_ready("edge"),
                         "the known-dead engine is still being tried")
        before = list(self.calls)
        self._speak(edge=dead, gemini=self._fake("gemini", "g.wav"))
        self.assertNotIn("edge", self.calls[len(before):],
                         "cooldown expired immediately")

    def test_no_engine_means_text_only_not_a_crash(self):
        self._speak(edge=self._fake("edge", None),
                    gemini=self._fake("gemini", None))
        self.assertEqual(ENGINE.get_state()["status"], "error")


class KeyHealthTest(unittest.TestCase):
    """A slow Gemini render is not a bad key."""

    KEY = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345"

    def setUp(self):
        # _KEY_COOLDOWN is module state; the 429 case writes it and would
        # otherwise leak into the timeout case and fake a failure.
        with ENGINE._KEY_COOLDOWN_LOCK:
            ENGINE._KEY_COOLDOWN.pop(self.KEY, None)
        self.addCleanup(self._clear)

    def _clear(self):
        with ENGINE._KEY_COOLDOWN_LOCK:
            ENGINE._KEY_COOLDOWN.pop(self.KEY, None)

    def test_timeout_does_not_poison_the_key(self):
        import requests
        key = self.KEY
        with mock.patch.dict(sys.modules["os"].environ, {"GOOGLE_API_KEY": key}), \
             mock.patch.object(ENGINE, "_get_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE, "_get_active_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE._GEMINI_SESSION, "post",
                               side_effect=requests.exceptions.Timeout()):
            self.assertIsNone(ENGINE._gemini_synthesize("hello", "en"))
        with ENGINE._KEY_COOLDOWN_LOCK:
            self.assertNotIn(key, ENGINE._KEY_COOLDOWN,
                             "one timeout put the key on a 300s cooldown")

    def test_429_still_rotates_the_key(self):
        key = self.KEY
        resp = mock.Mock(status_code=429, text="quota", json=lambda: {})
        with mock.patch.object(ENGINE, "_get_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE, "_get_active_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE._GEMINI_SESSION, "post", return_value=resp):
            self.assertIsNone(ENGINE._gemini_synthesize("hello", "en"))
        with ENGINE._KEY_COOLDOWN_LOCK:
            self.assertIn(key, ENGINE._KEY_COOLDOWN, "quota must still rotate away")

    def test_payload_has_no_unknown_part_fields(self):
        """'speech_metadata' is not part of the API and never shaped the voice."""
        key = self.KEY
        seen = {}

        def post(url, headers=None, json=None, timeout=None):
            seen["body"] = json
            seen["timeout"] = timeout
            return mock.Mock(status_code=404, text="not found", json=lambda: {})

        with mock.patch.object(ENGINE, "_get_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE, "_get_active_gemini_keys", return_value=[key]), \
             mock.patch.object(ENGINE._GEMINI_SESSION, "post", side_effect=post):
            ENGINE._gemini_synthesize("hello", "en")
        part = seen["body"]["contents"][0]["parts"][0]
        self.assertEqual(sorted(part.keys()), ["text"],
                         "unknown part field sent to Gemini: %s" % part)
        self.assertGreaterEqual(seen["timeout"], 20,
                                "8s timeout killed valid-but-slow renders")


if __name__ == "__main__":
    unittest.main()
