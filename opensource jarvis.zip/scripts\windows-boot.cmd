@echo off
rem JARVIS boot bring-up (called from the Windows Startup folder).
rem Brings every PM2-supervised piece back - voice engine, bridge, UI,
rem podcast, n8n and the floating HUD the owner sees on screen.
cd /d "C:\Users\PRATEEK\Desktop\jarvis-2.0"
call pm2 resurrect
