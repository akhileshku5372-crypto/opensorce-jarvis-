"""JARVIS persistent long-term memory (ChromaDB, collection `jarvis_memory`).

Split vector stores — ONE ChromaDB persistence dir (chroma_db/), TWO isolated
collections (ChromaDB collections are hard-isolated namespaces; neither engine
can read the other's vectors):

    jarvis_memory           -> this module (JARVIS long-term memory)
    kami_sensei_knowledge   -> backend/services/ingestion.py (KamiSensei RAG)

API (all functions never raise — they return safe values so the voice loop
stays alive):
    remember(text, kind)   -> store a memory, returns confirmation string
    recall(query, k)       -> top-k relevant memory strings
    all_memories(limit)    -> every memory, newest first
    forget(text)           -> delete memories containing `text`
    clear()                -> wipe the collection
    status()               -> {"available": bool, "count": int}
"""
import time
import uuid
from pathlib import Path

try:
    import storage_paths as _paths
except ImportError:  # pragma: no cover
    from background import storage_paths as _paths

# Resolved through the shared data root so this collection lives on D:
# alongside the conversation DB instead of inside the repo on C:.
CHROMA_DIR = _paths.jarvis_memory_dir()
COLLECTION = "jarvis_memory"

MAX_MEMORY_CHARS = 500

_client = None
_collection = None


def _get_collection():
    """Lazy ChromaDB client; returns the collection or None (never raises)."""
    global _client, _collection
    if _collection is not None:
        return _collection
    try:
        import chromadb
        from chromadb.config import Settings

        CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        _client = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=Settings(anonymized_telemetry=False))
        _collection = _client.get_or_create_collection(
            name=COLLECTION,
            metadata={"hnsw:space": "cosine"})
        return _collection
    except Exception:
        return None


def remember(text, kind="fact"):
    """Store one memory. Returns a short spoken confirmation string."""
    body = str(text or "").strip()[:MAX_MEMORY_CHARS]
    if not body:
        return "Kya yaad rakhna hai, Sir? Content missing tha."
    col = _get_collection()
    if col is None:
        return "Sir, memory store unavailable hai (chromadb missing)."
    try:
        col.add(
            ids=[uuid.uuid4().hex],
            documents=[body],
            metadatas=[{"kind": str(kind or "fact")[:40],
                        "created_at": time.strftime("%Y-%m-%d %H:%M")}])
        return "Yaad rakh liya, Sir: %s" % body[:80]
    except Exception as exc:
        return "Sir, memory save nahi hui (%s)." % type(exc).__name__


def recall(query, k=5):
    """Top-k semantically relevant memories (empty list on any failure)."""
    body = str(query or "").strip()
    if not body:
        return []
    col = _get_collection()
    if col is None:
        return []
    try:
        if (col.count() or 0) == 0:
            return []
        res = col.query(query_texts=[body], n_results=max(1, min(int(k), 8)))
        docs = (res.get("documents") or [[]])[0]
        return [str(d) for d in docs if d]
    except Exception:
        return []


def all_memories(limit=200):
    """Every stored memory, newest first: [{text, kind, created_at}]."""
    col = _get_collection()
    if col is None:
        return []
    try:
        rows = col.get(include=["documents", "metadatas"]) or {}
        out = []
        for i, doc in enumerate(rows.get("documents") or []):
            meta = (rows.get("metadatas") or [{}] * len(rows.get("documents") or []))[i] or {}
            out.append({
                "id": (rows.get("ids") or [""] * len(rows.get("documents") or []))[i],
                "text": str(doc or ""),
                "kind": str(meta.get("kind", "fact")),
                "created_at": str(meta.get("created_at", "")),
            })
        return out[-int(limit):][::-1]
    except Exception:
        return []


def forget(text):
    """Delete every memory containing `text`. Returns a confirmation string."""
    body = str(text or "").strip().lower()
    col = _get_collection()
    if col is None:
        return "Sir, memory store unavailable hai."
    if not body:
        return "Kya bhulana hai, Sir? Boliye kiski memory delete karni hai."
    try:
        rows = col.get(include=["documents"]) or {}
        ids = [mid for mid, doc in zip(rows.get("ids") or [],
                                       rows.get("documents") or [])
               if body in str(doc or "").lower()]
        if not ids:
            return "Sir, '%s' jaisi koi memory nahi mili." % body[:60]
        col.delete(ids=ids)
        return "Bhula diya, Sir — %d memory delete ho gayi." % len(ids)
    except Exception as exc:
        return "Sir, memory delete nahi hui (%s)." % type(exc).__name__


def clear():
    """Wipe the whole JARVIS memory collection."""
    global _collection
    col = _get_collection()
    if col is None:
        return "Sir, memory store unavailable hai."
    try:
        col.delete(where={"kind": {"$ne": "__never__"}})
        return "Poori memory clear kar di, Sir."
    except Exception:
        try:
            _client.delete_collection(COLLECTION)
            _collection = None
            _get_collection()
            return "Poori memory clear kar di, Sir."
        except Exception as exc:
            return "Sir, memory clear nahi hui (%s)." % type(exc).__name__


def status():
    """Health for the dashboard Memory Core panel."""
    col = _get_collection()
    available = col is not None
    count = 0
    if available:
        try:
            count = int(col.count() or 0)
        except Exception:
            count = 0
    return {"available": available, "count": count,
            "collection": COLLECTION, "dir": str(CHROMA_DIR)}
