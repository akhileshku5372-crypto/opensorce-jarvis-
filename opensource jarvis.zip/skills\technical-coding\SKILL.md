---
name: technical-coding
description: Hard technical skill track - writing readable code, reviewing, testing, debugging and shipping safely.
triggers: code review, refactor, testing, debugging, technical debt, refactoring, unit test, code quality, best practice
---

# Technical Coding Track

The hard-skill counterpart to the communication syllabus: how to write, change and
ship code that the next person (including you in six months) can still reason
about. Each track is a checklist you can be held to, not advice.

## Track 1: Readable Code & Naming
- **Names carry intent**: `retryWithBackoff` beats `doIt2`. No abbreviations that
  are not already common in the language (`id`, `url`, `ctx`).
- **Functions do one thing**: if the summary needs the word "and", split it.
- **Match the surrounding code**: consistency beats personal preference inside a
  codebase; propose a change as a separate commit when style genuinely diverges.
- **Comments explain why, never what**: the code already says what. A comment
  earns its place by recording a constraint, a trade-off or a bug that must not
  regress.

## Track 2: Testing & Verification
- **Test behaviour, not implementation**: assert on outputs a user could observe.
- **Cover the edges, not just the happy path**: empty input, wrong types, the
  boundary value, and the failure of every external call.
- **A test that cannot fail is a comment**: after writing it, break the code on
  purpose and watch it go red.
- **Reproduce before fixing**: a bug fix without a failing reproduction is a
  guess. Write the reproduction first.
- **Fast suite, honest suite**: a flaky test is worse than a missing one - it
  trains people to ignore red.

## Track 3: Debugging Discipline
- **Read the real error**, including the full traceback and the surrounding logs,
  before forming a theory.
- **Bisect**: narrow the space - binary search over commits, inputs or layers.
  Guessing is slower and feels better, which is exactly the trap.
- **Form one hypothesis, test it cheaply**: if the prediction is wrong, the
  hypothesis was wrong, not the test.
- **Change one thing at a time**: bundled changes hide which fix actually worked.
- **Remove debug leftovers before you finish**: stray prints and commented-out
  blocks are future confusion.

## Track 4: Safe Refactoring & Shipping
- **Refactor under green tests**: no behaviour change while the suite is red.
- **Small, reviewable commits**: one intent per commit; a 2000-line "misc"
  change is unreviewable and therefore unreviewed.
- **Never mix a refactor with a behaviour change**: reviewers cannot separate
  them, so both get weaker scrutiny.
- **Destructive and outward-facing actions need explicit approval**: deleting
  data, sending messages, publishing. A green build is not consent.
- **Write down what you did not verify**: the honest handoff beats a confident
  summary that hides the untested path.