import os, json, time, requests
for line in open(".env", encoding="utf-8"):
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())
nh = {"Authorization": "Bearer " + os.environ.get("NVIDIA_API_KEY", ""),
      "Accept": "application/json"}
out = {}
for m in ("deepseek-ai/deepseek-v4.1-flash", "moonshotai/kimi-k3",
          "nvidia/nemotron-3-super-120b-a12b", "google/gemma-4-31b-it",
          "google/gemma-3-12b-it"):
    t0 = time.time()
    try:
        r = requests.post("https://integrate.api.nvidia.com/v1/chat/completions",
                          headers=nh, timeout=25,
                          json={"model": m, "max_tokens": 30,
                                "messages": [{"role": "user", "content": "say OK"}]})
        out[m] = {"status": r.status_code, "secs": round(time.time() - t0, 1),
                  "body": r.text[:130].replace("\n", " ")}
    except Exception as e:
        out[m] = {"error": str(e)[:100]}
print(json.dumps(out, indent=1))
