"""WhatsApp deep-link sender (works without Playwright/Selenium).

Registers ONE confirm-gated cortex tool:

    whatsapp_send(recipient_data, message)

It opens the user's default browser on a real WhatsApp deep link, so the chat
opens with the message pre-filled. WhatsApp itself sends the message when the
user presses Send - this module is honest about that and never claims a send
that did not happen.

Deep link notes: the working, official deep-link host is wa.me
(https://wa.me/<country-code+number>?text=<urlencoded>). "https://whatsapp.com
<phone>&text=" is not a route WhatsApp serves, so it would silently fail; the
shape is validated here instead of shipping a broken URL.

Safety (AGENTS.md):
  * 2026-10-19 owner order: the phone-number path is GONE. A recipient is a
    NAME the owner speaks; the desktop app searches that chat by its own
    search and verifies the opened chat header. Any number spoken as a
    recipient is refused politely - no wa.me chat targeting, no local
    name->number contact book, no saved-number fallback;
  * the message text is urlencoded, never interpolated into a shell/argv;
  * a name can never smuggle a URL, path, or extra query parameter in;
  * the tool is confirm-gated in the registry (outward communication).
"""
from __future__ import annotations

import importlib.util
import os
import re
import sys
import threading
import time
import webbrowser
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent.parent

# The DESKTOP app is opened through WhatsApp's own registered URI scheme.
# Windows maps whatsapp:// to the installed WhatsApp client (Store or desktop
# installer) via ShellExecute, so no shell, no argv, no path is involved.
DESKTOP_SCHEME = "whatsapp://send"
# Fallback only: when no desktop client is installed we use the web client and
# SAY SO in the reply (honesty - never claim the app opened when it did not).
NAME_LINK_BASE = "https://web.whatsapp.com/send"
MAX_MESSAGE_CHARS = 1200
MIN_DIGITS = 8
MAX_DIGITS = 15
APP_VERIFY_TIMEOUT_S = 3.0

_DIGITS_RE = re.compile(r"\d+")


def looks_like_phone(value: str) -> bool:
    """True when the value is plausibly a phone number (not a contact name)."""
    text = str(value or "").strip()
    if not text:
        return False
    letters = len(re.findall(r"[^\W\d_]", text, re.UNICODE))
    digits = "".join(_DIGITS_RE.findall(text))
    return letters <= 2 and MIN_DIGITS <= len(digits) <= MAX_DIGITS


def build_name_link(message: str) -> tuple:
    """Web deep link for a NAME-only recipient (fallback when no app)."""
    text = _bound(message)
    if not text:
        return ("", "message khaali hai.")
    return (NAME_LINK_BASE + "?text=" + quote(text, safe=""), "")


def build_app_link(message: str) -> tuple:
    """whatsapp:// deep link -> opens the INSTALLED DESKTOP app.

    NAME only now (owner order): the app opens with the text ready and the
    route searches the chat by name - no phone parameter exists any more.
    """
    text = _bound(message)
    if not text:
        return ("", "message khaali hai.")
    return (DESKTOP_SCHEME + "?text=" + quote(text, safe=""), "")


def _bound(message) -> str:
    text = str(message or "").strip()
    return text[:MAX_MESSAGE_CHARS]


def _app_index():
    """Lazy handle on background/app_index.py (installed-app discovery)."""
    for name in ("app_index", "background.app_index"):
        try:
            return __import__(name, fromlist=["*"])
        except Exception:
            continue
    alias = "jarvis_app_index_for_wa"
    existing = sys.modules.get(alias)
    if existing is not None:
        return existing
    try:
        spec = importlib.util.spec_from_file_location(
            alias, ROOT / "background" / "app_index.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[alias] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


_INSTALL_TTL_S = 600.0
_install_cache = {"at": 0.0, "installed": False, "evidence": "",
                  "ready": False, "warming": False}
_install_lock = threading.Lock()


def _detect_install() -> tuple:
    """Real check: a live whatsapp:// handler OR an indexed WhatsApp app row."""
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,
                                r"whatsapp\shell\open\command"):
                return (True, "protocol handler")
        except OSError:
            pass
    index = _app_index()
    if index is not None:
        try:
            rows = index.search("whatsapp", limit=4)
        except Exception:
            rows = []
        for row in rows or []:
            if "whatsapp" in str(row.get("name") or "").casefold():
                return (True, "installed app: %s (%s)" % (row.get("name"),
                                                         row.get("source")))
    return (False, "")


def _warm_install_check() -> None:
    """Refresh the install answer on a background thread (never in a poll)."""
    with _install_lock:
        if _install_cache["warming"]:
            return
        _install_cache["warming"] = True

    def _worker():
        try:
            installed, evidence = _detect_install()
        except Exception as exc:
            installed, evidence = False, "check fail: %s" % type(exc).__name__
        with _install_lock:
            _install_cache.update({"at": time.monotonic(),
                                   "installed": bool(installed),
                                   "evidence": str(evidence)[:120],
                                   "ready": True, "warming": False})

    threading.Thread(target=_worker, name="jarvis-wa-install", daemon=True).start()


def desktop_app_installed(force: bool = False) -> tuple:
    """(installed, evidence) - cached for 10 min; `force` blocks (voice path)."""
    if force:
        installed, evidence = _detect_install()
        with _install_lock:
            _install_cache.update({"at": time.monotonic(),
                                   "installed": bool(installed),
                                   "evidence": str(evidence)[:120],
                                   "ready": True, "warming": False})
        return (bool(installed), str(evidence)[:120])
    with _install_lock:
        fresh = (_install_cache["ready"] and
                 time.monotonic() - _install_cache["at"] < _INSTALL_TTL_S)
        cached = (_install_cache["installed"], _install_cache["evidence"])
    if fresh:
        return cached
    _warm_install_check()
    if cached[0]:
        return cached                     # serve the old truth while refreshing
    return (False, "install check chal raha hai (pehli baar ~2 second)")


def _open_desktop(url: str) -> bool:
    """ShellExecute the whatsapp:// URI (no shell, no argv, no path)."""
    if not hasattr(os, "startfile"):
        return False
    try:
        os.startfile(url)
    except Exception:
        return False
    return True


def _open_browser(url: str):
    return webbrowser.open(url, new=2)


def _window_is_whatsapp(timeout_s: float = APP_VERIFY_TIMEOUT_S) -> bool:
    """Honest check: did a real WhatsApp window actually come to the front?"""
    if sys.platform != "win32":
        return True
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            import ctypes
            user32 = ctypes.windll.user32
            handle = user32.GetForegroundWindow()
            length = int(user32.GetWindowTextLengthW(handle))
            buffer = ctypes.create_unicode_buffer(length + 2)
            user32.GetWindowTextW(handle, buffer, length + 2)
            if "whatsapp" in str(buffer.value or "").casefold():
                return True
        except Exception:
            return False
        time.sleep(0.25)
    return False


def _recipient_target(recipient_data) -> tuple:
    """(number, display, mode) - NAME only, numbers refused by owner order.

    `mode` exists so callers can answer a number with one honest line instead
    of guessing: "phone" always carries an EMPTY number now - there is no
    deep-link chat targeting and no local number book to look up, so a spoken
    number can never silently become the send target.
    """
    if looks_like_phone(recipient_data):
        return ("", str(recipient_data)[:40], "phone")
    return ("", str(recipient_data)[:40], "name")


def send_to(recipient_data, message) -> tuple:
    """DESKTOP app first (whatsapp://), web only as an honest fallback.

    The reply always states which one actually happened - JARVIS never claims
    the app opened when it did not, and never claims a message was sent (the
    Send button stays with Sir).
    """
    text = _bound(message)
    if not text:
        return (False, "Sir, message khaali hai - kya bhejna hai bataiye.")
    _number, label, mode = _recipient_target(recipient_data)
    if mode == "phone":
        return (False, "Sir, number se WhatsApp access main ab use nahi karta "
                       "(aapne mana kiya tha) - saaf naam boliye, main app me "
                       "usi chat ko dhoondh kar message ready kar dunga. Kuch "
                       "nahi bheja gaya.")
    if not str(label).strip():
        return (False, "Sir, naam clear nahi hua - kisko bhejna hai bataiye. "
                       "Kuch nahi bheja gaya.")
    installed, evidence = desktop_app_installed()
    if installed:
        app_url, error = build_app_link(text)
        if not error and _open_desktop(app_url):
            if _window_is_whatsapp():
                return (True, "Sir, WhatsApp APP me %s ke liye message ready hai. "
                              "Send daba dein." % label)
            return (True, "Sir, WhatsApp app kholne ka request bhej diya hai (%s). "
                          "Agar app ki window na aaye to boliye - main browser me "
                          "khol dunga." % (evidence or "registered scheme"))
    url, error = build_name_link(text)
    if error:
        return (False, error)
    try:
        opened = _open_browser(url)
    except Exception as exc:
        return (False, "browser open nahi ho paya: %s: %s" % (type(exc).__name__, exc))
    if opened is False:
        return (False, "Sir, WhatsApp app is laptop par nahi mila aur default "
                       "browser bhi nahi khul raha. App install karke ya browser "
                       "set karke dobara boliye.")
    return (True, "Sir, WhatsApp app is laptop par installed nahi mila, isliye WEB "
                  "me khol diya - %s ke liye message ready hai. Chat chun kar Send "
                  "daba dein. (App install ho gaya to agli baar seedha APP me "
                  "khulega.)" % label)


def _load_cortex():
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def tool_send(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        recipient = cortex.read_str_param(args, "recipient_data", max_chars=60)
        message = cortex.read_str_param(args, "message", max_chars=MAX_MESSAGE_CHARS)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if not _bound(message):
        return cortex.fail_result("Sir, message khaali hai - kya bhejna hai bataiye.")
    _number, label, mode = _recipient_target(recipient)
    if mode == "phone":
        return cortex.fail_result(
            "Sir, number se WhatsApp access main ab use nahi karta (aapne mana "
            "kiya tha) - saaf naam boliye, main app me usi chat dhoondh lunga.")
    installed, evidence = desktop_app_installed()
    app_url = build_app_link(message)[0] if installed else ""
    web_url = build_name_link(message)[0]
    ok, said = send_to(recipient, message)
    if not ok:
        return cortex.fail_result(said)
    return cortex.ok_result(said, channel="app" if app_url else "web",
                            app_url=app_url, web_url=web_url, mode=mode,
                            app_evidence=evidence, recipient=label)


def _pyautogui():
    try:
        import pyautogui
        return pyautogui
    except Exception:
        return None


def can_autosend(force: bool = False) -> tuple:
    """(ok, why) - a REAL send needs the desktop app + a typing backend."""
    if _pyautogui() is None:
        return (False, "typing backend (pyautogui) nahi mila")
    installed, evidence = desktop_app_installed(force=force)
    if not installed:
        if "chal raha hai" in str(evidence):
            return (False, "install check chal raha hai (1-2 second), phir pata "
                           "chalega ki app hai ya nahi")
        return (False, "WhatsApp desktop app is laptop par installed nahi hai")
    return (True, evidence or "installed")


def _log(message):
    """One-line trace to stderr (PM2 log) so a silent send is debuggable."""
    try:
        print("[WHATSAPP] %s" % message, flush=True)
    except Exception:
        pass


def _load_desktop():
    """The verified WhatsApp desktop driver, loaded the same way as cortex."""
    name = "jarvis_whatsapp_desktop"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "whatsapp_desktop.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def autosend_to(recipient_data, message) -> tuple:
    """Send through the desktop app, and only claim what was actually verified.

    NAME only now (owner order 2026-10-19): every send goes through
    whatsapp_desktop, which searches, picks the best-scoring row, and REFUSES
    unless the opened chat's header matches the requested name. A spoken number
    is refused in the open - no deep link, no saved-number fallback, nothing.

    What was removed: the old name path guessed that Ctrl+F focuses the in-app
    search, pasted the name into whatever had focus, pressed Enter, and returned
    success because nothing raised. A failed search therefore pasted the name (and
    then the message) into whichever chat happened to be open - a message to the
    wrong person, reported as a success.
    """
    ready, why = can_autosend(force=True)
    if not ready:
        return (False, "Sir, message khud bhejna possible nahi: %s. App install "
                       "kar lijiye (Microsoft Store ya whatsapp.com), phir main "
                       "poora message khud type karke bhej dunga. Abhi kuch nahi "
                       "bheja gaya." % why)
    text = _bound(message)
    if not text:
        return (False, "Sir, message khaali hai - kya bhejna hai bataiye.")
    number, label, mode = _recipient_target(recipient_data)

    # 2026-10-19 owner order: NO phone deep-link path. A spoken number politely
    # refuses; the desktop app's own name search is the only way anything goes
    # out. (Old behaviour that is gone: "open 919812345678", and the saved-number
    # fallback that could retarget a send at a number the owner never named.)
    if mode == "phone":
        return (False, "Sir, number se WhatsApp access main ab use nahi karta "
                       "(aapne mana kiya tha) - saaf naam boliye, main app me "
                       "usi chat dhoondh kar poora message khud type karke bhej "
                       "dunga. Kuch nahi bheja gaya.")

    name = str(label).strip()
    if not name or len(name) > 40:
        return (False, "Sir, naam clear nahi hua - kisko bhejna hai bataiye. Kuch "
                       "nahi bheja gaya.")
    try:
        desktop = _load_desktop()
    except Exception as exc:
        _log("desktop driver load FAILED: %s: %s"
             % (type(exc).__name__, str(exc)[:160]))
        return (False, "Sir, desktop driver load nahi hua (%s) - kuch nahi bheja."
                % type(exc).__name__)
    try:
        ok, said = desktop.send(name, text)
    except Exception as exc:
        _log("desktop send EXC %s: %s" % (type(exc).__name__, str(exc)[:200]))
        return (False, "Sir, send fail hua (%s) - message gaya ya nahi, confirm "
                       "nahi hai." % type(exc).__name__)
    _log("desktop name-send %r (mode=%s) -> ok=%s %s"
         % (name[:30], mode, ok, str(said)[:120]))
    # A failed name search is reported as a failure. There is deliberately NO
    # "try the saved number instead" fallback: the owner asked for the name to be
    # searched in the app, and quietly retargeting a send at a stored number is the
    # exact behaviour that made this look like it was messaging the wrong person.
    return (bool(ok), str(said))


def open_chat(contact) -> tuple:
    """Open and VERIFY one WhatsApp chat by name; never types or sends.

    Returns (ok, opened_chat_name, why). This is the read-only sibling of
    autosend_to: it uses the same verified desktop driver, so a wrong or
    ambiguous name is refused instead of opening whichever row happened to be
    first.
    """
    name = str(contact or "").strip()
    if not name or len(name) > 60:
        return (False, "", "naam clear nahi hai")
    try:
        desktop = _load_desktop()
    except Exception as exc:
        _log("desktop driver load FAILED: %s: %s"
             % (type(exc).__name__, str(exc)[:160]))
        return (False, "", "desktop driver load nahi hua (%s)" % type(exc).__name__)
    try:
        ok, opened, why = desktop.open_chat(name)
    except Exception as exc:
        _log("desktop open_chat EXC %s: %s" % (type(exc).__name__, str(exc)[:200]))
        return (False, "", "chat open fail (%s)" % type(exc).__name__)
    _log("desktop open_chat %r -> ok=%s %s"
         % (name[:30], ok, str(why)[:120]))
    return (bool(ok), str(opened or ""), str(why or ""))


def last_preview(contact) -> str:
    """The chat-list preview for one chat, or '' when it is not observable."""
    try:
        desktop = _load_desktop()
        return str(desktop.last_message_preview(str(contact or "").strip()) or "")
    except Exception:
        return ""


def autosend_file(recipient_data, path) -> tuple:
    """Media (photo/video/audio/document) through the desktop app, NAME only.

    A number cannot receive a file this way: the wa.me deep link only prefills
    TEXT, so a number is refused honestly instead of silently downgrading the
    request to a text message (AGENTS.md: a requested format is never silently
    downgraded). The file itself is resolved by whatsapp_media before this is
    ever called - only a real, verified path reaches here.
    """
    ready, why = can_autosend(force=True)
    if not ready:
        return (False, "Sir, file khud bhejna possible nahi: %s. Abhi kuch nahi "
                       "bheja gaya." % why)
    _number, label, mode = _recipient_target(recipient_data)
    if mode == "phone":
        return (False, "Sir, number par file deep-link se nahi jaati - naam "
                       "boliye, main WhatsApp app me usi chat dhoondh kar file "
                       "bhej dunga. Kuch nahi bheja.")
    name = str(label).strip()
    if not name or len(name) > 40:
        return (False, "Sir, naam clear nahi hua - kisko bhejna hai bataiye. "
                       "Kuch nahi bheja gaya.")
    try:
        desktop = _load_desktop()
    except Exception as exc:
        _log("desktop driver load FAILED: %s: %s"
             % (type(exc).__name__, str(exc)[:160]))
        return (False, "Sir, desktop driver load nahi hua (%s) - kuch nahi bheja."
                % type(exc).__name__)
    try:
        ok, said = desktop.send_file(name, str(path))
    except Exception as exc:
        _log("desktop media-send EXC %s: %s" % (type(exc).__name__, str(exc)[:200]))
        return (False, "Sir, file send fail hua (%s) - gaya ya nahi, confirm "
                       "nahi hai." % type(exc).__name__)
    _log("desktop media-send %r file=%s -> ok=%s %s"
         % (name[:30], os.path.basename(str(path)), ok, str(said)[:120]))
    return (bool(ok), str(said))


def tool_autosend(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        recipient = cortex.read_str_param(args, "recipient_data", max_chars=60)
        message = cortex.read_str_param(args, "message", max_chars=MAX_MESSAGE_CHARS)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    ok, said = autosend_to(recipient, message)
    if not ok:
        return cortex.fail_result(said)
    return cortex.ok_result(said, recipient=str(recipient)[:40], sent=True)


def tool_autosend_file(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        recipient = cortex.read_str_param(args, "recipient_data", max_chars=60)
        path = cortex.read_str_param(args, "path", max_chars=260)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if not os.path.isfile(path):
        return cortex.fail_result("file hi nahi mili - kuch nahi bheja")
    ok, said = autosend_file(recipient, path)
    if not ok:
        return cortex.fail_result(said)
    return cortex.ok_result(said, recipient=str(recipient)[:40], sent=True)


def describe() -> str:
    ready, why = can_autosend()
    where = ("AUTO-SEND ready (%s) - message khud type karke bhej dega" % why) \
        if ready else ("AUTO-SEND abhi nahi: %s. Ab sirf draft/link banega." % why)
    return ("Sir, WhatsApp: %s. Naam boliye to main WhatsApp app me wahi chat "
            "dhoondh kar message khud type karke bhejta hoon - number system "
            "aapne band karaya hai, isliye naam hi kaafi hai." % where)


def specs() -> list:
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("whatsapp_send",
                        "WhatsApp DESKTOP app (whatsapp://) me chat kholo aur "
                        "message ready karo; app na ho to web fallback. Send user "
                        "dabata hai.",
                        tool_send,
                        parameters={"recipient_data": "naam (app me search hota hai)",
                                    "message": "message text"},
                        requires_confirmation=True, timeout_s=25.0),
        cortex.ToolSpec("whatsapp_autosend",
                        "WhatsApp DESKTOP app me NAAM search karke chat kholo, "
                        "message khud type karke SEND kar do (tabhi message "
                        "actually jaata hai).",
                        tool_autosend,
                        parameters={"recipient_data": "naam (app me search hota hai)",
                                    "message": "message text"},
                        requires_confirmation=True, timeout_s=45.0),
        cortex.ToolSpec("whatsapp_send_file",
                        "WhatsApp DESKTOP app me NAAM search karke chat kholo aur "
                        "ek REAL file (photo/video/audio/document) clipboard se "
                        "attach karke SEND karo. Sirf pehle se resolve kiya hua "
                        "path, sirf naam recipient.",
                        tool_autosend_file,
                        parameters={"recipient_data": "naam (app me search hota hai)",
                                    "path": "bheji jaane wali file ka poora path"},
                        requires_confirmation=True, timeout_s=60.0),
    ]
