"""Cowork OS executor: Open-Interpreter-inspired local actions, sandboxed.

NOT a shell passthrough (AGENTS.md forbids arbitrary CMD/PowerShell/shell
mode/executable/filesystem paths). The planner gets honest tools:

  * os_read_file   - read a repo-relative text file (bounded, never secrets)
  * os_list_files  - list a repo-relative directory (bounded)
  * os_search_text - literal repo search without a shell (bounded)
  * os_write_file  - write/append a repo-relative text file (confirm-gated)
  * os_run_command - ONE allowlisted repo command (confirm-gated, locked argv)

Every path resolves inside the repo ROOT; escaping, absolute paths,
dotfiles (.env/.dev.vars/.git), and secrets-looking files are refused.
"""
from __future__ import annotations

import fnmatch
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()

MAX_READ_CHARS = 6000
MAX_WRITE_CHARS = 20000
MAX_LIST_ROWS = 60
MAX_SEARCH_MATCHES = 40
MAX_SEARCH_FILES = 400

_SECRET_NAMES = {
    ".env", ".dev.vars", ".env.local", ".env.production",
    "secrets.json", "credentials.json", "id_rsa", "id_ed25519",
}
_SECRET_SUFFIXES = (".pem", ".key", ".pfx", ".p12", ".jks")


def _resolve_repo_path(raw: str) -> tuple:
    """(path, error) - repo-relative only, no escape, no secrets, no .git."""
    text = str(raw or "").strip().replace("\\", "/")
    if not text:
        return (None, "path khaali hai.")
    candidate = (ROOT / text).resolve()
    try:
        candidate.relative_to(ROOT)
    except ValueError:
        return (None, "path repo ke bahar hai - sirf repo ke andar ki files.")
    parts = set(candidate.relative_to(ROOT).parts)
    if ".git" in parts or ".venv" in parts or "__pycache__" in parts:
        return (None, "yeh folder executor ke liye band hai (.git/.venv/cache).")
    if candidate.name in _SECRET_NAMES or candidate.suffix.lower() in _SECRET_SUFFIXES:
        return (None, "secrets wali file executor se nahi khulti.")
    return (candidate, "")


def tool_read_file(args: dict) -> dict:
    try:
        path = cortex.read_str_param(args, "path", max_chars=300)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    target, error = _resolve_repo_path(path)
    if error:
        return cortex.fail_result(error)
    if not target.is_file():
        return cortex.fail_result("file nahi mili: %s" % path[:120])
    try:
        text = target.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        return cortex.fail_result("read fail: %s: %s" % (type(exc).__name__, exc))
    if len(text) > MAX_READ_CHARS:
        text = text[:MAX_READ_CHARS] + "\n... (truncated)"
    return cortex.ok_result(text, path=str(target.relative_to(ROOT)))


def tool_list_files(args: dict) -> dict:
    try:
        path = cortex.read_str_param(args, "path", required=False, default=".",
                                     max_chars=300)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    target, error = _resolve_repo_path(path or ".")
    if error:
        return cortex.fail_result(error)
    if not target.is_dir():
        return cortex.fail_result("folder nahi mila: %s" % path[:120])
    try:
        rows = sorted(p.name + ("/" if p.is_dir() else "") for p in target.iterdir())
    except Exception as exc:
        return cortex.fail_result("list fail: %s: %s" % (type(exc).__name__, exc))
    shown = rows[:MAX_LIST_ROWS]
    extra = "" if len(rows) <= MAX_LIST_ROWS else "\n... (aur %d)" % (len(rows) - MAX_LIST_ROWS)
    return cortex.ok_result("\n".join(shown) + extra, count=len(rows))

def tool_search_text(args: dict) -> dict:
    """Literal repo search without a shell, skipped paths blocked, bounded output."""
    try:
        query = cortex.read_str_param(args, "query", max_chars=160)
        path = cortex.read_str_param(args, "path", required=False, default=".",
                                     max_chars=300)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    target, error = _resolve_repo_path(path or ".")
    if error:
        return cortex.fail_result(error)
    if not target.exists():
        return cortex.fail_result("path nahi mila: %s" % path[:120])
    blocked = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache",
               "dist", "artifacts"}
    needle = query.casefold()
    rows, scanned = [], 0
    candidates = [target] if target.is_file() else sorted(target.rglob("*"))
    for candidate in candidates:
        if len(rows) >= MAX_SEARCH_MATCHES or scanned >= MAX_SEARCH_FILES:
            break
        if not candidate.is_file() or blocked & set(candidate.parts):
            continue
        try:
            if candidate.stat().st_size > 256 * 1024:
                continue
            safe, _ = _resolve_repo_path(str(candidate.relative_to(ROOT)))
            if safe is None:
                continue
            scanned += 1
            for number, line in enumerate(
                    candidate.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if needle in line.casefold():
                    rows.append("%s:%d: %s" % (
                        str(candidate.relative_to(ROOT)).replace("\\", "/"),
                        number, line.strip()[:240]))
                    if len(rows) >= MAX_SEARCH_MATCHES:
                        break
        except Exception:
            continue
    if not rows:
        return cortex.ok_result("(koi match nahi)", scanned=scanned)
    return cortex.ok_result("\n".join(rows)[:MAX_READ_CHARS], scanned=scanned,
                            matches=len(rows))


def tool_find_files(args: dict) -> dict:
    """Name/glob search inside the repo (shell-less, bounded, secrets blocked)."""
    try:
        pattern = cortex.read_str_param(args, "pattern", max_chars=80)
        path = cortex.read_str_param(args, "path", required=False, default=".",
                                     max_chars=300)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    target, error = _resolve_repo_path(path or ".")
    if error:
        return cortex.fail_result(error)
    if not target.exists():
        return cortex.fail_result("path nahi mila: %s" % path[:120])
    blocked = {".git", ".venv", "venv", "node_modules", "__pycache__",
               ".pytest_cache", "dist", "artifacts"}
    needle = pattern.casefold().strip("*? .")
    wildcard = any(ch in pattern for ch in "*?")
    rows, visited = [], 0
    candidates = [target] if target.is_file() else sorted(target.rglob("*"))
    for candidate in candidates:
        if len(rows) >= MAX_LIST_ROWS or visited >= 4000:
            break
        if not candidate.is_file() or blocked & set(candidate.parts):
            continue
        visited += 1
        name = candidate.name.casefold()
        if wildcard:
            if not fnmatch.fnmatch(name, pattern.casefold()):
                continue
        elif needle and needle not in name:
            continue
        safe, _ = _resolve_repo_path(str(candidate.relative_to(ROOT)))
        if safe is None:
            continue
        try:
            size = candidate.stat().st_size
        except OSError:
            continue
        rows.append("%s (%d B)" % (
            str(candidate.relative_to(ROOT)).replace("\\", "/"), size))
    if not rows:
        return cortex.ok_result("(koi file match nahi)", scanned=visited)
    extra = "" if len(rows) < MAX_LIST_ROWS else "\n... (bounded)"
    return cortex.ok_result("\n".join(rows) + extra, matches=len(rows),
                            scanned=visited)


def tool_write_file(args: dict) -> dict:
    try:
        path = cortex.read_str_param(args, "path", max_chars=300)
        content = cortex.read_str_param(args, "content", max_chars=MAX_WRITE_CHARS)
        mode = cortex.read_str_param(args, "mode", required=False, default="write",
                                     max_chars=10).lower()
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if mode not in ("write", "append"):
        aliases = {"w": "write", "a": "append", "w+": "write", "a+": "append"}
        mode = aliases.get(mode, "")
        if not mode:
            return cortex.fail_result("mode sirf 'write' ya 'append' ho sakta hai.")
    target, error = _resolve_repo_path(path)
    if error:
        return cortex.fail_result(error)
    if target.suffix.lower() in (".exe", ".bat", ".cmd", ".ps1", ".dll", ".msi"):
        return cortex.fail_result("executable/script file write band hai.")
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        if mode == "append" and target.is_file():
            with target.open("a", encoding="utf-8") as handle:
                handle.write(content)
        else:
            target.write_text(content, encoding="utf-8")
    except Exception as exc:
        return cortex.fail_result("write fail: %s: %s" % (type(exc).__name__, exc))
    return cortex.ok_result("likh diya: %s (%d chars, mode=%s)"
                            % (target.relative_to(ROOT), len(content), mode))


# Opening a repo file with the OS default handler spawns an app, so it is
# confirm-gated. Executable/script suffixes are refused: os.startfile on a
# .js/.vbs/.hta RUNS it, and that must never be one voice command away.
_OPEN_BLOCKED_SUFFIXES = (
    ".exe", ".com", ".bat", ".cmd", ".ps1", ".psm1", ".dll", ".msi", ".scr",
    ".pif", ".js", ".jse", ".vbs", ".vbe", ".wsf", ".wsh", ".hta", ".reg",
    ".lnk", ".url", ".cpl", ".jar", ".pyw",
)


def tool_open_file(args: dict) -> dict:
    """Open one repo file with the OS default app (no argv, no shell)."""
    try:
        path = cortex.read_str_param(args, "path", max_chars=300)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    target, error = _resolve_repo_path(path)
    if error:
        return cortex.fail_result(error)
    if not target.is_file():
        return cortex.fail_result("file nahi mili: %s" % path[:120])
    suffix = target.suffix.lower()
    if suffix in _OPEN_BLOCKED_SUFFIXES:
        return cortex.fail_result(
            "'%s' file open karna band hai (default handler ise execute kar "
            "sakta hai)." % (suffix or "no-ext"))
    if not hasattr(os, "startfile"):
        return cortex.fail_result("file open sirf Windows par available hai.")
    try:
        os.startfile(str(target))      # noqa: S606 - repo-resolved path, no argv
    except Exception as exc:
        return cortex.fail_result("open fail: %s: %s" % (type(exc).__name__, exc))
    rel = str(target.relative_to(ROOT)).replace("\\", "/")
    return cortex.ok_result("khol diya: %s" % rel, path=rel)


_ALLOWED_OPS = (
    "git_status", "git_branch", "git_diff", "git_log",
    "npm_test_bridge", "npm_test_browser", "npm_test_skills", "npm_test_core",
    "npm_build", "node_check_app", "python_tests",
)


def allowed_ops() -> list:
    return list(_ALLOWED_OPS)


def _argv_for(op: str) -> tuple:
    if op == "git_status":
        return (["git", "status", "--short"], "")
    if op == "git_branch":
        return (["git", "branch", "--show-current"], "")
    if op == "git_diff":
        return (["git", "diff", "--stat"], "")
    if op == "git_log":
        return (["git", "log", "--oneline", "-8"], "")
    if op == "npm_test_bridge":
        return (["npm", "run", "test:bridge"], "")
    if op == "npm_test_browser":
        return (["npm", "run", "test:browser"], "")
    if op == "npm_test_skills":
        return (["npm", "run", "test:skills"], "")
    if op == "npm_test_core":
        return (["npm", "run", "test:core"], "")
    if op == "npm_build":
        return (["npm", "run", "build"], "")
    if op == "node_check_app":
        return (["node", "--check", "public/static/app.js"], "")
    if op == "python_tests":
        return ([sys.executable, "-m", "unittest", "discover", "-s", "tests",
                 "-p", "test_*.py"], "")
    return (None, "command allowlist me nahi hai: %s" % op[:60])


def tool_run_command(args: dict) -> dict:
    try:
        op = cortex.read_str_param(args, "op", max_chars=40).lower()
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    argv, error = _argv_for(op)
    if error:
        return cortex.fail_result(error + " (allowed: %s)" % ", ".join(_ALLOWED_OPS))
    import subprocess
    try:
        done = subprocess.run(argv, cwd=str(ROOT), capture_output=True, text=True,
                              timeout=120, shell=False)
    except Exception as exc:
        return cortex.fail_result("command fail: %s: %s" % (type(exc).__name__, exc))
    out = ((done.stdout or "") + ("\n" + done.stderr if done.stderr else "")).strip()
    if len(out) > MAX_READ_CHARS:
        out = out[:MAX_READ_CHARS] + "\n... (truncated)"
    tail = out or "(koi output nahi, exit=%d)" % done.returncode
    return cortex.ok_result(tail, exit_code=done.returncode)


def specs() -> list:
    """ToolSpec list for the cortex registry (write/run/open confirm-gated)."""
    return [
        cortex.ToolSpec("os_read_file", "Repo ke andar text file padho (bounded).",
                        tool_read_file,
                        parameters={"path": "repo-relative file path"}),
        cortex.ToolSpec("os_list_files", "Repo ke andar folder list karo.",
                        tool_list_files,
                        parameters={"path": "repo-relative folder (default .)"}),
        cortex.ToolSpec("os_search_text",
                        "Repo ke andar literal text search karo (koi shell nahi).",
                        tool_search_text,
                        parameters={"query": "literal search text",
                                    "path": "repo-relative file/folder (default .)"}),
        cortex.ToolSpec("os_find_files",
                        "Repo ke andar naam/glob se file dhoondho (koi shell nahi).",
                        tool_find_files,
                        parameters={"pattern": "naam ya glob, jaise '*.py'",
                                    "path": "repo-relative folder (default .)"}),
        cortex.ToolSpec("os_write_file", "Repo ke andar text file likho/append karo.",
                        tool_write_file,
                        parameters={"path": "repo-relative path",
                                    "content": "likhne wala text",
                                    "mode": "write|append (default write)"},
                        requires_confirmation=True),
        cortex.ToolSpec("os_open_file",
                        "Repo file OS ke default app mein kholo (no argv).",
                        tool_open_file,
                        parameters={"path": "repo-relative file path"},
                        requires_confirmation=True),
        cortex.ToolSpec("os_run_command", "Sirf allowlisted repo command chalao.",
                        tool_run_command,
                        parameters={"op": " | ".join(_ALLOWED_OPS)},
                        requires_confirmation=True),
    ]


def describe() -> str:
    rows = specs()
    names = [s.name for s in rows]
    gated = [s.name for s in rows if s.requires_confirmation]
    return ("Sir, OS executor ready: %d tools (%s). Repo-sandboxed, koi shell "
            "nahi; confirm-gated: %s." % (len(names), ", ".join(names),
                                          ", ".join(gated)))
