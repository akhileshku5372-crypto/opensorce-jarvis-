import pathlib, re
p=pathlib.Path("public/static/brain-holo.js")
s=p.read_text(encoding="utf-8")
# Wrap buildScene in try
if "function buildScene(){ try{" not in s:
    s=s.replace("  function buildScene(){", "  function buildScene(){ try{")
    print("added try")
# Patch tail: clock=new THREE.Clock(); initialized=true; return true;
old="    clock=new THREE.Clock(); initialized=true; return true;\n  }"
new="    clock=new THREE.Clock(); initialized=true; console.log('[brain-holo] READY 4200pts 8centroids 36pulses '+W+'x'+H); return true;\n  }catch(e){ console.error('[brain-holo] buildScene FAILED', e); try{ if(container) container.innerHTML='<div style=\"display:grid;place-items:center;height:100%;color:#ff5d6c;font:12px Inter\">Hologram error: '+(e&&e.message||e)+'</div>'; }catch{} return false; }\n  }"
if old in s:
    s=s.replace(old,new)
    print("patched tail1")
else:
    # fallback find initialized line
    if "initialized=true; return true;" in s:
        s=s.replace("initialized=true; return true;", "initialized=true; console.log('[brain-holo] READY '+W+'x'+H); return true; }catch(e){ console.error('[brain-holo] buildScene FAILED',e); return false; }")
        print("fallback tail")
    else:
        print("tail miss")
p.write_text(s,encoding="utf-8")
import pathlib as pl
dp=pl.Path("dist/static/brain-holo.js")
if dp.parent.exists(): dp.write_text(s,encoding="utf-8")
print("len",len(s))
# sanity check brackets
print("open",s.count("{"),"close",s.count("}"),"parens",s.count("("),s.count(")"))
