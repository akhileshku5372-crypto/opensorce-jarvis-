"""Video Auto-Editor AI: real silence cutting, captions and scene labels.

Backs the "Video Auto-Editor AI" card using only what is actually installed:

  * silence cut  - ffmpeg `silencedetect` finds REAL silent spans from the
                   audio, and a keep-segments filter map renders a new file
                   with those spans removed. ffmpeg is present on this
                   machine, so this is genuinely working.
  * captions     - the local faster-whisper model that JARVIS already ships
                   for STT transcribes the audio, and timed segments are
                   written to a .srt next to the output.
  * scene labels - the EXISTING perception plugin (YOLOv10n ONNX) labels
                   sampled frames. It is imported, never reimplemented, so
                   there is still exactly one perception model in the repo.

Every stage degrades honestly: a missing ffmpeg or whisper model makes that
ONE stage report unavailable, and the tool says so rather than returning an
invented edit. Nothing is uploaded anywhere.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "artifacts" / "video"
MAX_SILENCE_SPAN = 30.0        # never merge/keep a silence longer than this
MIN_SILENCE_S = float(os.environ.get("JARVIS_SILENCE_MIN_S", "0.6"))
_SILENCE_START = re.compile(r"silence_start:\s*(-?[\d.]+)")
_SILENCE_END = re.compile(r"silence_end:\s*(-?[\d.]+)")


def ffmpeg_path() -> str:
    override = os.environ.get("JARVIS_FFMPEG_PATH")
    if override and Path(override).exists():
        return override
    return shutil.which("ffmpeg") or ""


def capabilities() -> dict:
    ffmpeg = ffmpeg_path()
    whisper = True
    try:
        from faster_whisper import WhisperModel  # noqa: F401
    except Exception:
        whisper = False
    return {
        "ok": True, "source": "local",
        "silence_cut": {"available": bool(ffmpeg), "engine": "ffmpeg" if ffmpeg else "",
                        "path": ffmpeg,
                        "reason": "" if ffmpeg else
                        "ffmpeg is not on PATH (winget install ffmpeg)"},
        "captions": {"available": whisper, "engine": "faster-whisper" if whisper else "",
                     "reason": "" if whisper else "faster-whisper is not installed"},
        "scene_labels": {"available": _perception_available(),
                         "engine": "YOLOv10n (perception plugin)" if
                         _perception_available() else "",
                         "reason": "" if _perception_available() else
                         "perception plugin is not importable"},
    }


def _perception_available() -> bool:
    try:
        return _perception().get("ok", False)
    except Exception:
        return False


def _perception():
    """Import the EXISTING perception plugin. Never a second model."""
    import importlib.util
    import sys
    key = "jarvis_plugin_perception"
    mod = sys.modules.get(key)
    if mod is None:
        path = ROOT / "extensions" / "plugins" / "perception" / "plugin.py"
        if not path.is_file():
            return {"ok": False, "error": "perception plugin not found"}
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
    status = mod.model_status()
    objs = (status.get("objects") or {})
    return {"ok": bool(objs.get("present")), "module": mod, "models": status}


def _probe(path: Path) -> dict:
    """Real duration/size/fps straight from ffprobe."""
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        return {"ok": False, "error": "ffprobe is not on PATH"}
    import json
    try:
        done = subprocess.run(
            [ffprobe, "-v", "error", "-print_format", "json",
             "-show_format", "-show_streams", str(path)],
            capture_output=True, text=True, timeout=60, shell=False,
            creationflags=0x08000000 if os.name == "nt" else 0)
        data = json.loads(done.stdout or "{}")
    except Exception as exc:
        return {"ok": False, "error": "ffprobe failed: %s" % type(exc).__name__}
    fmt = data.get("format") or {}
    video = next((s for s in data.get("streams") or []
                  if s.get("codec_type") == "video"), {})
    audio = next((s for s in data.get("streams") or []
                  if s.get("codec_type") == "audio"), None)
    return {"ok": True, "duration_s": float(fmt.get("duration") or 0),
            "size_bytes": int(fmt.get("size") or (path.stat().st_size if path.exists() else 0)),
            "width": video.get("width"), "height": video.get("height"),
            "fps": video.get("r_frame_rate"),
            "has_audio": audio is not None}


def find_silence(src: Path, min_s: float = MIN_SILENCE_S) -> dict:
    """REAL silent spans from ffmpeg silencedetect on the source audio."""
    ffmpeg = ffmpeg_path()
    if not ffmpeg:
        return {"ok": False, "error": "ffmpeg is not on PATH", "spans": []}
    try:
        done = subprocess.run(
            [ffmpeg, "-hide_banner", "-nostats", "-i", str(src),
             "-af", "silencedetect=noise=-32dB:d=%.2f" % float(min_s),
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=900, shell=False,
            creationflags=0x08000000 if os.name == "nt" else 0)
    except Exception as exc:
        return {"ok": False, "error": "silencedetect failed: %s" % type(exc).__name__,
                "spans": []}
    log = (done.stderr or "") + (done.stdout or "")
    starts = [float(m) for m in _SILENCE_START.findall(log)]
    ends = [float(m) for m in _SILENCE_END.findall(log)]
    spans = []
    for start in starts:
        # A trailing silence has no explicit end; treat it as open-ended.
        end = next((e for e in ends if e >= start), None)
        spans.append({"start": round(max(0.0, start), 3),
                      "end": round(end, 3) if end is not None else None})
    return {"ok": True, "spans": spans, "count": len(spans),
            "min_silence_s": float(min_s)}


def _keep_segments(duration: float, spans: list, min_keep: float = 0.4) -> list:
    """Complement of the silent spans, as keep ranges."""
    ranges, cursor = [], 0.0
    for span in spans:
        start = max(0.0, float(span.get("start") or 0.0))
        end = span.get("end")
        end = float(duration) if end is None else min(float(end), duration)
        if end <= start:
            continue
        if start - cursor >= min_keep:
            ranges.append((round(cursor, 3), round(start, 3)))
        cursor = max(cursor, end)
    if duration - cursor >= min_keep:
        ranges.append((round(cursor, 3), round(duration)))
    return ranges


def cut_silence(src, min_s: float = MIN_SILENCE_S,
                threshold_db: float = -32.0) -> dict:
    """Render a new file with real silence removed. Writes into artifacts/."""
    source = Path(str(src or "")).expanduser()
    caps = capabilities()
    if not caps["silence_cut"]["available"]:
        return {"ok": False, "error": caps["silence_cut"]["reason"]}
    if not source.is_file():
        return {"ok": False, "error": "video not found: %s" % source.name[:80]}
    info = _probe(source)
    if not info.get("ok"):
        return {"ok": False, "error": info.get("error", "could not probe the video")}
    if not info.get("has_audio"):
        return {"ok": False, "error": "this video has no audio track, "
                                     "so there is no silence to cut"}
    found = find_silence(source, min_s)
    if not found.get("ok"):
        return {"ok": False, "error": found.get("error", "silence detection failed")}
    keep = _keep_segments(info["duration_s"], found["spans"])
    if not keep:
        return {"ok": True, "source": "local", "edited": False, "output": None,
                "silence_spans": found["count"],
                "reason": "the whole track is silence at this threshold"}
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    dest = OUT_DIR / ("%s-cut.mp4" % source.stem[:48])
    expr = "+".join("between(t,%s,%s)" % (a, b) for a, b in keep)
    try:
        done = subprocess.run(
            [ffmpeg_path(), "-y", "-hide_banner", "-loglevel", "error",
             "-i", str(source),
             # Both timelines must be recompressed, otherwise ffmpeg pads the
             # output back to the original length and the cut becomes a no-op.
             "-filter:v", "select='%s',setpts=N/FRAME_RATE/TB" % expr,
             "-filter:a", "aselect='%s',asetpts=N/SR/TB" % expr,
             str(dest)],
            capture_output=True, text=True, timeout=3600, shell=False,
            creationflags=0x08000000 if os.name == "nt" else 0)
    except Exception as exc:
        return {"ok": False, "error": "ffmpeg render failed: %s" % type(exc).__name__}
    if not dest.is_file() or dest.stat().st_size == 0:
        return {"ok": False, "error": "ffmpeg produced no output: %s"
                                         % (done.stderr or "").strip()[-200:]}
    after = _probe(dest)
    return {"ok": True, "source": "local", "edited": True, "output": str(dest),
            "silence_spans": found["count"], "min_silence_s": float(min_s),
            "threshold_db": float(threshold_db), "keep_segments": keep,
            "duration_before_s": round(info["duration_s"], 2),
            "duration_after_s": after.get("duration_s"),
            "saved_s": round(info["duration_s"] - (after.get("duration_s") or 0), 2),
            "size_before": info["size_bytes"], "size_after": after.get("size_bytes")}


def _srt_timestamp(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    hours, rest = divmod(int(seconds), 3600)
    minutes, secs = divmod(rest, 60)
    millis = int(round((seconds - int(seconds)) * 1000))
    return "%02d:%02d:%02d,%03d" % (hours, minutes, secs, millis)


def write_srt(segments: list, dest: Path) -> dict:
    lines = []
    for index, seg in enumerate(segments, start=1):
        text = str(seg.get("text") or "").strip()
        if not text:
            continue
        lines.append("%d\n%s --> %s\n%s\n"
                     % (len(lines) // 4 + 1,
                        _srt_timestamp(seg.get("start") or 0),
                        _srt_timestamp(seg.get("end") or 0), text))
    try:
        dest.write_text("\n".join(lines), encoding="utf-8")
    except Exception as exc:
        return {"ok": False, "error": "could not write SRT: %s" % type(exc).__name__}
    return {"ok": True, "path": str(dest), "cues": len(lines) // 4}


def transcribe(src, model_size: str = "base") -> dict:
    """Real local STT with the faster-whisper model JARVIS already ships."""
    try:
        from faster_whisper import WhisperModel  # type: ignore
    except Exception:
        return {"ok": False, "error": "faster-whisper is not installed",
                "segments": []}
    source = Path(str(src or "")).expanduser()
    if not source.is_file():
        return {"ok": False, "error": "media not found", "segments": []}
    try:
        model = WhisperModel(os.environ.get("JARVIS_WHISPER_MODEL", model_size),
                             device=os.environ.get("JARVIS_WHISPER_DEVICE", "cpu"),
                             compute_type=os.environ.get("JARVIS_WHISPER_COMPUTE", "int8"))
        segments, _ = model.transcribe(str(source), vad_filter=True)
        rows = [{"start": round(float(s.start), 2), "end": round(float(s.end), 2),
                 "text": (s.text or "").strip()} for s in segments]
    except Exception as exc:
        return {"ok": False, "error": "transcription failed: %s: %s"
                                     % (type(exc).__name__, exc), "segments": []}
    return {"ok": True, "source": "local", "engine": "faster-whisper",
            "model": model_size, "segments": rows, "count": len(rows),
            "chars": sum(len(r["text"]) for r in rows)}


def caption(src, model_size: str = "base") -> dict:
    """Transcribe a real file and write a real .srt next to the output."""
    result = transcribe(src, model_size)
    if not result.get("ok"):
        return {"ok": False, "error": result.get("error", "transcription failed")}
    if not result["segments"]:
        return {"ok": True, "source": "local", "cues": 0, "segments": [],
                "reason": "no speech was detected in this file"}
    source = Path(str(src)).expanduser()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    return write_srt(result["segments"],
                     OUT_DIR / ("%s.srt" % source.stem[:48]))


def scene_labels(src, sample_every: float = 5.0) -> dict:
    """Label sampled video frames with the EXISTING perception model."""
    perc = _perception()
    if not perc.get("ok"):
        return {"ok": False, "error": perc.get("error", "perception unavailable"),
                "scenes": []}
    source = Path(str(src or "")).expanduser()
    if not source.is_file():
        return {"ok": False, "error": "video not found", "scenes": []}
    try:
        import cv2  # type: ignore
    except Exception:
        return {"ok": False, "error": "OpenCV is not installed", "scenes": []}
    module = perc["module"]
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        cap.release()
        return {"ok": False, "error": "could not open the video", "scenes": []}
    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    step = max(1, int(round(fps * max(1.0, float(sample_every)))))
    scenes, index, sampled = [], 0, 0
    try:
        while sampled <= 12:
            ok, frame = cap.read()
            if not ok or frame is None:
                break
            if sampled % step == 0:
                try:
                    det = module.detect_objects(frame)
                except Exception:
                    det = {}
                dets = det.get("detections") or []
                scenes.append({
                    "at_s": round(index / fps, 2) if fps else None,
                    "labels": [d.get("label") for d in dets if d.get("label")],
                    "counts": det.get("counts", {}),
                    "confidence_max": max([d.get("confidence", 0) for d in dets] or [0])})
                sampled += 1
            index += 1
    finally:
        cap.release()
    return {"ok": True, "source": "local", "engine": "YOLOv10n via perception plugin",
            "fps": round(fps, 2), "frames_sampled": len(scenes),
            "sample_every_s": float(sample_every), "scenes": scenes}


def _tool_video_status(args: dict) -> dict:
    caps = capabilities()
    live = [k for k in ("silence_cut", "captions", "scene_labels")
            if caps[k]["available"]]
    return {"ok": True,
            "output": ("Sir, video editor can: %s." % ", ".join(live)
                       if live else "Sir, no video stage is available yet."),
            "data": caps}


def _tool_cut_silence(args: dict) -> dict:
    out = cut_silence((args or {}).get("path", ""),
                      min_s=float((args or {}).get("min_silence_s")
                                  or MIN_SILENCE_S))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "silence cut failed")}
    if not out.get("edited"):
        return {"ok": True,
                "output": "Sir, %s" % out.get("reason", "nothing to cut"),
                "data": out}
    return {"ok": True,
            "output": ("Sir, removed %d silent span(s) and saved %.1f seconds. "
                       "Output: %s" % (out["silence_spans"], out["saved_s"],
                                        out["output"])),
            "data": out}


def _tool_caption(args: dict) -> dict:
    out = caption((args or {}).get("path", ""),
                  model_size=str((args or {}).get("model") or "base"))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "captioning failed")}
    if not out.get("cues"):
        return {"ok": True,
                "output": "Sir, %s" % out.get("reason", "no speech found"),
                "data": out}
    return {"ok": True, "output": "Sir, wrote %d caption cue(s) to %s"
                                 % (out["cues"], out["path"]), "data": out}


def _tool_scene_labels(args: dict) -> dict:
    out = scene_labels((args or {}).get("path", ""))
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error", "scene labelling failed")}
    if not out.get("scenes"):
        return {"ok": True, "output": "Sir, no scenes could be sampled.",
                "data": out}
    first = out["scenes"][0]
    return {"ok": True,
            "output": "Sir, labelled %d sampled scene(s). First: %s."
                      % (out["frames_sampled"],
                         ", ".join(first["labels"]) or "no objects"),
            "data": out}


def specs() -> list:
    """cortex ToolSpec list. Rendering writes a new file, so it is gated."""
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("video_editor_status",
                        "Which video stages (silence cut, captions, scene labels) are real.",
                        _tool_video_status, parameters={},
                        requires_confirmation=False, timeout_s=30.0,
                        tags=("video", "media")),
        cortex.ToolSpec("video_cut_silence",
                        "Detect and remove real silence from a local video.",
                        _tool_cut_silence,
                        parameters={"path": "video file path",
                                    "min_silence_s": "minimum silence length (s)"},
                        requires_confirmation=True, timeout_s=1200.0,
                        tags=("video", "media")),
        cortex.ToolSpec("video_caption",
                        "Transcribe a local video/audio with local Whisper to .srt.",
                        _tool_caption,
                        parameters={"path": "media file path", "model": "tiny|base"},
                        requires_confirmation=True, timeout_s=1200.0,
                        tags=("video", "media", "ocr")),
        cortex.ToolSpec("video_scene_labels",
                        "Label sampled video frames with the local perception model.",
                        _tool_scene_labels, parameters={"path": "video file path"},
                        requires_confirmation=False, timeout_s=300.0,
                        tags=("video", "media", "perception")),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()




