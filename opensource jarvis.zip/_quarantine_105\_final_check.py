# -*- coding: utf-8 -*-
"""_final_check.py — reads .env/.dev.vars (names + hash prefixes ONLY, no secrets),
checks pip deps, probes network, and validates every configured model slug."""
import hashlib, os, subprocess, sys, urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))

def env_map(name):
    p = os.path.join(ROOT, name)
    if not os.path.exists(p):
        return None
    out = {}
    for line in open(p, encoding='utf-8'):
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        out[k.strip()] = v.strip()
    return out

def sha12(s):
    if not s:
        return 'none'
    return hashlib.sha256(s.encode()).hexdigest()[:12]

def http_probe(url, key_name=None, key=None, timeout=12):
    req = urllib.request.Request(url, headers={'User-Agent': 'Jarvis-memory-probe/1.0'})
    if key_name and key:
        req.add_header('Authorization', 'Bearer ' + key)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read(20000)
            return r.status, len(body), body[:60].replace(b'\n', b' ')[:60]
    except Exception as e:
        sc = getattr(e, 'code', None)
        return sc, None, str(type(e).__name__)[:40]

groq_vars = {}
env_vars = env_map('.env') or {}
dev_vars = env_map('.dev.vars') or {}
for k, v in list(env_vars.items()):
    if k == 'GROQ_API_KEY':
        groq_vars['.env'] = v
for k, v in list(dev_vars.items()):
    if k == 'GROQ_API_KEY':
        groq_vars['.dev.vars'] = v

print('=== GROQ key reconciliation (hash prefixes only) ===')
all_groq = set()
new_key = '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'
for f, v in groq_vars.items():
    all_groq.add(v)
    print('%s: len=%d sha256[0:12]=%s %s' % (f, len(v), sha12(v),
          '== NEW_PASTED' if v == new_key else '<<< DIFFERENT FROM NEW_KEY'))
print('merged unique GROQ values:', sorted(all_groq))

print('\n=== configured MODEL slugs (names only) ===')
for f, m in [( '.env', [k for k in env_vars if k.endswith('_MODEL')]),
              ('.dev.vars', [k for k in dev_vars if k.endswith('_MODEL')])]:
    for k in m:
        print('%s %-24s = %s' % (f, k, env_vars.get(k) or dev_vars.get(k)))

print('\n=== pip deps (import) ===')
for mod in ('PIL', 'torch', 'silero_vad'):
    r = subprocess.run([sys.executable, '-c', 'import %s; print(%s.__version__)' % (mod, mod)],
                       capture_output=True, text=True)
    print('%-10s %s' % (mod, (r.stdout or r.stderr).strip()))

print('\n=== network probe ===')
for url in ('https://api.groq.com/openai/v1/models',
            'https://integrate.api.nvidia.com/v1/models',
            'https://openrouter.ai/api/v1/models',
            'https://pypi.org/simple/silero-vad/'):
    print('%s -> %s' % (url, http_probe(url)[0]))

print('\n=== configured-key model probes ===')
probes = [
    ('GROQ_MODEL',      env_vars.get('GROQ_MODEL')),
    ('GROQ_VISION_MODEL', env_vars.get('GROQ_VISION_MODEL')),
    ('OPENROUTER_MODEL', env_vars.get('OPENROUTER_MODEL')),
    ('NVIDIA_MODEL',     env_vars.get('NVIDIA_MODEL')),
    ('NVIDIA_VISION_MODEL', env_vars.get('NVIDIA_VISION_MODEL')),
    ('NVIDIA_CODE_MODEL', env_vars.get('NVIDIA_CODE_MODEL')),
    ('NVIDIA_FAST_MODEL', env_vars.get('NVIDIA_FAST_MODEL')),
    ('XKIRO_VISION_MODEL', env_vars.get('XKIRO_VISION_MODEL')),
    ('XKIRO_MODEL',      env_vars.get('XKIRO_MODEL')),
    ('GOOGLE_MODEL',     env_vars.get('GOOGLE_MODEL')),
]
for label, slug in probes:
    ok = slug and slug.strip()
    if not ok:
        print('%-20s (not configured)' % label)
        continue
    if label.startswith('GROQ'):
        url = 'https://api.groq.com/openai/v1/models/' + slug
        code = 'Bearer ' + env_vars.get('GROQ_API_KEY', '')
    elif label.startswith('NVIDIA'):
        url = 'https://integrate.api.nvidia.com/v1/models/' + slug
        code = 'Bearer ' + env_vars.get('NVIDIA_API_KEY', '')
    elif label.startswith('OPENROUTER'):
        url = 'https://openrouter.ai/api/v1/models/' + slug
        code = 'Bearer ' + env_vars.get('OPENROUTER_API_KEY', '')
    elif label.startswith('XKIRO'):
        url = 'https://llm.eqium.com/v1/models/' + slug
        code = 'Bearer ' + env_vars.get('XKIRO_API_KEY', '')
    else:
        url = 'https://generativelanguage.googleapis.com/v1beta/models/' + slug + ':list'
        code = 'Bearer ' + env_vars.get('GOOGLE_API_KEY', '')
    st, _, _ = http_probe(url, 'x', code)
    print('%-20s %-45s -> HTTP %s %s' % (label, slug, st, '(free)' if '(free)' in slug else ''))
