"""Firecrawl web search / deep research client for JARVIS.

Replaces the previous Tavily integration. Uses the Firecrawl REST API v2
(https://api.firecrawl.dev/v2) authenticated with FIRECRAWL_API_KEY.

  search()   -> ranked page results (+ markdown snippets)
  research() -> deep scan: wide search then scrape of the top sources,
                normalized into the {type, topic, report, sources} shape the
                HUD / dashboard research panels already render.
  extract()  -> clean markdown from one URL (scrape).

MULTI-KEY CREDIT POOL (background/firecrawl_keys.py)
Every configured FIRECRAWL_API_KEY* is treated as ONE provider:

  * simple calls (search, extract) use failover - one key at a time, rolling
    to the next key the moment one reports exhausted credits.
  * `research()` uses fanout - a wide search gathers a large source list, then
    each healthy key scrapes a DISJOINT slice of it in parallel. Key 1 reads
    the first N sources, key 2 the next N. No source is ever scraped twice, so
    the second key never pays for a page the first already read.

Never raises: returns {'error': ...} on any failure so the voice pipeline
stays alive, exactly like the old client.
"""
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    from concurrent.futures import ThreadPoolExecutor
except Exception:  # pragma: no cover - stdlib always has it on supported CPython
    ThreadPoolExecutor = None

_BASE = "https://api.firecrawl.dev/v2"
_TIMEOUT = 45
# Per-key HTTP deadline for one scrape. Deep research fans out across keys, so
# this stays short enough that a single slow page cannot stall the report.
_SCRAPE_TIMEOUT = 25
# How many sources one key may scrape in a single deep-research fanout.
_SOURCES_PER_KEY = 20

# This module is imported both by the voice engine (which already loaded
# .env/.dev.vars) and directly. Load the dotenv files here too, and read the
# keys lazily, so a missing import order can never look like "not set up".
try:
    from dotenv import dotenv_values as _dotenv_values
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for _file in (".env", ".dev.vars"):
        for _k, _v in _dotenv_values(os.path.join(_root, _file)).items():
            if _v and not os.environ.get(_k):
                os.environ[_k] = _v
except Exception:
    pass


def _pool():
    """Lazy-import the key pool (keeps this module importable standalone)."""
    global _POOL
    if _POOL is None:
        try:
            from background import firecrawl_keys
            _POOL = firecrawl_keys
        except Exception:
            try:
                import firecrawl_keys
                _POOL = firecrawl_keys
            except Exception:
                _POOL = False
    return _POOL or None


_POOL = None


def _pool_keys():
    pool = _pool()
    return pool.keys() if pool else []


def _healthy_keys():
    pool = _pool()
    return pool.healthy_keys() if pool else _pool_keys()


def _api_key():
    """Back-compat single key (first in the pool)."""
    keys = _pool_keys()
    return keys[0] if keys else (os.environ.get("FIRECRAWL_API_KEY") or "").strip()


def _headers(key=None):
    headers = {"Content-Type": "application/json"}
    key = key or _api_key()
    if key:
        headers["Authorization"] = "Bearer " + key
    return headers



def _post(path, payload, key=None, timeout=None):
    """POST to Firecrawl. Never raises.

    With `key=None` this is the FAILOVER path: try each healthy key in order
    and only give up when every key has been tried. A key that reports
    exhausted credits is parked so later requests skip it immediately.
    """
    pool = _pool()
    if key is None:
        candidates = _healthy_keys()
        if not candidates and pool is not None:
            # Everything is parked. Still try once so a cooled-down key that
            # has since been topped up can still serve the request.
            candidates = pool.keys()
        if not candidates:
            return {"error": "FIRECRAWL_API_KEY not set. Set it in .env or .dev.vars."}
    else:
        candidates = [key]

    last_error = ""
    for candidate in candidates:
        res, err = _post_once(path, payload, candidate,
                              timeout if timeout is not None else _TIMEOUT)
        if not err:
            if pool is not None:
                pool.report_success(candidate)
            return res
        last_error = err
        # Only a credit/quota error retires this key; a 5xx or timeout is
        # transient and must not disable a perfectly good key.
        parked = False
        if pool is not None:
            parked = pool.report_failure(candidate, err)
        if not parked:
            # Non-credit failure: a different key would hit the same problem,
            # so surface it immediately instead of burning the whole pool.
            return {"error": "%s (check FIRECRAWL_API_KEY)" % last_error}
    return {"error": "%s (all %d Firecrawl key(s) unavailable)"
                     % (last_error, len(candidates))}


def _post_once(path, payload, key, timeout):
    """One authenticated attempt. Returns (parsed_or_error_dict, error_text)."""
    req = urllib.request.Request(_BASE + path,
                                 data=json.dumps(payload).encode("utf-8"),
                                 headers=_headers(key), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8")), ""
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "ignore")
        try:
            parsed = json.loads(body)
            err = parsed.get("error", "")
            if isinstance(err, dict):
                err = err.get("message") or json.dumps(err)[:180]
            msg = err or parsed.get("message") or ("Firecrawl HTTP %s" % exc.code)
        except Exception:
            msg = body[:180] or ("Firecrawl HTTP %s" % exc.code)
        # Keep the HTTP code: Firecrawl signals spent credits with 402 and the
        # pool keys off that as well as the message text.
        return ({"error": "%s (HTTP %s)" % (str(msg)[:200], exc.code)},
                "%s HTTP %s" % (str(msg)[:200], exc.code))
    except Exception as exc:
        return ({"error": "Firecrawl request failed: %s: %s"
                        % (type(exc).__name__, exc)},
                "Firecrawl request failed: %s: %s" % (type(exc).__name__, exc))



def _normalize_results(data):
    """Flatten the v2 /search shape {success, data: {web: [...]}} to result dicts."""
    out = []
    if not isinstance(data, dict):
        return out
    payload = data.get("data") or {}
    items = payload.get("web") if isinstance(payload, dict) else None
    if items is None:  # tolerate flat-list shapes from future API versions
        items = data.get("data")
    for item in items or []:
        if not isinstance(item, dict):
            continue
        meta = item.get("metadata") or {}
        out.append({
            "url": item.get("url") or meta.get("sourceURL") or "",
            "title": item.get("title") or meta.get("title") or "Result",
            "content": item.get("description") or item.get("markdown") or "",
            "score": item.get("score"),
            "raw_content": (item.get("markdown") or item.get("description") or ""),
        })
    return out


def _search_error(res, fallback):
    err = res.get("error", "")
    if isinstance(err, dict):
        err = err.get("message") or ""
    return str(err).strip() or fallback


def search(query, max_results=5):
    """Web search via Firecrawl /search (ranked pages with content snippets)."""
    res = _post("/search", {"query": query, "limit": max_results, "sources": ["web"]})
    if res.get("error") or not res.get("success"):
        return {"type": "search", "query": query,
                "error": _search_error(res, "Firecrawl search failed")}
    results = _normalize_results(res)
    answer = " ".join((r["content"] or "") for r in results[:3])[:500].strip()
    return {"type": "search", "query": query, "results": results,
            "answer": answer, "provider": "firecrawl"}


def _scrape(url, key=None):
    """Scrape one URL to markdown, optionally pinned to a specific key."""
    res = _post("/scrape", {"url": url, "formats": ["markdown"]},
                key=key, timeout=_SCRAPE_TIMEOUT)
    if not res.get("success") or not isinstance(res.get("data"), dict):
        return ""
    return res["data"].get("markdown") or ""


def _distinct_urls(rows, cap):
    """One URL per host, in rank order, so two keys never fight over a domain."""
    seen, out = set(), []
    for r in rows:
        url = (r or {}).get("url") or ""
        if not url:
            continue
        host = urllib.parse.urlparse(url).netloc.lower()
        if not host or host in seen:
            continue
        seen.add(host)
        out.append(url)
        if len(out) >= cap:
            break
    return out


def _scrapes_for_key(urls, key):
    """Scrape one key's disjoint slice. Returns (url, markdown) pairs."""
    out = []
    for url in urls:
        try:
            md = _scrape(url, key=key)
        except Exception:
            md = ""
        if md:
            out.append((url, md))
    return out


def _fanout_scrape(urls, keys, per_key):
    """Run every healthy key over its own slice, all in parallel.

    Returns (scraped_pairs, slices) where slices is [(key, [urls])] so a
    failure can be attributed to the key that caused it.
    """
    slices = []
    if len(keys) > 1 and _pool() is not None:
        for key, chunk in _pool().split_evenly(urls, keys):
            if chunk:
                slices.append((key, chunk))
    elif urls:
        slices.append((keys[0], urls))

    scraped = []
    if len(slices) > 1 and ThreadPoolExecutor is not None:
        with ThreadPoolExecutor(max_workers=len(slices)) as exec_pool:
            futures = [exec_pool.submit(_scrapes_for_key, chunk, key)
                       for key, chunk in slices]
            for fut in futures:
                try:
                    scraped.extend(fut.result())
                except Exception:
                    continue
    else:
        for key, chunk in slices:
            scraped.extend(_scrapes_for_key(chunk, key))
    return scraped, slices



def research(topic, per_key=_SOURCES_PER_KEY):
    """Deep multi-source scan using the WHOLE key pool at once.

    1. One wide /search gathers a ranked candidate list.
    2. The list is de-duplicated per host and partitioned into contiguous,
       non-overlapping slices - one per healthy key.
    3. Every key scrapes its own slice IN PARALLEL, so key 1 reads the first N
       sources and key 2 reads the next N. A source is never scraped twice,
       so the second key never pays for a page the first already read.

    If a key dies mid-fanout its finished work is kept and its remaining
    sources are picked up by a surviving key, so one dead key can never
    silently shrink the report.
    """
    res = _post("/search", {"query": topic, "limit": 8, "sources": ["web"]})
    if res.get("error") or not res.get("success"):
        return {"type": "research", "topic": topic,
                "error": _search_error(res, "Firecrawl research failed")}
    results = _normalize_results(res)

    keys = _healthy_keys() or _pool_keys()[:1]
    if not keys:
        return {"type": "research", "topic": topic,
                "error": "No Firecrawl API key configured."}

    # Budget = per_key * number of keys: with 2 keys at 20 each, key 1 takes
    # sources 1-20 and key 2 takes 21-40.
    cap = per_key * len(keys)
    urls = _distinct_urls(results, cap)
    if not urls:
        urls = [r["url"] for r in results if r.get("url")][:cap]

    scraped, slices = _fanout_scrape(urls, keys, per_key)

    # A key that failed mid-run leaves sources un-scraped. Re-try those on a
    # surviving key so the report does not silently lose its tail.
    done = set(u for u, _ in scraped)
    missing = [u for u in urls if u not in done]
    if missing:
        survivor = next((k for k, c in slices if c), None)
        if survivor:
            scraped.extend(_scrapes_for_key(missing[:per_key], survivor))

    # Build the dossier from scraped pages; fall back to search snippets when
    # the pool could not read anything at all.
    report_parts, seen_hosts = [], set()
    for url, md in scraped:
        host = urllib.parse.urlparse(url).netloc.lower()
        if host in seen_hosts:
            continue
        seen_hosts.add(host)
        title = (md.lstrip().split("\n", 1)[0] or host)[:140].strip("#* ")
        body = md.strip()
        if len(body) > 700:
            body = body[:700].rsplit(" ", 1)[0] + "..."
        report_parts.append("### %s\n%s" % (title, body))
    if not report_parts:
        for r in results[:4]:
            body = (r.get("raw_content") or r.get("content") or "").strip()
            if body:
                report_parts.append("### %s\n%s"
                                    % (r.get("title") or r.get("url"), body[:400]))
    report = "\n\n".join(report_parts) or " ".join(
        r.get("content") for r in results[:4])[:800]

    all_sources = [u for u, _ in scraped] or [r["url"] for r in results if r.get("url")]
    return {"type": "research", "topic": topic, "report": report,
            "sources": all_sources[:cap],
            "provider": "firecrawl",
            "keys_used": len(keys), "scraped": len(scraped)}



def extract(url):
    md = _scrape(url)
    if not md:
        return {"type": "extract", "url": url, "error": "Firecrawl scrape returned no content"}
    return {"type": "extract", "url": url, "content": md}


_CREDITS_RE = re.compile(r"credit|quota|balance|billing|insufficient|402", re.I)


def _redact_keys(text):
    """Strip every configured key out of an error string before it is stored.

    `probe_error` reaches /state and the spoken reply, so a provider message
    that echoes the Authorization header must never carry the secret with it.
    """
    out = str(text or "")
    for key in _pool_keys():
        if key and key in out:
            out = out.replace(key, "fc-***")
    return out[:300]


def status() -> dict:
    """Return truthy only when Firecrawl actually answers a lightweight probe.

    A bare env var alone is NOT enough - the voice path must get a real
    round-trip back before we tell the user "search is available". The probe
    uses the FAILOVER path, so a dead first key still reports available.
    """
    keys = _pool_keys()
    pool = _pool()
    snap = pool.pool_status() if pool is not None else {
        "total": len(keys), "healthy": len(keys), "fanout": len(keys) > 1, "keys": []}
    base = {
        "available": False,
        "provider": "firecrawl",
        "api_key_set": bool(keys),
        "keys_total": snap.get("total", len(keys)),
        "keys_healthy": snap.get("healthy", len(keys)),
        "fanout": bool(snap.get("fanout")),
        "key_slots": [r.get("slot") for r in (snap.get("keys") or [])],
        "parked_keys": [r.get("slot") for r in (snap.get("keys") or [])
                        if r.get("parked")],
        # WHY the probe failed. Without this the caller can only say
        # "available nahi hai, setup kijiye", which blames a missing key for an
        # exhausted one.
        "probe_error": "",
        "out_of_credits": False,
    }
    if not keys:
        return base
    try:
        probe = _post("/search", {"query": "jarvis probe", "limit": 1, "sources": ["web"]})
        base["available"] = bool(probe and probe.get("success") and probe.get("data"))
        if not base["available"]:
            base["probe_error"] = _redact_keys(
                str((probe or {}).get("error") or "probe returned no data"))
    except Exception as exc:
        base["available"] = False
        base["probe_error"] = _redact_keys("%s: %s" % (type(exc).__name__, exc))
    base["out_of_credits"] = bool(_CREDITS_RE.search(base["probe_error"]))
    return base


def key_pool_status():
    """Non-secret key health for /state and the dashboard research panel."""
    pool = _pool()
    if pool is not None:
        return pool.pool_status()
    return {"total": 0, "healthy": 0, "fanout": False, "keys": []}


def available():
    return bool(_api_key())
