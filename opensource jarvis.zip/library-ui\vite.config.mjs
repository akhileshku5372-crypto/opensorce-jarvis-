import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

/* The archive UI builds to ONE fixed-name pair that JARVIS injects lazily:
 *   public/static/library/library-bundle.js
 *   public/static/library/library-bundle.css
 * Fixed names (no content hash) because app.js loads them by path, and the
 * dashboard's own vite build never sees this config. Run it with:
 *   node scripts/build-library-bundle.cjs
 */
export default defineConfig({
  root: 'library-ui',
  base: '/static/library/',
  // The repo's root tsconfig compiles JSX to hono/jsx (that is what the Hono
  // server renders). This UI is React, so the runtime is pinned here as well as
  // in library-ui/tsconfig.json - otherwise the bundle hands Hono JSX nodes to
  // React and it dies with "Objects are not valid as a React child".
  plugins: [react({ jsxImportSource: 'react' }), tailwindcss()],
  build: {
    outDir: '../public/static/library',
    emptyOutDir: true,
    cssCodeSplit: false,
    target: 'es2020',
    rollupOptions: {
      input: 'src/main.tsx',
      output: {
        entryFileNames: 'library-bundle.js',
        assetFileNames: 'library-bundle[extname]',
      },
    },
  },
})
