"""Compound voice instructions must become real tasks, not one eaten fragment.

Live 2026-10-18, measured with every sink stubbed (scratch/route_trace.py):

  "chrome kholo aur lofi beats search karo phir neeche scroll karo"
      -> bridge_command('scroll down')        # steps 1 and 2 silently dropped
  "open google chrome and search for lofi beats then scroll down"
      -> bridge_command('scroll down')        # same
  "jarvis hard task - open chrome and search lofi beats"
      -> bridge_command('hard task - open ...')  # Cortex never started: steps=0

Cause: _phase1_handle() (called at voice_engine.py:7286) ends in an alias table
whose entries are matched with an UNANCHORED re.search over the whole sentence
(line 5004-5009) and then `return True`. Any utterance that merely contains
"scroll down" / "volume up" / "play" is collapsed to that one bridge command,
so the Plan->Act->Observe loop at line 7758 is unreachable in practice.

Fix contract tested here:
  * a MULTI-STEP action sentence goes to the agent loop, and no single alias
    may claim it;
  * the hard-task marker still works, and now actually reaches Cortex;
  * single-atom commands are untouched - "open notepad" must still be the
    fast deterministic bridge path, never an LLM plan.

Stdlib only. No mouse, no keyboard, no browser, no WhatsApp, no network.
"""
import importlib.util
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "voice_engine", ROOT / "background" / "voice_engine.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load_engine()

COMPOUND = [
    "chrome kholo aur lofi beats search karo phir neeche scroll karo",
    "open google chrome and search for lofi beats then scroll down",
    "youtube kholo aur pehla video play karo phir neeche scroll karo",
]
# Multi-step, but already owned by a purpose-built deterministic route:
# _WRITE_ROUTE_RE handles "open <app> and write <text>" without the VLM. The
# requirement here is only that it must never collapse to one bridge atom.
COMPOUND_OWNED_ELSEWHERE = [
    "notepad kholo aur hello likh kar save karo",
]
SINGLE_ATOM = [
    "neeche scroll karo",
    "scroll down",
    "volume up karo",
    "open notepad",
    "notepad band karo",
    "music play karo",
]


class _FakeAgent:
    """Stands in for background/screen_agent.py so no input is ever synthesized."""

    def has_pending(self):
        return False

    def click_target(self, *a, **k):
        return "CLICK"

    def move_mouse(self, *a, **k):
        return "MOVE"

    def scroll_screen(self, *a, **k):
        return "SCROLL"

    def press_key(self, *a, **k):
        return "PRESS"

    def screen_task(self, task, *a, **k):
        return "SCREEN_TASK"

    def close_app(self, target):
        return "CLOSE"

    def cancel_pending(self, *a, **k):
        return "CANCEL"


class MultiStepDetectionTest(unittest.TestCase):
    def test_compound_sentences_are_multi_step(self):
        for text in COMPOUND:
            with self.subTest(text=text[:45]):
                self.assertTrue(ENGINE._multi_step_action(text),
                                "%r is two or more actions but was not detected"
                                % text[:60])

    def test_single_commands_are_not_multi_step(self):
        for text in SINGLE_ATOM:
            with self.subTest(text=text):
                self.assertFalse(ENGINE._multi_step_action(text),
                                 "%r is ONE action; sending it to an LLM plan "
                                 "would make a fast deterministic command slow "
                                 "and non-deterministic" % text)

    def test_questions_are_not_multi_step(self):
        for text in ("aaj mausam kaisa hai", "mujhe batao computer me kya chal raha hai",
                     "kya tumhe pata hai music kaise play karte hain"):
            with self.subTest(text=text[:40]):
                self.assertFalse(ENGINE._multi_step_action(text))


class RoutingTest(unittest.TestCase):
    """Which sink claims each utterance, with every side effect stubbed."""

    def _route(self, text):
        calls = []
        spoken = []

        def sink(name, ret):
            def f(*a, **k):
                calls.append((name, a[0] if a and isinstance(a[0], str) else ""))
                return ret
            return f

        real = {}
        patches = {
            "bridge_command": sink("BRIDGE", (True, "bridge ok")),
            "brain": sink("BRAIN", "BRAIN_REPLY"),
            "_agent_route": sink("CORTEX", None),
            "_open_url": sink("OPEN_URL", "Opening the website, Sir."),
            "speak": lambda msg, ui=None: (spoken.append(str(msg)), True)[1],
            "_screen_agent": lambda: _FakeAgent(),
        }
        for name, value in patches.items():
            real[name] = getattr(ENGINE, name, None)
            setattr(ENGINE, name, value)
        try:
            with ENGINE._recent_lock:
                ENGINE._recent.clear()
            with ENGINE._action_stamps_lock:
                ENGINE._action_stamps.clear()
            ENGINE.run_command(text, None, None, "typed")
        finally:
            for name, value in real.items():
                if value is not None:
                    setattr(ENGINE, name, value)
        return [n for n, _ in calls], calls, spoken

    def test_compound_never_collapses_to_one_alias(self):
        for text in COMPOUND:
            with self.subTest(text=text[:45]):
                names, calls, _ = self._route(text)
                eaten = [arg for name, arg in calls
                         if name == "BRIDGE" and arg.strip() in
                         ("scroll down", "scroll up", "volume up", "play", "mute")]
                self.assertFalse(
                    eaten,
                    "%r was collapsed to the single bridge command %r - the "
                    "other steps were silently dropped" % (text[:60], eaten))
                self.assertIn("CORTEX", names,
                              "a multi-step task must reach the agent loop")

    def test_compound_owned_elsewhere_never_collapses_to_one_atom(self):
        for text in COMPOUND_OWNED_ELSEWHERE:
            with self.subTest(text=text[:45]):
                names, calls, spoken = self._route(text)
                self.assertTrue(names or spoken,
                                "%r was silently dropped" % text[:60])
                for _, arg in calls:
                    self.assertNotIn(
                        arg.strip().lower(),
                        ("scroll down", "scroll up", "volume up", "play", "mute"),
                        "%r was reduced to the single atom %r" % (text[:60], arg))

    def test_hard_task_marker_reaches_the_loop(self):
        names, _, _ = self._route(
            "jarvis hard task - open chrome and search lofi beats")
        self.assertIn("CORTEX", names,
                      "the marker exists precisely to reach Cortex; it was "
                      "claimed by %r instead" % names)

    def test_single_atom_stays_on_the_fast_path(self):
        for text in ("neeche scroll karo", "open notepad", "volume up karo"):
            with self.subTest(text=text):
                names, calls, _ = self._route(text)
                self.assertIn("BRIDGE", names,
                              "a one-step command must stay deterministic")
                self.assertNotIn("CORTEX", names,
                                 "%r is one action; it must not pay for an LLM "
                                 "plan" % text)


class AgentLoopGateTest(unittest.TestCase):
    """The loop's own gate: a multi-step goal is enough; one atom is not."""

    def setUp(self):
        self._real_ext = ENGINE._extensions_mod
        self.addCleanup(lambda: setattr(ENGINE, "_extensions_mod", self._real_ext))
        self.seen = []
        seen = self.seen

        class FakeExt:
            @staticmethod
            def run_goal(goal):
                seen.append(goal)
                return {"ok": False}      # stop here; the call is the assertion

        ENGINE._extensions_mod = lambda: FakeExt

    def test_compound_goal_reaches_the_planner(self):
        ENGINE._agent_route("open chrome and search for lofi beats then scroll down")
        self.assertEqual(len(self.seen), 1,
                         "a multi-step action must be handed to the planner; "
                         "returning None sends it to the chat brain instead")

    def test_single_atom_does_not(self):
        for goal in ("open notepad", "neeche scroll karo", "volume up karo"):
            with self.subTest(goal=goal):
                ENGINE._agent_route(goal)
        self.assertEqual(
            self.seen, [],
            "a one-step command must stay on the deterministic bridge path - "
            "sending it to an LLM plan makes a reliable action unreliable")

    def test_marker_still_works_and_is_stripped(self):
        ENGINE._agent_route("jarvis hard task - open chrome and search lofi beats")
        self.assertEqual(len(self.seen), 1, "the marker path must still start")
        self.assertNotIn("hard task", self.seen[0].lower(),
                         "the marker must be stripped before the planner sees "
                         "the goal, or it eats the goal text")


class AgentToolSurfaceTest(unittest.TestCase):
    """Reaching the loop is useless if the loop has no tool for the step.

    screen_agent registered only click / type / read-screen, so a planned
    "scroll down" step had nothing to call even after routing was fixed.
    scroll_screen() and press_key() existed as functions reachable only from
    the hand-written voice regexes.
    """

    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location(
            "screen_agent_tools", ROOT / "background" / "screen_agent.py")
        cls.SA = importlib.util.module_from_spec(spec)
        sys.modules["screen_agent_tools"] = cls.SA
        spec.loader.exec_module(cls.SA)

    def _names(self):
        out = []
        for s in self.SA.specs():
            out.append(getattr(s, "name", None) or s[0])
        return out

    def test_scroll_and_key_are_registered(self):
        names = self._names()
        for required in ("gui_scroll", "gui_press_key"):
            self.assertIn(required, names,
                          "the planner cannot perform a step that has no tool")

    @unittest.skipUnless(importlib.util.find_spec("pyautogui"),
                         "without pyautogui the handler bails at the "
                         "availability guard and never reaches validation")
    def test_scroll_validates_before_touching_the_desktop(self):
        # A bad direction must be refused, not silently defaulted to "down".
        out = str(self.SA.gui_scroll({"direction": "sideways"}))
        self.assertIn("direction", out.lower(), out)
        self.assertNotIn("scrolled", out.lower(),
                         "%r scrolled the desktop despite a bad direction" % out)
        out = str(self.SA.gui_press_key({"key": "  "}))
        self.assertNotIn("pressed", out.lower(),
                         "%r pressed a key that was never named" % out)

    def test_handlers_stay_silent_about_success_when_unavailable(self):
        real = self.SA.available
        self.SA.available = lambda: False
        try:
            for out in (self.SA.gui_scroll({"direction": "down"}),
                        self.SA.gui_press_key({"key": "enter"})):
                self.assertIn("unavailable", str(out).lower(),
                              "%r claimed an action it did not perform" % out)
        finally:
            self.SA.available = real


if __name__ == "__main__":
    unittest.main(verbosity=2)
