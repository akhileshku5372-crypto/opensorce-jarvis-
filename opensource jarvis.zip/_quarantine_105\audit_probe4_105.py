"""WhatsApp desktop force check only (blocking, ~2s)."""
import importlib.util, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load_bg(name):
    full="jarvis_cowork_"+name
    if full in sys.modules: return sys.modules[full]
    p=ROOT/"background"/(name+".py")
    import importlib.util as iu
    spec=iu.spec_from_file_location(full,p)
    m=iu.module_from_spec(spec); sys.modules[full]=m
    spec.loader.exec_module(m); return m
wa=load_bg("whatsapp_sender")
print("FORCE_DESKTOP",wa.desktop_app_installed(force=True))
print("FORCE_AUTOSEND",wa.can_autosend(force=True))
ai=load_bg("app_index")
rows=ai.search("whatsapp",limit=4)
print("APPINDEX_WA",[(r.get("name"),r.get("source")) for r in rows])
