/* JARVIS Armour Studio (Phase 5.1-5.3) - honest 3D armour viewport.
 *
 * What this file does NOT pretend
 * -------------------------------
 * There is no Iron Man model in this repository and none can be downloaded here,
 * so the viewport never claims to show one. It lists the real .glb/.gltf files
 * the backend finds in artifacts/3d and loads one if you drop it there. Until
 * then it renders a procedurally built PLACEHOLDER and labels it as such in the
 * UI - a labelled placeholder, never a fake model.
 *
 * Reuses what already works instead of duplicating it: the MediaPipe hand
 * landmarks the camera pipeline already publishes on window.__JARVIS_HANDS__
 * drive the gesture controls, and three.js comes from the Phase 5 bundle.
 */
(function () {
  'use strict'

  var BUNDLE = '/static/armour-bundle.js'
  var MODELS_URL = '/armour/models'

  // Fixed callout anchors, used when a model has no recognisable part names.
  // x/y/z are metres in the model's own local space (placeholder scale).
  var SUBSYSTEMS = [
    { id: 'reactor', label: 'Arc Reactor', note: 'Chest power core',
      anchor: [0, 1.42, 0.36] },
    { id: 'repulsors', label: 'Repulsors', note: 'Palm emitters',
      anchor: [0.42, 0.92, 0.1] },
    { id: 'stabilizers', label: 'Flight Stabilizers', note: 'Back thruster pair',
      anchor: [0, 1.15, -0.3] },
    { id: 'hud', label: 'HUD', note: 'Visor projection',
      anchor: [0, 1.72, 0.3] }
  ]

  var state = {
    ready: false,        // three bundle loaded
    active: false,       // view is open -> rendering
    blueprint: false,
    modelName: '',
    modelSource: 'placeholder',
    gesture: 'off',      // off | waiting | live
    lastError: ''
  }

  var lib = null          // { THREE, OrbitControls, GLTFLoader }
  var scene, camera, renderer, controls, rootGroup, placeholderGroup
  var raf = 0, clock, raycaster, mouse = { x: 0, y: 0 }
  var boundSubsystem = null
  var dom = {}

  // ── bundle loading ────────────────────────────────────────────────────────
  function loadBundle(cb) {
    if (lib) return cb()
    if (state.ready) return
    state.ready = true
    var s = document.createElement('script')
    s.src = BUNDLE
    s.onload = function () {
      lib = window.JARVIS_ARMOUR_THREE || null
      if (!lib) { state.lastError = 'armour three bundle loaded but exposed no API'; return }
      build()
      cb()
    }
    s.onerror = function () {
      state.lastError = 'could not load /static/armour-bundle.js'
      say('3D engine load nahi hui - bundle missing')
    }
    document.head.appendChild(s)
  }

  // ── scene ─────────────────────────────────────────────────────────────────
  function build() {
    var THREE = lib.THREE
    scene = new THREE.Scene()
    scene.background = new THREE.Color('#04080c')
    scene.fog = new THREE.Fog('#04080c', 6, 18)

    camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100)
    camera.position.set(2.4, 1.6, 3.2)

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    renderer.outputColorSpace = THREE.SRGBColorSpace

    scene.add(new THREE.HemisphereLight(0x9fd8ff, 0x0a1418, 0.75))
    var key = new THREE.DirectionalLight(0xdff3ff, 1.5)
    key.position.set(3, 5, 4)
    scene.add(key)
    var rim = new THREE.DirectionalLight(0x1de9ff, 1.1)
    rim.position.set(-3, 2.4, -3)
    scene.add(rim)

    var grid = new THREE.GridHelper(14, 28, 0x1de9ff, 0x0f2a33)
    grid.position.y = 0
    scene.add(grid)

    rootGroup = new THREE.Group()
    scene.add(rootGroup)

    controls = new lib.OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.08
    controls.minDistance = 1.4
    controls.maxDistance = 9
    controls.target.set(0, 1.15, 0)
    controls.addEventListener('change', renderOnce)

    raycaster = new THREE.Raycaster()
    renderer.domElement.addEventListener('pointerdown', onPick)
    clock = new THREE.Clock()

    buildPlaceholder()
    mount()
    resize()
    loop()
  }

  /* Procedural stand-in so the viewport is never blank. Clearly a placeholder:
   * metallic torso capsule, arc-reactor torus, repulsor rings and stabiliser
   * fins - geometry, not a model of anything. */
  function buildPlaceholder() {
    var THREE = lib.THREE
    placeholderGroup = new THREE.Group()
    placeholderGroup.name = 'placeholder'

    var steel = new THREE.MeshStandardMaterial({ color: 0x9aa7ad, metalness: 0.9, roughness: 0.35 })
    var glow = new THREE.MeshBasicMaterial({ color: 0x36e2ff })

    var torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.9, 8, 24), steel)
    torso.position.y = 1.15
    torso.name = 'placeholder_torso'
    placeholderGroup.add(torso)

    var head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 24, 16), steel)
    head.position.y = 1.82
    head.name = 'placeholder_head'
    placeholderGroup.add(head)

    var reactor = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.045, 16, 40), glow)
    reactor.position.set(0, 1.42, 0.4)
    reactor.name = 'placeholder_reactor'
    placeholderGroup.add(reactor)

    ;[-1, 1].forEach(function (side) {
      var repulsor = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.035, 12, 32), glow)
      repulsor.position.set(0.44 * side, 0.95, 0.12)
      repulsor.name = 'placeholder_repulsor_' + (side < 0 ? 'l' : 'r')
      placeholderGroup.add(repulsor)

      var fin = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.06, 0.22), steel)
      fin.position.set(0.2 * side, 1.2, -0.3)
      fin.name = 'placeholder_stabilizer_' + (side < 0 ? 'l' : 'r')
      placeholderGroup.add(fin)
    })

    var hud = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.1, 0.02), glow)
    hud.position.set(0, 1.8, 0.24)
    hud.name = 'placeholder_hud'
    placeholderGroup.add(hud)

    rootGroup.add(placeholderGroup)
  }

  function mount() {
    var host = dom.stage
    if (!host) return
    if (renderer.domElement.parentNode !== host) {
      host.innerHTML = ''
      renderer.domElement.className = 'armour-canvas'
      host.appendChild(renderer.domElement)
    }
    window.addEventListener('resize', resize)
  }

  function resize() {
    if (!renderer || !dom.stage) return
    var w = dom.stage.clientWidth || 640
    var h = dom.stage.clientHeight || 460
    camera.aspect = w / Math.max(1, h)
    camera.updateProjectionMatrix()
    renderer.setSize(w, h, false)
    renderOnce()
  }

  function renderOnce() {
    if (renderer && state.active) renderer.render(scene, camera)
  }

  function loop() {
    cancelAnimationFrame(raf)
    var step = function () {
      raf = requestAnimationFrame(step)
      if (!renderer) return
      applyGestures()
      if (state.active) {
        controls.update()
        renderer.render(scene, camera)
      } else {
        clock.getDelta()
      }
    }
    raf = requestAnimationFrame(step)
  }

  // ── models ────────────────────────────────────────────────────────────────
  function fetchModels(cb) {
    fetch(MODELS_URL).then(function (r) { return r.json() }).then(function (d) {
      cb((d && d.models) || [])
    }).catch(function (err) {
      state.lastError = String((err && err.message) || err)
      say('model list nahi mili: ' + state.lastError)
      cb([])
    })
  }

  function loadModel(name) {
    if (!lib || !name) return
    say('model load ho raha hai: ' + name)
    new lib.GLTFLoader().load(
      '/armour/model/' + encodeURIComponent(name),
      function (gltf) {
        clearModel()
        var model = gltf.scene
        model.name = name
        rootGroup.add(model)
        state.modelName = name
        state.modelSource = 'file'
        bindSubsystems(model)
        applyBlueprint()
        fitCamera(model)
        say(name + ' load ho gaya - real model')
        renderSubsystemList()
      },
      undefined,
      function (err) {
        state.lastError = 'model load failed: ' + String((err && err.message) || err)
        say(state.lastError + ' - placeholder dikha raha hai')
        renderSubsystemList()
      })
  }

  function clearModel() {
    if (!rootGroup) return
    rootGroup.traverse(function (obj) {
      if (obj.isMesh) {
        if (obj.geometry && obj.geometry.dispose) obj.geometry.dispose()
        if (obj.material && obj.material.dispose) obj.material.dispose()
      }
    })
    while (rootGroup.children.length) rootGroup.remove(rootGroup.children[0])
    placeholderGroup = null
  }

  function fitCamera(model) {
    try {
      var box = new lib.THREE.Box3().setFromObject(model)
      var size = box.getSize(new lib.THREE.Vector3())
      var center = box.getCenter(new lib.THREE.Vector3())
      var radius = Math.max(size.x, size.y, size.z) / 2 || 1
      controls.target.copy(center)
      camera.position.set(center.x + radius * 1.6, center.y + radius * 0.8,
        center.z + radius * 2.2)
      controls.update()
    } catch (e) { /* a model without geometry keeps the default camera */ }
  }

  /* Bind a callout to a real mesh when its name mentions the subsystem, so the
   * blueprint list points at actual geometry instead of a guessed anchor. */
  function bindSubsystems(model) {
    var found = {}
    model.traverse(function (obj) {
      if (!obj.name) return
      var low = obj.name.toLowerCase()
      SUBSYSTEMS.forEach(function (s) {
        if (found[s.id]) return
        if (low.indexOf(s.id) >= 0 || low.indexOf(s.label.toLowerCase()) >= 0) {
          found[s.id] = obj
        }
      })
    })
    rootGroup.userData.bound = found
  }

  // ── blueprint mode (5.3) ──────────────────────────────────────────────────
  function applyBlueprint() {
    var glow = new lib.THREE.MeshBasicMaterial({ color: 0x36e2ff, wireframe: true })
    rootGroup.traverse(function (obj) {
      if (!obj.isMesh) return
      if (state.blueprint) {
        if (!obj.userData._solid) obj.userData._solid = obj.material
        obj.material = glow
      } else if (obj.userData._solid) {
        obj.material = obj.userData._solid
        obj.userData._solid = null
      }
    })
    if (dom.blueprintBtn) {
      dom.blueprintBtn.setAttribute('aria-pressed', String(state.blueprint))
      dom.blueprintBtn.classList.toggle('active', state.blueprint)
    }
  }

  // ── gesture control (5.2) ────────────────────────────────────────────────
  /* Reads the landmarks the existing camera pipeline already publishes. Palm
   * position orbits the model, a pinch zooms. Nothing here starts a camera or a
   * second MediaPipe instance - it only consumes what already runs. */
  var gest = { px: 0, py: 0, pinch: null }
  function applyGestures() {
    var hands = window.__JARVIS_HANDS__
    if (!hands || !hands.length || !controls) {
      if (state.gesture !== 'off') { state.gesture = 'off'; paintGesture() }
      return
    }
    var lm = hands[0]
    if (!lm || lm.length < 18) { state.gesture = 'waiting'; paintGesture(); return }
    state.gesture = 'live'

    var palm = lm[9]
    var scale = Math.max(0.02, dist(lm[0], lm[9]))
    var px = palm.x - gest.px
    var py = palm.y - gest.py
    gest.px = palm.x
    gest.py = palm.y

    // Palm movement orbits: vertical drag -> azimuth, horizontal -> polar.
    var radius = camera.position.distanceTo(controls.target)
    var offset = camera.position.clone().sub(controls.target)
    var spherical = new lib.THREE.Spherical().setFromVector3(offset)
    spherical.theta -= px * 6
    spherical.phi = Math.max(0.25, Math.min(Math.PI - 0.25, spherical.phi - py * 6))
    camera.position.copy(controls.target).add(
      new lib.THREE.Vector3().setFromSpherical(spherical))
    if (Math.abs(px) > 0.001 || Math.abs(py) > 0.001) camera.lookAt(controls.target)

    // Pinch (thumb tip 4 vs index tip 8) zooms by changing the orbit radius.
    var pinch = dist(lm[4], lm[8]) / scale
    if (gest.pinch != null && Math.abs(pinch - gest.pinch) > 0.05) {
      var factor = gest.pinch / Math.max(0.05, pinch)
      var next = Math.max(controls.minDistance, Math.min(controls.maxDistance,
        radius * factor))
      camera.position.copy(controls.target).add(offset.setLength(next))
    }
    gest.pinch = pinch
    paintGesture()
  }

  function dist(a, b) {
    var dx = (a.x - b.x), dy = (a.y - b.y), dz = ((a.z || 0) - (b.z || 0))
    return Math.sqrt(dx * dx + dy * dy + dz * dz)
  }

  function paintGesture() {
    if (!dom.gesture) return
    var text = state.gesture === 'live' ? 'Gesture: live (palm rotate, pinch zoom)'
      : state.gesture === 'waiting' ? 'Gesture: camera on, hands not visible'
        : 'Gesture: camera off'
    if (dom.gesture.textContent !== text) dom.gesture.textContent = text
  }

  // ── picking ───────────────────────────────────────────────────────────────
  function onPick(event) {
    if (!state.active || !rootGroup) return
    var rect = renderer.domElement.getBoundingClientRect()
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
    raycaster.setFromCamera(mouse, camera)
    var hits = raycaster.intersectObjects(rootGroup.children, true)
    var name = hits.length ? (hits[0].object.name || '') : ''
    var hit = SUBSYSTEMS.filter(function (s) {
      return name && (name.toLowerCase().indexOf(s.id) >= 0)
    })[0]
    highlight(hit ? hit.id : '')
  }

  function highlight(id) {
    boundSubsystem = id || null
    if (boundSubsystem && lib) {
      var pulse = new lib.THREE.Mesh(
        new lib.THREE.SphereGeometry(0.12, 16, 12),
        new lib.THREE.MeshBasicMaterial({ color: 0xff4d3d }))
      var anchor = SUBSYSTEMS.filter(function (s) {
        return s.id === boundSubsystem
      })[0]
      if (anchor) pulse.position.set(anchor.anchor[0], anchor.anchor[1], anchor.anchor[2])
      pulse.name = 'callout_marker'
      rootGroup.add(pulse)
      setTimeout(function () {
        if (pulse.parent) rootGroup.remove(pulse)
        if (pulse.geometry) pulse.geometry.dispose()
        if (pulse.material) pulse.material.dispose()
      }, 1400)
    }
    if (dom.subsystems) {
      Array.prototype.forEach.call(dom.subsystems.children, function (li) {
        li.classList.toggle('active', li.dataset.subsystem === boundSubsystem)
      })
    }
  }

  // ── UI glue ───────────────────────────────────────────────────────────────
  function say(text) {
    if (dom.note) dom.note.textContent = text
  }

  function renderSubsystemList(models) {
    if (!dom.subsystems) return
    dom.subsystems.innerHTML = ''
    SUBSYSTEMS.forEach(function (s) {
      var li = document.createElement('li')
      li.dataset.subsystem = s.id
      li.innerHTML = '<strong>' + s.label + '</strong><span>' + s.note + '</span>'
      li.addEventListener('click', function () { highlight(s.id) })
      dom.subsystems.appendChild(li)
    })
    if (dom.models) {
      dom.models.innerHTML = ''
      models.forEach(function (m) {
        var b = document.createElement('button')
        b.type = 'button'
        b.className = 'armour-model-btn'
        b.textContent = m.name + ' (' + Math.round((m.bytes || 0) / 1024) + ' KB)'
        b.addEventListener('click', function () { loadModel(m.name) })
        dom.models.appendChild(b)
      })
      if (!models.length) {
        var hint = document.createElement('p')
        hint.className = 'armour-hint'
        hint.textContent = 'artifacts/3d me koi .glb/.gltf nahi hai - abhi placeholder geometry dikh rahi hai.'
        dom.models.appendChild(hint)
      }
    }
    if (dom.source) {
      dom.source.textContent = state.modelSource === 'file'
        ? 'Model: ' + state.modelName + ' (real file)'
        : 'Placeholder geometry - koi model file load nahi hui'
    }
  }

  function cacheDom() {
    dom.stage = document.getElementById('armour-stage')
    dom.subsystems = document.getElementById('armour-subsystems')
    dom.models = document.getElementById('armour-models')
    dom.note = document.getElementById('armour-note')
    dom.source = document.getElementById('armour-source')
    dom.gesture = document.getElementById('armour-gesture')
    dom.blueprintBtn = document.getElementById('armour-blueprint')
    dom.resetBtn = document.getElementById('armour-reset')
  }

  function wireButtons() {
    if (dom.blueprintBtn && !dom.blueprintBtn.dataset.wired) {
      dom.blueprintBtn.dataset.wired = '1'
      dom.blueprintBtn.addEventListener('click', function () {
        if (!lib) return
        state.blueprint = !state.blueprint
        applyBlueprint()
      })
    }
    if (dom.resetBtn && !dom.resetBtn.dataset.wired) {
      dom.resetBtn.dataset.wired = '1'
      dom.resetBtn.addEventListener('click', function () {
        if (!lib) return
        camera.position.set(2.4, 1.6, 3.2)
        controls.target.set(0, 1.15, 0)
        controls.update()
      })
    }
  }

  function open() {
    cacheDom()
    if (!lib) {
      loadBundle(function () { wireButtons(); renderSubsystemList(); resize(); open() })
      return
    }
    wireButtons()
    state.active = true
    fetchModels(function (models) {
      renderSubsystemList(models)
      // Auto-load the first real model when one exists, so opening the view
      // shows the user's asset rather than the placeholder.
      if (models.length && state.modelSource !== 'file') loadModel(models[0].name)
    })
    paintGesture()
    resize()
  }

  function close() {
    state.active = false
    renderOnce()
  }

  function init() {
    cacheDom()
    wireButtons()
    paintGesture()
  }

  window.__JARVIS_ARMOUR__ = {
    init: init,
    open: open,
    close: close,
    onView: function (isArmour) { isArmour ? open() : close() },
    toggleBlueprint: function () {
      if (!lib) return
      state.blueprint = !state.blueprint
      applyBlueprint()
    },
    loadModel: loadModel,
    state: function () {
      return {
        ready: !!lib,
        active: state.active,
        blueprint: state.blueprint,
        modelName: state.modelName,
        modelSource: state.modelSource,
        gesture: state.gesture,
        subsystem: boundSubsystem,
        lastError: state.lastError
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()