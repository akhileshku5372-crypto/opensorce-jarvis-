# Installs voice prerequisites without touching your keys, memories or podcasts.
# -Full additionally installs the existing KamiSensei dependency set.
# -LocalSTT downloads/installs faster-whisper (recommended without a Groq key).
param([switch]$Full, [switch]$LocalSTT)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Invoke-Checked([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed (exit $LASTEXITCODE). Fix the error above, then rerun setup." }
}
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js 22 LTS (22.12+) from https://nodejs.org, then reopen PowerShell.' }
Invoke-Checked 'node' @('-e', 'const [a,b]=process.versions.node.split(".").map(Number); if(!((a===20&&b>=19)||(a===22&&b>=12)||a>22)) process.exit(1)')
$python = & node run_py.cjs --resolve
if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.12 x64 from python.org with Tcl/Tk and the Python launcher enabled; reopen PowerShell.' }
$python = ($python | Select-Object -Last 1).Trim()
# Keep an existing installation by default; an explicit JARVIS_PYTHON override wins.
# No new virtualenv is forced onto the untouched podcast/Kokoro services.
Invoke-Checked $python @('-m', 'pip', 'install', '--disable-pip-version-check', 'requests>=2.32', 'python-dotenv>=1.0', 'numpy>=1.26', 'sounddevice>=0.4.6', 'edge-tts>=7.0', 'psutil>=5.9')
if ($Full) { Invoke-Checked $python @('-m', 'pip', 'install', '-r', 'requirements.txt') }
elseif ($LocalSTT) { Invoke-Checked $python @('-m', 'pip', 'install', 'faster-whisper>=1.0') }
Invoke-Checked $python @('-c', 'import requests, dotenv, numpy, sounddevice, edge_tts, tkinter')
foreach ($file in @('.env', '.dev.vars')) {
    if (-not (Test-Path $file)) {
        Copy-Item '.env.example' $file
        Write-Host "Created $file (blank keys). Existing key files were not overwritten."
    }
}
Invoke-Checked 'npm' @('install')
Invoke-Checked 'npm' @('run', 'test:browser')
Invoke-Checked 'npm' @('run', 'test:bridge')
Invoke-Checked 'node' @('run_py.cjs', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_core.py')
Invoke-Checked 'npm' @('run', 'build')
if (-not (Get-Command pm2 -ErrorAction SilentlyContinue)) { Invoke-Checked 'npm' @('install', '--global', 'pm2') }
Write-Host ''
Write-Host 'Setup complete. Add your fresh GOOGLE_API_KEY to .env (and .dev.vars for dashboard/KamiSensei APIs).'
Write-Host 'For speech-to-text: add GROQ_API_KEY OR rerun setup with -LocalSTT.'
Write-Host 'Edge TTS needs internet, NOT an API key. ElevenLabs is optional and off by default.'
Write-Host 'Next: npm run jarvis     Diagnostics: npm run jarvis:doctor'
Write-Host 'Existing podcast/Kokoro services were not stopped or changed.'
