"""
Unit Tests for KamiSensei Ingestion & Vector Service
===================================================
Tests automated directory creation, ChromaDB collection initialization,
empty folder graceful alert, text extraction, chunking, and querying.
"""

import os
import sys
import tempfile
import unittest
from pathlib import Path

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from backend.services.ingestion import KamiSenseiIngestionService, KNOWLEDGE_BASE_DIR, CHROMA_DB_DIR


class TestKamiSenseiService(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.test_dir = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        cls.test_path = Path(cls.test_dir.name)
        cls.knowledge_dir = cls.test_path / "knowledge_base"
        cls.chroma_dir = cls.test_path / "chroma_db"
        cls.service = KamiSenseiIngestionService(
            knowledge_dir=cls.knowledge_dir,
            chroma_dir=cls.chroma_dir,
            collection_name="test_kami_knowledge"
        )

    @classmethod
    def tearDownClass(cls):
        try:
            cls.test_dir.cleanup()
        except Exception:
            pass

    def test_directory_creation(self):
        """Verify directories are automatically created without user intervention."""
        self.assertTrue(self.knowledge_dir.exists())
        self.assertTrue(self.chroma_dir.exists())
        self.assertTrue(KNOWLEDGE_BASE_DIR.exists())
        self.assertTrue(CHROMA_DB_DIR.exists())

    def test_empty_knowledge_base_alert(self):
        """Verify status when knowledge base is empty."""
        status = self.service.check_knowledge_base()
        self.assertTrue(status["is_empty"])
        self.assertEqual(status["files_count"], 0)
        self.assertTrue(status["db_connected"])

    def test_text_chunking(self):
        """Verify chunking mechanism produces expected overlapping chunks."""
        text = "Japanese grammar lesson 1. " * 30
        chunks = self.service.chunk_text(text, chunk_size=200, overlap=50)
        self.assertGreater(len(chunks), 1)
        for chunk in chunks:
            self.assertLessEqual(len(chunk), 200)

    def test_file_ingestion_and_query(self):
        """Verify adding a text/markdown study document ingests and queries properly."""
        sample_file = self.knowledge_dir / "sample_japanese_n5.md"
        sample_file.write_text(
            "# Japanese N5 Essentials\n\n"
            "Arigatou gozaimasu (ありがとうございます) means 'Thank you very much'.\n"
            "Konnichiwa (こんにちは) means 'Good afternoon'.\n"
            "Sensei (先生) is an honorific term for teacher or master.\n",
            encoding="utf-8"
        )

        files = self.service.list_knowledge_files()
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0]["name"], "sample_japanese_n5.md")

        ingest_result = self.service.ingest_all(force_reindex=True)
        self.assertTrue(ingest_result["ok"])
        self.assertEqual(ingest_result["ingested_files"], 1)
        self.assertGreater(ingest_result["ingested_chunks"], 0)

        # Query vector database
        matches = self.service.query("What does sensei mean?", top_k=2)
        self.assertIsInstance(matches, list)
        if matches:
            self.assertIn("sample_japanese_n5.md", matches[0]["metadata"]["source"])

    def test_multi_source_dynamic_global_query(self):
        """Dynamic multi-source engine: with NO source filter the query must
        search ALL indexed books globally and extract the exact 'source'
        string from every matched chunk's metadata."""
        # Second book added AFTER the first one was already indexed.
        second_book = self.knowledge_dir / "genki_i_te_form.md"
        second_book.write_text(
            "# Genki I: Te-form\n\n"
            "The te-form is created by dropping the final -masu and adding -te.\n"
            "Tabemasu becomes tabete. Nomimasu becomes nonde. Yomimasu becomes yonde.\n"
            "The te-form is used for requests, progressive actions, and linking clauses.\n",
            encoding="utf-8"
        )

        ingest_result = self.service.ingest_all(force_reindex=True)
        self.assertTrue(ingest_result["ok"])
        self.assertEqual(ingest_result["ingested_files"], 2)
        self.assertGreaterEqual(ingest_result["total_collection_count"], 2)

        # Global query: no source allowlist -> open semantic search across ALL books
        matches = self.service.query("How do I form the te-form of a verb?", top_k=6)
        self.assertIsInstance(matches, list)
        self.assertGreater(len(matches), 0)

        for m in matches:
            # Exact 'source' string must be extracted from the metadata array
            self.assertIsInstance(m["metadata"]["source"], str)
            self.assertTrue(m["metadata"]["source"])
            self.assertIsInstance(m["metadata"]["page"], int)
            # Normalized top-level fields for downstream controllers
            self.assertEqual(m["source"], m["metadata"]["source"])
            self.assertEqual(m["source_tag"], f"[Source: {m['source']}, Page {m['page']}]")

        matched_sources = {m["source"] for m in matches}
        # Both books are active in the store; the semantic te-form hit must come
        # from Genki, proving retrieval is not pinned to a single hardcoded file.
        self.assertIn("genki_i_te_form.md", matched_sources)

        # Explicit multi-source allowlist still works and falls back gracefully
        filtered = self.service.query("te-form", top_k=6, sources=["genki_i_te_form.md"])
        self.assertTrue(all(m["source"] == "genki_i_te_form.md" for m in filtered))
        # A non-existent selected source must stay empty. Falling back globally
        # would violate the user's explicit source boundary.
        fallback = self.service.query("te-form", top_k=6, sources=["does_not_exist.pdf"])
        self.assertEqual(fallback, [])

    def test_page_extractor_service(self):
        """Verify direct 3-page sequential extraction for explicit page queries."""
        from backend.services.page_extractor import PageExtractorService
        extractor = PageExtractorService(knowledge_dir=self.knowledge_dir)

        # 1. Query detection
        self.assertEqual(extractor.detect_page_query("Explain page 45 of Minna no Nihongo"), 45)
        self.assertEqual(extractor.detect_page_query("Check p. 110 grammar"), 110)
        self.assertEqual(extractor.detect_page_query("What is in lesson 14?"), 110) # Lesson 14 starts p.110
        self.assertIsNone(extractor.detect_page_query("General question without page"))

        # 2. Build a real temporary PDF so the extractor proves that it returns
        # source text rather than the old synthetic textbook fallback.
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        pdf_path = self.knowledge_dir / "page_reference.pdf"
        document = fitz.open()
        for page_number in range(1, 48):
            page = document.new_page()
            if page_number >= 45:
                page.insert_text(
                    (72, 72),
                    f"Page {page_number} verified Japanese grammar reference. "
                    "This paragraph is extracted directly from the temporary source PDF. "
                    "Particles, verb forms, examples, and explanations remain tied to this page.",
                    fontsize=10,
                )
        document.save(pdf_path)
        document.close()

        res = extractor.get_page_context("Explain the grammar on Page 45", source_hint=pdf_path.name)
        self.assertIsNotNone(res)
        self.assertTrue(res["ok"])
        self.assertEqual(res["start_page"], 45)
        self.assertEqual(res["pages_extracted"], [45, 46, 47])
        self.assertIn("Pages 45-47", res["source_tag"])
        self.assertGreater(len(res["text"]), 200)
        self.assertIn("temporary source PDF", res["text"])

        # 3. Query routing interception in ingestion service
        matches = self.service.query("Explain grammar on page 45", top_k=4, sources=[pdf_path.name])
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["page"], 45)
        self.assertIn("Pages 45-47", matches[0]["source_tag"])


if __name__ == "__main__":
    unittest.main()
