# Analysis: `leo007-htun/full_duplex_assistant` — can JARVIS use it?

**Date:** 2026-10-17 · **Cloned to:** `scratch/ref/full_duplex_assistant` (gitignored, 230 MB incl. demo video)
**Method:** read the code, not the README. Every claim below has a file/line reference.

## Verdict up front

**Do not adopt it.** Its "full duplex" is not a duplex engine — it is a browser tab
holding a WebSocket to **OpenAI's paid Realtime API**. JARVIS has no `OPENAI_API_KEY`
anywhere in `.dev.vars`/`.env` (checked: GROQ, OPENROUTER, GOOGLE×2, NVIDIA, XKIRO,
FIRECRAWL, GITHUB, WEATHER only), so adopting it means buying OpenAI credits, and it
would replace the desktop assistant with a web page.

**But three pieces of it are worth taking into JARVIS** — listed in §4, and they are the
pieces JARVIS is actually missing.

## 1. What the repo really is

| Component | Reality |
|---|---|
| `src/assistant/app.py` (140 LOC) | FastAPI shim. Endpoints: `/healthz`, `/metrics`, `/api/metrics`, **`/rt-token`** — and `/rt-token` POSTs to `https://api.openai.com/v1/realtime/sessions` with `{"model": "gpt-4o-mini-realtime-preview", "voice": "alloy"}` and returns an **ephemeral token to the browser** |
| `src/assistant/core/conversation.py` (46 LOC) | Plain `gpt-4o-mini` chat wrapper. `stream=False`. Hardcoded `session_id="ABC123"`. History trimmed to 42 messages, no persistence |
| `web/script.js` (1,200 LOC) | **This is the whole product**: `getUserMedia` in the browser → `wss://api.openai.com/v1/realtime` (1 match) → `server_vad` + `turn_detection` + `interrupt` handling. No `RTCPeerConnection` (plain WS) |
| `src/assistant/voice/mic_stream.py`, `tts_player.py` | Real desktop audio code (pyaudio + sounddevice)… **imported by nothing**. Verified: grep across `src`, `web`, `sdk-js` for `mic_stream|tts_player` outside its own folder returns zero. Dead path |
| `sdk-js/` | Browser SDK; contains no realtime/vad/interrupt logic |
| `requirements.txt` | `fastapi, uvicorn, httpx, openai, prometheus-client, psutil` — **no local STT, no local TTS, no VAD library, no model** |
| `tests/` | `tests/performance/` only (668 LOC). Zero functional tests of the voice loop |
| Health | 6 stars, 3 forks, 300 commits, created 2025-09-01, **last push 2025-11-15 (~11 months stale)**, 0 open issues, single author. MIT license |
| Languages | `language` appears **0 times** in `web/script.js`. Voice is `alloy`/`nova` (American). No Hindi, no Hinglish, no Japanese handling anywhere |

So the README's "full-duplex, barge-in, streaming ASR/TTS" is **borrowed from OpenAI's
Realtime API**, not implemented in this repo. That API is genuinely good — it is the same
class of engine as Gemini Live — but it is **paid**, and it is Google/OpenAI's cloud, not
this code.

## 2. Why it does not fit JARVIS

1. **Cost + no key.** `gpt-4o-mini-realtime-preview` and `gpt-4o-mini-tts` are metered
   OpenAI endpoints. You have neither an OpenAI key nor a budget line for per-minute audio.
2. **Wrong shape.** The microphone lives in a browser tab, so the assistant dies when the
   tab closes. JARVIS's whole design (AGENTS.md: one canonical voice runtime in
   `background/voice_engine.py`, HUD as a visual client of it) forbids a second mic pipeline.
   Adopting this = a second brain/mic, which is exactly what your rules prohibit.
3. **No Hindi/Hinglish/Japanese work** — your 4-language requirement is untouched here.
4. **Over-built around the edges, under-built in the middle.** Docker Compose + nginx +
   Prometheus + Grafana dashboards + alertmanager for a personal laptop assistant, while
   conversation memory is a hardcoded `"ABC123"` and there are no functional tests.
5. **Stale.** 11 months without a push, one maintainer.

## 3. What JARVIS already has that this repo does not

ChromaDB long-term memory, 4-language gating, wake word (openwakeword), Silero VAD, a
Windows action bridge with allowlist + confirmation gates, a HUD, memory protocol, model
catalog with key rotation. This repo has none of that — its LLM layer is one chat call.

## 4. The three things worth taking

### (a) Queue-and-flush streaming playback — `src/assistant/voice/tts_player.py`
49 lines, the best file in the repo. A consumer thread reads a byte queue and writes PCM
to a 24 kHz `sounddevice.OutputStream`; a `_stop_flag` **and a queue drain** stop speech
mid-sentence. JARVIS's `speak()` today synthesises the *entire* reply to a temp file and
hands it to ffplay/MCI, so barge-in means `proc.kill()` on a finished file — the reason
interruption feels dead. This is the shape Gemini Live's 24 kHz PCM stream needs, and
24 kHz is exactly the rate the Live probe returned (`mime:audio/pcm;rate=24000`).
**Take the pattern, not the dependency** (`sounddevice` is already installed; `pyaudio`
is not needed).

### (b) Interruption protocol — `web/script.js` `turn_detection` / `server_vad` / `interrupt`
The client reacts to a server-side VAD interrupt by dropping what it is playing. Gemini
Live has the identical contract — `realtimeInputConfig.automaticActivityDetection` and
`server_content.interrupted = true`, with the documented instruction to *discard your
client audio buffer immediately*. So this repo is a usable reference for the client half
of the barge-in handshake you are about to implement against Gemini Live.

### (c) The latency harness — `analyze_latency.py`, `web/latency_tracker.js`,
`docs/performance_metrics_design.md`
JARVIS has **no per-stage timing today** — which is precisely why "2 minute" could only be
answered by reading logs by hand and running a socket experiment. You do not need Prometheus
for this; you need the same idea (wake → STT → brain → first byte of TTS → playback start,
stamped per turn) written into `/state`. That is what turns the next complaint into a
measurement.

## 5. Recommendation

- **Skip the repo as a base.** Its engine is OpenAI Realtime (paid, no key, browser-bound)
  and its desktop audio path is dead code.
- **Connect JARVIS to Gemini Live instead.** Same class of duplex engine, already proven
  working on your existing free `GOOGLE_API_KEY` on 2026-10-17 (`gemini-3.8-live` returned
  6.7s of native 24 kHz PCM; `gemini-3.1-flash-live-preview` 10.2s), and it is the engine
  that ships the 99-language + auto-code-switch behaviour your Hindi/Hinglish/Japanese
  requirement needs. See `2026-10-16-jarvis-voice-design.md` §6.
- **Take (a), (b), (c) from this repo** into that work: streaming playback with a flushable
  queue, a real interrupted-event handshake, and per-stage latency stamps.

## 6. Clean-up note

`scratch/ref/full_duplex_assistant` is 230 MB (a 114 MB demo video dominates it) and is
inside the gitignored `scratch/` tree. Delete with
`rm -rf scratch/ref/full_duplex_assistant` once the three ideas above are implemented.
