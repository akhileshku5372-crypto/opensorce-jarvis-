"""Focus Analytics: real foreground-window / app usage accounting.

Backs the "Focus Analytics" catalog card with measured data only.

How it works, honestly:
  * A single background sampler thread polls the REAL foreground window title
    and process name through the Win32 API via ctypes (no extra dependency).
  * Each observation is bucketed by (process, normalised title); time is
    credited to the bucket that was actually in the foreground.
  * If the Win32 probe is unavailable (non-Windows, locked session) the card
    reports itself unavailable instead of returning fabricated numbers. That
    is the whole point of this module.

Nothing here reads keystrokes or window text beyond the title already on
screen, and nothing leaves the machine.
"""
from __future__ import annotations

import ctypes
import re
import threading
import time
from collections import defaultdict

_lock = threading.RLock()
_samples = 0
_seconds_tracked = 0.0
_buckets = defaultdict(float)     # "proc | title" -> seconds
_history = []                      # recent transitions (append-only, bounded)
_started_at = time.time()
_INTERVAL = 5.0
_MAX_HISTORY = 400
_STOP = threading.Event()
_thread = None

# Browser noise that would otherwise pollute the report.
_TITLE_NOISE = re.compile(
    r"[-—|]\s*(Microsoft Edge|Google Chrome|Edge|Chrome)\b.*$", re.I)


def _win32():
    """Real foreground window probe. None when it is not available."""
    if not hasattr(ctypes, "windll"):
        return None
    try:
        return getattr(ctypes.windll, "user32", None)
    except Exception:
        return None


def _window_text(user32) -> tuple:
    """(process_name, window_title) for the real foreground window."""
    if not user32:
        return "", ""
    handle = user32.GetForegroundWindow()
    if not handle:
        return "", ""
    length = user32.GetWindowTextLengthW(handle)
    title = ""
    if length > 0:
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(handle, buf, length + 1)
        title = buf.value or ""
    pid = ctypes.c_ulong(0)
    user32.GetWindowThreadProcessId(handle, ctypes.byref(pid))
    try:
        import psutil  # type: ignore
        name = psutil.Process(pid.value).name()
    except Exception:
        name = "pid-%s" % pid.value
    return name, _TITLE_NOISE.sub("", title).strip()[:120]


def available() -> bool:
    user32 = _win32()
    if user32 is None:
        return False
    try:
        return bool(user32.GetForegroundWindow() or user32.GetDesktopWindow())
    except Exception:
        return False


def _bucket_of(name: str, title: str) -> str:
    if not name and not title:
        return "unknown"
    return "%s | %s" % (name or "?", title or "(no title)")


def _observe() -> None:
    """One real sample. Runs only on the sampler thread."""
    global _samples, _seconds_tracked
    user32 = _win32()
    if user32 is None:
        return
    try:
        name, title = _window_text(user32)
    except Exception:
        return
    bucket = _bucket_of(name, title)
    with _lock:
        _samples += 1
        _seconds_tracked += _INTERVAL
        _buckets[bucket] += _INTERVAL
        if _history and _history[-1]["bucket"] == bucket:
            _history[-1]["seconds"] += _INTERVAL
        else:
            _history.append({"bucket": bucket, "at": time.time(),
                             "seconds": _INTERVAL})
            del _history[:-_MAX_HISTORY]


def start(interval: float = 5.0) -> dict:
    """Start the sampler. Idempotent - never spawns a second thread."""
    global _thread, _INTERVAL, _started_at
    with _lock:
        if _thread is not None and _thread.is_alive():
            return {"ok": True, "already_running": True}
        _INTERVAL = max(1.0, float(interval or 5.0))
        _started_at = time.time()
    _STOP.clear()
    thread = threading.Thread(target=_loop, name="jarvis-focus", daemon=True)
    thread.start()
    with _lock:
        _thread = thread
    return {"ok": True, "already_running": False, "interval_s": _INTERVAL}


def _loop() -> None:
    while not _STOP.is_set():
        _observe()
        _STOP.wait(_INTERVAL)


def stop() -> dict:
    global _thread
    _STOP.set()
    with _lock:
        thread = _thread
        _thread = None
    if thread is not None:
        thread.join(timeout=2.0)
    return {"ok": True}


def reset() -> dict:
    """Clear the measured window. Explicitly user-driven, never automatic."""
    global _samples, _seconds_tracked, _started_at
    with _lock:
        _buckets.clear()
        _history.clear()
        _samples = 0
        _seconds_tracked = 0.0
        _started_at = time.time()
    return {"ok": True, "source": "local"}


def snapshot(limit: int = 12) -> dict:
    """Real measured usage. `available: False` when there is nothing to say."""
    if not available():
        return {"ok": False, "source": "local", "available": False,
                "reason": "foreground window is not observable on this platform",
                "apps": [], "total_seconds": 0.0, "tracked_seconds": 0}
    with _lock:
        rows = sorted(_buckets.items(), key=lambda kv: kv[1], reverse=True)
        total = float(_seconds_tracked)
        history = list(_history[-40:])
        samples = int(_samples)
        since = _started_at
    apps = []
    for bucket, seconds in rows[:max(1, min(40, int(limit or 12)))]:
        proc, _, title = bucket.partition(" | ")
        apps.append({"process": proc, "title": title, "seconds": round(seconds),
                     "percent": round(seconds / total * 100.0, 1) if total else 0.0})
    return {"ok": True, "source": "local", "available": True, "reason": "",
            "tracked_seconds": round(total), "tracked_since": since,
            "samples": samples, "session_seconds": int(time.time() - since),
            "total_seconds": total, "apps": apps, "history": history}


def _tool_focus(args: dict) -> dict:
    limit = 12
    try:
        limit = int((args or {}).get("limit") or 12)
    except (TypeError, ValueError):
        pass
    snap = snapshot(limit)
    if not snap.get("available"):
        return {"ok": False, "output": snap.get("reason") or "focus analytics unavailable"}
    if not snap.get("apps"):
        return {"ok": True, "output": ("Sir, focus analytics is tracking but no "
                                       "window time is recorded yet."),
                "data": snap}
    top = snap["apps"][0]
    return {"ok": True,
            "output": "Sir, most time in %s at %s percent of tracked window time."
                      % (top["process"], top["percent"]),
            "data": snap}


def _tool_focus_start(args: dict) -> dict:
    return {"ok": True, "output": "Sir, focus analytics started.",
            "data": start(float((args or {}).get("interval") or 5.0))}


def _tool_focus_reset(args: dict) -> dict:
    return {"ok": True, "output": "Sir, focus history cleared.", "data": reset()}


def specs() -> list:
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("focus_analytics",
                        "Real measured foreground-app usage and screen time.",
                        _tool_focus, parameters={"limit": "how many apps (1-40)"},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("focus", "telemetry")),
        cortex.ToolSpec("focus_analytics_start",
                        "Start the foreground-window sampler.",
                        _tool_focus_start, parameters={"interval": "seconds (>=1)"},
                        requires_confirmation=False, timeout_s=10.0,
                        tags=("focus", "telemetry")),
        cortex.ToolSpec("focus_analytics_reset",
                        "Clear the measured focus window.",
                        _tool_focus_reset, parameters={},
                        requires_confirmation=True, timeout_s=10.0,
                        tags=("focus", "telemetry")),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    from pathlib import Path
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()

