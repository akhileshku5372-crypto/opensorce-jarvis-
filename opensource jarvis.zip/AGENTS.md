# OpenCode / Coding Agent Instructions

Continue this repository; do not rebuild JARVIS from scratch.

## Behavioral guidelines (Karpathy-inspired)
These rules govern HOW you work here. They bias toward caution over speed; for
trivial one-liners use judgment, but for anything non-trivial follow them.

### 1. Think before coding
- State assumptions explicitly. If uncertain, ask instead of guessing.
- If several interpretations exist, present them — do not pick silently.
- Push back when a simpler approach exists. Name what is confusing and stop.
### 2. Simplicity first
- Minimum code that solves the problem. Nothing speculative.
- No abstractions, flexibility, or config that was not requested.
- "Could a senior engineer call this overcomplicated?" If yes, simplify.
### 3. Surgical changes
- Touch only what the request requires. Do not refactor adjacent code or
  reformat unrelated lines. Match existing style even if you would differ.
- Remove only orphans YOUR change created; mention pre-existing dead code, do
  not delete it.
- Every changed line must trace back to the user's request.
### 4. Goal-driven execution
- Convert requests into verifiable goals before coding.
- "Fix the bug" → write a failing test that reproduces it → make it pass →
  prove no regressions.
- For multi-step work, state the plan as `step → verify: check`.
- Reuse this repo's real validation gates; do not invent new ones:
  `npm run test:bridge`, `node --check public/static/app.js`, `npm run build`,
  and the Python suite.
- Run Python tests through the SAME interpreter JARVIS runs under:
  `node run_py.cjs --resolve` prints it (normally `.venv\Scripts\python.exe`).
  A bare `python -m unittest ...` can silently pick a different interpreter that
  lacks `chromadb`, which makes the memory tests fail with
  `memory_store_unavailable` even though the store is healthy. That is a test
  harness artifact, not a product bug - confirm the interpreter before
  "fixing" anything in `conversation_memory.py`.

## Goal
Maintain one voice-first JARVIS runtime with a minimal dashboard, embedded scrollable conversation, a server-side AI proxy, and a loopback-only Windows action bridge.

## Required environment
- Windows 10/11
- Node.js 20 or newer and npm
- Chrome or Edge for Web Speech APIs
- Microphone permission; camera permission only for vision/gesture
- PM2 (the setup script installs it when missing)
- Fresh provider keys in `.dev.vars`; never expose them in `public/` or commit them

## First run
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-windows.ps1
```
Open http://127.0.0.1:7777 after both PM2 apps report online.

## Validation after every change
```powershell
npm run test:bridge
node --check public/static/app.js
npm run build
```
The full suite is `npm test`; the Modules matrix alone is `npm run test:modules`.

## Capability matrix (Modules & Upgrades)
- `background/capability_registry.py` is the single source of truth for the Modules page. Every one of the 52 catalog cards is probed against the live subsystems and reports exactly one of:
  - **LIVE** - the backing code path exists and is reachable right now
  - **READY** - the code exists but needs a runtime precondition you control (a key, a permission flip, an installed binary)
  - **BLOCKED** - it cannot work here, and the card names exactly what is missing
- The roadmap `phase` label is metadata, never a claim. A `DREAM` card must never report LIVE.
- Never reintroduce a hardcoded "capability scheduled" card or a click handler that only shows a toast. A card that cannot be probed must say why, not that it is "coming soon".
- Probes reuse `extensions._tool_list()` (already TTL-cached). Do not call `build_default_registry()` per probe; the MCP handshake makes that far too slow.

## Architecture constraints
- `src/index.tsx`: Hono UI and server-side AI API only.
- `public/static/app.js`: browser state, chat, voice, camera, and client intent routing.
- `local-bridge/server.cjs`: canonical OS action router; loopback only; allowlisted actions only.
- Never pass arbitrary input to CMD, PowerShell, shell mode, executable paths, or filesystem paths.
- Require confirmation before adding destructive actions.
- Keep duplicate-action suppression and TTS URL sanitization.
- Preserve the existing MediaPipe hand landmark implementation.
- Unknown commands may go to the AI, but AI output must never be executed as shell code.
- Keep the main dashboard laptop-sized and put advanced modules behind sidebar views.
- Treat `background/floating_ui.pyw` as the existing production HUD; repair and extend it instead of creating another overlay.
- The HUD must remain a visual client of `background/jarvis_core.py`; never add another microphone, assistant, memory, or tool pipeline.
- Preserve the reference composition: left reactor orb, right dark-glass conversation panel, cyan edge light, real runtime states, scrollable real history, and no fake demo turns.
- Panel minimize must enter orb-only mode. It must never hide every restore affordance; the reactor chevron restores the panel.

## New local modules (all additive, no new API keys)
| Module | Backs | Honesty rule |
|---|---|---|
| `background/telemetry.py` | Battery & Telemetry | battery is `unavailable` with a reason when the platform reports none; never a fake percentage |
| `background/scheduler_core.py` | Scheduler Core, Automation Studio, Command Composer | stores command strings only and re-submits them through `submit_command`; it never executes anything itself |
| `background/focus_analytics.py` | Focus Analytics | single sampler thread; reports `available: false` where the foreground window is not observable |
| `background/ocr_engine.py` | OCR Everywhere | digital PDF via PyMuPDF; scanned/screen paths need Tesseract and say so |
| `background/video_editor.py` | Video Auto-Editor AI | ffmpeg silence cut + faster-whisper captions + the existing perception model for scene labels |
| `background/doc_index.py` | Document Parliament, RAG search | only real files from the Desktop/Documents allowlist (or a folder the user names) are scanned; a scanned PDF with no text layer reports `no_text` with the reason, never "indexed"; re-index is incremental and a changed file's stale chunks are deleted, so a citation can never show old text |
| `background/dpapi_store.py` | token storage for Gmail/Calendar | Windows DPAPI only, and there is NO plaintext fallback: if pywin32 is missing a save fails loudly instead of writing a readable secret; an undecryptable token reports "re-authorize" instead of pretending the account is new |
| `background/calendar_ics.py` | Calendar Agenda (Phase 4, free path) | a calendar is read through its **private iCal feed** - no OAuth client, no cloud console, no billing, no bank account. Read-only by construction (no create/update/delete path). The feed URL is a bearer secret, so it is stored through `dpapi_store` (DPAPI) and never in clear text; no feed configured is reported as "not connected", never as "0 events" |
| `background/armour_assets.py` | Armour Studio 3D | lists only real `.glb/.gltf` files with their real sizes; an empty folder is reported as empty and the viewport renders labelled placeholder geometry - never a bundled "sample" pretending to be a model; `resolve()` refuses separators, drive letters and traversal, then re-checks the path really sits inside the model folder |
| `background/data_forge.py` | Data Forge (Phase 6.2) | a requested format is never silently downgraded: parquet without DuckDB fails with the install hint; nothing runs at import time (an import-seeded dataset used to manufacture evidence for the card); `telemetry_dataset()` stores the machine's real numbers only; SQL is restricted to SELECT/WITH |
- Exercise angles are `[a, VERTEX, b]` - the angle is measured AT the middle index. Getting this wrong measures the wrong joint (a push-up counted at the shoulder), which is why `tests/test_fight_coach.cjs` builds landmarks deliberately. `depth` must be TIGHTER than `downBelow`, otherwise the depth hint can never fire.
- The fight coach reuses `video.camera-feed` (already fed from the single stream) and never calls `getUserMedia` itself. Reps come only from measured landmark angles: no landmarks means no rep, and low visibility pauses counting.
- The Gmail/OAuth integration was REMOVED by owner request (the Google Cloud console path was unwanted). Do not reintroduce `gmail_client.py`, `oauth_bridge.py`, the `gmail-reader` card, `/gmail/*` routes or any `gmail_*` tool without being asked again. `tests/test_calendar_ics.py` asserts they stay gone.
- The calendar ICS reader expands only simple DAILY/WEEKLY/MONTHLY RRULEs, and deliberately appends each occurrence BEFORE advancing - the other order silently drops the original occurrence, so a daily standup looks like it starts tomorrow. Floating DTSTART values (no TZID, no `Z`) are local time; an unknown TZID is reported, never guessed.
- Phase 5 ships `public/static/armour-bundle.js`, a SEPARATE three.js + GLTFLoader bundle built by `node scripts/build-armour-bundle.cjs`. Do not regenerate `three-bundle.min.js` - that artifact backs the working brain hologram and has no build script; the armour bundle is fetched lazily, only when the Armour view opens.
- The armour viewer consumes `window.__JARVIS_HANDS__`, the landmarks the existing camera pipeline already publishes. It must never call `getUserMedia` or construct its own MediaPipe instance: one camera, one tracker.
- Code Red is a visual + alertness state (`STATE["battle_mode"]` -> `data-theme="codered"`). It must never close applications or touch power; those stay behind the confirm gate. The voice route says so out loud instead of implying otherwise.
- Phase 4 pairing is a two-step owner action (consent screen, then hand the code to `gmail_connect`/`calendar_connect`). Both connect tools are double-gated: `communication` category + `requires_confirmation`. The voice route never pairs an account on its own.
- `extensions/plugins/jarvis-modules/` exposes these through the real ToolRegistry and the real permission engine. Do not add a second registry.
- `scheduler_core._dispatch` must resolve the live engine from `__main__`; importing a second `voice_engine` would create a second brain/mic/memory and is forbidden.
- Both gates apply independently to a plugin tool: the cortex confirm gate AND the permission category. One user confirmation satisfies both - the confirm gate calls `permissions.grant_approval(tool)` and the plugin wrapper consumes it with `take_approval()`. The record is keyed by exact tool name, single-use, and expires after 120s. A `deny` in `permissions.json` must still win even after the user approves, because `check()` ignores `approved` when the decision is DENY.
- Resolve `background/permissions.py` through the shared `jarvis_cowork_permissions` key. A plain `import permissions` creates a SECOND module instance with its own approval ledger, and the two gates silently stop correlating.



## Secrets
`.env` and `.dev.vars` are intentionally ignored. If either is absent, copy `.env.example` and insert fresh keys. Any credential previously pasted into chat should be rotated.
