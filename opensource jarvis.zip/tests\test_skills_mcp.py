"""Skills + MCP wiring (single pipeline, one assistant).

Stdlib only — no mic, no TTS, no network except the loopback MCP stdio servers
JARVIS itself spawns from its own on-device config.
"""
import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = ROOT / "background"


def _load(name):
    spec = importlib.util.spec_from_file_location(name, BACKGROUND / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


SKILLS = _load("skill_loader")
MCP = _load("mcp_client")
BROWSER = _load("browser_agent")


class SkillLoaderTest(unittest.TestCase):
    def test_two_seed_skills_load(self):
        loaded = {s["name"] for s in SKILLS.load()}
        # The seed skills must always load; the directory is user-extensible,
        # so extra skills (e.g. careful-work) are legitimate, not failures.
        self.assertTrue({"meeting-notes", "daily-briefing"} <= loaded, loaded)

    def test_describe_mentions_both(self):
        text = SKILLS.describe().lower()
        self.assertIn("meeting-notes", text)
        self.assertIn("daily-briefing", text)

    def test_match_trigger(self):
        hits = [s["name"] for s in SKILLS.match("subah ki briefing de do")]
        self.assertEqual(hits, ["daily-briefing"])

    def test_no_false_trigger(self):
        self.assertEqual(SKILLS.match("volume up karo"), [])

    def test_context_injects_matched_body_only(self):
        text = SKILLS.context_for("meeting notes banao kal wali")
        self.assertIn("meeting-notes", text)
        self.assertIn("Action items", text)
        other = SKILLS.context_for("volume up karo")
        self.assertIn("meeting-notes", other)     # catalog always present
        self.assertNotIn("Action items", other)   # body only when matched

    def test_revision_is_stable_token(self):
        self.assertEqual(SKILLS.revision(), SKILLS.revision())

    def test_handles_missing_folder(self):
        real = SKILLS.SKILLS_DIR
        try:
            SKILLS.SKILLS_DIR = ROOT / "nope-missing-dir"
            self.assertEqual(SKILLS.load(force=True), [])
            self.assertIn("khaali", SKILLS.describe())
        finally:
            SKILLS.SKILLS_DIR = real
            SKILLS.load(force=True)

    def test_screen_control_skill_matches_and_teaches_the_real_tools(self):
        hits = [s["name"] for s in SKILLS.match("meri screen dekho aur click karo")]
        self.assertIn("screen-control", hits)
        body = SKILLS.body("screen-control")
        for tool in ("look_at_screen", "gui_locate_and_click", "gui_type_into",
                     "screen_task"):
            self.assertIn(tool, body)
        self.assertIn("confirm", body.lower())


class McpClientTest(unittest.TestCase):
    def test_resolve_repo_script(self):
        argv, cwd, error = MCP._resolve({"command": "tests/fixtures/mcp_echo_server.py", "args": []})
        self.assertEqual(error, "")
        self.assertTrue(argv and cwd)

    def test_rejects_arbitrary_command(self):
        argv, cwd, error = MCP._resolve({"command": "shutdown.exe", "args": []})
        self.assertIsNone(argv)
        self.assertIn("allowlisted", error)

    def test_rejects_escaping_cwd(self):
        argv, cwd, error = MCP._resolve({"command": "tests/fixtures/mcp_echo_server.py", "args": [],
                                         "cwd": ".."})
        self.assertIsNone(argv)
        self.assertIn("inside the repository", error)

    def test_echo_tools_listed(self):
        out = MCP.list_tools("echo", timeout=15.0)
        self.assertTrue(out.get("ok"), out)
        self.assertEqual([t["name"] for t in out["tools"]], ["echo"])

    def test_echo_call_roundtrip(self):
        out = MCP.call_tool("echo", "echo", {"text": "hello jarvis"})
        self.assertTrue(out.get("ok"), out)
        self.assertEqual(out.get("text"), "echo: hello jarvis")

    def test_files_server_sandboxed(self):
        out = MCP.call_tool("files", "read_file", {"path": "../../package.json"})
        self.assertFalse(out.get("ok"))
        out = MCP.call_tool("files", "list_files", {"path": "skills", "limit": 20})
        self.assertTrue(out.get("ok"), out)
        self.assertIn("SKILL.md", out.get("text", ""))

    def test_files_search_skips_runtime_artifacts(self):
        out = MCP.call_tool("files", "search_text",
                            {"query": "build_default_registry", "max_results": 10},
                            timeout=60.0)
        self.assertTrue(out.get("ok"), out)
        text = out.get("text", "")
        self.assertIn("background/cowork_tools.py", text)
        self.assertNotIn("artifacts/", text)

    def test_system_server_reports_real_values(self):
        out = MCP.call_tool("system", "system_metrics", {})
        self.assertTrue(out.get("ok"), out)
        import json
        data = json.loads(out["text"])
        self.assertIn("disk", data)
        self.assertIsNotNone(data["disk"])
        self.assertGreater(data["disk"]["total_gb"], 0)
        clock = MCP.call_tool("system", "current_time", {})
        self.assertTrue(clock.get("ok"), clock)
        self.assertIn("date", json.loads(clock["text"]))

    def test_call_unknown_server_is_honest(self):
        out = MCP.call_tool("nope", "echo", {})
        self.assertFalse(out.get("ok"))
        self.assertIn("not configured", out.get("error"))


class BrowserMcpServerTest(unittest.TestCase):
    """The browser MCP connector must be REAL and must stay safe.

    Tools/list is asserted for every launch (cheap). The two network tests
    skip when the Playwright driver is absent, so CI without Chromium stays
    green instead of failing on a missing optional binary.
    """

    @classmethod
    def setUpClass(cls):
        cls.rows = [t for t in (MCP.tools_snapshot(probe=True) or [])
                    if t["server"] == "browser"]

    def test_browser_server_is_configured_and_callable(self):
        entry = {s["name"]: s for s in MCP.servers()}.get("browser")
        self.assertIsNotNone(entry, "browser server missing from mcp/servers.json")
        self.assertTrue(entry["enabled"], entry.get("error"))
        self.assertTrue(entry["allow_call"])

    def test_browser_exposes_the_real_page_tools(self):
        names = {r["tool"] for r in self.rows}
        for tool in ("browse", "read_page", "list_links", "find_text",
                     "screenshot", "click", "fill"):
            self.assertIn(tool, names, "browser MCP is missing %s" % tool)

    def test_reads_are_read_only_and_mutations_are_destructive(self):
        by_name = {r["tool"]: r for r in self.rows}
        for tool in ("browse", "read_page", "list_links", "find_text", "screenshot"):
            self.assertTrue(by_name[tool].get("read_only", True) is not False
                            or by_name[tool]["annotations"]["readOnlyHint"],
                            tool)
        for tool in ("click", "fill"):
            self.assertFalse(by_name[tool]["annotations"]["readOnlyHint"], tool)
            self.assertTrue(by_name[tool]["annotations"]["destructiveHint"], tool)

    def test_unsafe_urls_are_refused_without_launching_anything(self):
        for bad in ("file:///C:/Windows/System32/cmd.exe",
                    "javascript:alert(1)", "data:text/html,<h1>x",
                    "vbscript:msgbox(1)", "C:\\Windows\\System32\\cmd.exe"):
            out = MCP.call_tool("browser", "browse", {"url": bad})
            self.assertFalse(out.get("ok"), "accepted %r: %s" % (bad, out))
            self.assertIn("http", str(out.get("error", "")).lower(), bad)

    @unittest.skipUnless(BROWSER.available(), "chromium driver not installed")
    def test_browse_really_renders_a_page(self):
        import json
        out = MCP.call_tool("browser", "browse", {"url": "https://example.com"},
                            timeout=60.0)
        self.assertTrue(out.get("ok"), out)
        data = json.loads(out["text"])
        self.assertEqual(data["http_status"], 200)
        self.assertIn("Example Domain", data["title"])
        self.assertIn("documentation", data["text"].lower())

    @unittest.skipUnless(BROWSER.available(), "chromium driver not installed")
    def test_session_survives_between_mcp_calls(self):
        """browse -> list_links across two separate server processes.

        Each MCP call spawns a fresh server, so this only passes when the last
        URL is remembered and restored instead of silently acting on
        about:blank.
        """
        import json
        MCP.call_tool("browser", "browse", {"url": "https://example.com"},
                      timeout=60.0)
        out = MCP.call_tool("browser", "list_links", {}, timeout=60.0)
        self.assertTrue(out.get("ok"), out)
        data = json.loads(out["text"])
        self.assertIn("example.com", data["url"])
        self.assertGreaterEqual(data["count"], 1)

    def test_describe_and_catalog_report_reality(self):
        self.assertIn("echo", MCP.describe().lower())
        self.assertIn("echo.echo", MCP.catalog())


if __name__ == "__main__":
    unittest.main(verbosity=2)
