"""Live bridge - lets a Gemini Live duplex session share JARVIS's one mic,
one command path and one memory.

Why a bridge instead of wiring `live_session` straight into `voice_engine`:
the engine is already 10k lines and owns the only microphone stream
(`_audio_q`, fed by `_mic_callback`). This module never opens a stream. The
existing consumer loop hands each chunk to `feed()` while Live owns the turn,
and goes back to VAD/STT/wake the moment it does not - so there is exactly one
capture path, and `stop()` restores today's behaviour byte-for-byte.

Everything user-shaped goes through the single canonical route: transcripts are
submitted with `submit_command(..., source="live")`, replies are handed back to
Live to be spoken natively (so barge-in works on them), and nothing here talks
to a model, a tool or a memory store by itself - the callables are injected by
`configure()` at boot.
"""

import array
import os
import threading
import time

FRAME_SAMPLES = 512           # 32 ms at 16 kHz: lower uplink latency than 100 ms
FRAME_BYTES = FRAME_SAMPLES * 2

# A laptop has no hardware echo cancellation on this Python capture path. While
# JARVIS's own 24 kHz reply is coming out of the speakers, the mic hears it and
# the server can treat it as the user starting a turn (observed 2026-10-20: the
# greeting triggered a self-reply). The guard sends silence while JARVIS speaks
# unless the mic is loud enough to be a real barge-in.
ECHO_GUARD = os.environ.get("JARVIS_LIVE_ECHO_GUARD", "1") != "0"
BARGE_RMS = float(os.environ.get("JARVIS_LIVE_BARGE_RMS", "1400"))
ECHO_TAIL_S = float(os.environ.get("JARVIS_LIVE_ECHO_TAIL", "0.35"))

# A spoken action result is marked as system content, not as something the user
# said: the persona forbids the model claiming an action until a SYSTEM line
# arrives, so the prefix is part of the contract, not decoration.
RESULT_PREFIX = "SYSTEM: "

_lock = threading.Lock()
_session = None
_active = False
_factory = None
_submit_fn = None
_remember_fn = None
_turn_fn = None
_tool_used = False

_pending_in = array.array("h")     # input samples not yet grouped for downsampling
_pending_pos = 0.0                 # fractional read cursor for 44.1 kHz-style rates
_buf = bytearray()                 # 16 kHz output samples waiting for a full frame
_user_parts = []
_jarvis_parts = []
_counters = {}
_last_speak_at = 0.0
_SILENCE_FRAME = b"\x00\x00" * FRAME_SAMPLES


def _blank():
    return {
        "live_stage": "off",
        "barge_in": 0,
        "dropped_chunks": 0,
        "first_audio_s": None,
        "turns": 0,
        "frames_sent": 0,
        "samples_in_16k": 0,
        "tool_calls": 0,
        "last_tool": "",
        "echo_gated": 0,
        "local_barge_in": 0,
        "echo_rms_max": 0,
        "last_mic_rms": 0,
        "last_error": "",
        "last_user": "",
        "last_jarvis": "",
    }


def configure(factory=None, submit_fn=None, remember_fn=None, turn_fn=None):
    """Inject the session class and the engine's existing routes. Called at boot.

    `remember_fn(text)` learns durable facts from the user's side only;
    `turn_fn(user, jarvis)` records the finished exchange in the prompt history
    and the visible activity feed. Keeping them separate stops JARVIS's own
    words from being learned back as facts about Sir.
    """
    global _factory, _submit_fn, _remember_fn, _turn_fn
    if factory is not None:
        _factory = factory
    if submit_fn is not None:
        _submit_fn = submit_fn
    if remember_fn is not None:
        _remember_fn = remember_fn
    if turn_fn is not None:
        _turn_fn = turn_fn


def taking_audio():
    return _active


def start():
    """Open one duplex session. False means Live is unavailable and the caller
    must keep using the classic pipeline - never a silent half-start."""
    global _session, _active
    if _active:
        return True
    if _factory is None:
        configure(factory=_default_factory)
    with _lock:
        _counters.update(_blank())
        _counters["live_stage"] = "opening"
        del _buf[:]
        _pending_in[:] = array.array("h")
        globals()["_pending_pos"] = 0.0
        globals()["_last_speak_at"] = 0.0
        del _user_parts[:]
        del _jarvis_parts[:]
    globals()["_tool_used"] = False
    with _lock:
        _session = _factory(on_transcript=_on_transcript, on_state=_on_state)
    if _session is None:
        # live_session needs the `websocket` package; without it there is no
        # session class at all. Degrade to classic instead of raising into the
        # caller's voice path.
        _note(stage="live_error", last_error="live_session unavailable")
        return False
    if not _session.open():
        # open() already published the specific reason through on_state; do not
        # overwrite it with a generic one, or /state cannot explain the failure.
        with _lock:
            reason = _counters.get("last_error") or "Live session refused to open"
        _note(stage="live_error", last_error=reason)
        _session = None
        return False
    globals()["_active"] = True
    _note(stage="live_ready")
    return True


def _default_factory(on_transcript, on_state):
    import importlib.util
    from pathlib import Path

    path = Path(__file__).resolve().parent / "live_session.py"
    spec = importlib.util.spec_from_file_location("live_session", str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.LiveSession(on_transcript=on_transcript, on_state=on_state)


def stop():
    """Give the mic back. Runs even when the socket is already gone, because a
    stuck flag would leave JARVIS deaf in both modes."""
    global _session, _active, _last_speak_at
    sess, _session = _session, None
    globals()["_active"] = False
    _last_speak_at = 0.0
    if sess is None:
        _note(stage="off")
        return
    try:
        sess.close()
    except Exception as exc:
        _note(stage="off", last_error="close(): %s" % type(exc).__name__)
    else:
        _note(stage="off")


def _frame_rms(frame):
    samples = array.array("h")
    samples.frombytes(frame[:len(frame) - len(frame) % 2])
    if not samples:
        return 0
    return int((sum(s * s for s in samples) / len(samples)) ** 0.5)


def feed(pcm_bytes, rate):
    """Hand the engine's chunk to Live, resampled to 16 kHz in 32 ms frames."""
    global _pending_pos, _last_speak_at
    if not _active or not pcm_bytes:
        return False
    rate = int(rate or 16000)
    with _lock:
        if rate == 16000:
            _buf.extend(pcm_bytes)
            _counters["samples_in_16k"] += len(pcm_bytes) // 2
        else:
            incoming = array.array("h")
            incoming.frombytes(pcm_bytes[:len(pcm_bytes) - len(pcm_bytes) % 2])
            _pending_in.extend(incoming)
            produced = array.array("h")
            if rate % 16000 == 0:
                # 48 kHz -> exact 3:1 box mean.
                ratio = rate // 16000
                while len(_pending_in) >= ratio:
                    group = _pending_in[:ratio]
                    del _pending_in[:ratio]
                    produced.append(sum(group) // ratio)
            else:
                # 44.1 kHz has no integer ratio. Decimating it (the old ratio=2)
                # played JARVIS's own voice at the wrong pitch; interpolate.
                step = rate / 16000.0
                while _pending_pos + 1 < len(_pending_in):
                    i = int(_pending_pos)
                    frac = _pending_pos - i
                    a = _pending_in[i]
                    b = _pending_in[i + 1]
                    produced.append(int(round(a + (b - a) * frac)))
                    _pending_pos += step
                drop = int(_pending_pos)
                if drop:
                    del _pending_in[:drop]
                    _pending_pos -= drop
            if produced:
                _buf.extend(produced.tobytes())
                _counters["samples_in_16k"] += len(produced)
        frames = []
        while len(_buf) >= FRAME_BYTES:
            frames.append(bytes(_buf[:FRAME_BYTES]))
            del _buf[:FRAME_BYTES]
    for frame in frames:
        sess = _session
        if sess is None:
            _note(stage="live_lost", last_error="Live dropped an audio frame")
            return False
        playing = bool(getattr(getattr(sess, "player", None), "speaking", False))
        if playing:
            _last_speak_at = time.monotonic()
        gated_window = playing or (time.monotonic() - _last_speak_at < ECHO_TAIL_S)
        if gated_window:
            rms = _frame_rms(frame)
            with _lock:
                _counters["last_mic_rms"] = rms
                if rms > int(_counters.get("echo_rms_max") or 0):
                    _counters["echo_rms_max"] = rms
            if ECHO_GUARD and rms < BARGE_RMS:
                # Speaker output, not a person: send silence so the server VAD
                # does not open a turn on JARVIS's own voice.
                frame = _SILENCE_FRAME
                with _lock:
                    _counters["echo_gated"] += 1
            elif ECHO_GUARD:
                # Loud enough to be the user cutting in: stop the reply now and
                # let the real speech through as the next turn.
                try:
                    sess.player.flush()
                except Exception:
                    pass
                _last_speak_at = 0.0
                with _lock:
                    _counters["local_barge_in"] += 1
        if not sess.send_pcm(frame):
            _note(stage="live_lost", last_error="Live dropped an audio frame")
            return False
        with _lock:
            _counters["frames_sent"] += 1
    return True


def utter(text):
    """Have Live speak a line natively. False = nothing live, caller falls back
    to the TTS file chain."""
    safe = " ".join(str(text or "").split())
    if not _active or not safe or _session is None:
        return False
    return bool(_session.send_text(RESULT_PREFIX + safe))


# ------------------------------------------------------------------ callbacks
def _on_transcript(who, text):
    """Buffer transcription deltas; nothing is learned or run until the turn
    ends. The endpoint streams words in pieces, so a fragment must never become
    a command or a memory."""
    text = str(text or "").strip()
    if not text:
        return
    slot = _user_parts if who == "user" else _jarvis_parts
    with _lock:
        slot.append(text)
        _counters["last_" + ("user" if who == "user" else "jarvis")] = " ".join(slot)


def _on_state(**kw):
    global _tool_used
    stage = str(kw.get("stage") or "")
    if stage == "live_tool":
        # A real function call already went through the canonical command
        # router, so the post-turn OS fallback must not submit the same action a
        # second time.
        _tool_used = True
        with _lock:
            _counters["tool_calls"] = int(_counters.get("tool_calls") or 0) + 1
            _counters["last_tool"] = str(kw.get("tool") or "")
    elif stage == "live_barge_in":
        with _lock:
            _counters["barge_in"] += 1
            _counters["dropped_chunks"] += int(kw.get("dropped_chunks") or 0)
    elif stage == "live_turn_done":
        with _lock:
            _counters["turns"] += 1
            if kw.get("first_audio_s") is not None:
                _counters["first_audio_s"] = kw["first_audio_s"]
            user_line = " ".join(_user_parts).strip()
            jarvis_line = " ".join(_jarvis_parts).strip()
            del _user_parts[:]
            del _jarvis_parts[:]
            tool_used = _tool_used
            _tool_used = False
        if _turn_fn and (user_line or jarvis_line):
            _turn_fn(user_line, jarvis_line)
        # Learn only from the user's side: feeding JARVIS's own reply back into
        # the fact extractor turns its wording into "facts about Sir".
        if user_line and _remember_fn:
            _remember_fn(user_line)
        # Fallback for a model that answered an action without calling the tool.
        # One argument only: production wires voice_engine._live_route here, and
        # passing a second `source` argument killed the reader on the first turn
        # (TypeError, 2026-10-20). The source is 'live' inside that route.
        if user_line and _submit_fn and not tool_used:
            _submit_fn(user_line)
    _note(**kw)


def _note(**kw):
    with _lock:
        stage = kw.pop("stage", None)
        for key, val in kw.items():
            if key == "dropped_chunks":
                continue            # counted, not overwritten
            _counters[key] = val
        if stage is not None:
            _counters["live_stage"] = stage
        _counters.setdefault("live_stage", "off")


def status():
    with _lock:
        out = dict(_blank())
        out.update(_counters)
    out["voice_mode"] = "live" if _active else "classic"
    return out
