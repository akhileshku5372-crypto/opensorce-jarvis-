(() => {
  const $ = (selector, root = document) => root.querySelector(selector)
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)]
  const state = {
    recognition: null,
    listening: false,
    cameraStream: null,
    handTracker: null,
    gestureActive: false,
    gestureFrame: 0,
    activeWindow: '',
    bridgeOnline: false,
    // Bridge-reported desktop geometry and PowerShell input-worker health,
    // handed to the gesture controller so the pointer mapping never guesses.
    bridgeDesktop: null,
    bridgeMouse: null,
    coreOnline: false,
    coreRevision: 0,
    // null = no /state poll seen yet on this page load, so the first clear_seq
    // read seeds the bell instead of being mistaken for a Clear Chat.
    clearSeq: null,
    coreEventIds: new Set(),
    // True between sending a turn to the core and its answer arriving on
    // /state. Lets the event pump attach the assistant half to the transcript.
    pendingCoreTurn: false,
    channelRevision: 0,
    channelInfo: { id: 'general_chat', guarded: false },
    messages: [],
    lastAction: { key: '', at: 0 },
    manualVoiceStop: false,
    micBlocked: false,
    mediaRecorder: null,
    recordingStream: null,
    activeAudio: null,
    timers: new Map(),
    settings: JSON.parse(localStorage.getItem('jarvis-settings') || '{}')
  }

  const moduleData = {
    gesture: [
      ['mouse-pointer-2', 'Right index = cursor', 'Steer the real Windows cursor with your right index finger.', 'gesture_point'],
      ['mouse-pointer-click', 'Right pinch = click', 'Right thumb + index pinch = left click, thumb + middle = right click.', 'gesture_click'],
      ['move', 'Right fist = drag', 'Make a fist to hold and drag, open to release. Open palm pauses the pointer.', 'gesture_drag'],
      ['hand', 'Left hand = JARVIS UI', 'Pinch selects the JARVIS control under that hand, open palm returns to the dashboard.', 'gesture_ui'],
      ['scale-3d', 'Both hands = view scale', 'Both index fingers apart / together scale the active view.', 'gesture_hud'],
      ['gallery-horizontal', 'Both palms = navigate', 'Swipe both palms left / right for sections, move up / down to scroll. Both pinches zoom the active view.', 'gesture_scroll'],
      ['hand-metal', 'Both fists = pause', 'Both fists pause every gesture action. Hold both palms up to resume, or press Pause controls. F8 is the emergency stop.', 'gesture_calibrate']
    ],
    system: [
      ['monitor-up', 'Window manager', 'Focus, minimize, maximize, snap or close windows.', 'list active windows'],
      ['folder-search', 'File explorer', 'Search and open local files via allowlisted actions.', 'list files on desktop'],
      ['gauge', 'Performance', 'Read live CPU, memory, disk and battery details.', 'show system info'],
      ['keyboard', 'Keyboard actions', 'Type text or execute approved keyboard shortcuts.', 'switch window'],
      ['camera', 'Screenshot', 'Capture and organize a desktop screenshot.', 'take a screenshot'],
      ['power', 'Power control', 'Lock, sleep, restart or shut down with confirmation.', 'lock pc']
    ]
  }

  function init() {
    if (window.lucide) window.lucide.createIcons()
    bindNavigation()
    bindSidebarCollapse()
    bindNavTooltips()
    bindCommands()
    bindChat()
    bindCamera()
    bindWebSearch()
    bindCamera()
    bindRepos()

    bindStorageFeatures()
    bindMemory()
    bindSettings()
    bindModuleMatrix()
    renderModules()
    initOrbParticles()
    updateClock()
    setInterval(updateClock, 1000)
    checkBridge()
    setInterval(checkBridge, 15000)
    pollCore()
    setInterval(pollCore, 900)
    renderSavedItems()
    applySettings()
    try{ refreshSettingsBrain(); drawSettingsOrbits(_lastBrain); }catch{}
    checkDueReminders()
    setInterval(checkDueReminders, 15000)
    // Auto-summon the floating mini UI whenever the dashboard tab is hidden
    // (taskbar-minimised, another window focused, or closed-but-app-running).
    // The tiny Python orb then visualises the background engine; POST is throttled.
    const ensureFloatingUI = () => {
      if (Date.now() - (state.lastFloatAt || 0) < 60000) return
      state.lastFloatAt = Date.now()
      // auto=true: the tab-hidden heartbeat must never re-open a HUD the user
      // closed on purpose - the explicit HUD pill stays the only tab summon.
      fetch('http://127.0.0.1:7780/float', {
        method: 'POST', mode: 'cors',
        headers: { 'Content-Type': 'application/json' },
        body: '{"auto":true}'
      }).catch(() => {})
    }
    document.addEventListener('visibilitychange', () => { if (document.hidden) ensureFloatingUI() })
    // The dashboard "HUD" pill summons the floating JARVIS console immediately,
    // and the background engine stays running independently of any browser tab.
    // The dashboard HUD pill and the workspace HUD module both summon the
    // floating console through one implementation (bindShellExtras binds the
    // data-float-hud buttons to the same function).
    $('#float-hud-button')?.addEventListener('click', summonFloatingHud)
    if (state.settings.wake !== false) {
      const armWakeMode = () => { if (!state.coreOnline && !state.listening) toggleVoice(); document.removeEventListener('pointerdown', armWakeMode) }
      document.addEventListener('pointerdown', armWakeMode)
      $('#voice-hint').textContent = 'Background core active — say “Hey JARVIS”'
    }
    // ── Safe error boundaries ─────────────────────────────────────────────
    // Every subsystem mounts behind its own guard so a single failing block can
    // never freeze the whole application loop or render an empty/white screen.
            const mount = (label, fn) => { try { fn() } catch (error) { console.error(`[JARVIS] ${label} failed:`, error) } }
    mount('Dashboard workspace modules', bindWorkspaceModules)
    mount('Conversation expand control', bindChatExpand)
    mount('Rail chat history', bindChatRail)
    mount('Notification bell', bindNotifyButton)
    mount('Shell extras (HUD + rail camera)', bindShellExtras)
    mount('Two-hand gesture control', initGestureControl)
    mount('KamiSensei dashboard bindings', bindKsDashboard)
    mount('Studio bindings', initStudioUI)
    mount('KamiSensei sources', bindKsSources)
    mount('KamiSensei chat bindings', bindKsChat)
    mount('KamiSensei Podcast Studio', initKsPodcastUI)
    mount('KamiSensei Audio Hub', initKsAudioHub)
    mount('KamiSensei Mini Player', initKsMiniPlayer)
    mount('KAMI/Sense workspace', initKsSense)
    mount('Extension system (plugins/skills/MCP)', () => { bindExtensions(); loadExtensions() })
    mount('Advanced Perception panel', () => { bindPerception(); loadPerception() })
    mount('Neural Brain', bindBrain)
  }

  // ── Living-particle engine for the JARVIS core ───────────────────────────
  // The orb is not decorative: every value below reads the REAL runtime state
  // that setRuntimeState() writes to <body data-runtime-state>. Standby drifts,
  // listening pulses, thinking/searching spin faster, speaking flows, working
  // turns the core orange and error turns it red.
  function initOrbParticles() {
    const canvas = $('#orb-particles')
    if (!canvas || !canvas.getContext) return
    const wrap = canvas.parentElement
    const ctx = canvas.getContext('2d')
    const reduceMotion = Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)
    const PROFILES = {
      standby: { energy: 0.22, speed: 0.55, hue: 'cyan' },
      idle: { energy: 0.22, speed: 0.55, hue: 'cyan' },
      listening: { energy: 0.72, speed: 1.6, hue: 'cyan' },
      thinking: { energy: 0.88, speed: 2.1, hue: 'cyan' },
      searching: { energy: 0.8, speed: 1.9, hue: 'violet' },
      speaking: { energy: 1, speed: 2.4, hue: 'cyan' },
      working: { energy: 0.62, speed: 1.7, hue: 'orange' },
      executing: { energy: 0.62, speed: 1.7, hue: 'orange' },
      interrupted: { energy: 0.3, speed: 0.7, hue: 'amber' },
      error: { energy: 0.45, speed: 0.5, hue: 'red' },
      offline: { energy: 0.1, speed: 0.3, hue: 'muted' }
    }
        const PALETTE = {
      cyan: ['#00d9ff', '#19e6ff', '#168bff', '#ff8a00'],
      violet: ['#a48bff', '#00d9ff', '#168bff'],
      orange: ['#ff8a00', '#ff9a3d', '#00d9ff'],
      amber: ['#ffb020', '#00d9ff', '#ff9a3d'],
      red: ['#ff4567', '#ff9a3d'],
      muted: ['#3d6a80', '#168bff']
    }
    let w = 0, h = 0, dpr = 1, t = 0, raf = 0
    let energy = 0.22, speed = 0.55, colors = PALETTE.cyan, nodes = []
    const currentState = () => String(document.body.dataset.runtimeState || 'standby').toLowerCase()
    const seed = () => {
      const count = reduceMotion ? 24 : Math.max(34, Math.round((w * h) / 2400))
      nodes = Array.from({ length: count }, () => ({
        a: Math.random() * Math.PI * 2,
        r: 0.16 + Math.random() * 0.84,
        size: 0.6 + Math.random() * 1.6,
        va: (Math.random() - 0.5) * 0.055,
        drift: 0.0006 + Math.random() * 0.0016,
        phase: Math.random() * Math.PI * 2,
        tint: Math.random()
      }))
    }
    const resize = () => {
      const rect = wrap.getBoundingClientRect()
      if (!rect.width || !rect.height) return
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = rect.width; h = rect.height
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      seed()
    }
    const frame = () => {
      const profile = PROFILES[currentState()] || PROFILES.standby
      const breathe = String(currentState()) === 'speaking' ? Math.max(0, Math.sin(t * 6)) * 0.18 : 0
      energy += ((profile.energy + breathe) - energy) * 0.06
      speed += (profile.speed - speed) * 0.05
      colors = PALETTE[profile.hue] || PALETTE.cyan
      wrap.style.setProperty('--orb-speed', speed.toFixed(2))
      const cx = w / 2, cy = h / 2
      const core = Math.min(w, h) * 0.27
      const pulse = 1 + Math.sin(t * (1.3 + energy * 3.6)) * 0.02 * (0.4 + energy)
            ctx.clearRect(0, 0, w, h)
      const glow = ctx.createRadialGradient(cx, cy, 2, cx, cy, core * 2.2 * pulse)
      glow.addColorStop(0, `rgba(0,217,255,${(0.06 + energy * 0.24).toFixed(3)})`)
      glow.addColorStop(0.55, `rgba(0,217,255,${(0.02 + energy * 0.09).toFixed(3)})`)
      glow.addColorStop(1, 'rgba(0,217,255,0)')
      ctx.fillStyle = glow
      ctx.beginPath(); ctx.arc(cx, cy, core * 2.2 * pulse, 0, Math.PI * 2); ctx.fill()
      for (let i = 0; i < nodes.length; i++) {
        const p = nodes[i]
        p.a += p.va * (0.4 + speed * 0.55)
        p.r += Math.sin(t * 0.6 + p.phase) * p.drift * (0.3 + energy)
        if (p.r > 1) p.r -= 0.86
        if (p.r < 0.12) p.r += 0.86
        const radius = core * (0.5 + p.r * 1.1)
        const x = cx + Math.cos(p.a) * radius
        const y = cy + Math.sin(p.a) * radius * 0.86
        ctx.globalAlpha = Math.max(0.06, Math.min(1, 0.3 + 0.7 * Math.sin(t * 2 + p.phase) * (0.35 + energy)))
        ctx.fillStyle = p.tint < 0.2 ? colors[colors.length - 1] : colors[Math.floor(p.tint * 3) % colors.length]
        ctx.beginPath(); ctx.arc(x, y, p.size * (0.7 + energy * 0.85), 0, Math.PI * 2); ctx.fill()
      }
      ctx.globalAlpha = 0.22 * energy
      ctx.strokeStyle = colors[0]
      ctx.lineWidth = 1
      for (let s = 0; s < 3; s++) {
        const a0 = t * (0.7 + s * 0.28) + s * 2.1
        const rr = core * (1.16 + 0.26 * s)
        ctx.beginPath(); ctx.arc(cx, cy, rr, a0, a0 + 0.85); ctx.stroke()
      }
      ctx.globalAlpha = 1
      t += 0.012 + energy * 0.012
      raf = requestAnimationFrame(frame)
    }
    resize()
    if (window.ResizeObserver) new ResizeObserver(resize).observe(wrap)
    else window.addEventListener('resize', resize)
    window.addEventListener('resize', resize)
    raf = requestAnimationFrame(frame)
  }

  // ══════════════════════════════════════════════════════════════════════════
  // EXTENSION SYSTEM UI - plugins, skills, MCP, permissions, marketplace
  // ══════════════════════════════════════════════════════════════════════════
  // Renders exactly what /extensions returns from the live managers. Nothing
  // is invented here: a capability that is not in the payload is not shown.
  const EXT_CORE = 'http://127.0.0.1:7780'
  let extSnapshot = null

  function extRow(name, detail, enabled, kind, slug) {
    const row = document.createElement('div')
    row.className = 'ext-row'
    row.innerHTML = `<div class="ext-row-main"><strong>${escapeHtml(name)}</strong>` +
      `<span class="panel-note">${escapeHtml(detail || '')}</span></div>` +
      `<button type="button" class="ext-toggle ${enabled ? 'is-on' : ''}" ` +
      `data-ext-kind="${kind}" data-ext-slug="${escapeHtml(slug || name)}" ` +
      `data-ext-enabled="${enabled ? '1' : '0'}">${enabled ? 'Enabled' : 'Disabled'}</button>`
    return row
  }

  function renderExtTab(name) {
    const pane = $(`#ext-panel-${name}`)
    if (!pane || !extSnapshot) return
    const note = (msg) => `<span class="panel-note">${msg}</span>`
    if (name === 'plugins') {
      const rows = extSnapshot.plugins || []
      pane.innerHTML = rows.length ? '' : note('No plugins installed. Add one under extensions/plugins/.')
      for (const p of rows) {
        pane.append(extRow(`${p.name} v${p.version}`,
          `${p.description} · ${(p.tools || []).length} tool(s)`, p.enabled, 'plugin', p.slug))
      }
    }
    if (name === 'skills') {
      const rows = extSnapshot.skills || []
      pane.innerHTML = rows.length ? '' : note('No SKILL.md found in skills/.')
      for (const s of rows) {
        pane.append(extRow(s.name,
          `${s.description} · ${(s.triggers || []).length} trigger(s) · ${s.size_bytes || 0} B`,
          s.enabled, 'skill', s.name))
      }
    }
    if (name === 'mcp') {
      const rows = extSnapshot.mcp || []
      pane.innerHTML = rows.length ? '' : note('No MCP connectors configured.')
      for (const m of rows) {
        const state = m.ok ? 'online' : (m.enabled ? ('offline: ' + (m.error || 'unknown')) : 'disabled')
        pane.append(extRow(m.name,
          `${state} · ${(m.tools || []).length} tool(s) · ${m.source || 'stdio'}`,
          !!m.enabled, 'mcp', m.name))
      }
    }

    if (name === 'permissions') {
      const cats = (extSnapshot.permissions || {}).categories || []
      pane.innerHTML = cats.length ? '' : note('No permission categories.')
      for (const c of cats) {
        const row = document.createElement('div')
        row.className = 'ext-row'
        row.innerHTML = `<div class="ext-row-main"><strong>${escapeHtml(c.label)}</strong>` +
          `<span class="panel-note">${escapeHtml(c.description)}` +
          `${c.overridden ? ' · overridden' : ''}</span></div>` +
          `<select class="field ext-perm" data-ext-cat="${escapeHtml(c.category)}">` +
          ['auto', 'ask', 'deny'].map((v) =>
            `<option value="${v}"${c.effective === v ? ' selected' : ''}>${v}</option>`).join('') +
          `</select>`
        pane.append(row)
      }
    }
    if (name === 'marketplace') {
      const rows = extSnapshot.marketplace || []
      pane.innerHTML = rows.length ? '' : note('Marketplace is empty.')
      for (const item of rows) {
        const row = document.createElement('div')
        row.className = 'ext-row'
        row.innerHTML = `<div class="ext-row-main"><strong>${escapeHtml(item.name)}</strong>` +
          `<span class="panel-note">${escapeHtml(item.description)} · ` +
          `${escapeHtml(item.category)} · ${escapeHtml(item.audience)}</span></div>` +
          (item.installed
            ? '<span class="ext-chip is-on">Installed</span>'
            : `<button type="button" class="primary-button ext-install" data-ext-item="${escapeHtml(item.id)}">Install</button>`)
        pane.append(row)
      }
    }
    if (name === 'activity') {
      const rows = extSnapshot.audit || []
      pane.innerHTML = rows.length ? '' : note('No permission decisions recorded yet.')
      for (const a of rows.slice().reverse()) {
        const row = document.createElement('div')
        row.className = 'ext-row'
        const when = a.at ? new Date(a.at * 1000).toLocaleTimeString() : ''
        row.innerHTML = `<div class="ext-row-main"><strong>${escapeHtml(a.tool || a.category)}</strong>` +
          `<span class="panel-note">${when} · ${escapeHtml(a.category)} · ${escapeHtml(a.decision)}</span></div>` +
          `<span class="ext-chip ${a.allowed ? 'is-on' : 'is-off'}">${a.allowed ? 'allowed' : 'blocked'}</span>`
        pane.append(row)
      }
    }
  }

  async function loadExtensions() {
    try {
      const response = await fetch(`${EXT_CORE}/extensions`, { cache: 'no-store', signal: AbortSignal.timeout(9000) })
      if (!response.ok) throw new Error('HTTP ' + response.status)
      extSnapshot = await response.json()
    } catch {
      for (const name of ['plugins', 'skills', 'mcp', 'permissions', 'marketplace']) {
        const pane = $(`#ext-panel-${name}`)
        if (pane) pane.innerHTML = '<span class="panel-note">Core offline — extensions unavailable.</span>'
      }
      return
    }
    const counts = extSnapshot.counts || {}
    const label = $('#ext-counts')
    if (label) {
      label.textContent = `${counts.plugins || 0} plugins · ${counts.skills || 0} skills · ` +
        `${counts.mcp_online || 0}/${counts.mcp_total || 0} MCP · ${counts.tools || 0} tools`
    }
    const active = $('[data-ext-tab].active')?.dataset.extTab || 'plugins'
    for (const name of ['plugins', 'skills', 'mcp', 'permissions', 'marketplace', 'activity']) {
      renderExtTab(name)
      const pane = $(`#ext-panel-${name}`)
      if (pane) pane.hidden = name !== active
    }
  }

  function bindExtensions() {
    $$('[data-ext-tab]').forEach((tab) => tab.addEventListener('click', () => {
      $$('[data-ext-tab]').forEach((t) => t.classList.toggle('active', t === tab))
      const name = tab.dataset.extTab
      for (const pane of $$('[data-ext-pane]')) pane.hidden = pane.dataset.extPane !== name
      renderExtTab(name)
    }))
    document.addEventListener('click', async (event) => {
      const toggle = event.target.closest('[data-ext-kind]')
      if (toggle) {
        const kind = toggle.dataset.extKind
        if (kind === 'mcp') return showToast('Restart an MCP connector from its config entry.')
        try {
          await fetch(`${EXT_CORE}/extensions/toggle`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ kind, name: toggle.dataset.extSlug, enabled: toggle.dataset.extEnabled !== '1' })
          })
          await loadExtensions()
        } catch { showToast('Could not reach the JARVIS core.', true) }
        return
      }
      const install = event.target.closest('[data-ext-item]')
      if (install) {
        install.textContent = 'Installing…'
        try {
          await fetch(`${EXT_CORE}/extensions/marketplace/install`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: install.dataset.extItem })
          })
          showToast('Install finished — see the Activity tab.')
        } catch { showToast('Install failed.', true) }
        await loadExtensions()
        return
      }
      const perm = event.target.closest('[data-ext-cat]')
      if (perm) {
        try {
          await fetch(`${EXT_CORE}/extensions/permissions`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ overrides: { [perm.dataset.extCat]: perm.value } })
          })
          showToast(`Permission '${perm.dataset.extCat}' set to ${perm.value}.`)
        } catch { showToast('Could not reach the JARVIS core.', true) }
      }
    })
    setInterval(loadExtensions, 12000)
  }

  // ── ADVANCED PERCEPTION UI (real state only, never invented) ───────────
  // Renders exactly what GET /perception and POST /perception/run return from
  // the local ONNX/OpenCV detectors. Nothing here is hard-coded or optimistic.
  function bindPerception() {
    $('#perception-refresh')?.addEventListener('click', () => {
      loadPerception()
      runPerception('all')
    })
  }

  function perceptionSet(kind, state, detail, model) {
    const s = $(`[data-perception-state="${kind}"]`)
    const d = $(`[data-perception-detail="${kind}"]`)
    const m = $(`[data-perception-model="${kind}"]`)
    if (s) s.textContent = state
    if (d) d.textContent = detail
    if (m && model != null) m.textContent = model
  }

  async function loadPerception() {
    const badge = $('#perception-source')
    try {
      const res = await fetch(`${EXT_CORE}/perception`, { cache: 'no-store', signal: AbortSignal.timeout(9000) })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const data = await res.json()
      if (badge) badge.textContent = data.source || 'local'
      const m = data.models || {}
      for (const kind of ['objects', 'faces']) {
        const info = m[kind] || {}
        perceptionSet(kind, info.present ? (info.loaded ? 'ready' : 'model present, idle') : 'model missing',
          info.error || (info.present ? `${info.bytes} bytes` : 'run a detection to load'),
          `model: ${info.model || 'n/a'}`)
      }
      const perm = data.permission || {}
      perceptionSet('attention', `permission: ${perm.decision || 'unknown'}`,
        `tools: ${(data.tools || []).length} registered`, 'observable signals only')
    } catch {
      perceptionSet('objects', 'core offline', '—', '—')
      perceptionSet('faces', 'core offline', '—', '—')
      perceptionSet('attention', 'core offline', '—', '—')
    }
  }

  async function runPerception(kind) {
    const label = (k) => (k === 'faces' ? 'faces' : k)
    try {
      const res = await fetch(`${EXT_CORE}/perception/run`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind, source: 'camera' }), signal: AbortSignal.timeout(20000)
      })
      const data = await res.json()
      if (res.status === 403) {
        for (const k of ['objects', 'faces', 'attention']) perceptionSet(k, 'permission denied', data.reason || '', '')
        return
      }
      if (data.objects) {
        const o = data.objects
        perceptionSet('objects', o.ok ? `${(o.detections || []).length} object(s)` : 'error',
          o.ok ? (o.summary || '—') + ` · ${o.latency_ms}ms · ${o.source}` : (o.error || ''), '')
      }
      if (data.faces) {
        const f = data.faces
        perceptionSet('faces', f.ok ? `${f.face_count} face(s)` : 'error',
          f.ok ? `${f.latency_ms}ms · ${f.source} · detection only` : (f.error || ''), '')
      }
      if (data.attention) {
        const a = data.attention
        perceptionSet('attention', a.state, `${a.reason} · signals ${JSON.stringify(a.signals || {})}`, '')
      }
    } catch (err) {
      perceptionSet('objects', 'failed', String(err), '')
    }
  }

  function activeViewId() {
    return $('.view.active')?.dataset?.viewPanel || 'dashboard'
  }

  const SIDEBAR_KEY = 'jarvis.sidebar.collapsed'

  // ── collapsed-rail tooltips ────────────────────────────────────────────────
  // The label cannot live in a `::after` here: `.nav-list` is a scroll
  // container and `.sidebar` is a fixed stacking context, so a bubble anchored
  // to a row is clipped the moment it leaves the 58px rail. One shared
  // position:fixed node escapes both. Only shown while collapsed - otherwise
  // the native label is already on screen and the bubble would just be noise.
  function bindNavTooltips() {
    const tip = $('#nav-tip')
    const sidebar = $('#sidebar')
    if (!tip || !sidebar) return
    let current = null
    const show = (el) => {
      if (!el?.dataset?.tip || !document.body.classList.contains('sidebar-collapsed')) return
      const r = el.getBoundingClientRect()
      tip.textContent = el.dataset.tip
      tip.classList.add('show')
      tip.setAttribute('aria-hidden', 'false')
      // Measure after the text is set, then clamp to the viewport so the last
      // item (or the core card) never pushes the bubble off-screen.
      const w = tip.offsetWidth
      const h = tip.offsetHeight
      // Anchor to the rail's outer edge, not the row's - rows are inset by the
      // sidebar padding, and clearing the *rail* is what actually matters.
      const rail = sidebar.getBoundingClientRect()
      const left = Math.min(rail.right + 12, window.innerWidth - w - 10)
      tip.style.left = `${Math.max(8, left)}px`
      tip.style.top = `${Math.min(Math.max(8, r.top + r.height / 2 - h / 2), window.innerHeight - h - 10)}px`
      current = el
    }
    const hide = () => {
      tip.classList.remove('show')
      tip.setAttribute('aria-hidden', 'true')
      current = null
    }
    const targets = () => sidebar.querySelectorAll('.nav-item[data-tip], .core-status[data-tip]')
    targets().forEach((el) => {
      el.addEventListener('mouseenter', () => show(el))
      el.addEventListener('mouseleave', hide)
      // Keyboard parity: the icon-only rail is otherwise unusable by keyboard.
      el.addEventListener('focus', () => show(el))
      el.addEventListener('blur', hide)
    })
    sidebar.addEventListener('scroll', hide, true)
    window.addEventListener('resize', () => { if (current) show(current) })
    document.addEventListener('click', hide)
  }

  function bindSidebarCollapse() {
    const body = document.body
    const button = $('#sidebar-collapse')
    if (!button) return
    // The drawer range (<=1080px) ignores the collapsed class entirely via CSS,
    // so never persist a decision the user could not actually see take effect.
    const isDrawer = () => window.matchMedia('(max-width:1080px)').matches
    const paint = (collapsed) => {
      body.classList.toggle('sidebar-collapsed', collapsed)
      button.setAttribute('aria-expanded', String(!collapsed))
      const verb = collapsed ? 'Expand' : 'Collapse'
      button.setAttribute('aria-label', `${verb} sidebar`)
      button.setAttribute('title', `${verb} sidebar`)
      button.querySelector('svg')?.setAttribute('data-lucide', collapsed ? 'panel-left-open' : 'panel-left-close')
      window.lucide?.createIcons()
    }
    let collapsed = false
    try { collapsed = localStorage.getItem(SIDEBAR_KEY) === '1' } catch {}
    if (!isDrawer()) paint(collapsed)
    button.addEventListener('click', () => {
      collapsed = !body.classList.contains('sidebar-collapsed')
      paint(collapsed)
      try { localStorage.setItem(SIDEBAR_KEY, collapsed ? '1' : '0') } catch {}
    })
    // Ctrl/Cmd+B is the convention users already expect for this.
    document.addEventListener('keydown', (event) => {
      if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 'b') return
      if (isDrawer()) return
      event.preventDefault()
      button.click()
    })
  }

  function bindNavigation() {
    const sidebar = $('#sidebar')
    const backdrop = $('#sidebar-backdrop')
    const close = () => { sidebar.classList.remove('open'); backdrop.classList.remove('open') }
    $('#menu-button')?.addEventListener('click', () => { sidebar.classList.add('open'); backdrop.classList.add('open') })
    $('#sidebar-close')?.addEventListener('click', close)
    backdrop?.addEventListener('click', close)
    document.addEventListener('click', (event) => {
      const target = event.target.closest('[data-view]')
      if (!target) return
      const id = target.dataset.view
      $$('.view').forEach((view) => {
        view.classList.toggle('active', view.dataset.viewPanel === id)
        // Clear any gesture HUD zoom left stuck on a previous view (BUG: scale persisted per-view)
        view.style.removeProperty('--hud-scale')
      })
      window.__JARVIS_GESTURE__?.resetHudScale?.()
      $$('.nav-item').forEach((item) => {
        const isSelf = item.dataset.view === id
        const isParentOfBrain = (id === 'brain' && item.dataset.view === 'settings')
        item.classList.toggle('active', isSelf || isParentOfBrain)
      })
      $$('.nav-subitem').forEach((sub) => {
        const isSubActive = (id === 'brain' && sub.dataset.view === 'brain') ||
                            (id === 'settings' && target === sub)
        sub.classList.toggle('active', Boolean(isSubActive))
      })
      if (id === 'library') loadLibraryUi()
      const settingsParent = event.target.closest('#nav-item-settings')
      const submenu = document.getElementById('nav-settings-submenu')
      if (settingsParent && submenu) {
        submenu.classList.toggle('open')
      }
      if (id === 'brain' && submenu) {
        submenu.classList.add('open')
        try { window.__JARVIS_BRAIN_HOLO__?.resume() } catch (_) {}
      } else if (id !== 'brain') {
        try { window.__JARVIS_BRAIN_HOLO__?.pause() } catch (_) {}
      }
      // Phase 5: the Armour Studio renders only while its view is open, exactly
      // like the hologram pauses when hidden.
      try { window.__JARVIS_ARMOUR__?.onView(id === 'armour') } catch (_) {}
      // Phase 6.3: the fight coach only feeds Pose while its view is open, and
      // it reuses the existing camera stream instead of opening a second one.
      try { window.__JARVIS_FIGHT__?.onView(id === 'fight') } catch (_) {}
      if (target.dataset.settingsTab) {
        const tabBtn = document.querySelector(`.settings-tab[data-settings-tab="${target.dataset.settingsTab}"]`)
        tabBtn?.click()
      }
      close()
      window.scrollTo({ top: 0, behavior: 'smooth' })
    })
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REPOS — GitHub repository workspaces
  //
  // One repo = one workspace. Opening a repository loads its metadata, its
  // full recursive file tree and its README, and every later file read and chat
  // turn is scoped to that repository. Multiple repositories stay open as
  // separate entries in REPOS.open, so "abc" and "xyz" never overwrite each
  // other.
  //
  // The GitHub token is NEVER handled here. This module only calls the local
  // proxy routes, which hold the key server-side. Nothing fetched from GitHub is
  // ever executed — files are displayed as inert text only.
  // ══════════════════════════════════════════════════════════════════════════
  const REPOS = {
    key: 'jarvis.repos.workspaces',
    // Rendered rows per repo. openclaw/openclaw really has 50,653 files, and
    // building that many DOM nodes freezes the dashboard - so the list is
    // capped and the cap is stated in the UI rather than hidden.
    listCap: 600,
    // full_name -> { detail, files, readme, sha, treeTruncated, activeFile,
    //                total, capped, chat[], state }
    // `state` is the load state of the TREE, not of the entry: 'idle' (never
    // fetched since this page loaded), 'loading', 'ready' or 'error'. Metadata
    // is restored from localStorage, so a chip can render before any network
    // call and a reopened page never shows an empty workspace list.
    open: new Map(),
    active: '',
    // Last search, kept so the result cards can be re-rendered when a repo is
    // added or closed and their buttons have to change state. Without this the
    // cards kept saying "Add to workspace" for a repo that was already open.
    results: [],
    // Which of the two panels is in view: 'results' (search list) or
    // 'workspace' (a repo is open). Explicit, so "back" always has a target.
    mode: 'results',
    // Repos the user chose to integrate into the JARVIS codebase, keyed by
    // full_name. This is the "add to jarvis" action - see reposIntegrate().
    integrated: new Map(),
    note: ''
  }

  // A repo name is only ever used as a localStorage key and as a display label;
  // it is never concatenated into a URL on this side (the server validates it).
  const REPO_NAME_RE = /^[^/\s\\]+\/[^/\s\\]+$/

  // The small slice of each repo that has to survive a reload: enough to draw
  // the workspace chips and the header without a single GitHub call. The file
  // tree is deliberately NOT persisted - 600 paths per repo would blow the
  // localStorage quota, and it is re-fetched when the workspace is activated.
  const reposSummary = (entry) => ({
    full_name: entry.detail.full_name,
    description: entry.detail.description || '',
    language: entry.detail.language || '',
    stars: entry.detail.stars || 0,
    forks: entry.detail.forks || 0,
    license: entry.detail.license || '',
    default_branch: entry.detail.default_branch || 'main',
    url: entry.detail.url || ''
  })

  const reposBlankEntry = (detail) => ({
    detail,
    files: [],
    readme: '',
    readmeError: '',
    treeError: '',
    sha: '',
    treeTruncated: false,
    activeFile: '',
    total: 0,
    capped: false,
    chat: [],
    state: 'idle'
  })

  const reposPersist = () => {
    try {
      localStorage.setItem(REPOS.key, JSON.stringify({
        version: 1,
        order: [...REPOS.open.keys()],
        active: REPOS.active,
        repos: [...REPOS.open.values()].map(reposSummary)
      }))
    } catch {}
  }

  // Rebuild the workspace list from localStorage on boot. This is what makes
  // "I added a repo and it was gone after refresh" a fixed bug: the identities
  // come back immediately, and the tree is only fetched when a chip is used.
  function reposRestore() {
    let saved = null
    try { saved = JSON.parse(localStorage.getItem(REPOS.key) || 'null') } catch { saved = null }
    if (!saved || !Array.isArray(saved.repos) || !saved.repos.length) return
    for (const repo of saved.repos) {
      const name = String(repo?.full_name || '')
      if (!REPO_NAME_RE.test(name) || REPOS.open.has(name)) continue
      REPOS.open.set(name, reposBlankEntry({
        full_name: name,
        description: String(repo.description || ''),
        language: String(repo.language || ''),
        stars: Number(repo.stars || 0),
        forks: Number(repo.forks || 0),
        license: String(repo.license || ''),
        default_branch: String(repo.default_branch || 'main'),
        url: String(repo.url || '')
      }))
    }
    if (!REPOS.open.size) return
    const order = Array.isArray(saved.order) ? saved.order : []
    // Active only if it survived validation; otherwise the last opened one.
    REPOS.active = REPOS.open.has(String(saved.active || ''))
      ? String(saved.active)
      : (order.slice().reverse().find((name) => REPOS.open.has(name)) || [...REPOS.open.keys()].pop() || '')
    reposRenderOpenTabs()
    if (REPOS.active) reposActivate(REPOS.active, { silent: true })
  }

  // POST, never GET: a GET whose query string contains a dot-extension
  // (path=README.md) is swallowed by Vite's dev-server asset middleware with a
  // bare 404 before it reaches the route. A JSON body cannot be matched that way.
  const reposApi = async (path, payload = {}) => {
    const response = await fetch(`/api/repos/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    const data = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`)
    return data
  }

  const reposFormatSize = (bytes) => {
    if (!bytes) return ''
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`
  }

  const reposFormatCount = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n))

  // Remember the last result set so the cards can be re-drawn after a repo is
  // added or closed - their button label and state depend on REPOS.open.
  function reposRenderResults(items, note) {
    const host = $('#repos-results')
    if (!host) return
    REPOS.results = Array.isArray(items) ? items : []
    REPOS.note = note || ''
    $('#repos-search-note').textContent = note
    if (!REPOS.results.length) { host.innerHTML = '<p class="panel-note">No repositories matched.</p>'; return }
    host.innerHTML = REPOS.results.map((repo) => {
      const isOpen = REPOS.open.has(repo.full_name)
      const isActive = isOpen && REPOS.active === repo.full_name
      const isIntegrated = REPOS.integrated.has(repo.full_name)
      return `
      <article class="repo-card${isActive ? ' is-active' : ''}" data-repo="${escapeHtml(repo.full_name)}">
        <header class="repo-card-head">
          <span class="repo-icon"><i data-lucide="git-branch"></i></span>
          <div class="repo-card-title">
            <strong>${escapeHtml(repo.full_name)}</strong>
            ${repo.language ? `<span class="repo-lang">${escapeHtml(repo.language)}</span>` : ''}
          </div>
          ${isIntegrated ? '<span class="repo-open-flag"><i data-lucide="check"></i>In JARVIS</span>' : isOpen ? '<span class="repo-open-flag"><i data-lucide="check"></i>In workspace</span>' : ''}
        </header>
        <p class="repo-card-desc">${escapeHtml(repo.description || 'No description provided.')}</p>
        <footer class="repo-card-foot">
          <span class="repo-stat"><i data-lucide="star"></i>${reposFormatCount(repo.stars)}</span>
          <span class="repo-stat"><i data-lucide="git-fork"></i>${reposFormatCount(repo.forks)}</span>
          <button type="button" class="primary-button" data-open-repo="${escapeHtml(repo.full_name)}">${isActive ? 'Show workspace' : isOpen ? 'Open workspace' : 'Add to workspace'}</button>
          <button type="button" class="text-button repo-integrate-btn" data-integrate-repo="${escapeHtml(repo.full_name)}" title="${isIntegrated ? 'Remove this repository from JARVIS integrations' : 'Add this repository to JARVIS integrations'}"><i data-lucide="${isIntegrated ? 'unplug' : 'plug'}"></i>${isIntegrated ? 'In JARVIS' : 'Add to JARVIS'}</button>
        </footer>
      </article>`
    }).join('')
    window.lucide?.createIcons()
  }

  // ── view state ──────────────────────────────────────────────────────────────
  // 'results' = the GitHub search list is what the user is looking at.
  // 'workspace' = a repository is open and its files/README/chat are in view.
  //
  // This existed implicitly before and was the reason there was "no back button":
  // both panels rendered one after the other, so after a search the only "back"
  // control lived inside the workspace - which was not visible from the results.
  // Now the mode is explicit and BOTH panels carry a way back.
  function reposSetMode(mode) {
    REPOS.mode = mode === 'workspace' ? 'workspace' : 'results'
    const results = $('#repos-search-panel')
    const workspace = $('#repos-workspace')
    const nav = $('#repos-panel-nav')
    const rail = $('.repos-open-panel')
    if (nav) nav.hidden = REPOS.mode !== 'results'
    if (results) results.hidden = REPOS.mode !== 'results'
    if (rail) rail.hidden = REPOS.mode !== 'results'
    // The workspace panel's own visibility stays governed by whether a repo is
    // actually open, so "back" cannot leave a blank panel behind.
    if (workspace && !workspace.hidden) {
      workspace.hidden = REPOS.mode !== 'workspace' || !REPOS.open.get(REPOS.active)
    }
    window.lucide?.createIcons()
  }

  // Leave the workspace view and return to whatever is behind it: the last
  // search results if there were any, otherwise the open-workspaces rail.
  function reposBackToResults() {
    REPOS.mode = 'results'
    reposSetMode('results')
    const host = $('#repos-results')
    if (host) host.scrollIntoView({ block: 'start', behavior: 'smooth' })
    else $('#repos-open-tabs')?.scrollIntoView({ block: 'center', behavior: 'smooth' })
  }

  // ── Workspace switcher ─────────────────────────────────────────────────────
  // Every open repo is a chip. This is the affordance that was missing: the
  // second repo replaced the first on screen and there was no way back to the
  // first one except searching for it again and hoping it came back.
  function reposRenderOpenTabs() {
    const host = $('#repos-open-tabs')
    if (!host) return
    $('#repos-open-count').textContent = REPOS.open.size ? String(REPOS.open.size) : '0'
    if (!REPOS.open.size) {
      host.innerHTML = '<p class="panel-note">No repositories open yet. Search above and add one.</p>'
      return
    }
    host.innerHTML = [...REPOS.open.values()].map((entry) => {
      const name = entry.detail.full_name
      const active = name === REPOS.active
      return `
        <div class="repo-tab${active ? ' active' : ''}" data-repo-tab="${escapeHtml(name)}" role="tab" aria-selected="${active}">
          <button type="button" class="repo-tab-main" data-repo-activate="${escapeHtml(name)}" title="${escapeHtml(name)}">
            <i data-lucide="folder-tree"></i>
            <span>${escapeHtml(name)}</span>
            ${entry.state === 'loading' ? '<i data-lucide="loader-2" class="repo-tab-spin"></i>' : ''}
          </button>
          <button type="button" class="repo-tab-close" data-repo-close="${escapeHtml(name)}" aria-label="Remove ${escapeHtml(name)} from workspaces" title="Remove from workspaces">
            <i data-lucide="x"></i>
          </button>
        </div>`
    }).join('')
    window.lucide?.createIcons()
  }

  // Switch to a repo that is already in the list. If its tree has not been
  // fetched yet (a restored entry, or one whose tree failed) it is loaded here
  // rather than leaving an empty Files tab on screen.
  function reposActivate(fullName, { silent = false } = {}) {
    const entry = REPOS.open.get(fullName)
    if (!entry) return
    REPOS.active = fullName
    $('#repos-viewer').hidden = true
    reposRenderOpenTabs()
    reposRenderWorkspace()
    reposSetMode('workspace')
    reposRenderResults(REPOS.results, REPOS.note)
    reposRenderReadme()
    reposRenderChat()
    reposPersist()
    if (entry.state === 'idle' || entry.state === 'error') reposLoad(entry, { force: entry.state === 'error' })
    if (!silent) showToast(`Switched to ${fullName}`)
  }

  // Remove one repository from the workspace list. The tree is re-fetchable
  // from GitHub at any time, so this only drops a local cache entry - it
  // deletes nothing on disk or on GitHub, and the repo can be re-added by
  // searching for it again.
  function reposClose(fullName) {
    const entry = REPOS.open.get(fullName)
    if (!entry) return
    REPOS.open.delete(fullName)
    if (REPOS.active === fullName) {
      // Fall back to the most recently added remaining repo, or to nothing.
      REPOS.active = [...REPOS.open.keys()].pop() || ''
    }
    reposRenderOpenTabs()
    reposRenderWorkspace()
    reposRenderResults(REPOS.results, REPOS.note)
    reposPersist()
    showToast(`Removed ${fullName} from workspaces`)
    // With nothing open the workspace is hidden; say why instead of leaving a
    // blank panel, and drop back to the search list because there is nothing
    // left to show in the workspace.
    if (!REPOS.active) {
      reposSetMode('results')
      const note = $('#repos-search-note')
      if (note) note.textContent = 'No repositories open. Search above to add one.'
    } else {
      const next = REPOS.open.get(REPOS.active)
      if (next && (next.state === 'idle' || next.state === 'error')) reposLoad(next, { force: next.state === 'error' })
    }
  }

  // Fetch the file tree and README for one entry. Metadata is already present
  // (fetched on add, or restored from localStorage), so the workspace header is
  // usable while this is in flight and the Files tab says it is loading.
  async function reposLoad(entry, { force = false } = {}) {
    if (!entry) return
    if (entry.state === 'loading') return
    if (entry.state === 'ready' && !force) return
    const repoName = entry.detail.full_name
    entry.state = 'loading'
    entry.treeError = ''
    if (REPOS.active === repoName) { reposRenderOpenTabs(); reposRenderWorkspace() }
    const [tree, readme] = await Promise.allSettled([
      reposApi('tree', { repo: repoName, ref: entry.detail.default_branch }),
      reposApi('file', { repo: repoName, ref: entry.detail.default_branch, path: 'README.md' })
    ])
    // The user may have switched or closed this repo while it was in flight, so
    // the data lands on the entry (keyed by name, not by position) and the DOM
    // is only written when this repo is still the visible one.
    entry.state = 'ready'
    if (tree.status === 'fulfilled') {
      entry.files = tree.value.files || []
      entry.sha = tree.value.sha || ''
      entry.treeTruncated = Boolean(tree.value.truncated)
      entry.total = Number(tree.value.total ?? entry.files.length)
      entry.capped = Boolean(tree.value.capped)
    } else {
      entry.files = []
      entry.treeError = tree.reason?.message || 'File tree unavailable'
    }
    if (readme.status === 'fulfilled' && readme.value.text) {
      entry.readme = readme.value.text
      entry.readmeError = ''
    } else {
      entry.readme = ''
      // No root README.md is normal for many repos, not an error worth a red
      // toast - say what is missing and move on.
      entry.readmeError = 'This repository has no README.md on its default branch.'
    }
    reposRenderOpenTabs()
    if (REPOS.active !== repoName) return
    reposRenderWorkspace()
    reposRenderReadme()
    reposRenderChat()
    if (tree.status === 'rejected') showToast(entry.treeError, true)
  }

  // README body for the ACTIVE repo only. Rendered from the entry, never from a
  // module-level variable, so switching repos cannot leave repo A's README
  // under repo B's name.
  function reposRenderReadme() {
    const host = $('#repos-readme')
    if (!host) return
    const entry = REPOS.open.get(REPOS.active)
    if (!entry) { host.innerHTML = '<span class="panel-note">Open a repository to read its README.</span>'; return }
    if (entry.readme) { host.innerHTML = `<pre class="repos-code">${escapeHtml(entry.readme)}</pre>`; return }
    if (entry.state === 'loading') { host.innerHTML = '<p class="panel-note">Loading README…</p>'; return }
    host.innerHTML = `<p class="panel-note">${escapeHtml(entry.readmeError || 'No README loaded yet.')}</p>`
  }

  // Repo-scoped chat log. Each repo keeps its OWN transcript so switching back
  // to the first repo shows its conversation, not the second repo's.
  function reposRenderChat() {
    const log = $('#repos-chat-log')
    if (!log) return
    const entry = REPOS.open.get(REPOS.active)
    log.innerHTML = ''
    if (!entry || !entry.chat.length) return
    for (const turn of entry.chat) {
      const item = document.createElement('div')
      item.className = `message ${turn.role}`
      item.innerHTML = `<span class="avatar">${turn.role === 'assistant' ? 'J' : 'P'}</span><p></p>`
      item.querySelector('p').textContent = turn.text
      log.append(item)
    }
    log.scrollTop = log.scrollHeight
  }

  function reposRenderFileList() {
    const host = $('#repos-files')
    if (!host) return
    const entry = REPOS.open.get(REPOS.active)
    if (!entry) return
    const filter = ($('#repos-file-filter')?.value || '').trim().toLowerCase()
    // A tree that failed or has not arrived yet is stated, never rendered as an
    // empty list - "0 files" would read as a fact about the repository.
    if (entry.state === 'loading' && !entry.files.length) {
      $('#repos-file-count').textContent = 'Loading file tree…'
      host.innerHTML = '<p class="panel-note">Loading the file tree from GitHub…</p>'
      return
    }
    if (entry.treeError && !entry.files.length) {
      $('#repos-file-count').textContent = entry.treeError
      host.innerHTML = `<p class="panel-note">${escapeHtml(entry.treeError)}</p>
        <button type="button" class="text-button repo-retry" data-repo-retry="${escapeHtml(entry.detail.full_name)}"><i data-lucide="rotate-cw"></i>Retry</button>`
      window.lucide?.createIcons()
      return
    }
    // `total` is the repo's real file count from the server; `files` is what
    // actually arrived (already capped there). Both are shown, so a capped
    // listing reads as "600 of 50,642" and never as a complete one.
    const total = entry.total ?? entry.files.length
    const files = filter ? entry.files.filter((file) => file.path.toLowerCase().includes(filter)) : entry.files
    const shown = Math.min(files.length, REPOS.listCap)
    const scope = filter
      ? `${files.length} of ${shown} listed match`
      : `${reposFormatCount(total)} file${total === 1 ? '' : 's'}`
    const capped = entry.capped || files.length > REPOS.listCap
    $('#repos-file-count').textContent = [
      scope,
      entry.treeTruncated ? 'GitHub truncated this listing' : null,
      entry.capped ? `listing first ${shown} of ${reposFormatCount(total)} — filter to narrow` : null,
      capped && !entry.capped ? `${files.length - shown} more not rendered` : null,
      entry.sha ? `@ ${entry.sha.slice(0, 7)}` : null
    ].filter(Boolean).join(' · ')
    if (!files.length) { host.innerHTML = '<p class="panel-note">No files matched.</p>'; return }
    // Capped at 600 rows: a 50,000-entry DOM list is what actually makes a
    // dashboard hang, and the filter box is the way past the cap.
    host.innerHTML = files.slice(0, REPOS.listCap).map((file) => `
      <button type="button" class="repo-file" data-repo-file="${escapeHtml(file.path)}" title="${escapeHtml(file.path)}">
        <i data-lucide="file-code"></i><span>${escapeHtml(file.path)}</span>
        <small>${reposFormatSize(file.size)}</small>
      </button>`).join('') + (capped
        ? `<p class="panel-note">${files.length - REPOS.listCap} more not rendered — use the filter to narrow the list.</p>` : '')
    window.lucide?.createIcons()
  }

  function reposRenderWorkspace() {
    const panel = $('#repos-workspace')
    if (!panel) return
    const entry = REPOS.open.get(REPOS.active)
    if (!entry) { panel.hidden = true; return }
    const repo = entry.detail
    panel.hidden = false
    $('#repos-workspace-name').textContent = repo.full_name
    $('#repos-workspace-desc').textContent = repo.description || 'No description provided.'
    $('#repos-workspace-meta').innerHTML = [
      ['star', `${reposFormatCount(repo.stars)} stars`],
      ['git-fork', `${reposFormatCount(repo.forks)} forks`],
      repo.language ? ['code', repo.language] : null,
      repo.license ? ['scale', repo.license] : null,
      ['git-commit-horizontal', repo.default_branch]
    ].filter(Boolean).map(([icon, label]) => `<span class="repo-stat"><i data-lucide="${icon}"></i>${escapeHtml(String(label))}</span>`).join('')
    const link = $('#repos-workspace-link')
    if (repo.url) { link.href = repo.url; link.hidden = false } else link.hidden = true
    $('#repos-chat-context').textContent = `Asking about ${repo.full_name} @ ${repo.default_branch}. JARVIS sees the file you have open plus the README — nothing else.`
    reposRenderFileList()
    window.lucide?.createIcons()
  }

  // Add a repository to the workspace list, or switch to it if it is already
  // there. Metadata is fetched first so the chip and the header appear at once;
  // the tree and README follow through reposLoad. Previously this always
  // re-created the entry, so clicking "Add to workspace" on a repo that was
  // already open silently threw away its loaded file tree.
  async function reposOpen(fullName) {
    const name = String(fullName || '').trim()
    if (!REPO_NAME_RE.test(name)) { showToast('That does not look like owner/repo', true); return }
    const existing = REPOS.open.get(name)
    if (existing) { reposActivate(name); return }
    try {
      const detail = await reposApi('detail', { repo: name })
      // Key on GitHub's canonical name, not on whatever the user clicked.
      const key = detail.full_name || name
      const entry = reposBlankEntry({ ...detail, full_name: key })
      REPOS.open.set(key, entry)
      REPOS.active = key
      $('#repos-viewer').hidden = true
      reposRenderOpenTabs()
      reposRenderWorkspace()
      reposRenderResults(REPOS.results, REPOS.note)
      reposRenderReadme()
      reposRenderChat()
      reposPersist()
      const view = $('[data-view-panel="repos"]')
      if (view && !view.classList.contains('active')) $('.nav-item[data-view="repos"]')?.click()
      reposSetMode('workspace')
      $('#repos-workspace')?.scrollIntoView({ block: 'start', behavior: 'smooth' })
      showToast(`Opened ${key}`)
      await reposLoad(entry)
    } catch (error) {
      const message = error.message || 'Could not open that repository'
      showToast(message, true)
      $('#repos-results')?.insertAdjacentHTML('afterbegin', `<p class="panel-note">${escapeHtml(message)}</p>`)
    }
  }

  // Display one file. The contents go into a <pre> as TEXT, so nothing from a
  // repository can ever become markup or execute as script.
  async function reposShowFile(path) {
    const entry = REPOS.open.get(REPOS.active)
    if (!entry) return
    const repoName = entry.detail.full_name
    $('#repos-code').textContent = 'Loading…'
    $('#repos-viewer-path').textContent = path
    $('#repos-viewer').hidden = false
    try {
      const data = await reposApi('file', { repo: repoName, ref: entry.detail.default_branch, path })
      if (REPOS.active !== repoName) return
      $('#repos-code').textContent = data.binary
        ? (data.note || 'Binary file - not shown as text.')
        : (data.truncated
            ? `${data.text}\n\n… truncated at 400 KB. Open the file on GitHub to read the rest.`
            : data.text)
      entry.activeFile = path
    } catch (error) {
      $('#repos-code').textContent = error.message || 'Could not read that file.'
    }
  }

  // Ask the real AI about the OPEN repository. The file currently open and the
  // README are passed as ground truth, so the answer is grounded in what is
  // actually on screen instead of the model guessing from the repo name. The
  // system message also forbids inventing file contents, because a confident
  // hallucinated answer about someone's code is worse than "I can't tell".
  async function reposAsk(question) {
    const entry = REPOS.open.get(REPOS.active)
    if (!entry) { showToast('Open a repository first', true); return }
    const repoName = entry.detail.full_name
    const log = $('#repos-chat-log')
    // Each turn is appended to THIS repo's transcript as well as the DOM, so
    // switching workspaces and coming back restores the right conversation.
    const push = (role, text) => {
      const item = document.createElement('div')
      item.className = `message ${role}`
      item.innerHTML = `<span class="avatar">${role === 'assistant' ? 'J' : 'P'}</span><p></p>`
      item.querySelector('p').textContent = text
      log.append(item)
      log.scrollTop = log.scrollHeight
      entry.chat.push({ role, text })
      return item
    }
    const setReply = (node, text) => {
      node.querySelector('p').textContent = text
      const last = entry.chat[entry.chat.length - 1]
      if (last && last.role === 'assistant') last.text = text
    }
    push('user', question)
    const reply = push('assistant', 'Reading the code…')
    let context = `Repository: ${repoName} (default branch ${entry.detail.default_branch}).\nDescription: ${entry.detail.description || 'none'}\n`
    if (entry.activeFile) {
      const data = await reposApi('file', { repo: repoName, ref: entry.detail.default_branch, path: entry.activeFile }).catch(() => null)
      if (data?.text) context += `\nThe user has "${entry.activeFile}" open. Contents:\n\`\`\`\n${data.text.slice(0, 12000)}\n\`\`\`\n`
    }
    if (entry.readme) context += `\nREADME excerpt:\n${entry.readme.slice(0, 3000)}\n`
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lang: state.settings.lang || 'auto',
          messages: [
            { role: 'system', content: 'You are JARVIS answering questions about a GitHub repository the user has open. Treat the supplied code and README as ground truth. If the answer is not in that context, say so plainly instead of inventing file contents.' },
            { role: 'user', content: `${context}\n\nQuestion: ${question}` }
          ]
        })
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'The AI provider did not answer')
      setReply(reply, data.reply)
    } catch (error) {
      setReply(reply, `Could not answer: ${error.message}`)
    }
  }

  // ── Add a repository to JARVIS ────────────────────────────────────────────────
// "Add to workspace" opened a read-only browser and nothing more, which is why
// integrating a repo seemed to have no effect. This calls the real server route
// that writes integrations/<owner>__<name>/integration.json, so the repository
// becomes a durable member of this JARVIS install and is re-listed after a
// reload. It stores metadata and file PATHS only - no code is copied in, and
// nothing from the repository is ever executed.
async function reposIntegrate(fullName) {
    const name = String(fullName || '').trim()
    if (!REPO_NAME_RE.test(name)) { showToast('That does not look like owner/repo', true); return }
    const removing = REPOS.integrated.has(name)
    if (!removing && !window.confirm(`Add ${name} to JARVIS?\n\nJARVIS stores the repository metadata and file index so you can search it, open its files and ask about its code. No code is copied into your JARVIS folder and nothing is executed.`)) return
    const button = document.querySelector(`[data-integrate-repo="${CSS.escape(name)}"]`)
    if (button) button.disabled = true
    try {
      if (removing) {
        await reposApi('unintegrate', { repo: name })
        REPOS.integrated.delete(name)
        showToast(`Removed ${name} from JARVIS integrations`)
      } else {
        const data = await reposApi('integrate', { repo: name })
        REPOS.integrated.set(name, data.integration || { full_name: name })
        const count = Number(data.integration?.file_count || 0)
        showToast(`${name} added to JARVIS — ${count} file${count === 1 ? '' : 's'} indexed`)
      }
      reposRenderResults(REPOS.results, REPOS.note)
      reposRenderIntegrations()
    } catch (error) {
      showToast(error.message || 'Could not update the JARVIS integration', true)
    } finally {
      if (button) button.disabled = false
    }
  }

  // The integrated-repositories rail, read back from disk on every load so the
  // list survives a refresh instead of resetting to empty.
  async function reposLoadIntegrations() {
    try {
      const data = await reposApi('integrations', {})
      REPOS.integrated.clear()
      for (const item of (data.items || [])) {
        if (item && REPO_NAME_RE.test(String(item.full_name || ''))) {
          REPOS.integrated.set(String(item.full_name), item)
        }
      }
    } catch { /* no key / server down: the rail says so rather than failing silently */ }
    reposRenderIntegrations()
    if (REPOS.results.length) reposRenderResults(REPOS.results, REPOS.note)
  }

  function reposRenderIntegrations() {
    const host = $('#repos-integrations')
    const count = $('#repos-integrations-count')
    if (!host) return
    if (count) count.textContent = String(REPOS.integrated.size)
    if (!REPOS.integrated.size) {
      host.innerHTML = '<p class="panel-note">No repositories added to JARVIS yet. Search above and use “Add to JARVIS”.</p>'
      return
    }
    host.innerHTML = [...REPOS.integrated.values()].map((item) => `
      <div class="repo-integration-row" data-integration="${escapeHtml(String(item.full_name))}">
        <i data-lucide="plug"></i>
        <button type="button" class="repo-tab-main" data-repo-activate="${escapeHtml(String(item.full_name))}" title="${escapeHtml(String(item.full_name))}">
          <span>${escapeHtml(String(item.full_name))}</span>
          <small>${item.file_count ? `${reposFormatCount(Number(item.file_count))} files` : ''}${item.language ? ` · ${escapeHtml(String(item.language))}` : ''}</small>
        </button>
        <button type="button" class="repo-tab-close" data-unintegrate="${escapeHtml(String(item.full_name))}" aria-label="Remove ${escapeHtml(String(item.full_name))} from JARVIS integrations" title="Remove from JARVIS integrations"><i data-lucide="x"></i></button>
      </div>`).join('')
    window.lucide?.createIcons()
  }

  function bindRepos() {
    // A 503 here is the honest "no key" state. It is stated in the UI rather
    // than swallowed, because a silently dead search box just looks broken.
    fetch('/api/repos/status').then((r) => r.json()).then((data) => {
      const chip = $('#repos-key-chip')
      if (!chip) return
      if (data.configured) {
        chip.textContent = 'GitHub connected'
        chip.classList.remove('offline')
      } else {
        chip.textContent = 'No GitHub key'
        chip.classList.add('offline')
        $('#repos-search-note').textContent = 'GITHUB_API_KEY is not set in .dev.vars. Add a fine-grained token with "Public Repositories: Read", then restart the server.'
        $('#repos-search-btn').disabled = true
      }
    }).catch(() => {})
    $('#repos-search-form')?.addEventListener('submit', async (event) => {
      event.preventDefault()
      const query = $('#repos-search-input').value.trim()
      if (!query) return
      const button = $('#repos-search-btn')
      button.disabled = true
      $('#repos-search-note').textContent = `Searching GitHub for “${query}”…`
      $('#repos-results').innerHTML = '<p class="panel-note">Searching…</p>'
      try {
        const data = await reposApi('search', { q: query })
        reposRenderResults(data.items || [], `${data.total ?? (data.items || []).length} repositories matched “${query}”.`)
      } catch (error) {
        reposRenderResults([], `Search failed: ${error.message}`)
      } finally {
        button.disabled = false
      }
    })
    $('#repos-results')?.addEventListener('click', (event) => {
      // Checked FIRST: the integrate button sits inside the card, so without the
      // early return one click would also fire reposOpen for the same card.
      const integrate = event.target.closest('[data-integrate-repo]')
      if (integrate) { reposIntegrate(integrate.dataset.integrateRepo); return }
      const open = event.target.closest('[data-open-repo]')
      // Return after the button match: the button is inside the card, so
      // falling through would fire reposOpen twice for one click.
      if (open) { reposOpen(open.dataset.openRepo); return }
      const card = event.target.closest('[data-repo]')
      if (card) reposOpen(card.dataset.repo)
    })
    // The integrations rail: open a repo, or drop it from JARVIS.
    $('#repos-integrations')?.addEventListener('click', (event) => {
      const drop = event.target.closest('[data-unintegrate]')
      if (drop) { reposIntegrate(drop.dataset.unintegrate); return }
      const open = event.target.closest('[data-repo-activate]')
      if (open) reposOpen(open.dataset.repoActivate)
    })
    // Workspace chips: switch between repos, or close one. Checked before the
    // tab row because the close button lives INSIDE the chip - without the early
    // return, one click on "x" would also activate the repo it removes.
    $('#repos-open-tabs')?.addEventListener('click', (event) => {
      const close = event.target.closest('[data-repo-close]')
      if (close) { reposClose(close.dataset.repoClose); return }
      const tab = event.target.closest('[data-repo-activate]')
      if (tab) reposActivate(tab.dataset.repoActivate)
    })
    // Remove button in the workspace header. It is a plain close, not a
    // destructive action on the repository: nothing is deleted on GitHub or on
    // disk, and the repo can be re-added from search at any time.
    $('#repos-close-active')?.addEventListener('click', () => {
      if (REPOS.active) reposClose(REPOS.active)
    })
    // Back to the repository list. The workspace is hidden rather than removed,
    // so the chips stay and the same repo can be reopened with one click. The
    // search panel becomes visible again, which is the fix for "no back button
    // after searching": both directions are now reachable from either panel.
    $('#repos-back')?.addEventListener('click', reposBackToResults)
    $('#repos-back-search')?.addEventListener('click', () => {
      // Already showing results; clear the query so the full match list is
      // visible again rather than a narrowed one.
      const input = $('#repos-search-input')
      if (input) input.value = ''
      reposBackToResults()
      const note = $('#repos-search-note')
      if (note && REPOS.results.length) {
        note.textContent = `${REPOS.results.length} repositories shown. Click one to open its workspace.`
      }
      input?.focus()
    })
    $('#repos-file-filter')?.addEventListener('input', reposRenderFileList)
    $('#repos-files')?.addEventListener('click', (event) => {
      const retry = event.target.closest('[data-repo-retry]')
      if (retry) {
        const entry = REPOS.open.get(retry.dataset.repoRetry)
        if (entry) reposLoad(entry, { force: true })
        return
      }
      const file = event.target.closest('[data-repo-file]')
      if (file) reposShowFile(file.dataset.repoFile)
    })
    $('#repos-viewer-close')?.addEventListener('click', () => { $('#repos-viewer').hidden = true })
    $('#repos-tabs')?.addEventListener('click', (event) => {
      const tab = event.target.closest('[data-repos-tab]')
      if (!tab) return
      $$('[data-repos-tab]').forEach((item) => item.classList.toggle('active', item === tab))
      $$('[data-repos-panel]').forEach((panel) => panel.classList.toggle('active', panel.dataset.reposPanel === tab.dataset.reposTab))
    })
    $('#repos-chat-form')?.addEventListener('submit', (event) => {
      event.preventDefault()
      const input = $('#repos-chat-input')
      const question = input.value.trim()
      if (!question) return
      input.value = ''
      reposAsk(question)
    })
    // Bring back the workspaces from the previous session. This runs after the
    // handlers are bound and the DOM is in place; a restored repo whose GitHub
    // key is missing simply shows its error state instead of vanishing.
    reposRestore()
    // Repos the user added to JARVIS itself, read back from disk. Fire-and-
    // forget: the rail renders its own empty state if this fails.
    reposLoadIntegrations()
  }

  // The archive HUD is React + Tailwind, the dashboard is vanilla. Instead of
  // rewriting one into the other, the UI is compiled by
  // scripts/build-library-bundle.cjs and fetched only when this view is opened
  // - same lazy-bundle pattern as armour-bundle.js. Until it mounts, the view
  // says what is missing instead of showing a blank box.
  const libraryLoad = { started: false, ready: false, watch: null }
  // The view sits in .workspace, which reserves 120px at the bottom for the
  // chat dock, and the topbar height changes with the breakpoints. So the
  // height is measured from the real topbar, not guessed in a calc().
  function sizeLibrary() {
    const root = document.getElementById('library-root')
    const bar = $('.topbar')
    if (!root || !bar) return
    const top = bar.getBoundingClientRect().bottom
    root.style.height = `${Math.max(420, Math.round(window.innerHeight - top - 10))}px`
  }
  window.addEventListener('resize', () => {
    if (document.querySelector('.view.active[data-view-panel="library"]')) sizeLibrary()
  })

  function loadLibraryUi() {
    const root = document.getElementById('library-root')
    if (!root) return
    sizeLibrary()
    if (libraryLoad.started) return
    libraryLoad.started = true
    const note = document.getElementById('library-loading')
    const say = (msg) => { if (note) note.textContent = msg }
    const mount = (stamp) => {
      const css = document.createElement('link')
      css.rel = 'stylesheet'
      css.href = '/static/library/library-bundle.css' + (stamp ? '?v=' + encodeURIComponent(stamp) : '')
      document.head.appendChild(css)
      const script = document.createElement('script')
      // The ?v= is the whole point: without it a tab that has the archive open
      // keeps executing the bundle it first fetched, so a rebuild looks like a
      // no-op to the person who asked for it.
      script.src = '/static/library/library-bundle.js' + (stamp ? '?v=' + encodeURIComponent(stamp) : '')
      script.onerror = () => {
        libraryLoad.started = false
        say('Archive bundle not found. Build it once with: node scripts/build-library-bundle.cjs')
      }
      script.onload = () => {
        const api = window.__JARVIS_LIBRARY__
        if (!api || typeof api.mount !== 'function') {
          say('Bundle loaded but it exposes no mount handle - rebuild it.')
          return
        }
        if (note) note.remove()
        api.mount(root)
        libraryLoad.ready = true
        showLibraryBuildBadge(root, stamp)
        watchLibraryBuild(root, stamp)
      }
      document.head.appendChild(script)
    }
    fetch('/static/library/build.json', { cache: 'no-store', signal: AbortSignal.timeout(4000) })
      .then((r) => (r.ok ? r.json() : null))
      .then((b) => mount(b && b.stamp ? String(b.stamp) : ''))
      .catch(() => mount(''))
  }

  // Which build is actually on screen, where he can see it without devtools.
  function showLibraryBuildBadge(root, stamp) {
    // React 19 clears the mount container on its first commit, so the badge goes
    // on the view around it - inside #library-root it was wiped, which is how the
    // "which build am I on?" proof silently disappeared.
    const host = (root && root.parentElement) || document.body
    if (!host || !stamp || host.querySelector('.library-build-badge')) return
    const badge = document.createElement('span')
    badge.className = 'library-build-badge'
    badge.textContent = 'archive build ' + stamp
    host.appendChild(badge)
  }

  // A tab that has been open since before the rebuild must say so instead of
  // quietly running old code - that is how "maine toh bola tha, kuch nahi badla"
  // happens. Poll the stamp; if the disk has a newer one, offer the reload.
  function watchLibraryBuild(root, stamp) {
    if (libraryLoad.watch) return
    libraryLoad.watch = setInterval(async () => {
      if (!document.querySelector('.view.active[data-view-panel="library"]')) return
      let now = ''
      try {
        const r = await fetch('/static/library/build.json', { cache: 'no-store', signal: AbortSignal.timeout(4000) })
        now = r.ok ? String((await r.json()).stamp || '') : ''
      } catch { return }
      if (!now || now === stamp) return
      const host = (root && root.parentElement) || document.body
      if (!host || host.querySelector('.library-stale')) return
      const bar = document.createElement('div')
      bar.className = 'library-stale'
      const label = document.createElement('span')
      label.textContent = 'Purana archive khula hai (build ' + stamp + '). Naya build ' + now + ' disk par hai.'
      const btn = document.createElement('button')
      btn.textContent = 'Reload'
      btn.addEventListener('click', () => location.reload())
      bar.appendChild(label)
      bar.appendChild(btn)
      host.appendChild(bar)
    }, 45000)
  }

  function bindCommands() {
    $('#command-form')?.addEventListener('submit', (event) => {
      event.preventDefault()
      const input = $('#command-input')
      const command = input.value.trim()
      if (command) executeCommand(command)
      input.value = ''
    })
    $('#command-focus')?.addEventListener('click', () => $('#chat-input')?.focus())
    $('#clear-activity')?.addEventListener('click', () => { $('#activity-list').innerHTML = '' })
    document.addEventListener('click', (event) => {
      const target = event.target.closest('[data-command]')
      if (target) executeCommand(target.dataset.command)
    })
    ;['voice-orb', 'dock-mic', 'voice-toggle', 'cowork-mic'].forEach((id) => $(`#${id}`)?.addEventListener('click', toggleVoice))
  }

  async function executeCommand(rawCommand) {
    const command = rawCommand.trim()
    const normalized = command.toLowerCase()
      .replace(/^(?:hey|hi|hello|ok|okay)\s+jarvis[,.]?\s*/i, '')
      .replace(/^(?:हे|हाय|ओके)?\s*(?:जार्विस|जारविस)[,।]?\s*/i, '')
      .replace(/^(?:ねえ|ヘイ|はい|ハイ|オーケー)?\s*(?:ジャービス|ジャーヴィス)[,.、]?\s*/i, '')
    const actionKey = normalized.replace(/\s+/g, ' ')
    if (state.lastAction.key === actionKey && Date.now() - state.lastAction.at < 2500) return showToast('Duplicate command ignored.')
    state.lastAction = { key: actionKey, at: Date.now() }
    // "Open this" / "click this" is a VOICE + GESTURE command: the pointer
    // already selected the target, so the gesture engine activates exactly
    // that control instead of asking the AI to guess. Handled before the core
    // so this two-word phrase never becomes a chat turn.
    const gestureKey = actionKey.replace(/[.!?。、।]+$/g, '').trim()
    const gestureTarget = /^(?:open|click|select|activate|press)\s+(?:this|that)(?:\s+(?:one|button|link|item|control))?$/.test(gestureKey)
      || /^(?:isko|ise|is|ye|yah)\s+(?:kholo|khol|kholen|click\s+karo|select\s+karo|chuno)$/.test(gestureKey)
      || /^(?:यह|यही|इसे|इसको)\s*(?:खोलो|खोलें|खोल|क्लिक करो|क्लिक करें|चुनो|चुनें)$/.test(gestureKey)
      || /^これを(?:開いて|開く|クリック(?:して)?|選択(?:して)?)$/.test(gestureKey)
    if (gestureTarget && window.__JARVIS_GESTURE__) {
      const handled = window.__JARVIS_GESTURE__.activateVoiceTarget('voice')
      if (handled) {
        addMessage('user', command)
        addActivity(command, 'Activated the control selected by gesture')
        setRuntimeState('STANDBY')
        return
      }
      // "this" has no meaning without a live pointer. Fail closed instead of
      // handing the phrase to the AI, which could act on a guessed target.
      showToast('Start hand tracking and point at a control before saying “open this”.', true)
      addActivity(command, 'Ignored: hand tracking is off and “this” has no gesture target')
      return
    }
    if (state.coreOnline) {
      setRuntimeState('EXECUTING')
      addActivity(command, 'Sent to the background JARVIS engine')
      // Tell the core which panel the user is standing in, so a casual reply
      // returns here instead of always jumping to the dashboard.
      const accepted = await sendCoreCommand(command, activeViewId())
      if (accepted) {
        // The core renders this turn itself (it echoes both sides back on
        // /state), so we must not draw it twice - but the transcript and the
        // prompt window are OURS. Without persisting here, a core-handled turn
        // never reached SQLite, so the NEXT message was answered with an empty
        // history and JARVIS said it had no context one message later.
        recordCoreTurn(command)
        return
      }
    }

    addMessage('user', command)
    setRuntimeState('EXECUTING')
    addActivity(command, 'Command received')

    if (state.bridgeOnline) {
      const bridgeResult = await sendBridgeCommand(command)
      if (bridgeResult.handled) return
    }

    const youtubeSearch = normalized.match(/(?:open\s+)?youtube(?:\s+(?:and\s+)?search(?:\s+for)?|\s+(?:pe|par)\s+search(?:\s+karo)?|\s+kholo?\s+(?:aur\s+)?(?:search\s+)?)\s+(.+)|youtube\s+(?:pe|par)\s+(.+?)\s+search\s+karo|यूट्यूब\s*(?:पर|पे)\s*(.+?)\s*(?:सर्च|खोज)(?:\s*करो)?|ユーチューブで(.+?)(?:を検索|検索して)/i)
    if (youtubeSearch) {
      const query = youtubeSearch[1] || youtubeSearch[2] || youtubeSearch[3] || youtubeSearch[4]
      return openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, `Searching YouTube for “${query}”`)
    }

    const webSearch = normalized.match(/(?:search(?:\s+the)?\s+web\s*(?:for|par)?|google(?:\s+search)?(?:\s+for)?|web\s+(?:pe|par)\s+search\s+karo)\s+(.+)|web\s+(?:pe|par)\s+(.+?)\s+search\s+karo|(?:वेब|गूगल)\s*(?:पर|पे)\s*(.+?)\s*(?:सर्च|खोज)(?:\s*करो)?|(?:ウェブ|グーグル)で(.+?)(?:を検索|検索して)/i)
    if (webSearch) {
      const query = webSearch[1] || webSearch[2] || webSearch[3] || webSearch[4]
      return openExternal(`https://www.google.com/search?q=${encodeURIComponent(query)}`, `Searching the web for “${query}”`)
    }

    const sites = {
      youtube: 'https://youtube.com', google: 'https://google.com', gmail: 'https://mail.google.com',
      whatsapp: 'https://web.whatsapp.com', spotify: 'https://open.spotify.com', github: 'https://github.com',
      instagram: 'https://instagram.com', facebook: 'https://facebook.com', linkedin: 'https://linkedin.com',
      reddit: 'https://reddit.com', netflix: 'https://netflix.com', chatgpt: 'https://chatgpt.com',
      gemini: 'https://gemini.google.com', drive: 'https://drive.google.com', maps: 'https://maps.google.com',
      wikipedia: 'https://wikipedia.org', amazon: 'https://amazon.in', flipkart: 'https://flipkart.com',
      stackoverflow: 'https://stackoverflow.com', notion: 'https://notion.so', canva: 'https://canva.com',
      discord: 'https://discord.com/app', twitch: 'https://twitch.tv'
    }
    const japaneseSites = { 'ユーチューブ': 'youtube', 'グーグル': 'google', 'ギットハブ': 'github', 'メール': 'gmail' }
    const japaneseOpen = normalized.match(/^(.+?)(?:を開いて|を開く)$/)
    if (japaneseOpen && japaneseSites[japaneseOpen[1]]) return openExternal(sites[japaneseSites[japaneseOpen[1]]], `Opening ${japaneseSites[japaneseOpen[1]]}`)
    const openMatch = normalized.match(/^(?:open|launch|khol(?:o)?|खोलो?)\s+([\w.-]+)/i)
    if (openMatch && sites[openMatch[1]]) return openExternal(sites[openMatch[1]], `Opening ${openMatch[1]}`)
    const domainMatch = normalized.match(/^(?:open|launch|khol(?:o)?)\s+(?:the\s+)?(?:website\s+)?([a-z0-9-]+\.[a-z]{2,})(?:\s+website)?$/i)
    if (domainMatch) return openExternal(`https://${domainMatch[1]}`, `Opening ${domainMatch[1]}`)
    if (/^https?:\/\//i.test(normalized)) return openExternal(normalized, 'Opening website')

    showToast('Thinking…')
    sendChat(command, true)
  }

  function openExternal(url, message) {
    const opened = window.open(url, '_blank', 'noopener,noreferrer')
    const result = opened ? message : 'Popup blocked. Allow popups for JARVIS.'
    addMessage('assistant', result)
    showToast(result, !opened)
    speak(result)
    setRuntimeState('STANDBY')
  }

  // Returns true only when the CORE has taken ownership of the turn, which means
  // it will echo the user message back on /state and render it itself.
  // A 400/413 means the core REFUSED the input and will never echo it, so we
  // must return false and let executeCommand render the user's own message and
  // answer it through the local chat path. Returning true on rejection is what
  // made a long pasted message disappear from the transcript with only a toast.
  async function sendCoreCommand(command, sourcePanelId = '') {
    try {
      const response = await fetch('http://127.0.0.1:7780/action', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command, source_panel_id: sourcePanelId }), signal: AbortSignal.timeout(2500)
      })
      if (response.status === 429) {
        showToast('JARVIS is busy. Wait for the current reply and retry.', true)
        return true // Do not reroute a rejected command into a second assistant.
      }
      if (!response.ok) {
        // Rejected outright (oversized body, invalid command). Nothing was queued
        // and nothing will be echoed, so hand the turn back to the dashboard: it
        // renders the user's own message and answers it. Safety is unchanged -
        // this still only reaches the allowlisted bridge and the AI chat path, so
        // no arbitrary text can reach a shell.
        const detail = await response.json().catch(() => ({}))
        const why = detail.error === 'invalid_command' ? 'too long' : 'rejected'
        showToast(`Core ${why} that message; answering it in chat instead.`, true)
        return false
      }
      const data = await response.json()
      if (data.ok !== true) showToast('Core did not confirm the command. Check the conversation before retrying.', true)
      // The core already classified it. Apply the focus transition now so the
      // panel moves on the click, not on the next /state poll.
      if (data.target_channel_id) {
        state.channelInfo = { id: data.target_channel_id, guarded: false }
        applyChannelRoute(data.target_channel_id)
      }
      return true
    } catch {
      // A timed-out POST may already have executed. Never replay OS actions
      // through the browser/bridge just because its acknowledgment was lost.
      showToast('Command acknowledgment lost. Check HUD/history before retrying; no duplicate action was sent.', true)
      return true
    }
  }

  async function sendBridgeCommand(command) {
    const url = state.settings.bridgeUrl || 'http://127.0.0.1:7778'
    try {
      const response = await fetch(`${url.replace(/\/$/, '')}/api/action`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command }), signal: AbortSignal.timeout(2200)
      })
      if (!response.ok) return { handled: false }
      const data = await response.json()
      const message = data.message || data.result || 'Action completed.'
      showToast(message)
      addMessage('assistant', message)
      addActivity(command, message)
      speak(message)
      return { handled: data.handled !== false }
    } catch { return { handled: false } }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // UNIVERSAL CENTRAL INPUT ROUTER - frontend receiver
  // ══════════════════════════════════════════════════════════════════════════
  // Mirrors background/intent_router.py. The core classifies every utterance and
  // broadcasts the decision on /state; here we (a) switch the destination view,
  // (b) open the matching tool drawer, (c) flash the target widget, and
  // (d) pipe each reply into ITS OWN panel console instead of the main log.
  //
  // The core remains the single source of truth. This layer only renders what
  // the core already decided - it never classifies on its own and never
  // executes anything, so a UI bug cannot cause an action.
  const CHANNELS = {
    cowork:           { panel: 'COWORK_PANEL',            view: 'cowork',      widget: 'cowork-task',      label: 'Co-work' },
    agent_workspace:  { panel: 'AGENT_WORKSPACE',         view: 'cowork',      widget: 'cowork-files',     label: 'Agent Workspace', drawer: 'files' },
    deep_research:    { panel: 'DEEP_RESEARCH_PANEL',     view: 'web',         widget: 'web-search-form',  label: 'Deep Research' },
    screen_analyzer:  { panel: 'SCREEN_ANALYZER_PANEL',   view: 'vision',      widget: 'vision-grid',      label: 'Screen Analyzer' },
    kamisensei:       { panel: 'KAMISENSEI_PANEL',        view: 'kamisensei',  widget: 'kamisensei-chat-log', label: 'KamiSensei' },
    study_mode:       { panel: 'STUDY_MODE',              view: 'kamisensei',  widget: 'ks-sense-metrics',  label: 'Study Mode', drawer: 'sense' },
    system_health:    { panel: 'SYSTEM_HEALTH_CARD',      view: 'system',      widget: 'mini-system',      label: 'System Health' },
    calendar:         { panel: 'CALENDAR_REMINDER_WIDGET',view: 'productivity',widget: 'reminders-list',   label: 'Calendar & Reminders' },
    voice:            { panel: 'VOICE_PANEL',             view: 'voice',       widget: 'voice-transcript', label: 'Voice Panel' },
    general_chat:     { panel: 'GENERAL_CHAT_PANEL',     view: 'dashboard',   widget: 'chat-log',         label: 'Conversation' }
  }

  // Per-channel reply consoles. Created lazily inside the owning view so a
  // routed answer never lands in the main chat log and streams stay separate.
  const channelLog = (channel) => {
    const meta = CHANNELS[channel] || CHANNELS.general_chat
    if (meta.view === 'dashboard') return $('#chat-log')
    const view = $(`[data-view-panel="${meta.view}"]`)
    if (!view) return null
    let log = $(`#channel-log-${channel}`, view)
    if (log) return log
    log = document.createElement('div')
    log.id = `channel-log-${channel}`
    log.className = 'channel-log'
    log.setAttribute('data-channel', channel)
    log.setAttribute('aria-live', 'polite')
    log.innerHTML = `<div class="channel-log-head"><i data-lucide="corner-down-right"></i><span>${escapeHtml(meta.panel)}</span>` +
      `<button type="button" class="channel-log-toggle" title="Collapse console" aria-label="Collapse console" aria-expanded="true"><i data-lucide="chevron-down"></i></button></div>` +
      `<div class="channel-log-body"></div>`
    // Collapsible: the console floats over the rail, so the user can shrink it
    // to a title bar when it is not the focus of the task.
    log.querySelector('.channel-log-toggle')?.addEventListener('click', (event) => {
      event.stopPropagation()
      const collapsed = log.classList.toggle('collapsed')
      const btn = log.querySelector('.channel-log-toggle')
      const label = collapsed ? 'Expand console' : 'Collapse console'
      btn?.setAttribute('aria-expanded', String(!collapsed))
      btn?.setAttribute('title', label)
      btn?.setAttribute('aria-label', label)
    })
    view.append(log)
    window.lucide?.createIcons()
    return log
  }

  // Append one message into a channel's own console (not the global log).
  function addChannelMessage(channel, role, text) {
    // The Web Intelligence console IS the deep-research panel: the answer
    // renders in its ANSWER zone, so no collapsible block is bolted under it.
    if (channel === 'deep_research' && document.getElementById('rc-answer')) {
      if (role === 'assistant') { _rcReply = String(text || '').slice(0, 1400); renderResearchConsole(_lastCoreData || {}) }
      return null
    }
    const log = channelLog(channel)
    if (!log) return addMessage(role, text)
    const body = $('.channel-log-body', log) || log
    const item = document.createElement('div')
    item.className = `message ${role}`
    item.innerHTML = `<span class="avatar">${role === 'assistant' ? 'J' : 'P'}</span><p></p>`
    item.querySelector('p').textContent = text
    body.append(item)
    log.scrollTop = log.scrollHeight
    return item
  }

  function flashWidget(widgetId, panel) {
    const el = widgetId ? document.getElementById(widgetId) : null
    if (!el) return
    el.classList.remove('channel-flash')
    // Force reflow so a rapid re-route replays the animation.
    void el.offsetWidth
    el.classList.add('channel-flash')
    el.setAttribute('data-active-panel', panel || '')
    setTimeout(() => el.classList.remove('channel-flash'), 1400)
  }

  function openChannelDrawer(drawer, channel) {
    if (!drawer) return
    // KamiSensei study drawer uses its real tab contract (data-ks-tab).
    if (drawer === 'sense') {
      const tab = $('#ks-sense-tab')
      if (tab) { tab.click(); flashWidget('ks-sense-metrics', channel) }
      return
    }
    const rail = $(`[data-cowork-tab="${drawer}"]`)
    if (rail) rail.click()
  }

  // STEP 2: apply the core's focus transition instantly.
  function applyChannelRoute(channel) {
    const meta = CHANNELS[channel]
    if (!meta) return
    // Only switch views for a confident, non-guarded route. Guarded routes
    // (safety-excluded, tool echo, ambiguous) must NOT yank the user away
    // from the panel they are working in.
    const info = state.channelInfo || {}
    if (info.guarded && String(info.id || '') === channel) {
      flashWidget(meta.widget, meta.panel)
      return
    }
    const target = $(`[data-view-panel="${meta.view}"]`)
    if (target && !target.classList.contains('active')) {
      const nav = $(`.nav-item[data-view="${meta.view}"]`)
      if (nav) nav.click()
      else { $$('.view').forEach((v) => v.classList.toggle('active', v.dataset.viewPanel === meta.view)) }
    }
    openChannelDrawer(meta.drawer, channel)
    flashWidget(meta.widget, meta.panel)
  }

  // STEP 3: the /state poll reads channel/channel_revision and renders here.
  function syncChannel(data) {
    const info = data && data.channel
    if (!info || typeof info !== 'object') return
    const id = String(info.id || 'general_chat')
    state.channelInfo = info
    const revision = Number(data.channel_revision || 0)
    if (revision === state.channelRevision) return
    const first = !state.channelRevision
    state.channelRevision = revision
    if (!first) applyChannelRoute(id)
  }

  function bindChat() {
    $('#chat-form')?.addEventListener('submit', (event) => {
      event.preventDefault()
      const input = $('#chat-input')
      const text = input.value.trim()
      if (text) executeCommand(text)
      input.value = ''
    })
    $('#chat-input')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('#chat-form').requestSubmit() }
    })
    $('#clear-chat-button')?.addEventListener('click', clearChat)
    bindChatHistory()
  }

  // ── ChatGPT-style chat history (DB-backed, survives reload + restart) ───────
// History lives in the JARVIS core's SQLite store (D: data root), NOT in
// localStorage. localStorage was per-browser: clearing site data, switching
// browser, or opening the HUD lost every conversation. The core is the single
// source of truth, so the sidebar, the HUD and the voice loop all agree.
//
// The core is async and may be briefly offline, so every helper degrades to an
// empty list rather than throwing. A failed fetch must never break chat.
// Same origin the Memory Core panel uses (declared below at ~line 3461), so
// this literal is intentional: referencing that const here would hit the
// temporal dead zone, because this function is defined before it is declared.
const CONV_CORE_URL = 'http://127.0.0.1:7780'
const ACTIVE_CHAT_KEY = 'jarvis-chat-active'

  async function convRequest(action, body) {
    const res = await fetch(`${CONV_CORE_URL}/conversations${action ? '/' + action : ''}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ surface: 'jarvis', ...(body || {}) })
    })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    return res.json()
  }

  async function chatSessions() {
    try {
      const res = await fetch(`${CONV_CORE_URL}/conversations?surface=jarvis`)
      if (!res.ok) return []
      const body = await res.json()
      return Array.isArray(body.conversations) ? body.conversations : []
    } catch { return [] }
  }

  function activeSessionId() {
    try { return localStorage.getItem(ACTIVE_CHAT_KEY) || '' } catch { return '' }
  }

  // Recall relevant memory from BOTH core stores for this user message.
  //   /memory        -> explicitly remembered facts (Memory Core panel)
  //   /memory/learned-> facts learned from conversations
  // Both are semantic recalls against the live D: stores, so a fact saved in a
  // PREVIOUS chat is still available here. This is what makes cross-chat
  // memory work; the old localStorage read could only ever see the last ~50
  // entries of the current browser profile and went stale on refresh.
  async function recallMemories(query) {
    const out = []
    for (const url of [`${CONV_CORE_URL}/memory`, `${CONV_CORE_URL}/memory/learned`]) {
      try {
        const res = await fetch(url, { signal: AbortSignal.timeout(4000) })
        if (!res.ok) continue
        const body = await res.json()
        const rows = Array.isArray(body?.memories) ? body.memories : []
        // Server returns everything; rank locally with a cheap token overlap so
        // an unrelated memory never crowds out the relevant one.
        const terms = String(query || '').toLowerCase().split(/[^a-z0-9ऀ-ॿ]+/).filter((t) => t.length > 2)
        const scored = rows.map((row) => {
          const text = String(row?.text || '')
          const low = text.toLowerCase()
          const hits = terms.filter((t) => low.includes(t)).length
          // Recent memories get a small nudge so ties prefer the newest.
          return { text, score: hits * 10 + (row?.created_at ? 1 : 0), hits }
        }).filter((r) => r.text)
        const hits = scored.filter((r) => r.hits > 0)
        const pool = hits.length ? hits : scored.slice(0, 3)
        out.push(...pool.map((r) => r.text))
      } catch { /* core offline: answer without memory rather than fail */ }
    }
    return [...new Set(out)].slice(0, 12)
  }

  // Auto-learn the user's own turn. Deliberately NOT awaited: learning must
  // never delay or break the answer the user is waiting for. The route runs
  // the same selective extraction as the MEMORY: token, so "main yaha rehta
  // hun" becomes a durable memory without the model needing to emit anything.
  function learnFromChat(userText) {
    const id = activeSessionId()
    if (!id || !String(userText || '').trim()) return
    convRequest('learn', { id, text: String(userText) }).catch(() => {})
  }

  // The real transcript of the ACTIVE conversation, straight from SQLite.
  // Two pieces for the prompt: the recent window PLUS - when the current
  // message refers back to something older than that window - the few older
  // rows that actually match it ("older messages when needed"). The server
  // keeps the last 10 messages, so when older rows are picked the combined
  // window is trimmed to fit that cap (older picks first, chronologically) -
  // otherwise they would be silently sliced off and never reach the model.
  // Falls back to an empty list so the caller can keep its in-memory window.
  async function conversationWindow(limit = 20, query = '') {
    const id = activeSessionId()
    if (!id) return []
    try {
      const res = await fetch(`${CONV_CORE_URL}/conversations/${encodeURIComponent(id)}?surface=jarvis`,
        { signal: AbortSignal.timeout(4000) })
      if (!res.ok) return []
      const body = await res.json()
      const rows = Array.isArray(body?.messages) ? body.messages : []
      const map = (m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '') })
      const recent = rows.slice(-limit)
      const terms = String(query || '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((t) => t.length > 2)
      if (!terms.length || rows.length <= limit) return recent.map(map)
      // Candidates = rows the server's last-10 cap could never deliver anyway.
      const head = rows.slice(0, Math.max(0, rows.length - 10))
      const scored = head.map((m, idx) => {
        const low = String(m.content || '').toLowerCase()
        return { idx, row: map(m), hits: terms.filter((t) => low.includes(t)).length }
      }).filter((r) => r.hits > 0)
      if (!scored.length) return recent.map(map)
      scored.sort((a, b) => b.hits - a.hits || a.idx - b.idx)
      const older = scored.slice(0, 3).sort((a, b) => a.idx - b.idx).map((r) => r.row)
      return [...older, ...recent.slice(-(10 - older.length)).map(map)]
    } catch { return [] }
  }

  function setActiveSessionId(id) {
    try {
      if (id) localStorage.setItem(ACTIVE_CHAT_KEY, id)
      else localStorage.removeItem(ACTIVE_CHAT_KEY)
    } catch {}
    // Tell the voice core which chat is on screen so its cross-chat recall does
    // not feed the live conversation back into its own prompt. Fire-and-forget:
    // a failure here must never block the UI.
    try {
      fetch(`${CONV_CORE_URL}/conversations/active`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id || '' })
      }).catch(() => {})
    } catch { /* core offline */ }
  }

  // Fire-and-forget: persistence must never block or break the chat UI.
  function persistMessage(role, content) {
    const text = String(content || '').trim()
    if (!text) return
    let id = activeSessionId()
    const run = id
      ? convRequest('message', { id, role, content: text })
      : convRequest('', {}).then((created) => {
          if (created && created.ok && created.id) {
            setActiveSessionId(created.id)
            id = created.id
            return convRequest('message', { id: created.id, role, content: text })
          }
          throw new Error('conversation_create_failed')
        })
    run.then(() => { renderChatHistory() }).catch(() => {})
  }

  function persistCurrentSession() {
    const last = state.messages[state.messages.length - 1]
    if (last) persistMessage(last.role, last.content)
  }

  // Async because the list comes from the core. Re-renders on arrival, so the
    // drawer may paint one frame late while the core answers.
  async function renderChatHistory() {
    const list = $('#chat-history-list')
    if (!list) return
    const sessions = await chatSessions()
    const active = activeSessionId()
    const query = String($('#chat-history-search')?.value || '').trim().toLowerCase()
    const visible = sessions.filter((session) => chatMatches(session, query))
    list.innerHTML = visible.length ? visible.map((s) => `
      <div class="chat-history-item ${s.id === active ? 'active' : ''}" data-chat-session="${escapeHtml(s.id)}">
        <button type="button" class="chat-history-open" title="Open conversation"><i data-lucide="message-square"></i><span>${escapeHtml(s.title || 'New chat')}</span></button>
        <time>${s.updated_at ? relativeTime(s.updated_at) : ''}</time>
        <button type="button" class="chat-history-rename" data-chat-rename="${escapeHtml(s.id)}" title="Rename conversation"><i data-lucide="pencil"></i></button>
        <button type="button" class="chat-history-delete" data-chat-delete="${escapeHtml(s.id)}" title="Delete conversation"><i data-lucide="trash-2"></i></button>
      </div>`).join('') : `<p class="panel-note">${sessions.length ? 'No conversations match that search.' : 'No saved conversations yet.'}</p>`
    if (window.lucide?.createIcons) window.lucide.createIcons()
    renderRailChatHistory(sessions)
  }

  // Restores the EXACT transcript from the database.
  async function loadChatSession(id) {
    if (!id) return
    let body = null
    try {
      const res = await fetch(`${CONV_CORE_URL}/conversations/${encodeURIComponent(id)}?surface=jarvis`)
      if (res.ok) body = await res.json()
    } catch { return }
    if (!body || !body.ok) return
    setActiveSessionId(id)
    state.messages = Array.isArray(body.messages) ? body.messages.map((m) => ({ role: m.role, content: m.content })) : []
    state.coreEventIds = new Set()
    const log = $('#chat-log')
    if (log) {
      log.innerHTML = ''
      if (!state.messages.length) {
        log.innerHTML = '<div class="message assistant"><span class="avatar">J</span><p>Hello, Prateek. Ask me anything or give me a command.</p></div>'
      } else {
        for (const m of state.messages) addMessage(m.role, m.content)
      }
    }
    renderChatHistory()
  }

  function newChatSession() {
    // Flush the live transcript so the previous chat is saved, then start clean.
    for (const m of state.messages) persistMessage(m.role, m.content)
    setActiveSessionId('')
    wipeLocalChat()
    renderChatHistory()
    showToast('New chat started.')
  }

  function deleteChatSession(id) {
    convRequest('delete', { id }).catch(() => {})
    if (activeSessionId() === id) {
      setActiveSessionId('')
      wipeLocalChat()
    }
    renderChatHistory()
  }

  function renameChatSession(id) {
    const next = window.prompt('Rename conversation', '')
    if (!next || !next.trim()) return
    convRequest('rename', { id, title: next.trim() }).then(renderChatHistory).catch(() => {})
  }

  function bindChatHistory() {
    const drawer = $('#chat-history')
    const open = (show) => {
      if (!drawer) return
      drawer.hidden = !show
      $('#chat-history-toggle')?.classList.toggle('active', show)
      if (show) renderChatHistory()
    }
    $('#chat-history-toggle')?.addEventListener('click', () => open(drawer.hidden))
    $('#chat-history-close')?.addEventListener('click', () => open(false))
    $('#chat-new-button')?.addEventListener('click', newChatSession)
    $('#chat-history-list')?.addEventListener('click', (event) => {
      const del = event.target.closest('[data-chat-delete]')
      if (del) { deleteChatSession(del.dataset.chatDelete); return }
      const ren = event.target.closest('[data-chat-rename]')
      if (ren) { renameChatSession(ren.dataset.chatRename); return }
      const item = event.target.closest('[data-chat-session]')
      if (item) loadChatSession(item.dataset.chatSession)
    })
    // Model picker: ChatGPT-style Auto/manual switch, persisted with settings.
    const select = $('#chat-model-select')
    if (select) {
      select.value = state.settings.aiProvider || 'auto'
      select.addEventListener('change', () => {
        state.settings = { ...state.settings, aiProvider: select.value }
        localStorage.setItem('jarvis-settings', JSON.stringify(state.settings))
        const el = $('#ai-provider-select')
        if (el) el.value = select.value
        const label = select.options[select.selectedIndex]?.textContent || 'Auto'
        showToast(`AI model: ${label}`)
      })
    }
    // Restore the last conversation into the log on boot. The id lives in
    // localStorage; the transcript comes from the database, so a reload or a
    // full app restart shows the same conversation again.
    const restoreId = activeSessionId()
    if (restoreId) loadChatSession(restoreId)
  }

  // Centralized Clear Chat. Both the dashboard button and the floating HUD
  // button call this same core endpoint; the voice command is handled inside the
  // canonical core itself, and every UI resyncs through the clear_seq bell.
  async function clearChat() {
    if (state.coreOnline) {
      try {
        await fetch('http://127.0.0.1:7780/clear', { method: 'POST', signal: AbortSignal.timeout(2000) })
      } catch (err) {
        console.debug('[JARVIS] Background clear endpoint unavailable:', err)
      }
    }
    wipeLocalChat()
    showToast('Chat cleared.')
  }

  function wipeLocalChat() {
    state.messages = []
    const log = $('#chat-log')
    if (log) log.innerHTML = '<div class="message assistant"><span class="avatar">J</span><p>Ask me anything or give me a command.</p></div>'
    state.coreEventIds = new Set()
    setRuntimeState('STANDBY')
  }

  // Record a turn the CORE handled, so the transcript and the prompt window
// stay truthful. `executeCommand` returns as soon as the core accepts, and the
// core paints the turn from its own /state events - but only the browser owns
// the SQLite transcript and the `state.messages` window that the next prompt is
// built from. Skipping this made every core-handled turn invisible to the next
// message, which is exactly the "forgot after one message" symptom.
//
// The user side is known now; the assistant side arrives asynchronously on
// /state, so it is claimed by the event pump via `pendingCoreTurn`.
function recordCoreTurn(userText) {
  const text = String(userText || '').trim()
  if (!text) return
  state.pendingCoreTurn = true
  state.messages.push({ role: 'user', content: text })
  persistMessage('user', text)
  learnFromChat(text)
}

// Called by the /state event pump when a core reply lands, so the assistant
// half of a core-handled turn reaches the transcript too. Deduped by the same
// `coreEventIds` gate as rendering, so a turn is never stored twice.
function recordCoreReply(reply) {
  const text = String(reply || '').trim()
  if (!text) return
  state.messages.push({ role: 'assistant', content: text })
  persistMessage('assistant', text)
}

  async function sendChat(text, userAlreadyAdded = false) {
    if (!userAlreadyAdded) addMessage('user', text)
    state.messages.push({ role: 'user', content: text })
      // Persist the user's turn too, so the transcript is complete even if the
      // reply never arrives (core offline, error, or page closed mid-request).
      persistMessage('user', text)
    const loading = addMessage('assistant', 'Thinking…', true)
    try {
      setRuntimeState('THINKING')
      // Memory comes from the CORE (both the explicit jarvis_memory store and
      // the learned store), NOT from a localStorage mirror. Reading localStorage
      // here was the bug that made chat "forget" everything after a refresh or
      // after a memory deleted from the Memory Core panel.
      const memories = await recallMemories(text)
      // Current-chat window from the DB, so a reloaded/older conversation keeps
      // its real history in the prompt instead of only the last 10 in-memory rows.
      // The current message rides along so rows OLDER than the window that refer
      // to it (indirect references) are still pulled in.
      const history = await conversationWindow(20, text)
      // The window used to be read straight off `state.messages`, but both boot
      // paths can swap that array between the two awaits above: /state's wipe
      // (line 3992/4021) replaces it, and loadChatSession (1904) reassigns it. A
      // message typed in the first seconds after load therefore went out with an
      // empty window and the server answered 400 "A message is required" - the
      // dashboard showed "AI is not configured yet" for a perfectly good brain.
      // The question being asked is the one row we hold locally, so it rides
      // along whether or not the array survived.
      const rows = history.length >= 2 ? history : state.messages.slice(-10)
      const window = rows.some((m) => m.role === 'user' && m.content === text)
        ? rows
        : [...rows, { role: 'user', content: text }]
      const response = await fetch('/api/ai/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: window, memories, lang: state.settings.language || 'auto', bridgeOnline: state.bridgeOnline, provider: state.settings.aiProvider || 'auto' }) })
      const data = await response.json()
      const diagnostics = Array.isArray(data.diagnostics) && data.diagnostics.length ? ` (${data.diagnostics.join(', ')})` : ''
      const rawReply = data.reply || `${data.error || 'AI is not configured yet.'}${diagnostics}`
      const actions = parseActionTags(rawReply)
      const reply = stripActionTags(rawReply) || (actions.length ? 'Working on it.' : rawReply)
      loading.querySelector('p').textContent = reply
      if (data.provider) $('#ai-provider').textContent = `AI: ${data.provider}`
      state.messages.push({ role: 'assistant', content: reply })
      persistMessage('assistant', reply)
      // Auto-learn from the user's turn. The /conversations/learn route runs the
      // SAME selective extraction as the MEMORY: token, so a plain sentence like
      // "main yaha rehta hun" is remembered without the model having to remember
      // to emit a token. JARVIS-surface only; study chat is blocked server-side.
      learnFromChat(text)
      speak(reply)
      addActivity(text, data.provider ? `Answered by ${data.provider}` : 'AI response')
      for (const action of actions) await executeTaggedAction(action)
      setRuntimeState('STANDBY')
    } catch {
      loading.querySelector('p').textContent = 'I could not reach the AI service. Check .dev.vars, internet access, then restart JARVIS.'
      setRuntimeState('ERROR')
    }
  }

  function addMessage(role, text, returnElement = false) {
    const item = document.createElement('div')
    item.className = `message ${role}`
    item.innerHTML = `<span class="avatar">${role === 'assistant' ? 'J' : 'P'}</span><p></p>`
    item.querySelector('p').textContent = text
    const log = $('#chat-log')
    if (!log) return undefined
    log.append(item)
    log.scrollTop = log.scrollHeight
    return returnElement ? item : undefined
  }

  function parseActionTags(text) {
    const actions = []
    const pattern = /\[ACTION:([a-z_]+):([^\]]*)\]/gi
    let match
    while ((match = pattern.exec(String(text))) !== null && actions.length < 8) actions.push({ name: match[1].toLowerCase(), param: match[2].trim() })
    return actions
  }

  function stripActionTags(text) {
    return String(text).replace(/\s*\[ACTION:[a-z_]+:[^\]]*\]/gi, '').trim()
  }

  async function executeTaggedAction({ name, param }) {
    setRuntimeState(name === 'answer_web' ? 'SEARCHING' : 'EXECUTING')
    if (name === 'open_url') {
      let url = param
      if (!/^https?:\/\//i.test(url)) url = `https://${url}`
      try { new URL(url) } catch { return showToast('JARVIS rejected an invalid website address.', true) }
      return openExternal(url, 'Opening the requested website')
    }
    if (name === 'youtube_search') return openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(param)}`, `Searching YouTube for “${param}”`)
    if (name === 'web_search') return openExternal(`https://www.google.com/search?q=${encodeURIComponent(param)}`, `Searching the web for “${param}”`)
    if (name === 'answer_web') return fetchSpokenResult(`/api/answer?q=${encodeURIComponent(param)}&lang=${encodeURIComponent(state.settings.language || 'auto')}`, 'Live research complete')
    if (name === 'weather') return fetchSpokenResult(`/api/weather?city=${encodeURIComponent(param)}`, 'Weather updated', formatWeather)
    if (name === 'news') return fetchSpokenResult(`/api/news?category=${encodeURIComponent(param || 'top')}`, 'News updated', formatNews)
    if (name === 'timer') return startTimer(Number(param))
    if (name === 'reminder') {
      const [minutes, ...parts] = param.split('|')
      return createRelativeReminder(Number(minutes), parts.join('|') || 'JARVIS reminder')
    }
    if (name === 'note') return saveNote(param)
    if (name === 'analyze_camera') return analyzeCamera(param)
    const bridgeCommands = {
      screenshot: 'take a screenshot', system_info: 'show system info', lock: 'lock my pc',
      volume: `volume ${param}`, app: `open ${param}`, browser: param, file: param,
      window: param, clipboard: param
    }
    if (bridgeCommands[name]) {
      const result = await sendBridgeCommand(bridgeCommands[name])
      if (!result.handled) showToast('This action needs the Windows local bridge.', true)
    }
  }

  async function fetchSpokenResult(url, activity, formatter = (data) => data.reply || data.error || 'No result available.') {
    try {
      const response = await fetch(url)
      const data = await response.json()
      const message = formatter(data)
      addMessage('assistant', message); addActivity(activity, message); speak(message)
    } catch { showToast('The live service is unavailable.', true) }
  }

  function formatWeather(data) {
    if (data.error) return 'I could not retrieve that weather report.'
    const current = data.current || {}
    return `${data.city || 'That location'} is ${current.temp ?? 'unknown'} degrees Celsius with ${current.humidity ?? 'unknown'} percent humidity.`
  }

  function formatNews(data) {
    const items = Array.isArray(data.items) ? data.items.slice(0, 3) : []
    return items.length ? `Top headlines: ${items.map((item) => item.title).join('. ')}` : 'No headlines are available right now.'
  }

  function startTimer(seconds) {
    const duration = Math.max(1, Math.min(86400, Math.round(seconds || 0)))
    if (!Number.isFinite(duration)) return showToast('That timer duration is invalid.', true)
    const id = Date.now()
    const handle = setTimeout(() => { state.timers.delete(id); showToast('Timer complete.'); speak('Your timer is complete.') }, duration * 1000)
    state.timers.set(id, handle)
    showToast(`Timer set for ${duration} seconds.`)
    addActivity('Timer started', `${duration} seconds`)
  }

  function createRelativeReminder(minutes, text) {
    const delay = Math.max(1, Math.min(43200, Math.round(minutes || 0)))
    const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
    reminders.push({ id: Date.now(), text, time: new Date(Date.now() + delay * 60000).toISOString() })
    localStorage.setItem('jarvis-reminders', JSON.stringify(reminders.slice(-100)))
    renderSavedItems(); showToast(`Reminder set for ${delay} minutes.`)
  }

  function saveNote(text) {
    if (!text) return
    const notes = JSON.parse(localStorage.getItem('jarvis-notes') || '[]')
    notes.unshift({ id: Date.now(), text })
    localStorage.setItem('jarvis-notes', JSON.stringify(notes.slice(0, 50)))
    renderSavedItems(); showToast('Note saved.')
  }

  async function analyzeCamera(question) {
    // Prefer the feed that is actually on screen (dashboard rail/workspace or
    // the Vision System view) so a hidden video can never abort vision.
    const video = $('.view.active video.camera-feed') || $('#camera-feed')
    if (!state.cameraStream || !video?.videoWidth) return showToast('Start the camera before using vision.', true)
    const canvas = document.createElement('canvas'); canvas.width = video.videoWidth; canvas.height = video.videoHeight
    canvas.getContext('2d').drawImage(video, 0, 0)
    try {
      const response = await fetch('/api/vision', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image: canvas.toDataURL('image/jpeg', .72), question, lang: state.settings.language || 'auto' }) })
      const data = await response.json(); const reply = data.reply || 'Vision analysis failed.'
      addMessage('assistant', reply); speak(reply)
    } catch { showToast('Vision service is unavailable.', true) }
  }

  async function toggleVoice() {
    if (state.coreOnline) {
      try {
        const response = await fetch('http://127.0.0.1:7780/listen', { method: 'POST', signal: AbortSignal.timeout(2500) })
        if (response.status === 503) return showToast('Microphone is not ready. Run npm run jarvis:doctor and check Windows microphone permissions.', true)
        if (!response.ok) throw new Error('Core rejected listen request')
        setRuntimeState('LISTENING')
        return showToast('Listening — speak your command now. No wake word needed for 10 seconds.')
      } catch {
        return showToast('Voice engine unavailable. Check jarvis-voice logs.', true)
      }
    }
    if (state.settings.voiceProvider === 'cloud' || (state.settings.language || 'auto') === 'auto') return toggleCloudVoice()
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) return showToast('Speech recognition is not supported in this browser. Use Chrome or Edge.', true)
    if (state.listening && state.recognition) { state.manualVoiceStop = true; return state.recognition.stop() }
    // User-initiated start: clear any permanent mic denial so a retry is
    // possible once permission has actually been granted in site settings.
    state.manualVoiceStop = false
    state.micBlocked = false
    state.micBlockedNotified = false
    const recognition = new SpeechRecognition()
    const speechLocales = { auto: 'en-IN', en: 'en-US', hi: 'hi-IN', hinglish: 'en-IN', ja: 'ja-JP' }
    recognition.lang = speechLocales[state.settings.language || 'auto'] || 'en-IN'
    recognition.interimResults = true
    // Wake mode defaults to ON everywhere else in the app (`wake !== false`),
    // so continuous listening must follow the same convention — an undefined
    // setting previously disabled continuous mode while the UI showed wake ON.
    recognition.continuous = state.settings.wake !== false
    recognition.onstart = () => setListening(true)
    recognition.onend = () => {
      setListening(false)
      // not-allowed / service-not-allowed end the stream with micBlocked set,
      // so auto-restart stays off until the user re-arms it from the mic button.
      if (state.settings.wake !== false && !state.manualVoiceStop && !state.micBlocked) setTimeout(() => {
        try { recognition.start() } catch (err) { console.debug('[JARVIS] Speech recognition restart skipped:', err) }
      }, 450)
    }
    recognition.onerror = (event) => {
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        // Permanent browser denial: never auto-retry, never toast-flood.
        state.micBlocked = true
        if (!state.micBlockedNotified) {
          state.micBlockedNotified = true
          showToast('Microphone access denied — click the site-permission icon in the address bar, allow the microphone, then click the mic button again.', true)
        }
        return
      }
      if (!['no-speech', 'aborted'].includes(event.error)) showToast(`Voice error: ${event.error}`, true)
    }
    recognition.onspeechstart = () => {
      if (state.activeAudio) { state.activeAudio.pause(); state.activeAudio = null; setRuntimeState('INTERRUPTED') }
      if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel()
        setRuntimeState('INTERRUPTED')
      }
    }
    recognition.onresult = (event) => {
      const transcript = [...event.results].map((result) => result[0].transcript).join('')
      $('#voice-transcript').textContent = transcript
      $('#voice-hint').textContent = transcript
      if (event.results[event.results.length - 1].isFinal) {
        const hasWakeWord = /hey\s+jarvis|(?:हे|हाय|ओके)?\s*(?:जार्विस|जारविस)|(?:ねえ|ヘイ|はい|ハイ)?\s*(?:ジャービス|ジャーヴィス)/i.test(transcript)
        if (state.settings.wake === false || hasWakeWord) executeCommand(transcript)
        else $('#voice-hint').textContent = 'Say “Hey JARVIS” before your command'
      }
    }
    state.recognition = recognition
    recognition.start()
  }

  async function toggleCloudVoice() {
    if (state.mediaRecorder?.state === 'recording') return state.mediaRecorder.stop()
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return showToast('Cloud voice recording is unavailable in this browser.', true)
    try {
      if (state.activeAudio) { state.activeAudio.pause(); state.activeAudio = null; setRuntimeState('INTERRUPTED') }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const chunks = []
      const recorder = new MediaRecorder(stream)
      state.mediaRecorder = recorder; state.recordingStream = stream
      recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data) }
      recorder.onstop = async () => {
        setListening(false); stream.getTracks().forEach((track) => track.stop())
        setRuntimeState('THINKING')
        const form = new FormData(); form.append('audio', new Blob(chunks, { type: recorder.mimeType || 'audio/webm' }), 'voice.webm')
        form.append('language', state.settings.language || 'auto')
        try {
          const response = await fetch('/api/stt', { method: 'POST', body: form })
          const data = await response.json()
          if (!data.text) throw new Error(data.error || 'empty')
          $('#voice-transcript').textContent = data.text
          executeCommand(data.text)
        } catch { showToast('Cloud speech recognition failed. Check your Groq key.', true); setRuntimeState('ERROR') }
      }
      recorder.start(); setListening(true); showToast('Listening — tap again when finished.')
    } catch { showToast('Microphone permission was denied.', true) }
  }

  function setListening(value) {
    state.listening = value
    $('#voice-orb')?.classList.toggle('listening', value)
    // Co-work does not paint the global topbar, so the mirrored mic button in
    // its heading must carry the same live state - otherwise the page would
    // claim to be idle while the microphone is actually open.
    $('#cowork-mic')?.classList.toggle('listening', value)
    setRuntimeState(value ? 'LISTENING' : 'STANDBY')
    $('#voice-toggle').innerHTML = value ? '<i data-lucide="square"></i> Stop listening' : '<i data-lucide="mic"></i> Start listening'
    if (window.lucide) window.lucide.createIcons()
  }

  function detectScriptLangs(text) {
    const has = (re) => re.test(text)
    const devanagari = has(/[\u0900-\u097F]/)
    const japanese = has(/[\u3040-\u30FF\u4E00-\u9FFF\uF900-\uFAFF]/)
    const latin = has(/[A-Za-z]/)
    const langs = []
    if (devanagari) langs.push('hi')
    if (japanese) langs.push('ja')
    if (latin) langs.push('en')
    return langs
  }
  async function speak(text) {
    if (state.settings.speak === false) return
    // When the background voice engine is online, it handles high-fidelity audio output
    // directly through system speakers. Suppress browser double-speech and robotic overlap!
    if (state.coreOnline) return

    const safeText = String(text)
      .replace(/\[ACTION:[a-z_]+:[^\]]*\]/gi, ' ')
      .replace(/```[\s\S]*?```/g, ' code omitted ')
      .replace(/`([^`\n]+)`/g, '$1')
      .replace(/\b(?:https?:\/\/|www\.)\S+/gi, 'the requested website')
      .replace(/(?:[A-Za-z]:[\\/]|\\\\)[^\s,;]+/g, 'the file')
      .replace(/\/(?:home|usr|var|tmp|opt|etc)\/[^\s,;]+/g, 'the file')
      .replace(/[`*_#>{}\[\]\\|~]/g, ' ')
      .replace(/\s+/g, ' ')
      .slice(0, 700).trim()
    if (!safeText) return
    if (state.settings.ttsProvider === 'elevenlabs' || detectScriptLangs(safeText).length > 1) {
      try {
        setRuntimeState('SPEAKING')
        const response = await fetch('/api/tts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: safeText, lang: state.settings.language || 'auto' }) })
        if (!response.ok) throw new Error()
        const audio = new Audio(URL.createObjectURL(await response.blob()))
        state.activeAudio = audio
        const muteBtn = $('#kamisensei-mute-btn')
        if (muteBtn) muteBtn.hidden = false
        audio.onended = () => { state.activeAudio = null; if (muteBtn) muteBtn.hidden = true; setRuntimeState(state.listening ? 'LISTENING' : 'STANDBY') }
        await audio.play(); return
      } catch { showToast(detectScriptLangs(safeText).length > 1 ? 'Multilingual voice offline; using browser voice (pronunciation may vary).' : 'Cloud voice unavailable; using browser voice.') }
    }
    if (!('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(safeText)
    const localeMap = { en: 'en-US', hi: 'hi-IN', hinglish: 'hi-IN', ja: 'ja-JP', auto: 'en-IN' }
    utterance.lang = localeMap[state.settings.language || 'auto'] || 'en-IN'
    utterance.rate = 1.03; utterance.pitch = .92
    const voices = window.speechSynthesis.getVoices() || []
    const langPrefix = utterance.lang.slice(0, 2).toLowerCase()
    const sameLang = voices.filter((v) => v.lang.toLowerCase().startsWith(langPrefix))
    if (!sameLang.length && langPrefix !== 'en') {
      console.warn('[TTS] No native browser voice for', langPrefix, '— avoiding English robot fallback')
      return
    }
    const maleHints = ['male', 'david', 'mark', 'daniel', 'george', 'men', 'hemant', 'madhur', 'ichiro', 'kira', 'guy', 'male en']
    const male = sameLang.find((v) => maleHints.some((h) => v.name.toLowerCase().includes(h)))
        || voices.find((v) => maleHints.some((h) => v.name.toLowerCase().includes(h)) && v.lang.toLowerCase().startsWith(langPrefix))
    utterance.voice = male || sameLang[0] || null
    utterance.onstart = () => { setRuntimeState('SPEAKING'); const muteBtn = $('#kamisensei-mute-btn'); if (muteBtn) muteBtn.hidden = false }
    utterance.onend = () => { setRuntimeState(state.listening ? 'LISTENING' : 'STANDBY'); const muteBtn = $('#kamisensei-mute-btn'); if (muteBtn) muteBtn.hidden = true }
    window.speechSynthesis.speak(utterance)
  }

  function bindWebSearch() {
    // The console does not open a browser tab any more: whatever is typed here
    // goes down the SAME command path as speech, so what he sees in the panel
    // is what the engine actually ran.
    $('#web-search-form')?.addEventListener('submit', (event) => {
      event.preventDefault()
      const query = String($('#web-search-input')?.value || '').trim()
      if (!query) return showToast('Enter a search query.', true)
      _rcReply = ''
      executeCommand('search the web for ' + query + ' in ' + _rcLang)
      $('#web-search-input').value = ''
    })
    $('#rc-deep-btn')?.addEventListener('click', () => {
      const query = String($('#web-search-input')?.value || '').trim()
      if (!query) return showToast('Enter a topic to research.', true)
      _rcReply = ''
      const base = _rcTier === 'search' ? 'quick research ' + query
        : _rcTier === 'exhaustive' ? 'research poora internet about ' + query
          : 'research ' + query
      // The trailing phrase is what the core's own style parser reads, so the
      // UI never invents a second protocol for choosing the output language.
      executeCommand(base + ' in ' + _rcLang)
    })
    $$('.rc-filter').forEach((btn) => btn.addEventListener('click', () => {
      _rcFilter = btn.dataset.filter || 'ALL'
      $$('.rc-filter').forEach((x) => x.classList.toggle('active', x === btn))
      renderResearchConsole(_lastCoreData || {})
    }))
    $$('.rc-lang').forEach((btn) => btn.addEventListener('click', () => {
      _rcLang = btn.dataset.lang || 'hinglish'
      $$('.rc-lang').forEach((x) => x.classList.toggle('active', x === btn))
    }))
    $$('.rc-tier').forEach((btn) => btn.addEventListener('click', () => {
      _rcTier = btn.dataset.tier || 'deep'
      $$('.rc-tier').forEach((x) => x.classList.toggle('active', x === btn))
    }))
  }

  // ── Camera + two-hand gesture control ────────────────────────────────
  // app.js owns the ONE camera stream and the UI entry points. Landmark
  // interpretation, pointer motion, deterministic gestures, custom mappings
  // and diagnostics live in gesture-control.js, published as
  // window.__JARVIS_GESTURE__. This block is the only bridge between them:
  // it never opens a second camera, never calls the AI and never sends
  // arbitrary shell text.
  let gestureControl = null
  const HUD_SCALE_MIN = 0.8
  const HUD_SCALE_MAX = 1.45

  function gesturePanels() { return $$('[data-gesture-panel]') }

  // Several views own a camera feed. Prefer one that is actually painted:
  // MediaPipe cannot read pixels from a display:none video.
  function activeGesturePanel() {
    const panels = gesturePanels()
    const visible = panels.filter((panel) => panel.getClientRects().length > 0)
    return visible.find((panel) => panel.closest('.view')?.classList.contains('active'))
      || visible[0] || panels[0] || null
  }

  function gestureVideoFor(panel) {
    const target = panel || activeGesturePanel()
    const candidates = [
      target?.querySelector('video.camera-feed'),
      ...(target?.closest('.view')?.querySelectorAll('video.camera-feed') || []),
      ...$$('.view.active video.camera-feed'),
      $('#camera-feed'),
      $('video.camera-feed')
    ].filter(Boolean)
    return candidates.find((video) => video.getClientRects().length > 0) || candidates[0] || null
  }

  // Two views own a camera power button and the gesture console owns a third.
  function setCameraPowerLabels(live) {
    const html = live ? '<i data-lucide="camera-off"></i> Stop camera' : '<i data-lucide="camera"></i> Start camera'
    $$('#camera-toggle, #camera-power-toggle, #gesture-camera-power').forEach((button) => {
      button.innerHTML = html
      button.setAttribute('aria-label', live ? 'Stop camera' : 'Start camera')
    })
    if (window.lucide) window.lucide.createIcons()
  }

  async function startCamera(deviceId) {
    if (state.cameraStream) return true
    if (!navigator.mediaDevices?.getUserMedia) {
      showToast('This browser does not expose a camera API.', true)
      return false
    }
    const video = { width: { ideal: 1280 }, height: { ideal: 720 } }
    if (deviceId) video.deviceId = { exact: deviceId }
    else video.facingMode = 'user'
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video, audio: false })
      state.cameraStream = stream
      stream.getVideoTracks()[0]?.addEventListener('ended', () => {
        // The user or Windows closed the camera. Never leave a mouse button
        // held down; the controller releases it before reporting the loss.
        if (state.cameraStream !== stream) return
        state.cameraStream = null
        gesturePanels().forEach((panel) => panel.classList.remove('active'))
        setCameraPowerLabels(false)
        gestureControl?.handleCameraLost('Camera disconnected. Gesture control stopped; mouse buttons were released.')
      })
      $$('video.camera-feed').forEach((node) => { node.srcObject = stream; node.play?.().catch(() => {}) })
      gesturePanels().forEach((panel) => panel.classList.add('active'))
      setCameraPowerLabels(true)
      return true
    } catch {
      showToast('Camera permission was denied or unavailable.', true)
      return false
    }
  }

  async function ensureCamera() {
    if (state.cameraStream) return true
    return startCamera(gestureControl?.settings?.cameraId || '')
  }

  function stopCamera() {
    const stream = state.cameraStream
    state.cameraStream = null
    if (gestureControl?.active) gestureControl.stop({ silent: true })
    if (stream) stream.getTracks().forEach((track) => track.stop())
    $$('video.camera-feed').forEach((node) => { node.srcObject = null })
    gesturePanels().forEach((panel) => panel.classList.remove('active'))
    setCameraPowerLabels(false)
  }

  async function toggleCamera() {
    if (state.cameraStream) {
      stopCamera()
      return false
    }
    return startCamera()
  }

  function bridgeMouse(body) {
    const url = (state.settings.bridgeUrl || 'http://127.0.0.1:7778').replace(/\/$/, '')
    return fetch(`${url}/api/mouse`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      // The bridge answers only after the PowerShell input worker acked the
      // command, so this covers a real round trip, not a queued request.
      body: JSON.stringify(body), signal: AbortSignal.timeout(2500)
    }).then(async (response) => {
      const result = await response.json().catch(() => null)
      if (result && typeof result.ok === 'boolean') return result
      return { ok: false, error: response.ok ? 'the bridge returned no result' : `the bridge answered HTTP ${response.status}` }
    }).catch(() => ({ ok: false, error: 'Windows bridge unreachable; no mouse action was sent.' }))
  }

  function bridgeAction(command) {
    const url = (state.settings.bridgeUrl || 'http://127.0.0.1:7778').replace(/\/$/, '')
    return fetch(`${url}/api/action`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command }), signal: AbortSignal.timeout(3000)
    }).then((response) => response.json().catch(() => ({ handled: false })))
      .catch(() => ({ handled: false, message: 'Windows bridge unreachable; no action was sent.' }))
  }

  function uiRequest(payload) {
    const url = (state.settings.bridgeUrl || 'http://127.0.0.1:7778').replace(/\/$/, '')
    return fetch(`${url}/api/ui`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload || {}), signal: AbortSignal.timeout(6000)
    }).then((response) => response.json().catch(() => ({ ok: false, error: 'UI Automation returned no JSON.' })))
      .catch(() => ({ ok: false, error: 'Windows bridge unreachable; UI Automation is offline.' }))
  }

  function applyHudScale(scale) {
    const view = document.querySelector('.view.active') || $('#dashboard-view')
    const clamped = Math.max(HUD_SCALE_MIN, Math.min(HUD_SCALE_MAX, Number(scale) || 1))
    if (view) view.style.setProperty('--hud-scale', clamped.toFixed(3))
    const readout = $('#hud-zoom')
    if (readout) readout.textContent = `${Math.round(clamped * 100)}%`
    return clamped
  }

  function toggleListeningGesture() {
    ($('#voice-orb') || $('#dock-mic') || $('#voice-toggle'))?.click()
  }

  function navSection(step) {
    const items = $$('.nav-item')
    if (!items.length) return
    const index = items.findIndex((btn) => btn.classList.contains('active'))
    const next = items[(((index < 0 ? 0 : index) + step) % items.length + items.length) % items.length]
    next?.click()
  }

  function toggleGestureTracking(panel) {
    return gestureControl?.toggle(panel)
  }

  function stopGestureTracking() {
    gestureControl?.stop()
  }

  // A toggle inside a camera panel tracks that panel; standalone toggles
  // (workspace Gesture pane, Vision tools card, gesture console) resolve to
  // the camera feed actually visible in their own view at click time.
  function panelForGestureButton(btn) {
    return btn.closest('[data-gesture-panel]') || activeGesturePanel()
  }

  function bindCamera() {
    $$('.gesture-toggle').forEach((btn) => {
      if (btn.dataset.gestureBound) return
      btn.dataset.gestureBound = '1'
      btn.addEventListener('click', () => {
        if (!gestureControl) return showToast('Gesture engine did not load. Reload the dashboard.', true)
        // The workspace Gesture pane has no video of its own. Reveal the camera
        // pane first so the one tracker has a painted frame to read.
        if (!state.gestureActive && btn.closest('[data-ws-pane="gesture"]')) setWorkspaceModule('camera', false)
        gestureControl.toggle(panelForGestureButton(btn))
      })
    })
    // init() calls bindCamera twice; the dataset guard keeps the camera power
    // buttons from toggling the stream twice on one click.
    ;[['#camera-toggle', toggleCamera], ['#camera-power-toggle', toggleCamera]].forEach(([selector, handler]) => {
      const button = $(selector)
      if (!button || button.dataset.cameraBound) return
      button.dataset.cameraBound = '1'
      button.addEventListener('click', handler)
    })
  }

  function initGestureControl() {
    if (gestureControl) return
    if (!window.__JARVIS_GESTURE_CONTROL__) {
      console.error('[JARVIS] gesture-control.js did not load; hand tracking is unavailable.')
      return
    }
    gestureControl = window.__JARVIS_GESTURE_CONTROL__.create({
      state,
      showToast,
      ensureCamera,
      startCamera,
      stopCamera,
      toggleCamera,
      videoFor: gestureVideoFor,
      activePanel: activeGesturePanel,
      navigateTo,
      navSection,
      bridgeMouse,
      bridgeAction,
      uiRequest,
      refreshBridge: checkBridge,
      applyHudScale,
      toggleListening: toggleListeningGesture
    })
    gestureControl.init()
    gestureControl.onBridgeStatus(Boolean(state.bridgeOnline), { desktop: state.bridgeDesktop, mouse: state.bridgeMouse })
  }

  function renderModules() {
    Object.entries(moduleData).forEach(([section, modules]) => {
      const root = $(`#${section}-grid`)
      if (!root) return
      root.innerHTML = modules.map(([icon, title, description, command]) => `<article class="panel module-card"><span class="module-icon"><i data-lucide="${icon}"></i></span><h3>${title}</h3><p>${description}</p><button data-command="${command}">Run action →</button></article>`).join('')
    })
    if (window.lucide) window.lucide.createIcons()
    loadModuleMatrix()
  }

  /* ── HONEST MODULES MATRIX ───────────────────────────────────────
     Renders exactly what GET /modules returns from background/capability_registry.py.
     Every card carries a real LIVE / READY / BLOCKED state and the exact reason it
     is in that state. Nothing here is hard-coded or optimistic - if a probe fails,
     the card says so rather than pretending the feature works. */
  let moduleMatrix = null
  let moduleFilter = 'ALL'

  const escModule = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

  // The chip has to read like a sentence, not like a truncated URL. The first
  // version produced "OPEN OPEN WHATSAPP" and "http://127.0.0.1:567" because it
  // pasted the launch target into a fixed 20-char slice.
  function cardActionLabel(launch) {
    const spec = launch || {}
    if (spec.view) return `OPEN ${String(spec.view).toUpperCase()}`
    if (spec.command) {
      const cmd = String(spec.command).trim().replace(/\s+/g, ' ')
      return cmd.split(' ')[0].toLowerCase() === 'open' ? cmd.toUpperCase() : `RUN: ${cmd.toUpperCase()}`
    }
    if (spec.url) return 'OPEN ITS OWN UI'
    return ''
  }

  function renderModuleMatrix() {
    const grid = $('[data-modules-grid]')
    const chip = $('[data-modules-chip]')
    if (!grid) return
    if (!moduleMatrix) { grid.innerHTML = '<p class="modules-empty">Probing live capabilities…</p>'; return }
    const counts = moduleMatrix.counts || {}
    if (chip) {
      chip.textContent = `${counts.LIVE || 0} LIVE · ${counts.READY || 0} READY · ${counts.BLOCKED || 0} BLOCKED`
      chip.classList.toggle('is-live', (counts.LIVE || 0) > 0)
    }
    const rows = (moduleMatrix.capabilities || []).filter(
      (row) => moduleFilter === 'ALL' || row.state === moduleFilter)
    if (!rows.length) { grid.innerHTML = '<p class="modules-empty">No capabilities in this state.</p>'; return }
    grid.innerHTML = rows.map((row) => {
      const reason = escModule(row.reason || '')
      const launch = row.launch || {}
      // The chip is a label, not a second click path - the card itself opens
      // it. Only a real action (n8n's start) gets a button, and that button
      // rides the same [data-command] delegate everything else uses.
      const label = cardActionLabel(launch)
      const chip = label ? `<span class="module-go">${escModule(label)}</span>` : ''
      const start = launch.start
        ? `<button type="button" class="module-start" data-command="${escModule(launch.start)}">Start</button>`
        : ''
      return `<article class="module-card-live" data-state="${escModule(row.state)}" data-module-id="${escModule(row.id)}" data-launch="${escModule(JSON.stringify(launch))}">
        <span class="module-icon"><i data-lucide="${escModule(row.icon)}"></i></span>
        <div class="module-card-body">
          <strong>${escModule(row.name)}</strong>
          <small class="module-desc">${escModule(row.desc || '')}</small>
          <small class="module-reason">${reason}</small>
          ${chip}${start}
        </div>
        <span class="module-state module-state-${escModule(row.state)}">${escModule(row.state)}</span>
        <span class="module-phase">${escModule(row.phase || '')}</span>
      </article>`
    }).join('')
    if (window.lucide) window.lucide.createIcons()
  }

  async function loadModuleMatrix(force) {
    try {
      const res = await fetch(`${EXT_CORE}/modules${force ? '?t=' + Date.now() : ''}`,
        { cache: 'no-store', signal: AbortSignal.timeout(30000) })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      moduleMatrix = await res.json()
      renderModuleMatrix()
    } catch (err) {
      const grid = $('[data-modules-grid]')
      const chip = $('[data-modules-chip]')
      if (grid) grid.innerHTML = `<p class="modules-empty">The JARVIS core did not answer the capability probe in 30s (${escModule(err.message)}). It is slow, not necessarily down - try Re-probe.</p>`
      if (chip) { chip.textContent = 'core offline'; chip.classList.remove('is-live') }
    }
  }

  function bindModuleMatrix() {
    $('#modules-refresh')?.addEventListener('click', () => loadModuleMatrix(true))
    document.addEventListener('click', (e) => {
      const filter = e.target.closest('[data-modules-filter]')
      if (!filter) return
      moduleFilter = filter.dataset.modulesFilter || 'ALL'
      document.querySelectorAll('[data-modules-filter]').forEach(
        (b) => b.classList.toggle('active', b === filter))
      renderModuleMatrix()
    })
    // Clicking a capability card blanks the CONTENT AREA only - the region under
    // the topbar and right of the sidebar, exactly the box he marked. The
    // full-screen version was rejected: it hid the sidebar and the topbar, so
    // there was nothing left to click. The box is measured from the real
    // elements at open time, because the sidebar collapses and the breakpoints
    // move both edges.
    const setBlankPage = (on) => {
      const page = $('#module-blank')
      if (!page) return
      if (on) {
        const bar = $('.topbar'), side = $('#sidebar')
        const barBottom = bar ? bar.getBoundingClientRect().bottom : 0
        const sideBox = side && side.getBoundingClientRect().width > 60 ? side.getBoundingClientRect() : null
        page.style.top = Math.round(barBottom) + 'px'
        page.style.left = Math.round(sideBox ? sideBox.right : 0) + 'px'
      }
      page.hidden = !on
    }
    // A card click now goes where the registry says the feature actually lives:
    // its own view, a spoken command through the one command path, or its own
    // loopback UI. Only a card with nowhere to go shows the blank area - the
    // owner asked for that for the cards that are not connected to anything.
    const cardRow = (id) => (((moduleMatrix || {}).capabilities) || [])
      .find((r) => String(r.id) === String(id))
    const launchCard = (row) => {
      const spec = (row && row.launch) || {}
      if (spec.view) {
        const nav = document.querySelector(`[data-view="${spec.view}"]`)
        if (nav) { nav.click(); return true }
      }
      if (spec.command) { executeCommand(String(spec.command)); return true }
      if (spec.url) { window.open(String(spec.url), '_blank', 'noopener'); return true }
      return false
    }
    document.addEventListener('click', (e) => {
      // A button inside the card (n8n's Start) answers for itself, through the
      // same [data-command] delegate the rest of the app uses.
      if (e.target.closest('[data-command]')) return
      const card = e.target.closest('.module-card-live')
      if (card) {
        if (launchCard(cardRow(card.dataset.moduleId))) { setBlankPage(false); return }
        setBlankPage(true)
        return
      }
      if (e.target.closest('#module-blank')) { setBlankPage(false); return }
      // Switching views must clear it, or the blank would sit over the next page.
      if (e.target.closest('[data-view]')) setBlankPage(false)
    })
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') setBlankPage(false)
    })
  }

  // Co-work deck (OpenClaw-style surfaces): live task / channels / schedule.
  // Renders ONLY real core state — empty registries show an honest empty state,
  // never placeholder rows and never a fake demo turn.
  let coworkActionsBound = false
  function bindCoworkActions() {
    if (coworkActionsBound) return
    const start = $('#cowork-start'), cancel = $('#cowork-cancel')
    const mcpRun = $('#mcp-run'), mcpRefresh = $('#mcp-refresh')
    if (!start && !mcpRun) return
    coworkActionsBound = true
    start?.addEventListener('click', async () => {
      const title = $('#cowork-title')?.value.trim() || 'Dashboard task'
      const stepsRaw = $('#cowork-steps')?.value || ''
      const steps = stepsRaw.split(/[;\n]+/).map((part) => part.trim()).filter(Boolean)
      if (!steps.length) { showToast('Add at least one step, separated by ";".', true); return }
      try {
        const response = await fetch('http://127.0.0.1:7780/cowork/start', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title, steps }), signal: AbortSignal.timeout(8000)
        })
        const payload = await response.json().catch(() => ({}))
        if (!response.ok || payload.ok === false) throw new Error(payload.message || payload.error || 'start failed')
        showToast(payload.message || 'Task started.')
      } catch (error) { showToast(`Co-work start failed: ${error.message || error}`, true) }
    })
    cancel?.addEventListener('click', async () => {
      try {
        await fetch('http://127.0.0.1:7780/cowork/cancel', { method: 'POST', signal: AbortSignal.timeout(8000) })
        showToast('Cancel requested.')
      } catch (error) { showToast(`Cancel failed: ${error.message || error}`, true) }
    })
    mcpRun?.addEventListener('click', async () => {
      const text = $('#mcp-call')?.value.trim() || ''
      const match = /^(?:mcp\s+call\s+)?([\w][\w\-.]{0,80})(?:\.([\w][\w\-.]{0,80}))?(?:\s+(\{.*\}))?\s*$/i.exec(text)
      if (!match) { showToast('Format: mcp call <server>.<tool> {"text": "hello"}', true); return }
      const server = match[1], tool = match[2] || ''
      let args = {}
      try { args = match[3] ? JSON.parse(match[3]) : {} } catch { showToast('Invalid JSON arguments.', true); return }
      if (!tool) { showToast('Name both parts: <server>.<tool>.', true); return }
      try {
        const response = await fetch('http://127.0.0.1:7780/mcp/call', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ server, tool, arguments: args }), signal: AbortSignal.timeout(30000)
        })
        const payload = await response.json().catch(() => ({}))
        if (!response.ok || payload.ok === false) throw new Error(payload.error || 'call failed')
        showToast(`MCP ${server}.${tool}: ${String(payload.text || '').slice(0, 160)}`)
      } catch (error) { showToast(`MCP call failed: ${error.message || error}`, true) }
    })
    mcpRefresh?.addEventListener('click', async () => {
      try {
        await fetch('http://127.0.0.1:7780/mcp/refresh', { method: 'POST', signal: AbortSignal.timeout(8000) })
        showToast('MCP catalog will refresh on the next prompt + poll.')
      } catch (error) { showToast(`Refresh failed: ${error.message || error}`, true) }
    })
    // ── Task workspace: tabs, rail, composer, permission gate, file browser ──
    const tabs = $('#cowork-tabs')
    tabs?.addEventListener('click', (event) => {
      const button = event.target.closest('[data-cowork-tab]')
      if (!button) return
      const name = button.dataset.coworkTab
      tabs.querySelectorAll('.cowork-tab').forEach((el) => el.classList.toggle('active', el === button))
      document.querySelectorAll('[data-cowork-panel]').forEach((panel) => {
        panel.classList.toggle('active', panel.dataset.coworkPanel === name)
      })
      if (name === 'files') loadCoworkFiles()
    })
    const railToggle = $('#cowork-rail-toggle')
    $('#cowork-new-task')?.addEventListener('click', () => {
      $('#cowork-goal')?.focus()
      $('#cowork-workspace')?.scrollTo({ top: 0, behavior: 'smooth' })
    })
    railToggle?.addEventListener('click', () => {
      const workspace = $('#cowork-workspace')
      if (!workspace) return
      const hidden = workspace.classList.toggle('rail-hidden')
      railToggle.textContent = hidden ? 'Show rail' : 'Hide rail'
      railToggle.setAttribute('aria-expanded', String(!hidden))
      localStorage.setItem('jarvis-cowork-rail', hidden ? 'hidden' : 'shown')
    })
    const resizeHandle = $('#cowork-rail-resize')
    resizeHandle?.addEventListener('pointerdown', (event) => {
      const workspace = $('#cowork-workspace')
      if (!workspace) return
      event.preventDefault()
      resizeHandle.setPointerCapture(event.pointerId)
      const onMove = (moveEvent) => {
        const rect = workspace.getBoundingClientRect()
        const width = Math.min(460, Math.max(240, rect.right - moveEvent.clientX))
        workspace.style.setProperty('--cowork-rail-w', `${width}px`)
      }
      const onUp = () => {
        const width = getComputedStyle(workspace).getPropertyValue('--cowork-rail-w').trim()
        if (width) localStorage.setItem('jarvis-cowork-rail-w', width)
        resizeHandle.removeEventListener('pointermove', onMove)
        resizeHandle.removeEventListener('pointerup', onUp)
      }
      resizeHandle.addEventListener('pointermove', onMove)
      resizeHandle.addEventListener('pointerup', onUp)
    })
    const goalStart = $('#cowork-goal-start')
    const startCortexRun = async () => {
      const goal = $('#cowork-goal')?.value.trim() || ''
      if (!goal) { showToast('Describe the task first.', true); return }
      try {
        const response = await fetch('http://127.0.0.1:7780/cortex/start', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ goal }), signal: AbortSignal.timeout(8000)
        })
        const payload = await response.json().catch(() => ({}))
        if (!response.ok || payload.ok === false) throw new Error(payload.message || payload.error || 'start failed')
        showToast(payload.message || 'Agent task started.')
        $('#cowork-goal').value = ''
      } catch (error) { showToast(`Task start failed: ${error.message || error}`, true) }
    }
    goalStart?.addEventListener('click', startCortexRun)
    $('#cowork-goal')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') { event.preventDefault(); startCortexRun() }
    })
    $('#cowork-cancel')?.addEventListener('click', async () => {
      const results = await Promise.allSettled([
        fetch('http://127.0.0.1:7780/cortex/cancel', { method: 'POST', signal: AbortSignal.timeout(8000) }),
        fetch('http://127.0.0.1:7780/cowork/cancel', { method: 'POST', signal: AbortSignal.timeout(8000) })
      ])
      const ok = results.some((r) => r.status === 'fulfilled' && r.value.ok)
      showToast(ok ? 'Stop requested.' : 'Nothing was running.', !ok)
    })
    const sendApproval = async (approve) => {
      try {
        await fetch('http://127.0.0.1:7780/cortex/approve', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ approve }), signal: AbortSignal.timeout(5000)
        })
        showToast(approve ? 'Action approved.' : 'Action denied.')
      } catch (error) { showToast(`Approval failed: ${error.message || error}`, true) }
    }
    $('#cowork-approve')?.addEventListener('click', () => sendApproval(true))
    $('#cowork-deny')?.addEventListener('click', () => sendApproval(false))
    $('#cowork-files-open')?.addEventListener('click', () => loadCoworkFiles($('#cowork-files-input')?.value || '.'))
    $('#cowork-refresh')?.addEventListener('click', async () => {
      try {
        const response = await fetch('http://127.0.0.1:7780/state', { cache: 'no-store', signal: AbortSignal.timeout(2000) })
        renderCowork(await response.json())
        showToast('Workspace state refreshed.')
      } catch (error) { showToast(`Refresh failed: ${error.message || error}`, true) }
    })
    // Restore persisted rail preference (resize width applied inline).
    const savedW = localStorage.getItem('jarvis-cowork-rail-w')
    if (savedW) $('#cowork-workspace')?.style.setProperty('--cowork-rail-w', savedW)
    if (localStorage.getItem('jarvis-cowork-rail') === 'hidden') {
      $('#cowork-workspace')?.classList.add('rail-hidden')
      if (railToggle) { railToggle.textContent = 'Show rail'; railToggle.setAttribute('aria-expanded', 'false') }
    }
  }

  // Read-only repo file browser for the Files tab (delegates to the core's
  // os_executor sandbox — same secrets/escape refusals as the agent itself).
  async function loadCoworkFiles(path) {
    const box = $('#cowork-files')
    if (!box) return
    const target = String(path ?? ($('#cowork-files-input')?.value || '.'))
    const input = $('#cowork-files-input')
    if (input) input.value = target
    box.innerHTML = '<span class="panel-note">Loading…</span>'
    try {
      const response = await fetch(`http://127.0.0.1:7780/files?path=${encodeURIComponent(target)}`, { signal: AbortSignal.timeout(6000) })
      const payload = await response.json().catch(() => ({}))
      if (!response.ok || payload.ok === false) throw new Error(payload.output || payload.error || 'list failed')
      const rows = String(payload.output || '').split('\n').filter(Boolean)
      if (!rows.length) { box.innerHTML = '<span class="panel-note">Folder is empty.</span>'; return }
      box.innerHTML = rows.map((row) => {
        const isDir = row.endsWith('/')
        const name = isDir ? row.slice(0, -1) : row
        const next = (target === '.' || target === '') ? name : `${target}/${name}`
        if (isDir) return `<button type="button" class="cowork-file-row dir" data-cowork-path="${escapeHtml(next)}">▸ ${escapeHtml(name)}</button>`
        return `<button type="button" class="cowork-file-row" data-cowork-read="${escapeHtml(next)}">• ${escapeHtml(name)}</button>`
      }).join('')
      box.querySelectorAll('[data-cowork-path]').forEach((el) => el.addEventListener('click', () => loadCoworkFiles(el.dataset.coworkPath)))
      box.querySelectorAll('[data-cowork-read]').forEach((el) => el.addEventListener('click', async () => {
        const preview = $('#cowork-file-preview')
        if (!preview) return
        preview.hidden = false
        preview.textContent = 'Loading…'
        try {
          const r = await fetch(`http://127.0.0.1:7780/file_read?path=${encodeURIComponent(el.dataset.coworkRead)}`, { signal: AbortSignal.timeout(6000) })
          const p = await r.json().catch(() => ({}))
          preview.textContent = r.ok && p.ok ? String(p.output || '') : String(p.output || p.error || 'Read refused.')
        } catch (error) { preview.textContent = `Read failed: ${error.message || error}` }
      }))
    } catch (error) { box.innerHTML = `<span class="panel-note">Files unavailable: ${escapeHtml(String(error.message || error))}</span>` }
  }
  function formatBytes(size) {
    if (!Number.isFinite(size) || size < 0) return ''
    if (size < 1024) return `${size} B`
    if (size < 1048576) return `${(size / 1024).toFixed(1)} KB`
    return `${(size / 1048576).toFixed(1)} MB`
  }

  function renderCowork(data) {
    const task = data.cowork && typeof data.cowork === 'object' ? data.cowork : {}
    const cortex = data.cortex && typeof data.cortex === 'object' ? data.cortex : {}
    // The workspace header prefers the ACTIVE runner (cortex run > step task),
    // falling back to whichever has real history — never a fabricated default.
    const cortexActive = cortex.status === 'running'
    const taskActive = !!task.running
    const isCortex = cortexActive || (!taskActive && !!cortex.run_id)
    const active = isCortex ? cortex : task
    const steps = Array.isArray(active.steps) ? active.steps : []
    const done = steps.filter((s) => s && s.status === 'done').length
    const failed = steps.filter((s) => s && s.status === 'failed').length
    const rawStatus = String(active.status || 'idle')
    const stateKey = data.cortex_confirm ? 'waiting'
      : ({ running: 'running', done: 'completed', idle: 'idle', failed: 'failed',
           cancelled: 'cancelled', interrupted: 'paused', skipped: 'cancelled' }[rawStatus] || 'idle')
    const titleEl = $('#cowork-task-title')
    if (titleEl) {
      const goal = String(isCortex ? (cortex.goal || '') : (task.title || '')).trim()
      titleEl.textContent = goal || 'No active task'
    }
    const stateEl = $('#cowork-task-state')
    if (stateEl) { stateEl.textContent = stateKey; stateEl.dataset.state = stateKey }
    const agentEl = $('#cowork-task-agent')
    if (agentEl) {
      const agent = rawStatus === 'idle' || !active.status ? '—'
        : isCortex ? 'Cortex planner (Plan→Act→Observe)' : 'Co-work step runner'
      agentEl.textContent = `Agent: ${agent}`
    }
    const stepsEl = $('#cowork-task-steps-count')
    if (stepsEl) stepsEl.textContent = `Steps: ${done}/${steps.length}${failed ? ` (${failed} failed)` : ''}`
    const timeEl = $('#cowork-task-time')
    if (timeEl) {
      const at = Number(isCortex ? cortex.created_at : task.created_at) || 0
      timeEl.textContent = at ? `Started: ${new Date(at * 1000).toLocaleTimeString()}` : 'Started: —'
    }
    const requestEl = $('#cowork-task-request')
    if (requestEl) {
      const goal = String(isCortex ? (cortex.goal || '') : '').trim()
      requestEl.hidden = !goal
      requestEl.textContent = goal ? `Request: ${goal}` : ''
    }
    // Live activity feed — real STATE rows only, newest at the bottom.
    const feed = $('#cowork-activity')
    if (feed) {
      const rows = Array.isArray(data.activity) ? data.activity : []
      feed.innerHTML = rows.length
        ? rows.slice(-60).map((row) => {
          const role = String(row.role || 'agent')
          const time = row.at ? new Date(row.at * 1000).toLocaleTimeString() : ''
          return `<div class="cowork-feed-row" data-role="${escapeHtml(role)}"><span class="cowork-feed-time">${escapeHtml(time)}</span><span>${escapeHtml(String(row.text || ''))}</span></div>`
        }).join('')
        : '<span class="panel-note">No activity yet. Start a task or speak to JARVIS — real events appear here live.</span>'
      feed.scrollTop = feed.scrollHeight
    }
    // Task plan: ordered steps from the active runner (real statuses only).
    const taskBox = $('#cowork-task')
    if (taskBox) {
      const lines = []
      if (steps.length) {
        const glyph = (status) => status === 'done' ? '✔' : status === 'running' ? '▶' : status === 'failed' ? '✖' : status === 'skipped' ? '⤼' : '•'
        steps.slice(0, 16).forEach((step) => {
          if (!step) return
          const label = String(step.title || step.tool || step.text || '').trim()
          if (!label) return
          const status = String(step.status || '')
          const output = String(step.output || step.result || '').trim().replace(/\n/g, ' ')
          lines.push(`<div class="cowork-plan-step" data-status="${escapeHtml(status)}"><span class="cowork-plan-glyph">${glyph(status)}</span><span class="cowork-plan-label">${escapeHtml(label)}</span><span class="cowork-plan-status">${escapeHtml(status || 'pending')}</span>${output ? `<span class="cowork-plan-output">${escapeHtml(output.slice(0, 200))}</span>` : ''}</div>`)
        })
      } else {
        lines.push('<span class="panel-note">No task plan yet. Describe a task below or say “cowork chalao …”.</span>')
      }
      taskBox.innerHTML = lines.join('')
    }
    // Permission gate (confirm-gated tools park here until approve/deny).
    const confirmBox = $('#cowork-confirm')
    if (confirmBox) {
      const pending = data.cortex_confirm && typeof data.cortex_confirm === 'object' ? data.cortex_confirm : null
      confirmBox.hidden = !pending
      if (pending) {
        const text = $('#cowork-confirm-text')
        if (text) text.textContent = `Permission required: ${String(pending.tool || 'tool')} ${String(pending.args || '')}`
      }
    }
    // Task progress card (rail): real percentages from step counts.
    const progressBox = $('#cowork-progress')
    if (progressBox) {
      if (steps.length) {
        const pct = Math.round((done / steps.length) * 100)
        const statusCopy = active.status === 'running' ? 'Agent is working' : active.status === 'completed' ? 'Task completed' : failed ? `${failed} step${failed === 1 ? '' : 's'} need attention` : 'Task is queued'
        const stepRows = steps.slice(0, 6).map((step) => {
          const status = String(step?.status || 'pending')
          const glyph = status === 'done' ? '✓' : status === 'running' ? '◉' : status === 'failed' ? '×' : status === 'skipped' ? '↷' : '○'
          return `<div class="cowork-progress-step" data-status="${escapeHtml(status)}"><span>${glyph}</span><strong>${escapeHtml(String(step?.title || step?.tool || step?.text || 'Untitled step'))}</strong></div>`
        }).join('')
        progressBox.innerHTML = `<div class="cowork-progress-visual"><div class="cowork-progress-ring" style="--cowork-progress:${pct * 3.6}deg"><span><strong>${pct}%</strong><small>complete</small></span></div><div class="cowork-progress-copy"><strong>${done} of ${steps.length} steps</strong><span>${statusCopy}</span><div class="cowork-progress-bar"><span style="width:${pct}%"></span></div></div></div><div class="cowork-progress-steps">${stepRows}</div>`
      } else {
        progressBox.innerHTML = '<span class="panel-note">No active task.</span>'
      }
    }
    // Artifacts card + tab: real files under artifacts/ only.
    const artifactRows = Array.isArray(data.artifacts) ? data.artifacts : []
    const artifactsBox = $('#cowork-artifacts')
    if (artifactsBox) {
      artifactsBox.innerHTML = artifactRows.length
        ? artifactRows.slice(0, 8).map((row) => `<div class="cowork-artifact-row" title="${escapeHtml(String(row.path || ''))}">• ${escapeHtml(String(row.name || ''))} <span class="panel-note">${formatBytes(Number(row.size) || 0)}</span></div>`).join('') +
          '<span class="panel-note">Full list in the Artifacts tab.</span>'
        : '<span class="panel-note">No artifacts generated yet.</span>'
    }
    const artifactsFull = $('#cowork-artifacts-full')
    if (artifactsFull) {
      // Content Writer documents (artifacts/documents/*) become real links so
      // one click opens the PDF/DOCX in a new tab. Everything else stays a
      // plain row - a file with no viewer must not pretend to be clickable.
      const linkFor = (row) => {
        const rel = String(row.path || '').replace(/\\/g, '/')
        if (!/^documents\/[A-Za-z0-9._-]+\.(pdf|docx|md|txt)$/i.test(rel)) return null
        return '/artifacts/' + rel
      }
      // Group by folder so the deliverables read as a list of documents rather
      // than one flat wall of rows. The server already ranks documents first;
      // this keeps that order inside each group instead of interleaving.
      const groups = new Map()
      for (const row of artifactRows) {
        const rel = String(row.path || '').replace(/\\/g, '/')
        const key = rel.includes('/') ? rel.slice(0, rel.indexOf('/')) : 'root'
        if (!groups.has(key)) groups.set(key, [])
        groups.get(key).push(row)
      }
      const head = `<div class="artifact-groups-head"><span class="panel-title">ARTIFACTS</span><span class="panel-note" id="cowork-artifacts-count">${artifactRows.length} of ${Number(data.artifacts_total) || artifactRows.length} files shown</span></div>`
      const body = artifactRows.length
        ? [...groups.entries()].map(([group, items]) => `
          <section class="artifact-group">
            <h4 class="artifact-group-title"><i data-lucide="folder"></i>${escapeHtml(group)} <span class="panel-note">${items.length}</span></h4>
            ${items.map((row) => {
              const href = linkFor(row)
              const size = formatBytes(Number(row.size) || 0)
              const when = row.at ? ` · ${new Date(row.at * 1000).toLocaleString()}` : ''
              const name = escapeHtml(String(row.path || row.name || ''))
              const inner = href
                ? `<a class="cowork-artifact-open" href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${name} <span class="panel-note">${size}${when} · open</span></a>`
                : `${name} <span class="panel-note">${size}${when}</span>`
              return `<div class="cowork-artifact-row" title="${name}">• ${inner}</div>`
            }).join('')}
          </section>`).join('')
        : '<span class="panel-note">No artifacts generated yet.</span>'
      artifactsFull.innerHTML = head + body
      window.lucide?.createIcons()
    }
    const channelBox = $('#cowork-channels')
    if (channelBox) {
      const channels = Array.isArray(data.channels) ? data.channels : []
      channelBox.innerHTML = channels.length
        ? channels.slice(0, 8).map((channel) => {
          const name = String(channel.name || channel.id || 'channel')
          const status = String(channel.status || 'linked')
          return `<div>${escapeHtml(name)} <span class="panel-note">${escapeHtml(status)}</span></div>`
        }).join('')
        : '<span class="panel-note">No messaging channel paired. The loopback Windows bridge is the only surface right now.</span>'
    }
    const scheduleBox = $('#cowork-schedule')
    if (scheduleBox) {
      const count = Number(data.schedule_count || 0)
      scheduleBox.innerHTML = count
        ? `<div>${count} scheduled job${count === 1 ? '' : 's'} registered in the core.</div>`
        : '<span class="panel-note">No scheduled job yet. Say “Jarvis, stop for 10 minutes” or set a voice reminder.</span>'
    }
    const skillsBox = $('#cowork-skills')
    if (skillsBox) {
      const names = Array.isArray(data.skills_list) ? data.skills_list : []
      const rev = `Skills revision ${Number(data.skills_revision || 0)}`
      skillsBox.innerHTML = names.length
        ? `<div>${rev} · ${names.length} workspace skill${names.length === 1 ? '' : 's'}</div>` +
          names.slice(0, 10).map((name) => `<div>• ${escapeHtml(String(name))}</div>`).join('') +
          `<span class="panel-note">Phase-1 local skills run without API keys. Say "use skill &lt;name&gt;".</span>`
        : `<div>${rev}</div><span class="panel-note">Phase-1 local skills run without API keys. No SKILL.md in skills/ yet.</span>`
    }
    const mcpBox = $('#cowork-mcp')
    if (mcpBox) {
      const tools = Array.isArray(data.mcp_tools) ? data.mcp_tools : []
      const callables = tools.filter((row) => row && row.allow_call)
      mcpBox.innerHTML = tools.length
        ? `<div>${tools.length} tool${tools.length === 1 ? '' : 's'} · ${callables.length} callable</div>` +
          tools.slice(0, 10).map((row) => {
            const tag = row.allow_call ? 'call' : 'list-only'
            return `<div>• ${escapeHtml(String(row.server || ''))}.${escapeHtml(String(row.tool || ''))} <span class="panel-note">${tag}</span></div>`
          }).join('') +
          `<span class="panel-note">Voice: "mcp call &lt;server&gt;.&lt;tool&gt; {…}".</span>`
        : '<span class="panel-note">No MCP tools listed. Add a server in mcp/servers.json, then press Refresh.</span>'
    }
    const lockChip = $('#cowork-power-lock')
    if (lockChip) {
      const locked = data.power_lock !== false
      lockChip.textContent = locked ? 'Power lock: ON' : 'Power lock: OFF — check core'
      lockChip.classList.toggle('offline', !locked)
    }
    // Browser tab: real research engine + registered web tools (honest about
    // no local browser automation — Playwright/Selenium are not installed).
    const browserBox = $('#cowork-browser')
    if (browserBox) {
      const webTools = (Array.isArray(data.tools) ? data.tools : []).filter((t) => t && String(t.name || '').startsWith('web_'))
      // Same sentence as the Web Intelligence console - one implementation,
      // so the two surfaces can never disagree about the engine's state.
      browserBox.innerHTML = `<div>Research engine: ${escapeHtml(researchProviderLine(data.research_provider))}</div>` +
        (webTools.length
          ? webTools.map((t) => `<div>• ${escapeHtml(String(t.name))} <span class="panel-note">${t.gated ? 'confirm-gated' : 'free'}</span></div>`).join('')
          : '<span class="panel-note">Web tools not registered.</span>') +
        '<span class="panel-note">No local browser automation installed — web work runs through the research/extract tools.</span>'
    }
    // Terminal tab: real os_* tool executions from this run (allowlisted only).
    const terminalBox = $('#cowork-terminal')
    if (terminalBox) {
      const cmdSteps = steps.filter((s) => s && String(s.tool || '').startsWith('os_'))
      terminalBox.innerHTML = cmdSteps.length
        ? cmdSteps.map((s) => `<div class="cowork-term-row"><span class="cowork-term-tool">${escapeHtml(String(s.tool))}</span> ${escapeHtml(String(s.args || '').slice(0, 160))} <span class="panel-note">→ ${escapeHtml(String(s.status || ''))}</span>${s.output ? `<pre>${escapeHtml(String(s.output).slice(0, 600))}</pre>` : ''}</div>`).join('')
        : '<span class="panel-note">No OS tool executions in this run. Commands are allowlisted and confirm-gated — nothing runs unattended.</span>'
    }
    // The Agents tab is the flow builder (public/static/agent-flow.js) and owns
    // its own rendering from /agents + /agents/catalog. Deliberately NOT
    // re-rendered from the /state poll: overwriting it here would wipe the
    // user's in-progress canvas on every 1s heartbeat.
  }

  /* ── DEEP RESEARCH CONSOLE (Web Intelligence view) ───────────────────
     Renders exactly what /state carries: the last research result, the real
     provider probe, and the actual cortex step ledger. A page that was only
     returned as a search snippet is labelled SNIPPET and never gets an OK
     chip, because "a tool returning a string is not a completed task". */
  function researchProviderLine(provider) {
    const p = provider && typeof provider === 'object' ? provider : {}
    const name = String(p.provider || 'none')
    if (p.available) {
      return `${name} - answering · keys ${Number(p.keys_healthy || 0)}/${Number(p.keys_total || 0)}` +
        (p.fanout ? ' · parallel' : '')
    }
    // available:false is NOT the same claim as "no keys": configured-and-out-of-
    // credits, configured-and-silent, and never-configured are three different
    // sentences. Collapsing them sends Sir re-doing a setup that is correct.
    if (!p.api_key_set) return `${name} - not configured (no key)`
    if (p.out_of_credits) return `${name} - ${Number(p.keys_total || 0)} key(s) configured, credits exhausted (HTTP 402)`
    return `${name} - configured, not answering: ${String(p.probe_error || 'no reason reported').slice(0, 90)}`
  }

  const _hostOf = (u) => {
    try { return new URL(String(u), 'http://jarvis.invalid').host.replace(/^www\./, '') }
    catch { return String(u || '?').slice(0, 28) }
  }

  function _rcSet(id, html) { const el = document.getElementById(id); if (el) el.innerHTML = html }

  // The report comes back as lines: headings, "- " bullets, paragraphs. Escape
  // first, then structure - so a page can never inject markup through prose.
  function _rcProse(text) {
    return String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const bullet = /^[•\-*]\s+/.test(l)
      const clean = l.replace(/^[•\-*]\s+/, '').replace(/^#+\s*/, '')
      const heading = !bullet && clean.length <= 52 && !/[.;!?]$/.test(clean) && /^[\w(]/.test(clean)
      if (heading) return `<h4 class="rc-h">${escapeHtml(clean)}</h4>`
      if (bullet) return `<div class="rc-li"><i></i><span>${escapeHtml(clean)}</span></div>`
      return `<p>${escapeHtml(clean)}</p>`
    }).join('')
  }
  const _rcShow = (id, show) => { const el = document.getElementById(id); if (el) el.hidden = !show }
  let _rcFilter = 'ALL'
  let _rcReply = ''
  let _rcTier = 'deep'
  let _rcLang = 'hinglish'
  let _lastCoreData = {}

  function renderResearchConsole(data) {
    const cloudLine = researchProviderLine(data.research_provider)
    const lastRun = (data.research && typeof data.research === 'object') ? data.research : null
    const usedProviders = (lastRun && Array.isArray(lastRun.providers)) ? lastRun.providers : []
    const answeredNames = new Set(usedProviders.filter((p) => p && p.ok).map((p) => String(p.name)))
    const chainSize = Number(lastRun && lastRun.chain_size) || answeredNames.size
    // The chip names the engine that ACTUALLY produced the last run. With
    // Firecrawl out of credits the free-tier bus is the working path, and a
    // chip that only repeats '402' reads as 'nothing works' when it is not true.
    const chipText = usedProviders.length
      ? `${answeredNames.size}/${chainSize} providers answered · tier ${String(lastRun.tier || 'deep')}`
      : 'research engine: ' + cloudLine
    const chip = document.getElementById('rc-provider')
    if (chip) chip.textContent = chipText
    const brainCard = document.getElementById('brain-bbb-research')
    if (brainCard) brainCard.textContent = chipText

    const r = (data.research && typeof data.research === 'object') ? data.research : null
    const steps = (data.cortex && Array.isArray(data.cortex.steps)) ? data.cortex.steps : []
    // The rail used to be empty for every research run, because research does
    // not go through the cortex step ledger. Show the stages this run actually
    // completed instead of an apology.
    const stages = (r && !steps.length) ? [
      ['plan', `${(r.queries || []).length} facet queries · tier ${r.tier || '-'}`, 'done'],
      ['search', `${Number(r.found) || 0} found → ${Number(r.unique) || 0} unique (${Number(r.collapsed) || 0} collapsed)`,
        (Number(r.found) || 0) > 0 ? 'done' : 'failed'],
      ['read', `${Number(r.scraped) || 0} of ${Number(r.attempted) || 0} pages read`,
        (Number(r.scraped) || 0) > 0 ? 'done' : 'failed'],
      ['write', `${String(r.report || '').length} chars · ${r.written_by || 'dossier'}`,
        String(r.report || '').length > 200 ? 'done' : 'failed'],
      ['save', (r.saved && r.saved.memory) ? 'brain memory · file only on export' : 'not saved',
        (r.saved && r.saved.memory) ? 'done' : 'failed'],
    ] : []
    const railRows = steps.length ? steps.map((step) => step) : stages
    _rcSet('rc-rail', railRows.length
      ? railRows.map((s, i) => {
          const isStage = Array.isArray(s)
          const st = isStage ? s[2] : String(s.status || 'pending')
          const cls = st === 'done' ? 'ok'
            : (st === 'failed' || st === 'cancelled' || st === 'interrupted') ? 'bad' : 'warn'
          return `<div class="rc-row${cls === 'bad' ? ' is-fail' : ''}"><span class="rc-idx">${i + 1}</span>` +
            `<span class="rc-main-copy"><span class="rc-host">${escapeHtml(isStage ? s[0] : String(s.tool || '?'))}</span>` +
            `<span class="rc-sub">${escapeHtml((isStage ? s[1] : String(s.output || '')).replace(/\s+/g, ' ').slice(0, 130))}</span></span>` +
            `<span class="rc-st ${cls}">${escapeHtml(st.toUpperCase())}</span></div>`
        }).join('')
      : '<p class="panel-note">No agent steps yet — a Co-work or agent run fills this.</p>')

    if (!r) {
      _rcSet('rc-answer', '<p class="panel-note">Nothing researched yet in this session. Say “research &lt;topic&gt;” or type below.</p>')
      _rcSet('rc-sources', '<p class="panel-note">No run yet.</p>')
      _rcSet('rc-evidence', '<p class="panel-note">No source fetched yet.</p>')
      _rcSet('rc-cited', '')
      _rcSet('rc-follow', '')
      _rcShow('rc-cited-title', false)
      _rcShow('rc-follow-title', false)
      const confEl = document.getElementById('rc-confidence')
      if (confEl) confEl.textContent = 'HOSTS —'
      _rcSet('rc-verified', '<strong>NOT RUN YET</strong><span class="rc-sep">·</span>nothing has been verified on this machine')
      return
    }

    const topic = String(r.topic || r.query || '')
    if (r.error) {
      _rcSet('rc-answer', `<p class="panel-note">Goal: ${escapeHtml(topic || '(unknown)')}</p>` +
        `<div class="rc-row is-fail"><span class="rc-main-copy"><span class="rc-host">run failed</span>` +
        `<span class="rc-sub">${escapeHtml(String(r.error).slice(0, 260))}</span></span>` +
        `<span class="rc-st bad">ERROR</span></div>`)
      _rcSet('rc-sources', '<p class="panel-note">No source list returned.</p>')
      _rcSet('rc-evidence', '<p class="panel-note">Nothing was read.</p>')
      _rcSet('rc-cited', '')
      _rcSet('rc-follow', '')
      _rcShow('rc-cited-title', false)
      _rcShow('rc-follow-title', false)
      const xs = document.getElementById('rc-export-status')
      if (xs) xs.textContent = 'nothing to export (run failed)'
      _rcSet('rc-verified', '<strong>NOT VERIFIED</strong><span class="rc-sep">·</span>0 sources read' +
        `<span class="rc-sep">·</span><em>${escapeHtml(String(r.error).slice(0, 120))}</em>`)
      return
    }

    const isResearch = r.type === 'research'
    $$('.rc-tier').forEach((b) => b.classList.toggle('active', b.dataset.tier === String(r.tier || _rcTier)))
    const detail = Array.isArray(r.sources_detail) ? r.sources_detail : []
    const sections = Array.isArray(r.sections) ? r.sections : []
    const providers = Array.isArray(r.providers) ? r.providers : []
    const rows = detail.length ? detail
      : isResearch
        ? (Array.isArray(r.sources) ? r.sources.map((u) => ({ url: String(u) })) : [])
        : (Array.isArray(r.results) ? r.results : [])
    const hostOf = (x) => x.host || _hostOf(x.url)
    const hosts = Array.from(new Set(rows.map(hostOf))).filter(Boolean)
    const readCount = detail.length ? detail.filter((d) => d.ok).length : (isResearch ? Number(r.scraped || 0) : 0)
    const cross = Number(r.cross_checked != null ? r.cross_checked : sections.filter((s) => s.verdict === 'cross_checked').length)
    const single = Number(r.single_source != null ? r.single_source : sections.filter((s) => s.verdict === 'single_source').length)
    const replyLine = _rcReply
      ? `<div class="rc-reply"><strong>JARVIS</strong> ${escapeHtml(_rcReply)}</div>` : ''

    const confEl = document.getElementById('rc-confidence')
    if (confEl) {
      const dots = Math.max(0, Math.min(6, hosts.length))
      confEl.innerHTML = `HOSTS ${hosts.length} · READ ${readCount} <span class="rc-dots">` +
        '<i class="f"></i>'.repeat(dots) + '<i></i>'.repeat(6 - dots) + '</span>'
    }

    _rcSet('rc-sources', hosts.length
      ? hosts.map((h) => {
          const mine = rows.filter((x) => hostOf(x) === h)
          const ok = mine.filter((x) => x.ok !== false).length
          return `<div class="rc-row"><span class="rc-main-copy"><span class="rc-host">${escapeHtml(h)}</span></span>` +
            `<span class="rc-st ${ok ? 'ok' : 'bad'}">${ok}/${mine.length}</span></div>`
        }).join('')
      : '<p class="panel-note">Provider returned no URLs.</p>')

    _rcShow('rc-providers-title', providers.length > 0)
    _rcSet('rc-providers', (() => {
      const agg = {}
      providers.forEach((p) => {
        const k = String(p.name || '?')
        agg[k] = agg[k] || { calls: 0, ok: 0, results: 0, err: '', parked: 0 }
        agg[k].calls += 1
        if (p.ok) { agg[k].ok += 1; agg[k].results += Number(p.results) || 0 }
        else { if (!agg[k].err) agg[k].err = String(p.error || ''); if (p.parked) agg[k].parked += 1 }
      })
      return Object.keys(agg).map((k) => `<div class="rc-row"><span class="rc-main-copy">` +
        `<span class="rc-host">${escapeHtml(k)}</span>` +
        `<span class="rc-sub">${agg[k].ok}/${agg[k].calls} queries ok` +
        `${agg[k].parked ? ' · PARKED' : ''}${agg[k].err ? ' · ' + escapeHtml(agg[k].err.slice(0, 52)) : ''}</span></span>` +
        `<span class="rc-st ${agg[k].ok ? 'ok' : 'bad'}">${agg[k].results}</span></div>`).join('')
    })())

    // Corroboration belongs with the source it describes, not with the prose.
    const supportOf = {}
    sections.forEach((sec) => { supportOf[String(sec.host || '')] = Number(sec.support) || 1 })
    const shown = detail.length
      ? detail.filter((d) => (_rcFilter === 'ALL' ? true : _rcFilter === 'READ' ? d.ok : !d.ok))
      : rows
    _rcSet('rc-evidence', shown.length
      ? shown.slice(0, 40).map((x, i) => {
          const ok = x.ok !== false && (Number(x.status) || 0) < 400
          const label = detail.length ? (x.ok ? 'READ' : 'FAILED') : (isResearch ? 'READ' : 'SNIPPET')
          const meta = detail.length
            ? (x.ok
              ? `${x.bytes >= 1024 ? (x.bytes / 1024).toFixed(1) + ' KB' : (Number(x.bytes) || 0) + ' B'} · ${Number(x.ms) || 0} ms`
              : `HTTP ${Number(x.status) || 0} · ${String(x.error || '').slice(0, 44)}`)
            : String(x.url).slice(0, 90)
          const raw = (detail.length && x.ok && x.snippet)
            ? String(x.snippet).replace(/\s+/g, ' ').slice(0, 150) : ''
          return `<div class="rc-row${(detail.length && !x.ok) ? ' is-fail' : ''}"><span class="rc-idx">${i + 1}</span>` +
            `<span class="rc-main-copy"><span class="rc-host">${escapeHtml(hostOf(x))}</span>` +
            `<span class="rc-sub">${escapeHtml(meta)}</span>` +
            (raw ? `<span class="rc-raw">${escapeHtml(raw)}</span>` : '') +
            `</span>` +
            `<span class="rc-st ${detail.length ? (x.ok ? 'ok' : 'bad') : (isResearch ? 'ok' : 'warn')}">${label}</span>` +
            (x.ok && supportOf[hostOf(x)] > 1 ? `<span class="rc-badge">×${supportOf[hostOf(x)]}</span>` : '') +
            `</div>`
        }).join('') + (shown.length > 40 ? `<p class="panel-note">+${shown.length - 40} more</p>` : '')
      : '<p class="panel-note">Nothing matches this filter.</p>')

    if (isResearch) {
      const reportText = String(r.report || '').trim()
      _rcSet('rc-answer', replyLine + (reportText
        ? `<div class="rc-prose">${_rcProse(reportText)}</div>`
        : '<p class="panel-note">No readable report was produced. The raw per-source extracts are in the EVIDENCE ledger.</p>') +
        `<div class="rc-meta">written by ${escapeHtml(String(r.written_by || 'dossier'))}` +
        ` · evidence ${escapeHtml(String(r.evidence_mode || 'unknown'))}` +
        ` · ${Number(r.scraped) || 0}/${Number(r.attempted) || rows.length} pages read` +
        ` · ${((Number(r.ms) || 0) / 1000) | 0}s</div>`)
      _rcSet('rc-verified', `<b>VERIFIED ${readCount} of ${detail.length || Number(r.attempted) || rows.length}</b>` +
        `<span class="rc-sep">·</span>pages read<span class="rc-sep">·</span>${new Set((detail.length ? detail.filter((d) => d.ok) : rows).map(hostOf)).size} hosts read` +
        `<span class="rc-sep">·</span><em>${cross} cross-checked · ${single} single-source</em>` +
        `<span class="rc-sep">·</span>${Number(r.found) || rows.length} found → ${Number(r.unique) || rows.length} unique (${Number(r.collapsed) || 0} collapsed)` +
        (r.saved && r.saved.memory ? `<span class="rc-sep">·</span><b>saved to brain</b>` : '') +
        `<span class="rc-right-note">tier ${escapeHtml(String(r.tier || 'deep'))} · ${((Number(r.ms) || 0) / 1000).toFixed(0)}s · ${escapeHtml(topic)}</span>`)
    } else {
      const answer = String(r.answer || '').trim()
      _rcSet('rc-answer', replyLine + (answer ? `<p>${escapeHtml(answer.slice(0, 900))}</p>` : '') +
        rows.slice(0, 6).map((x, i) => `<div class="rc-claim"><i></i><div class="rc-claim-body">` +
          `<h4>${escapeHtml(String(x.title || hostOf(x)).slice(0, 120))}</h4>` +
          `<p>${escapeHtml(String(x.content || x.snippet || '').slice(0, 320))}</p>` +
          `<div class="rc-badges"><span class="rc-badge single">SNIPPET — NOT READ</span>` +
          `<span class="rc-badge">[${i + 1}] ${escapeHtml(hostOf(x))}</span></div></div></div>`).join(''))
      _rcSet('rc-verified', `<strong>SNIPPETS ONLY</strong><span class="rc-sep">·</span>${rows.length} results listed` +
        `<span class="rc-sep">·</span><em>0 pages read — nothing here is verified</em>` +
        `<span class="rc-right-note">${escapeHtml(topic)}</span>`)
    }

    const made = (r.export && typeof r.export === 'object') ? r.export : {}
    const xStatus = document.getElementById('rc-export-status')
    if (xStatus) {
      const done = Object.keys(made).map((k) => `${k.toUpperCase()} ${Math.round((Number(made[k].bytes) || 0) / 1024)}KB @${made[k].at || ''}`)
      xStatus.textContent = done.length ? ('files: ' + done.join(' · ')) : 'not exported yet'
    }
    $$('.rc-x').forEach((b) => b.classList.toggle('ready', true))

    _rcSet('rc-cited', rows.slice(0, 8).map((x, i) =>
      `<div class="rc-card"><a href="${escapeHtml(String(x.url))}" target="_blank" rel="noopener noreferrer">[${i + 1}] ${escapeHtml(hostOf(x))}</a>` +
      `<div class="rc-card-url">${escapeHtml(String(x.url).replace(/^https?:\/\//, '').slice(0, 60))}</div></div>`).join(''))

    const t = (topic || 'this topic').slice(0, 80)
    _rcSet('rc-follow', [
      ['research ' + t + ' criticism and failures', 'Find criticism'],
      ['search the web for ' + t + ' statistics 2026', 'Find numbers'],
      ['research ' + t + ' primary sources', 'Primary sources'],
      ['research ' + t + ' compared across countries', 'Compare']
    ].map(([cmd, label]) =>
      `<button type="button" data-command="${escapeHtml(cmd)}">${escapeHtml(label)}</button>`).join(''))
    _rcShow('rc-cited-title', rows.length > 0)
    _rcShow('rc-follow-title', Boolean(topic))

    const brainDetail = document.getElementById('brain-research-detail')
    if (brainDetail) {
      brainDetail.textContent = isResearch
        ? `${Number(r.scraped || rows.length)} sources read · ${hosts.length} hosts`
        : `${rows.length} snippets · 0 read`
    }
  }

  function renderScreenWatchChip(data) {
    const chip = document.getElementById('live-screen-toggle')
    if (!chip) return
    const watch = (data && data.screen_watch) || {}
    const live = watch.live || {}
    const on = Boolean(watch.enabled)
    const error = String(watch.error || '').trim()
    const liveError = String(live.error || '').trim()
    const readable = String(live.readable || '').trim()
    const analysis = String(live.analysis || '').trim()
    const reading = Boolean(live.analyzing)
    const stale = Boolean(live.stale)
    let liveState = 'off'
    if (on) {
      if (reading) liveState = 'reading'
      else if (liveError) liveState = 'error'
      else if (readable || analysis) liveState = 'ready'
      else liveState = 'on'
    }
    chip.setAttribute('data-live', on ? '1' : '0')
    chip.setAttribute('data-live-state', liveState)
    chip.setAttribute('data-reading', reading ? '1' : '0')
    chip.setAttribute('data-analysis', (readable || analysis) ? '1' : '0')
    chip.setAttribute('data-stale', stale ? '1' : '0')
    chip.setAttribute('data-command', on ? 'live screen off kardo' : 'live screen chalu karo')
    chip.setAttribute('aria-pressed', on ? 'true' : 'false')
    chip.setAttribute('aria-busy', reading ? 'true' : 'false')
    chip.classList.toggle('has-error', Boolean(error) || Boolean(liveError))
    const where = String(watch.scope || '') === 'active_window' ? 'active window' : 'full screen'
    let title
    if (on) {
      const foreground = String(watch.foreground || '').trim()
      const latest = readable || analysis
      title = `Live screen ON (${where})` +
        (foreground ? ` - ${foreground}` : '') +
        (reading ? ' - reading screen...' : '') +
        (!reading && latest ? ` - ${readable ? 'READ: ' + readable : ''}${readable && analysis ? ' | ' : ''}${analysis || ''}` : '') +
        (!reading && !latest && liveError ? ` - ${liveError}` : '') +
        (stale && latest ? ' - refreshing after screen change' : '') +
        (error ? ` - ${error}` : '') +
        ' - click to stop and clear local data'
    } else {
      title = 'Live screen off - click or say “live screen on”'
    }
    chip.title = title
    chip.setAttribute('aria-label', title)
  }

  function renderDuplexChip(data) {
    const chip = document.getElementById('duplex-toggle')
    if (!chip) return
    const live = String(data.voice_mode || 'classic') === 'live'
    const mode = document.getElementById('duplex-mode')
    const meta = document.getElementById('duplex-meta')
    const next = live ? 'LIVE' : 'CLASSIC'
    if (mode && mode.textContent !== next) mode.textContent = next
    chip.setAttribute('data-live', live ? '1' : '0')
    // The chip toggles by speaking a command through the same path as the voice
    // console chips, so a click can never take a route the microphone cannot.
    chip.setAttribute('data-command', live ? 'live mode band karo' : 'live mode chalu kardo')
    const turns = Number(data.live_turns || 0)
    const first = data.live_first_audio_s
    const barges = Number(data.live_barge_in || 0)
    let line
    if (live) {
      line = `${first ? first + 's' : '-'} · ${turns} turns · ${barges} barge-ins`
      if (data.live_error) line += ` · ${String(data.live_error).slice(0, 24)}`
    } else if (turns) {
      line = `last run ${turns} turns · ${first || '-'}s first`
    } else {
      line = 'say “live mode on”'
    }
    if (meta && meta.textContent !== line) meta.textContent = line
  }

  async function pollCore() {
    if (state.corePolling) return
    state.corePolling = true
    try {
      const response = await fetch('http://127.0.0.1:7780/state', { cache: 'no-store', signal: AbortSignal.timeout(1200) })
      if (!response.ok) throw new Error()
      const data = await response.json()
      if (!state.coreOnline) {
        // Recovering native core owns the microphone; stop the browser fallback.
        state.manualVoiceStop = true
        state.recognition?.abort()
        if (state.mediaRecorder?.state === 'recording') {
          state.mediaRecorder.onstop = () => state.recordingStream?.getTracks().forEach(track => track.stop())
          state.mediaRecorder.stop()
        }
        state.recordingStream?.getTracks().forEach(track => track.stop())
        state.activeAudio?.pause()
        window.speechSynthesis?.cancel()
        setListening(false)
      }
      state.coreOnline = true
      // A NEW core session means the voice loop restarted, so the old on-screen
      // transcript is stale and must go. But the FIRST session seen after a page
      // load must NOT wipe the log: bindChatHistory has just restored the last
      // saved conversation from the database, and wiping here would throw it
      // away milliseconds later (and did, before this guard).
      if (data.session_id && data.session_id !== state.coreSessionId) {
        const isFirstSessionOfThisLoad = !state.coreSessionId
        state.coreSessionId = data.session_id
        if (!isFirstSessionOfThisLoad) wipeLocalChat()
      }
      if (data.last_error && data.last_error !== state.coreLastError) showToast(data.last_error, true)
      state.coreLastError = data.last_error || ''
      if ($('#voice-transcript')) $('#voice-transcript').textContent = data.last_transcript || data.last_user || ''
      state.coreRevision = Number(data.revision || state.coreRevision)
      _lastCoreData = data
      // Phase 5.4 Code Red: the core owns the battle state, the dashboard only
      // reflects it. Visual/alertness only - no destructive action rides on it.
      const battle = Boolean(data.battle_mode)
      if (battle !== state.battleMode) {
        state.battleMode = battle
        document.documentElement.dataset.theme = battle ? 'codered' : ''
        if (battle) showToast('CODE RED active', true)
      }
      // Phase 5.1: "open the armour studio" by voice switches the view. The sequence
      // number (not the name) is the trigger, so asking twice re-opens it.
      const openView = String(data.open_view || '')
      const openSeq = Number(data.open_view_seq || 0)
      if (openView && openSeq !== state.openViewSeq) {
        state.openViewSeq = openSeq
        const nav = document.querySelector(`[data-view="${openView}"]`)
        if (nav) nav.click()
      }
      // Clear Chat sync bell: whenever the canonical core session is cleared
      // (dashboard button, floating HUD, or voice), mirror it here immediately.
      // The bell has to be SEEN moving. state.clearSeq used to start at 0, so a
      // core cleared earlier in its life reported clear_seq=7 on the very first
      // poll after a page load and that wiped the fresh transcript - including a
      // turn typed milliseconds before it, which is how the chat request went out
      // with an empty window and the server answered 400. First poll seeds only.
      const clearSeq = Number(data.clear_seq || 0)
      if (state.clearSeq === null) state.clearSeq = clearSeq
      else if (clearSeq !== state.clearSeq) {
        state.clearSeq = clearSeq
        wipeLocalChat()
      }
      const statusMap = { idle: 'STANDBY', listening: 'LISTENING', thinking: 'THINKING', searching: 'SEARCHING', executing: 'WORKING', working: 'WORKING', speaking: 'SPEAKING', sleeping: 'SLEEPING', interrupted: 'INTERRUPTED', error: 'ERROR', offline: 'OFFLINE' }
      setRuntimeState(statusMap[String(data.status || '').toLowerCase()] || 'STANDBY')
      renderDuplexChip(data)
      renderScreenWatchChip(data)
      // Sleep ("stop") system: voice-hint explains how to bring JARVIS back.
      const sleepHint = $('#voice-hint')
      if (sleepHint) {
        if (String(data.status || '').toLowerCase() === 'sleeping') {
          const until = Number(data.sleep_until || 0)
          const mins = until > Date.now() / 1000 ? Math.max(1, Math.ceil((until - Date.now() / 1000) / 60)) : 0
          const text = (data.sleep_mode === 'timed' && mins) ? `Sleeping — auto wake in ~${mins} min` : 'Sleeping — say “Hey JARVIS, wake up”'
          if (sleepHint.textContent !== text) sleepHint.textContent = text
          state.coreWasSleeping = true
        } else if (state.coreWasSleeping) {
          state.coreWasSleeping = false
          sleepHint.textContent = state.settings.wake !== false ? 'Background core active — say “Hey JARVIS”' : 'Say “Hey JARVIS”'
        }
      }
      const events = Array.isArray(data.events) ? data.events : []
      for (const event of events) {
        const id = String(event.id || `${event.role}:${event.at}:${event.text}`)
        if (state.coreEventIds.has(id) || !event.text) continue
        state.coreEventIds.add(id)
        // STEP 3: pipe each reply into ITS channel console. general_chat
        // keeps the main transcript; every other channel gets its own
        // stream so panel output never mixes into the global log.
        const channel = String(event.target_channel_id || 'general_chat')
        addChannelMessage(channel, event.role === 'assistant' ? 'assistant' : 'user', event.text)
        // A core-handled turn is persisted on the SENDING side (recordCoreTurn),
        // but its answer only arrives here. Claim the assistant half exactly
        // once, otherwise the next prompt sees a dangling question with no reply.
        // The user half already arrived on the same event stream, so only the
        // assistant side is taken - that is what was missing from the transcript.
        //
        // Live turns are different: the voice core already wrote both sides to
        // the transcript before publishing this event. Writing the assistant
        // side here too would store every spoken answer twice.
        const liveEvent = event.origin === 'live'
        if (!liveEvent && state.pendingCoreTurn && event.role === 'assistant') {
          state.pendingCoreTurn = false
          recordCoreReply(event.text)
        }
        if (state.coreEventIds.size > 100) state.coreEventIds = new Set([...state.coreEventIds].slice(-60))
      }
      // STEP 2: focus transition (view switch + drawer + flash).
      syncChannel(data)
      if ($('#cowork-task') || $('#cowork-channels') || $('#cowork-schedule')) renderCowork(data)
      bindCoworkActions()
      if (data.brain || data.brain_revision != null) renderBrain(data)
      renderResearchConsole(data)
      const coreLabel = $('#bridge-label')
      if (coreLabel) coreLabel.textContent = data.bridge_online ? 'CORE + BRIDGE ONLINE' : 'CORE ONLINE'
    } catch {
      state.coreOnline = false
    } finally {
      state.corePolling = false
    }
  }

  let _brainRev = -1
  let _lastBrain = null
  let _brainHover = null
  let _brainPinned = null
  let _brainProjectCache = []
  const _lobeClass = (l) => ({ prefrontal_cortex:'prefrontal', motor_cortex:'motor', cerebrum:'cerebrum', hippocampus:'hippocampus', broca_area:'broca' }[String(l).toLowerCase()] || String(l).toLowerCase())
  const _BRAIN_NODES_3D = [
    { id:'prefrontal_cortex', label:'PREFRONTAL', abbr:'PFC', color:'#19e6ff', x: 0,   y:-86, z:   0, r:34, desc:'High-speed router — Groq / Gemini Flash. Intent + language, ~0ms, every key as ONE brain.' },
    { id:'broca_area',        label:'BROCA',        abbr:'BROCA', color:'#f472b6', x:-96, y:  10, z:  34, r:28, desc:'Voice -> Text — Groq Whisper (cloud) + faster-whisper (local CPU int8). VAD gated.' },
    { id:'cerebrum',          label:'CEREBRUM',     abbr:'CEREBRUM', color:'#8b5cf6', x: 92, y:  16, z: -24, r:40, desc:'Deep reasoning — Gemini 2.5-Pro / DeepSeek free pool. High complexity, heavy reasoning.' },
    { id:'motor_cortex',      label:'MOTOR',        abbr:'MOTOR', color:'#ff8a00', x:106, y:  66, z:  18, r:30, desc:'Motor cortex — local OS execution via allowlisted bridge (127.0.0.1:7778) + cowork_tools. 0-token bypass.' },
    { id:'hippocampus',       label:'HIPPOCAMPUS',  abbr:'HIPPO', color:'#25dda2', x:-90, y:  64, z: -18, r:32, desc:'Memory / RAG — Chroma (jarvis_memory / jarvis_learned) + JSON habit loop (hippocampus.json).' },
  ]
  const _BRAIN_EDGES = [['prefrontal_cortex','cerebrum'],['prefrontal_cortex','motor_cortex'],['prefrontal_cortex','hippocampus'],['broca_area','prefrontal_cortex'],['hippocampus','cerebrum']]
  function _brainProject(pt, yaw, pitch, dist, W, H) {
    let x = pt.x, y = pt.y, z = pt.z
    const cy = Math.cos(yaw), sy = Math.sin(yaw)
    let nx = x * cy + z * sy
    let nz = -x * sy + z * cy
    const cx = Math.cos(pitch), sx2 = Math.sin(pitch)
    let ny = y * cx - nz * sx2
    let nz2 = y * sx2 + nz * cx
    nz = nz2
    const persp = 420
    const scale = persp / (persp + nz + dist)
    return { x: W/2 + nx * scale, y: H/2 + ny * scale, scale, z: nz, visible: scale > 0.12 && scale < 3 }
  }
  function _brainWireframe(){}
  function _updateInspector(brain) {
    const panel = $('#brain-inspector')
    if (!panel) return
    const id = _brainPinned || _brainHover
    if (!id) { if (!_brainPinned) panel.hidden = true; return }
    const node = _BRAIN_NODES_3D.find(n=>n.id===id)
    if (!node) return
    panel.hidden = false
    const title = $('#brain-inspector-title'); if (title) title.textContent = node.label + '  ·  ' + node.abbr
    const desc = $('#brain-inspector-desc'); if (desc) desc.textContent = node.desc
    const list = $('#brain-inspector-meta'); if (!list) return
    const lobe = String((brain||_lastBrain||{}).lobe||'').toLowerCase()
    const active = lobe === id
    const lang = String((brain||_lastBrain||{}).language||'—')
    const cx = String((brain||_lastBrain||{}).complexity||'—')
    const model = String((brain||_lastBrain||{}).model||(brain||_lastBrain||{}).provider||'—')
    const reason = String((brain||_lastBrain||{}).reason||'—')
    const w = (brain||_lastBrain||{}).token_weight!=null? String((brain||_lastBrain||{}).token_weight):'—'
    const rows = []
    rows.push(['status', active ? '● ACTIVE — last route' : 'idle'])
    rows.push(['role', node.desc.split(' — ')[0] || node.desc.slice(0,48)])
    if (active) { rows.push(['language', lang]); rows.push(['complexity', cx]); rows.push(['weight', w]); rows.push(['model', model]); rows.push(['reason', reason.slice(0,120)]) }
    else rows.push(['tap', 'Route an utterance to activate'])
    list.innerHTML = rows.map(([k,v])=> `<li><span>${escapeHtml(k)}</span><span title="${escapeHtml(v)}">${escapeHtml(v)}</span></li>`).join('')
  }
  function _showBrainTooltip(node, px, py) {
    const tip = $('#brain-tooltip')
    if (!tip || !node) { if(tip) tip.hidden = true; return }
    tip.hidden = false; tip.style.left = px + 'px'; tip.style.top = py + 'px'
    const active = String((_lastBrain||{}).lobe||'').toLowerCase() === node.id
    tip.innerHTML = `<strong style="color:${node.color}">${escapeHtml(node.label)}${active ? '  ● LIVE' : ''}</strong><small>${escapeHtml(node.desc)}</small>`
  }
  function _hideBrainTooltip(){ const t=$('#brain-tooltip'); if(t) t.hidden=true }
  // ── BRAIN HUB wiring: SVG wires + 8 capability cards + status bar ──
  // Card anchor points in the 0–100 SVG viewBox (preserveAspectRatio=none).
  const _BRAIN_CAP_GEOM = {
    vision:{sx:31,sy:10}, language:{sx:31,sy:34}, memory:{sx:31,sy:58}, planning:{sx:31,sy:82},
    audio:{sx:69,sy:10}, tools:{sx:69,sy:34}, coding:{sx:69,sy:58}, computer_use:{sx:69,sy:82},
  }
  const _lobeToCap = () => (window.__JARVIS_BRAIN_HOLO__ && window.__JARVIS_BRAIN_HOLO__.LOBE_TO_CAP) || { prefrontal_cortex:'planning', cerebrum:'coding', motor_cortex:'tools', hippocampus:'memory', broca_area:'audio' }
  const _capColor = (id) => { const caps=(window.__JARVIS_BRAIN_HOLO__&&window.__JARVIS_BRAIN_HOLO__.CAPS)||[]; const c=caps.find(x=>x.id===id); return c?c.color:'#19e6ff' }
  function buildBrainWires(){
    const svg=$('#brain-wires'); if(!svg) return
    svg.innerHTML=''
    const NS='http://www.w3.org/2000/svg'
    for(const id in _BRAIN_CAP_GEOM){
      const g=_BRAIN_CAP_GEOM[id], left=g.sx<50
      const cxp=left?42:58
      const p=document.createElementNS(NS,'path')
      p.setAttribute('d',`M ${g.sx} ${g.sy} Q ${cxp} ${g.sy} 50 50`)
      p.setAttribute('stroke',_capColor(id)); p.setAttribute('data-wire',id); p.style.color=_capColor(id)
      svg.appendChild(p)
    }
  }
  function highlightBrainCap(capId){
    document.querySelectorAll('.brain-cap').forEach(el=>el.classList.toggle('active', !!capId && el.dataset.cap===capId))
    document.querySelectorAll('#brain-wires path').forEach(p=>p.classList.toggle('active', !!capId && p.dataset.wire===capId))
  }
  function showCapInspector(capId){
    const panel=$('#brain-inspector'); if(!panel) return
    const card=document.querySelector(`.brain-cap[data-cap="${capId}"]`); if(!card) return
    const label=card.querySelector('strong')?.textContent||capId
    const role=card.querySelector('small')?.textContent||''
    const model=card.querySelector('em')?.textContent||''
    const color=_capColor(capId); const active=card.classList.contains('active')
    panel.hidden=false
    const t=$('#brain-inspector-title'); if(t){ t.textContent=label; t.style.color=color }
    const d=$('#brain-inspector-desc'); if(d) d.textContent=`${role} — ${model}`
    const list=$('#brain-inspector-meta'); if(!list) return
    const mapped=_lobeToCap(); const lobeKey=Object.keys(mapped).find(k=>mapped[k]===capId)
    const rows=[['status', active?'● LIVE — active route':'idle'],['role',role],['stack',model]]
    if(active&&lobeKey) rows.push(['routed via', lobeKey.replace(/_/g,' ')])
    list.innerHTML=rows.map(([k,v])=>`<li><span>${escapeHtml(k)}</span><span title="${escapeHtml(v)}">${escapeHtml(v)}</span></li>`).join('')
  }
  function attachCapCards(){
    document.querySelectorAll('.brain-cap').forEach(card=>{
      const id=card.dataset.cap
      card.addEventListener('mouseenter',()=>{
        const label=card.querySelector('strong')?.textContent||id
        const small=card.querySelector('small')?.textContent||''
        const em=card.querySelector('em')?.textContent||''
        const r=card.getBoundingClientRect(), wr=$('#brain-canvas-wrap')?.getBoundingClientRect()
        if(!wr) return
        _showBrainTooltip({id,label,color:_capColor(id),desc:`${small} — ${em}`}, r.left-wr.left+r.width/2, r.top-wr.top)
      })
      card.addEventListener('mouseleave',()=>_hideBrainTooltip())
      card.addEventListener('click',(e)=>{ e.stopPropagation(); _brainPinned=id; showCapInspector(id) })
    })
  }
  function renderBrain(data) {
    const brain = data.brain
    const rev = Number(data.brain_revision || 0)
    const needsDraw = rev !== _brainRev || !brain
    _brainRev = rev
    if (brain && typeof brain === 'object') _lastBrain = brain
    const chip = $('#brain-chip')
    if (chip) {
      const online = Boolean(state.coreOnline)
      chip.textContent = online ? (brain?.lobe ? String(brain.lobe).toUpperCase().replace('_',' ') : 'BRAIN READY') : 'BRAIN OFFLINE'
      chip.className = 'connection-chip ' + (online ? 'online' : 'offline')
    }
    const _empty = !brain || typeof brain !== 'object' || !Object.keys(brain).length
    if (_empty) {
      if ($('#brain-json')) $('#brain-json').textContent = 'No route yet. Speak or type — the prefrontal decides in ~0ms.'
      if ($('#brain-meta')) $('#brain-meta').textContent = state.coreOnline ? 'Core online — awaiting first utterance.' : 'Core offline — start voice_engine to see routing.'
      if ($('#brain-hippocampus')) $('#brain-hippocampus').innerHTML = '<span class="panel-note">No hippocampus hits yet.</span>'
      highlightBrainCap(null)
      drawBrain(null); return
    }
    const lobe = String(brain.lobe || '—')
    const lang = String(brain.language || '—')
    const w = brain.token_weight != null ? String(brain.token_weight) : '—'
    const cx = String(brain.complexity || '—')
    const model = String(brain.model || brain.provider || '—')
    const reason = String(brain.reason || '')
    const lobeEl = $('#brain-lobe')
    if (lobeEl) { lobeEl.textContent = lobe.replace('_',' '); lobeEl.className = 'brain-chip ' + _lobeClass(lobe) }
    const rEl = $('#brain-reason'); if (rEl) rEl.textContent = reason || '—'
    const set = (id, v) => { const e = $('#'+id); if (e) e.textContent = v }
    set('brain-lang', lang); set('brain-weight', w); set('brain-complexity', cx); set('brain-model', model)
    const flow = $('#brain-flow')
    if (flow) {
      const steps = [['Prefrontal','route '+lang+'/'+cx], ['Hippocampus', (Array.isArray(brain.hippocampus)?brain.hippocampus.length:0)+' recall'], [lobe.replace('_',' '), model], ['TTS','edge-tts / SAPI']]
      flow.innerHTML = steps.map(([t,s],i) => `<div class="flow-step ${i===2?'active':''}"><strong>${escapeHtml(t)}</strong><small>${escapeHtml(s)}</small></div>`).join('')
    }
    const j = $('#brain-json'); if (j) j.textContent = JSON.stringify(brain, null, 2)
    const meta = $('#brain-meta'); if (meta) meta.textContent = 'rev ' + rev + ' · ' + (brain.ts || '')
    const hip = $('#brain-hippocampus')
    if (hip) {
      const arr = Array.isArray(brain.hippocampus) ? brain.hippocampus : []
      hip.innerHTML = arr.length ? arr.map(t => `<div class="saved-item"><span>${escapeHtml(String(t).slice(0,220))}</span></div>`).join('') : '<span class="panel-note">No hippocampus hits yet.</span>'
    }
    const histEl = $('#brain-history')
    if (histEl) {
      try {
        const raw = localStorage.getItem('jarvis:brain:history') || '[]'
        let hist = JSON.parse(raw); if (!Array.isArray(hist)) hist = []
        const entry = { at: Date.now(), lobe, lang, cx, w, model }
        if (needsDraw || !hist.length || hist[hist.length-1]?.lobe !== lobe) {
          hist.push(entry); if (hist.length > 8) hist = hist.slice(-8)
          localStorage.setItem('jarvis:brain:history', JSON.stringify(hist))
        }
        histEl.innerHTML = hist.slice().reverse().map(h => `<div class="saved-item"><span><strong>${escapeHtml(h.lobe)}</strong> · ${escapeHtml(h.lang)}/${escapeHtml(h.cx)} w=${escapeHtml(String(h.w))} · ${escapeHtml(h.model)}</span><small>${new Date(h.at).toLocaleTimeString()}</small></div>`).join('')
      } catch {}
    }
    _updateInspector(brain)
    // Light the capability card + wire that this lobe routed to, and fill the
    // bottom status bar from the SAME real brain object (honest '—' when idle).
    const capId = _lobeToCap()[lobe.toLowerCase()]
    highlightBrainCap(capId || null)
    const bbbModel = $('#brain-bbb-model'); if (bbbModel) bbbModel.textContent = model
    const bbbRouter = $('#brain-bbb-router'); if (bbbRouter) bbbRouter.textContent = (brain.provider && brain.provider !== model) ? `${model} · ${brain.provider}` : 'Auto'
    const bbbMem = $('#brain-bbb-memory'); if (bbbMem) { const n = Array.isArray(brain.hippocampus) ? brain.hippocampus.length : 0; bbbMem.textContent = n ? `${n} recall${n===1?'':'s'} live` : 'Idle — no recall' }
    if (needsDraw) drawBrain(brain)
    else _updateInspector(brain)
    try{ refreshSettingsBrain(); }catch{}
  }
  function _brainPick(px, py, dpr){ try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h&&h.hoverId) return h.hoverId }catch{} let best=null,bestD=1e9; for(const n of _brainProjectCache){ if(!n.visible) continue; const dx=px-n.px,dy=py-n.py; const r=(n.r*dpr*n.scale)+12*dpr; const d=Math.hypot(dx,dy); if(d<r&&d<bestD){best=n.id;bestD=d}} return best }
  function drawBrain(brain){ try{ const b=(brain!==undefined&&brain!==null)?brain:_lastBrain; if(b&&typeof b==='object') _lastBrain=b; try{ window.__BRAIN_LAST__=_lastBrain }catch{} const h=window.__JARVIS_BRAIN_HOLO__; if(h&&typeof h.setBrain==='function'){ h.setBrain(b); return } if(typeof window.__brainHoloDraw==='function'){ window.__brainHoloDraw(b); return } }catch(e){ console.warn('[brain-holo] draw fallback',e) } try{ const canvas=$('#brain-canvas'); if(!canvas||!canvas.getContext) return; const ctx=canvas.getContext('2d'); const W=canvas.width||640,H=canvas.height||360; ctx.clearRect(0,0,W,H); const g=ctx.createRadialGradient(W/2,H/2-10,20,W/2,H/2-10,260); g.addColorStop(0,'rgba(25,230,255,0.16)'); g.addColorStop(0.45,'rgba(13,60,80,0.18)'); g.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=g; ctx.fillRect(0,0,W,H); ctx.fillStyle='#8ee8ff'; ctx.font='700 13px Rajdhani,Inter,sans-serif'; ctx.textAlign='center'; ctx.fillText('Loading hologram\u2026',W/2,H/2) }catch{} }
  try{ window._updateInspector=_updateInspector; window._showBrainTooltip=_showBrainTooltip; window._hideBrainTooltip=_hideBrainTooltip }catch{}
  function bindBrain(){ buildBrainWires(); attachCapCards(); try{ window.lucide?.createIcons() }catch{}; const wrap=document.getElementById('brain-canvas-wrap'); const resetBtn=document.getElementById('brain-orbit-reset'); const autoChk=document.getElementById('brain-autorotate'); if(autoChk){ const hAuto=()=>{ try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h) h.setAuto(autoChk.checked) }catch{} }; autoChk.checked=true; try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h){ autoChk.checked=true; hAuto() }}catch{} autoChk.addEventListener('change',hAuto) } if(resetBtn) resetBtn.addEventListener('click',()=>{ _brainPinned=null; _brainHover=null; _hideBrainTooltip(); const ins=$('#brain-inspector'); if(ins) ins.hidden=true; try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h&&h.reset) h.reset(); else drawBrain(_lastBrain) }catch{ drawBrain(_lastBrain)} showToast('Hologram reset') }); document.getElementById('brain-inspector-close')?.addEventListener('click',()=>{ _brainPinned=null; _hideBrainTooltip(); const ins=$('#brain-inspector'); if(ins) ins.hidden=true; try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h) h.pinnedId=null }catch{} drawBrain(_lastBrain) }); $('#brain-refresh')?.addEventListener('click', async ()=>{ try{ const r=await fetch('http://127.0.0.1:7780/brain',{cache:'no-store',signal:AbortSignal.timeout(2000)}); const j=await r.json(); renderBrain({brain:j.brain,brain_revision:j.brain_revision}); showToast('Brain refreshed') }catch{ showToast('Brain refresh failed \u2014 core offline',true)} }); $('#brain-topology')?.addEventListener('click', async ()=>{ const mini=$('#brain-topology-mini'); if(!mini) return; const open=!mini.hidden; if(open){ mini.hidden=true; return } mini.hidden=false; mini.textContent='Loading topology\u2026'; try{ const [b,s]=await Promise.all([fetch('http://127.0.0.1:7780/brain',{cache:'no-store',signal:AbortSignal.timeout(2000)}).then(r=>r.json()).catch(()=>null), fetch('http://127.0.0.1:7780/state',{cache:'no-store',signal:AbortSignal.timeout(2000)}).then(r=>r.json()).catch(()=>null)]); const lines=[]; const brain=(b&&b.brain)||(s&&s.brain)||_lastBrain; if(brain) lines.push('Last lobe: '+(brain.lobe||'\u2014')+'  lang='+(brain.language||'\u2014')+'  w='+(brain.token_weight||'\u2014')); if(s&&s.revision!=null) lines.push('State rev: '+s.revision+'  brain_rev: '+(s.brain_revision||0)); if(b&&b.brain) lines.push('Brain: '+JSON.stringify(b.brain,null,2).slice(0,900)); if(!lines.length) lines.push('Topology: core offline \u2014 showing hologram only.'); mini.textContent=lines.join('\n\n'); _updateInspector(_lastBrain) }catch(e){ mini.textContent='Topology unavailable: '+String(e).slice(0,180)} }); drawBrain(null); let _brainRsz=0; window.addEventListener('resize',()=>{ clearTimeout(_brainRsz); _brainRsz=setTimeout(()=>{ try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h&&h.isReady&&h.isReady()) return }catch{}; drawBrain(_lastBrain) },180) }); const tryInitHolo=()=>{ try{ const h=window.__JARVIS_BRAIN_HOLO__; if(h&&h.init) h.init(); if(_lastBrain) drawBrain(_lastBrain)}catch{}}; if(window.__JARVIS_THREE__&&window.__JARVIS_OrbitControls__) tryInitHolo(); else window.addEventListener('jarvis:three-ready',tryInitHolo,{once:true}) }


  async function checkBridge() {
    const url = state.settings.bridgeUrl || 'http://127.0.0.1:7778'
    try {
      const response = await fetch(`${url.replace(/\/$/, '')}/api/status`, { signal: AbortSignal.timeout(1600) })
      if (!response.ok) throw new Error()
      const data = await response.json()
      setBridgeStatus(true, data)
    } catch { setBridgeStatus(false) }
  }

  function setBridgeStatus(online, data = {}) {
    const wasOnline = state.bridgeOnline
    state.bridgeOnline = online
    // Keep the measured desktop geometry and the input-worker health where the
    // gesture controller can read them. `desktop` is the bridge's own
    // coordinate space, so the pointer mapping never has to guess at DPI
    // scaling, and `mouse` is the real readiness of the PowerShell worker that
    // injects Windows input - not an assumption that the bridge implies a
    // working mouse.
    state.bridgeDesktop = online && data.desktop && data.desktop.width ? data.desktop : null
    state.bridgeMouse = online && data.mouse ? data.mouse : null
    const supported = online && data.platformSupported !== false
    if (!state.coreOnline) $('#bridge-label').textContent = supported ? 'BRIDGE ONLINE' : online ? 'COMPATIBILITY MODE' : 'BRIDGE OFFLINE'
    $('#connection-chip').textContent = supported ? 'Windows bridge connected' : online ? 'Bridge connected — Windows actions unavailable' : 'Local bridge disconnected'
    $('#connection-chip').classList.toggle('offline', !online)
    if (online) {
      const metrics = data.metrics || data.system || {}
      updateMetric('cpu', metrics.cpu)
      updateMetric('ram', metrics.ram || metrics.memory)
      updateMetric('disk', metrics.disk)
      updateMetric('batt', metrics.battery)
      state.activeWindow = String(metrics.activeWindow || data.active_window || '').trim()
      $('#system-note').textContent = state.activeWindow ? `Active: ${state.activeWindow}` : 'Live system telemetry connected.'
    }
    if (wasOnline !== online || online) gestureControl?.onBridgeStatus(online, data)
    updateStatusReadouts()
  }

  function updateMetric(name, value) {
    if (value == null) return
    const number = Math.max(0, Math.min(100, Number(value)))
    const readout = $(`#${name}-value`)
    if (readout) readout.textContent = `${Math.round(number)}%`
    const bar = $(`#${name}-bar`)
    if (bar) bar.style.width = `${number}%`
    // Rail gauge rings share the SAME bridge numbers — no invented telemetry.
    const ring = $(`#ring-${name}`)
    if (ring) {
      ring.style.strokeDashoffset = String(113.1 * (1 - number / 100))
      const wrap = ring.closest('.ring')
      if (wrap) {
        wrap.classList.toggle('warn', number >= 75 && number < 90)
        wrap.classList.toggle('hot', number >= 90)
      }
    }
    const ringValue = $(`#ring-${name}-value`)
    if (ringValue) ringValue.textContent = `${Math.round(number)}%`
    updateMiniSystem()
  }

  function updateMiniSystem() {
    const mini = $('#mini-system')
    if (!mini) return
    const read = (id) => $(`#${id}-value`)?.textContent || '--%'
    mini.textContent = `CPU ${read('cpu')} · RAM ${read('ram')} · DISK ${read('disk')}`
  }

  function bindStorageFeatures() {
    $('#save-note')?.addEventListener('click', () => {
      const value = $('#note-input').value.trim()
      if (!value) return
      const notes = JSON.parse(localStorage.getItem('jarvis-notes') || '[]')
      notes.unshift({ id: Date.now(), text: value })
      localStorage.setItem('jarvis-notes', JSON.stringify(notes.slice(0, 20)))
      $('#note-input').value = ''
      renderSavedItems()
      showToast('Note saved on this device.')
    })
    $('#save-reminder')?.addEventListener('click', () => {
      const text = $('#reminder-text').value.trim(), time = $('#reminder-time').value
      if (!text || !time) return showToast('Add reminder details and time.', true)
      const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
      reminders.push({ id: Date.now(), text, time })
      localStorage.setItem('jarvis-reminders', JSON.stringify(reminders))
      $('#reminder-text').value = ''; $('#reminder-time').value = ''
      renderSavedItems(); showToast('Reminder saved on this device.')
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {})
    })
    document.addEventListener('click', (event) => {
      const button = event.target.closest('[data-delete-type]')
      if (!button) return
      const key = button.dataset.deleteType === 'note' ? 'jarvis-notes' : 'jarvis-reminders'
      const items = JSON.parse(localStorage.getItem(key) || '[]').filter((item) => String(item.id) !== button.dataset.deleteId)
      localStorage.setItem(key, JSON.stringify(items)); renderSavedItems()
    })
  }

  function checkDueReminders() {
    const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
    let changed = false
    for (const reminder of reminders) {
      if (!reminder.notified && new Date(reminder.time).getTime() <= Date.now()) {
        reminder.notified = true; changed = true
        showToast(`Reminder: ${reminder.text}`); speak(`Reminder. ${reminder.text}`)
        if ('Notification' in window && Notification.permission === 'granted') new Notification('JARVIS reminder', { body: reminder.text })
      }
    }
    if (changed) localStorage.setItem('jarvis-reminders', JSON.stringify(reminders))
  }

  function renderSavedItems() {
    const notes = JSON.parse(localStorage.getItem('jarvis-notes') || '[]')
    const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
    if ($('#notes-list')) $('#notes-list').innerHTML = notes.map((item) => `<div class="saved-item"><span>${escapeHtml(item.text)}</span><button data-delete-type="note" data-delete-id="${item.id}">×</button></div>`).join('')
    if ($('#reminders-list')) $('#reminders-list').innerHTML = reminders.map((item) => `<div class="saved-item"><span>${escapeHtml(item.text)}<br><small>${new Date(item.time).toLocaleString()}</small></span><button data-delete-type="reminder" data-delete-id="${item.id}">×</button></div>`).join('')
    if ($('#dashboard-reminders') && reminders.length) $('#dashboard-reminders').innerHTML = `<i data-lucide="calendar-clock"></i><strong>${escapeHtml(reminders[0].text)}</strong><small>${new Date(reminders[0].time).toLocaleString()}</small>`
    if (window.lucide) window.lucide.createIcons()
  }

  // ── Memory Core: persistent ChromaDB store (voice engine :7780 /memory) ──
  // The browser panel mirrors the server-side `jarvis_memory` collection.
  // localStorage remains a read cache when the voice engine is offline.
  const MEMORY_CORE_URL = 'http://127.0.0.1:7780'

  async function refreshMemoryCore() {
    // Read BOTH stores. Previously only the explicit jarvis_memory list was
    // fetched, so anything learned from a conversation was invisible in the
    // panel AND un-deletable - which is why "saved memory came back" after a
    // refresh.
    const merged = []
    for (const url of [`${MEMORY_CORE_URL}/memory`, `${MEMORY_CORE_URL}/memory/learned`]) {
      try {
        const response = await fetch(url, { signal: AbortSignal.timeout(2500) })
        if (!response.ok) continue
        const data = await response.json()
        for (const [index, row] of (data.memories || []).entries()) {
          const text = String(row?.text || '').trim()
          if (text) merged.push({ id: String(row.id || `${url}#${index}`), text })
        }
      } catch { /* one store offline: keep whatever the other returned */ }
    }
    if (!merged.length && !navigator.onLine) { renderMemories(); return }
    localStorage.setItem('jarvis-memories', JSON.stringify(merged.slice(0, 100)))
    renderMemories()
  }

  async function deleteEverywhere(text) {
    // The fact may live in either collection, so try both. Deleting from only
    // one is what left orphaned memories behind.
    for (const [url, body] of [
      [`${MEMORY_CORE_URL}/memory/delete`, { text }],
      [`${MEMORY_CORE_URL}/memory/learned/delete`, { text }]
    ]) {
      try {
        await fetch(url, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body), signal: AbortSignal.timeout(3000)
        })
      } catch { /* offline: the local mirror is still updated below */ }
    }
  }

  function bindMemory() {
    $('#save-memory')?.addEventListener('click', async () => {
      const value = $('#memory-input').value.trim()
      if (!value) return
      $('#memory-input').value = ''
      try {
        const response = await fetch(`${MEMORY_CORE_URL}/memory`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: value }), signal: AbortSignal.timeout(4000)
        })
        if (!response.ok) throw new Error('save failed')
        showToast('Saved to persistent memory core (ChromaDB).')
      } catch {
        const memories = JSON.parse(localStorage.getItem('jarvis-memories') || '[]')
        if (!memories.some((item) => item.text.toLowerCase() === value.toLowerCase())) memories.unshift({ id: Date.now(), text: value })
        localStorage.setItem('jarvis-memories', JSON.stringify(memories.slice(0, 50)))
        showToast('Voice engine offline — saved to local cache only.', true)
      }
      await refreshMemoryCore()
    })
    $('#clear-memory')?.addEventListener('click', async () => {
      if (!confirm('Clear saved memories from the ChromaDB memory core?')) return
      try {
        const memories = JSON.parse(localStorage.getItem('jarvis-memories') || '[]')
        await Promise.all(memories.map((item) => fetch(`${MEMORY_CORE_URL}/memory/delete`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: item.text }), signal: AbortSignal.timeout(3000)
        }).catch(() => {})))
        showToast('Persistent memory core cleared.')
      } catch { showToast('Voice engine offline — cleared local cache.', true) }
      localStorage.removeItem('jarvis-memories')
      await refreshMemoryCore()
    })
    document.addEventListener('click', async (event) => {
      const button = event.target.closest('[data-memory-delete]')
      if (!button) return
      const memories = JSON.parse(localStorage.getItem('jarvis-memories') || '[]')
      const target = memories.find((item) => String(item.id) === button.dataset.memoryDelete)
      if (target) await deleteEverywhere(target.text)
      localStorage.setItem('jarvis-memories', JSON.stringify(memories.filter((item) => String(item.id) !== button.dataset.memoryDelete)))
      await refreshMemoryCore()
    })
    renderMemories()
    refreshMemoryCore()
  }

  function renderMemories() {
    const memories = JSON.parse(localStorage.getItem('jarvis-memories') || '[]')
    if ($('#memory-list')) $('#memory-list').innerHTML = memories.length ? memories.map((item) => `<div class="saved-item"><span>${escapeHtml(item.text)}</span><button data-memory-delete="${item.id}">×</button></div>`).join('') : '<p class="panel-note">No memories saved yet.</p>'
  }

  function bindSettings() {
    $('#save-settings')?.addEventListener('click', () => {
      state.settings = { name: $('#display-name').value.trim() || 'Prateek', bridgeUrl: $('#bridge-url').value.trim() || 'http://127.0.0.1:7778', language: $('#language-select').value, voiceProvider: $('#stt-provider').value, ttsProvider: $('#tts-provider').value, aiProvider: $('#ai-provider-select').value, speak: $('#speak-toggle').checked, wake: $('#wake-toggle').checked }
      localStorage.setItem('jarvis-settings', JSON.stringify(state.settings)); applySettings(); checkBridge(); showToast('Settings saved.')
    })
    // Settings > Neural Brain tabs (General / Neural Brain)
    $$('.settings-tab').forEach(btn => btn.addEventListener('click', () => {
      const tab = btn.dataset.settingsTab
      $$('.settings-tab').forEach(b => { const on=b===btn; b.classList.toggle('active', on); b.setAttribute('aria-selected', String(on)) })
      $$('[data-settings-panel]').forEach(p => { p.hidden = p.dataset.settingsPanel !== tab })
      if (window.lucide) window.lucide.createIcons()
      if (tab==='neural') { refreshSettingsBrain(); drawSettingsOrbits() }
    }))
    $('#settings-brain-pulse')?.addEventListener('click', () => {
      const el=$('#settings-brain-wrap'); if(el){ el.animate([{transform:'scale(1)'},{transform:'scale(1.02)'},{transform:'scale(1)'}],{duration:520,easing:'ease-out'}); }
      // pulse the 3D brain too if present
      try{ window.__JARVIS_BRAIN_HOLO__?.setBrain(_lastBrain || { lobe:'prefrontal_cortex' }) }catch{}
      showToast('Neural pulse sent')
    })
    $('#settings-brain-open')?.addEventListener('click', (e)=>{ e.preventDefault(); const v=document.querySelector('[data-view="brain"]'); if(v) v.click(); else location.hash='#brain' })
    // Clicking caps focuses the brain
    $$('.sb-cap').forEach(b => b.addEventListener('click', () => {
      const cap=b.dataset.cap
      $$('.sb-cap').forEach(x=>x.classList.toggle('active', x===b))
      const lobeMap={vision:'cerebrum',language:'broca_area',memory:'hippocampus',planning:'prefrontal_cortex',audio:'broca_area',tools:'motor_cortex',coding:'cerebrum',computer_use:'motor_cortex'}
      const lobe=lobeMap[cap]||'prefrontal_cortex'
      try{ window.__JARVIS_BRAIN_HOLO__?.setBrain({lobe}); }catch{}
      $('#sb-lobe')&&( $('#sb-lobe').textContent = lobe.toUpperCase().replace('_',' ') )
      showToast(cap + ' → ' + lobe)
    }))
  }

  function applySettings() {
    $('#display-name').value = state.settings.name || 'Prateek'
    $('#bridge-url').value = state.settings.bridgeUrl || 'http://127.0.0.1:7778'
    $('#language-select').value = state.settings.language || 'auto'
    $('#stt-provider').value = state.settings.voiceProvider || 'browser'
    $('#tts-provider').value = state.settings.ttsProvider || 'browser'
    $('#ai-provider-select').value = state.settings.aiProvider || 'auto'
    $('#speak-toggle').checked = state.settings.speak !== false
    $('#wake-toggle').checked = state.settings.wake !== false
    updateClock()
  }

  let _sbHealthCache={},_sbLastFetch=0;
  async function refreshSettingsBrain(){ try{ let health=null,now=Date.now(); if(now-_sbLastFetch>15000){ try{ const r=await fetch('/api/health',{cache:'no-store'}); if(r.ok) health=await r.json(); }catch{} if(health){_sbHealthCache=health;_sbLastFetch=now;} else health=_sbHealthCache; } else health=_sbHealthCache; const keys=(health&&health.keys)||{}; const map={groq:['vision','language'],gemini:['vision','language','coding'],openrouter:['tools','coding'],nvidia:['vision','planning','coding'],elevenlabs:['audio'],github:['coding','computer_use']}; const capHas={}; Object.entries(map).forEach(([k,caps])=>caps.forEach(c=>{ if(keys[k]) capHas[c]=true })); ['vision','language','memory','planning','audio','tools','coding','computer_use'].forEach(cap=>{ const dot=document.getElementById('sb-dot-'+cap); if(!dot) return; const has=!!capHas[cap]; const showOn=Object.keys(keys).length===0?true:has; dot.classList.toggle('on',showOn); dot.classList.toggle('missing',!showOn); }); ['groq','gemini','openrouter','nvidia','elevenlabs','github'].forEach(k=>{ const el=document.getElementById('sb-key-'+k); if(!el) return; const on=!!keys[k]; el.classList.toggle('on',on); el.classList.toggle('missing',!on); }); const b=_lastBrain||{}; const mEl=document.getElementById('sb-model'), rEl=document.getElementById('sb-router'), memEl=document.getElementById('sb-memory'); if(mEl) mEl.textContent=b.model||((health&&health.model&&health.model.locked)||'\u2014'); if(rEl) rEl.textContent=b.router||'Auto'; if(memEl){ const n=Array.isArray(b.hippocampus)?b.hippocampus.length:0; memEl.textContent=n? n+' recalls':'Idle'; } const chip=document.getElementById('settings-brain-chip'), lobeEl=document.getElementById('sb-lobe'), reasonEl=document.getElementById('sb-reason'); if(chip){ const rev=b.revision!=null?'REV '+b.revision:'BRAIN IDLE'; chip.textContent=b.lobe?(String(b.lobe).toUpperCase().replace('_',' ')+' \u00b7 '+rev):rev; } if(lobeEl&&b.lobe) lobeEl.textContent=String(b.lobe).toUpperCase().replace('_',' '); if(reasonEl&&b.reason) reasonEl.textContent=String(b.reason).slice(0,120); drawSettingsOrbits(b); }catch(e){} }
  function drawSettingsOrbits(brain){ const g=document.getElementById('sb-orbit-nodes'); if(!g) return; g.innerHTML=''; const caps=[{id:'vision',color:'#22c55e'},{id:'language',color:'#14b8a6'},{id:'memory',color:'#3b82f6'},{id:'planning',color:'#eab308'},{id:'audio',color:'#f43f5e'},{id:'tools',color:'#f97316'},{id:'coding',color:'#8b5cf6'},{id:'computer_use',color:'#06b6d4'}]; caps.forEach((c,i)=>{ const ang=(i/caps.length)*Math.PI*2 - Math.PI/2; const x=250+Math.cos(ang)*108, y=240+Math.sin(ang)*96; const sel=brain&&String(brain.lobe||'').toLowerCase().includes(c.id.slice(0,4)); const dot=document.getElementById('sb-dot-'+c.id); const hasKey=dot&&dot.classList.contains('on'); const line=document.createElementNS('http://www.w3.org/2000/svg','line'); line.setAttribute('x1','250'); line.setAttribute('y1','240'); line.setAttribute('x2',String(x)); line.setAttribute('y2',String(y)); line.setAttribute('stroke', hasKey?c.color:'#2a3a45'); line.setAttribute('stroke-width', sel?'2':'1'); line.setAttribute('opacity', sel?'0.95':hasKey?'0.55':'0.22'); g.appendChild(line); const outer=document.createElementNS('http://www.w3.org/2000/svg','circle'); outer.setAttribute('cx',String(x)); outer.setAttribute('cy',String(y)); outer.setAttribute('r', sel?'14':'10'); outer.setAttribute('fill','none'); outer.setAttribute('stroke',c.color); outer.setAttribute('stroke-width','1.2'); outer.setAttribute('opacity', hasKey?'0.7':'0.25'); g.appendChild(outer); const node=document.createElementNS('http://www.w3.org/2000/svg','circle'); node.setAttribute('cx',String(x)); node.setAttribute('cy',String(y)); node.setAttribute('r', sel?'7':'5.5'); node.setAttribute('fill', hasKey?c.color:'#2a3a45'); node.setAttribute('opacity', hasKey?'0.95':'0.5'); g.appendChild(node); }); }

  // ══════════════════════════════════════════════════════════════════════════
  // DASHBOARD SHELL — workspace modules, conversation expand, rail wiring
  // Every binding below drives real existing behaviour; nothing is a mock.
  // ══════════════════════════════════════════════════════════════════════════
  const WORKSPACE_MODULES = ['screen', 'camera', 'gesture', 'hud']

  function setWorkspaceModule(name, persist = true) {
    const stage = $('#ws-stage')
    if (!stage) return
    const id = WORKSPACE_MODULES.includes(name) ? name : 'screen'
    stage.dataset.wsActive = id
    $$('.ws-tab').forEach((tab) => {
      const on = tab.dataset.wsModule === id
      tab.classList.toggle('active', on)
      tab.setAttribute('aria-selected', String(on))
    })
    if (persist) { try { localStorage.setItem('jarvis-workspace-module', id) } catch { /* storage blocked */ } }
  }

  function bindWorkspaceModules() {
    $('#ws-tabs')?.addEventListener('click', (event) => {
      const tab = event.target.closest('[data-ws-module]')
      if (tab) setWorkspaceModule(tab.dataset.wsModule)
    })
    // MediaPipe can only read pixels from a video that is actually on screen,
    // so starting hand tracking always reveals the Camera module first. Only
    // dashboard toggles steer the module — the Vision view keeps its own feed.
    document.addEventListener('click', (event) => {
      if (event.target.closest('#dashboard-view .gesture-toggle') || event.target.closest('#rail-gesture-toggle')) setWorkspaceModule('camera', false)
    })
    $('#ws-fullscreen')?.addEventListener('click', () => {
      if (document.fullscreenElement) document.exitFullscreen?.()
      else document.documentElement.requestFullscreen?.().catch(() => showToast('Fullscreen was blocked by the browser.', true))
    })
    $('#ws-expand')?.addEventListener('click', (event) => {
      const panel = $('.workspace-panel')
      if (!panel) return
      const on = panel.classList.toggle('focused')
      event.currentTarget.classList.toggle('active', on)
    })
    setWorkspaceModule(localStorage.getItem('jarvis-workspace-module') || 'screen', false)
  }

  function bindChatExpand() {
    const panel = $('#dashboard-chat')
    const button = $('#chat-expand')
    if (!panel || !button) return
    const apply = (expanded) => {
      panel.classList.toggle('expanded', expanded)
      document.body.classList.toggle('chat-expanded', expanded)
      button.classList.toggle('active', expanded)
      button.setAttribute('aria-label', expanded ? 'Restore conversation' : 'Expand conversation')
      const log = $('#chat-log')
      if (log) log.scrollTop = log.scrollHeight
    }
    button.addEventListener('click', () => apply(!panel.classList.contains('expanded')))
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && panel.classList.contains('expanded')) apply(false)
    })
  }

  function relativeTime(timestamp) {
    const seconds = Math.max(1, Math.round((Date.now() - Number(timestamp)) / 1000))
    if (seconds < 60) return `${seconds}s ago`
    const minutes = Math.round(seconds / 60)
    if (minutes < 60) return `${minutes}m ago`
    const hours = Math.round(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    return `${Math.round(hours / 24)}d ago`
  }

  // Titles are the only searchable text carried on the list rows (the DB list is
  // intentionally lightweight). Searching message bodies would require
  // fetching every transcript, so title search is the honest, cheap behaviour.
  function chatMatches(session, query) {
    if (!query) return true
    return String(session.title || '').toLowerCase().includes(query)
  }

  // `sessions` is passed in from the caller when it is already on hand, so the
  // rail does not fire a second identical request to the core.
  async function renderRailChatHistory(sessions) {
    const list = $('#rail-chat-history-list')
    if (!list) return
    const rows = sessions || await chatSessions()
    const active = activeSessionId()
    const query = String($('#rail-chat-search')?.value || '').trim().toLowerCase()
    const visible = rows.filter((session) => chatMatches(session, query)).slice(0, 12)
    list.innerHTML = visible.length
      ? visible.map((session) => `
        <button type="button" class="rail-chat-item ${session.id === active ? 'active' : ''}" data-chat-session="${escapeHtml(session.id)}">
          <span class="rail-chat-icon"><i data-lucide="message-square"></i></span>
          <span class="rail-chat-copy"><strong>${escapeHtml(session.title || 'New chat')}</strong><small>${session.message_count || 0} messages</small></span>
          <time>${session.updated_at ? relativeTime(session.updated_at) : ''}</time>
        </button>`).join('')
      : `<p class="rail-chat-empty">${rows.length ? 'No conversations match that search.' : 'No saved conversations yet — your first chat will appear here.'}</p>`
    if (window.lucide?.createIcons) window.lucide.createIcons()
  }

  function bindChatRail() {
    $('#rail-chat-history-list')?.addEventListener('click', (event) => {
      const item = event.target.closest('[data-chat-session]')
      if (item) loadChatSession(item.dataset.chatSession)
    })
    $('#chat-history-view-all')?.addEventListener('click', () => {
      const drawer = $('#chat-history')
      if (!drawer) return
      drawer.hidden = false
      $('#chat-history-toggle')?.classList.add('active')
      renderChatHistory()
    })
    const refresh = () => renderChatHistory()
    $('#rail-chat-search')?.addEventListener('input', refresh)
    $('#chat-history-search')?.addEventListener('input', refresh)
    renderRailChatHistory()
  }

  function pendingReminders() {
    try { return JSON.parse(localStorage.getItem('jarvis-reminders') || '[]') } catch { return [] }
  }

  function refreshNotifyDot() {
    const dot = $('#notify-dot')
    if (dot) dot.hidden = pendingReminders().length === 0
  }

  function bindNotifyButton() {
    $('#notify-button')?.addEventListener('click', () => {
      const reminders = pendingReminders()
      if (!reminders.length) return showToast('No pending reminders.')
      showToast(`Pending reminders: ${reminders.map((item) => `${item.text} — ${new Date(item.time).toLocaleString()}`).join(' | ')}`)
    })
    refreshNotifyDot()
  }

  function updateStatusReadouts() {
    const online = state.coreOnline || state.bridgeOnline
    const live = $('#rail-live')
    if (live) {
      live.textContent = online ? 'LIVE' : 'OFFLINE'
      live.classList.toggle('online', online)
      live.classList.toggle('offline', !online)
    }
    const miniLive = $('#mini-live')
    if (miniLive) miniLive.textContent = state.coreOnline ? 'Core + bridge online' : state.bridgeOnline ? 'Bridge online — voice core offline' : 'Background core offline'
    const dot = $('#screen-dot')
    const screenState = $('#screen-state')
    const screenNote = $('#screen-note')
    if (dot) dot.classList.toggle('online', online)
    if (screenState) screenState.textContent = online ? 'Ready' : 'Offline'
    if (screenNote) screenNote.textContent = state.bridgeOnline ? 'screen agent standing by for a screen task' : 'start the Windows bridge to enable the screen agent'
  }

  let _lastHudSummon = 0
  function summonFloatingHud() {
    const now = Date.now()
    if (now - _lastHudSummon < 1800) return
    _lastHudSummon = now
    fetch('http://127.0.0.1:7780/float', { method: 'POST', mode: 'cors' })
      .then((response) => { if (response.ok) showToast('Floating JARVIS is on screen.') })
      .catch(() => showToast('Background engine is offline — run: npm run jarvis', true))
  }

  function bindShellExtras() {
    $$('[data-float-hud]').forEach((button) => button.addEventListener('click', summonFloatingHud))
    $('#hud-reset')?.addEventListener('click', () => { applyHudScale(1); showToast('Dashboard zoom reset.') })
    $('#rail-camera-toggle')?.addEventListener('click', () => {
      setWorkspaceModule('camera', false)
      if (state.cameraStream) return showToast('Camera stream is live — see the Camera module.')
      const power = $('#camera-power-toggle') || $('#camera-toggle')
      if (power) power.click()
      else toggleCamera()
    })
    $('#rail-gesture-toggle')?.addEventListener('click', () => {
      setWorkspaceModule('camera', false)
      const toggle = $('.stage-camera .gesture-toggle')
      if (toggle) toggle.click()
      else toggleGestureTracking($('#rail-camera-preview'))
    })
    updateStatusReadouts()
  }

  function updateClock() {
    const now = new Date(), hour = now.getHours()
    const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
    $('#greeting').textContent = `${greeting}, ${state.settings.name || 'Prateek'}.`
    $('#clock').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    $('#date').textContent = now.toLocaleDateString([], { day: '2-digit', month: 'long', year: 'numeric', weekday: 'long' }).toUpperCase()
    if ($('#today-short')) $('#today-short').textContent = now.toLocaleDateString([], { day: '2-digit', month: 'short' }).toUpperCase()
  }

  // Human copy for the conversation header chip and the Voice Assistant strip.
  // Derived from the SAME runtime value the background core reports.
  const CHAT_LIVE_COPY = {
    standby: 'JARVIS is on standby',
    idle: 'JARVIS is on standby',
    listening: 'JARVIS is listening…',
    thinking: 'JARVIS is thinking…',
    searching: 'JARVIS is searching the web…',
    speaking: 'JARVIS is speaking…',
    working: 'JARVIS is working…',
    executing: 'JARVIS is working…',
    interrupted: 'Interrupted — say “Hey JARVIS” to resume',
    sleeping: 'Sleeping — say “Hey JARVIS, wake up”',
    error: 'Something went wrong — check the diagnostics',
    offline: 'Background core offline'
  }

  function setRuntimeState(value) {
    const label = $('#voice-state')
    if (label) label.textContent = value
    const voiceLabel = $('#voice-label')
    if (voiceLabel) voiceLabel.textContent = `${value.toUpperCase()}...`
    // The orb caption, the conversation header chip and the status strip all
    // mirror the SAME runtime value the background core reports.
    const orbState = $('#orb-state')
    if (orbState) orbState.textContent = value.toUpperCase()
    const chatLive = $('#chat-live-state')
    if (chatLive) chatLive.textContent = CHAT_LIVE_COPY[value.toLowerCase()] || 'JARVIS is on standby'
    const miniVoice = $('#mini-voice')
    if (miniVoice) miniVoice.textContent = CHAT_LIVE_COPY[value.toLowerCase()] || 'Standby — say “Hey JARVIS”'
    const chip = $('#command-focus')
    if (chip) chip.lastChild.textContent = value.charAt(0) + value.slice(1).toLowerCase()
    document.body.dataset.runtimeState = value.toLowerCase()
    // JARVIS status pipeline: IDLE → LISTENING → THINKING → SPEAKING → WORKING
    const aliases = { searching: 'thinking', executing: 'working', interrupted: 'idle', error: 'idle', offline: 'idle' }
    const stage = aliases[value.toLowerCase()] || value.toLowerCase()
    const pipeline = $('#status-pipeline')
    if (pipeline) pipeline.querySelectorAll('.stage').forEach((el) => el.classList.toggle('active', el.dataset.stage === stage))
  }
  function navigateTo(id) { document.querySelector(`[data-view="${id}"]`)?.click() }
  function addActivity(title, detail) {
    const item = document.createElement('li')
    item.innerHTML = '<span class="activity-icon"><i data-lucide="terminal"></i></span><div><strong></strong><small></small></div><time>Now</time>'
    item.querySelector('strong').textContent = title
    item.querySelector('small').textContent = detail
    $('#activity-list').prepend(item)
    while ($('#activity-list').children.length > 5) $('#activity-list').lastElementChild.remove()
    if (window.lucide) window.lucide.createIcons()
  }
  function showToast(message, error = false) {
    const region = $('#toast-region')
    if (region) {
      const existing = Array.from(region.querySelectorAll('.toast')).find(t => t.textContent === message)
      if (existing) return { update: () => {}, dismiss: () => existing.remove() }
      while (region.children.length >= 3) region.firstElementChild?.remove()
    }
    const toast = document.createElement('div'); toast.className = `toast${error ? ' error' : ''}`; toast.textContent = message
    if (region) region.append(toast)
    let removed = false
    const rm = () => { if (!removed) { removed = true; toast.remove() } }
    const timer = setTimeout(rm, 4200)
    const handle = {
      update: (msg, isError = false) => { toast.textContent = msg; toast.className = `toast${isError ? ' error' : ''}` },
      dismiss: () => { clearTimeout(timer); rm() }
    }
    return handle
  }
  function escapeHtml(text) { const div = document.createElement('div'); div.textContent = text; return div.innerHTML }

  // ══════════════════════════════════════════════════════════════════════════
  // KAMISENSEI STUDIO & ARTIFACT LIBRARY RE-IMPLEMENTATION
  // ══════════════════════════════════════════════════════════════════════════
  const STUDIO_ENABLED_TYPES = ['note', 'mind_map', 'report', 'flashcard_set', 'quiz', 'data_table', 'study_guide', 'briefing_doc', 'faq', 'timeline']
  const STUDIO_TYPE_META = {
    note: { label: 'Notes', icon: 'sticky-note' },
    mind_map: { label: 'Mind Map', icon: 'git-fork' },
    report: { label: 'Reports', icon: 'file-text' },
    flashcard_set: { label: 'Flashcards', icon: 'layers' },
    quiz: { label: 'Quiz', icon: 'help-circle' },
    data_table: { label: 'Data Table', icon: 'table' },
    study_guide: { label: 'Study Guide', icon: 'graduation-cap' },
    briefing_doc: { label: 'Briefing Doc', icon: 'file-text' },
    faq: { label: 'FAQ', icon: 'message-circle-question' },
    timeline: { label: 'Timeline', icon: 'history' },
    audio_overview: { label: 'Audio Overview', icon: 'audio-lines' }
  }

  // Two-state Studio panel: 'dashboard' (generation grid + artifact library)
  // or 'artifact' (full-panel interactive artifact viewer).
  let studioView = 'dashboard'
  let activeArtifactId = null
  let ksSelectedSources = [] // filenames the user picked for artifact generation

  function ksTimeAgo(iso) {
    const then = new Date(iso).getTime()
    if (!Number.isFinite(then)) return ''
    const mins = Math.floor(Math.max(0, Date.now() - then) / 60000)
    if (mins < 1) return 'Just now'
    if (mins < 60) return `${mins} minute${mins === 1 ? '' : 's'} ago`
    const hours = Math.floor(mins / 60)
    if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`
    const days = Math.floor(hours / 24)
    return `${days} day${days === 1 ? '' : 's'} ago`
  }

  function initStudioUI() {
    // Async boot: wait for the IndexedDB state core, then bind + restore.
    window.KS.ready.then(async () => {
      bindStudioDashboard()
      bindArtifactWorkspace()
      initStudioSplitter()
      // Source selection is PER-NOTEBOOK now: nothing global is restored at
      // boot — a notebook's own selection loads when it is opened.
      ksSelectedSources = []
      await Promise.all([loadKsSources(), loadKsStatus(), loadKsJsonSources({ silent: true })])
      await ensureActiveNotebook()
      await ksMigrateLegacyNotebookData()
      window.KS.prefs.get('ks-last-artifact', null).then((id) => {
        if (!id) return
        window.KS.artifacts.get(id).then((art) => {
          // Boot restore guard: only reopen the last artifact when it belongs
          // to the ACTIVE notebook — never surface another workspace's output.
          if (art && art.status === 'ready' && String(art.notebookId || '') === ksActiveNotebookId()) openArtifactViewer(art.id, { restored: true })
        })
      })
      // Any Audio Overview left in 'generating' by a previous page session has
      // no live SSE stream to finish it — recover it honestly, then render.
      await ksRecoverStuckAudioArtifacts()
      window.KS.bus.on('artifacts:changed', refreshArtifactLibrary)
      refreshArtifactLibrary()
    }).catch((err) => console.error('[KS] Studio init failed:', err))
  }

  function refreshArtifactLibrary() {
    if (studioView === 'dashboard') renderArtifactLibrary()
  }

  function bindStudioDashboard() {
        document.querySelectorAll('.studio-macro-card[data-studio-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const action = btn.getAttribute('data-studio-action')
        if (action === 'audio_overview') { openKsPodcastModal(); return } // local Kokoro-82M podcast
        if (!STUDIO_ENABLED_TYPES.includes(action)) return // disabled tiles never trigger
        openArtifactModal(action)
      })
    })
    $('#studio-add-note-btn')?.addEventListener('click', startManualNote)
    $('#ks-artifact-close')?.addEventListener('click', closeArtifactModal)
    $('#ks-art-cancel')?.addEventListener('click', closeArtifactModal)
    $('#ks-art-generate')?.addEventListener('click', submitArtifactGeneration)
  }

    /* ── KamiSensei AI Podcast Studio (local Kokoro-82M offline TTS) ──────────
   * Server streams NDJSON (one JSON object per "\n") from
   *   POST /api/kamisensei/generate-podcast
   * frames: {type:'script',script,total_turns}
   *   {type:'audio',batch,batches,turn,speaker,text,audio:<base64 wav>}
   *   {type:'tts_warning',message,turn}  {type:'error',message}
   *   {type:'done',total_turns,total_batches,url,seconds,engine}
   */
  const ksPodcast = {
    ctx: null, src: null, queue: [], playing: false,
    abort: null, script: [], totalTurns: 0, totalBatches: 0,
    notebookId: null, format: 'deep_dive', length: 'default',
  }
  function ksPodcastNotebookId() { return (ksRoute && (ksRoute.notebookId || ksRoute.workbook)) || 'session' }
  function ksPodcastStopPlayback() {
    try { if (ksPodcast.ctx) { ksPodcast.ctx.close() } } catch (e) {}
    ksPodcast.ctx = null
    if (ksPodcast.src) { try { ksPodcast.src.stop() } catch (e) {} ksPodcast.src = null }
    ksPodcast.queue = []
    ksPodcast.playing = false
  }
  function ksPodcastReset() {
    ksPodcastStopPlayback()
    ksPodcast.script = []
    ksPodcast.totalTurns = 0
    ksPodcast.totalBatches = 0
    if (ksPodcast.abort) { try { ksPodcast.abort.abort() } catch (e) {} ksPodcast.abort = null }
    const thinking = $('#ks-pod-thinking')
    if (thinking) thinking.style.display = 'none'
    const gen = $('#ks-pod-generate')
    if (gen) gen.disabled = false
    const stop = $('#ks-pod-stop')
    if (stop) stop.style.display = 'none'
  }
  async function openKsPodcastModal(workbookKey) {
    const modal = $('#ks-podcast-modal')
    if (!modal) return
    ksPodcast.notebookId = workbookKey || ksPodcastNotebookId()
    modal.style.display = 'flex'
    ksPodcastReset()
    ksPodcastBindControls()
    const status = $('#ks-pod-status')
    if (status) status.textContent = 'Configure your AI co-hosts and press Generate.'
    // Fetch fresh sources from both ChromaDB and JSON store before populating
    await loadKsSources()
    await loadKsJsonSources({ silent: true })
    populateKsPodcastSources()
    if (window.lucide) window.lucide.createIcons()
  }
  function closeKsPodcastModal() { stopKsPodcastStream(); const m = $('#ks-podcast-modal'); if (m) m.style.display = 'none'; ksPodcast.notebookId = null }
  function populateKsPodcastSources() {
    const box = $('#ks-pod-sources')
    if (!box) return
    box.innerHTML = '<span class="ks-art-src-loading">Loading sources…</span>'
    
    // Combine both ChromaDB sources AND JSON-store YouTube transcripts
    const manifest = ksNotebookManifestNames()
    const allSources = []
    
    // Add ChromaDB sources (PDFs, etc.)
    if (ksSourceCache && ksSourceCache.length) {
      ksSourceCache.forEach((file) => {
        const name = ksSourceName(file)
        if (!name) return
        if (manifest.size && !manifest.has(name)) return
        allSources.push({ name, type: 'file', file })
      })
    }
    
    // Add JSON-store YouTube transcripts
    if (ksJsonSources && ksJsonSources.length) {
      ksJsonSources.forEach((src) => {
        const name = src.title || src.url || 'YouTube Source'
        if (manifest.size && !manifest.has(name)) return
        allSources.push({ name, type: 'youtube', src })
      })
    }
    
    if (!allSources.length) {
      box.innerHTML = '<span class="ks-art-src-loading">This notebook has no sources yet. Add sources to ground the podcast.</span>'
      return
    }
    
    box.innerHTML = ''
    allSources.forEach((item) => {
      const name = item.name
      const label = document.createElement('label')
      label.style.display = 'flex'; label.style.alignItems = 'center'; label.style.gap = '6px'
      label.style.fontSize = '11px'; label.style.color = '#cde7f2'
      const cb = document.createElement('input')
      cb.type = 'checkbox'; cb.value = name
      cb.checked = ksSelectedSources.includes(name)
      cb.style.accentColor = '#22c7f2'
      cb.addEventListener('change', () => {
        if (cb.checked) { if (!ksSelectedSources.includes(name)) ksSelectedSources.push(name) }
        else ksSelectedSources = ksSelectedSources.filter((s) => s !== name)
        persistKsSourceSelection()
      })
      label.appendChild(cb)
      // Add type indicator icon
      const icon = document.createTextNode(item.type === 'youtube' ? '▶ ' : '📄 ')
      label.appendChild(icon)
      label.appendChild(document.createTextNode(name))
      box.appendChild(label)
    })
  }
  function ksPodcastReadFormat() {
    const active = $('.ks-pod-format-btn.active')
    return active ? active.getAttribute('data-format') : (ksPodcast.format || 'deep_dive')
  }
  function ksPodcastReadLength() {
    const active = $('.ks-pod-len-btn.active')
    return active ? active.getAttribute('data-len') : (ksPodcast.length || 'default')
  }
  function ksPodcastBindControls() {
    if (ksPodcast._bound) return
    ksPodcast._bound = true
    const fmtBtns = document.querySelectorAll('.ks-pod-format-btn')
    fmtBtns.forEach((b) => {
      b.addEventListener('click', () => {
        document.querySelectorAll('.ks-pod-format-btn').forEach((x) => x.classList.remove('active'))
        b.classList.add('active')
        ksPodcast.format = b.getAttribute('data-format') || 'deep_dive'
      })
    })
    const lenBtns = document.querySelectorAll('.ks-pod-len-btn')
    lenBtns.forEach((b) => {
      b.addEventListener('click', () => {
        document.querySelectorAll('.ks-pod-len-btn').forEach((x) => x.classList.remove('active'))
        b.classList.add('active')
        ksPodcast.length = b.getAttribute('data-len') || 'default'
      })
    })
  }
  function ksPodcastCustomSources() {
    const allSources = $('#ks-pod-all-sources')
    if (allSources && allSources.checked) return null
    return ksSelectedSources.length ? [...ksSelectedSources] : null
  }
    async function startKsPodcastStream() {
    const generateBtn = $('#ks-pod-generate')
    const stopBtn = $('#ks-pod-stop')
    const thinking = $('#ks-pod-thinking')
    const status = $('#ks-pod-status')
    const rateEl = $('#ks-pod-rate')
    const rateVal = $('#ks-pod-rate-val')
    const languageEl = $('#ks-pod-language')

    if (generateBtn) generateBtn.disabled = true
    if (stopBtn) stopBtn.style.display = 'inline-flex'
    if (thinking) thinking.style.display = 'flex'
    if (status) status.textContent = 'Thinking… local Kokoro-82M is composing the dialogue script.'
    ksPodcastStopPlayback()
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    // Live chunk autoplay is disabled on purpose: the old code sounded each turn
    // the moment it arrived (before the full podcast was compiled) through a raw
    // WebAudio context that had no visible player. Audio now plays once, in the
    // mini-player, from the compiled master file — see handleKsPodcastDone().

    const lenKey = ksPodcastReadLength()
    const durationMinutes = (lenKey === 'short' ? 6 : lenKey === 'long' ? 15 : 10)
    const promptEl = document.getElementById('ks-pod-custom-prompt')
    const srcs = ksPodcastCustomSources()
    // Commit the Audio Overview into the persistent Artifact Library right
    // away as a 'generating' record, then close the modal — the Studio card
    // carries the live status from this moment on.
    const focus = promptEl ? promptEl.value.trim() : ''
    const langMode = languageEl ? languageEl.value : 'hinglish'
    // Remember the artifact title/language for the done-flip mini-player opener.
    ksPodcast.title = focus || 'Audio Overview Document'
    ksPodcast.language = langMode
    try {
      // A previous Audio Overview still pending must never stay in limbo once a
      // new run begins — it is superseded and honestly resolved to 'failed'.
      await ksResolvePendingArtifact({ status: 'failed', error: 'Superseded by a new generation.' })
      const record = await window.KS.artifacts.create({
        type: 'audio_overview',
        title: focus || 'Audio Overview Document',
        status: 'generating',
        url: '',
        duration: 0,
        prompt: focus,
        format: ksPodcastReadFormat(),
        language: langMode,
        sources: srcs || [],
        sourceCount: srcs ? srcs.length : 0,
        notebookId: ksPodcast.notebookId || ksPodcastNotebookId()
      })
      ksPodcast.artifactId = record.id
      // Persist the pending id — a reload mid-generation then recovers this card
      // instead of stranding it forever (ksResolvePendingArtifact uses it).
      await window.KS.prefs.set('ks-pending-audio-artifact', { id: record.id, notebookId: record.notebookId, ts: Date.now() }).catch(() => {})
    } catch (err) {
      console.error('[KS Podcast] artifact commit failed:', err)
      ksPodcast.artifactId = null
    }
    const podModal = $('#ks-podcast-modal')
    if (podModal) podModal.style.display = 'none'
    if (studioView !== 'dashboard') setStudioView('dashboard')
    const body = {
      notebookId: ksPodcast.notebookId || ksPodcastNotebookId(),
      speech_rate: rateEl ? (parseFloat(rateEl.value) || 1) : 1,
      mode: 'notebooklm',
      format: ksPodcastReadFormat(),
      language_mode: languageEl ? languageEl.value : 'hinglish',
      duration_minutes: durationMinutes,
      custom_prompt: promptEl ? promptEl.value.trim() : '',
      sources: srcs && srcs.length ? srcs : undefined,
    }
    if (rateVal && rateEl) rateVal.textContent = `${parseFloat(rateEl.value).toFixed(2)}x`

          ksPodcast.abort = new AbortController()
      ksPodcast.finalized = false
    try {
      const res = await fetch('/api/kamisensei/generate-podcast', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body), signal: ksPodcast.abort.signal,
      })
      if (!res.ok) throw new Error(`Podcast engine returned HTTP ${res.status}`)
      if (!res.body) throw new Error('No stream returned from the podcast engine.')
      const reader = res.body.getReader()
      const dec = new TextDecoder()
      let buf = ''
      while (true) {
        if (ksPodcast.abort && ksPodcast.abort.signal.aborted) return
                const { done, value } = await reader.read()
        if (done) { if (!ksPodcast.finalized) handleKsPodcastDone(); return }
        buf += dec.decode(value, { stream: true })
        let nl
        while ((nl = buf.indexOf('\n')) !== -1) {
          const line = buf.slice(0, nl).trim()
          buf = buf.slice(nl + 1)
          if (!line) continue
          let payload
          try { payload = JSON.parse(line) } catch (e) { console.debug('[KS Podcast] ignored line:', line.slice(0, 80)); continue }
          handleKsPodcastFrame(payload)
        }
      }
    } catch (err) {
      if (ksPodcast.abort && ksPodcast.abort.signal.aborted) return
      console.error('[KS Podcast] stream failed:', err)
      ksAudioArtifactFail(err.message || 'stream failed')
      if (status) status.textContent = `Error: ${err.message || 'stream failed'}`
      showToast('Podcast generation failed: ' + (err.message || 'unknown error'), true)
    } finally {
      if (generateBtn) generateBtn.disabled = false
      if (thinking) thinking.style.display = 'none'
    }
  }
    function handleKsPodcastFrame(payload) {
    const status = $('#ks-pod-status')
    const thinking = $('#ks-pod-thinking')
    switch (payload.type) {
      case 'meta':
        ksPodcast.meta = payload
        break
      case 'script':
        ksPodcast.script = Array.isArray(payload.script) ? payload.script : []
        ksPodcast.totalTurns = payload.total_turns || ksPodcast.script.length
        if (status) status.textContent = `Script complete — ${ksPodcast.totalTurns} dialogue turn${ksPodcast.totalTurns === 1 ? '' : 's'}. Synthesizing locally…`
        if (thinking) thinking.style.display = 'flex'
        break
      case 'audio':
        if (!payload.audio) { if (status) status.textContent = 'Synthesis pause — a dialogue turn was skipped.'; return }
        ksPodcastQueueAudio(payload.audio, payload)
        if (status) status.textContent = `Synthesizing turn ${payload.turn + 1}/${ksPodcast.totalTurns || '?'} — ${payload.speaker}`
        break
      case 'tts_warning':
        console.warn('[KS Podcast] tts_warning:', payload.message)
        showToast('Kokoro TTS note: ' + payload.message)
        break
      case 'error':
        console.error('[KS Podcast] engine error:', payload.message)
        showToast('Podcast error: ' + payload.message, true)
        if (status) status.textContent = `Error: ${payload.message || 'engine error'}`
        ksAudioArtifactFail(payload.message)
        break
      case 'done':
        handleKsPodcastDone(payload)
        break
    }
  }
  function ksPodcastQueueAudio(b64, turn) {
    // Live chunk playback is intentionally removed: streaming turns would start
    // sounding before the whole podcast is compiled and had no visible player.
    // Progress is still reported by the 'audio' frame handler in
    // handleKsPodcastFrame(); the finished file is played via the mini-player.
  }
  async function ksPodcastDrainQueue() {
    if (!ksPodcast.ctx || ksPodcast.queue.length === 0) { ksPodcast.playing = false; return }
    ksPodcast.playing = true
    const item = ksPodcast.queue.shift()
    try {
      const src = ksPodcast.ctx.createBufferSource()
      src.buffer = await ksPodcast.ctx.decodeAudioData(item.bytes)
      src.connect(ksPodcast.ctx.destination)
      ksPodcast.src = src
      const status = $('#ks-pod-status')
      if (status) status.textContent = `▶ ${item.speaker}: ${item.text.slice(0, 96)}${item.text.length > 96 ? '…' : ''}`
      src.onended = () => { ksPodcast.src = null; ksPodcastDrainQueue() }
      src.start(0)
    } catch (e) {
      console.warn('[KS Podcast] decode/play failed:', e)
      ksPodcast.src = null
      ksPodcastDrainQueue()
    }
  }
  function ksPodcastDecodeB64(b64) {
    try {
      const binary = atob(b64)
      const bytes = new Uint8Array(binary.length)
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)
      return bytes.buffer
    } catch (e) {
      console.error('[KS Podcast] base64 decode failed:', e)
      return null
    }
  }
    async function handleKsPodcastDone(payload = {}) {
    ksPodcast.finalized = true
    const thinking = $('#ks-pod-thinking')
    const status = $('#ks-pod-status')
    const gen = $('#ks-pod-generate')
    const stop = $('#ks-pod-stop')
    if (thinking) thinking.style.display = 'none'
    if (gen) gen.disabled = false
    if (stop) stop.style.display = 'none'
    ksPodcast.playing = false
    if (payload && payload.url && status) {
      const secs = payload.seconds ? ` · ${payload.seconds}s` : ''
      const engine = payload.engine || 'kokoro-82m-local'
      status.innerHTML = `<span style="color:#8ee8ff">Podcast ready</span> · engine ${engine}${secs} · <a href="${payload.url}" target="_blank" rel="noopener" style="color:#22c7f2">Open recording</a>`
    } else if (status) {
      status.textContent = 'Podcast stream complete. Chunk playback above still works.'
    }
    // Flip the committed artifact from 'generating' to 'ready' with the
    // compiled master URL — its Studio card becomes a live player instantly.
    // The pending id lives BOTH in memory and in KS.prefs, so a card can never
    // be orphaned in 'generating' forever: whichever path completes first
    // resolves it (memory first, persisted id as the reload-safe fallback).
    const resolvedId = await ksResolvePendingArtifact({
      status: payload && payload.url ? 'ready' : 'failed',
      url: (payload && payload.url) || '',
      duration: Number(payload && payload.seconds) || 0,
      error: payload && payload.url ? null : 'Compilation finished without a master file.'
    })
    // Surface the finished podcast in the bottom-docked mini-player. This is the
    // only place audio plays now — the old live WebAudio chunk stream (which had
    // no UI and started before the file was ready) is gone.
    if (payload && payload.url && resolvedId) {
      openKsMiniPlayer({
        id: resolvedId,
        title: ksPodcast.title || 'Audio Overview Document',
        url: payload.url,
        duration: Number(payload.seconds) || 0,
        language: ksPodcast.language || 'hinglish',
        format: ksPodcast.format || ksPodcastReadFormat() || 'deep_dive',
      })
    }
  }
  /** Resolve (and forget) whichever Audio Overview is currently pending, using
   * the in-memory id first, then the persisted id that survives reloads.
   * Returns the resolved artifact id (or null when nothing was pending). */
  async function ksResolvePendingArtifact(patch) {
    const stored = await window.KS.prefs.get('ks-pending-audio-artifact', null)
    const pending = ksPodcast.artifactId || (stored && (typeof stored === 'string' ? stored : stored.id))
    if (!pending) return null
    ksPodcast.artifactId = null
    await window.KS.prefs.set('ks-pending-audio-artifact', null).catch(() => {})
    try {
      const existing = await window.KS.artifacts.get(pending)
      if (!existing || existing.status !== 'generating') return pending
      await window.KS.artifacts.update(pending, patch)
    } catch (err) {
      console.error('[KS Podcast] artifact completion failed:', err)
    }
    return pending
  }
  function ksAudioArtifactFail(message) {
    ksResolvePendingArtifact({ status: 'failed', error: message || 'Generation failed' })
  }
  function stopKsPodcastStream() {
        if (ksPodcast.abort) { try { ksPodcast.abort.abort() } catch (e) {} ksPodcast.abort = null }
    ksPodcastStopPlayback()
    ksPodcast.finalized = false
    // Force-kill every audio channel: Web Speech queue, any artifact player,
    // and the streaming fetch — nothing may keep speaking after Stop.
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    const sharedAudio = ksAudioEl()
    if (sharedAudio) { try { sharedAudio.pause() } catch (e) {} }
    ksAudioArtifactFail('Stopped by user.')
    const thinking = $('#ks-pod-thinking')
    if (thinking) thinking.style.display = 'none'
    const gen = $('#ks-pod-generate')
    if (gen) gen.disabled = false
    const stop = $('#ks-pod-stop')
    if (stop) stop.style.display = 'none'
    const status = $('#ks-pod-status')
    if (status) status.textContent = 'Stopped. Local synthesis and playback cancelled.'
  }
  function initKsPodcastUI() {
    const modal = $('#ks-podcast-modal')
    if (!modal) return
    $('#ks-podcast-close')?.addEventListener('click', closeKsPodcastModal)

    const rateEl = $('#ks-pod-rate')
    const rateVal = $('#ks-pod-rate-val')
    if (rateEl && rateVal) {
      rateVal.textContent = `${parseFloat(rateEl.value).toFixed(2)}x`
      rateEl.addEventListener('input', () => { rateVal.textContent = `${parseFloat(rateEl.value).toFixed(2)}x` })
    }

    $('#ks-pod-stop')?.addEventListener('click', stopKsPodcastStream)
    $('#ks-pod-generate')?.addEventListener('click', () => {
      if ('speechSynthesis' in window) window.speechSynthesis.cancel()
      startKsPodcastStream()
    })

    modal.addEventListener('click', (e) => { if (e.target === modal) closeKsPodcastModal() })
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.style.display === 'flex') closeKsPodcastModal() })
  }
  /* ── NotebookLM Audio Hub — track history + holographic footer player ──────
   * Every compiled Kokoro-82M master MP3 (/static/podcast_<key>.mp3, produced
   * by the local engine on http://127.0.0.1:7779) is registered here on the
   * done frame, persisted per-notebook via KS.prefs (IndexedDB), rendered as a
   * scrollable stacked list with waveform + metadata + context dropdown, and
   * mounted into the docked footer timeline player (#ks-global-player).
   */
  const KS_AUDIO_SPEEDS = [1, 1.2, 1.4]
  const KS_AUDIO_FORMAT_LABELS = { deep_dive: 'Deep Dive', brief: 'Brief', critique: 'Critique', debate: 'Debate' }
  const ksAudio = { tracks: [], currentId: null, speedIdx: 0, seekDragging: false }
  function ksAudioEl() { return document.getElementById('ks-global-audio') }
  function ksAudioPrefKey() { return 'ks-podcast-tracks-' + (ksPodcastNotebookId() || 'session') }
  function ksAudioFormatDur(total) {
    const s = Math.max(0, Math.round(Number(total) || 0))
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
  }
  async function loadKsAudioHub() {
    try {
      const saved = await window.KS.prefs.get(ksAudioPrefKey(), [])
      ksAudio.tracks = Array.isArray(saved) ? saved : []
    } catch (err) {
      console.error('[KS Audio Hub] load failed:', err)
      ksAudio.tracks = []
    }
    renderKsAudioHub()
  }
  function ksAudioPersist() {
    window.KS.prefs.set(ksAudioPrefKey(), ksAudio.tracks).catch((err) => console.error('[KS Audio Hub] persist failed:', err))
  }
  function renderKsAudioHub() {
    const hub = $('#ks-audio-hub')
    const list = $('#ks-audio-track-list')
    const player = $('#ks-global-player')
    if (!hub || !list) return
    const count = $('#ks-audio-hub-count')
    if (count) count.textContent = ksAudio.tracks.length ? `${ksAudio.tracks.length} episode${ksAudio.tracks.length === 1 ? '' : 's'}` : ''
    if (!ksAudio.tracks.length) {
      hub.style.display = 'none'
      if (player && !ksAudio.currentId) player.style.display = 'none'
      return
    }
    hub.style.display = ''
    if (player) player.style.display = ''
    list.innerHTML = ''
    ksAudio.tracks.forEach((t) => {
      const isCurrent = ksAudio.currentId === t.id
      const item = document.createElement('div')
      item.className = 'ks-audio-item' + (isCurrent ? ' active' : '')
      item.dataset.trackId = t.id

      const wave = document.createElement('span')
      wave.className = 'ks-wave' + (isCurrent && ksAudioEl() && !ksAudioEl().paused ? ' playing' : '')
      wave.innerHTML = '<i></i><i></i><i></i><i></i><i></i>'
      item.appendChild(wave)

      const main = document.createElement('div')
      main.className = 'ks-audio-item-main'
      const title = document.createElement('span')
      title.className = 'ks-audio-item-title'
      title.textContent = t.title || 'Audio Overview'
      main.appendChild(title)
      const meta = document.createElement('span')
      meta.className = 'ks-audio-item-meta'
      const srcCount = t.sourceCount || 0
      meta.textContent = `${ksAudioFormatDur(t.seconds)} • ${srcCount} source${srcCount === 1 ? '' : 's'} • ${ksTimeAgo(t.createdAt)}`
      main.appendChild(meta)
      item.appendChild(main)

      const menuBtn = document.createElement('button')
      menuBtn.className = 'ks-audio-item-menu'
      menuBtn.type = 'button'
      menuBtn.title = 'Audio Overview actions'
      menuBtn.innerHTML = '<i data-lucide="more-vertical"></i>'
      menuBtn.addEventListener('click', (e) => { e.stopPropagation(); openKsTrackMenu(e, t.id) })
      item.appendChild(menuBtn)

      const details = document.createElement('div')
      details.className = 'ks-audio-item-details'
      details.id = `ks-audio-details-${t.id}`
      details.style.display = 'none'
      const focusLabel = t.prompt ? t.prompt : 'No custom focus prompt — full knowledge base dive.'
      const srcList = (Array.isArray(t.sources) && t.sources.length) ? t.sources.join(', ') : 'Entire knowledge base'
      details.innerHTML = `<div class="ks-ad-row"><b>Focus prompt</b><span></span></div><div class="ks-ad-row"><b>Format</b><span></span></div><div class="ks-ad-row"><b>Sources</b><span></span></div>`
      const spans = details.querySelectorAll('.ks-ad-row span')
      if (spans[0]) spans[0].textContent = focusLabel
      if (spans[1]) spans[1].textContent = `${KS_AUDIO_FORMAT_LABELS[t.format] || t.format || 'Deep Dive'} • ${t.language || 'hinglish'}`
      if (spans[2]) spans[2].textContent = srcList
      item.appendChild(details)

      item.addEventListener('click', () => playKsTrack(t.id))
      list.appendChild(item)
    })
    if (window.lucide) window.lucide.createIcons()
  }
  function playKsTrack(id) {
    const t = ksAudio.tracks.find((x) => x.id === id)
    const a = ksAudioEl()
    if (!t || !a) return
    const target = new URL(t.url, location.href).href
    if (a.src !== target) { a.src = t.url; a.playbackRate = KS_AUDIO_SPEEDS[ksAudio.speedIdx] }
    ksAudio.currentId = id
    const label = $('#ks-global-track-title')
    if (label) label.textContent = t.title || 'Audio Overview'
    const player = $('#ks-global-player')
    if (player) player.style.display = ''
    a.play().catch((err) => console.warn('[KS Audio Hub] autoplay blocked:', err))
    renderKsAudioHub()
  }
  function ksAudioSyncPlayIcon() {
    const a = ksAudioEl()
    if (!a) return
    const btn = $('#ks-global-play')
    if (btn) btn.innerHTML = `<i data-lucide="${a.paused ? 'play' : 'pause'}"></i>`
    if (window.lucide) window.lucide.createIcons()
  }
  function initKsAudioHub() {
    const a = ksAudioEl()
    if (!a || a.dataset.ksAudioBound) return
    a.dataset.ksAudioBound = '1'
    const seek = $('#ks-global-seekbar')
    const cur = $('#ks-global-cur')
    const dur = $('#ks-global-dur')
    a.addEventListener('loadedmetadata', () => {
      if (dur) dur.textContent = ksAudioFormatDur(a.duration)
      if (seek && Number.isFinite(a.duration)) seek.max = String(a.duration)
    })
    a.addEventListener('timeupdate', () => {
      if (cur) cur.textContent = ksAudioFormatDur(a.currentTime)
      if (seek && !ksAudio.seekDragging) seek.value = String(a.currentTime)
    })
    a.addEventListener('play', () => { ksAudioPauseAllExcept(a); ksAudioSyncPlayIcon(); renderKsAudioHub() })
    a.addEventListener('pause', () => { ksAudioSyncPlayIcon(); renderKsAudioHub() })
    a.addEventListener('ended', () => { ksAudioSyncPlayIcon(); renderKsAudioHub() })
    if (seek) {
      seek.addEventListener('pointerdown', () => { ksAudio.seekDragging = true })
      seek.addEventListener('pointerup', () => { ksAudio.seekDragging = false })
      seek.addEventListener('input', () => { a.currentTime = parseFloat(seek.value) || 0 })
    }
    $('#ks-global-play')?.addEventListener('click', () => { if (a.paused) a.play().catch(() => {}); else a.pause() })
    $('#ks-global-back')?.addEventListener('click', () => { a.currentTime = Math.max(0, a.currentTime - 10) })
    $('#ks-global-fwd')?.addEventListener('click', () => { a.currentTime = Math.min(a.duration || a.currentTime + 10, a.currentTime + 10) })
    $('#ks-global-speed')?.addEventListener('click', () => {
      ksAudio.speedIdx = (ksAudio.speedIdx + 1) % KS_AUDIO_SPEEDS.length
      a.playbackRate = KS_AUDIO_SPEEDS[ksAudio.speedIdx]
      const badge = $('#ks-global-speed')
      if (badge) badge.textContent = `${KS_AUDIO_SPEEDS[ksAudio.speedIdx].toFixed(1)}x`
    })
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeKsTrackMenu()
    })
  }
  /* ── Per-track context dropdown: Download / Share / Rename / Delete / Info ─ */
  function closeKsTrackMenu() {
    const m = document.getElementById('ks-track-menu')
    if (m) m.remove()
  }
  function ksTrackMenuOutside(e) {
    const m = document.getElementById('ks-track-menu')
    if (m && !m.contains(e.target)) closeKsTrackMenu()
  }
  function openKsTrackMenu(evt, trackId) {
    evt.stopPropagation()
    closeKsTrackMenu()
    document.removeEventListener('click', ksTrackMenuOutside, true)
    const t = ksAudio.tracks.find((x) => x.id === trackId)
    if (!t) return
    const menu = document.createElement('div')
    menu.id = 'ks-track-menu'
    menu.className = 'ks-track-menu'
    const actions = [
      ['⬇️', 'Download', () => {
        const link = document.createElement('a')
        link.href = t.url
        link.download = `${(t.title || 'audio-overview').replace(/[^\w\- ]+/g, '').trim().slice(0, 80) || 'audio-overview'}.mp3`
        document.body.appendChild(link)
        link.click()
        link.remove()
        showToast('Download started')
      }],
      ['🔗', 'Share', () => {
        const shareUrl = new URL(t.url, location.href).href
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(shareUrl)
            .then(() => showToast('Share link copied to clipboard'))
            .catch(() => showToast(shareUrl))
        } else showToast(shareUrl)
      }],
      ['✏️', 'Rename', () => {
        const name = window.prompt('Rename Audio Overview', t.title || '')
        if (name && name.trim()) {
          t.title = name.trim().slice(0, 120)
          ksAudioPersist()
          if (ksAudio.currentId === t.id) { const label = $('#ks-global-track-title'); if (label) label.textContent = t.title }
          renderKsAudioHub()
        }
      }],
      ['🗑️', 'Delete', () => {
        if (!window.confirm('Delete this Audio Overview from the Studio list?')) return
        const wasCurrent = ksAudio.currentId === t.id
        ksAudio.tracks = ksAudio.tracks.filter((x) => x.id !== t.id)
        if (wasCurrent) {
          const a = ksAudioEl()
          if (a) { a.pause(); a.removeAttribute('src'); a.load() }
          ksAudio.currentId = null
          const player = $('#ks-global-player')
          if (player) player.style.display = ksAudio.tracks.length ? '' : 'none'
        }
        ksAudioPersist()
        renderKsAudioHub()
        showToast('Audio Overview deleted')
      }],
      ['ℹ️', 'View prompt and sources', () => {
        const d = document.getElementById(`ks-audio-details-${t.id}`)
        if (d) d.style.display = d.style.display === 'block' ? 'none' : 'block'
      }]
    ]
    actions.forEach(([icon, label, fn]) => {
      const b = document.createElement('button')
      b.type = 'button'
      b.innerHTML = `<span class="ks-tm-icon">${icon}</span><span>${label}</span>`
      b.addEventListener('click', (e) => { e.stopPropagation(); closeKsTrackMenu(); fn() })
      menu.appendChild(b)
    })
    document.body.appendChild(menu)
    const rect = menu.getBoundingClientRect()
    menu.style.left = `${Math.max(8, Math.min(evt.clientX - rect.width + 12, window.innerWidth - rect.width - 8))}px`
    menu.style.top = `${Math.min(evt.clientY + 6, window.innerHeight - rect.height - 8)}px`
    setTimeout(() => document.addEventListener('click', ksTrackMenuOutside, true), 0)
  }
  /* ── done-frame → Audio Hub registration (loads master instantly) ────────── */
  function ksAudioHubRegister(payload) {
    if (!payload || !payload.url) return
    const meta = ksPodcast.meta || {}
    const promptEl = document.getElementById('ks-pod-custom-prompt')
    const focus = promptEl ? promptEl.value.trim() : ''
    const fmtLabel = KS_AUDIO_FORMAT_LABELS[meta.format] || 'Deep Dive'
    const srcUsed = Array.isArray(meta.sources_used) ? meta.sources_used.length : 0
    const track = {
      id: `p${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
      url: payload.url,
      title: focus.slice(0, 72) || `Audio Overview • ${fmtLabel}`,
      seconds: Number(payload.seconds) || 0,
      sourceCount: srcUsed || (Number(meta.context_chunks) || 0),
      createdAt: new Date().toISOString(),
      format: meta.format || ksPodcast.format || 'deep_dive',
      language: meta.language_mode || 'hinglish',
      prompt: focus,
      sources: Array.isArray(meta.sources_used) ? meta.sources_used : []
    }
    ksAudio.tracks.unshift(track)
    if (ksAudio.tracks.length > 50) ksAudio.tracks = ksAudio.tracks.slice(0, 50)
    ksAudioPersist()
    ksAudio.currentId = null
    renderKsAudioHub()
    // Load the finished master into the footer timeline player instantly.
    playKsTrack(track.id)
  }
  /* ── Generation modal (topic + source scope) ────────────────────────────── */
  let modalAction = null

  // Absolute artifact request contract read from the modal controls.
  // { requestedCount, requestedDifficulty, requestedLanguage, requestedDepth }
  function readArtifactContract() {
    const countEl = $('#ks-art-count')
    const depthEl = $('#ks-art-depth')
    const diffEl = $('#ks-art-difficulty')
    const langEl = $('#ks-art-language')
    const count = countEl ? parseInt(countEl.value, 10) : NaN
    return {
      requestedCount: Number.isFinite(count) && count >= 1 ? Math.min(count, 150) : undefined,
      requestedDepth: depthEl && depthEl.value ? depthEl.value : undefined,
      requestedDifficulty: diffEl && diffEl.value ? diffEl.value : undefined,
      requestedLanguage: langEl && langEl.value ? langEl.value : undefined
    }
  }

  function openArtifactModal(action) {
    modalAction = action
    const modal = $('#ks-artifact-modal')
    if (!modal) return
    const title = $('#ks-artifact-modal-title')
    if (title) title.textContent = `Generate ${STUDIO_TYPE_META[action].label}`
    const topic = $('#ks-art-topic')
    if (topic) topic.value = ''
    const genBtn = $('#ks-art-generate')
    if (genBtn) { genBtn.disabled = false; genBtn.textContent = 'Generate' }
    modal.style.display = 'flex'
    populateSourceCheckboxes()
  }

  function closeArtifactModal() {
    const modal = $('#ks-artifact-modal')
    if (modal) modal.style.display = 'none'
    modalAction = null
    const errBox = $('#ks-art-error')
    if (errBox) errBox.textContent = ''
    const genBtn = $('#ks-art-generate')
    if (genBtn) { genBtn.disabled = false; genBtn.textContent = 'Generate' }
  }

  async function populateSourceCheckboxes() {
    const box = $('#ks-art-sources')
    if (!box) return
    box.innerHTML = '<span class="ks-art-src-loading">Loading sources…</span>'
    try {
      const res = await fetch('/api/kamisensei/sources-list', { signal: AbortSignal.timeout(8000) })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      const files = Array.isArray(data.files) ? data.files : []
      box.innerHTML = ''
      // Per-notebook scope: only sources owned by the ACTIVE notebook can be
      // used for artifact generation.
      const manifest = ksNotebookManifestNames()
      const scoped = manifest.size
        ? files.filter((file) => manifest.has(typeof file === 'string' ? file : String(file.filename || file.name || '')))
        : []
      if (!scoped.length) {
        box.innerHTML = '<span class="ks-art-src-loading">This notebook has no sources yet. Add sources first, then generate.</span>'
        return
      }
      scoped.forEach((file) => {
        const name = typeof file === 'string' ? file : String(file.filename || file.name || '')
        if (!name) return
        const label = document.createElement('label')
        label.className = 'ks-art-src-item'
        const cb = document.createElement('input')
        cb.type = 'checkbox'
        cb.value = name
        cb.checked = file.indexed !== false && ksSelectedSources.includes(name)
        cb.disabled = file.indexed === false
        if (cb.disabled) label.title = 'This source has not been indexed yet.'
        cb.addEventListener('change', () => {
          if (cb.checked) { if (!ksSelectedSources.includes(name)) ksSelectedSources.push(name) }
          else ksSelectedSources = ksSelectedSources.filter((s) => s !== name)
          window.KS.prefs.set('ks-selected-sources', [...ksSelectedSources])
            .catch((err) => console.error('[KS] Source selection persistence failed:', err))
        })
        label.appendChild(cb)
        label.appendChild(document.createTextNode(' ' + name))
        box.appendChild(label)
      })
    } catch (err) {
      console.error('[KS] Failed to load source list:', err)
      box.innerHTML = '<span class="ks-art-src-loading">Could not load the source list. Check the local bridge and vector service before generating.</span>'
    }
  }

  /* ── Studio two-state rendering ─────────────────────────────────────────── */
  function renderStudio() {
    const dash = $('#ks-studio-dashboard')
    const ws = $('#ks-artifact-workspace')
    if (!dash || !ws) return
    if (studioView === 'artifact') {
      dash.style.display = 'none'
      ws.style.display = 'flex'
      renderArtifactViewer()
    } else {
      dash.style.display = ''
      ws.style.display = 'none'
      renderArtifactLibrary()
      loadKsAudioHub()
    }
  }

  function renderArtifactLibrary() {
    const library = $('#ks-artifact-library')
    if (!library) return
    window.KS.artifacts.all().then((items) => {
      // Preserve in-card audio playback across re-renders (artifact updates
      // trigger full library rebuilds — a playing episode must not restart).
      const playingCard = library.querySelector('.ks-audio-art-player audio')
      const resume = playingCard && !playingCard.paused
        ? { id: playingCard.closest('[data-artifact-id]')?.dataset.artifactId, time: playingCard.currentTime, rate: playingCard.playbackRate }
        : null
      library.innerHTML = ''
      library.style.display = ''

      const header = document.createElement('div')
      header.className = 'ks-art-lib-title'
      header.textContent = 'Artifact Library'
      library.appendChild(header)

      // PER-NOTEBOOK ISOLATION: only artifacts created inside the ACTIVE
      // notebook are rendered. Without this filter the first notebook's
      // Studio output used to appear in EVERY notebook. Legacy records
      // created before notebook tagging have no owner — they stay in
      // IndexedDB but are never shown inside a workspace.
      const activeNb = ksActiveNotebookId()
      items = items.filter((a) => String(a.notebookId || '') === activeNb)

      if (!items.length) {
        const empty = document.createElement('div')
        empty.className = 'ks-art-lib-empty'
        empty.textContent = 'Studio output for this notebook will be saved here. Generate an artifact above or add a note.'
        library.appendChild(empty)
        return
      }

      items.forEach((art) => {
        if (art.type === 'audio_overview') { renderKsAudioArtifactCard(library, art); return }
        const meta = STUDIO_TYPE_META[art.type] || { label: art.type, icon: 'file-text' }
        const card = document.createElement('div')
        card.className = 'ks-art-lib-item' + (art.status === 'failed' ? ' failed' : '') + (art.status === 'generating' ? ' generating' : '')
        card.dataset.artifactId = art.id

        const main = document.createElement('div')
        main.className = 'ks-art-lib-main'
        const row1 = document.createElement('div')
        row1.className = 'ks-art-lib-row1'
        row1.innerHTML = `<i data-lucide="${meta.icon}"></i>`
        const label = document.createElement('span')
        label.className = 'ks-art-lib-label'
        label.textContent = art.title || meta.label
        row1.appendChild(label)
        main.appendChild(row1)
        const metaLine = document.createElement('span')
        metaLine.className = 'ks-art-lib-meta'
        const srcPart = art.sourceCount ? `${art.sourceCount} source${art.sourceCount === 1 ? '' : 's'} • ` : ''
        metaLine.textContent = `${meta.label} • ${srcPart}${ksTimeAgo(art.updatedAt)}`
        main.appendChild(metaLine)
        card.appendChild(main)

        if (art.status === 'generating') {
          const spin = document.createElement('span')
          spin.className = 'ks-art-lib-status'
          spin.innerHTML = '<i data-lucide="loader-2" class="spin"></i> Generating…'
          card.appendChild(spin)
        } else if (art.status === 'failed') {
          const fail = document.createElement('button')
          fail.className = 'ks-art-lib-status failed'
          fail.type = 'button'
          fail.title = art.error || 'Generation failed'
          fail.innerHTML = '<i data-lucide="rotate-cw"></i> Retry'
          fail.addEventListener('click', (e) => { e.stopPropagation(); retryArtifact(art) })
          card.appendChild(fail)
        }

        const menuBtn = document.createElement('button')
        menuBtn.className = 'ks-art-lib-menu'
        menuBtn.type = 'button'
        menuBtn.title = 'Artifact actions'
        menuBtn.innerHTML = '<i data-lucide="more-vertical"></i>'
        menuBtn.addEventListener('click', (e) => { e.stopPropagation(); openArtifactCardMenu(e, art) })
        card.appendChild(menuBtn)

        card.addEventListener('click', () => {
          if (art.status === 'ready') openArtifactViewer(art.id)
          else if (art.status === 'failed') retryArtifact(art)
        })
        library.appendChild(card)
      })
      if (window.lucide) window.lucide.createIcons()
    }).catch((err) => console.error('[KS] Artifact library render failed:', err))
  }

  /* ── Bottom-docked Audio Mini-Player (single shared <audio>, app-wide) ──────
   * Exactly one audio surface plays at a time across the whole dashboard: the
   * inline artifact players, the Studio footer ribbon, and this docked
   * mini-player all mute each other through ksAudioPauseAllExcept().
   * Trigger: clicking a ready Audio Overview artifact in the library.
   */
  const KS_MINI_SPEEDS = [1, 1.25, 1.5, 2]
  const ksMini = { currentId: null, speedIdx: 0, seekDragging: false, art: null }
  function ksMiniEl() { return document.getElementById('ks-mini-audio') }
  function ksAudioPauseAllExcept(keep) {
    document.querySelectorAll('audio').forEach((el) => {
      if (el !== keep && !el.paused) { try { el.pause() } catch (e) {} }
    })
    // The Kokoro chunk stream uses WebAudio, not <audio> elements — kill it too.
    ksPodcastStopPlayback()
  }
  function openKsMiniPlayer(art) {
    if (!art || !art.url) return
    const a = ksMiniEl()
    const wrap = document.getElementById('ks-mini-player')
    if (!a || !wrap) return
    const target = new URL(art.url, location.href).href
    if (a.src !== target) { a.src = art.url; a.playbackRate = KS_MINI_SPEEDS[ksMini.speedIdx] }
    ksMini.currentId = art.id
    ksMini.art = art
    const title = document.getElementById('ks-mini-title')
    if (title) title.textContent = art.title || 'Audio Overview Document'
    const meta = document.getElementById('ks-mini-meta')
    if (meta) meta.textContent = `${KS_AUDIO_FORMAT_LABELS[art.format] || 'Deep Dive'} • ${art.language || 'hinglish'}${art.duration ? ' • ' + ksAudioFormatDur(art.duration) : ''}`
    wrap.style.display = ''
    a.play().then(() => ksAudioPauseAllExcept(a)).catch((err) => console.warn('[KS Mini] autoplay blocked:', err))
    if (window.lucide) window.lucide.createIcons()
  }
  function closeKsMiniPlayer() {
    const a = ksMiniEl()
    if (a) { a.pause(); a.removeAttribute('src'); a.load() }
    ksMini.currentId = null
    ksMini.art = null
    const wrap = document.getElementById('ks-mini-player')
    if (wrap) wrap.style.display = 'none'
  }
  function ksMiniSyncPlayIcon() {
    const a = ksMiniEl()
    const btn = document.getElementById('ks-mini-play')
    if (a && btn) btn.innerHTML = `<i data-lucide="${a.paused ? 'play' : 'pause'}"></i>`
    if (window.lucide) window.lucide.createIcons()
  }
  function initKsMiniPlayer() {
    const a = ksMiniEl()
    if (!a || a.dataset.ksMiniBound) return
    a.dataset.ksMiniBound = '1'
    const seek = document.getElementById('ks-mini-seekbar')
    const cur = document.getElementById('ks-mini-cur')
    const dur = document.getElementById('ks-mini-dur')
    a.addEventListener('loadedmetadata', () => {
      if (dur) dur.textContent = ksAudioFormatDur(a.duration)
      if (seek && Number.isFinite(a.duration)) seek.max = String(a.duration)
    })
    a.addEventListener('timeupdate', () => {
      if (cur) cur.textContent = ksAudioFormatDur(a.currentTime)
      if (seek && !ksMini.seekDragging) seek.value = String(a.currentTime)
    })
    a.addEventListener('play', () => { ksMiniSyncPlayIcon(); ksAudioPauseAllExcept(a) })
    a.addEventListener('pause', ksMiniSyncPlayIcon)
    a.addEventListener('ended', ksMiniSyncPlayIcon)
    if (seek) {
      seek.addEventListener('pointerdown', () => { ksMini.seekDragging = true })
      seek.addEventListener('pointerup', () => { ksMini.seekDragging = false })
      seek.addEventListener('input', () => { a.currentTime = parseFloat(seek.value) || 0 })
    }
    document.getElementById('ks-mini-play')?.addEventListener('click', () => { if (a.paused) a.play().catch(() => {}); else a.pause() })
    document.getElementById('ks-mini-back')?.addEventListener('click', () => { a.currentTime = Math.max(0, a.currentTime - 10) })
    document.getElementById('ks-mini-fwd')?.addEventListener('click', () => { a.currentTime = Math.min(a.duration || a.currentTime + 10, a.currentTime + 10) })
    document.getElementById('ks-mini-speed')?.addEventListener('click', () => {
      ksMini.speedIdx = (ksMini.speedIdx + 1) % KS_MINI_SPEEDS.length
      a.playbackRate = KS_MINI_SPEEDS[ksMini.speedIdx]
      const badge = document.getElementById('ks-mini-speed')
      if (badge) badge.textContent = `${KS_MINI_SPEEDS[ksMini.speedIdx]}x`
    })
    document.getElementById('ks-mini-close')?.addEventListener('click', closeKsMiniPlayer)
    document.getElementById('ks-mini-menu')?.addEventListener('click', (e) => { e.stopPropagation(); openKsMiniMenu(e) })
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && ksMini.currentId) closeKsMiniPlayer()
    })
  }
  /* Mini-player 3-dot options: Download / Share / Rename / Delete. Rename and
   * Delete go through the persistent artifacts registry (ks-state.js) so the
   * library card and the player stay in sync after the mutation. */
  function openKsMiniMenu(evt) {
    evt.stopPropagation()
    closeKsTrackMenu()
    document.removeEventListener('click', ksMiniMenuOutside, true)
    const art = ksMini.art
    if (!art) return
    const menu = document.createElement('div')
    menu.id = 'ks-mini-menu-pop'
    menu.className = 'ks-track-menu'
    const actions = [
      ['⬇️', 'Download', () => {
        const link = document.createElement('a')
        link.href = art.url
        link.download = `${(art.title || 'audio-overview').replace(/[^\w\- ]+/g, '').trim().slice(0, 80) || 'audio-overview'}.mp3`
        document.body.appendChild(link)
        link.click()
        link.remove()
        showToast('Download started')
      }],
      ['🔗', 'Share', () => {
        const shareUrl = new URL(art.url, location.href).href
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(shareUrl)
            .then(() => showToast('Share link copied to clipboard'))
            .catch(() => showToast(shareUrl))
        } else showToast(shareUrl)
      }],
      ['📝', 'Rename', () => {
        const name = window.prompt('Rename Audio Overview', art.title || '')
        if (name && name.trim()) {
          const clean = name.trim().slice(0, 120)
          window.KS.artifacts.rename(art.id, clean).catch((err) => console.error('[KS Mini] rename failed:', err))
          art.title = clean
          const t = document.getElementById('ks-mini-title')
          if (t) t.textContent = clean
          renderArtifactLibrary()
        }
      }],
      ['🗑️', 'Delete', () => {
        if (!window.confirm('Delete this Audio Overview permanently?')) return
        window.KS.artifacts.remove(art.id).catch((err) => console.error('[KS Mini] delete failed:', err))
        closeKsMiniPlayer()
        renderArtifactLibrary()
        showToast('Audio Overview deleted')
      }]
    ]
    actions.forEach(([icon, label, fn]) => {
      const b = document.createElement('button')
      b.type = 'button'
      b.innerHTML = `<span class="ks-tm-icon">${icon}</span><span>${label}</span>`
      b.addEventListener('click', (e) => { e.stopPropagation(); closeKsMiniMenu(); fn() })
      menu.appendChild(b)
    })
    document.body.appendChild(menu)
    const rect = menu.getBoundingClientRect()
    menu.style.left = `${Math.max(8, Math.min(evt.clientX - rect.width + 12, window.innerWidth - rect.width - 8))}px`
    menu.style.top = `${Math.max(8, evt.clientY - rect.height - 10)}px`
    setTimeout(() => document.addEventListener('click', ksMiniMenuOutside, true), 0)
  }
  function closeKsMiniMenu() {
    const m = document.getElementById('ks-mini-menu-pop')
    if (m) m.remove()
  }
  function ksMiniMenuOutside(e) {
    const m = document.getElementById('ks-mini-menu-pop')
    if (m && !m.contains(e.target)) closeKsMiniMenu()
  }
  /* ── Audio Overview artifact card — generating loader / ready player ─────── */
  const KS_ART_SPEEDS = [1, 1.25, 1.5, 2]
  function renderKsAudioArtifactCard(library, art) {
    const card = document.createElement('div')
    card.className = 'ks-audio-art-card' + (art.status === 'failed' ? ' failed' : '')
    card.dataset.artifactId = art.id

    const head = document.createElement('div')
    head.className = 'ks-audio-art-head'
    const icon = document.createElement('i')
    icon.setAttribute('data-lucide', 'audio-lines')
    head.appendChild(icon)
    const main = document.createElement('div')
    main.className = 'ks-audio-art-main'
    const title = document.createElement('span')
    title.className = 'ks-audio-art-title'
    title.textContent = art.title || 'Audio Overview Document'
    main.appendChild(title)
    const meta = document.createElement('span')
    meta.className = 'ks-audio-art-meta'
    const dur = art.duration ? ` • ${ksAudioFormatDur(art.duration)}` : ''
    meta.textContent = `${STUDIO_TYPE_META.audio_overview.label} • ${art.language || 'hinglish'}${dur} • ${ksTimeAgo(art.updatedAt)}`
    main.appendChild(meta)
    head.appendChild(main)
    const menuBtn = document.createElement('button')
    menuBtn.className = 'ks-audio-art-menu'
    menuBtn.type = 'button'
    menuBtn.title = 'Audio Overview actions'
    menuBtn.innerHTML = '<i data-lucide="more-vertical"></i>'
    menuBtn.addEventListener('click', (e) => { e.stopPropagation(); openKsAudioArtifactMenu(e, art) })
    head.appendChild(menuBtn)
    if (art.status === 'ready' && art.url) {
      // Clicking the generated artifact summons the bottom-docked mini-player.
      main.classList.add('clickable')
      main.title = 'Open in mini-player'
      main.addEventListener('click', (e) => { e.stopPropagation(); openKsMiniPlayer(art) })
    }
    card.appendChild(head)

    if (art.status === 'generating') {
      const loader = document.createElement('div')
      loader.className = 'ks-audio-art-loader'
      loader.innerHTML = '<span class="ks-aal-bolt">&#9889;</span> KAMI-SENSEI CORE // Rendering Local Audio Buffers...'
      card.appendChild(loader)
    } else if (art.status === 'failed') {
      const fail = document.createElement('div')
      fail.className = 'ks-audio-art-fail'
      fail.textContent = art.error || 'Generation failed — retry from the Audio Overview panel.'
      card.appendChild(fail)
    } else if (art.status === 'ready' && art.url) {
      card.appendChild(buildKsAudioArtifactPlayer(art))
    }
    library.appendChild(card)
  }

  /** Boot-time recovery: an audio_overview left in 'generating' has no live SSE
   * session after a reload (the in-memory id is gone), so it can never flip on
   * its own. Mark it failed honestly instead of stranding a zombie loader card.
   */
  async function ksRecoverStuckAudioArtifacts() {
    try {
      const all = await window.KS.artifacts.all()
      let swept = 0
      for (const art of all) {
        if (!art || art.type !== 'audio_overview' || art.status !== 'generating') continue
        if (ksPodcast.artifactId === art.id) continue
        await window.KS.artifacts.update(art.id, {
          status: 'failed',
          error: 'Generation was interrupted (page reload or tab closed) before the local engine finished. Regenerate to compile it again.'
        }).catch(() => { console.error(`[KS] Failed to recover orphaned artifact ${art.id}`) })
        swept++
      }
      if (swept) {
        await window.KS.prefs.set('ks-pending-audio-artifact', null).catch(() => {})
        console.warn(`[KS] Recovered ${swept} orphaned audio artifact(s).`)
        renderArtifactLibrary()
      }
    } catch (err) {
      console.error('[KS] Audio artifact recovery sweep failed:', err)
    }
  }

  function buildKsAudioArtifactPlayer(art) {
    const player = document.createElement('div')
    player.className = 'ks-audio-art-player'
    const audio = document.createElement('audio')
    audio.preload = 'metadata'
    audio.src = art.url
    player.appendChild(audio)

    const seekRow = document.createElement('div')
    seekRow.className = 'ks-aap-seek-row'
    const cur = document.createElement('span')
    cur.className = 'ks-aap-time'
    cur.textContent = '0:00'
    const seek = document.createElement('input')
    seek.type = 'range'
    seek.className = 'ks-aap-seek w-full h-1 bg-purple-600 rounded-lg appearance-none cursor-pointer'
    seek.min = '0'; seek.max = '100'; seek.step = '0.1'; seek.value = '0'
    seek.setAttribute('aria-label', 'Audio Overview seek position')
    const dur = document.createElement('span')
    dur.className = 'ks-aap-time'
    dur.textContent = ksAudioFormatDur(art.duration)
    seekRow.appendChild(cur); seekRow.appendChild(seek); seekRow.appendChild(dur)
    player.appendChild(seekRow)

    const ctrlRow = document.createElement('div')
    ctrlRow.className = 'ks-aap-controls'
    const back = document.createElement('button')
    back.type = 'button'; back.title = 'Rewind 10s'
    back.innerHTML = '<i data-lucide="rotate-ccw"></i><small>10</small>'
    const play = document.createElement('button')
    play.type = 'button'; play.className = 'ks-aap-play'; play.title = 'Play / Pause'
    play.innerHTML = '<i data-lucide="play"></i>'
    const fwd = document.createElement('button')
    fwd.type = 'button'; fwd.title = 'Fast-forward 10s'
    fwd.innerHTML = '<i data-lucide="rotate-cw"></i><small>10</small>'
    const speed = document.createElement('button')
    speed.type = 'button'; speed.className = 'ks-aap-speed'; speed.title = 'Playback speed'
    speed.textContent = '1.0x'
    ctrlRow.appendChild(back); ctrlRow.appendChild(play); ctrlRow.appendChild(fwd); ctrlRow.appendChild(speed)
    player.appendChild(ctrlRow)

    let speedIdx = 0
    let dragging = false
    audio.addEventListener('play', () => {
      // Single-audience rule: one audio surface plays at a time app-wide.
      ksAudioPauseAllExcept(audio)
      play.innerHTML = '<i data-lucide="pause"></i>'
      if (window.lucide) window.lucide.createIcons()
    })
    audio.addEventListener('pause', () => {
      play.innerHTML = '<i data-lucide="play"></i>'
      if (window.lucide) window.lucide.createIcons()
    })
    audio.addEventListener('loadedmetadata', () => {
      dur.textContent = ksAudioFormatDur(audio.duration)
      if (Number.isFinite(audio.duration)) seek.max = String(audio.duration)
    })
    audio.addEventListener('timeupdate', () => {
      cur.textContent = ksAudioFormatDur(audio.currentTime)
      if (!dragging) seek.value = String(audio.currentTime)
    })
    seek.addEventListener('pointerdown', () => { dragging = true })
    seek.addEventListener('pointerup', () => { dragging = false })
    seek.addEventListener('input', () => { audio.currentTime = parseFloat(seek.value) || 0 })
    play.addEventListener('click', () => { if (audio.paused) audio.play().catch(() => {}); else audio.pause() })
    back.addEventListener('click', () => { audio.currentTime = Math.max(0, audio.currentTime - 10) })
    fwd.addEventListener('click', () => { audio.currentTime = Math.min(audio.duration || audio.currentTime + 10, audio.currentTime + 10) })
    speed.addEventListener('click', () => {
      speedIdx = (speedIdx + 1) % KS_ART_SPEEDS.length
      audio.playbackRate = KS_ART_SPEEDS[speedIdx]
      speed.textContent = `${KS_ART_SPEEDS[speedIdx]}x`
    })
    return player
  }

  /* ── Audio Overview three-dots menu: prompt / delete / share / download ──── */
  function closeKsAudioArtifactMenu() {
    const m = document.getElementById('ks-audio-art-menu')
    const p = document.getElementById('ks-audio-prompt-overlay')
    if (m) m.remove()
    if (p) p.remove()
  }
  function ksAudioArtifactMenuOutside(e) {
    const m = document.getElementById('ks-audio-art-menu')
    if (m && !m.contains(e.target)) closeKsAudioArtifactMenu()
  }
  function openKsAudioArtifactMenu(evt, art) {
    evt.stopPropagation()
    closeKsAudioArtifactMenu()
    document.removeEventListener('click', ksAudioArtifactMenuOutside, true)
    const menu = document.createElement('div')
    menu.id = 'ks-audio-art-menu'
    menu.className = 'ks-track-menu'
    const actions = [
      ['📝', 'View Prompt', () => {
        const ov = document.createElement('div')
        ov.id = 'ks-audio-prompt-overlay'
        ov.className = 'ks-audio-prompt-overlay'
        const box = document.createElement('div')
        box.className = 'ks-audio-prompt-box'
        const closeX = document.createElement('button')
        closeX.className = 'ks-audio-prompt-close'; closeX.type = 'button'; closeX.innerHTML = '<i data-lucide="x"></i>'
        closeX.addEventListener('click', () => ov.remove())
        const h = document.createElement('h4'); h.textContent = 'Audio Overview directives'
        box.appendChild(closeX); box.appendChild(h)
        const rows = [
          ['Focus prompt', art.prompt || 'No custom focus prompt — full knowledge base dive.'],
          ['Format', `Audio Overview — ${KS_AUDIO_FORMAT_LABELS[art.format] || art.format || 'deep_dive'}`],
          ['Language', art.language || 'hinglish'],
          ['Sources', (Array.isArray(art.sources) && art.sources.length) ? art.sources.join(', ') : 'Entire knowledge base']
        ]
        rows.forEach(([k, v]) => {
          const row = document.createElement('div')
          row.className = 'ks-ap-row'
          const b = document.createElement('b'); b.textContent = k
          const s = document.createElement('span'); s.textContent = v
          row.appendChild(b); row.appendChild(s)
          box.appendChild(row)
        })
        ov.appendChild(box)
        ov.addEventListener('click', (e) => { if (e.target === ov) ov.remove() })
        document.body.appendChild(ov)
        if (window.lucide) window.lucide.createIcons()
      }],
      ['⬇️', 'Download', () => {
        if (!art.url) { showToast('No compiled file yet — still generating.', true); return }
        const link = document.createElement('a')
        link.href = art.url
        link.download = `${(art.title || 'audio-overview').replace(/[^\w\- ]+/g, '').trim().slice(0, 80) || 'audio-overview'}.mp3`
        document.body.appendChild(link); link.click(); link.remove()
        showToast('Download started')
      }],
      ['🔗', 'Share', () => {
        if (!art.url) { showToast('No compiled file yet — still generating.', true); return }
        const url = new URL(art.url, location.href).href
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(() => showToast('Audio link copied to clipboard')).catch(() => showToast(url))
        } else showToast(url)
      }],
      ['🗑️', 'Delete', () => {
        if (!window.confirm(`Delete "${art.title || 'Audio Overview'}" from the Artifact Library?`)) return
        window.KS.artifacts.remove(art.id)
          .then(() => showToast('Audio Overview deleted'))
          .catch((err) => showToast('Delete failed: ' + err.message, true))
      }]
    ]
    actions.forEach(([icon, label, fn]) => {
      const b = document.createElement('button')
      b.type = 'button'
      b.innerHTML = `<span class="ks-tm-icon">${icon}</span><span>${label}</span>`
      b.addEventListener('click', (e) => { e.stopPropagation(); menu.remove(); fn() })
      menu.appendChild(b)
    })
    document.body.appendChild(menu)
    const rect = menu.getBoundingClientRect()
    menu.style.left = `${Math.max(8, Math.min(evt.clientX - rect.width + 12, window.innerWidth - rect.width - 8))}px`
    menu.style.top = `${Math.min(evt.clientY + 6, window.innerHeight - rect.height - 8)}px`
    setTimeout(() => document.addEventListener('click', ksAudioArtifactMenuOutside, true), 0)
  }

  /* ── Artifact generation pipeline ───────────────────────────────────────── */
  async function submitArtifactGeneration() {
    if (!modalAction) return
    const action = modalAction
    const topicInput = $('#ks-art-topic')
    const topic = topicInput ? topicInput.value.trim() : ''
    const genBtn = $('#ks-art-generate')
    const errBox = $('#ks-art-error')
    if (errBox) errBox.textContent = ''
    if (genBtn) { genBtn.disabled = true; genBtn.textContent = 'Generating…' }

    // Create the artifact record FIRST so the library card appears instantly.
    let record
    try {
      const created = await window.KS.artifacts.create({
        type: action,
        title: topic || STUDIO_TYPE_META[action].label,
        status: 'generating',
        notebookId: ksActiveNotebookId(),
        sourceIds: [...ksSelectedSources],
        sourceCount: ksSelectedSources.length,
        contract: readArtifactContract(),
        content: null
      })
      record = created
    } catch (err) {
      console.error('[KS] Failed to create artifact record:', err)
      if (errBox) errBox.textContent = 'Could not create the artifact record: ' + err.message
      if (genBtn) { genBtn.disabled = false; genBtn.textContent = 'Generate' }
      return
    }

    closeArtifactModal()
    if (studioView === 'artifact') renderStudio() // refresh library behind viewer

    try {
      const res = await fetch('/api/kamisensei/artifact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          topic: topic || undefined,
          notebookId: ksRoute.notebookId || ksRoute.workbook || undefined,
          sourceIds: [...ksSelectedSources],
          ...readArtifactContract()
        }),
        signal: AbortSignal.timeout(300000)
      })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.ok !== true || !data.artifact) {
        throw new Error((data && data.error) || `Generation request failed (HTTP ${res.status})`)
      }

      const resolvedSources = Array.isArray(data.artifact.sourcesUsed)
        ? data.artifact.sourcesUsed.map(String).filter(Boolean)
        : [...ksSelectedSources]
      await window.KS.artifacts.update(record.id, {
        status: 'ready',
        title: data.artifact.title || topic || STUDIO_TYPE_META[action].label,
        content: data.artifact.artifactData,
        sourceIds: resolvedSources,
        sourceCount: resolvedSources.length,
        citations: Array.isArray(data.artifact.citations) ? data.artifact.citations : [],
        provider: data.provider || null,
        model: data.model || null,
        error: null
      })
      openArtifactViewer(record.id)
    } catch (err) {
      console.error('[KS] Artifact generation failed:', err)
      await window.KS.artifacts.update(record.id, {
        status: 'failed',
        error: err.message || 'Generation failed'
      }).catch((e2) => console.error('[KS] Failed to persist artifact error state:', e2))
      showToast(`Artifact generation failed: ${err.message || 'unknown error'}`, true)
      openArtifactViewer(record.id)
    }
  }

  async function retryArtifact(art) {
    if (!art || art.status === 'generating') return
    await window.KS.artifacts.update(art.id, { status: 'generating', error: null })
    try {
      const res = await fetch('/api/kamisensei/artifact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: art.type,
          topic: (art.title && art.title !== STUDIO_TYPE_META[art.type]?.label) ? art.title : undefined,
          notebookId: ksRoute.notebookId || ksRoute.workbook || undefined,
          sourceIds: Array.isArray(art.sourceIds) ? [...art.sourceIds] : [],
          ...(art.contract && typeof art.contract === 'object' ? art.contract : {})
        }),
        signal: AbortSignal.timeout(300000)
      })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.ok !== true || !data.artifact) {
        throw new Error((data && data.error) || `Generation request failed (HTTP ${res.status})`)
      }
      const resolvedSources = Array.isArray(data.artifact.sourcesUsed)
        ? data.artifact.sourcesUsed.map(String).filter(Boolean)
        : (Array.isArray(art.sourceIds) ? [...art.sourceIds] : [])
      await window.KS.artifacts.update(art.id, {
        status: 'ready',
        title: data.artifact.title || art.title,
        content: data.artifact.artifactData,
        sourceIds: resolvedSources,
        sourceCount: resolvedSources.length,
        citations: Array.isArray(data.artifact.citations) ? data.artifact.citations : [],
        provider: data.provider || null,
        model: data.model || null,
        error: null
      })
      openArtifactViewer(art.id)
    } catch (err) {
      console.error('[KS] Artifact retry failed:', err)
      await window.KS.artifacts.update(art.id, { status: 'failed', error: err.message || 'Generation failed' })
        .catch((e2) => console.error('[KS] Failed to persist artifact error state:', e2))
    }
  }

  /* ── Artifact Viewer (full Studio workspace state) ──────────────────────── */
  function bindArtifactWorkspace() {
    $('#ks-ws-close')?.addEventListener('click', () => setStudioView('dashboard'))
    $('#ks-ws-back')?.addEventListener('click', () => setStudioView('dashboard'))
    $('#ks-ws-menu')?.addEventListener('click', (e) => {
      window.KS.artifacts.get(activeArtifactId).then((art) => { if (art) openArtifactCardMenu(e, art) })
        .catch((err) => console.error('[KS] Failed to load artifact for menu:', err))
    })
    // Maximize expands the Studio panel to its CSS max width while an artifact
    // is open; clicking again restores the persisted dashboard width.
    $('#ks-ws-maximize')?.addEventListener('click', async () => {
      const ws = $('#ks-artifact-workspace')
      const panel = document.querySelector('.kamisensei-workspace-grid .studio-panel')
      if (!ws || !panel) return
      if (ws.dataset.maximized === '1') {
        delete ws.dataset.maximized
        panel.style.width = lastStudioWidth + 'px'
        panel.style.setProperty('--ks-studio-w', lastStudioWidth + 'px')
      } else {
        ws.dataset.maximized = '1'
        const maxW = Math.min(Math.floor(window.innerWidth * STUDIO_MAX_RATIO), window.innerWidth - STUDIO_CHAT_RESERVE)
        panel.style.width = maxW + 'px'
        panel.style.setProperty('--ks-studio-w', maxW + 'px')
      }
      if (window.lucide) window.lucide.createIcons()
    })
    // Quick-launch "Generate Dynamic Flashcards" opens the same modal flow.
    document.querySelectorAll('.quick-macro-btn[data-studio-action="flashcard_set"]').forEach((btn) => {
      btn.addEventListener('click', () => openArtifactModal('flashcard_set'))
    })
  }

  /* ── Studio panel resizing — Pointer Events, clamped, persisted ─────────── */
  const STUDIO_MIN_W = 300          // absolute floor: never collapses invisible
  const STUDIO_MAX_RATIO = 0.65     // 65% viewport ceiling
  const STUDIO_CHAT_RESERVE = 400   // center chat keeps >= 400px landing zone
  // Hard ceiling: min(65vw, 100vw - 400px) so the chat column always stays
  // readable no matter how far the splitter is dragged.
  const studioMaxW = () => Math.max(
    STUDIO_MIN_W,
    Math.min(
      Math.floor(window.innerWidth * STUDIO_MAX_RATIO),
      window.innerWidth - STUDIO_CHAT_RESERVE
    )
  )
  let lastStudioWidth = (() => {
    const saved = parseInt(localStorage.getItem('ks-studio-w') || '430', 10)
    return Number.isFinite(saved) && saved >= STUDIO_MIN_W ? saved : 430
  })()

  function initStudioSplitter() {
    const splitter = $('#ks-studio-splitter')
    const panel = document.querySelector('.kamisensei-workspace-grid .studio-panel')
    if (!splitter || !panel) return

    const clampWidth = (px) => {
      return Math.min(Math.max(Math.round(px), STUDIO_MIN_W), studioMaxW())
    }
    const applyWidth = (px) => {
      lastStudioWidth = clampWidth(px)
      // Inline width wins immediately; the CSS custom property stays
      // coherent for stylesheet consumers (lockstep, no drift).
      panel.style.width = lastStudioWidth + 'px'
      panel.style.setProperty('--ks-studio-w', lastStudioWidth + 'px')
    }
    // Restore persisted width before the first interaction.
    applyWidth(lastStudioWidth)

    let dragging = false
    splitter.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return
      e.preventDefault()
      dragging = true
      splitter.classList.add('dragging')
      document.body.classList.add('ks-resizing')
      try { splitter.setPointerCapture(e.pointerId) } catch (err) { console.warn('[KS] Pointer capture failed:', err) }
    })
    splitter.addEventListener('pointermove', (e) => {
      if (!dragging) return
      e.preventDefault()
      // Anchored viewport formula (no start-width snapshot -> no transition-
      // lag drift, no inversion): the splitter rides the panel's left edge,
      // so panel width = viewport width - cursor X. Dragging LEFT widens.
      const newWidth = window.innerWidth - e.clientX
      applyWidth(newWidth)
    })
    const endDrag = (e) => {
      if (!dragging) return
      dragging = false
      splitter.classList.remove('dragging')
      document.body.classList.remove('ks-resizing')
      try { splitter.releasePointerCapture(e.pointerId) } catch (err) { console.debug('[KS] Pointer was already released:', err) }
      localStorage.setItem('ks-studio-w', String(lastStudioWidth))
    }
    splitter.addEventListener('pointerup', endDrag)
    splitter.addEventListener('pointercancel', endDrag)
    // Keep the clamp sane if the window is resized after dragging.
    window.addEventListener('resize', () => {
      if (dragging) return
      const ws = $('#ks-artifact-workspace')
      if (ws && ws.dataset.maximized === '1') return
      applyWidth(lastStudioWidth)
    })
  }

  function setStudioView(view) {
    studioView = view
    if (view === 'dashboard') {
      activeArtifactId = null
      window.KS.prefs.set('ks-last-artifact', null)
        .catch((err) => console.error('[KS] Failed to clear last artifact preference:', err))
    }
    renderStudio()
    if (window.lucide) window.lucide.createIcons()
  }

  function openArtifactViewer(id, opts) {
    activeArtifactId = id
    studioView = 'artifact'
    window.KS.prefs.set('ks-last-artifact', id)
      .catch((err) => console.error('[KS] Failed to persist active artifact:', err))
    renderStudio()
    if (!opts || !opts.restored) addActivity('KamiSensei', 'Opened artifact in Studio')
  }

  async function renderArtifactViewer() {
    const ws = $('#ks-artifact-workspace')
    const titleEl = $('#ks-ws-title')
    const body = $('#ks-ws-content')
    if (!ws || !body) return
    if (!activeArtifactId) { setStudioView('dashboard'); return }
    let art = null
    try {
      art = await window.KS.artifacts.get(activeArtifactId)
    } catch (err) {
      console.error('[KS] Failed to load artifact:', err)
    }
    if (!art) { setStudioView('dashboard'); return }

    const meta = STUDIO_TYPE_META[art.type] || { label: art.type, icon: 'file-text' }
    if (titleEl) titleEl.textContent = art.title || meta.label
    const crumb = $('#ks-ws-crumb')
    if (crumb) {
      const sourceIds = Array.isArray(art.sourceIds) ? art.sourceIds : []
      const sourceCount = Number(art.sourceCount) || sourceIds.length
      crumb.textContent = sourceCount
        ? `Studio • ${sourceCount} source${sourceCount === 1 ? '' : 's'}`
        : 'Studio'
      crumb.title = sourceIds.length ? sourceIds.join('\n') : 'No source metadata retained'
    }
    body.innerHTML = ''

    if (art.status === 'generating') {
      body.innerHTML = '<div class="ks-ws-generating"><i data-lucide="loader-2" class="spin"></i><p>Generating artifact from selected sources…</p></div>'
      if (window.lucide) window.lucide.createIcons()
      return
    }
    if (art.status === 'failed') {
      const errBox = document.createElement('div')
      errBox.className = 'ks-ws-error'
      const strong = document.createElement('strong')
      strong.textContent = 'Generation failed.'
      errBox.appendChild(strong)
      const msg = document.createElement('p')
      msg.textContent = art.error || 'The generator did not return usable content.'
      errBox.appendChild(msg)
      const retry = document.createElement('button')
      retry.type = 'button'
      retry.className = 'ks-ws-retry-btn'
      retry.textContent = 'Retry'
      retry.addEventListener('click', () => retryArtifact(art))
      errBox.appendChild(retry)
      body.appendChild(errBox)
      return
    }

    // Interactive renderers live in ks-artifacts.js (window.KSArtifacts.render)
    // and return a full-panel DOM element bound to the artifact's own controls.
    const render = window.KSArtifacts && typeof window.KSArtifacts.render === 'function'
      ? window.KSArtifacts.render
      : null
    if (!render) {
      body.innerHTML = '<div class="ks-ws-error"><strong>Renderer unavailable.</strong><p>The artifact renderer module (ks-artifacts.js) failed to load. Check the console for details.</p></div>'
      console.error('[KS] window.KSArtifacts.render is not available — was ks-artifacts.js loaded?')
      return
    }
    const panel = render(art, {
      onSaveContent: (content) => window.KS.artifacts.saveContent(art.id, content)
    })
    body.appendChild(panel)
    if (window.lucide) window.lucide.createIcons()
  }

  /* ── Artifact card action menu (Open / Rename / Duplicate / Delete) ─────── */
  function openArtifactCardMenu(ev, art) {
    closeArtifactCardMenu()
    const menu = document.createElement('div')
    menu.className = 'ks-art-lib-menu-pop'
    menu.id = 'ks-art-lib-menu-pop'
    ;[
      { label: 'Open', action: () => openArtifactViewer(art.id) },
      { label: 'Rename', action: () => renameArtifact(art) },
      { label: 'Duplicate', action: () => duplicateArtifact(art) },
      { label: 'Export (.md)', action: () => exportArtifactMarkdown(art) },
      { label: 'Share (copy)', action: () => shareArtifactMarkdown(art) },
      { label: 'Delete', danger: true, action: () => deleteArtifact(art) }
    ].forEach((item) => {
      const btn = document.createElement('button')
      btn.type = 'button'
      btn.className = 'ks-art-menu-item' + (item.danger ? ' danger' : '')
      btn.textContent = item.label
      btn.addEventListener('click', (e) => { e.stopPropagation(); closeArtifactCardMenu(); item.action() })
      menu.appendChild(btn)
    })
    document.body.appendChild(menu)
    const r = ev.currentTarget.getBoundingClientRect()
    menu.style.top = Math.max(8, Math.min(window.innerHeight - menu.offsetHeight - 8, r.bottom + 4)) + 'px'
    menu.style.left = Math.max(8, Math.min(window.innerWidth - menu.offsetWidth - 8, r.right - menu.offsetWidth)) + 'px'
    setTimeout(() => {
      document.addEventListener('click', closeArtifactCardMenu)
      document.addEventListener('keydown', ksMenuEsc)
    }, 0)
  }

  function ksMenuEsc(e) { if (e.key === 'Escape') closeArtifactCardMenu() }

  function closeArtifactCardMenu() {
    document.getElementById('ks-art-lib-menu-pop')?.remove()
    document.removeEventListener('click', closeArtifactCardMenu)
    document.removeEventListener('keydown', ksMenuEsc)
  }

  /* ── Export / Share helpers (local-first, output is pure text — never executed) ── */
  function ksArtifactToMarkdown(art) {
    const lines = []
    lines.push(`# ${art.title || STUDIO_TYPE_META[art.type]?.label || 'Artifact'}`)
    lines.push('')
    const content = art.content && typeof art.content === 'object' ? art.content : {}
    if (content.summary || content.overview) {
      lines.push((content.summary || content.overview) + '')
      lines.push('')
    }
    ;(content.sections || content.background || []).forEach((s) => {
      if (!s) return
      if (s.title) { lines.push(`## ${s.title}`); lines.push('') }
      if (s.body) { lines.push(s.body); lines.push('') }
    })
    const pushList = (head, key, fmt) => {
      const items = Array.isArray(content[key]) ? content[key] : []
      if (!items.length) return
      lines.push(`## ${head}`); lines.push('')
      items.forEach((it) => {
        if (it == null) return
        if (fmt === 'qa') { lines.push(`- **${it.question || ''}**\n  ${it.answer || ''}`) }
        else if (fmt === 'term') { lines.push(`- **${it.term || ''}** — ${it.definition || ''}`) }
        else if (fmt === 'event') { lines.push(`- **${it.date || ''}: ${it.title || ''}** — ${it.description || ''}`) }
        else lines.push(`- ${String(it)}`)
        lines.push('')
      })
    }
    pushList('Key Points', 'keyPoints')
    pushList('Key Details', 'keyDetails')
    pushList('Key Findings', 'keyFindings')
    pushList('Conclusions', 'conclusions')
    pushList('Action Items', 'actionItems')
    pushList('Examples', 'examples')
    pushList('Key Terms', 'keyTerms', 'term')
    pushList('Practice', 'practicePrompts', 'qa')
    pushList('Questions', 'questions', 'qa')
    pushList('Events', 'events', 'event')
    if ((content.flashcard || content.cards) && Array.isArray(content.cards)) {
      lines.push('## Flashcards'); lines.push('')
      content.cards.forEach((c) => { if (c && c.front) { lines.push(`- **${c.front}** — ${c.back || ''}`); lines.push('') } })
    }
    if (content.quiz && Array.isArray(content.quiz.questions)) {
      lines.push('## Quiz'); lines.push('')
      content.quiz.questions.forEach((q) => { if (q && q.question) { lines.push(`- ${q.question} (answer: ${Array.isArray(q.options) ? q.options[q.correctAnswer] : q.correctAnswer})`); lines.push('') } })
    }
    if (Array.isArray(content.sources) && content.sources.length) {
      lines.push('## References'); lines.push('')
      content.sources.forEach((s) => { lines.push(`- ${s}`); lines.push('') })
    }
    return lines.join('\n')
  }

  function downloadTextFile(filename, text, mime) {
    try {
      const blob = new Blob([text], { type: mime || 'text/markdown;charset=utf-8' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
    } catch (err) {
      console.error('[KS] Export failed:', err)
      showToast('Export failed: ' + (err.message || err), 'error')
    }
  }

  function safeFileName(name) {
    return String(name || 'artifact').replace(/[^a-z0-9\-_ ]/gi, '_').replace(/\s+/g, '_').slice(0, 60)
  }

  function exportArtifactMarkdown(art) {
    const md = ksArtifactToMarkdown(art)
    downloadTextFile(safeFileName(art.title || STUDIO_TYPE_META[art.type]?.label || 'artifact') + '.md', md)
    showToast('Artifact exported as Markdown.', 'success')
  }

  async function shareArtifactMarkdown(art) {
    const md = ksArtifactToMarkdown(art)
    try {
      await navigator.clipboard.writeText(md)
      showToast('Markdown copied to clipboard — paste it anywhere to share.', 'success')
    } catch (err) {
      console.error('[KS] Clipboard share failed:', err)
      showToast('Clipboard unavailable; use Export (.md) instead.', 'error')
    }
  }

  async function renameArtifact(art) {
    const next = window.prompt('Rename artifact:', art.title || '')
    if (next === null) return // cancelled
    const title = next.trim()
    if (!title || title === art.title) return
    try {
      await window.KS.artifacts.update(art.id, { title })
    } catch (err) {
      console.error('[KS] Artifact rename failed:', err)
      showToast('Could not rename the artifact: ' + (err.message || err), 'error')
    }
  }

  async function duplicateArtifact(art) {
    try {
      await window.KS.artifacts.create({
        type: art.type,
        title: (art.title || 'Artifact') + ' (copy)',
        status: art.status === 'ready' ? 'ready' : 'failed',
        sourceIds: Array.isArray(art.sourceIds) ? [...art.sourceIds] : [],
        sourceCount: art.sourceCount || 0,
        content: art.content,
        citations: Array.isArray(art.citations) ? art.citations : []
      })
      showToast('Artifact duplicated.', 'success')
    } catch (err) {
      console.error('[KS] Artifact duplicate failed:', err)
      showToast('Could not duplicate the artifact: ' + (err.message || err), 'error')
    }
  }

  async function deleteArtifact(art) {
    if (!window.confirm(`Delete "${art.title || 'this artifact'}"? This cannot be undone.`)) return
    try {
      await window.KS.artifacts.remove(art.id)
      if (activeArtifactId === art.id) setStudioView('dashboard')
    } catch (err) {
      console.error('[KS] Artifact delete failed:', err)
      showToast('Could not delete the artifact: ' + (err.message || err), 'error')
    }
  }

  /* ── Manual note creation ───────────────────────────────────────────────── */
  async function startManualNote() {
    try {
      const created = await window.KS.artifacts.create({
        type: 'note',
        title: 'Untitled Note',
        status: 'ready',
        notebookId: ksActiveNotebookId(),
        sourceIds: [...ksSelectedSources],
        sourceCount: ksSelectedSources.length,
        content: {
          type: 'note',
          title: 'Untitled Note',
          summary: 'Add a concise overview for this note.',
          sections: [{ title: 'Study Notes', body: 'Start writing here.' }],
          keyPoints: [],
          examples: [],
          sources: [...ksSelectedSources]
        }
      })
      openArtifactViewer(created.id)
    } catch (err) {
      console.error('[KS] Manual note creation failed:', err)
      showToast('Could not create the note: ' + (err.message || err), 'error')
    }
  }

  /* ── KAMI/Sense — personalized study command center ──────────────────────
   * Isolated workspace tab (Layer 1.5) mounted from the "KAMI/Sense" tab on
   * the notebook dashboard. Three columns — Japanese Tasks/Drills checklist,
   * Daily Revision Schedule, and Progress Analytics — persist entirely in
   * localStorage so study logs survive reboots. No backend round-trips.
   */
  const KS_SENSE_KEY = { tasks: 'ks-sense-tasks-v1', revs: 'ks-sense-revisions-v1', log: 'ks-sense-log-v1' }
  const KS_SENSE_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  const ksSense = { tasks: [], revs: [], log: [] }
  function ksSenseUid() { return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7) }
  function ksSenseRead(key, fallback) {
    try {
      const raw = localStorage.getItem(key)
      if (!raw) return fallback
      const val = JSON.parse(raw)
      return Array.isArray(val) ? val : fallback
    } catch (e) { return fallback }
  }
  function ksSenseWrite(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value))
      const pill = $('#ks-sense-save-state')
      if (pill) {
        pill.textContent = 'SAVED ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        setTimeout(() => { pill.textContent = 'SYNCED' }, 1800)
      }
    } catch (e) { console.warn('[KS Sense] persist failed:', e) }
  }
  function ksSenseToday() { return new Date().toISOString().slice(0, 10) }
  function ksSenseMarkCompletion() {
    const day = ksSenseToday()
    const row = ksSense.log.find((d) => d.day === day)
    if (row) row.count += 1
    else ksSense.log.push({ day, count: 1 })
    if (ksSense.log.length > 30) ksSense.log = ksSense.log.slice(-30)
    ksSenseWrite(KS_SENSE_KEY.log, ksSense.log)
  }
  function ksSenseItemRow(item, kind) {
    const row = document.createElement('div')
    row.className = 'ks-sense-item' + (item.done ? ' done' : '')
    row.dataset.itemId = item.id
    const check = document.createElement('button')
    check.type = 'button'
    check.className = 'ks-sense-check'
    check.title = item.done ? 'Mark as not done' : 'Mark as done'
    check.innerHTML = item.done ? '<i data-lucide="check-circle-2"></i>' : '<i data-lucide="circle"></i>'
    check.addEventListener('click', () => {
      item.done = !item.done
      item.doneAt = item.done ? Date.now() : null
      if (item.done) ksSenseMarkCompletion()
      const store = kind === 'task' ? KS_SENSE_KEY.tasks : KS_SENSE_KEY.revs
      ksSenseWrite(store, kind === 'task' ? ksSense.tasks : ksSense.revs)
      renderKsSenseTasks(); renderKsSenseRevs(); renderKsSenseMetrics()
    })
    row.appendChild(check)
    const body = document.createElement('div')
    body.className = 'ks-sense-item-body'
    const text = document.createElement('span')
    text.className = 'ks-sense-item-text'
    text.textContent = item.text
    body.appendChild(text)
    if (kind === 'rev') {
      const tag = document.createElement('small')
      tag.className = 'ks-sense-item-day'
      tag.textContent = item.day || 'Mon'
      body.appendChild(tag)
    }
    row.appendChild(body)
    const del = document.createElement('button')
    del.type = 'button'
    del.className = 'ks-sense-item-del'
    del.title = 'Remove entry'
    del.innerHTML = '<i data-lucide="trash-2"></i>'
    del.addEventListener('click', () => {
      if (kind === 'task') ksSense.tasks = ksSense.tasks.filter((t) => t.id !== item.id)
      else ksSense.revs = ksSense.revs.filter((t) => t.id !== item.id)
      ksSenseWrite(kind === 'task' ? KS_SENSE_KEY.tasks : KS_SENSE_KEY.revs, kind === 'task' ? ksSense.tasks : ksSense.revs)
      renderKsSenseTasks(); renderKsSenseRevs(); renderKsSenseMetrics()
    })
    row.appendChild(del)
    return row
  }
  function renderKsSenseTasks() {
    const list = $('#ks-sense-task-list')
    const stats = $('#ks-sense-task-stats')
    if (!list) return
    list.innerHTML = ''
    if (!ksSense.tasks.length) {
      const empty = document.createElement('div')
      empty.className = 'ks-sense-empty'
      empty.textContent = 'No active drills. Add a task above — e.g. "Genki L14 〜た form drill".'
      list.appendChild(empty)
    } else {
      ksSense.tasks.forEach((t) => list.appendChild(ksSenseItemRow(t, 'task')))
    }
    if (stats) {
      const open = ksSense.tasks.filter((t) => !t.done).length
      stats.textContent = `${open} open · ${ksSense.tasks.length - open} done`
    }
  }
  function renderKsSenseRevs() {
    const list = $('#ks-sense-rev-list')
    const stats = $('#ks-sense-rev-stats')
    if (!list) return
    list.innerHTML = ''
    if (!ksSense.revs.length) {
      const empty = document.createElement('div')
      empty.className = 'ks-sense-empty'
      empty.textContent = 'Revision schedule is clear. Plan a slot — e.g. "Review kanji deck 3".'
      list.appendChild(empty)
    } else {
      const sorted = [...ksSense.revs].sort((a, b) => KS_SENSE_DAYS.indexOf(a.day) - KS_SENSE_DAYS.indexOf(b.day))
      sorted.forEach((t) => list.appendChild(ksSenseItemRow(t, 'rev')))
    }
    if (stats) {
      const open = ksSense.revs.filter((t) => !t.done).length
      stats.textContent = `${ksSense.revs.length} scheduled · ${ksSense.revs.length - open} cleared`
    }
  }
  // ─────────────────────────────────────────────────────────────────────────
  // KAMISENSEI MAIN DASHBOARD → NOTEBOOK VIEW ROUTER
  // All click targets on the dashboard grid (Featured Workbook cards + the
  // "[ + Create New Notebook ]" dashed card + the top-bar Create button) feed a
  // single global route state. Updating it swaps the two layers inside the
  // KamiSensei view: hides the dashboard grid and mounts the 3-column
  // SOURCES | CHAT | STUDIO notebook layout. Back returns to the grid.
  // Runs behind the shared error boundary so no click can ever freeze the loop.
  // ─────────────────────────────────────────────────────────────────────────
  function renderKsSenseMetrics() {
    const box = $('#ks-sense-metrics')
    if (!box) return
    const doneTasks = ksSense.tasks.filter((t) => t.done).length
    const doneRevs = ksSense.revs.filter((t) => t.done).length
    const totalDone = doneTasks + doneRevs
    // Streak: consecutive days (ending today) with at least one completion.
    const days = new Set(ksSense.log.filter((d) => d.count > 0).map((d) => d.day))
    let streak = 0
    for (let i = 0; i < 30; i++) {
      const probe = new Date(); probe.setDate(probe.getDate() - i)
      if (days.has(probe.toISOString().slice(0, 10))) streak += 1
      else if (i > 0) break
    }
    const todayCount = (ksSense.log.find((d) => d.day === ksSenseToday()) || { count: 0 }).count
    const metrics = [
      ['check-circle-2', 'Completions', String(totalDone), 'all time'],
      ['flame', 'Day streak', String(streak), streak === 1 ? 'day' : 'days'],
      ['calendar-check', 'Today', String(todayCount), todayCount === 1 ? 'item cleared' : 'items cleared'],
      ['list-todo', 'Open items', String(ksSense.tasks.length + ksSense.revs.length - doneTasks - doneRevs), 'pending']
    ]
    box.innerHTML = ''
    metrics.forEach(([icon, label, value, sub]) => {
      const card = document.createElement('div')
      card.className = 'ks-sense-metric'
      card.innerHTML = `<i data-lucide="${icon}"></i><div class="ks-sense-metric-body"><strong>${value}</strong><span>${label}</span><small>${sub}</small></div>`
      box.appendChild(card)
    })
    // 7-day completion log — real bars from the persisted daily counters.
    const bars = $('#ks-sense-week-bars')
    if (bars) {
      bars.innerHTML = ''
      const max = Math.max(1, ...ksSense.log.map((d) => d.count))
      for (let i = 6; i >= 0; i--) {
        const probe = new Date(); probe.setDate(probe.getDate() - i)
        const key = probe.toISOString().slice(0, 10)
        const row = ksSense.log.find((d) => d.day === key)
        const count = row ? row.count : 0
        const col = document.createElement('div')
        col.className = 'ks-sense-bar-col'
        const bar = document.createElement('div')
        bar.className = 'ks-sense-bar' + (count ? ' filled' : '')
        bar.style.height = `${Math.max(6, Math.round((count / max) * 100))}%`
        bar.title = `${probe.toLocaleDateString([], { weekday: 'short' })}: ${count} completed`
        const label = document.createElement('small')
        label.textContent = KS_SENSE_DAYS[(probe.getDay() + 6) % 7]
        col.appendChild(bar); col.appendChild(label)
        bars.appendChild(col)
      }
    }
    if (window.lucide) window.lucide.createIcons()
  }
  function openKsSenseView() {
    const dash = $('#ks-main-dashboard')
    const nb = $('#ks-notebook-view')
    const sense = $('#ks-sense-view')
    if (!sense || !dash) return
    dash.style.display = 'none'
    if (nb) nb.style.display = 'none'
    sense.style.display = ''
    document.querySelectorAll('.ks-tab').forEach((b) => b.classList.toggle('active', b.id === 'ks-sense-tab'))
    renderKsSenseMetrics()
    window.scrollTo({ top: 0, behavior: 'auto' })
    if (window.lucide) window.lucide.createIcons()
  }
  function closeKsSenseView() {
    const dash = $('#ks-main-dashboard')
    const sense = $('#ks-sense-view')
    if (!sense || !dash) return
    sense.style.display = 'none'
    dash.style.display = ''
    document.querySelectorAll('.ks-tab').forEach((b) => b.classList.remove('active'))
    const allTab = document.querySelector('.ks-tab[data-ks-tab="all"]')
    if (allTab) allTab.classList.add('active')
    if (window.lucide) window.lucide.createIcons()
  }
  function initKsSense() {
    const view = $('#ks-sense-view')
    if (!view || view.dataset.ksSenseBound) return
    view.dataset.ksSenseBound = '1'
    ksSense.tasks = ksSenseRead(KS_SENSE_KEY.tasks, [])
    ksSense.revs = ksSenseRead(KS_SENSE_KEY.revs, [])
    ksSense.log = ksSenseRead(KS_SENSE_KEY.log, [])
    // Tasks / drills checklist — free-text study items persisted on submit.
    $('#ks-sense-task-form')?.addEventListener('submit', (e) => {
      e.preventDefault()
      const input = $('#ks-sense-task-input')
      const text = input ? input.value.trim() : ''
      if (!text) return
      ksSense.tasks.unshift({ id: ksSenseUid(), text: text.slice(0, 160), done: false, createdAt: Date.now() })
      if (input) input.value = ''
      ksSenseWrite(KS_SENSE_KEY.tasks, ksSense.tasks)
      renderKsSenseTasks(); renderKsSenseMetrics()
    })
    // Daily revision schedule — day-tagged goals sorted Mon→Sun on render.
    $('#ks-sense-rev-form')?.addEventListener('submit', (e) => {
      e.preventDefault()
      const input = $('#ks-sense-rev-input')
      const dayEl = $('#ks-sense-rev-day')
      const text = input ? input.value.trim() : ''
      if (!text) return
      ksSense.revs.unshift({ id: ksSenseUid(), text: text.slice(0, 160), day: dayEl ? dayEl.value : 'Mon', done: false, createdAt: Date.now() })
      if (input) input.value = ''
      ksSenseWrite(KS_SENSE_KEY.revs, ksSense.revs)
      renderKsSenseRevs(); renderKsSenseMetrics()
    })
    // Workspace tab switching: KAMI/Sense in, every other tab back out.
    $('#ks-sense-tab')?.addEventListener('click', (e) => { e.stopPropagation(); openKsSenseView() })
    document.querySelectorAll('.ks-tab').forEach((btn) => {
      if (btn.id === 'ks-sense-tab') return
      btn.addEventListener('click', () => {
        if (view.style.display !== 'none') closeKsSenseView()
      })
    })
    $('#ks-sense-back-btn')?.addEventListener('click', closeKsSenseView)
    renderKsSenseTasks(); renderKsSenseRevs(); renderKsSenseMetrics()
  }
  let ksRoute = { view: 'dashboard', workbook: '' }

  /* Notebook scope key: every artifact record, chat persist and UI write is
   * tagged with the ACTIVE notebook id so one notebook's Studio output,
   * dialogue or sources can never leak into another's workspace
   * (NotebookLM parity: every notebook opens ekdum fresh). */
  function ksActiveNotebookId() {
    return (ksRoute && (ksRoute.notebookId || ksRoute.workbook)) || 'session'
  }

  // Auto-create/activate a notebook if none is active. YouTube/web/text sources
  // are notebook-scoped (stored in the notebook's state.sources[]), so an
  // active notebook MUST exist before any UI source is added — otherwise
  // ksAddUiSource silently returns false and the source vanishes. This keeps
  // the very first "Add sources" flow working without forcing the user to
  // manually click "Create notebook" first.
  async function ensureActiveNotebook(label = 'Untitled Notebook') {
    if (ksActiveNotebookId() !== 'session') return ksActiveNotebookId()
    try {
      const res = await fetch('/api/kamisensei/create-notebook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: label }),
        signal: AbortSignal.timeout(15000),
      })
      const data = await res.json().catch(() => null)
      if (res.ok && data && data.status === 'success' && data.notebookId) {
        ksRoute.notebookId = data.notebookId
        // Make the freshly created notebook's empty state load immediately.
        resetKsNotebookSession()
        return data.notebookId
      }
    } catch (err) {
      console.error('[KS] auto notebook create failed:', err)
    }
    return ksActiveNotebookId()
  }

  const KS_WORKBOOKS = {
    'genki-1': { title: 'Genki I — 3rd Edition', tag: 'Elementary • 23 Lessons' },
    'genki-2': { title: 'Genki II — 3rd Edition', tag: 'Intermediate • 23 Lessons' },
    tobira: { title: 'Tobira Gateway', tag: 'Pre-Advanced • 15 Lessons' },
    'jlpt-n3': { title: 'JLPT N3 Sou-Matome', tag: 'Grammar + Vocab • 8 Weeks' },
    'kanji-master': { title: 'Kanji Master N4-N3', tag: '800 Kanji • Drill Workbook' }
  }

  /* Every notebook open gets a unique session identity: featured workbooks
   * use their stable catalog key; custom notebooks mint a timestamp key
   * IMMEDIATELY (not after the server round-trip) so chat, sources and the
   * Studio are scoped to this exact session from the first frame. */
  function ksNotebookSessionId(workbookKey) {
    return workbookKey || ('notebook-' + Date.now().toString() + '-' + Math.random().toString(36).slice(2, 6))
  }

  /* Full flush between notebooks — and, critically, on EVERY notebook open:
   * chat history + citations, source selection and cache, the Studio viewer
   * context, and the Studio Audio Hub/player. Artifact RECORDS stay persisted
   * in IndexedDB — only the previous notebook's active viewing context dies. */
  function resetKsNotebookSession() {
    clearKsChat(true)
    // Belt-and-braces: a fresh notebook MUST mount with an empty chat buffer
    // and cleared citations, even if a streaming reply from the previous
    // notebook is still mutating these globals (the ksAsk notebook guard
    // drops its write, this guarantees the buffer itself is clean).
    ksChatHistory = []
    ksCitations = []
    ksStickBottom = true
    ksSourceCache = []
    // Per-notebook restore: the incoming notebook mounts with ITS OWN saved
    // source selection — a fresh notebook starts with nothing selected and an
    // empty sources list (NotebookLM parity). No wipe-persist here or the
    // target notebook's saved selection would be erased.
    ksSelectedSources = ksNotebookSelectedSources()
    renderKsSources([])
    loadKsSources().catch((err) => console.error('[KS] Source refresh after notebook switch failed:', err))
    activeArtifactId = null
    if (window.KS && window.KS.prefs) window.KS.prefs.set('ks-last-artifact', null)
    // Audio Hub flush: the incoming session mounts with zero tracks loaded —
    // prefs are keyed per notebook id, so the new session starts as an empty
    // slate and old episodes never leak into a fresh notebook.
    ksAudio.tracks = []
    ksAudio.currentId = null
    closeKsTrackMenu()
    const hubEl = $('#ks-audio-hub')
    if (hubEl) hubEl.style.display = 'none'
    const playerEl = $('#ks-global-player')
    if (playerEl) playerEl.style.display = 'none'
    const audioEl = ksAudioEl()
    if (audioEl) { audioEl.pause(); audioEl.removeAttribute('src'); audioEl.load() }
    if (studioView !== 'dashboard') setStudioView('dashboard')
    else renderStudio()
  }

  function openKsNotebook(workbookKey, labelOverride) {
    const dashboard = $('#ks-main-dashboard')
    const notebook = $('#ks-notebook-view')
    if (!dashboard || !notebook) return
    // Existing-notebook overload: openKsNotebook({ id, title, catalogKey })
    // reopens a persisted workspace (dashboard grid cards) without minting
    // a new identity — the recycling bug's second half, now closed.
    if (workbookKey && typeof workbookKey === 'object') {
      return reopenKsNotebook(workbookKey)
    }
    const meta = KS_WORKBOOKS[workbookKey]
    const label = labelOverride || (meta ? meta.title : 'New Notebook')
    // DATA ISOLATION ENGINE routing:
    //  • Featured catalog workbooks resolve via ensureForCatalog() so "Genki I"
    //    always reopens the SAME persisted workspace — no identity recycling.
    //  • Custom notebooks go through create(), which commits the metadata to
    //    the registry AND the empty state matrix synchronously BEFORE the view
    //    mounts — a browser refresh can never drop a brand-new notebook.
    let activeId
    let effectiveLabel = label
    if (workbookKey) {
      activeId = (window.KSNotebooks ? KSNotebooks.ensureForCatalog(workbookKey, label) : { id: workbookKey }).id
    } else {
      // Unique default name so every created notebook is distinguishable from
      // the previous one (the "it just opens the old notebook" pain point).
      if (!effectiveLabel || effectiveLabel === 'New Notebook') {
        const now = new Date()
        effectiveLabel = `Study Notebook · ${now.toLocaleDateString([], { month: 'short', day: 'numeric' })} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
      }
      activeId = window.KSNotebooks ? KSNotebooks.create(effectiveLabel).id : ksNotebookSessionId('')
    }
    ksRoute = { view: 'notebook', workbook: workbookKey, notebookId: activeId }
    // Refresh the registry grid immediately so the brand-new notebook is already
    // visible the moment the user navigates back to the dashboard.
    if (!workbookKey) renderKsNotebookGrid()
    resetKsNotebookSession()
    restoreKsChatHistory()
    // Server-side metadata.json descriptor (fire-and-forget; the client
    // registry commit above is already durability-guaranteed).
    if (!workbookKey) {
      openKsCreateNotebook(effectiveLabel, activeId).catch((err) => {
        console.error('[KS] Notebook creation failed:', err)
        showToast('Notebook created locally (server save skipped).', true)
      })
    }
    dashboard.style.display = 'none'
    notebook.style.display = ''
    // Dynamic header: ALWAYS reflects the active selection ("Genki I — 3rd
    // Edition", "Kanji Master N4-N3", "New Notebook"…) — never a stale label.
    const titleEl = $('#ks-nb-active-title')
    if (titleEl) titleEl.textContent = effectiveLabel
    window.scrollTo({ top: 0, behavior: 'auto' })
    if (window.lucide) window.lucide.createIcons()
    addActivity('KamiSensei', `Opened ${effectiveLabel}`)
    if (!workbookKey) showToast(`New notebook created: ${effectiveLabel}`, false)
  }

  async function openKsCreateNotebook(label, provisionalId) {
    try {
      const res = await fetch('/api/kamisensei/create-notebook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: label || 'New Notebook', notebookId: provisionalId || undefined }),
        signal: AbortSignal.timeout(10000)
      })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.status !== 'success') throw new Error((data && data.error) || `HTTP ${res.status}`)
      // NOTE: the server id is NEVER adopted as the session key — the local
      // registry id stays canonical so artifacts/chat/sources tagged during
      // this session can never be orphaned by a late id switch.
      showToast(`Notebook "${label}" created and saved.`, false)
    } catch (err) {
      console.error('[KS] Notebook save failed:', err)
      showToast(`Notebook save failed: ${err.message || 'unknown error'}`, true)
    }
  }


  /* Reopen a persisted notebook by its registry identity (dashboard cards).
   * Loads the isolated data sector (rebuilding an empty canvas if the sector
   * was lost while metadata survived), then mounts the view against that id. */
  function reopenKsNotebook(entry) {
    const dashboard = $('#ks-main-dashboard')
    const notebook = $('#ks-notebook-view')
    if (!dashboard || !notebook || !entry || !entry.id) return
    if (window.KSNotebooks && !KSNotebooks.load(entry.id)) return
    ksRoute = { view: 'notebook', workbook: entry.catalogKey || '', notebookId: entry.id }
    resetKsNotebookSession()
    restoreKsChatHistory()
    dashboard.style.display = 'none'
    notebook.style.display = ''
    const titleEl = $('#ks-nb-active-title')
    if (titleEl) titleEl.textContent = entry.title || 'Untitled Notebook'
    window.scrollTo({ top: 0, behavior: 'auto' })
    if (window.lucide) window.lucide.createIcons()
    addActivity('KamiSensei', `Opened ${entry.title || 'notebook'}`)
  }

  /* Dashboard "Recent Japanese Notebooks" grid injector — renders one card per
   * entry in the jarvis_kamisensei_library registry (source of truth), most
   * recent first. Cards reopen their persisted workspace via the identity
   * overload of openKsNotebook. The static create-card is never touched. */
  const KS_NB_CARD_STYLES = ['grad-ocean', 'grad-violet', 'grad-ember', 'grad-jade']
  const KS_NB_CARD_KANJI = ['本', '語', '漢', '文']
  let ksNbSearchQuery = ''
  function renderKsNotebookGrid() {
    const grid = $('#ks-nb-grid')
    if (!grid) return
    grid.querySelectorAll('.ks-nb-card').forEach((el) => el.remove())
    if (!window.KSNotebooks) return
    const createBtn = $('#ks-grid-create-nb')
    const q = ksNbSearchQuery
    KSNotebooks.list()
      .filter((m) => !q || String(m.title || '').toLowerCase().includes(q))
      .forEach((meta, index) => {
      const card = document.createElement('div')
      card.className = 'ks-nb-card'
      card.setAttribute('role', 'button')
      card.tabIndex = 0
      card.title = meta.title
      const styleCls = KS_NB_CARD_STYLES[index % KS_NB_CARD_STYLES.length]
      const kanji = KS_NB_CARD_KANJI[index % KS_NB_CARD_KANJI.length]
      const art = document.createElement('div')
      art.className = `ks-nb-card-art ${styleCls}`
      const span = document.createElement('span')
      span.textContent = meta.title && meta.title.charAt(0)
      art.appendChild(span)
      card.appendChild(art)
      const info = document.createElement('div')
      info.className = 'ks-nb-card-info'
      const strong = document.createElement('strong')
      strong.textContent = meta.title || 'Untitled Notebook'
      info.appendChild(strong)
      const small = document.createElement('small')
      small.textContent = `Updated ${ksTimeAgo(new Date(meta.updatedAt || Date.now()).toISOString()) || 'just now'}`
      info.appendChild(small)
      card.appendChild(info)
      const menuBtn = document.createElement('button')
      menuBtn.className = 'ks-nb-menu'
      menuBtn.type = 'button'
      menuBtn.title = 'Notebook actions'
      menuBtn.setAttribute('aria-label', 'Notebook actions')
      menuBtn.innerHTML = '<i data-lucide="more-vertical"></i>'
      menuBtn.addEventListener('click', (e) => { e.stopPropagation(); openKsNotebookMenu(e, meta) })
      card.appendChild(menuBtn)
      const openIt = () => openKsNotebook({ id: meta.id, title: meta.title, catalogKey: meta.catalogKey })
      card.addEventListener('click', openIt)
      card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openIt() } })
      if (createBtn && createBtn.parentElement === grid) grid.insertBefore(card, createBtn.nextSibling)
      else grid.appendChild(card)
    })
    if (window.lucide) window.lucide.createIcons()
  }

  // Notebook card context menu (Rename / Export transcript / Delete) — a tiny
  // non-destructive popover mirroring the artifact card menu pattern.
  function openKsNotebookMenu(ev, meta) {
    closeKsNotebookMenu()
    const menu = document.createElement('div')
    menu.className = 'ks-art-lib-menu-pop'
    menu.id = 'ks-nb-menu-pop'
    ;[
      { label: `Rename "${meta.title || 'Notebook'}"`, action: () => renameKsNotebook(meta) },
      { label: 'Export transcript (.md)', action: () => exportKsNotebook(meta) },
      { label: 'Delete notebook', danger: true, action: () => deleteKsNotebook(meta) }
    ].forEach((item) => {
      const btn = document.createElement('button')
      btn.type = 'button'
      btn.className = 'ks-art-menu-item' + (item.danger ? ' danger' : '')
      btn.textContent = item.label
      btn.addEventListener('click', (e) => { e.stopPropagation(); closeKsNotebookMenu(); item.action() })
      menu.appendChild(btn)
    })
    document.body.appendChild(menu)
    const r = ev.currentTarget.getBoundingClientRect()
    menu.style.top = Math.max(8, Math.min(window.innerHeight - menu.offsetHeight - 8, r.bottom + 4)) + 'px'
    menu.style.left = Math.max(8, Math.min(window.innerWidth - menu.offsetWidth - 8, r.right - menu.offsetWidth)) + 'px'
    setTimeout(() => {
      document.addEventListener('click', closeKsNotebookMenu)
      document.addEventListener('keydown', ksMenuEsc)
    }, 0)
  }

  function closeKsNotebookMenu() {
    document.getElementById('ks-nb-menu-pop')?.remove()
    document.removeEventListener('click', closeKsNotebookMenu)
    document.removeEventListener('keydown', ksMenuEsc)
  }

  function renameKsNotebook(meta) {
    const next = window.prompt('Rename notebook:', meta.title || '')
    if (next === null) return
    const title = next.trim()
    if (!title || title === meta.title) return
    if (!window.KSNotebooks) return
    window.KSNotebooks.rename(meta.id, title)
    renderKsNotebookGrid()
    showToast(`Notebook renamed to "${title}".`, false)
  }

  function exportKsNotebook(meta) {
    if (!window.KSNotebooks) return
    const snap = window.KSNotebooks.snapshot(meta.id)
    const lines = []
    lines.push(`# ${snap.title}`)
    lines.push('')
    lines.push(`Sources: ${snap.sourceCount}`)
    lines.push('')
    lines.push('## Conversation')
    lines.push('')
    if (!snap.chatHistory || !snap.chatHistory.length) lines.push('_No conversation recorded yet._')
    snap.chatHistory.forEach((m) => {
      lines.push(`**${m.role === 'assistant' ? 'KamiSensei' : 'You'}:** ${m.content}`)
      lines.push('')
    })
    downloadTextFile(safeFileName(snap.title || 'notebook') + '.md', lines.join('\n'))
    showToast('Notebook transcript exported as Markdown.', false)
  }

  function deleteKsNotebook(meta) {
    if (!window.KSNotebooks) return
    if (!window.confirm(`Delete notebook "${meta.title}"? Its sources, chat and artifacts will be removed from this browser.`)) return
    window.KSNotebooks.remove(meta.id)
    if (ksRoute.view === 'notebook' && ksRoute.notebookId === meta.id) {
      closeKsNotebook()
    } else {
      renderKsNotebookGrid()
    }
    showToast(`Notebook "${meta.title}" deleted.`, false)
  }

  function closeKsNotebook() {
    const dashboard = $('#ks-main-dashboard')
    const notebook = $('#ks-notebook-view')
    if (!dashboard || !notebook) return
    ksRoute = { view: 'dashboard', workbook: '' }
    notebook.style.display = 'none'
    dashboard.style.display = ''
    renderKsNotebookGrid()
    if (window.lucide) window.lucide.createIcons()
  }

  function bindKsDashboard() {
    // Featured Japanese Workbook cards (Genki I, Genki II, Tobira, JLPT N3, Kanji Master).
    document.querySelectorAll('.ks-featured-card[data-nb-featured]').forEach((card) => {
      card.addEventListener('click', (event) => {
        // The share action inside a card is a leaf control — don't hijack it.
        if (event.target.closest('.ks-card-share')) return
        openKsNotebook(card.getAttribute('data-nb-featured'))
      })
    })

    // "[ + Create New Notebook ]" dashed card in the Recent grid.
    $('#ks-grid-create-nb')?.addEventListener('click', () => openKsNotebook('', 'New Notebook'))

    // Top-bar "Create notebook" button on the dashboard.
    $('#ks-dash-create-nb')?.addEventListener('click', () => openKsNotebook('', 'New Notebook'))

    // Top-bar "Create notebook" button inside the notebook view -> stays in view, fresh workbook label.
    $('#kamisensei-create-nb')?.addEventListener('click', () => openKsNotebook('', 'New Notebook'))

    // Back button in the notebook header restores the dashboard grid.
    $('#ks-back-btn')?.addEventListener('click', closeKsNotebook)

    // Live search filter for the Recent notebooks grid.
    $('#ks-nb-search')?.addEventListener('input', (e) => {
      ksNbSearchQuery = String(e.target && e.target.value || '').trim().toLowerCase()
      renderKsNotebookGrid()
      if (window.lucide) window.lucide.createIcons()
    })

    // One-time registry healer: drop blank/duplicate-id entries and rebuild any
    // missing per-notebook data sector left behind by older versions (the real
    // cause of "created notebooks never appear / the old one keeps opening").
    if (window.KSNotebooks && typeof window.KSNotebooks.heal === 'function') {
      const healed = window.KSNotebooks.heal()
      if (healed > 0) console.warn(`[KS] Notebook registry healed: ${healed} stale entry/entries fixed.`)
    }

    // Initial registry-backed render of the Recent notebooks grid.
    renderKsNotebookGrid()
  }
// ─────────────────────────────────────────────────────────────────────────
  // KAMISENSEI SOURCES PANEL (Left Column) — NotebookLM-style source manager.
  // Lists indexed files, lets Sir select/deselect which sources scope both the
  // chat RAG query AND artifact generation, and supports upload / delete /
  // delete-all / drag-drop. Every mutation refreshes the list + Studio library.
  // ─────────────────────────────────────────────────────────────────────────
  let ksSourceCache = []

  function ksSourceName(file) {
    return String(file && (file.name || file.filename || '')).trim()
  }

  function updateKsSourceScopeIndicator() {
    const indicator = $('#ks-chat-source-scope')
    if (!indicator) return
    const manifest = ksNotebookManifestNames()
    const indexedCount = ksSourceCache.filter((file) => file.indexed !== false && (!manifest.size || manifest.has(ksSourceName(file)))).length
    indicator.textContent = ksSelectedSources.length
      ? `${ksSelectedSources.length} selected source${ksSelectedSources.length === 1 ? '' : 's'}`
      : `${indexedCount} indexed source${indexedCount === 1 ? '' : 's'} • all in scope`
  }

  /* ── Per-notebook source manifest helpers ────────────────────────────────
   * Every notebook owns its OWN sources (NotebookLM parity): the manifest
   * lives in the notebook's isolated state sector (jarvis_kamisensei_data_<id>
   * → sources[]), and the selected subset in selectedSources[]. A brand-new
   * notebook therefore mounts with ZERO sources — an old book's files can
   * never appear inside it. */
  function ksNotebookState() {
    const id = ksActiveNotebookId()
    if (!window.KSNotebooks || id === 'session') return null
    try { return KSNotebooks.load(id) } catch (err) { return null }
  }
  function ksNotebookManifestNames() {
    const state = ksNotebookState()
    return new Set(((state && Array.isArray(state.sources)) ? state.sources : []).map((s) => String(s.name || '')).filter(Boolean))
  }
  function ksNotebookSelectedSources() {
    const state = ksNotebookState()
    return (state && Array.isArray(state.selectedSources)) ? state.selectedSources.slice() : []
  }
  function ksAddSourceToManifest(name) {
    const id = ksActiveNotebookId()
    if (!window.KSNotebooks || id === 'session' || !name) return
    try {
      KSNotebooks.update(id, (prev) => {
        const sources = Array.isArray(prev.sources) ? prev.sources : []
        if (sources.some((s) => s.name === name)) return prev
        return { ...prev, sources: sources.concat({ id: KSNotebooks.generateSecureUUID(), name: String(name), pageCount: 0, status: 'indexed' }) }
      })
    } catch (err) { console.error('[KS] Manifest add failed:', err) }
  }
  function ksRemoveSourceFromManifest(name) {
    const id = ksActiveNotebookId()
    if (!window.KSNotebooks || id === 'session' || !name) return
    try {
      KSNotebooks.update(id, (prev) => ({ ...prev, sources: (Array.isArray(prev.sources) ? prev.sources : []).filter((s) => s.name !== name) }))
    } catch (err) { console.error('[KS] Manifest remove failed:', err) }
  }

  function persistKsSourceSelection() {
    updateKsSourceScopeIndicator()
    const id = ksActiveNotebookId()
    if (window.KSNotebooks && id !== 'session') {
      try {
        KSNotebooks.update(id, (prev) => ({ ...prev, selectedSources: [...ksSelectedSources] }))
        return
      } catch (err) { console.error('[KS] Notebook selection persistence failed:', err) }
    }
    if (window.KS && window.KS.prefs) {
      window.KS.prefs.set('ks-selected-sources', [...ksSelectedSources])
        .catch((err) => console.error('[KS] Source selection persistence failed:', err))
    }
  }

  /* ── ONE-TIME legacy migration: pre-isolation data → first notebook ────────
   * Artifacts created before notebook tagging and sources added before the
   * per-notebook manifest had no owner (they appeared in EVERY notebook, then
   * — after strict filtering — in NONE). They are adopted here by the OLDEST
   * notebook in the registry (Sir ka pehla workspace) so nothing they made
   * is lost, while every new notebook stays perfectly fresh. */
  async function ksMigrateLegacyNotebookData() {
    if (!window.KS || !window.KS.prefs || !window.KSNotebooks) return
    const done = await window.KS.prefs.get('ks-legacy-nb-migration-v1', false)
    if (done) return
    try {
      const registry = KSNotebooks.list()
      const oldest = registry.length ? registry[registry.length - 1] : null
      if (!oldest) return // no notebook exists yet — retry on a later boot
      // 1. Adopt untagged artifacts into the first notebook.
      const arts = await window.KS.artifacts.all()
      for (const art of arts) {
        if (art && !art.notebookId) {
          await window.KS.artifacts.update(art.id, { notebookId: oldest.id }).catch((err) =>
            console.error('[KS] Artifact adoption failed:', art.id, err))
        }
      }
      // 2. Adopt global knowledge-base files + the old global selection into
      //    the first notebook's manifest. If the bridge was offline and the
      //    KB list never loaded, bail WITHOUT setting the done-flag so the
      //    migration retries on the next boot — Sir ke sources kabhi lost
      //    nahi ho sakte sirf ek offline first-boot ki wajah se.
      if (!ksSourceCache.length) {
        console.warn('[KS] Legacy migration: source list unavailable (bridge offline?) — will retry next boot.')
        return
      }
      const kbNames = [...new Set(ksSourceCache.map(ksSourceName).filter(Boolean))]
      const state = ksNotebookStateFor(oldest.id)
      const existing = new Set(((state && state.sources) || []).map((s) => s.name))
      const adopted = kbNames.filter((n) => !existing.has(n))
        .map((name) => ({ id: KSNotebooks.generateSecureUUID(), name, pageCount: 0, status: 'indexed' }))
      const savedSel = await window.KS.prefs.get('ks-selected-sources', [])
      const kbSet = new Set(kbNames)
      KSNotebooks.update(oldest.id, (prev) => ({
        ...prev,
        sources: (Array.isArray(prev.sources) ? prev.sources : []).concat(adopted),
        selectedSources: Array.isArray(savedSel) ? savedSel.filter((n) => kbSet.has(n)) : []
      }))
      await window.KS.prefs.set('ks-selected-sources', []).catch(() => {})
      if (adopted.length) console.log(`[KS] Legacy migration: ${adopted.length} source(s) + untagged artifacts adopted by "${oldest.title}".`)
      await window.KS.prefs.set('ks-legacy-nb-migration-v1', true)
    } catch (err) {
      console.error('[KS] Legacy notebook migration failed:', err)
    }
  }
  function ksNotebookStateFor(id) {
    if (!window.KSNotebooks || !id || id === 'session') return null
    try { return KSNotebooks.load(id) } catch (err) { return null }
  }

  async function loadKsStatus() {
    const dbStatus = $('#ks-db-status')
    const modelStatus = $('#ks-ai-model')
    const voiceStatus = $('#ks-voice-id')
    try {
      const res = await fetch('/api/kamisensei/status', { signal: AbortSignal.timeout(12000) })
      const data = await res.json().catch(() => null)
      if (dbStatus) dbStatus.textContent = res.ok && data && data.db_connected ? 'Connected' : 'Unavailable'
      if (modelStatus) modelStatus.textContent = data && data.google_model ? data.google_model : 'Configured provider'
      if (voiceStatus) voiceStatus.textContent = data && data.voice_id ? data.voice_id : 'Browser / system voice'
      if (!res.ok) console.warn('[KS] Status check reported unavailable services:', data && (data.error || data.message))
      return data
    } catch (err) {
      console.error('[KS] Status check failed:', err)
      if (dbStatus) dbStatus.textContent = 'Unavailable'
      if (modelStatus) modelStatus.textContent = 'Provider unavailable'
      if (voiceStatus) voiceStatus.textContent = 'Browser / system voice'
      return null
    }
  }

  async function loadKsSources() {
    try {
      const res = await fetch('/api/kamisensei/files', { signal: AbortSignal.timeout(10000) })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.ok === false) {
        throw new Error((data && (data.error || data.message)) || `Source registry returned HTTP ${res.status}`)
      }
      const files = Array.isArray(data.files) ? data.files : []
      ksSourceCache = files
      // PER-NOTEBOOK SOURCE LIST: only files registered in THIS notebook's
      // manifest are rendered — an old notebook's sources can never appear
      // inside a new one (a fresh notebook shows the empty "Add sources"
      // state exactly like NotebookLM).
      const manifest = ksNotebookManifestNames()
      const visibleFiles = manifest.size ? files.filter((file) => manifest.has(ksSourceName(file))) : []
      const indexedNames = new Set(visibleFiles.filter((file) => file.indexed !== false).map(ksSourceName).filter(Boolean))
      const selectedBefore = ksSelectedSources.length
      ksSelectedSources = ksSelectedSources.filter((name) => indexedNames.has(name))
      if (ksSelectedSources.length !== selectedBefore) persistKsSourceSelection()
      renderKsSources(visibleFiles)
      updateKsSourceScopeIndicator()
      const countBadge = $('#ks-loaded-count')
      if (countBadge) countBadge.textContent = `${visibleFiles.length} file${visibleFiles.length === 1 ? '' : 's'}`
      return visibleFiles
    } catch (err) {
      console.error('[KS] Source list fetch failed:', err)
      renderKsSources([], 'The local source service is unavailable. Start the JARVIS bridge, then retry.')
      const countBadge = $('#ks-loaded-count')
      if (countBadge) countBadge.textContent = 'Unavailable'
      return []
    }
  }

  // ── KamiSensei JSON-store sources (kamisensei_db.json) ───────────────────
  // Extracted YouTube transcripts persisted by the backend. They survive page
  // reloads, so we keep a module-level array + an explicit loader (the vanilla
  // JS equivalent of a useEffect) and render them as cards in the panel.
  let ksJsonSources = []
  let ksJsonSourcesLoaded = false

  async function loadKsJsonSources({ silent = false } = {}) {
    try {
      const res = await fetch('/api/kamisensei/sources', { signal: AbortSignal.timeout(12000) })
      const data = await res.json().catch(() => null)
      if (res.ok && data && Array.isArray(data.sources)) {
        ksJsonSources = data.sources
        ksJsonSourcesLoaded = true
        renderKsJsonSources()
        return ksJsonSources
      }
    } catch (err) {
      if (!silent) console.error('[KS] JSON sources fetch failed:', err)
    }
    return []
  }

  function renderKsJsonSources() {
    let host = $('#ks-json-sources')
    const list = $('#sources-file-list')
    const empty = $('#sources-empty-state')
    if (!list) return

    if (!host) {
      host = document.createElement('div')
      host.id = 'ks-json-sources'
      host.className = 'ks-json-sources'
      list.parentNode.insertBefore(host, list)
    }
    host.innerHTML = ''

    // Dedupe: a YouTube video is saved BOTH in this notebook's UI sources
    // (state.sources[]) and the backend JSON store (kamisensei_db.json). It
    // must render as ONE card — the notebook UI source is the visible card, the
    // JSON copy is the reload-safe persistence layer. Legacy duplicates (saved
    // before this rule) also collapse here.
    const uiUrls = new Set(ksUiSourceList().map((s) => String(s.url || '').trim()).filter(Boolean))
    const visible = ksJsonSources.filter((src) => !uiUrls.has(String(src.url || '').trim()))

    const fileCount = list.children.length
    const hasAny = fileCount > 0 || visible.length > 0
    if (empty) empty.style.display = hasAny ? 'none' : ''
    if (!hasAny) { host.style.display = 'none'; return }
    host.style.display = ''

    visible.forEach((src) => {
      const row = document.createElement('div')
      row.className = 'source-file-item ks-link-source ks-json-source'
      row.setAttribute('data-kind', 'youtube')
      row.setAttribute('data-id', src.id || '')

      const cb = document.createElement('input')
      cb.type = 'checkbox'
      cb.className = 'source-select-cb'
      cb.checked = ksSelectedSources.includes(src.title)
      cb.title = 'Use this source for scoped queries'
      cb.addEventListener('click', (e) => e.stopPropagation())
      cb.addEventListener('change', (e) => {
        e.stopPropagation()
        if (cb.checked) { if (!ksSelectedSources.includes(src.title)) ksSelectedSources.push(src.title) }
        else { ksSelectedSources = ksSelectedSources.filter((s) => s !== src.title) }
        persistKsSourceSelection()
      })
      row.appendChild(cb)

      const icon = document.createElement('span')
      icon.className = 'ks-src-kind-icon yt'
      icon.innerHTML = '<i data-lucide="youtube"></i>'
      row.appendChild(icon)

      const nameWrap = document.createElement('div')
      nameWrap.className = 'file-meta-col ks-src-name-col'
      const nameEl = document.createElement('span')
      nameEl.className = 'file-name-text'
      nameEl.textContent = src.title || src.url || 'YouTube video'
      nameEl.title = src.url || src.title || ''
      nameWrap.appendChild(nameEl)
      if (src.url) {
        const urlEl = document.createElement('span')
        urlEl.className = 'ks-src-url'
        urlEl.textContent = src.url
        nameWrap.appendChild(urlEl)
      }
      row.appendChild(nameWrap)

      const meta = document.createElement('span')
      meta.className = 'source-file-meta'
      meta.textContent = src.author ? `Channel: ${src.author}` : 'YouTube'
      row.appendChild(meta)

      const del = document.createElement('button')
      del.className = 'file-delete-btn'
      del.type = 'button'
      del.title = 'Remove this source'
      del.innerHTML = '<i data-lucide="trash-2"></i>'
      del.addEventListener('click', (e) => { e.stopPropagation(); deleteKsJsonSource(src) })
      row.appendChild(del)

      row.addEventListener('click', (e) => {
        if (e.target.closest('.source-select-cb') || e.target.closest('.file-delete-btn')) return
        openKsSourceViewer({ kind: 'youtube', name: src.title || src.url, url: src.url || '', transcript: src.transcript || '', author: src.author || '' })
      })

      host.appendChild(row)
    })

    if (window.lucide) window.lucide.createIcons()
  }

  async function deleteKsJsonSource(src) {
    if (!src || !src.id) return
    if (!confirm(`Remove "${src.title || 'this source'}" from your notebook?`)) return
    try {
      await fetch(`/api/kamisensei/sources/${encodeURIComponent(src.id)}`, { method: 'DELETE', signal: AbortSignal.timeout(10000) }).catch(() => {})
    } catch { /* best-effort backend delete */ }
    // Keep the notebook UI-source manifest in sync so the same video can't
    // linger behind as a UI card once its persisted record is gone.
    if (window.KSNotebooks && src.url) {
      const nbId = ksActiveNotebookId()
      if (nbId && nbId !== 'session') {
        try {
          KSNotebooks.update(nbId, (prev) => ({
            ...prev,
            sources: (Array.isArray(prev.sources) ? prev.sources : []).filter((s) => String(s.url || '') !== String(src.url || '')),
          }))
        } catch (err) { console.error('[KS] JSON delete notebook sync failed:', err) }
      }
    }
    ksJsonSources = ksJsonSources.filter((s) => s.id !== src.id)
    renderKsJsonSources()
    showToast(`Removed ${src.title || 'source'}.`)
  }

  function renderKsSources(files, errorMessage = '') {
    const list = $('#sources-file-list')
    const empty = $('#sources-empty-state')
    if (!list) return
    const linkSources = ksUiSourceList()
    const hasFiles = (Array.isArray(files) && files.length > 0) || linkSources.length > 0
    list.innerHTML = ''
    list.style.display = hasFiles ? '' : 'none'
    if (empty) {
      empty.style.display = hasFiles ? 'none' : ''
      const message = empty.querySelector('p')
      if (message) {
        message.textContent = errorMessage || 'Add PDF, TXT, Markdown, JSON, website links, or YouTube videos to ground KamiSensei.'
      }
    }
    if (hasFiles && !errorMessage) list.appendChild(ksSelectAllRow())

    files.forEach((file) => {
      const name = ksSourceName(file)
      if (!name) return
      const row = document.createElement('div')
      row.className = 'source-file-item'

      const selectWrap = document.createElement('div')
      selectWrap.className = 'file-meta-col'
      const cb = document.createElement('input')
      cb.type = 'checkbox'
      cb.className = 'source-select-cb'
      cb.checked = file.indexed !== false && ksSelectedSources.includes(name)
      cb.disabled = file.indexed === false
      cb.title = cb.disabled
        ? 'This source has not been indexed yet.'
        : 'Use this source for artifact generation and scoped queries'
      // Checkbox toggles selection ONLY when the box itself is clicked — never
      // bubbles to the card's click handler (which opens the source viewer).
      cb.addEventListener('click', (e) => e.stopPropagation())
      cb.addEventListener('change', (e) => {
        e.stopPropagation()
        if (cb.checked) {
          if (!ksSelectedSources.includes(name)) ksSelectedSources.push(name)
        } else {
          ksSelectedSources = ksSelectedSources.filter((s) => s !== name)
        }
        persistKsSourceSelection()
      })
      selectWrap.appendChild(cb)
      row.appendChild(selectWrap)

      const nameWrap = document.createElement('div')
      nameWrap.className = 'file-meta-col'
      nameWrap.style.flex = '1'
      nameWrap.style.minWidth = '0'
      const nameEl = document.createElement('span')
      nameEl.className = 'file-name-text'
      nameEl.textContent = name
      nameEl.title = name
      nameEl.style.cursor = 'pointer'
      nameEl.addEventListener('click', (e) => {
        e.stopPropagation()
        openKsSourceViewer({ kind: 'file', name, meta: parts.join(' • ') || 'Indexed document' })
      })
      nameWrap.appendChild(nameEl)
      row.appendChild(nameWrap)

      const metaWrap = document.createElement('span')
      metaWrap.className = 'source-file-meta'
      const parts = []
      if (file.size_display) parts.push(file.size_display)
      else if (file.size_bytes) parts.push(`${Math.max(1, Math.round(file.size_bytes / 1024))} KB`)
      const pages = Number(file.pages)
      if (Number.isFinite(pages) && pages > 0) parts.push(`${pages} page${pages === 1 ? '' : 's'}`)
      if (file.chunks) parts.push(`${file.chunks} chunks`)
      if (!file.chunks && file.indexed) parts.push('Indexed')
      metaWrap.textContent = parts.join(' • ')
      row.appendChild(metaWrap)

      // The whole card (except the checkbox + delete button) opens the viewer.
      row.addEventListener('click', (e) => {
        if (e.target.closest('.source-select-cb') || e.target.closest('.file-delete-btn')) return
        openKsSourceViewer({ kind: 'file', name, meta: parts.join(' • ') || 'Indexed document' })
      })

      if (file.indexed === false) {
        const idxBadge = document.createElement('span')
        idxBadge.className = 'source-index-badge'
        idxBadge.textContent = 'Not indexed'
        row.appendChild(idxBadge)
      }

      const del = document.createElement('button')
      del.className = 'file-delete-btn'
      del.type = 'button'
      del.title = `Delete ${name}`
      del.innerHTML = '<i data-lucide="trash-2"></i>'
      del.addEventListener('click', (e) => { e.stopPropagation(); deleteKsSource(name) })
      row.appendChild(del)
      list.appendChild(row)
    })
    // UI-only link & copied-text sources (NotebookLM parity shell — real
    // crawler/transcript ingestion ships in a later pass).
    linkSources.forEach((src) => list.appendChild(ksLinkSourceRow(src)))
    if (window.lucide) window.lucide.createIcons()
  }

  /* ── UI-only link & copied-text sources ───────────────────────────────────
   * Saved straight into the notebook's own manifest sector (state.sources[])
   * with a `kind` tag, so they survive reloads and stay per-notebook. They
   * are listed, selectable, and viewable — but nothing is crawled yet. */

  // ── Source-panel loading state (YouTube transcript fetch, etc.) ──────────
  let isAddingSource = false
  function setKsSourceLoading(on, message = 'Fetching transcript…') {
    isAddingSource = !!on
    const el = $('#sources-loading')
    const txt = $('#sources-loading-text')
    if (txt && message) txt.textContent = message
    if (el) el.style.display = on ? 'flex' : 'none'
    const list = $('#sources-file-list')
    if (list) list.style.opacity = on ? '0.55' : '1'
    const addBtn = $('#kamisensei-add-source-btn')
    if (addBtn) addBtn.disabled = isAddingSource
  }
  function ksUiSourceList() {
    const state = ksNotebookState()
    return ((state && Array.isArray(state.sources)) ? state.sources : []).filter((s) => s && s.kind)
  }
  function ksAddUiSource(entry) {
    const id = ksActiveNotebookId()
    if (!window.KSNotebooks || id === 'session' || !entry || !entry.name) return false
    let added = false
    try {
      KSNotebooks.update(id, (prev) => {
        const sources = Array.isArray(prev.sources) ? prev.sources : []
        if (sources.some((s) => s.name === entry.name)) return prev
        added = true
        return {
          ...prev,
          sources: sources.concat({
            id: KSNotebooks.generateSecureUUID(),
            name: String(entry.name),
            url: entry.url || '',
            text: entry.text || '',
            transcript: entry.transcript || '',
            author: entry.author || '',
            kind: entry.kind,
            pageCount: 0,
            status: 'link',
          }),
        }
      })
    } catch (err) { console.error('[KS] Link source add failed:', err) }
    return added
  }
  function ksRemoveUiSource(name, meta) {
    const id = ksActiveNotebookId()
    const src = (meta && meta.url) ? meta : (ksUiSourceList().find((s) => s.name === name) || null)
    if (!window.KSNotebooks || id === 'session' || !name) return
    try {
      KSNotebooks.update(id, (prev) => ({
        ...prev,
        sources: (Array.isArray(prev.sources) ? prev.sources : []).filter((s) => s.name !== name),
      }))
    } catch (err) { console.error('[KS] Link source remove failed:', err) }
    // YouTube sources live in BOTH the notebook manifest AND the backend JSON
    // store (kamisensei_db.json). Delete both copies so the source never comes
    // back as a ghost card after the next reload.
    if (src && src.kind === 'youtube' && src.url) {
      fetch('/api/kamisensei/sources/delete-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: String(src.url) }),
        signal: AbortSignal.timeout(10000),
      }).catch(() => {})
    }
  }

  function ksSelectAllRow() {
    const wrap = document.createElement('label')
    wrap.className = 'ks-src-selectall'
    const cb = document.createElement('input')
    cb.type = 'checkbox'
    cb.className = 'source-select-cb'
    cb.title = 'Select or clear every selectable source'
    cb.addEventListener('change', () => {
      $('#sources-file-list')?.querySelectorAll('.source-select-cb').forEach((box) => {
        if (box === cb || box.disabled) return
        if (box.checked !== cb.checked) {
          box.checked = cb.checked
          box.dispatchEvent(new Event('change'))
        }
      })
    })
    const label = document.createElement('span')
    label.textContent = 'Select all'
    wrap.append(cb, label)
    return wrap
  }

  function ksLinkSourceRow(src) {
    const row = document.createElement('div')
    row.className = 'source-file-item ks-link-source'
    row.setAttribute('data-kind', src.kind || 'web')

    // Checkbox sits STRICTLY on the left of the name and only toggles when the
    // box itself is clicked — click/stopPropagation never bubbles to the card.
    const cb = document.createElement('input')
    cb.type = 'checkbox'
    cb.className = 'source-select-cb'
    cb.checked = ksSelectedSources.includes(src.name)
    cb.title = 'Keep this source in scope'
    cb.addEventListener('click', (e) => e.stopPropagation())
    cb.addEventListener('change', (e) => {
      e.stopPropagation()
      if (cb.checked) {
        if (!ksSelectedSources.includes(src.name)) ksSelectedSources.push(src.name)
      } else {
        ksSelectedSources = ksSelectedSources.filter((s) => s !== src.name)
      }
      persistKsSourceSelection()
    })
    row.appendChild(cb)

    const icon = document.createElement('span')
    icon.className = 'ks-src-kind-icon ' + (src.kind === 'youtube' ? 'yt' : src.kind === 'web' ? 'web' : 'text')
    const iconName = src.kind === 'youtube' ? 'youtube' : src.kind === 'web' ? 'globe' : 'clipboard-list'
    icon.innerHTML = `<i data-lucide="${iconName}"></i>`
    row.appendChild(icon)

    const nameWrap = document.createElement('div')
    nameWrap.className = 'file-meta-col ks-src-name-col'
    const nameEl = document.createElement('span')
    nameEl.className = 'file-name-text'
    nameEl.textContent = src.name
    nameEl.title = src.url ? `${src.name}\n${src.url}` : src.name
    nameWrap.appendChild(nameEl)
    if (src.url) {
      const urlEl = document.createElement('span')
      urlEl.className = 'ks-src-url'
      urlEl.textContent = src.url
      nameWrap.appendChild(urlEl)
    }
    row.appendChild(nameWrap)

    const del = document.createElement('button')
    del.className = 'file-delete-btn'
    del.type = 'button'
    del.title = `Remove ${src.name}`
    del.innerHTML = '<i data-lucide="trash-2"></i>'
    del.addEventListener('click', (e) => {
      e.stopPropagation()
      ksRemoveUiSource(src.name, src)
      showToast(`Removed ${src.name}.`)
      loadKsSources()
      loadKsJsonSources({ silent: true })
    })
    row.appendChild(del)

    row.addEventListener('click', (e) => {
      if (e.target.closest('.source-select-cb') || e.target.closest('.file-delete-btn')) return
      openKsSourceViewer({ kind: src.kind, name: src.name, url: src.url || '', text: src.text || '', transcript: src.transcript || '', author: src.author || '' })
    })
    return row
  }

  /* ── Add Sources modal (NotebookLM-style shell) ─────────────────────────── */
  function openKsAddSourceModal() {
    const modal = $('#ks-add-source-modal')
    if (!modal) return
    modal.style.display = 'flex'
    const searchInput = $('#ks-asm-search-input'); if (searchInput) searchInput.value = ''
    const linksTa = $('#ks-asm-links-input'); if (linksTa) linksTa.value = ''
    const pasteTa = $('#ks-asm-paste-input'); if (pasteTa) pasteTa.value = ''
    const note = $('#ks-asm-search-note'); if (note) note.style.display = 'none'
    ksAsmShowView('main')
  }
  function ksAsmClose() {
    const m = $('#ks-add-source-modal')
    if (m) m.style.display = 'none'
  }
  function ksAsmShowView(view) {
    const map = { main: '#ks-asm-main', links: '#ks-asm-links', paste: '#ks-asm-pasteview' }
    Object.entries(map).forEach(([key, sel]) => {
      const el = $(sel)
      if (el) el.style.display = key === view ? 'flex' : 'none'
    })
    const title = $('#ks-asm-title')
    if (title) {
      title.textContent = view === 'links' ? 'Add websites & YouTube links'
        : view === 'paste' ? 'Add copied text'
        : 'Add sources'
    }
  }
  // ── Add Sources: websites & YouTube links ─────────────────────────────────
  // Website links are saved instantly as UI-only sources. YouTube links hit
  // the real /api/kamisensei/youtube-extract endpoint — a loading indicator
  // shows in the Source Panel, and on success the transcript + title are
  // stored on the source entry and the list refreshes so it appears instantly.
  async function ksAsmCommitLinks() {
    const ta = $('#ks-asm-links-input')
    if (!ta) return
    const urls = [...new Set(ta.value.split(/[\s,]+/).map((s) => s.trim()).filter(Boolean))]
    if (!urls.length) { showToast('Paste at least one link first.', true); return }

    // Guarantee a notebook exists so UI sources actually persist (YouTube /
    // web / text sources live in the notebook's state.sources[], which is a
    // no-op while ksActiveNotebookId() is still 'session').
    await ensureActiveNotebook()

    const ytUrls = []
    const webUrls = []
    urls.forEach((raw) => {
      const url = /^https?:\/\//i.test(raw) ? raw : 'https://' + raw
      const isYt = /(?:youtube\.com|youtu\.be)/i.test(url)
      ;(isYt ? ytUrls : webUrls).push(url)
    })

    // Website links: instant UI-only source (no crawl yet).
    webUrls.forEach((url) => {
      const name = url.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '')
      ksAddUiSource({ kind: 'web', name, url })
    })

    // YouTube links: fetch the real transcript via the KamiSensei backend.
    if (ytUrls.length) {
      setKsSourceLoading(true, `Fetching transcript${ytUrls.length > 1 ? 's' : ''}…`)
      let okCount = 0
      for (const url of ytUrls) {
        const displayName = url.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '')
        setKsSourceLoading(true, `Fetching transcript: ${displayName.length > 40 ? displayName.slice(0, 40) + '…' : displayName}`)
        try {
          const res = await fetch('/api/kamisensei/youtube-extract', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url }),
            signal: AbortSignal.timeout(150000),
          })
          const data = await res.json().catch(() => null)
          if (res.ok && data && data.status === 'success') {
            ksAddUiSource({
              kind: 'youtube',
              name: data.title || displayName,
              url,
              transcript: data.transcript || '',
              author: data.author || '',
            })
            okCount++
          } else {
            const errMsg = (data && data.error) || `HTTP ${res.status}`
            ksAddUiSource({ kind: 'youtube', name: displayName, url })
            showToast(`Could not fetch transcript for: ${displayName} — ${errMsg}`, true)
            console.warn('[KS] YouTube extract failed:', url, errMsg)
          }
        } catch (err) {
          ksAddUiSource({ kind: 'youtube', name: displayName, url })
          showToast(`Network error fetching transcript for: ${displayName}`, true)
          console.error('[KS] YouTube extract network error:', url, err)
        }
      }
      setKsSourceLoading(false)
      if (webUrls.length) showToast(`Added ${okCount}/${ytUrls.length} YouTube transcript${ytUrls.length === 1 ? '' : 's'} and ${webUrls.length} link source${webUrls.length === 1 ? '' : 's'}.`, okCount === ytUrls.length)
      else showToast(okCount === ytUrls.length
        ? `Fetched ${okCount} YouTube transcript${okCount === 1 ? '' : 's'} — saved to this notebook.`
        : `Fetched ${okCount}/${ytUrls.length} transcripts. See toasts for failures.`, okCount === ytUrls.length)
      ksAsmClose()
      await loadKsSources().then(renderStudio).catch(() => {})
      await loadKsJsonSources()
      return
    }

    // Website-links-only path (no YouTube): instant save.
    if (webUrls.length) {
      showToast(`Added ${webUrls.length} link source${webUrls.length === 1 ? '' : 's'} — saved to this notebook. Link indexing is coming soon.`)
      ksAsmClose()
      await loadKsSources().then(renderStudio).catch(() => {})
    }
  }
  function ksAsmCommitPaste() {
    const ta = $('#ks-asm-paste-input')
    if (!ta) return
    const text = ta.value.trim()
    if (!text) { showToast('Paste some text first.', true); return }
    const name = text.slice(0, 48).replace(/\s+/g, ' ').trim() + (text.length > 48 ? '…' : '')
    ensureActiveNotebook().then(() => {
      if (!ksAddUiSource({ kind: 'text', name, text })) { showToast('That text source already exists.', true); return }
      showToast('Copied text saved as a source (deep text indexing coming soon).')
      ksAsmClose()
      loadKsSources().then(renderStudio).catch(() => {})
    })
  }
  function bindKsAddSourceModal() {
    $('#kamisensei-add-source-btn')?.addEventListener('click', openKsAddSourceModal)
    $('#sources-empty-add-btn')?.addEventListener('click', openKsAddSourceModal)
    $('#ks-asm-close')?.addEventListener('click', ksAsmClose)
    $('#ks-add-source-modal')?.addEventListener('click', (e) => { if (e.target.id === 'ks-add-source-modal') ksAsmClose() })
    $('#ks-asm-upload')?.addEventListener('click', () => {
      const fi = $('#kamisensei-file-input')
      if (fi) { ksAsmClose(); fi.click() }
    })
    $('#ks-asm-websites')?.addEventListener('click', () => ksAsmShowView('links'))
    $('#ks-asm-paste')?.addEventListener('click', () => ksAsmShowView('paste'))
    $('#ks-asm-drive')?.addEventListener('click', () => showToast('Google Drive import is coming soon — UI preview only.', true))
    $('#ks-asm-scan')?.addEventListener('click', () => showToast('Adobe Scan import is coming soon — UI preview only.', true))
    $('#ks-asm-links-back')?.addEventListener('click', () => ksAsmShowView('main'))
    $('#ks-asm-paste-back')?.addEventListener('click', () => ksAsmShowView('main'))
    $('#ks-asm-links-add')?.addEventListener('click', ksAsmCommitLinks)
    $('#ks-asm-paste-add')?.addEventListener('click', ksAsmCommitPaste)
    $('#ks-asm-search-go')?.addEventListener('click', () => {
      const note = $('#ks-asm-search-note')
      if (note) note.style.display = 'block'
    })
    $('#ks-asm-search-input')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault()
        const note = $('#ks-asm-search-note')
        if (note) note.style.display = 'block'
      }
    })
  }

  /* ── In-panel Source Viewer (UI shell) ──────────────────────────────────── */
  function openKsSourceViewer(src) {
    const viewer = $('#ks-source-viewer')
    if (!viewer) return
    const title = $('#ks-sv-title')
    if (title) title.textContent = src.name || 'Source'
    const guideBody = $('#ks-sv-guide-body')
    if (guideBody) guideBody.style.display = 'none'
    const body = $('#ks-sv-body')
    if (body) {
      if (src.kind === 'youtube') {
        if (src.transcript) {
          body.innerHTML = `
            <div class="ks-sv-chip yt"><i data-lucide="youtube"></i><span>YouTube video</span></div>
            ${src.author ? `<p class="ks-sv-meta">Channel: ${escapeHtml(src.author)}</p>` : ''}
            <div class="ks-sv-transcript-wrap">
              <div class="ks-sv-transcript-head"><i data-lucide="scroll-text"></i><span>Transcript</span></div>
              <pre class="ks-sv-pre ks-sv-transcript">${escapeHtml(src.transcript)}</pre>
            </div>
            ${src.url ? `<a class="ks-sv-url" href="${escapeHtml(src.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(src.url)}</a>` : ''}`
        } else {
          body.innerHTML = `
            <div class="ks-sv-chip yt"><i data-lucide="youtube"></i><span>YouTube video</span></div>
            <p class="ks-sv-note">This video is saved to the notebook but no transcript was extracted. The video may have no captions, or extraction failed.</p>
            ${src.url ? `<a class="ks-sv-url" href="${escapeHtml(src.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(src.url)}</a>` : ''}`
        }
      } else if (src.kind === 'web') {
        body.innerHTML = `
          <div class="ks-sv-chip web"><i data-lucide="globe"></i><span>Website</span></div>
          <p class="ks-sv-note">This page is saved to the notebook. Page-text extraction is coming soon — once wired, the readable article will render here.</p>
          ${src.url ? `<a class="ks-sv-url" href="${escapeHtml(src.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(src.url)}</a>` : ''}`
      } else if (src.kind === 'text') {
        body.innerHTML = `
          <div class="ks-sv-chip text"><i data-lucide="clipboard-list"></i><span>Copied text</span></div>
          <pre class="ks-sv-pre">${escapeHtml(src.text || '(empty)')}</pre>`
      } else {
        body.innerHTML = `
          <div class="ks-sv-chip file"><i data-lucide="file-text"></i><span>Document</span></div>
          <p class="ks-sv-meta">${escapeHtml(src.meta || 'Indexed document')}</p>
          <p class="ks-sv-note">In-app PDF / text preview is on the roadmap. This file is already indexed — ask KamiSensei about it in Chat, or generate an artifact to see its content in action.</p>`
      }
    }
    viewer.style.display = 'flex'
    if (window.lucide) window.lucide.createIcons()
  }
  function closeKsSourceViewer() {
    const v = $('#ks-source-viewer')
    if (v) v.style.display = 'none'
  }
  function bindKsSourceViewer() {
    $('#ks-sv-back')?.addEventListener('click', closeKsSourceViewer)
    $('#ks-sv-guide')?.addEventListener('click', () => {
      const body = $('#ks-sv-guide-body')
      if (!body) return
      const open = body.style.display !== 'none'
      body.style.display = open ? 'none' : 'block'
      $('#ks-sv-guide')?.classList.toggle('open', !open)
    })
  }

  async function uploadKsFiles(fileList) {
    const files = fileList && fileList.length ? Array.from(fileList) : []
    if (!files.length) return
    let okCount = 0
    const uploadToastId = showToast(`Importing ${files.length} file${files.length === 1 ? '' : 's'}…`, false)
    for (const file of files) {
      try {
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader()
          reader.onload = () => resolve(String(reader.result || ''))
          reader.onerror = () => reject(new Error('Could not read the file'))
          reader.readAsDataURL(file)
        })
        uploadToastId.update(`Uploading ${file.name} and indexing…`)
        const res = await fetch('/api/kamisensei/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: file.name, data: base64 }),
          signal: AbortSignal.timeout(120000)
        })
        const data = await res.json().catch(() => null)
        if (!res.ok) throw new Error((data && data.message) || `HTTP ${res.status}`)
        okCount++
        // Register the file in THIS notebook's manifest and auto-select it so
        // chat + artifact generation are grounded only in what this notebook owns.
        ksAddSourceToManifest(file.name)
        if (!ksSelectedSources.includes(file.name)) ksSelectedSources.push(file.name)
      } catch (err) {
        console.error('[KS] Upload failed for', file.name, err)
        showToast(`Upload failed: ${file.name} — ${err.message || 'unknown error'}`, true)
      }
    }
    if (okCount) showToast(`Imported ${okCount} source${okCount === 1 ? '' : 's'} and triggered ingestion.`, false)
    await loadKsSources()
    renderStudio()
  }

  async function deleteKsSource(name) {
    if (!confirm(`Delete source "${name}"? This removes the file and its vector index.`)) return
    try {
      const res = await fetch('/api/kamisensei/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: name }),
        signal: AbortSignal.timeout(120000)
      })
      const data = await res.json().catch(() => null)
      if (!res.ok) throw new Error((data && data.message) || `HTTP ${res.status}`)
      ksSelectedSources = ksSelectedSources.filter((s) => s !== name)
      ksRemoveSourceFromManifest(name)
      persistKsSourceSelection()
      showToast(`Deleted ${name}.`)
    } catch (err) {
      console.error('[KS] Source delete failed:', err)
      showToast(`Delete failed: ${err.message || 'unknown error'}`, true)
    }
    await loadKsSources()
    renderStudio()
  }

  function bindKsSources() {
    const fileInput = $('#kamisensei-file-input')
    ;['#sources-import-btn']
      .map((sel) => $(sel))
      .filter(Boolean)
      .forEach((btn) => btn.addEventListener('click', () => { if (fileInput) fileInput.click() }))
    if (fileInput) {
      fileInput.addEventListener('change', async () => {
        await uploadKsFiles(fileInput.files)
        fileInput.value = ''
      })
    }

    // Drag & drop over the content area / dropzone.
    const dropTargets = [$('#sources-content-area'), $('#sources-dropzone')].filter(Boolean)
    const onDragOver = (e) => { e.preventDefault(); const dz = $('#sources-dropzone'); if (dz) dz.classList.add('dragover') }
    const onDragLeave = () => { const dz = $('#sources-dropzone'); if (dz) dz.classList.remove('dragover') }
    const onDrop = async (e) => {
      e.preventDefault()
      const dz = $('#sources-dropzone')
      if (dz) dz.classList.remove('dragover')
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) await uploadKsFiles(e.dataTransfer.files)
    }
    dropTargets.forEach((el) => {
      el.addEventListener('dragover', onDragOver)
      el.addEventListener('dragleave', onDragLeave)
      el.addEventListener('drop', onDrop)
    })

    bindKsAddSourceModal()
    bindKsSourceViewer()

    $('#sources-delete-all-btn')?.addEventListener('click', async () => {
      if (!ksSourceCache.length) return
      if (!confirm(`Delete all ${ksSourceCache.length} sources? This removes every file and its vector index.`)) return
      let failed = 0
      for (const file of ksSourceCache) {
        const name = ksSourceName(file)
        if (!name) continue
        try {
          const res = await fetch('/api/kamisensei/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: name }),
            signal: AbortSignal.timeout(120000)
          })
          if (!res.ok) failed++
        } catch (err) {
          failed++
          console.error(`[KS] Failed to delete source ${name}:`, err)
        }
      }
      ksSelectedSources = []
      persistKsSourceSelection()
      if (failed) showToast(`Deleted ${Math.max(0, ksSourceCache.length - failed)} sources; ${failed} failed.`, true)
      else showToast('All sources deleted.')
      await loadKsSources()
      renderStudio()
    })

    // Non-blocking API polling: refresh the SOURCES grid every 10 seconds so newly
    // written files in ./knowledge_base/ appear without a manual reload.
    window.KS.ready.then(() => loadKsSources()).catch((err) => console.error('[KS] Sources init failed:', err))
    loadKsSources()
    setInterval(() => {
      if (document.visibilityState !== 'visible' || ksRoute.view !== 'notebook') return
      loadKsSources().catch((err) => console.error('[KS] Scheduled source refresh failed:', err))
    }, 30000)
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && ksRoute.view === 'notebook') {
        loadKsSources().catch((err) => console.error('[KS] Visibility refresh failed:', err))
      }
    })
  }

  // ─────────────────────────────────────────────────────────────────────────
  // KAMISENSEI LINGUISTIC CONSOLE (Center Column)
  // Wires the pinned "Ask a question…" input to the RAG-backed KamiSensei
  // engine and renders the conversation into the center chat column. Runs
  // inside its own error boundary so it can never freeze the rest of the app.
  // ─────────────────────────────────────────────────────────────────────────
  let ksChatBusy = false
  let ksChatAbortController = null

  function setKsChatBusyState(busy) {
    const sendButton = $('#kamisensei-send-btn')
    if (!sendButton) return
    sendButton.title = busy ? 'Cancel response' : 'Send message'
    sendButton.setAttribute('aria-label', busy ? 'Cancel response' : 'Send message')
    sendButton.classList.toggle('cancelling', busy)
    sendButton.innerHTML = busy ? '<i data-lucide="square"></i>' : '<i data-lucide="send"></i>'
    if (window.lucide) window.lucide.createIcons()
  }

  function ksRenderMarkdown(text) {
    return String(text)
      .split('\n')
      .map((raw) => {
        const line = escapeHtml(raw)
        if (/^###\s+/.test(raw)) return `<div class="ks-section-lead"><strong>${line.replace(/^###\s+/, '')}</strong></div>`
        if (!line.trim()) return ''
        return `<p class="ks-p">${line
          .replace(/\*\*(.*?)\*\*/g, '<strong class="ks-bold">$1</strong>')
          .replace(/`([^`]+)`/g, '<code class="ks-code">$1</code>')
        }</p>`
      })
      .join('')
  }

  function ksBubble(role, content, citations = []) {
    const log = $('#kamisensei-chat-log')
    if (!log) return
    const msg = document.createElement('div')
    msg.className = `ks-msg ${role}`
    const bubble = document.createElement('div')
    bubble.className = 'ks-bubble'
    if (role === 'user') {
      bubble.textContent = content
    } else {
      const flow = document.createElement('div')
      flow.className = 'ks-markdown-flow'
      flow.innerHTML = ksRenderMarkdown(content) + ksCitationChips(citations)
      bindCitationChips(flow, citations)
      bubble.appendChild(flow)
    }
    const avatar = document.createElement('span')
    avatar.className = 'ks-avatar'
    avatar.textContent = role === 'assistant' ? 'J' : 'P'
    msg.appendChild(avatar)
    msg.appendChild(bubble)
    log.appendChild(msg)
    log.scrollTop = log.scrollHeight
  }

  /* ── Streaming chat (SSE): meta → token* → done | error ─────────────────── */
  let ksChatHistory = []
  let ksCitations = []
  let ksStickBottom = true

  async function restoreKsChatHistory() {
    // Per-notebook restore: reads ONLY the active notebook's isolated data
    // sector (jarvis_kamisensei_data_<id>) — never a global chat key, so one
    // notebook's dialogue can never leak into another's workspace.
    const id = ksRoute && ksRoute.notebookId
    if (!id) return
    if (window.KSNotebooks) {
      ksChatHistory = KSNotebooks.chatOf(id).slice(-20)
    } else if (window.KS && window.KS.prefs) {
      try {
        const saved = await window.KS.prefs.get('ks-chat-history-' + id, [])
        ksChatHistory = Array.isArray(saved) ? saved.slice(-20) : []
      } catch (err) {
        console.error('[KS] Chat history restore failed:', err)
        return
      }
    } else {
      return
    }
    if (!ksChatHistory.length) return
    const hero = $('#kamisensei-welcome-hero')
    const log = $('#kamisensei-chat-log')
    if (hero) hero.style.display = 'none'
    if (log) {
      log.style.display = 'flex'
      log.innerHTML = ''
      ksChatHistory.forEach((turn) => ksBubble(turn.role, turn.content, Array.isArray(turn.citations) ? turn.citations : []))
    }
  }

  function persistKsChatHistory() {
    // Synchronous per-notebook commit: every user query, assistant reply, and
    // clear is written to this notebook's own sector immediately.
    const id = ksRoute && ksRoute.notebookId
    if (!id) return
    if (window.KSNotebooks) {
      KSNotebooks.updateChat(id, ksChatHistory.slice(-20))
    } else if (window.KS && window.KS.prefs) {
      window.KS.prefs.set('ks-chat-history-' + id, ksChatHistory.slice(-20))
        .catch((err) => console.error('[KS] Chat history persistence failed:', err))
    }
  }

  function ksNearBottom(log) {
    return log.scrollHeight - log.scrollTop - log.clientHeight < 90
  }

  function ksScrollChat(log) {
    if (ksStickBottom) log.scrollTop = log.scrollHeight
    const jump = $('#ks-jump-latest')
    if (jump) jump.style.display = ksStickBottom ? 'none' : 'flex'
  }

  function showKsCitation(index, citations = ksCitations) {
    const cite = citations.find((c) => c.index === index)
    if (!cite) return
    const modal = $('#ks-citation-popover')
    if (!modal) return
    const src = $('#ks-cite-source'); if (src) src.textContent = cite.source || 'Unknown source'
    const pg = $('#ks-cite-page'); if (pg) pg.textContent = cite.page ? `Page ${cite.page}` : 'Page unavailable'
    const tx = $('#ks-cite-text'); if (tx) tx.textContent = cite.text || '(no passage retained)'
    modal.style.display = 'flex'
  }

  function ksCitationChips(citations = ksCitations) {
    if (!citations.length) return ''
    const chips = citations.map((c) => `<button class="ks-cite-chip" type="button" data-cite="${c.index}" title="${escapeHtml(c.source)}${c.page ? ` · Page ${c.page}` : ''}">[${c.index}]</button>`).join('')
    return `<div class="ks-cite-row"><span class="ks-cite-label">SOURCES</span>${chips}</div>`
  }

  function bindCitationChips(root, citations = ksCitations) {
    root.querySelectorAll('.ks-cite-chip').forEach((chip) => {
      chip.addEventListener('click', () => showKsCitation(Number(chip.getAttribute('data-cite')), citations))
    })
  }

  async function ksAsk(query) {
    if (ksChatBusy) return
    // Notebook ownership snapshot: the reply is written back ONLY if this
    // exact notebook is still active when the stream finishes — a notebook
    // switch mid-stream can never plant the old dialogue in the new one.
    const notebookAtStart = ksActiveNotebookId()
    const hero = $('#kamisensei-welcome-hero')
    const log = $('#kamisensei-chat-log')
    if (hero) hero.style.display = 'none'
    if (log) log.style.display = 'flex'
    ksBubble('user', query)
    ksChatBusy = true
    ksChatAbortController = new AbortController()
    let timedOut = false
    const timeoutId = setTimeout(() => {
      timedOut = true
      ksChatAbortController?.abort()
    }, 120000)
    setKsChatBusyState(true)
    setRuntimeState('THINKING')
    ksStickBottom = true

    // Assistant message shell: thinking indicator until the first token lands.
    const msg = document.createElement('div')
    msg.className = 'ks-msg assistant'
    const bubble = document.createElement('div')
    bubble.className = 'ks-bubble'
    const flow = document.createElement('div')
    flow.className = 'ks-markdown-flow'
    flow.innerHTML = '<div class="ks-thinking"><span class="ks-thinking-dot"></span><span class="ks-thinking-text">KAMI-SENSEI // Processing context...</span></div>'
    bubble.appendChild(flow)
    const avatar = document.createElement('span')
    avatar.className = 'ks-avatar'
    avatar.textContent = 'J'
    msg.appendChild(avatar)
    msg.appendChild(bubble)
    if (log) log.appendChild(msg)
    ksScrollChat(log || document.body)

    let reply = ''
    let errored = ''
    let meta = null

    try {
      const response = await fetch('/api/kamisensei/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          // Empty selection scopes retrieval to THIS notebook's manifest —
          // another notebook's sources can never leak into the RAG context.
          sourceIds: (() => {
            const scope = ksSelectedSources.length ? [...ksSelectedSources] : [...ksNotebookManifestNames()]
            return scope.length ? scope : undefined
          })(),
          notebookId: ksRoute.notebookId || ksRoute.workbook || undefined,
          history: ksChatHistory.slice(-10)
        }),
        signal: ksChatAbortController.signal
      })
      if (!response.ok || !response.body) throw new Error(`KamiSensei engine returned HTTP ${response.status}`)

      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const frames = buffer.split('\n\n')
        buffer = frames.pop() || ''
        for (const frame of frames) {
          let event = 'message'
          let data = ''
          for (const line of frame.split('\n')) {
            if (line.startsWith('event:')) event = line.slice(6).trim()
            else if (line.startsWith('data:')) data += line.slice(5).trim()
          }
          if (!data) continue
          try {
            const payload = JSON.parse(data)
            if (event === 'meta') { meta = payload; ksCitations = Array.isArray(payload.citations) ? payload.citations : [] }
            else if (event === 'token') { reply += String(payload.t || '') }
            else if (event === 'done') {
              // Server's authoritative final metadata (provider, sources_used, citations, context info)
              if (!meta) meta = payload
              else {
                meta.provider = meta.provider || payload.provider
                meta.sources_used = Array.isArray(payload.sources_used) ? payload.sources_used : meta.sources_used
                if (Array.isArray(payload.citations) && !ksCitations.length) ksCitations = payload.citations
                meta.context_chunks = payload.context_chunks ?? meta.context_chunks
                meta.context_ok = payload.context_ok ?? meta.context_ok
              }
            }
            else if (event === 'error') { errored = String(payload.error || 'Stream failure') }
          } catch (err) {
            console.debug('[KS] Ignored malformed SSE frame:', err)
          }
        }
        if (reply) {
          flow.innerHTML = ksRenderMarkdown(reply)
          setRuntimeState('STREAMING')
        }
        if (log) ksScrollChat(log)
        if (errored) break
      }
      if (errored) throw new Error(errored)
      if (!reply.trim()) throw new Error('The engine returned an empty response.')

      const responseCitations = ksCitations.map((citation) => ({ ...citation }))
      flow.innerHTML = ksRenderMarkdown(reply) + ksCitationChips(responseCitations)
      bindCitationChips(flow, responseCitations)
      if (ksActiveNotebookId() !== notebookAtStart) return // notebook switched mid-stream — never write across workspaces
      ksChatHistory.push({ role: 'user', content: query })
      ksChatHistory.push({ role: 'assistant', content: reply, citations: responseCitations })
      if (ksChatHistory.length > 20) ksChatHistory = ksChatHistory.slice(-20)
      persistKsChatHistory()
      const sourcesUsed = (meta && Array.isArray(meta.sources_used)) ? meta.sources_used : []
      if (sourcesUsed.length) addActivity(`KamiSensei: ${query}`, `Sources: ${sourcesUsed.slice(0, 4).join(' · ')}`)
      else addActivity(`KamiSensei: ${query}`, meta && meta.provider ? `Answered by ${meta.provider}` : 'KamiSensei response')
      speak(reply)
      if (window.lucide) window.lucide.createIcons()
      setRuntimeState('STANDBY')
    } catch (err) {
      const wasCancelled = ksChatAbortController && ksChatAbortController.signal.aborted && !timedOut
      const fail = timedOut
        ? 'The KamiSensei response timed out after 120 seconds.'
        : wasCancelled
          ? 'Response cancelled.'
          : String(err && err.message ? err.message : '')
      if (!wasCancelled) console.error('[KS] Chat query failed:', err)
      flow.innerHTML = ksRenderMarkdown(fail || 'I could not reach the KamiSensei engine. Check that the local bridge is running, then try again.')
      if (!wasCancelled) showToast(fail ? `KamiSensei: ${fail}` : 'KamiSensei query failed', true)
      setRuntimeState(wasCancelled ? 'STANDBY' : 'ERROR')
    } finally {
      clearTimeout(timeoutId)
      ksChatBusy = false
      ksChatAbortController = null
      setKsChatBusyState(false)
      ksScrollChat(log || document.body)
    }
  }

  function clearKsChat(silent) {
    const log = $('#kamisensei-chat-log')
    const hero = $('#kamisensei-welcome-hero')
    if (log) { log.innerHTML = ''; log.style.display = 'none' }
    if (hero) hero.style.display = ''
    if (ksChatAbortController) ksChatAbortController.abort()
    ksChatHistory = []
    ksCitations = []
    // silent=true is the notebook-switch reset path: the new notebook's sector
    // must NOT receive the old session's (now emptied) chat buffer.
    if (!silent) persistKsChatHistory()
    if (!silent) showToast('KamiSensei chat cleared.')
  }

  function bindKsChat() {
    window.KS.ready.then(restoreKsChatHistory)
      .catch((err) => console.error('[KS] Chat state initialization failed:', err))
    const form = $('#kamisensei-prompt-form')
    form?.addEventListener('submit', (event) => {
      event.preventDefault()
      if (ksChatBusy) {
        ksChatAbortController?.abort()
        return
      }
      const input = $('#kamisensei-input')
      if (!input) return
      const text = input.value.trim()
      if (!text) return
      input.value = ''
      ksAsk(text)
    })
    $('#kamisensei-input')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') { event.preventDefault(); form?.requestSubmit() }
    })
    $('#kamisensei-mic-btn')?.addEventListener('click', toggleVoice)
    $('#kamisensei-mute-btn')?.addEventListener('click', () => {
      if (state.activeAudio) {
        try { state.activeAudio.pause(); state.activeAudio = null } catch (err) { console.warn('[JARVIS] Could not stop active audio:', err) }
      }
      if ('speechSynthesis' in window && !state.activeAudio) window.speechSynthesis.cancel()
      const muteBtn = $('#kamisensei-mute-btn')
      if (muteBtn) muteBtn.hidden = true
      setRuntimeState(state.listening ? 'LISTENING' : 'STANDBY')
      showToast('Assistant audio stopped.')
    })
    $('#kamisensei-clear-chat-btn')?.addEventListener('click', clearKsChat)
    // Smart auto-scroll: follow the stream only while the user is near the
    // bottom; manual upward scrolling stops forced scrolling until they
    // either return to the bottom or click [Jump to latest].
    const log = $('#kamisensei-chat-log')
    if (log && log.dataset.ksScrollBound !== '1') {
      log.dataset.ksScrollBound = '1'
      log.addEventListener('scroll', () => {
        ksStickBottom = ksNearBottom(log)
        const jump = $('#ks-jump-latest')
        if (jump) jump.style.display = ksStickBottom ? 'none' : 'flex'
      })
    }
    $('#ks-jump-latest')?.addEventListener('click', () => {
      ksStickBottom = true
      const chatLog = $('#kamisensei-chat-log')
      if (chatLog) chatLog.scrollTop = chatLog.scrollHeight
      const jump = $('#ks-jump-latest')
      if (jump) jump.style.display = 'none'
    })
    $('#ks-citation-close')?.addEventListener('click', () => {
      const modal = $('#ks-citation-popover')
      if (modal) modal.style.display = 'none'
    })
  }

  
  // ---- Floating Research Launcher ----
  let researchWindow = null;
  let lastResearchSeq = 0;
  function openResearch() {
    const w = 900, h = 680, sx = window.screen.availWidth - w - 20, sy = 40;
    researchWindow = window.open('/research', 'jarvis-research',
      'width=' + w + ',height=' + h + ',left=' + sx + ',top=' + sy + ',menubar=no,toolbar=no,location=no,status=no');
  }
  function ensureResearchFab() {
    if ($('#research-fab')) return;
    const fab = document.createElement('div');
    fab.id = 'research-fab';
    fab.title = 'Open Research Panel';
    fab.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35M11 8v6M8 11h6"/></svg>';
    document.body.appendChild(fab);
    fab.addEventListener('click', openResearch);
  }
  function patchResearch() {
    ensureResearchFab();
    setInterval(async () => {
      try {
        const r = await fetch('/api/voice-state', { cache: 'no-store' });
        if (!r.ok) return;
        const d = await r.json();
        if (d.research_seq && d.research_seq !== lastResearchSeq) {
          lastResearchSeq = d.research_seq;
          const fab = $('#research-fab');
          if (fab) fab.classList.add('flash');
          setTimeout(() => { if (fab) fab.classList.remove('flash'); }, 4000);
          if (!researchWindow || researchWindow.closed) openResearch();
        }
      } catch (e) {}
    }, 2500);
  }

document.addEventListener('DOMContentLoaded', init)
})();
