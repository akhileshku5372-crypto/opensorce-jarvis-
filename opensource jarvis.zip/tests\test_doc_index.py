"""Phase 2 - document RAG tests.

Everything runs against a temp JARVIS_DATA_ROOT (never the real store) and only
touches files inside a temp document tree, so the suite stays offline-safe and
cannot cite or delete the user's real documents.

The behaviour locked in here is the honesty contract, not just happy paths:
junk directories are skipped, scanned PDFs are reported as no_text instead of
"indexed", a deleted file can no longer be cited, and a quota stop says so.
"""
import importlib
import importlib.util
import os
import shutil
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class _TempRoot:
    def __init__(self):
        self.path = Path(tempfile.mkdtemp(prefix="jarvis_doc_test_"))

    def cleanup(self):
        shutil.rmtree(self.path, ignore_errors=True)


def _load_module(key: str, path: Path):
    spec = importlib.util.spec_from_file_location(key, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


class DocIndexTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = _TempRoot()
        cls.addClassCleanup(cls.tmp.cleanup)
        os.environ["JARVIS_DATA_ROOT"] = str(cls.tmp.path)
        os.environ.pop("JARVIS_DOC_ROOTS", None)
        sys.path.insert(0, str(ROOT / "background"))
        # Purge storage identities so the module resolves THIS temp root.
        for name in list(sys.modules):
            if (name in ("storage_paths", "doc_index")
                    or name.startswith("jarvis_cowork_")):
                sys.modules.pop(name, None)
        cls.doc_index = importlib.import_module("doc_index")
        cls.docs = cls.tmp.path / "documents"
        cls.docs.mkdir(parents=True, exist_ok=True)

    def setUp(self):
        # Every test starts from an empty index but keeps the temp root.
        self.doc_index.clear()

    # ── helpers ────────────────────────────────────────────────────────────

    def _pdf(self, name, page_texts):
        import pymupdf as fitz
        path = self.docs / name
        doc = fitz.open()
        for text in page_texts:
            page = doc.new_page()
            if text:
                page.insert_text((72, 72), text)
        doc.save(str(path))
        doc.close()
        return path

    def _docx(self, name, paragraphs):
        import docx
        path = self.docs / name
        doc = docx.Document()
        for text in paragraphs:
            doc.add_paragraph(text)
        doc.save(str(path))
        return path

    def _text(self, name, body, folder=None):
        path = (folder or self.docs) / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body, encoding="utf-8")
        return path

    # ── scanning ───────────────────────────────────────────────────────────

    def test_scan_filters_extensions_and_skips_junk_dirs(self):
        folder = self.tmp.path / "scan_tree"
        folder.mkdir(parents=True, exist_ok=True)
        self._text("keep.md", "hello", folder)
        self._text("keep.csv", "a,b\n1,2", folder)
        self._text("skip.png", "not a doc", folder)
        self._text("code/app.py", "print('x')", folder)
        self._text("node_modules/pkg/readme.md", "noise", folder)
        big = folder / "big.pdf"
        big.write_bytes(b"\x00" * (self.doc_index.MAX_FILE_BYTES + 1024))
        files, skipped = self.doc_index._scan([folder], include_code=False)
        names = sorted(p.name for p, _, _ in files)
        self.assertEqual(names, ["keep.csv", "keep.md"])
        self.assertGreaterEqual(skipped["ext"], 1)      # png
        self.assertGreaterEqual(skipped["dir"], 1)      # node_modules
        self.assertGreaterEqual(skipped["big"], 1)      # 20MB+ file
        code_files, _ = self.doc_index._scan([folder], include_code=True)
        code_names = sorted(p.name for p, _, _ in code_files)
        self.assertIn("app.py", code_names)

    def test_chunks_pack_paragraphs_and_split_long_ones(self):
        body = "first paragraph\n\n" + ("x" * 2500)
        chunks = self.doc_index._chunks(body, limit=1000)
        self.assertGreaterEqual(len(chunks), 3)
        for chunk in chunks:
            self.assertLessEqual(len(chunk), 1000)

    # ── extraction ─────────────────────────────────────────────────────────

    def test_pdf_pages_keep_page_numbers_and_blank_pages_are_no_text(self):
        path = self._pdf("two_pages.pdf", ["alpha page one", "beta page two"])
        pages, error = self.doc_index._pages_of(path)
        self.assertEqual(error, "")
        self.assertEqual([p for p, _ in pages], [1, 2])
        blank = self._pdf("blank.pdf", [None])
        pages, error = self.doc_index._pages_of(blank)
        self.assertEqual(error, "")
        self.assertEqual(pages, [])

    def test_docx_and_pptx_extraction(self):
        path = self._docx("memo.docx", ["Contract renewal date", "Fee is 5000"])
        pages, error = self.doc_index._pages_of(path)
        self.assertEqual(error, "")
        self.assertIn("Contract renewal date", pages[0][1])
        pptx_path = self.docs / "deck.pptx"
        try:
            from pptx import Presentation
            deck = Presentation()
            slide = deck.slides.add_slide(deck.slide_layouts[5])
            slide.shapes.title.text = "Roadmap slide about telemetry"
            deck.save(str(pptx_path))
        except Exception as exc:                      # pragma: no cover
            self.skipTest("python-pptx unavailable: %s" % exc)
        pages, error = self.doc_index._pages_of(pptx_path)
        self.assertEqual(error, "")
        self.assertEqual(pages[0][0], 1)
        self.assertIn("telemetry", pages[0][1])

    # ── index + query round trip ───────────────────────────────────────────

    def test_index_then_query_returns_real_citations(self):
        folder = self.tmp.path / "corpus"
        self._text("battery.md",
                   "Laptop battery health measured at 92 percent capacity "
                   "with 120 charge cycles recorded.",
                   folder)
        self._text("recipe.md",
                   "Paneer butter masala needs cream, tomatoes and butter.",
                   folder)
        report = self.doc_index.index(roots=[folder])
        self.assertTrue(report["ok"], report)
        self.assertEqual(report["indexed"], 2)
        self.assertGreater(report["chunks"], 0)
        out = self.doc_index.query("how healthy is the laptop battery", k=3)
        self.assertTrue(out["ok"], out)
        self.assertTrue(out["results"])
        top = out["results"][0]
        self.assertEqual(top["document"], "battery.md")
        self.assertIn("battery", top["excerpt"].lower())
        self.assertTrue(top["path"].endswith("battery.md"))
        self.assertIn("battery.md", out["formatted"][0])
        spoken = self.doc_index.spoken("battery", out["results"])
        self.assertIn("battery.md", spoken)

    def test_query_before_any_index_says_so(self):
        out = self.doc_index.query("anything")
        self.assertFalse(out["ok"])
        self.assertEqual(out["error"], "index_empty")
        self.assertIn("index my documents", out["hint"])

    def test_reindex_is_incremental_and_drops_stale_and_deleted_chunks(self):
        folder = self.tmp.path / "inc"
        path = self._text("notes.md", "original alpha topic marker", folder)
        first = self.doc_index.index(roots=[folder])
        self.assertEqual(first["indexed"], 1)
        second = self.doc_index.index(roots=[folder])
        self.assertEqual(second["unchanged"], 1)
        self.assertEqual(second["indexed"], 0)
        # change the file: bump mtime so the manifest notices
        path.write_text("completely different beta wording", encoding="utf-8")
        os.utime(path, (time.time() + 5, time.time() + 5))
        third = self.doc_index.index(roots=[folder])
        self.assertEqual(third["updated"], 1)
        stale = self.doc_index.query("original alpha topic marker")
        found_stale = [r for r in stale.get("results", [])
                       if "alpha" in r["excerpt"]]
        self.assertEqual(found_stale, [],
                         "old text must not survive a re-index")
        fresh = self.doc_index.query("completely different beta wording")
        self.assertTrue(fresh["ok"])
        self.assertTrue(fresh["results"])
        # delete the file: it must vanish from search and from the manifest
        path.unlink()
        fourth = self.doc_index.index(roots=[folder])
        self.assertEqual(fourth["removed"], 1)
        gone = self.doc_index.query("completely different beta wording")
        self.assertFalse(gone.get("results"))

    def test_scanned_pdf_without_text_layer_is_reported_not_indexed(self):
        folder = self.tmp.path / "scans"
        folder.mkdir(parents=True, exist_ok=True)
        blank = folder / "scan.pdf"
        import pymupdf as fitz
        doc = fitz.open()
        doc.new_page()
        doc.save(str(blank))
        doc.close()
        report = self.doc_index.index(roots=[folder])
        self.assertEqual(report["no_text"], 1)
        self.assertEqual(report["indexed"], 0)
        state = self.doc_index.status()
        self.assertEqual(state["no_text"], 1)

    def test_quota_stop_is_reported_honestly(self):
        folder = self.tmp.path / "quota"
        self._text("big.md", "quota probe " * 200, folder)
        original = self.doc_index._paths.guard_write
        self.doc_index._paths.guard_write = lambda n: False
        try:
            report = self.doc_index.index(roots=[folder])
        finally:
            self.doc_index._paths.guard_write = original
        self.assertFalse(report["ok"])
        self.assertEqual(report["stopped"], "storage_quota_reached")

    def test_status_reports_counts_and_roots(self):
        state = self.doc_index.status()
        self.assertTrue(state["available"])
        self.assertEqual(state["collection"], "jarvis_documents")
        self.assertIn("jarvis", state["dir"].lower())
        self.assertFalse(state["running"])

    # ── tool wrappers + background thread ──────────────────────────────────

    def test_tool_search_without_index_is_honest(self):
        out = self.doc_index._tool_doc_search({"query": "anything"})
        self.assertFalse(out["ok"])
        self.assertIn("index my documents", out["output"])

    def test_tool_index_runs_in_background_and_finishes(self):
        folder = self.tmp.path / "threaded"
        self._text("threaded.md", "threaded indexing marker content", folder)
        out = self.doc_index._tool_doc_index({"roots": str(folder), "limit": 5})
        self.assertTrue(out["ok"], out)
        deadline = time.time() + 60
        while self.doc_index.index_running() and time.time() < deadline:
            time.sleep(0.25)
        self.assertFalse(self.doc_index.index_running(), "index thread hung")
        report = self.doc_index._RUN.get("report") or {}
        self.assertTrue(report.get("ok"), report)
        found = self.doc_index.query("threaded indexing marker")
        self.assertTrue(found["ok"])
        self.assertEqual(found["results"][0]["document"], "threaded.md")
        status_text = self.doc_index._tool_doc_status({})["output"]
        self.assertIn("Document index", status_text)

    def test_clear_wipes_store_and_manifest(self):
        folder = self.tmp.path / "wipe"
        self._text("wipe.md", "wipe me later", folder)
        report = self.doc_index.index(roots=[folder])
        self.assertTrue(report["ok"])
        self.assertGreater(self.doc_index.status()["files"], 0)
        self.doc_index.clear()
        self.assertEqual(self.doc_index.status()["files"], 0)
        self.assertEqual(self.doc_index.status()["chunks"], 0)


class DocRouteTests(unittest.TestCase):
    """The REAL voice path: phrase -> _doc_route -> local index -> spoken
    citation. This is the Phase 2.4 trigger ("JARVIS, search my documents for
    X"), exercised through the actual dispatcher, not a re-implementation."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = _TempRoot()
        cls.addClassCleanup(cls.tmp.cleanup)
        os.environ["JARVIS_DATA_ROOT"] = str(cls.tmp.path / "data")
        cls.corpus = cls.tmp.path / "corpus"
        cls.corpus.mkdir(parents=True, exist_ok=True)
        os.environ["JARVIS_DOC_ROOTS"] = str(cls.corpus)
        sys.path.insert(0, str(ROOT / "background"))
        for name in list(sys.modules):
            if (name in ("storage_paths",)
                    or name.startswith("jarvis_cowork_")):
                sys.modules.pop(name, None)
        cls.voice = _load_module("voice_engine_route",
                                 ROOT / "background" / "voice_engine.py")
        cls.replies = []

    def setUp(self):
        self.replies.clear()

    def _reply(self, text, **_):
        self.replies.append(text)

    def test_query_phrase_parsing(self):
        q = self.voice._doc_search_query
        self.assertEqual(
            q("JARVIS search my documents for battery health"),
            "battery health")
        self.assertEqual(
            q("mere documents me battery health dhundo"), "battery health")
        self.assertIn("warranty", q("search my notes for warranty details"))
        # NOT ours: the bridge's file search and plain web questions.
        self.assertIsNone(q("find report.pdf"))
        self.assertIsNone(q("search files for invoice"))
        self.assertIsNone(q("search the web for battery health"))
        self.assertIsNone(q("what is the weather"))

    def test_index_and_status_phrases_are_recognised(self):
        idx = self.voice._DOC_INDEX_RE
        self.assertTrue(idx.search("index my documents"))
        self.assertTrue(idx.search("reindex my documents"))
        self.assertTrue(idx.search("document index status"))
        self.assertTrue(idx.search("mere documents ka index karo"))
        self.assertFalse(idx.search("open my documents folder"))
        # A search sentence must not START an index run: it is answered as a
        # search (honest empty-store hint), never as an index command.
        doc = self.voice._doc_index_mod()
        doc.clear()
        self.replies.clear()
        handled = self.voice._doc_route(
            "search my documents for the index page", "x", self._reply)
        self.assertTrue(handled)
        self.assertIn("index nahi hue", self.replies[0])
        self.assertFalse(doc.index_running(), "search must not start an index")

    def test_roundtrip_index_then_search_speaks_a_citation(self):
        doc = self.voice._doc_index_mod()
        self.assertIsNotNone(doc)
        doc.clear()
        (self.corpus / "battery.md").write_text(
            "Laptop battery health measured at 92 percent capacity with 120 "
            "charge cycles on the pack.", encoding="utf-8")
        # 1) search before any index: honest, and names the trigger.
        handled = self.voice._doc_route(
            "jarvis search my documents for battery health",
            "jarvis search my documents for battery health", self._reply)
        self.assertTrue(handled)
        self.assertIn("index my documents", self.replies[0])
        # 2) index through the same voice path, wait for the real thread.
        handled = self.voice._doc_route("index my documents",
                                        "index my documents", self._reply)
        self.assertTrue(handled)
        deadline = time.time() + 90
        while doc.index_running() and time.time() < deadline:
            time.sleep(0.25)
        self.assertFalse(doc.index_running(), "index thread hung")
        self.assertGreaterEqual(doc.status()["files"], 1)
        # 3) the same search now cites the real file.
        self.replies.clear()
        handled = self.voice._doc_route(
            "jarvis search my documents for battery health",
            "jarvis search my documents for battery health", self._reply)
        self.assertTrue(handled)
        self.assertIn("battery.md", self.replies[0])
        # 4) status through voice reports real numbers, not a promise.
        self.replies.clear()
        self.voice._doc_route("document index status", "document index status",
                              self._reply)
        self.assertIn("1 files", self.replies[0])

    def test_unrelated_sentences_are_not_handled(self):
        for phrase in ("find report.pdf", "what is the weather",
                       "open notepad", "play music"):
            self.assertIsNone(
                self.voice._doc_route(phrase, phrase, self._reply), phrase)


if __name__ == "__main__":
    unittest.main()
