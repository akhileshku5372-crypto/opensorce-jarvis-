# Designing a voice‑first JARVIS that reproduces OpenClaw + Claude Cowork features

## Executive summary
This report synthesizes OpenClaw’s local-first agent runtime patterns and Anthropic’s Claude Cowork collaborative task model into a pragmatic design for a voice‑first JARVIS assistant with (a) a web dashboard/API and (b) a floating voice‑orb HUD + chat. The synthesis extracts a minimal set of primitives, maps them to runtime components and APIs, provides text architecture/sequence diagrams, identifies priorities and risks, sketches concrete API/channel adapter patterns, describes dashboard and HUD UI panels, and proposes an implementation checklist. Primary evidence is cited throughout. 

## High‑level comparison (OpenClaw vs Claude Cowork)
- OpenClaw: a TypeScript/Node.js, local‑first agent runtime and gateway that connects channels, agents, tools, sessions, model providers, and UIs; stores conversations, memory and skills as plain files in a workspace and provides a plugin/skill registry (ClawHub). It runs on user devices (Node.js 22+), supports channel adapters for WhatsApp/Telegram/Slack/Discord, and exposes a gateway API and WebSocket streams [1], [2], [3], [8].  
  [1], [2], [3], [8]

- Claude Cowork: a desktop‑focused, sandboxed multi‑step task runner that plans, decomposes tasks into subtasks/sub‑agents, enforces folder‑scoped permissions and VM isolation, and requires user approval for significant actions; Anthropic exposes Agents/Sessions/Skills APIs for managed agents and sessions in their platform [9], [11], [13], [10].  
  [9], [11], [13], [10]

Key synthesis: OpenClaw provides a flexible gateway + plugin model and local file‑based memory; Claude Cowork provides hardened sandboxing, a master agent loop with controlled sub‑agent branching and an explicit plan→execute→report workflow. These combine into an orchestrator that runs agent loops, invokes tools in sandboxes, and exposes multi‑participant sessions/workspaces.

## Minimal implementation primitives → runtime components, data models, state transitions, API endpoints
Primitives (minimal set): channels, sessions, tasks, scheduler/cron, skills/tools, memory, workspaces, sub‑agents, orchestrator.

Mapping (concise):
- Channels: channel adapters (Telegram/WhatsApp/Slack/Discord) implemented as inbound webhook handlers + outbound bot/webhook clients; map messages to channel session IDs like channel:telegram:user_id or channel:discord:channel_id [5]. Component: Channel Adapter Service; API: POST /v1/webhooks/{channel}.  
  [5]

- Sessions: Session object (id, workspace_id, participants, type: interactive|scheduled|subagent, sandbox_ref, created_at, timeout). Transition: created → active → idle → closed. Gateway exposes session methods (create, stream events, send message) analogous to OpenClaw Sessions API and Claude Sessions [8], [10].  
  [8], [10]

- Tasks & Sub‑agents: Task model (id, parent_task_id, plan, status: planned/running/waiting/succeeded/failed, artifacts, approvals). Orchestrator spawns sub‑agent sessions with shallow context (fresh context or inherited) and collects results; limit parallelism/depth per Claude master loop approach [11].  
  [11]

- Scheduler/Cron: Cron registry (cron_id, expr, tz, jitter, target_session/template). Each run creates a new session (stateless by default unless externalized storage used) as in Claude Code/OpenClaw cron patterns [12], [5].  
  [12], [5]

- Skills/Tools: Skill metadata (id, entrypoint, visibility scope: workspace/global, required_permissions). Tools executed in sandboxed runners (local container/VM) and surfaced through typed hook events (before_tool_call/after_tool_call) as in OpenClaw [4], [16].  
  [4], [16]

- Memory: Multi‑layer file memory (short/medium/long) implemented as Markdown files (MEMORY.md, daily logs), with optional consolidation (“Dreaming”) to long‑term files as OpenClaw does; permissions enforced by workspace/sandbox boundaries [6], [7], [17].  
  [6], [7], [17]

API endpoints (proposal inspired by OpenClaw/Claude):
- POST /v1/sessions — create session (body: workspace, participants, type)
- GET /v1/sessions/{id}/events/stream — SSE/ws event stream (messages, tool calls, status)
- POST /v1/sessions/{id}/messages — inbound user/channel message
- POST /v1/agents — register reusable agent config (bootstrap files)
- POST /v1/cron — register scheduled job (cron, session_template, jitter)
(Design draws from OpenClaw gateway endpoints and Claude Agents/Sessions API concepts.)  
  [8], [10]

## Architecture & sequence diagrams (text)
Orchestrator overview (ASCII):

Gateway/API
  │
  ├─ Channel Adapters (Slack/Discord/Telegram/WhatsApp) → Normalizer
  │
  └─ Orchestrator (Session manager, Scheduler, Skill loader, Tool sandbox pool)
        ├─ Model provider(s) (local or cloud)
        └─ Sandboxed Runners (VM/container for tools/sub‑agents)
  
Agent loop (sequence flow inspired by OpenClaw/Claude master loop):
1. Ingest message → assemble context (bootstrap files: AGENTS.md, SOUL.md, TOOLS.md, IDENTITY.md, USER.md injected)  
2. Model inference → parse tool_call or plan  
3a. If tool_call → before_tool_call hook → run tool in sandbox → after_tool_call → return results into context → loop  
3b. If plan with subtasks → spawn sub‑agent sessions (limited depth/parallelism) → collect results  
4. Stream output to session/channel; persist transcript and memory as configured  
(Step ordering follows OpenClaw agent loop and Claude single‑threaded master loop patterns.)  
  [4], [11], [7]

## Feature priorities, complexity & security implications
Must‑have
- Gateway with sessions/events streaming, channels adapters, local file workspace, skill loader, sandboxed tool execution. Complexity: medium; infra: Node.js runtime, Docker/VM sandbox pool; security: enforce workspace isolation and explicit approvals for destructive actions (OpenClaw local files + Claude folder‑scoped permissions model) [1], [9], [16].  
  [1], [9], [16]

Nice‑to‑have
- Fully managed cloud sessions/subagents, GUI plugin marketplace, deep multi‑tenant RBAC, native desktop VM sandboxing. Complexity: high; infra: managed containers/VMs, billing/quota controls; security: stricter isolation and network allow‑lists per Claude Cowork patterns [10], [13], [2].  
  [10], [13], [2]

Privacy/scaling notes: local file memory reduces cloud PII exposure (OpenClaw pattern) but cloud model calls still expose prompt data unless models are local; Claude Cowork uses VM and folder scoping for reduced risk. Rate limits and usage caps apply to managed agents and scheduled runs on cloud tiers [1], [9], [12].  
  [1], [9], [12]

## Channel adapters & session state syncing
Recommended pattern:
- Channel adapter receives webhook → normalize to internal Message schema → call POST /v1/sessions/{id}/messages → orchestrator assembles context and streams responses back via adapter webhook/bot. Use channel session IDs like channel:telegram:user_id for routing (OpenClaw uses these patterns) [5], [8]. Persist transcripts to workspace files and emit events on WebSocket for dashboard sync.  
  [5], [8]

Example webhook mapping endpoint (proposal):
- POST /webhook/telegram { channel_id, user_id, text, attachments } → internal POST /v1/sessions/{channel:telegram:user_id}/messages

## Web dashboard panels and voice‑orb HUD
Web dashboard panels (informed by OpenClaw playbook and Claude Cowork UI):
- Sessions list & live streams; Session inspector shows transcript, active tools, memory snippets, artifacts.  
- Workspaces & bootstrap files editor (SOUL.md, AGENTS.md, MEMORY.md).  
- Task list & Scheduler panel (cron registry, upcoming runs, jitter, run history).  
- Skills/Plugin manager (install from ClawHub-like registry).  
- Task‑state inspector (visual plan → subtasks → sub‑agent statuses).  
  [17], [2], [9]

Voice‑orb HUD + chat panel (design notes):
- Floating orb: wake word / touch to mute; minimal visual waveform + transcription; single-button push‑to‑speak fallback; display active task list with current task, ETA, approvals required. Provide explicit confirmations before destructive actions (Claude Cowork pattern). Support multimodal fallback to chat panel showing the plan and offering "delegate", "reschedule", "run now".  
  [9], [17]

Example multi‑step planning UI text snapshot (voice transcript → task state):
- User: "Prepare Q2 release notes and email stakeholders."  
- Agent (voice): "Plan: 1) draft notes, 2) summarize PRs, 3) prepare email — run subtasks 1–2 in parallel; approve sending?"  
- Buttons: Approve Send / Review Draft / Schedule 09:00 — UI shows sub‑agent statuses and artifacts as they complete.  
  [11], [9]

## Task/scheduler voice patterns & sample transcript
Design pattern: user intent → planner (generate explicit plan) → confirm (if actions require approvals) → spawn subtasks/sub‑agents → stream progress → finalize and persist artifacts. Scheduled jobs create new sessions per cron entry (stateless unless external persistence is used) [12].  

Sample short voice transcript:
- Wake → "JARVIS, schedule daily CI report at 08:00."  
- JARVIS: "Will run in workspace 'dev'. Create cron job 'daily-ci' with jitter ±5m? Say 'confirm' to create."  
- User: "Confirm." → Orchestrator registers cron → returns job id and next run time.  
  [12], [5]

## Pragmatic reference architecture & implementation plan
Reference stack (open source first path):
- Base: OpenClaw TypeScript gateway + skill loader; run via Docker Compose (OpenClaw repo provides compose and supports Node.js 22+) [1], [2], [18].  
- Sandboxing: containerized tool runners; for stronger isolation follow Claude Cowork VM/folder-permission approach for destructive operations [13].  
- Models: support local model hosts (Ollama-style local runner) or cloud APIs; gate network access for sandboxes.  
- Integrations: connect Anthropic Agents/Sessions APIs for managed agents or use local runtime for offline mode [10], [8].  
  [1], [2], [13], [10], [8], [18]

Milestones checklist (minimal):
1. Deploy gateway with sessions/messages API and WebSocket stream. [8]  
2. Implement channel adapters for Slack/Discord/Telegram/WhatsApp and session routing. [2], [5]  
3. Implement skill loader, bootstrap files, file‑based memory (short/medium/long). [7], [6]  
4. Implement sandboxed tool runner with before/after tool hooks and approval UI. [4], [16]  
5. Add scheduler/cron registry that creates sessions per run. [12]  
6. Build web dashboard panels and floating voice HUD with STT/TTS integration (local/cloud) and confirmation flows. [17], [9]  
7. Hardening: RBAC, workspace isolation, logging, rate limits, and privacy review. [13], [1]

## Evidence gaps
- Precise OpenClaw API request/response JSON schemas beyond endpoint names are not present in the findings; implementation must derive shapes from gateway docs or the repository. [8], [15]  
- Low‑level STT/TTS streaming, WebRTC or voice interruption semantics are not specified in the evidence and require design choices or additional sources.  
- Exact licensing/usage limits and cost details for managed Anthropic Managed Agents and cloud cron quotas vary by plan; only high‑level caps and pricing hints are present and may need vendor verification. [12], [10]

## References
[1] https://testmuai.com/blog/openclaw-github-repository
[2] https://clawtrust.ai/blog/openclaw-github-skills
[3] https://verdent.ai/guides/openclaw/architecture
[4] https://docs.openclaw.ai/concepts/agent-loop
[5] https://dench.com/blog/openclaw-session-management
[6] https://felo.ai/blog/openclaw-memory-management-guide
[7] https://arxiv.org/html/2604.14228v1
[8] https://fast.io/resources/openclaw-api-gateway-guide
[9] https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork
[10] https://platform.claude.com/docs/en/api/overview
[11] https://blog.promptlayer.com/claude-code-behind-the-scenes-of-the-master-agent-loop
[12] https://mindstudio.ai/blog/claude-code-cron-jobs-schedule-agents
[13] https://micheallanham.substack.com/p/claude-cowork-architecture-synthesis
[14] https://blink.new/blog/openclaw-api-guide-endpoints-integration-2026
[15] https://theagentstack.substack.com/p/openclaw-architecture-part-5-tools
[16] https://openclawplaybook.ai/guides
[17] https://github.com/centminmod/explain-openclaw