import JSZip from 'jszip';

/* The zip this UI came in had a "download the whole AI Studio project" button -
 * inside JARVIS that button would hand out somebody's demo source, not his
 * books. Same button, same call sites, honest job: it zips the Skill Library
 * itself (the shelf catalog, the license notes and the vendored MIT text).
 *
 * Everything it reads comes from JARVIS's own loopback endpoints, so nothing is
 * invented here: no shelf, no zip - and the reason comes back as the error.
 */

function triggerBlobDownload(blob: Blob, filename: string) {
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(blobUrl), 8000);
}

async function getJson(url: string): Promise<any> {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`${url} -> HTTP ${res.status}`);
  return res.json();
}

export async function downloadCompleteProjectZip(): Promise<void> {
  const shelf = await getJson('/api/library/shelf');
  const books: any[] = shelf.books || [];
  if (!books.length) {
    throw new Error('The shelf is empty - import a book first (skills/library/sources.json).');
  }

  const zip = new JSZip();
  zip.file('README.txt',
    'JARVIS Skill Library export\n' +
    `generated: ${new Date().toISOString()}\n` +
    `books: ${books.length}, chapters: ${books.reduce((n, b) => n + (b.chapters?.length || 0), 0)}\n\n` +
    'Every chapter keeps its license and attribution line. Public domain, CC and MIT\n' +
    'material stays credited - do not strip the LICENSE.txt files.\n');
  zip.file('shelf.json', JSON.stringify(shelf, null, 2));

  for (const book of books) {
    const dir = zip.folder(book.slug || 'untitled');
    if (!dir) continue;
    dir.file('book.json', JSON.stringify({
      title: book.title, author: book.author, stream: book.stream,
      level: book.level, license: book.license, attribution: book.attribution,
      source_url: book.source_url, chapters: (book.chapters || []).map((c: any) => c.title),
    }, null, 2));
    for (const chapter of book.chapters || []) {
      try {
        const part = await getJson(`/api/library/chapter?slug=${encodeURIComponent(book.slug)}&chapter=${encodeURIComponent(chapter.id || chapter.title)}`);
        dir.file(`${String(chapter.id || chapter.title).replace(/[^\w.-]/g, '_')}.md`,
          `# ${chapter.title}\n\n${part.text || ''}\n\n---\n${book.title} · ${book.author}\nLicense: ${book.license} · ${book.attribution || ''}\n`);
      } catch (err) {
        dir.file(`${String(chapter.id || chapter.title).replace(/[^\w.-]/g, '_')}.MISSING.txt`,
          `This chapter could not be read: ${String((err as Error).message)}\n`);
      }
    }
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  triggerBlobDownload(blob, `jarvis-skill-library-${new Date().toISOString().slice(0, 10)}.zip`);
}
