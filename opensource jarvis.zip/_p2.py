import pathlib, re
p=pathlib.Path("public/static/brain-holo.js")
s=p.read_text(encoding="utf-8")
old="    const W=Math.max(320,Math.round(wrap.getBoundingClientRect().width)||640);\n    const H=Math.max(300,Math.round(wrap.getBoundingClientRect().height)||520);"
new="    let _r=wrap.getBoundingClientRect();\n    let _w=Math.round(_r.width), _h=Math.round(_r.height);\n    if(_w<12) _w=wrap.clientWidth||wrap.offsetWidth||640;\n    if(_h<12) _h=wrap.clientHeight||wrap.offsetHeight||520;\n    const W=Math.max(320,_w||640);\n    const H=Math.max(520,_h||520);\n    try{ if(_h<200) wrap.style.minHeight='520px'; }catch{}"
if old in s:
    s=s.replace(old,new)
    print("p2 sizing patched")
else:
    print("p2 miss - attempting regex")
    s=re.sub(r"const W=Math\.max\(320,.*?520\);", new, s, flags=re.S)
    print("p2 regex done" if new[:20] in s else "still miss")
p.write_text(s,encoding="utf-8")
import pathlib as pl
dp=pl.Path("dist/static/brain-holo.js")
if dp.parent.exists():
    dp.write_text(s,encoding="utf-8")
print("len",len(s))
