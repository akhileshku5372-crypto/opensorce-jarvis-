"""Extension System: MCP / Skill / Plugin managers, permission engine,
tool-registry bridge, marketplace and the agent capability selector.

Stdlib + real local subsystems only. No network, no LLM, no app launch.
Every assertion runs against the SAME modules the voice engine uses, so a
pass here means the live integration works.
"""
import importlib.util
import json
import shutil
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def _load(name):
    """Load under the shared 'jarvis_cowork_' key used by cowork_tools.

    This matters: cortex.ToolSpec is checked with isinstance() inside
    ToolRegistry.register(), so a SECOND copy of the cortex module would make
    every plugin tool silently skip.
    """
    key = "jarvis_cowork_" + name
    spec = importlib.util.spec_from_file_location(
        key, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


EXT = _load("extensions")
PERMS = _load("permissions")
TOOLS = _load("cowork_tools")
CORTEX = TOOLS.cortex          # the SAME instance the registry validates against


class PermissionEngineTest(unittest.TestCase):
    def test_all_nine_categories_exist(self):
        for name in ("read_files", "edit_files", "execute_commands", "web_fetch",
                     "mcp", "browser", "computer_control", "communication",
                     "destructive"):
            self.assertIn(name, PERMS.CATEGORIES, name)

    def test_defaults_match_the_existing_safety_posture(self):
        """Assert the SHIPPED posture, not the user's current effective policy.

        `decision_for()` merges persisted overrides from extensions/
        permissions.json, so a user who legitimately relaxed `communication`
        to "auto" would otherwise fail this test. Read the declared defaults
        from CATEGORIES directly: that is the safety posture the product
        installs, and it is constant regardless of user state. The override
        layer itself is covered by test_overrides_persist_and_reject_invalid_input.
        """
        self.assertEqual(PERMS.CATEGORIES["read_files"]["default"], "auto")
        self.assertEqual(PERMS.CATEGORIES["destructive"]["default"], "deny")
        for gated in ("edit_files", "execute_commands", "mcp", "browser",
                      "computer_control", "communication"):
            self.assertEqual(PERMS.CATEGORIES[gated]["default"], "ask", gated)

    def test_ask_blocks_until_approved(self):
        blocked = PERMS.check("edit_files")
        self.assertFalse(blocked["allowed"])
        self.assertTrue(blocked["requires_approval"])
        self.assertTrue(PERMS.check("edit_files", approved=True)["allowed"])

    def test_deny_can_never_be_approved_away(self):
        """The single most important guarantee of the permission engine."""
        result = PERMS.check("destructive", approved=True)
        self.assertFalse(result["allowed"])
        self.assertEqual(result["decision"], "deny")

    def test_unknown_category_is_denied(self):
        self.assertEqual(PERMS.check("not_a_category")["decision"], "deny")
        self.assertFalse(PERMS.check("not_a_category")["allowed"])

    def test_overrides_persist_and_reject_invalid_input(self):
        original = PERMS.load()
        try:
            ok, _ = PERMS.save_overrides({"destructive": "ask"})
            self.assertTrue(ok)
            PERMS.load(force=True)
            self.assertEqual(PERMS.decision_for("destructive"), "ask")
            bad, message = PERMS.save_overrides({"destructive": "maybe"})
            self.assertFalse(bad)
            self.assertIn("invalid", message.lower())
            self.assertFalse(PERMS.save_overrides({"nope": "ask"})[0])
        finally:
            PERMS.save_overrides(original)
            PERMS.load(force=True)
        self.assertEqual(PERMS.decision_for("destructive"), "deny")

    def test_audit_records_every_decision(self):
        PERMS.check("read_files", tool="probe")
        self.assertTrue(PERMS.recent_audit(10))

    def test_policy_snapshot_shape(self):
        snap = PERMS.policy()
        self.assertEqual(len(snap["categories"]), len(PERMS.CATEGORIES))
        for row in snap["categories"]:
            self.assertIn(row["effective"], ("auto", "ask", "deny"))



class McpManagerTest(unittest.TestCase):
    """Real handshake against the configured stdio connectors."""

    def test_lists_configured_servers(self):
        rows = EXT.mcp_servers()
        self.assertTrue(rows, "no MCP servers discovered")
        names = {r["name"] for r in rows}
        self.assertIn("files", names)
        self.assertIn("system", names)

    def test_health_is_measured_not_guessed(self):
        for row in EXT.mcp_servers():
            self.assertIn("ok", row)
            self.assertIn("enabled", row)
            if not row.get("ok") and row.get("enabled"):
                self.assertTrue(row.get("error"), "offline server must say why")

    def test_tool_discovery_returns_real_tools(self):
        tools = EXT.mcp_tools("files", timeout=12.0)
        self.assertTrue(tools, "files connector exposed no tools")
        self.assertTrue(any("list" in str(t.get("name")) for t in tools))

    def test_call_without_approval_is_refused(self):
        result = EXT.mcp_call("files", "list_files", {}, approved=False)
        self.assertFalse(result["ok"])
        self.assertIn("approval", result["error"].lower())

    def test_register_rejects_a_non_allowlisted_command(self):
        ok, message = EXT.mcp_register("evil", "rm", description="nope")
        self.assertFalse(ok)
        self.assertIn("allowlisted", message.lower())

    def test_toggle_unknown_server_fails_honestly(self):
        self.assertFalse(EXT.mcp_set_enabled("no_such_server", True)[0])


class SkillManagerTest(unittest.TestCase):
    def test_real_skills_are_discovered(self):
        rows = EXT.skills()
        self.assertGreaterEqual(len(rows), 2)
        slugs = {r["slug"] for r in rows}
        self.assertIn("meeting-notes", slugs)
        self.assertIn("daily-briefing", slugs)

    def test_metadata_is_populated(self):
        for row in EXT.skills():
            self.assertTrue(row["name"])
            self.assertIsInstance(row["triggers"], list)
            self.assertGreater(row["size_bytes"], 0, row["name"])

    def test_skill_body_is_readable(self):
        self.assertTrue(EXT.skill_body("meeting-notes"))

    def test_trigger_matching_selects_the_right_skill(self):
        """'meeting notes' is a real trigger declared in skills/meeting-notes."""
        hits = EXT.skill_match("please make meeting notes from this")
        self.assertTrue(hits)
        self.assertEqual(hits[0]["name"], "meeting-notes")

    def test_disable_hides_a_skill_from_matching(self):
        EXT.set_enabled("skill", "meeting-notes", False)
        try:
            rows = {r["name"]: r for r in EXT.skills()}
            self.assertFalse(rows["meeting-notes"]["enabled"])
            self.assertEqual(EXT.skill_match("make meeting notes"), [])
        finally:
            EXT.set_enabled("skill", "meeting-notes", True)

    def test_remove_refuses_paths_outside_skills(self):
        self.assertFalse(EXT.skill_remove("../../../etc")[0])


class PluginManagerTest(unittest.TestCase):
    def test_shipped_plugin_is_discovered(self):
        rows = EXT.plugins()
        self.assertTrue(rows, "no plugins discovered")
        self.assertEqual(rows[0]["slug"], "ext-manager")
        self.assertTrue(rows[0]["entry_ok"])
        self.assertTrue(rows[0]["enabled"])

    def test_manifest_metadata(self):
        meta = EXT.plugins()[0]
        self.assertEqual(meta["version"], "1.0.0")
        self.assertEqual(meta["category"], "system")
        self.assertIn("list_extensions", meta["tools"])

    def test_health_check_really_imports_the_entry(self):
        report = EXT.plugin_health("ext-manager")
        self.assertTrue(report["ok"], report.get("error"))
        self.assertIn("list_extensions", report["tools"])

    def test_health_of_unknown_plugin_is_an_error(self):
        self.assertFalse(EXT.plugin_health("nope")["ok"])

    def test_plugin_exposes_a_tool_table(self):
        """A plugin declares TOOLS as a list of specs, each with a handler."""
        mod, err = EXT._import_plugin("ext-manager")
        self.assertEqual(err, "")
        table = getattr(mod, "TOOLS")
        self.assertIsInstance(table, list)
        self.assertTrue(table)
        for spec in table:
            self.assertIn("name", spec)
            self.assertIn("description", spec)
            self.assertTrue(callable(spec["handler"]), spec["name"])


class ToolRegistryBridgeTest(unittest.TestCase):
    """Every installed capability MUST reach the real ToolRegistry."""

    def setUp(self):
        self.registry = TOOLS.build_default_registry()

    def test_existing_tools_still_register(self):
        names = [t.name for t in self.registry.list()]
        self.assertGreaterEqual(len(names), 16)
        self.assertTrue(any(n.startswith("mcp_") for n in names))
        self.assertTrue(any(n.startswith("os_") for n in names))

    def test_plugin_tools_reach_the_registry(self):
        result = EXT.register_plugin_tools(self.registry)
        self.assertEqual(result["failed"], 0, result["errors"])
        self.assertGreaterEqual(result["registered"], 2, result)
        names = [t.name for t in self.registry.list()]
        self.assertIn("plug_ext_manager_list_extensions", names)
        self.assertIn("plug_ext_manager_extension_health", names)

    def test_plugin_tool_schemas_are_exposed_to_the_llm(self):
        EXT.register_plugin_tools(self.registry)
        spec = next(t for t in self.registry.list()
                    if t.name == "plug_ext_manager_list_extensions")
        self.assertIn("limit", spec.parameters)
        self.assertIn("plugin", spec.tags)
        self.assertTrue(spec.description)

    def test_plugin_tool_executes_for_real(self):
        EXT.register_plugin_tools(self.registry)
        out = self.registry.execute("plug_ext_manager_list_extensions", {})
        self.assertTrue(out["ok"], out.get("output"))
        self.assertIn("skills", out["output"])

    def test_disabled_plugin_registers_nothing(self):
        # Assert on THIS plugin's own tools. A blanket "no plug_* tools" check
        # would be wrong the moment a second plugin ships - the point of the
        # test is that disabling one plugin removes exactly its own tools.
        EXT.set_enabled("plugin", "ext-manager", False)
        try:
            reg = TOOLS.build_default_registry()
            EXT.register_plugin_tools(reg)
            self.assertEqual([t.name for t in reg.list()
                              if t.name.startswith("plug_ext_manager_")], [])
        finally:
            EXT.set_enabled("plugin", "ext-manager", True)

    def test_plugin_tool_respects_the_permission_engine(self):
        """A plugin tool in a denied category must not execute."""
        EXT.register_plugin_tools(self.registry)
        original = PERMS.load()
        try:
            PERMS.save_overrides({"read_files": "deny"})
            PERMS.load(force=True)
            out = self.registry.execute("plug_ext_manager_list_extensions", {})
            self.assertFalse(out["ok"])
            self.assertIn("denied", out["output"].lower())
        finally:
            PERMS.save_overrides(original)
            PERMS.load(force=True)


class MarketplaceTest(unittest.TestCase):
    def test_catalog_is_not_empty(self):
        self.assertGreaterEqual(len(EXT.marketplace()), 5)

    def test_every_item_points_at_something_real(self):
        for row in EXT.marketplace():
            self.assertIn(row["category"], ("mcp", "skills", "plugins"))
            self.assertIn(row["audience"], ("public", "personal", "recommended"))
            self.assertTrue(row["description"])

    def test_search_and_filter(self):
        self.assertTrue(EXT.marketplace(query="workspace"))
        self.assertTrue(all(r["category"] == "mcp"
                            for r in EXT.marketplace(category="mcp")))
        self.assertTrue(all(r["audience"] == "recommended"
                            for r in EXT.marketplace(audience="recommended")))

    def test_installed_flag_is_computed_live(self):
        rows = {r["id"]: r for r in EXT.marketplace()}
        self.assertTrue(rows["mcp-workspace"]["installed"])
        self.assertTrue(rows["skill-meeting-notes"]["installed"])

    def test_categories_exposed(self):
        self.assertEqual(EXT.marketplace_categories(), ["mcp", "plugins", "skills"])

    def test_unknown_item_install_fails_honestly(self):
        self.assertFalse(EXT.marketplace_install("no-such-item")[0])


class AgentCapabilityTest(unittest.TestCase):
    def test_capabilities_reflect_live_subsystems(self):
        counts = EXT.capabilities()["counts"]
        self.assertGreaterEqual(counts["mcp_total"], 1)
        self.assertGreaterEqual(counts["skills"], 1)
        self.assertGreaterEqual(counts["tools"], 16)

    def test_capability_selection_is_explainable(self):
        pick = EXT.select_capability("please make meeting notes from this")
        self.assertEqual(pick["kind"], "skill")
        self.assertEqual(pick["name"], "meeting-notes")
        self.assertTrue(pick["reason"])

    def test_selection_falls_back_instead_of_guessing(self):
        self.assertEqual(
            EXT.select_capability("zzzz qqqq unrelated gibberish")["kind"], "none")

    def test_snapshot_has_every_ui_section(self):
        snap = EXT.snapshot()
        for key in ("mcp", "skills", "plugins", "tools", "permissions",
                    "marketplace", "audit", "counts"):
            self.assertIn(key, snap)

    def test_snapshot_tool_list_includes_plugin_tools(self):
        """The UI tool list must be the SAME registry the agent can call.

        Regression: _tool_list() used build_default_registry() alone, so the
        dashboard advertised N tools while the planner could not see the two
        ext-manager tools, and toggling a plugin appeared to do nothing.
        """
        names = [t["name"] for t in EXT.snapshot()["tools"]]
        self.assertIn("plug_ext_manager_list_extensions", names)
        self.assertIn("plug_ext_manager_extension_health", names)

    def test_plugin_toggle_changes_the_advertised_tool_list(self):
        EXT.snapshot()                       # prime the tool-list cache
        EXT.set_enabled("plugin", "ext-manager", False)
        try:
            names = [t["name"] for t in EXT.snapshot()["tools"]]
            self.assertEqual([n for n in names
                              if n.startswith("plug_ext_manager_")], [])
        finally:
            EXT.set_enabled("plugin", "ext-manager", True)
        names = [t["name"] for t in EXT.snapshot()["tools"]]
        self.assertIn("plug_ext_manager_list_extensions", names)

    def test_snapshot_cache_is_fresh_and_invalidated(self):
        """Caching must never serve a stale tool list after a toggle."""
        EXT.snapshot()                       # prime the cache
        first = [t["name"] for t in EXT.snapshot()["tools"]]
        self.assertEqual(first, [t["name"] for t in EXT.snapshot()["tools"]])
        before = EXT.snapshot()["counts"]["plugins_enabled"]
        EXT.set_enabled("plugin", "ext-manager", False)
        try:
            # Exactly ONE plugin should be disabled by that toggle.
            self.assertEqual(EXT.snapshot()["counts"]["plugins_enabled"],
                             before - 1)
        finally:
            EXT.set_enabled("plugin", "ext-manager", True)
        self.assertEqual(EXT.snapshot()["counts"]["plugins_enabled"], before)

    def test_describe_is_a_spoken_summary(self):
        text = EXT.describe().lower()
        self.assertIn("extension", text)
        self.assertIn("tools", text)


class NoFakeIntegrationTest(unittest.TestCase):
    def test_a_broken_plugin_is_reported_not_faked(self):
        folder = EXT.PLUGIN_DIR / "broken-probe"
        folder.mkdir(parents=True, exist_ok=True)
        try:
            (folder / "plugin.json").write_text(json.dumps({
                "name": "Broken", "version": "1.0.0", "entry": "plugin.py"}),
                encoding="utf-8")
            (folder / "plugin.py").write_text("raise RuntimeError('boom')\n",
                                              encoding="utf-8")
            report = EXT.plugin_health("broken-probe")
            self.assertFalse(report["ok"])
            self.assertIn("import failed", report["error"])
            self.assertIn("broken-probe", {p["slug"] for p in EXT.plugins()})
        finally:
            EXT.plugin_remove("broken-probe")

    def test_install_rejects_sources_it_should_never_touch(self):
        """A missing folder, a bad name and a manifest-less folder all fail."""
        ok, message = EXT.plugin_install("does-not-exist")
        self.assertFalse(ok)
        self.assertIn("must be a folder", message)

        weird = EXT.PLUGIN_DIR / "!!"
        weird.mkdir(parents=True, exist_ok=True)
        try:
            ok, message = EXT.plugin_install(str(weird))
            self.assertFalse(ok)
            self.assertIn("invalid plugin folder name", message)
        finally:
            weird.rmdir()

        naked = EXT.PLUGIN_DIR.parent / "staging-naked-probe"
        naked.mkdir(parents=True, exist_ok=True)
        try:
            (naked / "plugin.py").write_text("TOOLS = []\n", encoding="utf-8")
            ok, message = EXT.plugin_install(str(naked))
            self.assertFalse(ok)
            self.assertIn("plugin.json", message)
        finally:
            shutil.rmtree(naked, ignore_errors=True)

    def test_install_round_trip_and_self_install_guard(self):
        """A real folder installs, appears in plugins(), and cannot self-copy."""
        staging = EXT.PLUGIN_DIR.parent / "_staging_probe"
        source = staging / "Probe Plugin"
        source.mkdir(parents=True, exist_ok=True)
        try:
            (source / "plugin.json").write_text(json.dumps({
                "name": "Probe", "version": "0.1.0", "entry": "plugin.py",
                "description": "test", "category": "test", "tools": ["probe"]}),
                encoding="utf-8")
            (source / "plugin.py").write_text("TOOLS = []\n", encoding="utf-8")
            ok, message = EXT.plugin_install(str(source))
            self.assertTrue(ok, message)
            slugs = {p["slug"] for p in EXT.plugins()}
            self.assertIn("probe-plugin", slugs)   # 'Probe Plugin' -> slug
            # Installing an already-installed plugin must refuse, not rmtree
            # the live copy onto itself.
            ok, message = EXT.plugin_install(str(EXT.PLUGIN_DIR / "probe-plugin"))
            self.assertFalse(ok)
            self.assertIn("already installed", message)
        finally:
            EXT.plugin_remove("probe-plugin")
            shutil.rmtree(staging, ignore_errors=True)

    def test_no_shell_is_ever_invoked(self):
        """Plugin execution goes through Python callables only."""
        source = (ROOT / "background" / "extensions.py").read_text(encoding="utf-8")
        for forbidden in ("subprocess.Popen", "os.system", "shell=True", "eval("):
            self.assertNotIn(forbidden, source, forbidden)


if __name__ == "__main__":
    unittest.main()
