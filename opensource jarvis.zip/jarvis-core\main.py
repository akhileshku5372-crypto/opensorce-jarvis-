"""Legacy entry point redirected to the canonical voice runtime."""
import runpy
from pathlib import Path

if __name__ == '__main__':
    runpy.run_path(str(Path(__file__).resolve().parents[1] / 'background' / 'voice_engine.py'), run_name='__main__')
