"""Resolve a spoken media request to ONE real file, and put it on the clipboard.

AGENTS.md rule: a path or a filename is never taken straight from raw speech.
The spoken words are only HINTS. The real path is resolved against the actual
filesystem - an existing folder, a containment check, a real non-empty file -
and only the resolved absolute path reaches the OS. The confirm sentence always
names the resolved file, so a wrong pick is visible before anything is sent.

Measured on this machine 2026-10-19 (WhatsApp Store app): a CF_HDROP file
pasted into the composer opens an attachment preview whose Button is literally
named "Open photo, <filename>, item 1 of 1", next to "Send 1 selected" and
"Remove attachment" buttons; invoke() on the send button sent the photo and the
chat-list row changed to "<time> Photo". Those are the signals
whatsapp_desktop.send_file requires before it claims anything.
"""
import os
import re
import struct
from pathlib import Path

# kind -> the extensions a file must have to be picked for that kind.
# "document" accepts any extension the folder holds.
MEDIA_KINDS = {
    "photo": (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".heic"),
    "video": (".mp4", ".mkv", ".mov", ".avi", ".webm", ".3gp", ".m4v"),
    "audio": (".mp3", ".wav", ".ogg", ".m4a", ".opus", ".aac", ".flac",
              ".wma", ".amr"),
    "document": None,
}

# The spoken folders a folder hint is looked up under (home first, then the
# known user folders). Nothing outside these roots is ever guessed.
FOLDER_ROOTS = ("Desktop", "Pictures", "Downloads", "Documents", "Videos")


def _home():
    return Path.home()


def default_folder():
    """Where 'photo bhejo' looks when no folder was named."""
    return _home() / "Desktop" / "JARVIS-Send"


def kind_of_word(word):
    """One spoken media word -> kind ('' when it is not a media word)."""
    w = str(word or "").strip(".,!?;:").casefold()
    if not w:
        return ""
    if w in ("photo", "photos", "pic", "pics", "picture", "pictures", "image",
             "images", "tasveer", "screenshot", "screenshots"):
        return "photo"
    if w in ("video", "videos"):
        return "video"
    if w in ("audio", "audios", "gana", "gaana", "song", "songs",
             "voice", "note"):
        return "audio"
    if w in ("file", "files", "document", "documents", "doc", "docs", "pdf"):
        return "document"
    return ""


def classify(path):
    """A real file -> the kind word used in the spoken reply."""
    ext = Path(str(path)).suffix.casefold()
    for kind, exts in MEDIA_KINDS.items():
        if exts and ext in exts:
            return kind
    return "document"


def resolve_folder(spoken):
    """Spoken folder hint -> (existing directory, '') or (None, reason).

    '' resolves to the default drop folder (created on demand, so "photo bhejo"
    works with no setup). A bare name is looked up as a direct subfolder of the
    home dir and the known roots (home first, then Desktop, Pictures,
    Downloads, Documents, Videos). A hint with separators is resolved directly.
    Everything is validated: no '..', no UNC, must be a real directory.
    """
    hint = str(spoken or "").strip().strip("\"'").strip().strip("\\/")
    if not hint:
        folder = default_folder()
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            return None, "default folder %s ban nahi paaya (%s)" % (folder,
                                                                    type(exc).__name__)
        return folder, ""
    if ".." in hint or hint.startswith("\\\\"):
        return None, "folder ka naam theek nahi hai"
    hint = os.path.expandvars(hint)
    if re.search(r"[\\/]", hint):
        hint = os.path.expanduser(hint)
        candidates = [Path(hint)]
    else:
        roots = [_home()] + [_home() / r for r in FOLDER_ROOTS]
        candidates = [root / hint for root in roots if (root / hint).is_dir()]
        if not candidates:
            return None, ("'%s' naam ka folder nahi mila (home, Desktop, Pictures, "
                          "Downloads, Documents, Videos me dhoondha)" % hint)
    folder = Path(candidates[0]).resolve()
    if not folder.is_dir():
        return None, "'%s' naam ka folder nahi mila" % hint
    return folder, ""


def resolve_file(spoken_name, folder, kind):
    """ONE real file from `folder`, or (None, reason).

    An empty name picks the NEWEST file whose extension matches `kind` (any
    file for 'document'). A spoken name is matched exactly first, then by
    stem, then by 'contains'; an ambiguous match is refused, never guessed.
    When a name is given and the kind disagrees with the file's real type, the
    mismatch is reported instead of silently sending something else.
    """
    try:
        folder = Path(folder).resolve()
    except Exception:
        return None, "folder padh nahi paaya"
    if not folder.is_dir():
        return None, "folder exist nahi karta"
    name = str(spoken_name or "").strip().strip("\"'").strip()
    if name:
        if ".." in name or re.search(r"[\\/]", name):
            return None, ("file ka naam theek nahi hai - sirf naam boliye, poora "
                          "path nahi")
    try:
        entries = sorted((p for p in folder.iterdir() if p.is_file()),
                         key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception as exc:
        return None, "folder ki list nahi khul paayi (%s)" % type(exc).__name__
    if not entries:
        return None, "'%s' folder khaali hai" % folder.name

    if name:
        want = name.casefold()
        exact = [p for p in entries if p.name.casefold() == want
                 or p.stem.casefold() == want]
        cands = exact or [p for p in entries if want in p.name.casefold()]
        if not cands:
            return None, "'%s' naam ki file '%s' me nahi mili" % (name,
                                                                  folder.name)
        if len(cands) > 1:
            shown = ", ".join(p.name for p in cands[:3])
            return None, ("'%s' se %d file mili (%s) - kaun si, poora naam boliye"
                          % (name, len(cands), shown))
        pick = cands[0]
        if kind and kind != "document" and classify(pick) != kind:
            return None, ("'%s' %s hai, %s nahi - jo sach me bhejna hai wo naam "
                          "boliye" % (pick.name, classify(pick), kind))
    else:
        exts = MEDIA_KINDS.get(kind)
        matching = ([p for p in entries if p.suffix.casefold() in exts]
                    if exts is not None else entries)
        if not matching:
            return None, "'%s' me koi %s nahi hai" % (folder.name,
                                                      kind or "file")
        pick = matching[0]

    try:
        pick = pick.resolve()
    except Exception:
        return None, "file ka path resolve nahi hua"
    if os.path.commonpath([str(folder), str(pick)]) != str(folder):
        return None, "file folder ke bahar resolve hui - refuse kiya"
    if not pick.is_file() or pick.stat().st_size <= 0:
        return None, "file khaali ya padhi nahi ja sakti - kuch nahi bheja"
    return pick, ""


def hdrop_bytes(path):
    """CF_HDROP payload for exactly one file (DROPFILES header, wide chars)."""
    payload = (str(path) + "\0\0").encode("utf-16-le")
    return struct.pack("IiiII", 20, 0, 0, 0, 1) + payload


def copy_file(path):
    """Put ONE real file on the clipboard as CF_HDROP. False = it failed."""
    p = Path(str(path))
    if not p.is_file():
        return False
    try:
        import win32clipboard
        import win32con
    except Exception:
        return False
    try:
        win32clipboard.OpenClipboard()
        try:
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32con.CF_HDROP, hdrop_bytes(p))
        finally:
            win32clipboard.CloseClipboard()
        return True
    except Exception:
        return False
