import os, json, requests
for line in open(".env", encoding="utf-8"):
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())
try:
    r = requests.get("https://integrate.api.nvidia.com/v1/models",
                     headers={"Authorization": "Bearer " + os.environ.get("NVIDIA_API_KEY", "")},
                     timeout=25)
    data = r.json().get("data", [])
    ids = [m.get("id", "") for m in data]
    print("NVIDIA models list status:", r.status_code, "count:", len(ids))
    print(json.dumps(ids[:60], indent=0))
except Exception as e:
    print("nvidia models error:", e)
