"""P0 power isolation + sleep/wake gates + co-work meta-routes.

Stdlib only — no mic, no TTS, no network. Locks in two live bugs that were
found and fixed:
  * laptop power verbs ("laptop band karo", "system band karo") slipped past
    power_guard and reached the LLM brain / the bridge shutdown route;
  * the documented wake phrases ("uth jao", "उठ जाओ", "band ho jao",
    "sleep mode off", "stop sleeping") could never wake a deep-sleeping JARVIS.

Run:  npm run test:power
"""
import importlib.util
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "voice_engine", ROOT / "background" / "voice_engine.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load_engine()


class WakeGateTest(unittest.TestCase):
    STRICT = ["wake up", "hey jarvis wake up", "get up", "uth jao", "jag jao",
              "उठो", "उठ जाओ", "जाग जाओ", "जार्विस उठ जाओ", "起きて"]
    EXIT = ["band ho jao", "बंद हो जाओ", "sleep mode off", "sleep mode band",
            "stop sleeping", "जाग उठ"]
    NOISE = ["wake up the music player", "the baby will wake up soon tonight",
             "band ho jao na please bhai abhi karo", "उठाना मेरा बैग",
             "sleep mode karo"]

    def _strip(self, phrase):
        return ENGINE.strip_wake(phrase).strip(" .,!?:;।。、")

    def test_strict_wake_phrases(self):
        for phrase in self.STRICT:
            with self.subTest(phrase=phrase):
                self.assertTrue(ENGINE._is_wake_phrase(self._strip(phrase)))

    def test_sleep_exit_phrases(self):
        for phrase in self.EXIT:
            with self.subTest(phrase=phrase):
                self.assertTrue(ENGINE._sleep_exit_phrase(self._strip(phrase)))

    def test_noise_never_wakes(self):
        for phrase in self.NOISE:
            stripped = self._strip(phrase)
            with self.subTest(phrase=phrase):
                self.assertFalse(ENGINE._is_wake_phrase(stripped))
                self.assertFalse(ENGINE._sleep_exit_phrase(stripped))


class PowerIsolationTest(unittest.TestCase):
    DENIED = ["shutdown", "shut down", "power off", "restart", "reboot",
              "hibernate", "log off", "shutdown karo", "restart karo",
              "laptop band karo", "system band karo", "laptop band",
              "put my laptop to sleep", "laptop so jao"]
    ALLOWED = ["restart chrome", "close chrome", "laptop band ho gaya",
               "gaana band karo", "open notepad"]

    def test_machine_power_is_denied(self):
        for command in self.DENIED:
            with self.subTest(command=command):
                blocked, reason = ENGINE.power_guard(command)
                self.assertTrue(blocked, "%r must be denied" % command)
                self.assertIn(reason, ("os-power", "laptop-sleep"))

    def test_app_targets_and_reports_stay_allowed(self):
        for command in self.ALLOWED:
            with self.subTest(command=command):
                blocked, reason = ENGINE.power_guard(command)
                self.assertFalse(blocked, "%r must stay allowed (%s)" % (command, reason))


class MetaRouteTest(unittest.TestCase):
    """run_command must answer status / co-work / skills locally and must never
    put JARVIS to sleep on a power verb."""

    ROUTES = [("status", "status"), ("kya haal hai", "status"),
              ("cowork", "co-work"), ("team", "channels"),
              ("task list", "co-work"), ("skills", "skills"),
              ("kya kya skills", "skills")]
    POWER = ["shutdown", "restart", "laptop band karo", "laptop so jao"]

    def setUp(self):
        self.spoken = []
        self.sleep_calls = []
        self._real_speak = ENGINE.speak
        self._real_enter = ENGINE.enter_sleep
        self._real_exit = ENGINE.exit_sleep
        ENGINE.speak = lambda message, ui=None: self.spoken.append(str(message))
        ENGINE.enter_sleep = lambda seconds=0.0, ui=None: self.sleep_calls.append(seconds)
        ENGINE.exit_sleep = lambda ui=None, announce=True: self.sleep_calls.append(0.0)
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real_speak
        ENGINE.enter_sleep = self._real_enter
        ENGINE.exit_sleep = self._real_exit

    def _route(self, text):
        self.spoken.clear()
        self.sleep_calls.clear()
        # Repeat cooldown and burst lockout are correct product behaviour, but
        # inside one test process they would hide the reply we assert on.
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, list(self.spoken), list(self.sleep_calls)

    def test_meta_routes_answer_locally(self):
        for command, expected in self.ROUTES:
            with self.subTest(command=command):
                handled, said, slept = self._route(command)
                self.assertTrue(handled)
                self.assertFalse(slept, "meta-route slept on %r" % command)
                self.assertTrue(said, "no reply for %r" % command)
                self.assertIn(expected, " ".join(said).lower())

    def test_power_verbs_never_sleep(self):
        for command in self.POWER:
            with self.subTest(command=command):
                handled, said, slept = self._route(command)
                self.assertTrue(handled)
                self.assertFalse(slept, "POWER LEAK: %r -> %r" % (command, slept))
                self.assertIn("block", " ".join(said).lower())

    def test_reports_read_real_state(self):
        cowork = ENGINE._cowork_list_tasks().lower()
        self.assertIn("co-work", cowork)
        self.assertIn("channels", cowork)
        self.assertIn("scheduled", cowork)
        skills = ENGINE._skills_report().lower()
        self.assertIn("skills", skills)
        self.assertIn("notes", skills)


class ScriptIntegrityTest(unittest.TestCase):
    """cp1252 mojibake made whole language branches silently unmatchable.

    Live 2026-10-18: the Cyrillic address never woke JARVIS, because the source
    literal was "джарви" + "Ñ" + U+0081. The second byte of a mis-decoded "с"
    came back as an INVISIBLE C1 control, so the regex could not match any real
    STT output and nothing in the repo looked broken. Greek and the two
    repaired Arabic spellings in strip_wake were dead the same way.
    """

    CYRILLIC = ["\u0434\u0436\u0430\u0440\u0432\u0438\u0441",
                "\u0434\u0436\u0430\u0440\u0432\u0456\u0441",
                "\u0434\u0436\u0430\u0301\u0440\u0432\u0438\u0441"]
    GREEK = ["\u03C4\u03B6\u03AC\u03C1\u03B2\u03B9\u03C2",
             "\u03C4\u03B6\u03B1\u03C1\u03B2\u03B9\u03C2"]
    ARABIC = ["\u062C\u0627\u0631\u0641\u064A\u0633",
              "\u062C\u0627\u0631\u0641\u06CC\u0633"]

    def test_cyrillic_and_greek_addresses_are_a_wake(self):
        for address in self.CYRILLIC + self.GREEK:
            with self.subTest(address=address):
                self.assertTrue(ENGINE._MULTI_WAKE_SCRIPT_RE.search(address),
                                "%r is absent from the multilingual wake "
                                "pattern - that language branch is dead"
                                % address)
                # wake_phrase is the live mic gate that owns the pattern.
                # _is_wake_phrase is the narrow deep-sleep exit gate and is
                # deliberately English/Hindi/Japanese only - do not widen it.
                self.assertTrue(ENGINE.wake_phrase(address + " open notepad"))

    def test_addressless_blocked_script_still_never_wakes(self):
        """Counterweight: repairing a literal must not turn foreign TV
        noise into a wake. No address in the utterance -> no wake."""
        for noise in ("\u043f\u0440\u0438\u0432\u0435\u0442 \u043a\u0430\u043a \u0434\u0435\u043b\u0430",
                      "\u03b3\u03b5\u03b9\u03b1 \u03c3\u03bf\u03c5 \u03c4\u03b9 \u03ba\u03b1\u03bd\u03b5\u03b9\u03c2",
                      "\u043f\u0440\u0438\u0432\u0456\u0442 \u044f\u043a \u0441\u043f\u0440\u0430\u0432\u0438",
                      "\u0645\u0631\u062d\u0628\u0627 \u0643\u064a\u0641 \u062d\u0627\u0644\u0643"):
            with self.subTest(noise=noise):
                self.assertFalse(ENGINE.wake_phrase(noise))

    def test_arabic_address_is_stripped_not_executed(self):
        for address in self.ARABIC:
            with self.subTest(address=address):
                self.assertEqual(ENGINE.strip_wake(address + " open notepad"),
                                 "open notepad")

    def test_source_carries_no_mojibake_signature(self):
        """Two signatures: an invisible C1 control, or a 2+ Latin-1 run.

        Both were present for an unknown period and every gate stayed green,
        because a mangled regex is still a valid regex - it just matches
        nothing. Scanning the source is the only check that can catch it.
        """
        roots = [ROOT / "background", ROOT / "src"]
        files = [ROOT / "public" / "static" / "app.js"]
        for folder in roots:
            files.extend(p for p in sorted(folder.rglob("*"))
                         if p.suffix in (".py", ".pyw", ".ts", ".tsx")
                         and "__pycache__" not in p.parts)
        pattern = re.compile(r"[\u0080-\u009F]|[\u00C2-\u00FF]{2,}")
        checked = 0
        for path in files:
            text = path.read_text(encoding="utf-8", errors="replace")
            checked += 1
            hit = pattern.search(text)
            self.assertIsNone(
                hit, "%s is cp1252-mangled at offset %s (%r)"
                % (path.relative_to(ROOT).as_posix(), hit and hit.start(),
                   hit and hit.group()))
        self.assertGreater(checked, 40, "the scan silently stopped finding files")

if __name__ == "__main__":
    unittest.main(verbosity=2)
