"""One configurable root for ALL persistent JARVIS + KamiSensei data.

Why this module exists
----------------------
Before this, persistent data was scattered across hardcoded paths in a dozen
modules: ``chroma_db/`` in the repo, ``backend/kamisensei_db.json``,
``notebooks/``, and browser IndexedDB. Moving all of that to D: by editing each
call site would be error-prone and easy to regress, so every module resolves its
path through here instead.

Layout (under ``JARVIS_DATA_ROOT``, default ``D:\\JARVIS_DATA``)::

    D:\\JARVIS_DATA
      jarvis\\conversations.db      conversation history (SQLite)
      jarvis\\memory\\              ChromaDB - collection `jarvis_memory`
      jarvis\\docs\\                ChromaDB - collection `jarvis_documents` (Phase 2 RAG)
      jarvis\\apps\\                DPAPI-encrypted OAuth tokens (Phase 4 Gmail/Calendar)
      jarvis\\artifacts\\           agent/cortex/scheduler runtime state
      kamisensei\\conversations.db  KamiSensei conversation history (SQLite)
      kamisensei\\memory\\           ChromaDB - collection `kami_sensei_memory`
      kamisensei\\rag\\              ChromaDB - collection `kami_sensei_knowledge`
      kamisensei\\sources.json       extracted YouTube/link sources
      kamisensei\\notebooks\\        notebook descriptors

Two rules this module enforces:

1. **Never lose data.** If the configured root is unusable (missing drive,
   permission error, full disk) we fall back to the legacy in-repo location and
   say so through :func:`status`. Silently writing new data to a second place is
   how stores split and "disappear"; a loud fallback does not.
2. **Never raise on import.** Directory creation is lazy and failure-tolerant so
   a bad D: cannot stop the voice core from booting.

Env override: ``JARVIS_DATA_ROOT`` (any path). Tests set it to a temp dir.
"""

from __future__ import annotations

import os
from pathlib import Path

DEFAULT_ROOT = r"D:\JARVIS_DATA"
ROOT_ENV = "JARVIS_DATA_ROOT"

# ── Storage ceiling ────────────────────────────────────────────────────────
# JARVIS itself sets NO cap on how many memories or conversations it stores.
# Without a ceiling the only limit is the disk itself, and a runaway RAG
# ingest or a runaway chat loop can silently fill the drive. 10 GB is generous
# for text memory (roughly millions of facts) while still leaving the rest of
# D: untouched. Override with JARVIS_DATA_MAX_GB (0 disables the ceiling).
MAX_BYTES_ENV = "JARVIS_DATA_MAX_GB"
DEFAULT_MAX_GB = 10.0
_WARN_RATIO = 0.90

#: Repo root, used only for the legacy fallback location.
REPO = Path(__file__).resolve().parent.parent

_STATE = {"root": None, "fallback": None}


def _legacy_root() -> Path:
    return REPO


def _usable(path: Path) -> bool:
    """True when `path` exists (or can be created) and is writable."""
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".jarvis_write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:
        return False


def data_root() -> Path:
    """Resolved data root, created on first use.

    Cached after the first successful call so repeated module-level lookups do
    not re-probe the filesystem on every request.
    """
    if _STATE["root"] is not None:
        return _STATE["root"]

    configured = os.environ.get(ROOT_ENV) or DEFAULT_ROOT
    candidate = Path(configured)
    if _usable(candidate):
        _STATE["root"] = candidate
        _STATE["fallback"] = None
        return candidate

    # Do not raise. Fall back to the legacy in-repo location so the app keeps
    # working and keeps reading whatever data is already there.
    legacy = _legacy_root()
    _STATE["root"] = legacy
    _STATE["fallback"] = str(candidate)
    return legacy


def sub(*parts: str) -> Path:
    """A subdirectory of the data root, e.g. ``sub('jarvis', 'memory')``."""
    path = data_root().joinpath(*parts)
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def file_path(*parts: str) -> Path:
    """A file inside the data root, ensuring its parent directory exists."""
    path = data_root().joinpath(*parts)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def using_fallback() -> bool:
    return bool(_STATE["fallback"])


# ── Size accounting ───────────────────────────────────────────────────────
_USAGE_CACHE = {"at": 0.0, "bytes": None}


def max_bytes() -> int:
    """Ceiling for the whole data root. 0 means "no ceiling configured"."""
    raw = os.environ.get(MAX_BYTES_ENV)
    if raw is None or str(raw).strip() == "":
        return int(DEFAULT_MAX_GB * (1024 ** 3))
    try:
        gb = float(str(raw).strip())
    except (TypeError, ValueError):
        return int(DEFAULT_MAX_GB * (1024 ** 3))
    if gb <= 0:            # explicit opt-out
        return 0
    return int(gb * (1024 ** 3))


def usage_bytes(max_age=5.0) -> int:
    """Total bytes under the data root.

    Cached briefly: a directory walk hits every RAG segment file, and callers
    ask for this on every write. A few seconds of staleness is harmless for a
    quota check and avoids a multi-thousand-file walk per message.
    """
    import time
    now = time.monotonic()
    if (_USAGE_CACHE["bytes"] is not None
            and (now - _USAGE_CACHE["at"]) < max_age):
        return _USAGE_CACHE["bytes"]
    total = 0
    try:
        for path in data_root().rglob("*"):
            try:
                if path.is_file():
                    total += path.stat().st_size
            except OSError:
                continue
    except Exception:
        return _USAGE_CACHE["bytes"] or 0
    _USAGE_CACHE.update({"at": now, "bytes": total})
    return total


def over_quota(incoming=0) -> bool:
    """True when `incoming` more bytes would push us past the ceiling."""
    cap = max_bytes()
    if cap <= 0:
        return False
    return (usage_bytes() + max(0, int(incoming))) > cap


def guard_write(nbytes: int) -> bool:
    """Refuse a write that would exceed the ceiling. True == allowed.

    Callers use this to fail loudly and skip the write rather than filling the
    disk. Not raising keeps a full quota from taking down the voice core.
    """
    return not over_quota(nbytes)


def quota_status() -> dict:
    """Honest usage report for the UI and the tests."""
    cap = max_bytes()
    used = usage_bytes(max_age=0.0)   # force fresh for an explicit report
    out = {
        "root": str(data_root()),
        "used_bytes": used,
        "used_mb": round(used / (1024 ** 2), 2),
        "max_bytes": cap,
        "max_gb": round(cap / (1024 ** 3), 2) if cap else 0,
        "unlimited": cap <= 0,
        "over_quota": bool(cap) and used > cap,
    }
    if cap:
        out["percent"] = round(used * 100.0 / cap, 2)
        out["free_bytes"] = max(0, cap - used)
        out["warning"] = used >= cap * _WARN_RATIO
    return out


def status() -> dict:
    """Honest report of where data actually lives right now."""
    root = data_root()
    info = {"root": str(root), "configured": os.environ.get(ROOT_ENV) or DEFAULT_ROOT,
            "fallback": _STATE["fallback"], "ok": True, "writable": True}
    try:
        root.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        info["ok"] = False
        info["writable"] = False
        info["error"] = "%s: %s" % (type(exc).__name__, exc)
    # Usage + ceiling travel with the location report so the existing
    # /conversations/storage endpoint answers both questions at once.
    try:
        info.update(quota_status())
    except Exception:
        pass
    return info


# ── Named locations used across the codebase ────────────────────────────────
def jarvis_db() -> Path:
    """JARVIS conversation history (SQLite)."""
    return file_path("jarvis", "conversations.db")


def kamisensei_db() -> Path:
    """KamiSensei conversation history (SQLite)."""
    return file_path("kamisensei", "conversations.db")


def jarvis_memory_dir() -> Path:
    """ChromaDB dir holding ONLY the `jarvis_memory` collection."""
    return sub("jarvis", "memory")


def jarvis_docs_dir() -> Path:
    """ChromaDB + manifest dir for the Phase 2 document RAG store.

    Its own directory (not shared with `jarvis_memory`) so the document index
    can be wiped and rebuilt without touching learned memories.
    """
    return sub("jarvis", "docs")


def jarvis_apps_dir() -> Path:
    """DPAPI-encrypted OAuth token store (Phase 4 Gmail/Calendar).

    Separate from `jarvis_docs_dir` so wiping the document index can never take
    an authorization with it, and separate from the memory store so a token is
    never mixed into a ChromaDB directory.
    """
    return sub("jarvis", "apps")


def kamisensei_memory_dir() -> Path:
    """ChromaDB dir holding the KamiSensei user-memory collection."""
    return sub("kamisensei", "memory")


def kamisensei_rag_dir() -> Path:
    """ChromaDB dir holding ONLY `kami_sensei_knowledge` (the RAG corpus).

    Kept separate from the user-memory dir so the two namespaces stay
    physically separate, not just logically separate by collection name.
    """
    return sub("kamisensei", "rag")


def kamisensei_sources() -> Path:
    return file_path("kamisensei", "sources.json")


def kamisensei_notebooks() -> Path:
    return sub("kamisensei", "notebooks")


def jarvis_artifacts() -> Path:
    return sub("jarvis", "artifacts")