"""Self-learning P3: routine learner - JARVIS learns task->tool recipes from
REAL completed work and reuses them as prompt knowledge.

Contract: the same funnel that scores tools also feeds this learner; only
genuinely confirmed outcomes teach; three consecutive real failures retire a
recipe never to return; the store is on-device, bounded and atomic; and every
failure here is strictly additive to runtime behaviour.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


# Every test run targets a THROWAWAY ledger/recipes store - the owner's live
# artifacts/brain/*.json must never be written or wiped by a test process.
import os as _os, tempfile as _tempfile
_os.environ.setdefault("JARVIS_RESULTS_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_results.json"))
_os.environ.setdefault("JARVIS_ROUTINES_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_routines.json"))


def _load(name, sub="background"):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / sub / ("%s.py" % name))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ROUTINES = _load("routines")
RESULTS = _load("results")
ENGINE = _load("voice_engine")

RESULTS.purge()
ROUTINES.purge()
ENGINE._WA_PENDING.clear()
ENGINE._WA_MEDIA_PENDING.clear()
ENGINE._WA_MSG_ASK.clear()
ENGINE._WA_LAST_TEXT.clear()

TASK = "waiting room ki light off karo"


class RoutineLearnTest(unittest.TestCase):
    def setUp(self):
        RESULTS.purge()
        ROUTINES.purge()
        self.addCleanup(ROUTINES.purge)
        self.addCleanup(RESULTS.purge)
        self.addCleanup(RESULTS.saw_task, "")   # forget the phrase after

    def test_a_confirmed_success_builds_a_recipe(self):
        for _ in range(2):
            RESULTS.record("hotel_wait_off", True, task=TASK)
        hit = ROUTINES.best(TASK)
        self.assertIsNotNone(hit)
        self.assertEqual(hit[1]["tool"], "hotel_wait_off")
        self.assertEqual(hit[1]["ok"], 2)

    def test_a_failure_does_not_teach_and_three_retire(self):
        RESULTS.record("hotel_wait_off", False, "not found", task=TASK)
        self.assertIsNone(ROUTINES.best(TASK))
        for _ in range(3):
            RESULTS.record("hotel_wait_off", True, task=TASK)
        RESULTS.record("hotel_wait_off", False, "gone", task=TASK)
        RESULTS.record("hotel_wait_off", False, "gone", task=TASK)
        RESULTS.record("hotel_wait_off", False, "gone", task=TASK)
        self.assertIsNone(ROUTINES.best(TASK), "a dead recipe must retire")

    def test_denied_runs_are_not_teaching_material(self):
        RESULTS.record("gui_type_into", False, denied=True, task=TASK)
        self.assertIsNone(ROUTINES.best(TASK))

    def test_different_phrasing_of_the_same_task_is_recalled(self):
        RESULTS.record("hotel_wait_off", True, task=TASK)
        hit = ROUTINES.best("Sir, waiting room wali light ko off kardo please")
        self.assertIsNotNone(hit, "token-overlap must bridge paraphrases")
        self.assertEqual(hit[1]["tool"], "hotel_wait_off")

    def test_two_different_tasks_never_merge(self):
        RESULTS.record("hotel_wait_off", True, task=TASK)
        self.assertFalse(ROUTINES.best("youtube pe lullaby song chalao"))

    def test_prompt_line_names_the_recipe_with_runs(self):
        RESULTS.record("hotel_wait_off", True, task=TASK)
        RESULTS.record("hotel_wait_off", True, task=TASK)
        line = ROUTINES.prompt_line()
        self.assertIn("hotel_wait_off", line)
        self.assertIn("2x sahi", line)
        self.assertIn("waiting room", line)

    def test_prompt_line_is_empty_until_work_happened(self):
        self.assertEqual(ROUTINES.prompt_line(), "")

    def test_store_is_bounded(self):
        for i in range(200):
            ROUTINES.observe("naya kaam number %d kro" % i, "tool_%d" % i, True)
        data = ROUTINES._load()
        self.assertLessEqual(len(data.get("recipes") or {}), 120)

    def test_observe_alone_is_exception_safe(self):
        key, changed = ROUTINES.observe("", "tool_x", True)
        self.assertEqual(key, "")
        self.assertFalse(changed)


class FunnelWiringTest(unittest.TestCase):
    def setUp(self):
        RESULTS.purge()
        ROUTINES.purge()
        self.addCleanup(ROUTINES.purge)
        self.addCleanup(RESULTS.purge)
        self.addCleanup(RESULTS.saw_task, "")

    def test_voice_run_command_registers_the_task_for_the_funnel(self):
        # The route hook must be wired exactly where real commands enter, so
        # every action completed under this utterance lands behind its phrase.
        RESULTS.saw_task("notepad kholo aur likhna shuru karo")
        RESULTS.record("notepad_open", True, "opened")
        hit = ROUTINES.best("notepad kholo aur likhna shuru karo")
        self.assertIsNotNone(hit)
        self.assertEqual(hit[1]["tool"], "notepad_open")


class RecipeRouteTest(unittest.TestCase):
    """'kya kaam sikhe' reads the learned cookbook back."""

    def setUp(self):
        self.spoken = []
        self.agent = unittest.mock.MagicMock()
        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: None
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        RESULTS.purge()
        ROUTINES.purge()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        RESULTS.purge()
        ROUTINES.purge()
        RESULTS.saw_task("")

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_readback_lists_learned_recipes(self):
        ROUTINES.observe("waiting room off karo", "hotel_wait_off", True)
        handled, said = self._route("kya kaam sikhe tune")
        self.assertTrue(handled)
        self.assertIn("hotel_wait_off", said)
        self.assertIn("waiting room off karo", said)

    def test_empty_cookbook_is_honest(self):
        handled, said = self._route("kya kaam sikhe tune")
        self.assertTrue(handled)
        self.assertIn("naya kaam nahi seekha", said)

    def test_screen_task_route_teaches_a_real_recipe(self):
        self.agent.has_pending.return_value = False
        self.agent.screen_task.return_value = "Sir, 'notepad' launch ho gaya."
        handled, said = self._route("screen task open notepad")
        self.assertTrue(handled)
        self.assertIn("launch", said)
        self.assertEqual(RESULTS.stats("screen_task")["status"], "working")
        hit = ROUTINES.best("screen task open notepad")
        self.assertIsNotNone(hit)
        self.assertEqual(hit[1]["tool"], "screen_task")


class ScreenOutcomeTest(unittest.TestCase):
    """Direct screen-agent work is now part of the same P2/P3 funnel."""

    def setUp(self):
        RESULTS.purge()
        ROUTINES.purge()
        ENGINE._screen_pending_task_clear()
        RESULTS.saw_task(TASK)
        self.addCleanup(ROUTINES.purge)
        self.addCleanup(RESULTS.purge)
        self.addCleanup(ENGINE._screen_pending_task_clear)
        self.addCleanup(RESULTS.saw_task, "")

    def test_a_staged_confirmation_is_not_scored_as_an_outcome(self):
        class Agent:
            def has_pending(self):
                return True

            def screen_task(self, *a):
                return 'Sir, "close notepad" destructive action hai. Boliye "confirm".'

        ENGINE._screen_task_recorded(Agent(), "close notepad", None, "en")
        self.assertEqual(RESULTS.stats("screen_task")["status"], "idle")

    def test_a_real_failure_is_scored_as_a_failure(self):
        class Agent:
            def has_pending(self):
                return False

            def screen_task(self, *a):
                return "Sir, click target missing tha, ruk gaya."

        ENGINE._screen_task_recorded(Agent(), "click Save", None, "en")
        self.assertEqual(RESULTS.stats("screen_task")["status"], "broken")

    def test_a_confirmed_action_teaches_its_own_outcome(self):
        class Agent:
            def __init__(self):
                self.pending = True

            def has_pending(self):
                return self.pending

            def screen_task(self, *a):
                return ("Sir, screen pe 'Search' pe click karna hai. "
                        'Boliye "confirm" to click karunga.')

            def confirm_pending(self):
                self.pending = False
                return "clicked at (120, 240)."

        agent = Agent()
        ENGINE._screen_task_recorded(agent, "click Search", None, "en")
        self.assertEqual(RESULTS.stats("screen_task")["status"], "idle")
        ENGINE._screen_confirm_recorded(agent)
        self.assertEqual(RESULTS.stats("screen_action")["status"], "working")
        hit = ROUTINES.best(TASK)
        self.assertIsNotNone(hit)
        self.assertEqual(hit[1]["tool"], "screen_action")


import unittest.mock  # noqa: E402

if __name__ == "__main__":
    unittest.main()
