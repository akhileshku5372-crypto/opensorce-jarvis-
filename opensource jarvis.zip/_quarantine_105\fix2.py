import io

path = "background/cortex.py"
f = io.open(path, "r", encoding="utf-8", newline="")
lines = f.readlines()
f.close()

# Find the fan-out code's step = { (should be around line 617)
step_idx = None
for i, line in enumerate(lines):
    if i > 610 and i < 625 and "step = {" in line:
        step_idx = i
        break

if step_idx is None:
    print("step = { NOT FOUND in fan-out section")
    exit(1)

print("Found step = { at line", step_idx + 1)

# Find the second "})" after step = {
count = 0
removed = False
for i in range(step_idx, len(lines)):
    if lines[i].strip() == "})":
        count += 1
        if count >= 2 and not removed:
            print("removing line", i + 1)
            del lines[i]
            removed = True
            break

if removed:
    f = io.open(path, "w", encoding="utf-8", newline="")
    f.writelines(lines)
    f.close()
    print("done")
else:
    print("NOT FOUND: only found", count, "closing }})")
