"""JARVIS 1.0.5 mission probe: offline capability checks, no network, no sends."""
import importlib.util, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

def has(mod):
    return importlib.util.find_spec(mod) is not None

out = {"mods": {m: has(m) for m in
    ["pyautogui","playwright","pptx","fitz","chromadb","pyperclip"]}}
import shutil
out["bins"] = {b: bool(shutil.which(b)) for b in
    ["tesseract","ffmpeg","chromium","chrome"]}
# chromium binary dir
try:
    cache = Path.home()/"AppData"/"Local"/"ms-playwright"
    out["chromium_dir"] = (cache.is_dir() and
        any(p.name.startswith("chromium") for p in cache.iterdir()))
except Exception as e:
    out["chromium_dir"] = "err:%s" % e

def load_bg(name):
    full = "jarvis_cowork_"+name
    if full in sys.modules:
        return sys.modules[full]
    p = ROOT/"background"/(name+".py")
    if not p.is_file():
        return None
    import importlib.util as iu
    spec = iu.spec_from_file_location(full, p)
    m = iu.module_from_spec(spec); sys.modules[full]=m
    spec.loader.exec_module(m); return m

for name in ["screen_agent","app_index","presentation_builder",
             "whatsapp_sender","whatsapp_web","browser_agent",
             "capability_registry","cortex","permissions"]:
    try:
        m = load_bg(name)
        out[name] = {"loaded": m is not None}
        if m is not None and hasattr(m,"capabilities"):
            try: out[name]["caps"]=m.capabilities()
            except Exception as e: out[name]["caps_err"]=str(e)[:200]
        if m is not None and hasattr(m,"specs"):
            try: out[name]["specs"]=[s.name for s in m.specs()]
            except Exception as e: out[name]["specs_err"]=str(e)[:200]
    except Exception as e:
        out[name] = {"loaded": False, "err": "%s:%s"%(type(e).__name__,e)[:300]}
try:
    ai = load_bg("app_index"); out["app_count"]=ai.count()
    out["app_sample"]=[r["name"] for r in ai.build_index()[:8]]
except Exception as e:
    out["app_count"]="err:%s"%e
try:
    import py_compile
    py_compile.compile(str(ROOT/"background"/"floating_ui.pyw"),doraise=True)
    out["hud_compile"]=True
except Exception as e:
    out["hud_compile"]="FAIL:%s"%e
# pptx render smoke (no LLM, no network)
try:
    pb = load_bg("presentation_builder")
    deck={"title":"Probe Deck","subtitle":"offline render check",
      "slides":[{"heading":"","bullets":[],"speaker_notes":""},
        {"heading":"Alpha","bullets":["one","two"],
         "speaker_notes":"notes here"}]}
    p=ROOT/"artifacts"/"presentations"/"_probe105.pptx"
    ok,detail=pb.render_pptx(deck,p,"jarvis")
    info={"ok":ok,"detail":detail,
      "exists":p.is_file(),"bytes":p.stat().st_size if p.is_file() else 0}
    if p.is_file():
        from pptx import Presentation
        prs=Presentation(str(p))
        info["slides"]=len(prs.slides._sldIdLst)
        info["notes"]=prs.slides[1].notes_slide.notes_text_frame.text[:40]
        p.unlink()
    out["pptx_render"]=info
except Exception as e:
    out["pptx_render"]="FAIL:%s:%s"%(type(e).__name__,e)[:300]
# bridge loopback check (static)
try:
    txt=(ROOT/"local-bridge"/"server.cjs").read_text(encoding="utf-8")
    out["bridge_loopback"]=("127.0.0.1" in txt and
        "server.listen(PORT, HOST" in txt)
except Exception as e:
    out["bridge_loopback"]="err:%s"%e
print(json.dumps(out,indent=1)[:9000])
