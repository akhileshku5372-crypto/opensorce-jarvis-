// Read-only check: does the Co-work view actually give its height to the
// selected tab? Drives a headless Chrome over CDP, opens Co-work, then every
// workspace tab, and reports the real box of each chrome row plus the n8n
// iframe. Also proves the global topbar is hidden on Co-work but still shown
// on Dashboard. No writes, no desktop actions.
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const out = path.join(root, 'artifacts', 'ui-audit', 'cowork-space')
mkdirSync(out, { recursive: true })

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-cowork-space-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking', 'about:blank',
], { stdio: ['ignore', 'ignore', 'pipe'] })
setTimeout(() => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  process.exit(124)
}, 240000).unref()

const wait = ms => new Promise(r => setTimeout(r, ms))
let ws, seq = 0
const pending = new Map()
const endpoint = new Promise((resolve, reject) => {
  let log = ''
  const timer = setTimeout(() => reject(new Error('Chrome startup timed out')), 20000)
  chrome.stderr.on('data', d => {
    log += d
    const m = log.match(/DevTools listening on (ws:\/\/[^\s]+)/)
    if (m) { clearTimeout(timer); resolve(m[1]) }
  })
  chrome.on('error', reject)
})
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++seq
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(method + ' timeout')) }, 20000)
    pending.set(id, { resolve, reject, timer })
    ws.send(JSON.stringify({ id, method, params }))
  })
}
async function evaluate(expression) {
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails))
  return r.result.value
}
const box = sel => `(() => { const e = document.querySelector(${JSON.stringify(sel)});
  if (!e) return null; const r = e.getBoundingClientRect();
  return { h: Math.round(r.height), w: Math.round(r.width) }; })()`

try {
  const browserUrl = await endpoint
  const origin = new URL(browserUrl).origin.replace('ws:', 'http:')
  const targets = await (await fetch(origin + '/json/list')).json()
  const target = targets.find(t => t.type === 'page') || targets[0]
  ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((res, rej) => {
    ws.addEventListener('open', res, { once: true })
    ws.addEventListener('error', rej, { once: true })
  })
  ws.addEventListener('message', e => {
    const m = JSON.parse(String(e.data))
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); clearTimeout(p.timer); pending.delete(m.id)
      if (m.error) p.reject(new Error(JSON.stringify(m.error))); else p.resolve(m.result)
    }
  })
  await send('Page.enable'); await send('Runtime.enable')
  // Viewport is overridable so the same audit can be re-run on a small laptop
  // (UI_AUDIT_SIZE=1366x768) without editing the script.
  const [vw, vh] = String(process.env.UI_AUDIT_SIZE || '1600x950').split('x').map(Number)
  await send('Emulation.setDeviceMetricsOverride', { width: vw, height: vh, deviceScaleFactor: 1, mobile: false })
  await send('Page.navigate', { url: 'http://127.0.0.1:7777' })
  await wait(5000)

  const report = {}
  // Baseline: Dashboard must still paint the global topbar.
  report.dashboardTopbar = await evaluate(box('.topbar'))

  // Wait until the nav control actually exists AND has painted. A bare
  // `?.click()` swallows a not-yet-booted app and every later probe then
  // measures a hidden panel and reports a convincing row of zeros.
  // The UI is a Vite SSR dev server: it logged "ready in 31110 ms" on a cold
  // start, so the allowance has to exceed that or this fails on a fresh boot.
  async function waitFor(expression, label, tries = 150) {
    for (let i = 0; i < tries; i++) {
      try { if (await evaluate(`!!(${expression})`)) return true } catch {}
      await wait(250)
    }
    throw new Error(`timed out waiting for ${label}: ${expression}`)
  }

  await waitFor(`document.querySelector('.nav-item[data-view="cowork"]')`, 'sidebar nav')
  await evaluate(`document.querySelector('.nav-item[data-view="cowork"]').click(), 1`)
  // Prove the switch landed before trusting any box below it.
  await waitFor(`(getComputedStyle(document.querySelector('[data-view-panel="cowork"]')).display !== 'none')`,
    'cowork panel visible')
  await wait(400)

  report.cowork = { viewport: await evaluate('innerHeight') }
  report.cowork.topbar = await evaluate(box('.topbar'))
  report.cowork.topbarDisplay = await evaluate(`getComputedStyle(document.querySelector('.topbar')).display`)
  report.cowork.heading = await evaluate(box('[data-view-panel="cowork"] .view-heading'))
  report.cowork.nav = await evaluate(box('[data-view-panel="cowork"] .cowork-nav'))
  report.cowork.taskHeader = await evaluate(box('[data-view-panel="cowork"] .cowork-task-header'))
  report.cowork.composer = await evaluate(box('[data-view-panel="cowork"] .cowork-composer'))
  report.cowork.micPresent = await evaluate('!!document.getElementById("cowork-mic")')
  // Every tab: the active panel must fill the box under the chrome rows.
  // n8n is measured while its own tab is the active one - an inactive panel
  // is display:none, so sampling it later would report a meaningless 0.
  for (const tab of ['chat', 'files', 'browser', 'terminal', 'artifacts', 'agents', 'extensions']) {
    await evaluate(`document.querySelector('[data-cowork-tab="${tab}"]').click(), 1`)
    // Confirm this panel is the painted one; a dropped click would otherwise be
    // measured as a hidden 0 and read as a layout failure.
    await waitFor(`(getComputedStyle(document.querySelector('[data-cowork-panel="${tab}"]')).display !== 'none')`,
      `panel ${tab} active`)
    await wait(500)
    report.cowork[tab] = await evaluate(`(() => {
      const p = document.querySelector('[data-cowork-panel="' + ${JSON.stringify(tab)} + '"]');
      if (!p) return null;
      const r = p.getBoundingClientRect();
      const host = document.getElementById('cowork-panels').getBoundingClientRect();
      const row = { panelH: Math.round(r.height), hostH: Math.round(host.height),
        fills: Math.abs(r.height - host.height) <= 2,
        display: getComputedStyle(p).display };
      const f = document.getElementById('n8n-frame');
      if (${JSON.stringify(tab)} === 'agents' && f) {
        const fr = f.getBoundingClientRect();
        row.n8nFrameH = Math.round(fr.height);
        row.n8nFrameW = Math.round(fr.width);
        row.n8nShare = +(fr.height / r.height).toFixed(3);
      }
      return row;
    })()`)
  }

  // NOTE: do NOT probe the n8n iframe here. This point runs with the Extensions
  // tab active, so [data-cowork-panel="agents"] is display:none and every box
  // would read 0 - a measurement of a hidden element, not a layout bug. The
  // valid figure is report.n8nActive, taken below with the Agents tab active.

  // Where exactly does the non-panel height go? Every row above and below the
  // panels, so an unexpectedly tall row is visible instead of mysterious.
  report.heightBudget = await evaluate(`(() => {
    const rows = [['heading', '.view-heading'], ['nav', '.cowork-nav'],
      ['taskHeader', '.cowork-task-header'], ['panels', '#cowork-panels'],
      ['composer', '.cowork-composer'], ['advanced', '.cowork-advanced']];
    const out = { viewport: innerHeight, rows: {} };
    let sum = 0;
    for (const [k, sel] of rows) {
      const e = document.querySelector('[data-view-panel="cowork"] ' + sel) || document.querySelector(sel);
      if (!e) continue;
      const h = Math.round(e.getBoundingClientRect().height);
      out.rows[k] = h; sum += h;
    }
    out.rowsTotal = sum;
    const c = document.querySelector('[data-view-panel="cowork"] .cowork-composer');
    if (c) {
      const f = c.querySelector('.field');
      const fs = getComputedStyle(f);
      out.composerFieldH = Math.round(f.getBoundingClientRect().height);
      out.composerPadding = getComputedStyle(c).padding;
      out.fieldBox = { padding: fs.padding, margin: fs.margin, minHeight: fs.minHeight,
        height: fs.height, fontSize: fs.fontSize, lineHeight: fs.lineHeight, border: fs.borderWidth };
      out.composerChildren = [...c.children].map(e => e.tagName + '#' + (e.id || '') +
        ':' + Math.round(e.getBoundingClientRect().height));
    }
    return out;
  })()`)

  // Nothing may spill outside the viewport horizontally.
  report.overflow = await evaluate(`(() => {
    const bad = [];
    for (const e of document.querySelectorAll('.workspace *')) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && (r.right > innerWidth + 2 || r.left < -2)) {
        bad.push({ id: e.id, cls: String(e.className).slice(0, 50), w: Math.round(r.width) });
        if (bad.length > 8) break;
      }
    }
    return { pageWidth: document.documentElement.scrollWidth, viewport: innerWidth, bad };
  })()`)

  // send() resolves the CDP result object itself, so the PNG is at .data here -
// reading .result.data would silently skip the file.
const shot = await send('Page.captureScreenshot', { format: 'png' })
  if (shot?.data) writeFileSync(path.join(out, 'cowork-extensions.png'), Buffer.from(shot.data, 'base64'))

  await evaluate(`document.querySelector('[data-cowork-tab="agents"]')?.click(), 1`)
  await wait(1500)
  // Re-measured with the Agents tab active: an inactive panel is display:none.
  report.n8nActive = await evaluate(`(() => {
    const f = document.getElementById('n8n-frame');
    const p = document.querySelector('[data-cowork-panel="agents"]');
    if (!f || !p) return null;
    const fr = f.getBoundingClientRect(), pr = p.getBoundingClientRect();
    return { frameH: Math.round(fr.height), frameW: Math.round(fr.width),
      panelH: Math.round(pr.height), panelW: Math.round(pr.width),
      share: +(fr.height / pr.height).toFixed(3),
      minHeight: getComputedStyle(f).minHeight,
      src: (f.getAttribute('src') || '').slice(0, 30) };
  })()`)
  const shotAgents = await send('Page.captureScreenshot', { format: 'png' })
  if (shotAgents?.data) writeFileSync(path.join(out, 'cowork-agents.png'), Buffer.from(shotAgents.data, 'base64'))

  await evaluate(`document.querySelector('[data-cowork-tab="chat"]')?.click(), 1`)
  await wait(900)
  const shotChat = await send('Page.captureScreenshot', { format: 'png' })
  if (shotChat?.data) writeFileSync(path.join(out, 'cowork-chat.png'), Buffer.from(shotChat.data, 'base64'))

  console.log(JSON.stringify(report, null, 2))
} finally {
  try { if (ws) ws.close() } catch {}
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { chrome.kill() } catch {}
  await wait(600)
  try { rmSync(profile, { recursive: true, force: true, maxRetries: 3 }) } catch {}
}