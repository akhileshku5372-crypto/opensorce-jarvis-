"""Wiring tests: the duplex session must share JARVIS's mic, command path,
memory and /state - never replace or duplicate them.

Stdlib + fakes only: no network, no audio, no microphone. The real sound is
proven by `background/live_session.py --mic` after these pass.
"""
import importlib.util
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load("voice_engine")
BRIDGE = _load("live_bridge")
LOCAL_OCR = _load("local_ocr")


class LiveSpeechTest(unittest.TestCase):
    """speak() is the single exit for everything JARVIS says, so the duplex
    choice has to be made there - otherwise a reply is heard twice or not at
    all."""

    def setUp(self):
        ENGINE.live_bridge = BRIDGE
        BRIDGE.stop()
        self.spoken = []
        self.addCleanup(BRIDGE.stop)

    def _chain(self):
        """The classic TTS chain, recorded instead of run."""
        ENGINE._TTS_DOWN_UNTIL.clear()
        ENGINE._TTS_FAILS.clear()
        patchers = [
            mock.patch.object(ENGINE, "_tts_engine_ready", lambda *_a: True),
            mock.patch.object(ENGINE, "_edge_synthesize",
                              lambda *_a, **_kw: "fake.mp3"),
            mock.patch.object(ENGINE, "_play_mp3", lambda *_a: True),
        ]
        for p in patchers:
            p.start()
            self.addCleanup(p.stop)

    def test_live_voice_speaks_and_no_tts_file_is_built(self):
        built = []
        with mock.patch.object(BRIDGE, "taking_audio", lambda: True), \
             mock.patch.object(BRIDGE, "utter",
                               lambda t: self.spoken.append(t) or True):
            self._chain()
            ENGINE._edge_synthesize = lambda *_a, **_kw: built.append("edge") or "fake.mp3"
            thread = ENGINE.speak("YouTube is open, sir.", None)
            if thread is not None:
                thread.join(3)
        self.assertEqual(self.spoken, ["YouTube is open, sir."])
        self.assertEqual(built, [], "a duplex reply must never build an mp3")
        self.assertEqual(ENGINE.get_state()["last_jarvis"], "YouTube is open, sir.")

    def test_when_live_refuses_the_line_the_tts_chain_still_speaks(self):
        # A duplex socket can die between turns. Audio must degrade to the old
        # path, not to silence - the 2026-10-16 failure mode.
        ENGINE._TTS_DOWN_UNTIL.clear()
        ENGINE._TTS_FAILS.clear()
        called = []
        patchers = [
            mock.patch.object(BRIDGE, "taking_audio", lambda: True),
            mock.patch.object(BRIDGE, "utter", lambda t: False),
            mock.patch.object(ENGINE, "_tts_engine_ready", lambda *_a: True),
            mock.patch.object(ENGINE, "_edge_synthesize",
                              lambda *_a, **_kw: called.append("edge") or "fake.mp3"),
            mock.patch.object(ENGINE, "_play_mp3", lambda *_a: True),
        ]
        for p in patchers:
            p.start()
            self.addCleanup(p.stop)
        thread = ENGINE.speak("Fallback line, sir.", None)
        if thread is not None:
            thread.join(3)
        self.assertEqual(called, ["edge"])

    def test_classic_mode_is_untouched(self):
        self._chain()
        called = []
        real = ENGINE._edge_synthesize
        ENGINE._edge_synthesize = lambda *_a, **_kw: called.append("edge") or "fake.mp3"
        thread = ENGINE.speak("Normal reply.", None)
        if thread is not None:
            thread.join(3)
        ENGINE._edge_synthesize = real
        self.assertEqual(called, ["edge"])


class MicSharingTest(unittest.TestCase):
    """The engine's consumer loop must hand the chunk to Live and skip local
    recognition, or two recognizers fight over one sentence."""

    def setUp(self):
        # _live_publish is throttled to 2/s; reset the clock so this test reads
        # the state it just published instead of a previous test's snapshot.
        ENGINE._live_state_at = 0.0

    def test_chunk_goes_to_live_and_local_stt_is_skipped(self):
        fed = []
        with mock.patch.object(BRIDGE, "taking_audio", lambda: True), \
             mock.patch.object(BRIDGE, "feed",
                               lambda data, rate: fed.append((data, rate)) or True), \
             mock.patch.object(BRIDGE, "status",
                               lambda: {"voice_mode": "live", "live_stage": "live_ready",
                                        "barge_in": 0, "first_audio_s": 0.4,
                                        "turns": 2, "frames_sent": 11,
                                        "dropped_chunks": 0, "last_error": "",
                                        "last_user": "open youtube",
                                        "last_jarvis": "On it, sir.",
                                        "tool_calls": 1, "last_tool": "jarvis_command"}):
            self.assertTrue(ENGINE._live_take_audio(b"\x01\x02" * 512, 16000))
        self.assertEqual(fed, [(b"\x01\x02" * 512, 16000)])
        # The panel and HUD read /state only - so the duplex numbers have to be
        # published there, not just kept inside the bridge.
        st = ENGINE.get_state()
        self.assertEqual(st["live_stage"], "live_ready")
        self.assertEqual(st["voice_mode"], "live")
        self.assertEqual(st["live_first_audio_s"], 0.4)
        self.assertEqual(st["live_tool_calls"], 1)

    def test_live_turn_publishes_one_event_pair_not_one_per_chunk(self):
        ENGINE._live_state_at = 0.0
        before = len(ENGINE.get_state().get("events") or [])
        ENGINE._live_turn("open youtube", "On it, sir.")
        self.assertEqual(ENGINE.get_state().get("last_user"), "open youtube")
        self.assertEqual(ENGINE.get_state().get("last_jarvis"), "On it, sir.")
        # A later feed/publish loop must not re-append the same pair. This was
        # the real 0.5s feed spam seen on 2026-10-20.
        with mock.patch.object(BRIDGE, "status",
                               lambda: {"voice_mode": "live", "live_stage": "live_ready",
                                        "barge_in": 0, "first_audio_s": 0.4,
                                        "turns": 2, "frames_sent": 11,
                                        "dropped_chunks": 0, "last_error": "",
                                        "last_user": "open youtube",
                                        "last_jarvis": "On it, sir.",
                                        "tool_calls": 0, "last_tool": ""}):
            for _ in range(3):
                ENGINE._live_state_at = 0.0
                ENGINE._live_publish()
        rows = (ENGINE.get_state().get("events") or [])[before:]
        self.assertEqual(len([r for r in rows if r.get("text") == "open youtube"]), 1)
        self.assertEqual(len([r for r in rows if r.get("text") == "On it, sir."]), 1)

    def test_a_refused_frame_hands_the_mic_back_to_classic(self):
        # The exact failure that made "live mode band karo" impossible to say:
        # a dead socket kept swallowing every chunk while local STT was skipped.
        seen = []
        with mock.patch.object(BRIDGE, "taking_audio", lambda: True), \
             mock.patch.object(BRIDGE, "feed", lambda data, rate: False), \
             mock.patch.object(BRIDGE, "status", lambda: {"voice_mode": "live",
                                                          "live_stage": "live_lost",
                                                          "last_error": "dead"}):
            with mock.patch.object(ENGINE, "_live_fallback",
                                   lambda reason: seen.append(reason)):
                self.assertFalse(ENGINE._live_take_audio(b"\x01\x02" * 512, 16000))
        import time
        deadline = time.monotonic() + 2
        while not seen and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertEqual(seen, ["audio frame dropped"])

    def test_chunk_stays_with_the_engine_when_live_is_off(self):
        with mock.patch.object(BRIDGE, "taking_audio", lambda: False):
            self.assertFalse(ENGINE._live_take_audio(b"\x01\x02" * 512, 16000))


class CommandRoutingTest(unittest.TestCase):
    """Live answers conversation itself. Only a desktop action may be
    submitted, or every question would be answered twice - by Live and by the
    brain, spending brain quota for nothing."""

    def test_an_os_action_is_submitted_through_the_one_command_path(self):
        submitted = []
        with mock.patch.object(ENGINE, "classify_command_intent", lambda _t: "os"), \
             mock.patch.object(ENGINE, "submit_command",
                               lambda text, ui, bridge, source="voice":
                               submitted.append((text, source))):
            ENGINE._LIVE_UI = None
            ENGINE._LIVE_BRIDGE = None
            handled = ENGINE._live_route("open youtube")
        self.assertTrue(handled)
        self.assertEqual(submitted, [("open youtube", "live")])

    def test_a_conversational_line_is_left_for_the_live_voice(self):
        submitted = []
        with mock.patch.object(ENGINE, "classify_command_intent", lambda _t: "chat"), \
             mock.patch.object(ENGINE, "submit_command",
                               lambda *a, **kw: submitted.append(a)):
            self.assertFalse(ENGINE._live_route("who wrote the gita"))
        self.assertEqual(submitted, [])

    def test_the_mode_phrase_parser_reads_hinglish_and_english(self):
        self.assertIs(ENGINE._live_mode_request("live mode chalu kardo"), True)
        self.assertIs(ENGINE._live_mode_request("enter duplex mode"), True)
        self.assertIs(ENGINE._live_mode_request("live mode band karo"), False)
        self.assertIs(ENGINE._live_mode_request("stop live mode"), False)
        self.assertIsNone(ENGINE._live_mode_request("open youtube"))
        self.assertIsNone(ENGINE._live_mode_request("research quantum computing"))

    def test_boot_injects_the_engines_own_routes_into_the_bridge(self):
        seen = {}
        ENGINE.live_bridge = BRIDGE
        with mock.patch.object(BRIDGE, "configure", lambda **kw: seen.update(kw)):
            ENGINE._live_boot()
        for key in ("factory", "submit_fn", "remember_fn", "turn_fn"):
            self.assertIn(key, seen)
            self.assertTrue(callable(seen[key]), "%s must be a real route" % key)

    def test_route_still_accepts_an_explicit_source_for_old_callers(self):
        submitted = []
        with mock.patch.object(ENGINE, "classify_command_intent", lambda _t: "os"), \
             mock.patch.object(ENGINE, "submit_command",
                               lambda text, ui, bridge, source="voice":
                               submitted.append((text, source))):
            self.assertTrue(ENGINE._live_route("open youtube", "live"))
        self.assertEqual(submitted, [("open youtube", "live")])


class LiveToolTest(unittest.TestCase):
    """The model's function calls must land on the same router, never a shell."""

    def setUp(self):
        ENGINE.live_bridge = BRIDGE
        BRIDGE.stop()
        self.addCleanup(BRIDGE.stop)

    def test_jarvis_command_dispatches_through_submit_command(self):
        submitted = []
        with mock.patch.object(ENGINE, "submit_command",
                               lambda text, ui, bridge, source="voice":
                               submitted.append((text, source)) or True):
            result = ENGINE._live_tool_call("jarvis_command",
                                            {"command": "open youtube"})
        self.assertTrue(result["ok"])
        self.assertIn("SYSTEM", result["result"])
        self.assertEqual(submitted, [("open youtube", "live")])

    def test_whatsapp_chat_open_uses_the_same_router(self):
        # The transcript failure was a missing canonical route, not a missing
        # Live tool: opening a chat must dispatch through submit_command too.
        submitted = []
        with mock.patch.object(ENGINE, "submit_command",
                               lambda text, ui, bridge, source="voice":
                               submitted.append((text, source)) or True):
            result = ENGINE._live_tool_call(
                "jarvis_command",
                {"command": "WhatsApp pe Akhilesh ka chat kholo"})
        self.assertTrue(result["ok"])
        self.assertEqual(submitted, [("WhatsApp pe Akhilesh ka chat kholo",
                                      "live")])

    def test_web_search_is_dispatched_not_executed_in_the_model(self):
        submitted = []
        with mock.patch.object(ENGINE, "submit_command",
                               lambda text, ui, bridge, source="voice":
                               submitted.append(text) or True):
            result = ENGINE._live_tool_call("web_search", {"query": "today news"})
        self.assertTrue(result["ok"])
        self.assertEqual(submitted, ["search the web for today news"])

    def test_an_unknown_tool_fails_honestly(self):
        result = ENGINE._live_tool_call("rm_rf", {})
        self.assertFalse(result["ok"])
        self.assertIn("unknown tool", result["error"])

    def test_empty_command_is_refused(self):
        result = ENGINE._live_tool_call("jarvis_command", {"command": "  "})
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"], "empty command")

    def test_look_at_screen_is_declared_and_uses_the_free_vision_route(self):
        tools = {tool["name"]: tool for tool in ENGINE._LIVE_TOOLS}
        self.assertIn("look_at_screen", tools)
        self.assertIn("question",
                      tools["look_at_screen"]["parameters"]["properties"])
        seen = {}

        def fake_analyze(ui, lang, question=None):
            seen.update({"ui": ui, "lang": lang, "question": question})
            return "A code editor is open, Sir."

        with mock.patch.object(ENGINE, "_LIVE_UI", "http://127.0.0.1:7777"), \
             mock.patch.object(ENGINE, "analyze_screen", fake_analyze), \
             mock.patch.object(ENGINE, "submit_command",
                               lambda *a, **k: self.fail(
                                   "look_at_screen must not dispatch a command")):
            result = ENGINE._live_tool_call(
                "look_at_screen", {"question": "what is open?"})
        self.assertTrue(result["ok"])
        self.assertEqual(result["result"], "A code editor is open, Sir.")
        self.assertEqual(seen["ui"], "http://127.0.0.1:7777")
        self.assertEqual(seen["question"], "what is open?")

    def test_screen_vision_failure_is_reported_as_a_failure(self):
        with mock.patch.object(ENGINE, "_LIVE_UI", "http://127.0.0.1:7777"), \
             mock.patch.object(ENGINE, "analyze_screen",
                               lambda *a, **k: "My vision systems are offline, Sir."):
            result = ENGINE._live_tool_call("look_at_screen", {})
        self.assertFalse(result["ok"])
        self.assertIn("offline", result["error"])

    def test_screen_capture_failure_is_reported_as_a_failure(self):
        with mock.patch.object(ENGINE, "_LIVE_UI", "http://127.0.0.1:7777"), \
             mock.patch.object(ENGINE, "analyze_screen",
                               lambda *a, **k: "I could not capture the screen, Sir."):
            result = ENGINE._live_tool_call("look_at_screen", {})
        self.assertFalse(result["ok"])
        self.assertIn("capture", result["error"])


class LocalOcrTest(unittest.TestCase):
    """Windows OCR is the no-key Live Screen reader: no temp files, no cloud."""

    def test_ocr_output_is_cleaned_without_duplicate_lines(self):
        self.assertEqual(
            LOCAL_OCR.clean_text("hello\r\nhello\r\n  world  \x00"),
            "hello\nworld")

    def test_summary_states_only_measured_facts(self):
        text = ("Inbox (7)\n"
                "Budget approval needed\n"
                "This action will permanently delete the folder")
        summary = LOCAL_OCR.summarize(text, "Gmail - Chrome")
        self.assertIn("Gmail", summary)
        self.assertIn("7 unread", summary)
        self.assertIn("characters readable", summary)
        self.assertIn("delete", summary)
        self.assertIn("action khud nahi", summary)

    def test_file_type_text_does_not_misclassify_file_explorer(self):
        summary = LOCAL_OCR.summarize(
            "Chrome HTML\nJSON Source File", "src - File Explorer")
        self.assertIn("File Explorer", summary)
        self.assertNotIn("Chrome browser", summary)

    def test_a_word_containing_an_app_name_is_not_that_app(self):
        summary = LOCAL_OCR.summarize("notes", "Knowledge Base - Notepad")
        self.assertIn("Notepad", summary)
        self.assertNotIn("Edge browser", summary)

    def test_summary_does_not_quote_the_jarvis_dashboard_behind_the_window(self):
        text = ("Live screen on. Sir. Windows ke built-in OCR se local\n"
                "Budget approval needed before Friday")
        summary = LOCAL_OCR.summarize(text, "JARVIS_ALPHA - File Explorer")
        self.assertIn("Budget approval needed", summary)
        self.assertNotIn("Windows ke built", summary)

    def test_summary_uses_the_window_title_and_not_a_taskbar_uuid(self):
        text = ("6b135107-tf94,\n"
                "JARVIS_BETA\n"
                "Budget approval needed before Friday")
        summary = LOCAL_OCR.summarize(text, "JARVIS_BETA - File Explorer")
        self.assertIn("File Explorer active hai (JARVIS_BETA", summary)
        self.assertNotIn("6b135107", summary)
        other = LOCAL_OCR.summarize(text, "JARVIS_ALPHA - File Explorer")
        self.assertNotEqual(summary, other)
        self.assertIn("JARVIS_ALPHA", other)

    def test_frame_goes_to_powershell_through_stdin_not_a_temp_file(self):
        seen = {}

        def fake_run(args, **kwargs):
            seen["args"] = args
            seen["input"] = kwargs.get("input")
            return mock.Mock(returncode=0, stdout=b"Hello\nHello\nWorld", stderr=b"")

        with mock.patch.object(LOCAL_OCR, "available", lambda: True), \
             mock.patch.object(LOCAL_OCR, "_powershell", lambda: "powershell.exe"), \
             mock.patch.object(LOCAL_OCR.subprocess, "run", side_effect=fake_run):
            result = LOCAL_OCR.read_base64("ZmFrZQ==")
        self.assertTrue(result["ok"])
        self.assertEqual(result["text"], "Hello\nWorld")
        self.assertEqual(result["source"], "windows-ocr")
        self.assertIsInstance(seen["input"], bytes)
        self.assertNotIn("temp", " ".join(seen["args"]).lower())

    def test_missing_ocr_language_is_reported_as_a_failure(self):
        with mock.patch.object(LOCAL_OCR, "available", lambda: True), \
             mock.patch.object(LOCAL_OCR, "_powershell", lambda: "powershell.exe"), \
             mock.patch.object(LOCAL_OCR.subprocess, "run",
                               return_value=mock.Mock(
                                   returncode=2,
                                   stdout=b"",
                                   stderr=b"OCR_ENGINE_UNAVAILABLE: missing")):
            result = LOCAL_OCR.read_base64("ZmFrZQ==")
        self.assertFalse(result["ok"])
        self.assertIn("language pack", result["error"])


class ScreenWatchTest(unittest.TestCase):
    """Live Screen must be one local sampler behind the one command router."""

    def setUp(self):
        self.addCleanup(ENGINE.set_state,
                        screen_watch=ENGINE._screen_watch_default_status())
        # Stop any reader before the status cleanup runs; otherwise a stray
        # thread would publish over the next test's state.
        self.addCleanup(ENGINE._screen_live_stop)

    def _wait_for(self, predicate, timeout=2.5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.01)
        return False

    def test_the_switch_phrases_are_explicit_and_do_not_steal_screen_analysis(self):
        for text in ("live screen on", "live screen chalu kardo",
                     "screen share on karo", "screen watch off"):
            with self.subTest(text=text):
                self.assertIn(ENGINE._screen_watch_request(text), (True, False))
        self.assertIs(ENGINE._screen_watch_request("live screen on"), True)
        self.assertIs(ENGINE._screen_watch_request("live screen off kardo"), False)
        self.assertIs(ENGINE._screen_watch_request("meri screen dekhna shuru karo"), True)
        self.assertIs(ENGINE._screen_watch_request("meri screen dekhna band karo"), False)
        self.assertIsNone(ENGINE._screen_watch_request("screen pe kya hai"))
        self.assertIsNone(ENGINE._screen_watch_request("what is on my screen"))
        self.assertIsNone(ENGINE._screen_watch_request("live mode on"))

    def test_switch_runs_before_screen_analysis(self):
        seen = []
        with mock.patch.object(ENGINE, "_screen_watch_set",
                               lambda on, ui=None: seen.append((on, ui)) or "ok"), \
             mock.patch.object(ENGINE, "analyze_screen",
                               lambda *a, **k: self.fail(
                                   "live screen must not run screen analysis")), \
             mock.patch.object(ENGINE, "speak", lambda *a, **k: None), \
             mock.patch.object(ENGINE, "_remember_turn", lambda *a, **k: None):
            ENGINE._recent.clear()
            ENGINE._action_stamps.clear()
            self.assertTrue(ENGINE.run_command(
                "meri screen dekhna shuru karo", "ui", "bridge"))
        self.assertEqual(seen, [(True, "ui")])

    def test_on_and_off_publish_status_and_off_clears(self):
        class FakeAgent:
            def __init__(self):
                self.started = None
                self.stopped = False

            def start_watching(self, **kwargs):
                self.started = kwargs
                return dict(ENGINE._screen_watch_default_status(),
                            enabled=True, scope=kwargs.get("scope", "full_screen"))

            def watch_status(self):
                return dict(ENGINE._screen_watch_default_status(), enabled=True)

            def latest_frame(self, max_age=5.0):
                return None

            def stop_watching(self):
                self.stopped = True
                return dict(ENGINE._screen_watch_default_status(),
                            cleared_at=1.0)

        fake = FakeAgent()
        with mock.patch.object(ENGINE, "_screen_agent", return_value=fake):
            on_reply = ENGINE._screen_watch_set(True)
            self.assertIn("on", on_reply.lower())
            self.assertGreaterEqual(fake.started["fps"], 1.5)
            self.assertTrue(ENGINE.get_state()["screen_watch"]["enabled"])
            off_reply = ENGINE._screen_watch_set(False)
        self.assertTrue(fake.stopped)
        self.assertIn("clear", off_reply.lower())
        state = ENGINE.get_state()["screen_watch"]
        self.assertFalse(state["enabled"])
        self.assertEqual(state["frames"], 0)
        self.assertEqual(state["cleared_at"], 1.0)

    def test_continuous_reader_publishes_readable_and_analysis_then_clears(self):
        class FakeAgent:
            def watch_status(self):
                return dict(ENGINE._screen_watch_default_status(),
                            enabled=True, frames=3, last_change_at=100.0)

            def latest_frame(self, max_age=5.0):
                return {"jpeg_b64": "ZmFrZQ==", "captured_at": 100.0,
                        "foreground": "Dashboard", "scope": "full_screen"}

        fake = FakeAgent()
        with mock.patch.object(ENGINE, "_screen_agent", return_value=fake), \
             mock.patch.object(
                 ENGINE, "_screen_live_local_read",
                 return_value=("JARVIS dashboard",
                               "Sir dashboard dekh rahe hain.",
                               "windows-ocr", 45)) as local_read, \
             mock.patch.object(
                 ENGINE, "_analyze_frame_full",
                 side_effect=AssertionError(
                     "the local path must never call cloud vision")):
            started = ENGINE._screen_live_start("http://ui")
            self.assertTrue(started["enabled"])
            self.assertTrue(self._wait_for(
                lambda: ENGINE._screen_live_snapshot()["analysis"]))
            self.assertTrue(self._wait_for(
                lambda: ENGINE.get_state()["screen_watch"]["live"]["analysis"]))
        live = ENGINE.get_state()["screen_watch"]["live"]
        self.assertEqual(live["readable"], "JARVIS dashboard")
        self.assertEqual(live["analysis"], "Sir dashboard dekh rahe hain.")
        self.assertEqual(live["model"], "windows-ocr")
        self.assertEqual(live["readable_source"], "windows-ocr")
        self.assertEqual(live["analysis_source"], "local-rules")
        self.assertEqual(live["read_elapsed_ms"], 45)
        self.assertEqual(live["analysis_frames"], 1)
        self.assertFalse(live["stale"])
        self.assertNotIn("jpeg_b64", live)
        local_read.assert_called()

        ENGINE._screen_live_stop()
        cleared = ENGINE.get_state()["screen_watch"]["live"]
        self.assertFalse(cleared["enabled"])
        self.assertEqual(cleared["readable"], "")
        self.assertEqual(cleared["analysis"], "")
        self.assertEqual(cleared["error"], "")

    def test_a_frame_that_changes_during_ocr_is_not_published(self):
        class FakeAgent:
            frame_at = 100.0

            def watch_status(self):
                return dict(ENGINE._screen_watch_default_status(),
                            enabled=True, frames=3,
                            last_change_at=self.frame_at)

            def latest_frame(self, max_age=5.0):
                return {"jpeg_b64": "ZmFrZQ==",
                        "captured_at": self.frame_at,
                        "foreground": "Dashboard"}

        fake = FakeAgent()
        first_started = threading.Event()
        release = threading.Event()
        calls = []

        def read(frame):
            calls.append(frame["captured_at"])
            if len(calls) == 1:
                first_started.set()
                release.wait(2.0)
                return ("screen one", "analysis one", "windows-ocr", 0)
            return ("screen two", "analysis two", "windows-ocr", 0)

        with mock.patch.object(ENGINE, "_screen_agent", return_value=fake), \
             mock.patch.object(ENGINE, "_screen_live_local_read",
                               side_effect=read):
            ENGINE._screen_live_start("http://ui")
            self.assertTrue(first_started.wait(2.0))
            # Screen changes while the first OCR process is still running.
            fake.frame_at = 101.0
            release.set()
            self.assertTrue(self._wait_for(
                lambda: ENGINE.get_state()["screen_watch"]["live"].get(
                    "readable") == "screen two"))
        live = ENGINE.get_state()["screen_watch"]["live"]
        self.assertEqual(live["readable"], "screen two")
        self.assertEqual(live["analysis"], "analysis two")
        self.assertNotIn("screen one", live["analysis"])
        self.assertGreaterEqual(len(calls), 2)
        ENGINE._screen_live_stop()

    def test_off_during_an_inflight_analysis_cannot_repopulate_cleared_data(self):
        class FakeAgent:
            def watch_status(self):
                return dict(ENGINE._screen_watch_default_status(),
                            enabled=True, frames=3, last_change_at=100.0)

            def latest_frame(self, max_age=5.0):
                return {"jpeg_b64": "ZmFrZQ==", "captured_at": 100.0}

        started = threading.Event()
        release = threading.Event()

        def slow_read(frame):
            started.set()
            release.wait(2.0)
            return ("private text", "private analysis", "windows-ocr", 0)

        fake = FakeAgent()
        with mock.patch.object(ENGINE, "_screen_agent", return_value=fake), \
             mock.patch.object(ENGINE, "_screen_live_local_read",
                               side_effect=slow_read):
            ENGINE._screen_live_start("http://ui")
            self.assertTrue(started.wait(2.0))
            threading.Timer(0.15, release.set).start()
            ENGINE._screen_live_stop()
        time.sleep(0.1)
        live = ENGINE._screen_live_snapshot()
        self.assertFalse(live["enabled"])
        self.assertEqual(live["readable"], "")
        self.assertEqual(live["analysis"], "")
        self.assertEqual(live["error"], "")

    def test_continuous_reader_reports_a_local_ocr_failure_and_backs_off(self):
        class FakeAgent:
            def watch_status(self):
                return dict(ENGINE._screen_watch_default_status(),
                            enabled=True, frames=3, last_change_at=100.0)

            def latest_frame(self, max_age=5.0):
                return {"jpeg_b64": "ZmFrZQ==", "captured_at": 100.0}

        fake = FakeAgent()
        with mock.patch.object(ENGINE, "_screen_agent", return_value=fake), \
             mock.patch.object(ENGINE, "_SCREEN_LIVE_CLOUD_FALLBACK", False), \
             mock.patch.object(ENGINE, "_screen_live_local_read",
                               side_effect=RuntimeError("ocr missing")) as read:
            ENGINE._screen_live_start("http://ui")
            self.assertTrue(self._wait_for(
                lambda: ENGINE._screen_live_snapshot()["error"]))
            live = ENGINE._screen_live_snapshot()
            self.assertIn("Local OCR", live["error"])
            self.assertIn("ocr missing", live["error"])
            self.assertGreater(live["backoff_until"], time.time())
            self.assertEqual(live["failures"], 1)
            time.sleep(0.35)
            self.assertEqual(read.call_count, 1,
                             "an error must not hammer OCR")
        ENGINE._screen_live_stop()

    def test_a_generic_screen_question_uses_the_fresh_live_read(self):
        with ENGINE._SCREEN_LIVE_LOCK:
            ENGINE._SCREEN_LIVE_STATE.update(
                enabled=True, readable="JARVIS dashboard",
                analysis="Sir dashboard dekh rahe hain.",
                analysis_at=time.time(), analysis_frame_at=100.0)
        agent = mock.Mock()
        agent.latest_frame.return_value = None
        with mock.patch.object(ENGINE, "_screen_agent", return_value=agent), \
             mock.patch.object(ENGINE, "_analyze_frame",
                               side_effect=AssertionError(
                                   "fresh live read must be reused")), \
             mock.patch.object(ENGINE.tempfile, "mkstemp",
                               side_effect=AssertionError("no capture")):
            reply = ENGINE.analyze_screen("http://ui", "en",
                                          "screen pe kya hai")
        self.assertIn("JARVIS dashboard", reply)
        self.assertIn("Sir dashboard dekh rahe hain", reply)

    def test_the_two_line_live_read_is_split_without_inventing_text(self):
        self.assertEqual(
            ENGINE._screen_live_split("READ: hello\nVIEW: world"),
            ("hello", "world"))
        self.assertEqual(
            ENGINE._screen_live_split("READ: (none)\nVIEW: blank screen"),
            ("", "blank screen"))

    def test_a_cached_frame_skips_the_disk_capture(self):
        frame = {"jpeg_b64": "ZmFrZQ==", "captured_at": 1.0,
                 "foreground": "Chrome", "scope": "full_screen", "age_s": 0.2}
        agent = mock.Mock()
        agent.latest_frame.return_value = frame
        with mock.patch.object(ENGINE, "_screen_agent", return_value=agent), \
             mock.patch.object(ENGINE, "_analyze_frame",
                               return_value="cached answer") as analyze, \
             mock.patch.object(ENGINE.tempfile, "mkstemp",
                               side_effect=AssertionError("no temp file")), \
             mock.patch.object(ENGINE.subprocess, "run",
                               side_effect=AssertionError("must use the cache")):
            reply = ENGINE.analyze_screen("http://ui", "en", "what is open?")
        self.assertEqual(reply, "cached answer")
        analyze.assert_called_once_with("ZmFrZQ==", "http://ui",
                                        "what is open?", "en")

    def test_without_a_live_frame_the_old_capture_path_still_works_and_cleans_up(self):
        agent = mock.Mock()
        agent.latest_frame.return_value = None
        path = Path(tempfile.gettempdir()) / "jarvis-live-wiring-fallback.png"
        path.write_bytes(b"fake-png")
        with mock.patch.object(ENGINE, "_screen_agent", return_value=agent), \
             mock.patch.object(ENGINE.tempfile, "mkstemp",
                               return_value=(0, str(path))), \
             mock.patch.object(ENGINE.os, "close"), \
             mock.patch.object(ENGINE.subprocess, "run",
                               return_value=mock.Mock(returncode=0)), \
             mock.patch.object(ENGINE, "_analyze_frame",
                               return_value="fresh capture") as analyze:
            reply = ENGINE.analyze_screen("http://ui", "en", "read screen")
        self.assertEqual(reply, "fresh capture")
        analyze.assert_called_once()
        self.assertFalse(path.exists())


class ModeSwitchTest(unittest.TestCase):
    def test_voice_command_starts_the_session_and_says_so(self):
        with mock.patch.object(BRIDGE, "start", lambda: True):
            reply = ENGINE._live_set_mode(True)
        self.assertIn("live", reply.lower())
        self.assertEqual(ENGINE.get_state().get("voice_mode"), "live")

    def test_a_failed_start_is_reported_as_a_failure(self):
        # Honesty rule: never announce a duplex mode that did not open.
        BRIDGE.stop()
        with mock.patch.object(BRIDGE, "start", lambda: False):
            reply = ENGINE._live_set_mode(True)
        self.assertIn("nahi", reply.lower())
        self.assertEqual(ENGINE.get_state().get("voice_mode"), "classic")

    def test_stop_gives_the_mic_back_and_says_so(self):
        with mock.patch.object(BRIDGE, "start", lambda: True), \
             mock.patch.object(BRIDGE, "stop", lambda: None):
            ENGINE._live_set_mode(True)
            reply = ENGINE._live_set_mode(False)
        self.assertIn("classic", ENGINE.get_state().get("voice_mode"))
        self.assertTrue(reply)


if __name__ == "__main__":
    unittest.main()
