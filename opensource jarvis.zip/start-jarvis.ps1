# One canonical PM2 launcher. Never launch the retired jarvis_core.py stub.
param([switch]$Float, [switch]$WithPodcasts)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Invoke-Checked([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Exe failed (exit $LASTEXITCODE). Fix the error above before continuing." }
}
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js 22.12+ LTS, then run setup-windows.ps1.' }
if (-not (Get-Command pm2 -ErrorAction SilentlyContinue)) { throw 'Run setup-windows.ps1 first (PM2 missing).' }
if (-not (Test-Path 'node_modules/vite/bin/vite.js')) { throw 'Run setup-windows.ps1 first (Node dependencies missing).' }
$python = & node run_py.cjs --resolve
if ($LASTEXITCODE -ne 0) { throw 'Python resolution failed. Run setup-windows.ps1.' }
$env:JARVIS_PYTHON = ($python | Select-Object -Last 1).Trim()
Invoke-Checked $env:JARVIS_PYTHON @('-c', 'import requests, dotenv, numpy, sounddevice, edge_tts, tkinter')

# Do not kill arbitrary processes using our ports. Explain stale/manual engines.
$raw = & pm2 jlist
if ($LASTEXITCODE -ne 0) { throw 'PM2 could not list processes. Run pm2 ls.' }
# pm2 jlist embeds each app's full environment, which contains duplicate
# case-variant keys (username/USERNAME) that crash PS5.1 ConvertFrom-Json.
# So never parse it whole: extract app names with a targeted regex and validate
# only the array envelope. A freshly daemonized PM2 legitimately returns [].
$blob = ($raw -join "`n").Trim()
if (-not ($blob.StartsWith('[') -and $blob.EndsWith(']'))) {
    throw 'PM2 process list is not valid JSON. Run pm2 ls and retry.'
}
$managed = @([regex]::Matches($blob, '"name"\s*:\s*"([^"]+)"') |
    ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
foreach ($entry in @(@(7777, 'jarvis-ui'), @(7778, 'jarvis-windows-bridge'), @(7780, 'jarvis-voice'))) {
    $listener = Get-NetTCPConnection -LocalPort $entry[0] -State Listen -ErrorAction SilentlyContinue
    if ($listener -and $managed -notcontains $entry[1]) {
        throw "Port $($entry[0]) is already used outside the managed $($entry[1]) service. Close that old JARVIS/manual process, then retry. No unrelated process was killed."
    }
}
Invoke-Checked 'npm' @('run', 'build')
$apps = 'jarvis-ui,jarvis-windows-bridge,jarvis-voice,jarvis-hud'
if ($WithPodcasts) { $apps += ',jarvis-podcast,jarvis-kokoro' }
Invoke-Checked 'pm2' @('startOrRestart', 'ecosystem.config.cjs', '--only', $apps, '--update-env')
Invoke-Checked 'pm2' @('save')

$ready = $false
foreach ($attempt in 1..40) {
    try {
        $ui = Invoke-RestMethod 'http://127.0.0.1:7777/api/health' -TimeoutSec 2
        $voice = Invoke-RestMethod 'http://127.0.0.1:7780/health' -TimeoutSec 2
        if ($ui.ok -and $voice.version -eq '2.0.2') { $ready = $true; break }
    } catch {}
    Start-Sleep -Milliseconds 750
}
if (-not $ready) { throw 'Startup health check failed. Run npm run jarvis:doctor and pm2 logs jarvis-voice --lines 60 --nostream.' }
if ($Float) {
    Invoke-RestMethod 'http://127.0.0.1:7780/float' -Method Post -TimeoutSec 5 | Out-Null
}
Start-Process 'http://127.0.0.1:7777'
Write-Host 'JARVIS voice engine 2.0.2 is reachable. Mic readiness is separate: npm run jarvis:doctor'
Write-Host 'Try typed "what time is it" (or "time batao"), then Listen and "aap kaise ho".'
Write-Host 'Stop voice temporarily: pm2 stop jarvis-voice. Restart: npm run jarvis'
Write-Host 'Podcast services are unchanged; use -WithPodcasts to start them after full dependency setup.'
