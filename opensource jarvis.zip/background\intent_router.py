﻿"""
Universal Central Input Router - semantic intent parser for every JARVIS module.

The router is a PURE classifier. It decides WHERE an answer should be shown
(`target_channel_id`), never WHAT gets executed. Execution authority stays in
`background/voice_engine.py:run_command()`, whose cascade already owns the
power guard, confirm gates, duplicate suppression and STT dedupe.

That split is the safety property this module exists to guarantee: a routing
bug can mis-file a message into the wrong panel, but it can never cause a
destructive action, bypass a Safety Guard confirm token, or restart the voice
loop - because the router is never consulted on the execution path.

Transport note: JARVIS has no websockets. The single source of truth is the
`STATE` dict in voice_engine.py, served by `GET /state` and polled by the
dashboard. `channel_revision` is the seq token the browser uses to detect a
focus transition without opening a second transport.
"""
from __future__ import annotations

import re

# --------------------------------------------------------------------------
# Channel registry
# --------------------------------------------------------------------------
# `view` is a real `data-view-panel` value in src/index.tsx.
# `widget` is the element that flashes on arrival; `drawer` is an optional
# tool-drawer key.
CHANNELS = {
    "cowork": {
        "panel": "COWORK_PANEL", "view": "cowork",
        "widget": "cowork-task", "label": "Co-work",
    },
    "agent_workspace": {
        "panel": "AGENT_WORKSPACE", "view": "cowork",
        "widget": "cowork-files", "drawer": "files",
        "label": "Agent Workspace",
    },
    "deep_research": {
        "panel": "DEEP_RESEARCH_PANEL", "view": "web",
        "widget": "web-search-form", "label": "Deep Research",
    },
    "screen_analyzer": {
        "panel": "SCREEN_ANALYZER_PANEL", "view": "vision",
        "widget": "vision-grid", "label": "Screen Analyzer",
    },
    "kamisensei": {
        "panel": "KAMISENSEI_PANEL", "view": "kamisensei",
        "widget": "kamisensei-chat-log", "label": "KamiSensei",
    },
    "study_mode": {
        "panel": "STUDY_MODE", "view": "kamisensei",
        "widget": "ks-sense-metrics", "drawer": "sense",
        "label": "Study Mode",
    },
    "system_health": {
        "panel": "SYSTEM_HEALTH_CARD", "view": "system",
        "widget": "mini-system", "label": "System Health",
    },
    "calendar": {
        "panel": "CALENDAR_REMINDER_WIDGET", "view": "productivity",
        "widget": "reminders-list", "label": "Calendar & Reminders",
    },
    "voice": {
        "panel": "VOICE_PANEL", "view": "voice",
        "widget": "voice-transcript", "label": "Voice Panel",
    },
    "general_chat": {
        "panel": "GENERAL_CHAT_PANEL", "view": "dashboard",
        "widget": "chat-log", "label": "Conversation",
    },
}

# Origin panel -> channel, so casual chat returns to the panel the user was
# actually standing in instead of always dumping to the dashboard.
_PANEL_CHANNEL = {
    "cowork": "cowork", "kamisensei": "kamisensei", "web": "deep_research",
    "vision": "screen_analyzer", "system": "system_health",
    "productivity": "calendar", "voice": "voice",
}

# Route: (channel, weight, pattern). Weights are additive, highest total wins.
# Ties break on list order, so specific channels are listed first. Matched
# against the utterance after the wake word is stripped.
ROUTES = [
    # ── KamiSensei / Japanese / SRS ─────────────────────────────────────
    ("kamisensei", 3, r"\b(?:kamisensei|kami\s?sensei)\b"),
    ("kamisensei", 3, r"(?:日本語|にほんご|nihongo)"),
    ("kamisensei", 3, r"\b(?:bunpro|anki|an\s?ki|srs|spaced\s+repetition)\b"),
    ("kamisensei", 3, r"\b(?:kanji|hiragana|katakana|romaji|vocab(?:ulary)?)\b"),
    ("kamisensei", 3, r"\b(?:jlpt|genki|toeic|n[1235]\s+grammar)\b"),
    ("kamisensei", 2, r"\b(?:grammar|translate|translation)\b.*\b(?:jp|japanese|english|hindi)\b"),
    # A bare language mention is a strong language-learning signal: "how do I
    # say thank you in japanese" is a translation request, not small talk.
    ("kamisensei", 2, r"\b(?:in|into)\s+(?:japanese|hindi|english)\b"),
    ("kamisensei", 2, r"\b(?:japanese|hindi)\s+(?:word|words|phrase|phrases|meaning)\b"),
    ("kamisensei", 2, r"\bhow\s+(?:do|to|can)\s+i\s+say\b.*\b(?:japanese|hindi|english)\b"),
    ("kamisensei", 2, r"\b(?:flash\s?cards?|mnemonic|deck)\b"),
    ("study_mode", 3, r"\b(?:study\s?mode|study\s?session|revision|practice\s?session)\b"),
    ("study_mode", 2, r"\b(?:review\s+(?:my\s+)?(?:cards?|deck|notes?)|memoriz\w*|yaad\s?karo)\b"),
    ("study_mode", 2, r"\b(?:daily\s+goals?|streak|progress\s+analytics)\b"),

    # ── Local code / workspace / MCP / terminal ─────────────────────────
    ("agent_workspace", 3, r"\b(?:mcp|model\s+context\s+protocol)\b"),
    ("agent_workspace", 3, r"\b(?:terminal|powershell|bash|console|cli)\b"),
    ("agent_workspace", 3, r"\b(?:repo|repository|code\s?base|src\s+folder|project\s+files?)\b"),
    ("agent_workspace", 2, r"\b(?:open|read|show|list)\s+(?:the\s+)?files?\b"),
    ("agent_workspace", 2, r"\b(?:file\s+tree|directory\s+(?:listing|structure)|folder\s+(?:tree|structure))\b"),
    ("cowork", 3, r"\b(?:co\s?-?work|multi\s?-?agent|sub\s?-?agents?)\b"),
    ("cowork", 2, r"\b(?:delegate|orchestrate|spawn\s+(?:an?\s+)?agent|pipeline)\b"),
    ("cowork", 2, r"\b(?:build|create|write|refactor|implement|fix|debug)\b.*\b(?:script|program|module|function|class|app|feature|test)\b"),
    ("cowork", 2, r"\b(?:skill|tool)\s+(?:registry|catalog|run|invoke)\b"),

    # ── Web crawling / deep research / PDF ──────────────────────────────
    ("deep_research", 3, r"\b(?:deep\s+research|research\s+(?:on|about|into))\b"),
    ("deep_research", 3, r"\b(?:crawl|crawler|scrap\w+|firecrawl)\b"),
    ("deep_research", 3, r"\b(?:pdf|parse\s+(?:the\s+)?(?:pdf|document)|document\s+analysis)\b"),
    ("deep_research", 2, r"\b(?:search\s+(?:the\s+)?web|web\s+search|google\s+search|look\s+up)\b"),
    ("deep_research", 2, r"\b(?:compare|analyz\w+|summariz\w+|find\s+(?:me\s+)?(?:articles?|papers?|sources?))\b"),
    ("deep_research", 2, r"\b(?:latest\s+news|today'?s?\s+news|current\s+affairs)\b"),

    # ── System vision / desktop snapshot ────────────────────────────────
    ("screen_analyzer", 4, r"\bwhat'?s\s+(?:on\s+)?my\s+screen\b"),
    ("screen_analyzer", 4, r"\bwhat\s+is\s+(?:on\s+)?my\s+screen\b"),
    ("screen_analyzer", 4, r"\b(?:analyz\w+|read|describe|what'?s\s+happening)\b.*\bscreen\b"),
    ("screen_analyzer", 3, r"\b(?:on\s+)?(?:my\s+)?screen\s+(?:shot|snapshot|analysis)\b"),
    ("screen_analyzer", 3, r"\bdesktop\s+(?:snapshot|screen)\b"),
    ("screen_analyzer", 2, r"\b(?:screen\s?shot|screen\s?capture|grab\s+(?:my\s+)?(?:the\s+)?screen)\b"),
    ("screen_analyzer", 3, r"\b(?:this\s+(?:window|page|error\s+message)|current\s+(?:window|page))\b"),
    ("screen_analyzer", 2, r"\b(?:gaze|\bocr\b|on\s?-?screen\s+text|highlighted\s+text)\b"),

    # ── Hardware metrics / telemetry ────────────────────────────────────
    ("system_health", 4, r"\b(?:cpu|ram|memory\s+usage|gpu|disk|battery)\b"),
    ("system_health", 4, r"\b(?:system\s+info|hardware\s+(?:info|stats|metrics))\b"),
    ("system_health", 3, r"\b(?:telemetry|temperature|fan\s+speed|overclock|thermal)\b"),
    ("system_health", 3, r"\bhow\s+(?:much|many)\s+(?:ram|memory|cpu|disk|battery)\b"),
    ("system_health", 2, r"\b(?:performance\s+(?:stats|metrics)|vitals|health\s+check|resource\s+usage)\b"),

    # ── Reminders / alarms / schedules ──────────────────────────────────
    ("calendar", 4, r"\b(?:remind\s+me|set\s+a\s+reminder|reminder)\b"),
    ("calendar", 4, r"\b(?:alarm|scheduled?\s+task|schedule\s+(?:a|an|for))\b"),
    ("calendar", 3, r"\b(?:appointment|calendar|agenda|deadline|due\s+date)\b"),
    ("calendar", 2, r"\b(?:meeting|call)\s+(?:at|on)\b"),
    ("calendar", 2, r"\b(?:in\s+\d+\s*(?:min|minute|hour|day)s?|tomorrow|today\s+at|tonight\s+at)\b"),
    ("calendar", 2, r"\b(?:don'?t\s+let\s+me\s+forget|note\s+down|set\s+a?\s*timer)\b"),

    # ── Voice panel ─────────────────────────────────────────────────────
    ("voice", 3, r"\bvoice\s+(?:panel|command\s+settings|control|mode|settings)\b"),
    ("voice", 2, r"\b(?:wake\s+word|continuous\s+listening|mic\s+(?:level|check|test))\b"),
]

_COMPILED = [(ch, w, re.compile(p, re.IGNORECASE)) for ch, w, p in ROUTES]

# STRUCTURAL EXCLUSIONS. These are already fully owned by the execution
# cascade in run_command. Re-routing them would be actively harmful: a
# destructive OS command must never light up the calendar panel, and a Safety
# Guard confirmation must always render where the user is looking. Matching
# any of these forces general_chat / the originating panel.
_EXCLUSION = re.compile(
    r"\b(?:shutdown|shut\s+down|restart|reboot|factory\s+reset|log\s?off|"
    r"format|erase|wipe|uninstall|kill\s+process|delete\s+file)\b",
    re.IGNORECASE,
)

# CIRCULAR-LOOP GUARD. A tool response (research report, cortex plan, file
# listing) contains words like "kanji" or "schedule" purely as CONTENT. If
# that text were re-fed to the router it would bounce the UI into a second
# panel mid-stream. The engine stamps tool replies with ECHO_SENTINEL; the
# regex also catches raw tool_result envelopes for defence in depth.
ECHO_SENTINEL = "\x00jarvis-tool-echo\x00"

_LOOP_GUARD = re.compile(
    r"(?:\x00jarvis-tool-echo|"
    r"^\s*tool_result(?:_json)?\s*:|"
    r"^\s*\[jarvis:route\]|"
    r"routing\s+decision\s*:)",
    re.IGNORECASE,
)


def strip_wake_words(text):
    """Remove a leading 'hey jarvis' in any supported script.

    Mirrors voice_engine.strip_wake but is duplicated so this module stays
    importable standalone (voice_engine pulls in sounddevice/requests, which
    must not be a test-time dependency of a pure classifier).
    """
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    patterns = (
        r"^(?:hey|hi|hello|ok|okay|yo)\s+jarvis[,.]?\s*",
        r"^jarvis\b[,.]?\s*",
        r"^(?:हे|हाय|ओके)\s*(?:जार्विस|जारविस)[,।]?\s*",
        r"^(?:ねえ|ヘイ|はい|ハイ|オーケー)?\s*(?:ジャービス|ジャーヴィス)[,.、]?\s*",
    )
    for pattern in patterns:
        stripped = re.sub(pattern, "", value, flags=re.IGNORECASE)
        if stripped != value:
            value = stripped.strip()
    return value


def is_tool_echo(text):
    """True when `text` is a tool/agent response, not a user utterance.

    Guards against circular routing: a tool result that re-enters the router
    must never trigger a second feature panel.
    """
    return bool(_LOOP_GUARD.search(str(text or "")))


def _origin_channel(source_panel_id):
    """Map a frontend panel/view id to its channel, defaulting to chat."""
    key = str(source_panel_id or "").strip().lower()
    if key in CHANNELS:
        return key
    return _PANEL_CHANNEL.get(key, "general_chat")


def _decision(channel, source_panel_id, confidence, reason,
              scores=None, guarded=False):
    meta = CHANNELS.get(channel) or CHANNELS["general_chat"]
    return {
        "channel": channel,
        "target_channel_id": channel,
        "panel": meta["panel"],
        "view": meta["view"],
        "widget": meta.get("widget", ""),
        "drawer": meta.get("drawer", ""),
        "label": meta.get("label", ""),
        "confidence": confidence,
        "scores": scores or {},
        "reason": reason,
        "source_panel_id": str(source_panel_id or ""),
        "guarded": guarded,
    }


def classify_intent(user_prompt, source_panel_id=None):
    """Score one utterance against every channel and return a decision dict.

    Order of rules:
      1. circular-loop guard (tool echoes never re-route)
      2. safety exclusion (destructive/confirm-gated stays put)
      3. weighted structural scoring (ties -> origin panel)
    """
    raw = str(user_prompt or "")
    origin = _origin_channel(source_panel_id)

    if is_tool_echo(raw):
        return _decision(origin, source_panel_id, 0.0,
                         "tool echo - routing suppressed", guarded=True)

    if _EXCLUSION.search(raw):
        return _decision(origin, source_panel_id, 0.0,
                         "safety-excluded - answer stays in the active panel",
                         guarded=True)

    text = strip_wake_words(raw)
    if not text:
        return _decision(origin, source_panel_id, 0.0, "empty utterance")

    scores = {}
    for channel, weight, pattern in _COMPILED:
        if pattern.search(text):
            scores[channel] = scores.get(channel, 0) + weight

    if not scores:
        return _decision(origin, source_panel_id, 0.0,
                         "no module intent - conversational reply to origin panel")

    best_score = max(scores.values())
    tied = sorted(k for k, v in scores.items() if v == best_score)
    # A genuine tie means the utterance is ambiguous across modules; sending
    # it back to the panel the user is standing in is safer than guessing.
    if len(tied) > 1:
        return _decision(origin, source_panel_id, 0.25,
                         "ambiguous intent (%s) - kept in origin panel"
                         % "/".join(tied), scores=scores)

    channel = tied[0]
    others = [v for k, v in scores.items() if k != channel]
    runner_up = max(others) if others else 0
    # Confidence is margin over the runner-up, so a near-tie scores low and
    # the UI can avoid a jarring panel jump.
    confidence = round(min(1.0, (best_score - runner_up + 1) / float(best_score + 1)), 3)
    return _decision(channel, source_panel_id, confidence,
                     "matched %s (score %d)" % (channel, best_score),
                     scores=scores)


def route_global_input(user_prompt, source_panel_id=None):
    """Public entry point: classify one input and return the routing decision.

    `source_panel_id` is the panel the input originated from (voice orb, HUD,
    dashboard composer, KamiSensei box). Casual chat returns to that panel.
    """
    try:
        return classify_intent(user_prompt, source_panel_id)
    except Exception:
        # The router must NEVER break the voice loop. On any internal error
        # fall back to the originating panel with a zero-confidence route.
        return _decision(_origin_channel(source_panel_id), source_panel_id,
                         0.0, "classifier error - safe fallback", guarded=True)


def stamp_echo(text):
    """Mark tool output so it can never re-trigger a feature panel."""
    return ECHO_SENTINEL + str(text or "")


def strip_echo(text):
    """Remove the echo sentinel before text is spoken or displayed."""
    return str(text or "").replace(ECHO_SENTINEL, "")


def channel_view(channel):
    """Frontend `data-view-panel` for a channel id."""
    return (CHANNELS.get(str(channel or "")) or CHANNELS["general_chat"])["view"]

