"""Battery & telemetry: honest local machine health, stdlib + psutil.

This backs the "Battery & Telemetry" catalog card. It is deliberately honest:

  * every number comes from a real probe at call time
  * battery is reported as UNAVAILABLE when the platform cannot supply it.
    `psutil.sensors_battery()` returns None on most Windows laptops, so the UI
    must never show a fake percentage - it shows "unavailable on this device".
  * top processes are sampled from real psutil process info, never invented.

No network, no new dependency (psutil is already in requirements.txt).
"""
from __future__ import annotations

import os
import platform
import shutil
import time
from pathlib import Path


def _psutil():
    try:
        import psutil  # type: ignore
        return psutil
    except Exception:
        return None


def _round(value, digits=1):
    try:
        return round(float(value), digits)
    except (TypeError, ValueError):
        return None


def battery() -> dict:
    """Real battery state, or an honest 'unavailable' with the reason."""
    psutil = _psutil()
    out = {"supported": False, "available": False, "reason": "",
           "percent": None, "plugged": None, "seconds_left": None}
    if psutil is None:
        out["reason"] = "psutil is not installed in this environment"
        return out
    out["supported"] = True
    try:
        sensors = getattr(psutil, "sensors_battery", None)
        raw = sensors() if callable(sensors) else None
    except Exception as exc:
        out["reason"] = "battery probe failed: %s" % type(exc).__name__
        return out
    if raw is None:
        out["reason"] = ("this platform does not expose a battery "
                         "(desktop or driver does not report one)")
        return out
    out["available"] = True
    out["percent"] = _round(getattr(raw, "percent", None))
    out["plugged"] = getattr(raw, "power_plugged", None)
    secs = getattr(raw, "secsleft", None)
    out["seconds_left"] = int(secs) if isinstance(secs, (int, float)) and secs > 0 else None
    return out


def cpu() -> dict:
    """Per-core utilisation sampled over a real (short) interval."""
    psutil = _psutil()
    if psutil is None:
        return {"available": False, "reason": "psutil is not installed"}
    try:
        per_core = psutil.cpu_percent(interval=0.12, percpu=True)
        overall = psutil.cpu_percent(interval=None)
    except Exception as exc:
        return {"available": False, "reason": "cpu probe failed: %s" % type(exc).__name__}
    cores = [_round(v) for v in per_core]
    load = None
    try:
        load = [_round(v) for v in psutil.getloadavg()]
    except (AttributeError, OSError):
        load = None
    return {"available": True, "reason": "", "percent": _round(overall),
            "cores": cores, "physical": psutil.cpu_count(logical=False),
            "logical": psutil.cpu_count(logical=True), "loadavg": load}


def memory() -> dict:
    psutil = _psutil()
    if psutil is None:
        return {"available": False, "reason": "psutil is not installed"}
    try:
        vm = psutil.virtual_memory()
        sw = psutil.swap_memory()
    except Exception as exc:
        return {"available": False, "reason": "memory probe failed: %s" % type(exc).__name__}
    return {"available": True, "reason": "",
            "total_gb": _round(vm.total / (1024 ** 3), 2),
            "used_gb": _round(vm.used / (1024 ** 3), 2),
            "available_gb": _round(getattr(vm, "available", 0) / (1024 ** 3), 2),
            "percent": _round(vm.percent),
            "swap_used_gb": _round(getattr(sw, "used", 0) / (1024 ** 3), 2)}


def disks() -> list:
    """Real usage per fixed drive. Never invents a drive that is not there."""
    psutil = _psutil()
    rows = []
    if psutil is not None:
        try:
            for part in psutil.disk_partitions(all=False):
                if not str(getattr(part, "mountpoint", "")).endswith("\\"):
                    continue
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                except (PermissionError, OSError):
                    continue
                rows.append({"drive": part.mountpoint,
                             "fstype": part.fstype or "",
                             "total_gb": _round(usage.total / (1024 ** 3), 1),
                             "used_gb": _round(usage.used / (1024 ** 3), 1),
                             "free_gb": _round(usage.free / (1024 ** 3), 1),
                             "percent": _round(usage.percent)})
        except Exception:
            rows = []
    if not rows:                                   # last-resort, still real
        drive = os.environ.get("SystemDrive", "C:\\")
        try:
            usage = shutil.disk_usage(drive)
            rows.append({"drive": drive, "fstype": "",
                         "total_gb": _round(usage.total / (1024 ** 3), 1),
                         "used_gb": _round(usage.used / (1024 ** 3), 1),
                         "free_gb": _round(usage.free / (1024 ** 3), 1),
                         "percent": _round(usage.used / max(1, usage.total) * 100.0)})
        except Exception:
            pass
    return rows


def top_processes(limit: int = 6) -> list:
    """Real process sample. Names and CPU% come from psutil, nothing else."""
    psutil = _psutil()
    if psutil is None:
        return []
    limit = max(1, min(20, int(limit or 6)))
    try:
        procs = list(psutil.process_iter(["pid", "name", "cpu_percent",
                                           "memory_percent"]))
    except Exception:
        return []
    rows = []
    for proc in procs:
        try:
            info = proc.info
            rows.append({"pid": int(info.get("pid") or 0),
                         "name": str(info.get("name") or "?")[:64],
                         "cpu_percent": _round(info.get("cpu_percent")),
                         "memory_percent": _round(info.get("memory_percent"))})
        except Exception:
            continue
    # The first cpu_percent() sample per process is always 0.0, so rank by
    # memory for the first sample instead of pretending we know CPU usage yet.
    rows.sort(key=lambda r: (r.get("memory_percent") or 0.0), reverse=True)
    return rows[:limit]


def system() -> dict:
    """Full snapshot used by the telemetry tool and the Modules page."""
    uptime = None
    psutil = _psutil()
    if psutil is not None:
        try:
            uptime = round(time.time() - psutil.boot_time())
        except Exception:
            uptime = None
    return {"ok": True, "source": "local", "at": time.time(),
            "host": {"platform": platform.platform(),
                     "system": platform.system(), "release": platform.release(),
                     "python": platform.python_version(), "uptime_s": uptime},
            "battery": battery(), "cpu": cpu(), "memory": memory(),
            "disks": disks(), "processes": top_processes()}


def describe() -> str:
    """Spoken one-liner for the voice route."""
    snap = system()
    cpu_pct = (snap.get("cpu") or {}).get("percent")
    mem = snap.get("memory") or {}
    bat = snap.get("battery") or {}
    parts = []
    if cpu_pct is not None:
        parts.append("CPU %d percent" % int(cpu_pct))
    if mem.get("percent") is not None:
        parts.append("RAM %d percent used" % int(mem["percent"]))
    if bat.get("available") and bat.get("percent") is not None:
        parts.append("battery %d percent" % int(bat["percent"]))
    else:
        parts.append("battery not reported by this device")
    return ("Sir, telemetry: %s." % ", ".join(parts)) if parts \
        else "Telemetry unavailable, Sir."


def _tool_snapshot(args: dict) -> dict:
    return {"ok": True, "output": describe(), "data": system()}


def _tool_top(args: dict) -> dict:
    limit = 6
    try:
        limit = int((args or {}).get("limit") or 6)
    except (TypeError, ValueError):
        pass
    rows = top_processes(limit)
    if not rows:
        return {"ok": False, "output": "process list unavailable (psutil missing?)"}
    return {"ok": True,
            "output": "Sir, top processes: " + ", ".join(
                "%s at %s%% memory" % (r["name"], r["memory_percent"])
                for r in rows[:5]),
            "data": {"ok": True, "source": "local", "count": len(rows),
                     "processes": rows}}


def specs() -> list:
    """cortex ToolSpec list. Read-only, so never confirm-gated."""
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("telemetry_snapshot",
                        "Real local CPU/RAM/disk/process/battery snapshot.",
                        _tool_snapshot, parameters={},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("telemetry", "system")),
        cortex.ToolSpec("telemetry_top_processes",
                        "Top local processes by memory, sampled live.",
                        _tool_top, parameters={"limit": "how many rows (1-20)"},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("telemetry", "system")),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()


