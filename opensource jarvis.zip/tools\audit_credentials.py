"""One-shot credential audit. Probes every configured provider and prints a
masked report. NEVER prints a raw key. Read-only: makes no config changes.

Run: .venv/Scripts/python.exe tools/audit_credentials.py
"""
import os
import sys
import json
import importlib.util
import urllib.request
import urllib.error

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)
try:
    from dotenv import dotenv_values as _dv
    for _f in (".env", ".dev.vars"):
        for _k, _v in _dv(os.path.join(_ROOT, _f)).items():
            if _v and not os.environ.get(_k):
                os.environ[_k] = _v
except Exception:
    pass


def mask(v):
    v = (v or "").strip()
    if not v:
        return "(empty)"
    if len(v) <= 8:
        return "***"
    return "%s...%s (len %d)" % (v[:6], v[-4:], len(v))


def probe(url, headers, method="GET", payload=None, timeout=20):
    """Return (state, detail). Never raises."""
    try:
        data = json.dumps(payload).encode() if payload else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return "LIVE", "HTTP %s" % resp.status
    except urllib.error.HTTPError as exc:
        code, body = exc.code, exc.read()[:200].decode("utf-8", "ignore")
        if code in (401, 403):
            return "INVALID", "HTTP %s - key rejected" % code
        if code == 402:
            return "NO_CREDIT", "HTTP 402 - out of credits"
        if code == 429:
            return "RATE_LIMIT", "HTTP 429 - rate limited (key likely valid)"
        if 500 <= code < 600:
            return "UPSTREAM_ERR", "HTTP %s - provider 5xx, not key's fault" % code
        return "HTTP_%s" % code, body[:80]
    except Exception as exc:
        return "NET_ERR", "%s: %s" % (type(exc).__name__, str(exc)[:70])


ROWS = []


def add(name, var, state, detail, extra=""):
    ROWS.append((name, var, mask(os.environ.get(var, "")), state, detail, extra))


# ── Google Gemini (two independent keys) ─────────────────────────────────
for idx, var in ((1, "GOOGLE_API_KEY"), (2, "GOOGLE_API_KEY_2")):
    key = os.environ.get(var, "")
    if not key:
        add("Google Gemini #%d" % idx, var, "MISSING", "not configured")
        continue
    st, det = probe("https://generativelanguage.googleapis.com/v1beta/models?key=" + key,
                    {"Content-Type": "application/json"})
    add("Google Gemini #%d" % idx, var, st, det,
        "model=%s" % os.environ.get("GOOGLE_MODEL", "?"))

# ── Groq: primary LLM + cloud STT ────────────────────────────────────────
key = os.environ.get("GROQ_API_KEY", "")
if not key:
    add("Groq (LLM+STT)", "GROQ_API_KEY", "MISSING", "not configured")
else:
    st, det = probe("https://api.groq.com/openai/v1/models",
                    {"Authorization": "Bearer " + key})
    add("Groq (LLM+STT)", "GROQ_API_KEY", st, det,
        "model=%s | whisper=%s" % (os.environ.get("GROQ_MODEL", "?"),
                                   os.environ.get("GROQ_VISION_MODEL", "?")))

# ── OpenRouter ───────────────────────────────────────────────────────────
key = os.environ.get("OPENROUTER_API_KEY", "")
if not key:
    add("OpenRouter", "OPENROUTER_API_KEY", "MISSING", "not configured")
else:
    st, det = probe("https://openrouter.ai/api/v1/auth/key",
                    {"Authorization": "Bearer " + key})
    add("OpenRouter", "OPENROUTER_API_KEY", st, det,
        "model=%s" % os.environ.get("OPENROUTER_MODEL", "?"))

# ── xKiro ────────────────────────────────────────────────────────────────
key = os.environ.get("XKIRO_API_KEY", "")
if not key:
    add("xKiro", "XKIRO_API_KEY", "MISSING", "not configured")
else:
    add("xKiro", "XKIRO_API_KEY", "SET",
        "no public probe; used via openai-compatible route",
        "model=%s" % os.environ.get("XKIRO_MODEL", "?"))

# ── NVIDIA NIM ───────────────────────────────────────────────────────────
key = os.environ.get("NVIDIA_API_KEY", "")
if not key:
    add("NVIDIA NIM", "NVIDIA_API_KEY", "MISSING", "not configured")
else:
    st, det = probe("https://integrate.api.nvidia.com/v1/models",
                    {"Authorization": "Bearer " + key})
    add("NVIDIA NIM", "NVIDIA_API_KEY", st, det,
        "models: %s" % ",".join(m for m in (
            os.environ.get("NVIDIA_MODEL"), os.environ.get("NVIDIA_VISION_MODEL"),
            os.environ.get("NVIDIA_CODE_MODEL"), os.environ.get("NVIDIA_FAST_MODEL")) if m))

# ── Firecrawl multi-key pool ─────────────────────────────────────────────
_spec = importlib.util.spec_from_file_location(
    "fc_audit", os.path.join(_ROOT, "background", "firecrawl_client.py"))
FC = importlib.util.module_from_spec(_spec)
sys.modules["fc_audit"] = FC
_spec.loader.exec_module(FC)
try:
    snap = FC.key_pool_status()
    for i, row in enumerate(snap.get("keys", []), 1):
        state = "PARKED-CREDITS" if row["parked"] else "LIVE"
        detail = ("cooldown %ds: %s" % (row["cooldown_s"], row["reason"][:50])
                  if row["parked"] else "usable (uses=%d ok=%d)" % (row["uses"], row["ok"]))
        ROWS.append(("Firecrawl key #%d" % i, "FIRECRAWL_API_KEY[_N]",
                     row["slot"], state, detail,
                     "fanout=%s healthy=%d/%d" % (snap.get("fanout"),
                                                  snap.get("healthy"), snap.get("total"))))
except Exception as exc:
    add("Firecrawl pool", "FIRECRAWL_API_KEY", "PROBE_ERR", str(exc)[:80])

# ── Optional / situational providers ─────────────────────────────────────
add("Weather", "WEATHER_API_KEY",
    "SET" if os.environ.get("WEATHER_API_KEY") else "MISSING",
    "OpenWeather - weather lookup" if os.environ.get("WEATHER_API_KEY") else "not configured")
add("Mem0", "MEM0_API_KEY",
    "SET" if os.environ.get("MEM0_API_KEY") else "MISSING",
    "optional cloud memory mirror" if os.environ.get("MEM0_API_KEY")
    else "absent - local memory store used instead")
add("LiveKit", "LIVEKIT_API_KEY",
    "SET" if os.environ.get("LIVEKIT_API_KEY") else "MISSING",
    "optional realtime voice" if os.environ.get("LIVEKIT_API_KEY")
    else "absent - browser Web Speech used instead")

W = "{:<20} {:<24} {:<32} {:<15} {}"
print(W.format("PROVIDER", "ENV VAR", "MASKED VALUE", "STATE", "DETAIL"))
print("-" * 128)
for name, var, masked, state, detail, extra in ROWS:
    print(W.format(name, var, masked, state, detail[:42]))
    if extra:
        print(" " * 96 + extra)
json.dump([{"provider": n, "var": v, "masked": m, "state": s, "detail": d, "extra": e}
           for n, v, m, s, d, e in ROWS],
          open(os.path.join(_ROOT, "temp", "credential_audit.json"), "w"), indent=1)
print("\nwrote temp/credential_audit.json")


def add(name, var, state, detail, extra=""):
    ROWS.append((name, var, mask(os.environ.get(var, "")), state, detail, extra))
