# -*- coding: utf-8 -*-
"""_dirmap.py — compact map of a directory tree (dirs only, depth-limited)."""
import os, sys

root = sys.argv[1] if len(sys.argv) > 1 else '.'
skip = {'node_modules', '.git', '.venv', '__pycache__', '.cache', '.n8n', 'models', 'knowledge_base', 'artifacts', 'dist', '.wrangler', 'ethanplusai-jarvis', 'public/static'}
depth = 0 if len(sys.argv) < 3 else int(sys.argv[2])

def show(path, depth):
    try:
        entries = sorted(os.listdir(path))
    except Exception as e:
        print('ERR ' + path + ' ' + str(e)); return
    for e in entries:
        p = os.path.join(path, e)
        if os.path.isdir(p):
            if depth > 0 and path.count(os.sep) >= depth:
                continue
            print('D ' + p.replace('\\', '/'))
            if depth > 0:
                show(p, depth)

for d in sys.argv[3:] or ['.']:
    p = os.path.join(root, d) if d != '.' else root
    if os.path.isdir(p):
        print('## ' + p.replace('\\', '/'))
        show(p, depth)
