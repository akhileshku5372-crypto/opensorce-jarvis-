/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SubsystemInfo, BrainNode } from '../../types/jarvis';
import {
  X,
  Zap,
  Activity,
  Layers,
  ShieldCheck,
  Cpu,
  Clock,
  ArrowRight,
  Wrench,
} from 'lucide-react';
import { soundFx } from '../../services/soundEffects';

interface NodeDetailDrawerProps {
  subsystem: SubsystemInfo | null;
  node: BrainNode | null;
  onClose: () => void;
  onStimulateNode: () => void;
}

export const NodeDetailDrawer: React.FC<NodeDetailDrawerProps> = ({
  subsystem,
  node,
  onClose,
  onStimulateNode,
}) => {
  if (!subsystem) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-80 sm:w-96 bg-slate-950/95 border-l border-cyan-500/30 backdrop-blur-xl shadow-2xl z-50 flex flex-col transition-transform duration-300 animate-in slide-in-from-right font-rajdhani">
      {/* Drawer Header */}
      <div className="flex items-center justify-between p-4 border-b border-cyan-500/20 bg-cyan-950/20">
        <div className="flex items-center gap-2.5">
          <div
            className="w-3 h-3 rounded-full animate-pulse"
            style={{ backgroundColor: subsystem.color, boxShadow: `0 0 10px ${subsystem.color}` }}
          />
          <div>
            <h3 className="font-orbitron font-bold text-sm text-white tracking-wider">
              {subsystem.title} ARCHITECTURE
            </h3>
            <span className="text-xs text-cyan-300/80 font-rajdhani">
              {subsystem.lobeRegion}
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            onClose();
            soundFx.playChirp();
          }}
          className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Drawer Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Status & Firing Metrics */}
        <div className="grid grid-cols-2 gap-2">
          <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Activity className="w-3 h-3 text-cyan-400" /> Synaptic Rate
            </div>
            <div className="text-lg font-mono-code font-bold text-cyan-300 mt-1">
              {subsystem.synapticRateHz} <span className="text-xs font-normal">Hz</span>
            </div>
            <div className="text-[10px] text-emerald-400">Firing Optimal</div>
          </div>

          <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-400" /> Latency
            </div>
            <div className="text-lg font-mono-code font-bold text-amber-300 mt-1">
              {subsystem.latencyMs} <span className="text-xs font-normal">ms</span>
            </div>
            <div className="text-[10px] text-slate-400">Live Telemetry</div>
          </div>
        </div>

        {/* Purpose & Architecture */}
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
          <div className="text-xs font-semibold text-cyan-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5" /> Subsystem Purpose
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            {subsystem.description}
          </p>
        </div>

        {/* Connected Models & Providers (.env mapping) */}
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
          <div className="text-xs font-semibold text-purple-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" /> Models & Runtime Providers
          </div>
          <div className="space-y-1.5 font-mono-code text-xs">
            {subsystem.models.map((mod, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-1.5 rounded bg-black/40 border border-purple-500/20"
              >
                <span className="text-slate-200">{mod}</span>
                <span className="text-[10px] text-emerald-400 px-1 rounded bg-emerald-950/60 border border-emerald-500/30">
                  Ready
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Registered Capabilities & Tools */}
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
          <div className="text-xs font-semibold text-emerald-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Wrench className="w-3.5 h-3.5" /> Registered Tools & MCPs
          </div>
          <div className="flex flex-wrap gap-1.5">
            {subsystem.registeredTools.map((tool, i) => (
              <span
                key={i}
                className="text-[11px] font-mono-code px-2 py-0.5 rounded bg-slate-800/80 text-emerald-300 border border-emerald-500/20"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>

        {/* Last Relevant Event */}
        <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
            Last Recorded Event
          </div>
          <div className="text-xs text-slate-200 font-mono-code bg-black/50 p-2 rounded border border-slate-800">
            {subsystem.recentAction}
          </div>
        </div>

        {/* Security & Secret Masking Indicator */}
        <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <div className="text-[11px] text-emerald-300">
            Credentials masked. Secrets stored in local runtime environment.
          </div>
        </div>
      </div>

      {/* Drawer Action Footer */}
      <div className="p-4 border-t border-cyan-500/20 bg-slate-950/90 flex gap-2">
        <button
          onClick={() => {
            onStimulateNode();
            soundFx.playPulse();
          }}
          className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-orbitron font-semibold text-xs transition-all shadow-[0_0_15px_rgba(6,182,212,0.4)]"
        >
          <Zap className="w-3.5 h-3.5" /> Stimulate Action Potential
        </button>
      </div>
    </div>
  );
};
