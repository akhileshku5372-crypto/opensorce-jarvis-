// HIT /api/tts on the running jarvis-ui and report which edge-tts voice was selected.
const cases = [
  ['mixed', { text: 'नमस्ते please こんにちは', lang: 'auto' }],
  ['hindi', { text: 'आप कैसे हैं आज तो मतलब', lang: 'hi' }],
  ['japanese', { text: 'こんにちは、元気ですね。', lang: 'ja' }],
  ['english', { text: 'Hello JARVIS, status report', lang: 'en' }],
  ['hinglish-latin', { text: 'kal meeting 9 baje hai na', lang: 'hinglish' }],
]
for (const [name, body] of cases) {
  try {
    const r = await fetch('http://127.0.0.1:7777/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    // Read headers first (blob is the audio body)
    const voice = r.headers.get('X-TTS-Voice') || r.headers.get('x-tts-voice') || '(no X-TTS-Voice → fell through to a downstream engine)'
    let len = r.headers.get('content-length')
    if (!len) { try { const b = await r.blob(); len = `${Math.round(b.size/1024)}KB` } catch { len = '?' } }
    console.log(`${name.padEnd(16)} -> HTTP ${r.status} | voice: ${voice} | audio: ${len}`)
  } catch (e) {
    console.log(`${name.padEnd(16)} -> fetch error: ${e.message}`)
  }
}
