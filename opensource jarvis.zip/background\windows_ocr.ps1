# Windows.Media.Ocr helper for JARVIS Live Screen.
#
# The JPEG frame is base64 on stdin and decoded into an in-memory WinRT stream:
# no screenshot, no OCR text and no temp file ever touch the disk.
# Output is UTF-8 text on stdout; a failure exits non-zero and writes the
# reason to stderr so the caller can report exactly what went wrong.

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'

try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.Streams.DataWriter, Windows.Foundation, ContentType = WindowsRuntime]

    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        })[0]

    function Await($WinRtTask, $ResultType) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
        $netTask.Result
    }

    $b64 = [Console]::In.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($b64)) {
        [Console]::Error.WriteLine('OCR_ERROR: no image data on stdin')
        exit 3
    }

    try {
        $bytes = [Convert]::FromBase64String($b64.Trim())
    } catch {
        [Console]::Error.WriteLine('OCR_ERROR: image is not valid base64')
        exit 4
    }

    $memory = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
    $writer = New-Object Windows.Storage.Streams.DataWriter($memory)
    $writer.WriteBytes($bytes)
    $null = Await ($writer.StoreAsync()) ([UInt32])
    $null = Await ($writer.FlushAsync()) ([Boolean])
    $null = $writer.DetachStream()
    $null = $memory.Seek(0)

    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($memory)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if (-not $engine) {
        $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage('en-US')
    }
    if (-not $engine) {
        [Console]::Error.WriteLine('OCR_ENGINE_UNAVAILABLE: install a Windows OCR language pack')
        exit 2
    }

    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $lines = @($result.Lines | ForEach-Object { $_.Text })
    [Console]::Out.Write(($lines -join "`n"))
} catch {
    [Console]::Error.WriteLine(('OCR_ERROR: ' + $_.Exception.Message))
    exit 5
}
