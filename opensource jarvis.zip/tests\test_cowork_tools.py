"""Cowork OS executor + browser agent tests (stdlib only, no network).

os_executor never touches the shell for read/list/write; os_run_command
uses locked argv on allowlisted ops only. browser_agent talks to the
Firecrawl client module, which tests stub out (koi network nahi).
"""
import importlib.util
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = ROOT / "background"


def _load(name):
    spec = importlib.util.spec_from_file_location(name, BACKGROUND / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


CORTEX = _load("cortex")
OSEXEC = _load("os_executor")
BROWSER = _load("browser_agent")
COWORK_TOOLS = _load("cowork_tools")


class OsExecutorTest(unittest.TestCase):
    def test_read_refuses_outside_repo_and_secrets(self):
        self.assertFalse(OSEXEC.tool_read_file({"path": "../package.json"})["ok"])
        self.assertFalse(OSEXEC.tool_read_file({"path": ".env"})["ok"])
        self.assertFalse(OSEXEC.tool_read_file({"path": ".git/config"})["ok"])

    def test_read_and_list_inside_repo(self):
        got = OSEXEC.tool_read_file({"path": "package.json"})
        self.assertTrue(got["ok"], got)
        self.assertIn("jarvis", got["output"].lower())
        listed = OSEXEC.tool_list_files({"path": "skills"})
        self.assertTrue(listed["ok"], listed)
        self.assertIn("daily-briefing/", listed["output"])

    def test_write_reports_success_and_cleans_up(self):
        target = ROOT / "artifacts" / "executor-test.txt"
        try:
            got = OSEXEC.tool_write_file({"path": "artifacts/executor-test.txt",
                                          "content": "hello jarvis"})
            self.assertTrue(got["ok"], got)
            self.assertEqual(target.read_text(encoding="utf-8"), "hello jarvis")
        finally:
            try:
                target.unlink()
            except FileNotFoundError:
                pass

    def test_write_accepts_common_mode_aliases(self):
        target = ROOT / "artifacts" / "executor-alias-test.txt"
        try:
            got = OSEXEC.tool_write_file({"path": "artifacts/executor-alias-test.txt",
                                          "content": "alias ok", "mode": "w"})
            self.assertTrue(got["ok"], got)
            self.assertEqual(target.read_text(encoding="utf-8"), "alias ok")
        finally:
            try:
                target.unlink()
            except FileNotFoundError:
                pass

    def test_run_command_rejects_arbitrary_ops(self):
        got = OSEXEC.tool_run_command({"op": "rm -rf /"})
        self.assertFalse(got["ok"])
        self.assertIn("allowlist", got["output"])

    def test_search_is_bounded_and_blocks_secrets(self):
        got = OSEXEC.tool_search_text({"query": "jarvis", "path": "background"})
        self.assertTrue(got["ok"], got)
        self.assertIn("background/", got["output"])
        denied = OSEXEC.tool_search_text({"query": "KEY", "path": ".env"})
        self.assertFalse(denied["ok"])

    def test_run_command_allowlist_is_locked(self):
        self.assertIn("git_status", OSEXEC.allowed_ops())
        self.assertIn("python_tests", OSEXEC.allowed_ops())
        argv, error = OSEXEC._argv_for("git_status")
        self.assertEqual(error, "")
        self.assertEqual(argv, ["git", "status", "--short"])
        self.assertEqual(OSEXEC._argv_for("rm -rf /")[0], None)

    def test_specs_write_command_and_open_are_confirm_gated(self):
        gated = {s.name for s in OSEXEC.specs() if s.requires_confirmation}
        self.assertEqual(gated, {"os_write_file", "os_run_command", "os_open_file"})


class BrowserAgentTest(unittest.TestCase):
    def _stub_firecrawl(self, search=None, extract=None):
        class Stub:
            @staticmethod
            def search(topic, max_results=5):
                return search

            @staticmethod
            def research(topic):
                return search

            @staticmethod
            def extract(url):
                return extract
        BROWSER._firecrawl_mod = Stub

    def tearDown(self):
        BROWSER._firecrawl_mod = None

    def test_research_formats_results(self):
        self._stub_firecrawl(
            search={"type": "search", "query": "q",
                    "results": [{"title": "T", "url": "https://x.test",
                                 "content": "hello body"}],
                    "answer": "", "provider": "firecrawl"},
            extract={})
        got = BROWSER.tool_web_research({"topic": "q"})
        self.assertTrue(got["ok"], got)
        self.assertIn("- T :: hello body", got["output"])
        self.assertIn("https://x.test", got.get("sources", []))

    def test_extract_rejects_non_http(self):
        self._stub_firecrawl(search={}, extract={})
        self.assertFalse(BROWSER.tool_web_extract({"url": "file:///etc/passwd"})["ok"])

    def test_snapshot_saves_inside_repo(self):
        self._stub_firecrawl(search={},
                             extract={"type": "extract", "url": "https://x.test",
                                      "content": "page body here"})
        target = ROOT / "artifacts" / "browser" / "probe.md"
        try:
            got = BROWSER.tool_web_snapshot({"url": "https://x.test", "name": "probe"})
            self.assertTrue(got["ok"], got)
            self.assertIn("page body here", target.read_text(encoding="utf-8"))
        finally:
            try:
                target.unlink()
            except FileNotFoundError:
                pass


class CoworkToolsRegistryTest(unittest.TestCase):
    BUILTINS = {"os_list_files", "os_read_file", "os_search_text", "os_run_command",
                "os_write_file", "web_extract", "web_research", "web_snapshot"}

    def test_builtin_tools_always_registered(self):
        registry = COWORK_TOOLS.build_default_registry()
        self.assertTrue(self.BUILTINS.issubset(set(registry.names())))
        self.assertIn("os_read_file", registry.catalog())
        self.assertIn("web_research", registry.catalog())

    def test_gated_tools_refuse_without_confirm(self):
        registry = COWORK_TOOLS.build_default_registry()
        denied = registry.execute("os_write_file",
                                  {"path": "artifacts/nope.txt", "content": "x"})
        self.assertFalse(denied["ok"])
        self.assertTrue(denied["denied"])
        self.assertFalse((ROOT / "artifacts" / "nope.txt").exists())

    def test_desktop_gui_tools_are_registered_and_gated(self):
        """Phase 1 (Agent-S ACI): the three gui_* tools exist and are gated.

        click/type mutate the desktop, so they must be confirm-gated;
        screen capture is gated too because it rides the `camera` permission
        category. This test only inspects the specs - it never executes a
        handler, because a real gui call would capture the screen and call
        the VLM.
        """
        registry = COWORK_TOOLS.build_default_registry()
        names = set(registry.names())
        for tool in ("gui_locate_and_click", "gui_type_into",
                     "gui_read_screen_region"):
            self.assertIn(tool, names, "gui tool missing from registry")
            self.assertIn(tool, registry.catalog(),
                          "gui tool hidden from the planner catalog")
        # Every computer-control tool is gated so the permission category's
        # `ask` can be satisfied by one confirmation, and a policy `deny` can
        # block it even while the session blanket grant is on.
        for tool in ("gui_locate_and_click", "gui_type_into",
                     "gui_read_screen_region", "gui_scroll", "gui_press_key",
                     "gui_focus_app", "gui_press_combo", "gui_type_active",
                     "os_launch_app", "os_write_file", "os_run_command",
                     "os_open_file"):
            with self.subTest(tool=tool):
                self.assertTrue(
                    registry.get(tool).requires_confirmation,
                    "%s must be confirm-gated" % tool)

    def test_every_gated_core_tool_carries_a_permission_category(self):
        """The desktop control surface must not bypass the permission engine."""
        registry = COWORK_TOOLS.build_default_registry()
        mapped = COWORK_TOOLS._PERMISSION_CATEGORY
        for name in registry.names():
            if name.startswith("gui_") or name in mapped:
                with self.subTest(tool=name):
                    self.assertIn(name, mapped,
                                  "%s is unmapped - permissions.json could "
                                  "never gate it" % name)
                    self.assertIn("permission", registry.get(name).tags)

    def test_permission_deny_blocks_a_computer_control_tool(self):
        """A policy deny must refuse the click even with an approval recorded."""
        perms = COWORK_TOOLS._load("permissions")
        registry = COWORK_TOOLS.build_default_registry()
        saved = perms.load()
        try:
            perms.save_overrides({"computer_control": "deny"})
            denied = registry.execute(
                "gui_locate_and_click", {"element_description": "OK button"},
                confirm=lambda *_: True)
            self.assertFalse(denied["ok"])
            self.assertIn("denied by the current permission policy",
                          denied["output"])
            # read-only file access is unaffected by a computer-control deny
            self.assertEqual(perms.decision_for("read_files"),
                             perms.CATEGORIES["read_files"]["default"])
        finally:
            perms.save_overrides(
                {k: v for k, v in saved.items()
                 if v in ("auto", "ask", "deny")})
            perms.load(force=True)

    def test_gui_click_is_refused_before_any_screen_call(self):
        """A denied gate must never reach pyautogui / the VLM."""
        registry = COWORK_TOOLS.build_default_registry()
        denied = registry.execute("gui_locate_and_click",
                                  {"element_description": "OK button"})
        self.assertFalse(denied["ok"])
        self.assertTrue(denied.get("denied"))
        refused = registry.execute("gui_type_into",
                                   {"field_name": "search", "text": "hi"},
                                   confirm=lambda *_: False)
        self.assertFalse(refused["ok"])
        self.assertTrue(refused.get("denied"))

    def test_configured_mcp_tools_are_live_and_read_only(self):
        registry = COWORK_TOOLS.build_default_registry()
        names = set(registry.names())
        self.assertIn("mcp_echo_echo", names)
        spec = registry.get("mcp_echo_echo")
        self.assertFalse(spec.requires_confirmation)
        got = registry.execute("mcp_echo_echo", {"text": "hello jarvis"})
        self.assertTrue(got["ok"], got)
        self.assertIn("echo: hello jarvis", got["output"])
        workspace = [n for n in names if n.startswith("mcp_files_")]
        self.assertIn("mcp_files_search_text", workspace)
        for name in workspace:
            self.assertFalse(registry.get(name).requires_confirmation)

    def test_write_capable_mcp_requires_real_confirmation(self):
        called = []

        def fake_call(server, tool, arguments, timeout=0):
            called.append((server, tool, dict(arguments)))
            return {"ok": True, "text": "write done"}

        rows = [{"server": "unsafe", "tool": "commit", "description": "Writes data",
                 "schema": {"type": "object", "properties": {"value": {"type": "string"}},
                            "required": ["value"]},
                 "annotations": {"readOnlyHint": False}, "read_only": False,
                 "allow_call": True}]
        registry = COWORK_TOOLS.cortex.ToolRegistry()
        with mock.patch.object(COWORK_TOOLS.mcp_client, "tools_snapshot", return_value=rows), \
                mock.patch.object(COWORK_TOOLS.mcp_client, "call_tool", side_effect=fake_call):
            report = COWORK_TOOLS.register_mcp_tools(registry)
            self.assertEqual(report["registered"], 1)
            spec = registry.get("mcp_unsafe_commit")
            self.assertTrue(spec.requires_confirmation)
            denied = registry.execute("mcp_unsafe_commit", {"value": "x"})
            self.assertTrue(denied["denied"])
            self.assertEqual(called, [])
            allowed = registry.execute("mcp_unsafe_commit", {"value": "x"},
                                       confirm=lambda *_: True)
            self.assertTrue(allowed["ok"], allowed)
        self.assertEqual(called, [("unsafe", "commit", {"value": "x"})])

    def test_mcp_argument_schema_is_enforced(self):
        registry = COWORK_TOOLS.build_default_registry()
        missing = registry.execute("mcp_echo_echo", {})
        self.assertFalse(missing["ok"])
        self.assertIn("missing MCP argument", missing["output"])

    def test_describe_is_honest(self):
        text = COWORK_TOOLS.describe()
        self.assertIn("cowork tools ready", text)
        self.assertIn("confirm-gated", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
