"""Free-tier deep research engine: providers -> local fetch -> claim ledger.

Why this exists: Firecrawl's cloud credits are exhausted on every key, and the
"3 keys" pool was never redundancy (credits are per account). Depth does not
need a paid SERP - it needs (a) many query facets, (b) quota-free providers,
and (c) reading the pages locally. Nothing here imports a third-party package:
extraction is stdlib, so this works the same offline as on the dev box.

Honesty contract (the whole point of the console that renders this):
  * a URL that was only *returned by a search* is never marked read
  * every provider failure is a row with ok=False and the real reason
  * corroboration is computed from how many DISTINCT hosts share the claim's
    keywords - the model never grades its own confidence
"""

import html
import importlib.util
import json
import os
import sys
import re
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser

TIMEOUT_S = 14.0
MAX_TEXT_CHARS = 12000
USER_AGENT = "jarvis-research/1.0 (personal assistant; contact: sir@localhost)"

# tier -> (queries per facet set, pages to read). Tiers are explicit so the
# console can print an estimate before the run starts.
TIERS = {
    # search = a fast brief from provider snippets, no page reads at all.
    "search": {"queries": 1, "read": 0},
    "deep": {"queries": 4, "read": 24},
    "exhaustive": {"queries": 9, "read": 60},
}

_DROP_TAGS = {"script", "style", "noscript", "template", "svg", "iframe", "nav",
              "header", "footer", "aside", "form", "button", "figure", "figcaption"}
# Site chrome that is not content: Wikipedia maintenance banners, cookie walls,
# paywall teasers. They read as confident prose and are worth nothing.
_BOILERPLATE = re.compile(
    r"please help improve|learn how and when to remove|multiple issues|"
    r"you can help|citation needed|please subscribe|enable javascript|"
    r"we use cookies|sign in to continue|all rights reserved|"
    r"this article is about .*search for", re.I)

_BLOCK_TAGS = {"p", "li", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "pre",
               "td", "th", "dd", "dt", "article", "section", "div"}


def _load_sibling(name):
    """Import a background module once, or None. Never raises into a run."""
    key = "jarvis_deep_research_" + name
    cached = sys.modules.get(key)
    if cached is not None:
        return cached
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), name + ".py")
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        sys.modules.pop(key, None)
        return None


# A dead credential must not be re-tried on every query of every run: three
# consecutive failures park the provider for PARK_SECONDS, and the console says
# so instead of the whole tier silently degrading into timeouts.
PARK_AFTER_FAILS = 3
PARK_SECONDS = 1800
_PARK = {}
_FAILS = {}


def _parked(name, now=None):
    now = time.time() if now is None else now
    return _PARK.get(name, 0.0) > now


def _note(name, ok):
    if ok:
        _FAILS[name] = 0
        _PARK.pop(name, None)
        return
    _FAILS[name] = _FAILS.get(name, 0) + 1
    if _FAILS[name] >= PARK_AFTER_FAILS:
        _PARK[name] = time.time() + PARK_SECONDS


def _env(name, default=""):
    if os.environ.get(name):
        return os.environ[name].strip()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for fname in (".dev.vars", ".env"):
        path = os.path.join(root, fname)
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith(name + "="):
                        return line.split("=", 1)[1].strip()
        except OSError:
            continue
    return default


class _Extractor(HTMLParser):
    """Crude but adequate readability: keep block text, drop chrome."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.blocks = []
        self._skip = 0
        self._cur = []

    def handle_starttag(self, tag, attrs):
        if tag in _DROP_TAGS:
            self._skip += 1
        elif tag in _BLOCK_TAGS:
            self._flush()

    def handle_endtag(self, tag):
        if tag in _DROP_TAGS and self._skip:
            self._skip -= 1
        elif tag in _BLOCK_TAGS:
            self._flush()

    def handle_data(self, data):
        if not self._skip and data:
            self._cur.append(data)

    def _flush(self):
        text = re.sub(r"\s+", " ", "".join(self._cur)).strip()
        self._cur = []
        if len(text) >= 40:
            self.blocks.append(text)

    def result(self):
        self._flush()
        seen, out = set(), []
        for b in self.blocks:
            key = b[:80].lower()
            if key in seen:
                continue
            seen.add(key)
            if _BOILERPLATE.search(b):
                continue
            out.append(b)
        return "\n\n".join(out)[:MAX_TEXT_CHARS]


def _machine_format(text):
    """True when the "extracted text" is JSON/XML/empty rather than prose.

    Measured live: a springer.nl page returned a ContentMine metadata blob and
    the console rendered it as a research finding. Machine payloads are evidence
    that a fetch happened - never a claim, and never report material.
    """
    head = (text or "").strip()
    if len(head) < 120:
        return True
    if head[0] in "{[<":
        return True
    return head[:400].count('":') >= 4


def extract_text(markup):
    if not markup:
        return ""
    if "<" not in markup:
        return re.sub(r"\s+", " ", markup).strip()[:MAX_TEXT_CHARS]
    parser = _Extractor()
    try:
        parser.feed(markup)
    except Exception:
        return ""
    return parser.result()


def _request(url, data=None, headers=None, timeout=TIMEOUT_S):
    req = urllib.request.Request(url, data=data, headers=dict(headers or {}))
    req.add_header("User-Agent", USER_AGENT)
    req.add_header("Accept", "application/json, text/html;q=0.9, */*;q=0.5")
    with urllib.request.urlopen(req, timeout=timeout) as res:
        raw = res.read()
    return getattr(res, "status", 200), raw.decode("utf-8", "replace")


def _row(url, title="", snippet="", provider=""):
    url = str(url or "").strip()
    if not url.startswith("http"):
        return None
    return {"url": url, "title": html.unescape(str(title or ""))[:160],
            "content": re.sub(r"\s+", " ", str(snippet or ""))[:700],
            "provider": provider}


# ── providers ───────────────────────────────────────────────────────────
def tavily_search(query, limit=8):
    key = _env("TAVILY_API_KEY")
    if not key:
        return None, "no TAVILY_API_KEY"
    body = json.dumps({"query": query, "max_results": limit,
                       "include_answer": True}).encode("utf-8")
    code, raw = _request("https://api.tavily.com/search", data=body,
                         headers={"Authorization": "Bearer " + key,
                                  "Content-Type": "application/json"})
    doc = json.loads(raw)
    rows = [_row(r.get("url"), r.get("title"), r.get("content"), "tavily")
            for r in (doc.get("results") or [])]
    return ([r for r in rows if r], str(doc.get("answer") or "").strip()[:900])


def exa_search(query, limit=8):
    key = _env("EXA_API_KEY")
    if not key:
        return None, "no EXA_API_KEY"
    body = json.dumps({"query": query, "numResults": limit,
                       "text": {"maxCharacters": 1200}}).encode("utf-8")
    code, raw = _request("https://api.exa.ai/search", data=body,
                         headers={"x-api-key": key, "Content-Type": "application/json"})
    doc = json.loads(raw)
    rows = []
    for r in (doc.get("results") or []):
        text = (r.get("text") or r.get("summary") or "") if isinstance(r, dict) else ""
        row = _row(r.get("url"), r.get("title"), text, "exa")
        if row:
            rows.append(row)
    return rows, ""


_OPENALEX_KEY_OK = [True]


def openalex_search(query, limit=8):
    """250M+ works with citation edges. Free token lifts 10 req/s -> 30 req/s.

    A rejected token must not cost us the provider: the first 401/403 stops
    sending the key for the rest of the process and the keyless pool (which
    does work) carries on.
    """
    token = _env("OPENALEX_API_KEY") if _OPENALEX_KEY_OK[0] else ""
    params = urllib.parse.urlencode({"search": query, "per-page": limit,
                                     "mailto": _env("OPENALEX_MAILTO", "sir@localhost")})
    url = "https://api.openalex.org/works?" + params
    if token:
        try:
            _code, raw = _request(url, headers={"Authorization": "Bearer " + token})
        except urllib.error.HTTPError as exc:
            if exc.code not in (401, 403):
                raise
            _OPENALEX_KEY_OK[0] = False
            _code, raw = _request(url)
    else:
        _code, raw = _request(url)
    doc = json.loads(raw)
    rows = []
    for w in (doc.get("results") or []):
        url2 = w.get("doi") or (w.get("primary_location") or {}).get("landing_page_url") \
            or "https://openalex.org/works/" + str(w.get("id", "")).rsplit("/", 1)[-1]
        row = _row(url2, w.get("display_name"),
                   "cited by %s · %s" % (w.get("cited_by_count"), w.get("publication_year")),
                   "openalex")
        if row:
            rows.append(row)
    return rows, ""


def wikipedia_search(query, limit=6):
    params = urllib.parse.urlencode({"action": "query", "list": "search",
                                     "srsearch": query, "srlimit": limit,
                                     "format": "json", "utf8": "1"})
    code, raw = _request("https://en.wikipedia.org/w/api.php?" + params)
    doc = json.loads(raw)
    rows = []
    for hit in ((doc.get("query") or {}).get("search") or []):
        title = hit.get("title") or ""
        snippet = re.sub(r"<[^>]+>", "", hit.get("snippet") or "")
        row = _row("https://en.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_")),
                   title, snippet, "wikipedia")
        if row:
            rows.append(row)
    return rows, ""


def hn_search(query, limit=8):
    params = urllib.parse.urlencode({"query": query, "hitsPerPage": limit})
    code, raw = _request("https://hn.algolia.com/api/v1/search?" + params)
    doc = json.loads(raw)
    rows = []
    for hit in (doc.get("hits") or []):
        url = hit.get("url") or "https://news.ycombinator.com/item?id=" + str(hit.get("objectID"))
        row = _row(url, hit.get("title"),
                   "%s points · %s comments" % (hit.get("points"), hit.get("num_comments")),
                   "hackernews")
        if row:
            rows.append(row)
    return rows, ""


def firecrawl_search(query, limit=8):
    """The keys Sir already has stay FIRST in the chain - when they answer."""
    fc = _load_sibling("firecrawl_client")
    if fc is None:
        return None, "firecrawl_client not importable"
    res = fc.search(query, max_results=limit)
    if not isinstance(res, dict) or res.get("error"):
        return None, str((res or {}).get("error") or "firecrawl returned nothing")[:160]
    rows = [_row(r.get("url"), r.get("title"),
                 r.get("content") or r.get("snippet"), "firecrawl")
            for r in (res.get("results") or [])]
    return [r for r in rows if r], str(res.get("answer") or "").strip()[:900]


def serper_search(query, limit=8):
    key = _env("SERPER_API_KEY")
    if not key:
        return None, "no SERPER_API_KEY"
    body = json.dumps({"q": query, "num": min(limit, 10)}).encode("utf-8")
    _code, raw = _request("https://google.serper.dev/search", data=body,
                          headers={"X-API-KEY": key, "Content-Type": "application/json"})
    doc = json.loads(raw)
    rows = [_row(h.get("link"), h.get("title"), h.get("snippet"), "serper")
            for h in (doc.get("organic") or [])]
    return [r for r in rows if r], ""


_CORE_KEY_OK = [True]


def core_search(query, limit=8):
    """CORE works keyless; a rejected token must not take the provider down."""
    token = _env("CORE_API_KEY") if _CORE_KEY_OK[0] else ""
    params = urllib.parse.urlencode({"q": query[:120], "limit": limit})
    url = "https://api.core.ac.uk/v3/search/works?" + params
    if token:
        try:
            _code, raw = _request(url, headers={"Authorization": "Bearer " + token,
                                                "Accept": "application/json"})
        except urllib.error.HTTPError as exc:
            if exc.code not in (401, 403, 500):
                raise
            _CORE_KEY_OK[0] = False
            _code, raw = _request(url, headers={"Accept": "application/json"})
    else:
        _code, raw = _request(url, headers={"Accept": "application/json"})
    doc = json.loads(raw)
    rows = []
    for w in (doc.get("results") or []):
        row = _row(w.get("fulltext_identifier") or w.get("download_url")
                   or ("https://core.ac.uk/display/" + str(w.get("core_id") or "")),
                   w.get("title"), (w.get("abstract") or "")[:600], "core")
        if row:
            rows.append(row)
    return rows, ""


PROVIDERS = [
    ("firecrawl", firecrawl_search),
    ("tavily", tavily_search),
    ("exa", exa_search),
    ("serper", serper_search),
    ("core", core_search),
    ("openalex", openalex_search),
    ("wikipedia", wikipedia_search),
    ("hackernews", hn_search),
]


def _facets(topic, tier):
    """Query breadth comes from facets, not from repeating one sentence."""
    t = str(topic or "").strip()
    base = [t]
    if tier == "search":
        return base
    facets = ["%s latest developments" % t, "%s criticism and failures" % t,
              "%s statistics and data" % t]
    if tier == "deep":
        return (base + facets)[:4]
    return (base + facets + ["%s primary sources" % t, "%s comparison alternatives" % t,
                             "%s risks and safety" % t, "%s cost and economics" % t,
                             "%s research papers" % t])[:9]


def search_all(queries):
    """Every provider is tried for every facet; a failure never stops the run.

    This is the failover Sir asked for: an exhausted key, a 403, a dead host -
    each becomes one honest row, and the next provider carries the load.
    """
    rows, providers, answer = [], [], ""
    for query in queries:
        for name, fn in PROVIDERS:
            if _parked(name):
                providers.append({"name": name, "query": query[:60], "ok": False,
                                  "results": 0, "ms": 0, "parked": True,
                                  "error": "parked after %d failures" % PARK_AFTER_FAILS})
                continue
            started = time.time()
            try:
                got, extra = fn(query)
            except Exception as exc:
                _note(name, False)
                providers.append({"name": name, "query": query[:60], "ok": False,
                                  "results": 0, "parked": False,
                                  "ms": int((time.time() - started) * 1000),
                                  "error": "%s: %s" % (type(exc).__name__, str(exc)[:120])})
                continue
            elapsed = int((time.time() - started) * 1000)
            if got is None:
                _note(name, False)
                providers.append({"name": name, "query": query[:60], "ok": False,
                                  "results": 0, "ms": elapsed, "parked": False,
                                  "error": str(extra or "not configured")[:160]})
                continue
            # Zero hits is still an answer. Parking a provider for a
            # narrow query would hide a key that is working fine.
            _note(name, True)
            rows.extend(got)
            if extra and len(extra) > len(answer):
                answer = extra
            providers.append({"name": name, "query": query[:60], "ok": True,
                              "results": len(got), "ms": elapsed,
                              "parked": False, "error": ""})
    return rows, providers, answer


def _canonical(url):
    parsed = urllib.parse.urlsplit(str(url or ""))
    host = parsed.netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    path = re.sub(r"[/#?]+$", "", parsed.path or "")
    return "%s://%s%s" % (parsed.scheme or "https", host, path)


def _host(url):
    host = urllib.parse.urlsplit(str(url or "")).netloc.lower()
    return host[4:] if host.startswith("www.") else host


def dedupe(rows):
    """Collapse exact URLs, then near-duplicate titles, keeping provider order."""
    out, seen_url, seen_title = [], set(), set()
    collapsed = 0
    for row in rows:
        canon = _canonical(row.get("url"))
        # Only http(s) may ever become a fetch target: a provider that echoes
        # javascript:, file:, or data: must not reach the request layer.
        if not canon.startswith("http://") and not canon.startswith("https://"):
            collapsed += 1
            continue
        title_key = re.sub(r"\W+", "", str(row.get("title") or "").lower())[:60]
        if canon in seen_url:
            collapsed += 1
            continue
        if title_key and title_key in seen_title:
            collapsed += 1
            continue
        seen_url.add(canon)
        if title_key:
            seen_title.add(title_key)
        clean = dict(row)
        clean["url"] = canon
        clean["host"] = _host(canon)
        out.append(clean)
    return out, collapsed


def fetch_all(rows, budget):
    """Read pages locally. One worker per host at a time, never hammering."""
    targets = rows[:budget]
    results = [None] * len(targets)
    gap = {}
    gap_lock = threading.Lock()
    sem = threading.Semaphore(6)

    def worker(index, row):
        url = row.get("url")
        host = row.get("host") or _host(url)
        rec = {"url": url, "host": host, "title": row.get("title") or "",
               "provider": row.get("provider") or "", "ok": False, "bytes": 0,
               "chars": 0, "ms": 0, "status": 0, "error": "", "text": ""}
        started = time.time()
        with gap_lock:
            wait_for = gap.get(host, 0.0) - time.time()
            gap[host] = max(gap.get(host, 0.0), time.time()) + 1.0
        if wait_for > 0:
            time.sleep(min(wait_for, 3.0))
        try:
            with sem:
                status, markup = _request(url, timeout=TIMEOUT_S)
            text = extract_text(markup)
            machine = _machine_format(text)
            rec.update({"status": status, "bytes": len(markup.encode("utf-8", "replace")),
                        "chars": len(text), "text": text,
                        "snippet": "" if machine else text[:220],
                        "ok": bool(text) and status < 400 and not machine,
                        "error": ("" if (text and status < 400 and not machine)
                                  else ("machine data (JSON/XML), not prose" if machine
                                        else "no readable text (HTTP %s)" % status))})
        except urllib.error.HTTPError as exc:
            rec["status"] = exc.code
            rec["error"] = "HTTP %s" % exc.code
        except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
            rec["error"] = "%s: %s" % (type(exc).__name__, str(exc)[:100])
        except Exception as exc:
            rec["error"] = "%s: %s" % (type(exc).__name__, str(exc)[:100])
        rec["ms"] = int((time.time() - started) * 1000)
        results[index] = rec

    threads = [threading.Thread(target=worker, args=(i, r), daemon=True)
               for i, r in enumerate(targets)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=TIMEOUT_S + 8)
    return [r for r in results if r]


_STOP = set("the a an of and or to in for on with by is are was were as at from that this "
            "it its into their they we you our new 2025 2026".split())


def _keywords(text):
    words = re.findall(r"[a-z]{4,}", (text or "").lower())
    counts = {}
    for w in words:
        if w in _STOP:
            continue
        counts[w] = counts.get(w, 0) + 1
    return set(sorted(counts, key=counts.get, reverse=True)[:12])


def build_sections(reads):
    """One section per distinct host that was actually read."""
    sections, seen_hosts = [], set()
    for rec in reads:
        if not rec.get("ok") or not rec.get("text"):
            continue
        host = rec.get("host")
        if host in seen_hosts:
            continue
        seen_hosts.add(host)
        body = " ".join(str(rec["text"]).split("\n\n")[:4])[:900]
        sections.append({"host": host, "url": rec.get("url"),
                         "title": (rec.get("title") or host)[:120],
                         "text": body, "kw": _keywords(rec.get("title") + " " + body)})
    return sections


def corroborate(sections):
    """A claim is corroborated when ANOTHER HOST's text shares most of its keywords."""
    for sec in sections:
        supporters = 0
        for other in sections:
            if other is sec or not sec["kw"]:
                continue
            shared = len(sec["kw"] & other["kw"])
            if shared >= max(4, int(len(sec["kw"]) * 0.35)):
                supporters += 1
        sec["support"] = 1 + supporters
        sec["verdict"] = "cross_checked" if supporters >= 1 else "single_source"
    return sections


class _WriterChain:
    """Try the free writer first, then the restored Radox prose pool."""

    def __init__(self, *mods):
        self.mods = [m for m in mods if m is not None]

    def llm(self, messages, max_tokens=1200):
        system = ""
        user = []
        for message in messages or []:
            role = message.get("role")
            content = str(message.get("content") or "")
            if role == "system":
                system = content
            elif role != "assistant":
                user.append(content)
        prompt = "\n\n".join(user)
        last_meta = {}
        for mod in self.mods:
            try:
                if hasattr(mod, "llm"):
                    text, meta = mod.llm(messages, max_tokens=max_tokens)
                elif hasattr(mod, "write"):
                    text, meta = mod.write(prompt, system=system,
                                           max_tokens=max_tokens)
                else:
                    continue
            except Exception as exc:
                last_meta = {"error": "%s: %s" % (type(exc).__name__, str(exc)[:120])}
                continue
            if text:
                return text, meta or {}
            last_meta = meta or last_meta
        return None, last_meta


def _writer():
    """Free writer first; Radox is a fallback when its keys are configured."""
    mods = []
    free = _load_sibling("content_writer")
    if free is not None and hasattr(free, "llm"):
        mods.append(free)
    radox = _load_sibling("radox_writer")
    if radox is not None and hasattr(radox, "write") and radox.available():
        mods.append(radox)
    return _WriterChain(*mods) if mods else None


def compose_report(topic, sections, language=None, progress=None):
    """Map-reduce the read pages into one human report on the free chain.

    Map: each batch of sections becomes short notes with their hosts. Reduce:
    the notes become the report. Both stages say "using ONLY", and the caller
    keeps the deterministic dossier when the writer fails - so a dead writer
    costs quality, never the run. Returns ``(report, meta)`` so the caller can
    report the model that actually wrote it.
    """
    mod = _writer()
    if mod is None or not sections:
        return "", {}
    system = ("You are JARVIS, a research analyst writing one section of a report. Never "
              "state your model name or developer, never greet the reader, and begin with "
              "the requested content on the first line.")
    lang = {"hinglish": "Write in Hinglish (Roman Hindi + simple English mix). ",
            "ja": "Write in natural Japanese (\u65e5\u672c\u8a9e). ",
            "en": "Write in plain English. "}.get(language or "en",
                                                   "Write in plain English. ")
    batches = [sections[i:i + 8] for i in range(0, len(sections), 8)][:8]
    notes = []
    writer_meta = {}
    for index, batch in enumerate(batches, 1):
        block = "\n\n".join("[%s] %s :: %s" % (b.get("host"), b.get("title"), b.get("text"))
                            for b in batch)[:7000]
        text, meta = mod.llm([
            {"role": "system", "content": system},
            {"role": "user", "content": (
                "Using ONLY this evidence, write 6 dense factual notes. Keep numbers, dates "
                "and names exactly as written, and end every note with the host it came "
                "from.\n\nTOPIC: %s\n\nEVIDENCE:\n%s" % (topic, block))},
        ], max_tokens=2400)
        if text:
            notes.append("## batch %d\n%s" % (index, " ".join(text.split())[:1600]))
            writer_meta = meta or writer_meta
        if progress:
            try:
                progress("map %d/%d" % (index, len(batches)))
            except Exception:
                pass
    if not notes:
        return "", writer_meta
    text, meta = mod.llm([
        {"role": "system", "content": system},
        {"role": "user", "content": (
            "%s"
            "You are JARVIS writing a deep research report. Using ONLY the notes below, write "
            "1) a 3-4 sentence overview, 2) 'Key findings' with 6-10 bullets each ending with "
            "its source host, 3) 'Where sources disagree' (say \"no disagreement in evidence\" "
            "if none), 4) 'Gaps' with 2-4 bullets. Plain sentences, no tables, under 500 "
            "words.\n\nTOPIC: %s\n\nNOTES:\n%s" % (lang, topic, "\n\n".join(notes))[:14000])},
    ], max_tokens=3000)
    if not text:
        return "", writer_meta
    # Keep the line structure: the console renders bullets and
    # section headings from it. Collapsing to one line made a 40-page report
    # read as a wall of text.
    return text.replace(chr(13) + chr(10), chr(10)).strip()[:4500], (meta or writer_meta)


def pick_tier(text):
    t = str(text or "").lower()
    if re.search(r"\bpoora|exhaustive|har site|every site|complete|in depth|deeply\b", t):
        return "exhaustive"
    if re.search(r"\bjust\b|\bsirf\b|\bbas\b|quick|only tell", t):
        return "search"
    return "deep"


def estimate(tier):
    spec = TIERS.get(tier, TIERS["deep"])
    return {"queries": spec["queries"], "read": spec["read"],
            "minutes": max(1, int(round(spec["read"] * 1.6 / 60.0)))}


def run(topic, tier=None, source_text="", language=None):
    tier = tier or pick_tier(source_text or topic)
    spec = TIERS.get(tier, TIERS["deep"])
    started = time.time()
    queries = _facets(topic, tier)
    rows, providers, answer = search_all(queries)
    unique, collapsed = dedupe(rows)
    reads = fetch_all(unique, spec["read"]) if spec["read"] else []
    sections = corroborate(build_sections(reads))
    dossier = "\n\n".join("### %s\n%s" % (x["title"], x["text"]) for x in sections)
    if not sections:
        # Search tier: the snippets the providers returned ARE the evidence.
        dossier = "\n\n".join("### %s\n%s" % (r.get("title") or _host(r.get("url")),
                                              r.get("content") or "")
                              for r in unique[:8] if r.get("content"))
    composed, writer_meta = compose_report(topic, sections, language=language)
    used_writer = bool(composed and composed != dossier)
    report = composed or dossier or answer
    hosts = sorted({r["host"] for r in reads if r.get("ok")})
    payload = {
        "type": "research", "topic": str(topic or "")[:200], "tier": tier,
        "queries": queries, "providers": providers,
        "results": [{"title": r.get("title"), "url": r.get("url"),
                     "content": r.get("content")} for r in unique[:12]],
        "answer": answer,
        "report": report or (answer or ""),
        "dossier": dossier,
        "evidence_mode": ("pages-read" if sections else
                          ("snippets" if unique else "none")),
        "written_by": (("radox-pool" if writer_meta.get("slot")
                        and not writer_meta.get("provider") else "free-writer")
                       if used_writer else
                       ("deterministic-dossier" if dossier else "none")),
        "writer_model": (writer_meta.get("model") or "") if used_writer else "",
        "writer_provider": (writer_meta.get("provider") or "") if used_writer else "",
        "sources": [s["url"] for s in sections] or [r["url"] for r in reads if r.get("ok")],
        "sources_detail": [{k: v for k, v in r.items() if k != "text"} for r in reads],
        "sections": [{"host": s["host"], "url": s["url"], "title": s["title"],
                      "text": s["text"][:900], "support": s["support"],
                      "verdict": s["verdict"]} for s in sections],
        "hosts": len(hosts), "host_list": hosts,
        "scraped": len([r for r in reads if r.get("ok")]),
        "attempted": len(reads), "found": len(rows), "unique": len(unique),
        "collapsed": collapsed,
        "cross_checked": len([s for s in sections if s["verdict"] == "cross_checked"]),
        "single_source": len([s for s in sections if s["verdict"] == "single_source"]),
        "answered": len(dict.fromkeys(p["name"] for p in providers if p["ok"])),
        "chain_size": len(PROVIDERS),
        "parked": sorted(dict.fromkeys(
            p["name"] for p in providers if p.get("parked"))),
        "provider": "chain (%s)" % "+".join(
            dict.fromkeys(p["name"] for p in providers if p["ok"])),
        "ms": int((time.time() - started) * 1000),
    }
    if not payload["report"]:
        payload["error"] = "0 pages readable: %s" % (
            "; ".join("%s %s" % (p["name"], p["error"] or "%d results" % p["results"])
                      for p in providers[:5]) or "no provider answered")
    return payload


def status():
    """Chain health, measured by one real 1-result call per provider."""
    out = []
    for name, fn in PROVIDERS:
        if _parked(name):
            out.append({"name": name, "ok": False, "parked": True,
                        "error": "parked after %d failures" % PARK_AFTER_FAILS})
            continue
        try:
            rows, _ = fn("battery", limit=1)
            _note(name, True)
            out.append({"name": name, "ok": bool(rows), "parked": False,
                        "error": "" if rows else "no results"})
        except Exception as exc:
            _note(name, False)
            out.append({"name": name, "ok": False, "parked": False,
                        "error": "%s: %s" % (type(exc).__name__, str(exc)[:120])})
    return out


if __name__ == "__main__":
    import sys
    topic = sys.argv[1] if len(sys.argv) > 1 else "solid state battery energy density"
    doc = run(topic)
    print(json.dumps({k: v for k, v in doc.items()
                      if k not in ("sources_detail", "sections", "results")}, indent=2)[:2000])
