"""Phase 6.2 tests: Data Forge really produces data, and never lies about format.

Run:  node run_py.cjs -m unittest discover -s tests -p test_data_forge.py

Everything here writes into a temp dataset dir (JARVIS_DATA_STUB is not used -
data_forge owns artifacts/datasets, so the module's own dir is redirected for
the duration of the test).
"""

from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))

import data_forge                                        # noqa: E402

ROWS = [{"service": "core", "cpu": 12.5, "healthy": True},
        {"service": "ui", "cpu": 3.25, "healthy": True},
        {"service": "bridge", "cpu": 0.5, "healthy": False}]


class ForgeBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="jarvis-forge-")
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        patcher = patch.object(data_forge, "DATASET_DIR", self.folder)
        patcher.start()
        self.addCleanup(patcher.stop)

    def _cleanup_orphan_temp(self):
        for path in self.folder.glob("*.csv.tmp"):
            path.unlink()


class CreateDatasetTests(ForgeBase):
    def test_csv_is_written_with_headers_and_rows(self):
        out = data_forge.create_dataset(ROWS, name="metrics", fmt="csv")
        self.assertTrue(out["ok"], out)
        path = Path(out["path"])
        self.assertTrue(path.is_file())
        with open(path, newline="", encoding="utf-8") as handle:
            read = list(csv.DictReader(handle))
        self.assertEqual(len(read), 3)
        self.assertEqual(read[0]["service"], "core")
        self.assertEqual(out["rows"], 3)

    def test_parquet_is_a_real_parquet_file_when_duckdb_is_present(self):
        if not data_forge._duckdb():
            self.skipTest("duckdb not installed")
        out = data_forge.create_dataset(ROWS, name="metrics", fmt="parquet")
        self.assertTrue(out["ok"], out)
        path = Path(out["path"])
        self.assertEqual(path.suffix, ".parquet")
        self.assertEqual(path.read_bytes()[:4], b"PAR1")
        back = data_forge.read_rows(str(path))
        self.assertTrue(back["ok"], back)
        self.assertEqual(back["count"], 3)
        self.assertEqual({row["service"] for row in back["rows"]},
                         {"core", "ui", "bridge"})
        self._cleanup_orphan_temp()

    def test_requested_format_is_never_silently_downgraded(self):
        # The old module wrote JSONL when asked for parquet. It must fail loudly
        # instead, with the install hint.
        with patch.object(data_forge, "_duckdb", return_value=None):
            out = data_forge.create_dataset(ROWS, name="metrics", fmt="parquet")
        self.assertFalse(out["ok"])
        self.assertIn("duckdb", out["error"].lower())
        self.assertEqual(list(self.folder.glob("*.parquet")), [])

    def test_unknown_format_is_rejected_not_coerced(self):
        out = data_forge.create_dataset(ROWS, name="metrics", fmt="xlsx")
        self.assertFalse(out["ok"])
        self.assertIn("unsupported format", out["error"])

    def test_empty_rows_are_refused(self):
        self.assertFalse(data_forge.create_dataset([], name="empty")["ok"])

    def test_jsonl_round_trip(self):
        out = data_forge.create_dataset(ROWS, name="metrics", fmt="jsonl")
        back = data_forge.read_rows(out["path"])
        self.assertEqual(back["rows"][0]["service"], "core")


class FromFileTests(ForgeBase):
    def test_csv_file_becomes_parquet_dataset(self):
        source = self.folder / "input.csv"
        with open(source, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["a", "b"])
            writer.writeheader()
            writer.writerow({"a": 1, "b": "x"})
            writer.writerow({"a": 2, "b": "y"})
        out = data_forge.from_file(str(source), name="converted", fmt="csv")
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["source_rows"], 2)
        self.assertEqual(out["rows"], 2)

    def test_missing_file_is_reported(self):
        out = data_forge.from_file(str(self.folder / "nope.csv"))
        self.assertFalse(out["ok"])
        self.assertIn("no such file", out["error"])


class QueryTests(ForgeBase):
    def setUp(self):
        super().setUp()
        self.created = data_forge.create_dataset(ROWS, name="metrics", fmt="csv")

    def test_read_only_sql_answers_from_the_real_dataset(self):
        if not data_forge._duckdb():
            self.skipTest("duckdb not installed")
        sql = ("SELECT service, cpu FROM read_csv_auto('%s') "
               "ORDER BY cpu DESC" % Path(self.created["path"]).as_posix())
        out = data_forge.query(sql)
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["rows"][0]["service"], "core")

    def test_writes_are_refused(self):
        for sql in ("DELETE FROM read_csv_auto('x')",
                    "CREATE TABLE t AS SELECT 1",
                    "INSERT INTO t VALUES (1)",
                    "DROP TABLE t"):
            out = data_forge.query(sql)
            self.assertFalse(out["ok"], sql)
            self.assertIn("read-only", out["error"])

    def test_empty_sql_is_refused(self):
        self.assertFalse(data_forge.query("")["ok"])


class StatusTests(ForgeBase):
    def test_empty_dir_reports_zero_datasets_honestly(self):
        info = data_forge.status()
        self.assertEqual(info["count"], 0)
        self.assertEqual(info["datasets"], [])
        self.assertIn("no dataset", info["note"])

    def test_status_lists_real_files_only(self):
        data_forge.create_dataset(ROWS, name="metrics", fmt="csv")
        (self.folder / "notes.txt").write_text("ignore me", encoding="utf-8")
        info = data_forge.status()
        self.assertEqual(info["count"], 1)
        self.assertTrue(info["datasets"][0]["name"].endswith(".csv"))
        self.assertEqual(info["formats"], ["csv"])


class TelemetryDatasetTests(ForgeBase):
    def test_dataset_is_built_from_real_machine_numbers(self):
        out = data_forge.telemetry_dataset()
        self.assertTrue(out["ok"], out)
        self.assertGreater(out["rows"], 0)
        self.assertEqual(out["name"].split("_")[0], "system")
        back = data_forge.read_rows(out["path"])
        metrics = {row["metric"] for row in back["rows"]}
        self.assertIn("cpu_percent", metrics)
        self.assertIn("ram_used_percent", metrics)


class VoiceRouteTests(unittest.TestCase):
    """The real dispatcher route for datasets."""

    @classmethod
    def setUpClass(cls):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "voice_engine_dataset", ROOT / "background" / "voice_engine.py")
        cls.voice = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.voice)

    def test_telemetry_request_creates_a_dataset(self):
        with tempfile.TemporaryDirectory() as tmp:
            import data_forge
            with patch.object(data_forge, "DATASET_DIR", Path(tmp)), \
                 patch.object(self.voice, "_data_forge_mod",
                              return_value=data_forge):
                said = []
                handled = self.voice._dataset_route(
                    "telemetry ka dataset banao", "", said.append)
        self.assertTrue(handled)
        self.assertIn("dataset ban gaya", said[0])

    def test_inventory_request_lists_datasets(self):
        import data_forge
        said = []
        with patch.object(self.voice, "_data_forge_mod", return_value=data_forge):
            handled = self.voice._dataset_route("datasets dikhao", "", said.append)
        self.assertTrue(handled)
        self.assertTrue(said[0].startswith("Sir,"))

    def test_unrelated_sentence_is_not_stolen(self):
        with patch.object(self.voice, "_data_forge_mod") as forge:
            handled = self.voice._dataset_route("play music", "", lambda _t: None)
        self.assertIsNone(handled)
        forge.assert_not_called()


class CapabilityProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "capability_registry_forge",
            ROOT / "background" / "capability_registry.py")
        cls.registry = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.registry)
        # The probe loads its OWN data_forge instance; redirect THAT one so the
        # real artifacts/datasets on this machine cannot decide the verdict.
        cls.forge = cls.registry._load("data_forge")

    def test_card_is_ready_until_a_dataset_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(self.forge, "DATASET_DIR", Path(tmp)):
                verdict = self.registry._probe_data_forge()
        self.assertEqual(verdict["state"], "READY")
        self.assertIn("no dataset has been produced yet", verdict["reason"])

    def test_card_is_live_once_a_real_dataset_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(self.forge, "DATASET_DIR", Path(tmp)):
                out = self.forge.create_dataset(ROWS, name="probe", fmt="csv")
                self.assertTrue(out["ok"], out)
                verdict = self.registry._probe_data_forge()
        self.assertEqual(verdict["state"], "LIVE")
        self.assertIn("probe", verdict["reason"])


if __name__ == "__main__":
    unittest.main()