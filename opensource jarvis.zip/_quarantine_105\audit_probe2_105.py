"""Focused probe: plugin registration + SCREENTASK consumer check (offline)."""
import importlib.util, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
def load_bg(name):
    full="jarvis_cowork_"+name
    if full in sys.modules: return sys.modules[full]
    p=ROOT/"background"/(name+".py")
    import importlib.util as iu
    spec=iu.spec_from_file_location(full,p)
    m=iu.module_from_spec(spec); sys.modules[full]=m
    spec.loader.exec_module(m); return m
cx=load_bg("cortex"); tools=load_bg("cowork_tools"); ext=load_bg("extensions")
reg=tools.build_default_registry()
res=ext.register_plugin_tools(reg)
names=sorted(reg.names())
print("REG_TOTAL",len(names))
print("REG_RESULT",res)
print("PLUG_PREFIX",[n for n in names if n.startswith("plug_")][:40])
print("HAS_WRITER",[n for n in names if "write_document" in n])
print("HAS_PRES",[n for n in names if "create_presentation" in n])
print("HAS_GUI",[n for n in names if n.startswith("gui_")])
print("HAS_WAWEB",[n for n in names if n.startswith("whatsapp_web")])
# presentation_builder specs shape
pb=load_bg("presentation_builder")
try:
    sp=pb.specs(); print("PB_SPECS_TYPE",type(sp),str(sp)[:300])
except Exception as e:
    print("PB_SPECS_ERR",e)
# SCREENTASK consumer: does brain() or run_command parse it?
ve=(ROOT/"background"/"voice_engine.py").read_text(encoding="utf-8",errors="ignore")
import re
print("SCREENTASK_COUNT",len(re.findall(r"SCREENTASK",ve)))
print("SCREENTASK_PARSE",bool(re.search(r"SCREENTASK[\"']?\s*[:=]|split\(.*SCREENTASK|SCREENTASK.*split|_SCREEN.*TASK.*parse|parse.*SCREEN",ve)))
print("BRAIN_DEF",bool(re.search(r"def brain\(",ve)))
