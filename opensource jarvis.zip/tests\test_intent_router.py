﻿"""Universal input router: per-module classification, safety and loop guards.

Stdlib only, no network, no LLM, no app launch. Imports the pure router
directly - it must stay importable without sounddevice/requests.
"""
import importlib.util
import inspect
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ROUTER = _load("intent_router")
route = ROUTER.route_global_input


class ModuleRoutingTest(unittest.TestCase):
    """STEP 1: every module maps to its own destination channel."""

    def assert_routes(self, channel, *prompts):
        for prompt in prompts:
            decision = route(prompt)
            self.assertEqual(decision["channel"], channel,
                             "%r -> %s (%s)" % (prompt, decision["channel"],
                                                decision["reason"]))

    def test_cowork_and_agent_workspace(self):
        self.assert_routes("agent_workspace",
                           "open the terminal in my repo",
                           "list the files in my workspace",
                           "show me the mcp tool registry")
        self.assert_routes("cowork",
                           "start a cowork task",
                           "write a python script for parsing csv",
                           "orchestrate a multi agent pipeline")

    def test_deep_research(self):
        self.assert_routes("deep_research",
                           "do deep research on quantum computing",
                           "crawl this website and scrape the pricing",
                           "parse this pdf and summarize it",
                           "search the web for the latest news")

    def test_screen_analyzer(self):
        self.assert_routes("screen_analyzer",
                           "what is on my screen",
                           "whats on my screen right now",
                           "analyze this screen",
                           "read this error message on screen",
                           "take a screenshot of my screen")

    def test_kamisensei_and_study_mode(self):
        self.assert_routes("kamisensei",
                           "teach me kanji for N3",
                           "explain bunpro grammar",
                           "make me anki flashcards for hiragana",
                           "how do I say thank you in japanese")
        self.assert_routes("study_mode",
                           "start my study mode revision session",
                           "review my cards",
                           "show my streak")

    def test_system_health(self):
        self.assert_routes("system_health",
                           "how much RAM is my CPU using",
                           "check my system info",
                           "what is the GPU temperature",
                           "show resource usage")

    def test_calendar(self):
        self.assert_routes("calendar",
                           "remind me to drink water in 10 minutes",
                           "set a reminder for the meeting",
                           "schedule a call tomorrow at 5",
                           "set an alarm for 7am")

    def test_voice_panel(self):
        self.assert_routes("voice",
                           "open voice panel settings",
                           "check my mic level",
                           "change my wake word")

    def test_every_channel_exposes_a_real_view_and_panel(self):
        for channel, meta in ROUTER.CHANNELS.items():
            self.assertTrue(meta["panel"].isupper(), channel)
            self.assertTrue(meta["view"], channel)
            self.assertTrue(meta["widget"], channel)


class OriginPanelTest(unittest.TestCase):
    """Casual chat returns to the panel the user was standing in."""

    def test_conversational_input_returns_to_origin(self):
        for panel, expected in (("cowork", "cowork"), ("kamisensei", "kamisensei"),
                                ("vision", "screen_analyzer"),
                                ("productivity", "calendar"),
                                ("system", "system_health"), ("voice", "voice")):
            for prompt in ("haan yaar ek joke sunao", "hello", "thanks bhai"):
                decision = route(prompt, panel)
                self.assertEqual(decision["channel"], expected,
                                 "%r from %s -> %s" % (prompt, panel,
                                                       decision["channel"]))


class SafetyGuardTest(unittest.TestCase):
    """STEP 4: safety exclusions are never re-routed into a feature panel."""

    def test_destructive_commands_stay_in_the_origin_panel(self):
        """A guarded route returns to WHERE THE USER IS, never a new panel."""
        for prompt in ("shut down the laptop", "restart my pc",
                       "factory reset the system", "delete file report.txt"):
            decision = route(prompt, "kamisensei")
            self.assertTrue(decision["guarded"], prompt)
            self.assertEqual(decision["confidence"], 0.0, prompt)
            # KamiSensei is not a channel, so chat is the safe destination;
            # the key property is that it is NOT one of the module channels.
            self.assertNotIn(decision["channel"],
                             ("calendar", "cowork", "deep_research",
                              "system_health", "agent_workspace"), prompt)

    def test_safety_exclusion_beats_a_stronger_keyword(self):
        # "remind me" would normally route to the calendar. A destructive verb
        # anywhere in the utterance must win so no action gets mis-filed.
        decision = route("remind me after you restart my laptop", "cowork")
        self.assertTrue(decision["guarded"])
        self.assertNotEqual(decision["channel"], "calendar")

    def test_guarded_routes_never_switch_the_view(self):
        """The destination view must be the panel the user is already on."""
        for panel, view in (("cowork", "cowork"), ("vision", "vision"),
                            ("productivity", "productivity")):
            self.assertEqual(route("shutdown now", panel)["view"], view)

    def test_exclusion_never_routes_to_calendar(self):
        """A destructive verb must never light up the calendar panel."""
        for prompt in ("delete file notes.txt", "wipe the drive",
                       "remind me to restart the server"):
            self.assertNotEqual(route(prompt, "vision")["channel"], "calendar",
                                prompt)


class CircularLoopGuardTest(unittest.TestCase):
    """STEP 4: a tool response must never re-trigger another feature panel."""

    def test_tool_echo_is_never_rerouted(self):
        poison = ("kanji schedule reminder cpu ram deep research "
                  "co-work terminal")
        decision = route(ROUTER.stamp_echo(poison), "vision")
        self.assertTrue(decision["guarded"])
        # The poison text matches many channels, but an echo must collapse to
        # the origin panel instead of bouncing the UI.
        self.assertEqual(decision["channel"], "screen_analyzer")
        self.assertEqual(decision["confidence"], 0.0)

    def test_repeated_echoes_stay_stable(self):
        """Feeding a tool result back repeatedly cannot drift the channel."""
        text = ROUTER.stamp_echo("remind me about the kanji deck")
        first = route(text, "vision")
        for _ in range(5):
            self.assertEqual(route(text, "vision")["channel"], first["channel"])

    def test_raw_tool_envelopes_are_caught(self):
        for envelope in ("tool_result: kanji reminder schedule",
                         "tool_result_json: cpu ram telemetry",
                         "[jarvis:route] kamisensei study_mode"):
            self.assertTrue(ROUTER.is_tool_echo(envelope), envelope)

    def test_sentinel_round_trips(self):
        self.assertEqual(ROUTER.strip_echo(ROUTER.stamp_echo("hello")),
                         "hello")

    def test_user_utterance_is_not_an_echo(self):
        for prompt in ("remind me at 5", "teach me kanji",
                       "what is on my screen"):
            self.assertFalse(ROUTER.is_tool_echo(prompt), prompt)


class RobustnessTest(unittest.TestCase):
    def test_empty_and_non_string_input(self):
        for value in ("", "   ", None, 0, [], {}):
            self.assertIn(route(value, "cowork")["channel"], ROUTER.CHANNELS)


class EngineIntegrationTest(unittest.TestCase):
    """The engine must expose the router and never break the voice loop."""

    def setUp(self):
        self.engine = _load("voice_engine")

    def test_engine_exposes_routing_helpers(self):
        for name in ("route_global_input", "apply_channel_route", "_router"):
            self.assertTrue(callable(getattr(self.engine, name)), name)

    def test_apply_channel_route_broadcasts_state(self):
        before = int(self.engine.STATE.get("channel_revision", 0))
        decision = self.engine.apply_channel_route("teach me kanji", "cowork")
        self.assertEqual(decision["channel"], "kamisensei")
        self.assertEqual(self.engine.STATE["target_channel_id"], "kamisensei")
        self.assertEqual(self.engine.STATE["channel"]["panel"],
                         "KAMISENSEI_PANEL")
        self.assertGreater(int(self.engine.STATE["channel_revision"]), before)

    def test_events_are_stamped_with_target_channel(self):
        self.engine.set_state(target_channel_id="calendar", last_jarvis="Noted.")
        event = self.engine.STATE["events"][-1]
        self.assertEqual(event["target_channel_id"], "calendar")

    def test_tool_echo_sentinel_never_reaches_state_or_tts(self):
        text = self.engine._router_strip_echo(
            ROUTER.stamp_echo("kanji reminder schedule"))
        self.assertNotIn("\x00", text)
        self.assertIn("kanji", text)

    def test_destructive_command_is_not_rerouted(self):
        decision = self.engine.route_global_input("shut down my laptop",
                                                  "kamisensei")
        self.assertTrue(decision["guarded"])
        self.assertNotEqual(decision["channel"], "calendar")
        self.assertEqual(decision["confidence"], 0.0)

    def test_router_never_raises_on_garbage(self):
        for value in (None, "", 12345, {"a": 1}, b"bytes", object()):
            self.assertIn(
                self.engine.route_global_input(value, "cowork")["channel"],
                ROUTER.CHANNELS)

    def test_run_command_signature_stays_backward_compatible(self):
        """Existing callers pass (text, ui, bridge, source) positionally."""
        params = list(inspect.signature(
            self.engine.run_command).parameters)
        self.assertEqual(params[:4], ["text", "ui", "bridge", "source"])
        self.assertIn("source_panel_id", params)

    def test_submit_command_signature_stays_backward_compatible(self):
        params = list(inspect.signature(
            self.engine.submit_command).parameters)
        self.assertEqual(params[:4], ["text", "ui", "bridge", "source"])
        self.assertIn("source_panel_id", params)


class NonLatinWakeTest(unittest.TestCase):
    """The Hindi and Japanese address patterns were stored cp1252-mangled.

    A mangled pattern never matches real Devanagari or kana, so every non-Latin
    address fell through unstripped: the wake word stayed glued to the command
    and the utterance mis-routed. These pin the repaired literals, and the
    source check stops the same corruption from creeping back in silently.
    """

    def test_hindi_address_is_stripped(self):
        self.assertEqual(ROUTER.strip_wake_words("\u0939\u0947 \u091C\u093E\u0930\u094D\u0935\u093F\u0938 youtube kholo"),
                         "youtube kholo")
        self.assertEqual(ROUTER.strip_wake_words("\u0939\u093E\u092F \u091C\u093E\u0930\u094D\u0935\u093F\u0938, time batao"),
                         "time batao")

    def test_japanese_address_is_stripped(self):
        self.assertEqual(ROUTER.strip_wake_words("\u306D\u3048 \u30B8\u30E3\u30FC\u30D3\u30B9 youtube \u3092\u958B\u3044\u3066"),
                         "youtube \u3092\u958B\u3044\u3066")
        self.assertEqual(ROUTER.strip_wake_words("\u30B8\u30E3\u30FC\u30D3\u30B9\u3001time"), "time")

    def test_japanese_language_word_routes_to_kamisensei(self):
        for prompt in ("\u65E5\u672C\u8A9E\u3092\u6559\u3048\u3066", "\u306B\u307B\u3093\u3054 no keiyu"):
            decision = route(prompt)
            self.assertEqual(decision["channel"], "kamisensei",
                             "%r -> %s (%s)" % (prompt, decision["channel"],
                                                decision["reason"]))

    def test_router_source_keeps_the_real_scripts(self):
        """Guard: if the file is ever re-mangled these literals vanish."""
        source = (ROOT / "background" / "intent_router.py").read_text(
            encoding="utf-8")
        for literal in ("\u091C\u093E\u0930\u094D\u0935\u093F\u0938",   # जार्विस
                        "\u30B8\u30E3\u30FC\u30D3\u30B9",                 # ジャービス
                        "\u65E5\u672C\u8A9E",                               # 日本語
                        "\u306B\u307B\u3093\u3054"):                       # にほんご
            # assertTrue, not assertIn: assertIn prints the whole container on
            # failure, and the container here is the entire module source.
            self.assertTrue(literal in source,
                            "intent_router.py lost %r - the file is mangled "
                            "again (cp1252 double-encoding)" % literal)

if __name__ == "__main__":
    unittest.main()
