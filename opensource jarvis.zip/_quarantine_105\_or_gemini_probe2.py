# -*- coding: utf-8 -*-
"""_or_gemini_probe2.py — read OPENROUTER_API_KEY from .env and probe gemini-2.5-flash."""
import json, os, urllib.request, urllib.error

key = None
for line in open('.env', encoding='utf-8'):
    line = line.strip()
    if line.startswith('OPENROUTER_API_KEY='):
        key = line.split('=', 1)[1]
        break
print('key_from_env:', bool(key), len(key or ''))

def post(url, model, timeout=25):
    req = urllib.request.Request(url, data=json.dumps(
        {'model': model, 'messages': [{'role': 'user', 'content': 'say OK'}], 'max_tokens': 10}
    ).encode(), headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read(3000))
            return r.status, (d.get('choices') or [{}])[0].get('message', {}).get('content', '') or d.get('model', '')
    except urllib.error.HTTPError as e:
        return e.code, e.read(300).decode('utf-8', 'ignore')[:120]
    except Exception as e:
        return None, type(e).__name__ + ' ' + str(e)[:70]

st, body = post('https://openrouter.ai/api/v1/chat/completions', 'google/gemini-2.5-flash')
print('OPENROUTER_MODEL=google/gemini-2.5-flash -> HTTP', st, repr(body))
