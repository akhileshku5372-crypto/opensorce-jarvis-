"""Installed-app index + safe launcher (fills the "app list" gap).

WHY: the loopback bridge keeps a fixed ~20-entry APP_ALLOWLIST, so any other
program on this laptop ("open figma", "open steam") dead-ended with
"approved local app list mein nahi hai". This module indexes what is ACTUALLY
installed, so JARVIS can drive the real machine instead of 20 hardcoded names:

  * Start Menu shortcuts (.lnk) - user + all users  -> os.startfile(lnk)
  * Windows "App Paths" registry keys              -> os.startfile(exe)
  * a fixed built-in URI/exe set (same posture as the bridge allowlist)
  * Store/UWP packages from the AppModel repository + AppxManifest.xml

Safety (AGENTS.md):
  * the launch target ALWAYS comes from the index. The user's words only
    SELECT a row (fuzzy match); they are never a path, argv, or shell input.
  * launches are argument-free: os.startfile(<indexed path>) and, for UWP,
    explorer.exe with one validated "shell:AppsFolder\\<AUMID>" argument.
  * weak or ambiguous matches ask the user instead of guessing.
  * no shell, no arbitrary executable paths, no user-supplied argv.
"""
from __future__ import annotations

import difflib
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

INDEX_TTL_S = 300.0
MAX_ROWS = 1500
MAX_STORE_PACKAGES = 300
MIN_SCORE = 0.66
MIN_QUERY_CHARS = 3

_URI_ALLOWLIST = ("ms-settings:", "ms-photos:", "microsoft.windows.camera:",
                  "mail:", "ms-clock:", "whatsapp:")
_AUMID_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}![A-Za-z0-9_.\-]{1,64}$")
# Start Menu maintenance shortcuts ("Uninstall KMPlayer", "Repair Tool", "Readme")
# are not apps to open. Dropped at index time so "open X" can never land on an
# uninstaller/installer by fuzzy name.
_MAINTENANCE_NAME_RE = re.compile(
    r"^(?:uninstall\w*|remove|change|modify|repair|readme|help|documentation|"
    r"docs|release notes|user manual|license|check for updates|setup|install)\b",
    re.I)

# Fixed built-ins: the same names the bridge already treats as approved.
_BUILTINS = (
    ("notepad", "exe", r"%SystemRoot%\System32\notepad.exe"),
    ("calculator", "exe", r"%SystemRoot%\System32\calc.exe"),
    ("paint", "exe", r"%SystemRoot%\System32\mspaint.exe"),
    ("file explorer", "exe", r"%SystemRoot%\explorer.exe"),
    ("task manager", "exe", r"%SystemRoot%\System32\Taskmgr.exe"),
    ("command prompt", "exe", r"%SystemRoot%\System32\cmd.exe"),
    ("terminal", "exe", r"%SystemRoot%\System32\wt.exe"),
    ("settings", "uri", "ms-settings:"),
    ("photos", "uri", "ms-photos:"),
    ("camera", "uri", "microsoft.windows.camera:"),
    ("mail", "uri", "mail:"),
)

_cache = {"at": 0.0, "rows": [], "lock": threading.RLock()}


def _expand(value: str) -> str:
    return os.path.expandvars(str(value or "")).strip()


def _row(name: str, kind: str, target: str, source: str):
    clean = re.sub(r"\s+", " ", str(name or "")).strip(" .-_")
    if not clean or len(clean) > 80 or not target:
        return None
    if _MAINTENANCE_NAME_RE.match(clean):
        return None
    return {"name": clean, "kind": kind, "target": _expand(target), "source": source}


def _norm(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", str(value or "").casefold()))


def _start_menu_dirs():
    dirs = []
    appdata = os.environ.get("APPDATA")
    programdata = os.environ.get("PROGRAMDATA")
    if appdata:
        dirs.append(Path(appdata) / "Microsoft/Windows/Start Menu/Programs")
    if programdata:
        dirs.append(Path(programdata) / "Microsoft/Windows/Start Menu/Programs")
    return tuple(d for d in dirs if d.is_dir())


def index_from_dirs(dirs, limit: int = MAX_ROWS):
    """Pure helper (also used by tests): .lnk names -> index rows."""
    rows = []
    for base in dirs:
        try:
            for path in Path(base).rglob("*.lnk"):
                if len(rows) >= limit:
                    return rows
                row = _row(path.stem, "lnk", str(path), "start-menu")
                if row:
                    rows.append(row)
        except OSError:
            continue
    return rows


def _index_app_paths(rows):
    if os.name != "nt":
        return
    try:
        import winreg
    except Exception:
        return
    roots = ((winreg.HKEY_LOCAL_MACHINE,
              r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"),
             (winreg.HKEY_LOCAL_MACHINE,
              r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths"),
             (winreg.HKEY_CURRENT_USER,
              r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"))
    for hive, key_path in roots:
        try:
            with winreg.OpenKey(hive, key_path) as key:
                for index in range(winreg.QueryInfoKey(key)[0]):
                    if len(rows) >= MAX_ROWS:
                        return
                    try:
                        sub_name = winreg.EnumKey(key, index)
                        with winreg.OpenKey(key, sub_name) as sub:
                            exe, _ = winreg.QueryValueEx(sub, "")
                    except OSError:
                        continue
                    row = _row(Path(str(sub_name)).stem, "exe", str(exe), "app-paths")
                    if row:
                        rows.append(row)
        except OSError:
            continue


def _index_store_apps(rows):
    """UWP/Store apps: AppxAllUserStore package list + AppxManifest.xml -> AUMID.

    Notes: Win11 24H2 replaced the old AppModel\\Repository registry hive with
    StateRepository, so the package list comes from AppxAllUserStore and the
    manifest is read from WindowsApps (readable for the current user here -
    verified). Anything unreadable is skipped instead of guessed.
    """
    if os.name != "nt" or len(rows) >= MAX_ROWS:
        return
    try:
        import winreg
        import xml.etree.ElementTree as ET
    except Exception:
        return
    key_path = (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Appx"
                r"\AppxAllUserStore\Applications")
    winapps = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "WindowsApps"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as key:
            packages = [winreg.EnumKey(key, index)
                        for index in range(winreg.QueryInfoKey(key)[0])]
    except OSError:
        return
    parsed = 0
    for package in packages:
        if parsed >= MAX_STORE_PACKAGES or len(rows) >= MAX_ROWS:
            return
        manifest = winapps / package / "AppxManifest.xml"
        try:
            if not manifest.is_file():
                continue
        except OSError:
            continue
        try:
            root = ET.parse(str(manifest)).getroot()
        except Exception:
            continue
        parsed += 1
        props = root.find("{*}Properties")
        is_framework = props is not None and str(
            props.findtext("{*}Framework") or "").lower() == "true"
        if is_framework:
            continue
        parts = package.split("_")
        if len(parts) < 2:
            continue
        family = "%s_%s" % (parts[0], parts[-1])
        label = ""
        if props is not None:
            label = str(props.findtext("{*}DisplayName") or "")
        if not label or label.startswith("ms-resource:"):
            label = parts[0]
        for app_node in root.findall("{*}Applications/{*}Application"):
            app_id = str(app_node.get("Id") or "").strip()
            aumid = "%s!%s" % (family, app_id)
            if not app_id or not _AUMID_RE.match(aumid):
                continue
            row = _row(label, "aumid", aumid, "store")
            if row:
                rows.append(row)



# One CONSTANT, read-only PowerShell query. No user input is ever interpolated:
# it returns Start-menu apps (name + AUMID), including per-user MSIX/Store apps
# that the registry hives miss (WhatsApp Desktop is installed that way and was
# invisible to every other source). The result is only used as index rows.
_STARTS_APPS_PS = ("Get-StartApps | Select-Object Name,AppID | "
                   "ConvertTo-Json -Compress")
_STARTS_APPS_TTL_S = 300.0
_starts_apps_cache = {"at": 0.0, "rows": []}


def _start_apps_rows(max_rows=400):
    if os.name != "nt":
        return []
    now = time.monotonic()
    with _starts_apps_cache_lock:
        if _starts_apps_cache["rows"] and now - _starts_apps_cache["at"] < _STARTS_APPS_TTL_S:
            return list(_starts_apps_cache["rows"])
    try:
        done = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             _STARTS_APPS_PS],
            capture_output=True, text=True, timeout=15, shell=False,
            stdin=subprocess.DEVNULL, creationflags=getattr(
                subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        return []
    raw = (done.stdout or "").strip()
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    rows = []
    for item in data or []:
        if not isinstance(item, dict) or len(rows) >= max_rows:
            continue
        aumid = str(item.get("AppID") or "").strip()
        if not aumid or not _AUMID_RE.match(aumid):
            continue
        row = _row(str(item.get("Name") or aumid.split("!")[0]), "aumid", aumid,
                   "start-apps")
        if row:
            rows.append(row)
    with _starts_apps_cache_lock:
        _starts_apps_cache["rows"] = list(rows)
        _starts_apps_cache["at"] = now
    return list(rows)


_starts_apps_cache_lock = threading.Lock()


def _index_start_apps(rows):
    """Merge the Start-apps (Store/MSIX) source into the index rows."""
    if os.name != "nt" or len(rows) >= MAX_ROWS:
        return
    rows.extend(_start_apps_rows())


def build_index(force: bool = False, extra_dirs=None):
    """Cached, real index of installed apps (never fabricates entries)."""
    with _cache["lock"]:
        now = time.monotonic()
        if not force and _cache["rows"] and now - _cache["at"] < INDEX_TTL_S:
            return list(_cache["rows"])
        rows = []
        for name, kind, target in _BUILTINS:
            row = _row(name, kind, target, "builtin")
            if row:
                rows.append(row)
        rows.extend(index_from_dirs(extra_dirs or _start_menu_dirs()))
        _index_app_paths(rows)
        _index_store_apps(rows)
        _index_start_apps(rows)
        seen, unique = set(), []
        for row in rows:
            key = (_norm(row["name"]), _norm(row["target"]))
            if key in seen:
                continue
            seen.add(key)
            unique.append(row)
        _cache["rows"] = unique[:MAX_ROWS]
        _cache["at"] = now
        return list(_cache["rows"])


def count() -> int:
    return len(build_index())


def _score(query: str, name: str) -> float:
    q, n = _norm(query), _norm(name)
    if not q or not n:
        return 0.0
    if q == n:
        return 1.0
    if n.startswith(q):
        return 0.94
    if q in n:
        return 0.9
    # Token level: voice asks in concepts ("music player"), apps are named
    # differently ("Windows Media Player", "VLC"). Any meaningful query word
    # inside the app name counts - never above the fuzzy ceiling, so an exact
    # name still wins.
    tokens = [t for t in q.split() if len(t) >= 3]
    if tokens:
        hits = sum(1 for t in tokens if t in n)
        if hits:
            return min(0.72 + 0.05 * (hits - 1), 0.89)
    return difflib.SequenceMatcher(None, q, n).ratio()


def search(query: str, limit: int = 8):
    clean = str(query or "").strip()
    if len(_norm(clean)) < MIN_QUERY_CHARS:
        return []
    scored = []
    for row in build_index():
        score = _score(clean, row["name"])
        if score >= MIN_SCORE:
            scored.append((score, row))
    scored.sort(key=lambda item: (-item[0], len(item[1]["name"])))
    return [dict(row, score=round(score, 3)) for score, row in scored[:limit]]


def resolve(query: str):
    """(row, alternatives) - exact/prefix hit wins; otherwise best or nothing."""
    matches = search(query, limit=6)
    if not matches:
        return (None, [])
    best = matches[0]
    if best["score"] >= 0.999:
        return (best, matches[1:4])   # exact/normalized name: no ambiguity
    if len(matches) >= 2 and abs(matches[0]["score"] - matches[1]["score"]) < 0.03:
        # Do near-identical names ka matlab hai guessing - user se poocho.
        # (Prefix/fuzzy scores par ye check zaroori hai: "report" se "Report
        # Lab" aur "Report Maker" dono 0.94 hain.)
        return (None, matches[:5])
    return (best, matches[1:4])


def _startfile(target: str):
    if not hasattr(os, "startfile"):
        raise RuntimeError("ye capability sirf Windows par hai")
    os.startfile(target)      # noqa: S606 - indexed target, no argv, no shell


def _spawn(argv):
    subprocess.Popen(argv, shell=False, close_fds=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL)


_GENERIC_TITLE_TOKENS = frozenset(("microsoft", "windows", "store", "apps"))


def _foreground_title() -> str:
    if os.name != "nt":
        return ""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        handle = user32.GetForegroundWindow()
        length = int(user32.GetWindowTextLengthW(handle))
        buffer = ctypes.create_unicode_buffer(length + 2)
        user32.GetWindowTextW(handle, buffer, length + 2)
        return str(buffer.value or "")
    except Exception:
        return ""


def _window_matches(name: str, timeout_s: float = 2.5) -> bool:
    """Honest check for UWP launches: did a matching window really appear?"""
    tokens = [t for t in _norm(name).split()
              if len(t) >= 4 and t not in _GENERIC_TITLE_TOKENS]
    if not tokens or os.name != "nt":
        return True
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        title = _foreground_title().casefold()
        if title and any(token in title for token in tokens):
            return True
        time.sleep(0.25)
    return False



def launch(row: dict):
    """(ok, message). Target must be an index row we produced ourselves."""
    if not isinstance(row, dict):
        return (False, "invalid app row")
    kind = str(row.get("kind") or "")
    target = str(row.get("target") or "")
    name = str(row.get("name") or "app")[:40]
    if kind == "uri":
        if target not in _URI_ALLOWLIST:
            return (False, "URI allowlist mein nahi hai")
    elif kind == "aumid":
        if not _AUMID_RE.match(target):
            return (False, "AUMID shape invalid")
    elif kind in ("exe", "lnk"):
        if not target:
            return (False, "target khaali hai")
    else:
        return (False, "unknown kind: %s" % kind[:20])
    try:
        if kind == "aumid":
            explorer = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                                    "explorer.exe")
            _spawn([explorer, "shell:AppsFolder\\" + target])
            if not _window_matches(name):
                return (True, "Sir, '%s' ka launch request bhej diya, lekin "
                              "window 2.5s mein confirm nahi hui." % name)
            return (True, "Sir, '%s' khol diya." % name)
        _startfile(target)
    except Exception as exc:
        return (False, "%s: %s" % (type(exc).__name__, exc))
    return (True, "Sir, '%s' launch kar diya." % name)


def launch_name(name: str):
    """Voice/bridge fallback: (handled, message, row)."""
    row, alternatives = resolve(name)
    if row is None:
        if alternatives:
            names = ", ".join(a["name"] for a in alternatives[:5])
            return (True, "Sir, '%s' exact match nahi mila. Ye milte-julte apps "
                          "hain: %s. Poora naam boliye." % (str(name)[:40], names), None)
        return (False, "", None)
    ok, message = launch(row)
    if ok:
        return (True, message, row)
    return (True, "Sir, '%s' launch nahi ho paya: %s" % (row["name"][:40], message), row)


def describe() -> str:
    total = count()
    if total <= len(_BUILTINS):
        return ("Sir, app index abhi sirf built-ins (%d) dekh raha hai - Start "
                "Menu/registry scan Windows par hi chalta hai." % total)
    return ("Sir, app index ready: %d installed apps indexed (Start Menu + App "
            "Paths + Store). Naam boliye, fuzzy match se launch kar dunga." % total)


def _load_cortex():
    import importlib.util
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def tool_find_apps(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        query = cortex.read_str_param(args, "query", required=False, default="",
                                      max_chars=60)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if query:
        rows = search(query, limit=10)
        if rows:
            return cortex.ok_result("\n".join(
                "%s (%s, score %.2f)" % (r["name"], r["source"], r["score"])
                for r in rows), index_size=count())
        # No direct hit: show real index candidates so the planner can pick a
        # name and launch it. Never fabricated, never a guess.
        head = build_index()[:40]
        return cortex.ok_result(
            "(query '%s' ka direct match nahi mila; index ke pehle %d apps "
            "dikha rahe hain)\n%s" % (str(query)[:40], len(head),
                                      "\n".join("%s\t%s" % (r["name"], r["source"])
                                                for r in head)),
            index_size=count())
    rows = build_index()[:40]
    return cortex.ok_result("\n".join("%s\t%s" % (r["name"], r["source"])
                                      for r in rows), index_size=count())


_ZERO_WIDTH_RE = re.compile(r"[\u200b\u200c\u200d\ufeff\u00ad]")


def _norm_title(text: str) -> str:
    """Casefolded title with zero-width marks and runs of space removed.

    Edge's window title is 'New tab - Personal - Microsoft\u200b Edge' - that
    invisible U+200B between the words made every 'microsoft edge' substring
    match fail, so the app could be launched but never recognised afterwards.
    """
    s = _ZERO_WIDTH_RE.sub("", str(text or "")).casefold()
    return re.sub(r"\s+", " ", s).strip()


def window_appeared(*needles, timeout_s: float = 6.0) -> str:
    """Poll visible top-level windows until one matches a needle. '' if not.

    os_launch_app used to report success the moment a launch was dispatched, so
    a dead launch and a slow launch looked identical to Sir and to the agent
    loop. Matching is substring on the normalised window title.
    """
    import ctypes
    import time as _t
    wants = [_norm_title(n) for n in needles if str(n or "").strip()]
    wants = [w for w in wants if w]
    if not wants:
        return ""
    try:
        user32 = ctypes.windll.user32
    except Exception:
        return ""
    deadline = _t.time() + max(0.0, timeout_s)
    while True:
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def _cb(hwnd, _lparam):
            if user32.IsWindowVisible(hwnd):
                n = user32.GetWindowTextLengthW(hwnd)
                if n:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    title = (buf.value or "").strip()
                    low = _norm_title(title)
                    if any(w in low for w in wants):
                        found.append(title)
            return True

        try:
            user32.EnumWindows(_cb, 0)
        except Exception:
            return ""
        if found:
            return found[0][:90]
        if _t.time() >= deadline:
            return ""
        _t.sleep(0.4)


def tool_launch_app(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        name = cortex.read_str_param(args, "name", max_chars=60)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    handled, message, row = launch_name(name)
    if not handled:
        return cortex.fail_result(
            "installed apps ke index mein '%s' nahi mila (index: %d apps)."
            % (name[:40], count()))
    # Dispatch is not delivery. Wait for a real window whose title matches, and
    # say plainly when none shows up - until this line existed, every launch
    # reported success whether or not anything appeared on screen.
    title = window_appeared(name, (row or {}).get("name") if row else "",
                            timeout_s=6.0)
    if not title:
        return cortex.fail_result(
            "Sir, '%s' dispatch to hua par %ds tak koi window nahi dikhi. "
            "Launch confirm nahi ho paya - ise 'ho gaya' mat samajna."
            % (name[:40], 6), retryable=True)
    extra = {"window": title}
    if row:
        extra.update(app=row["name"], kind=row["kind"], source=row["source"])
    return cortex.ok_result(message, **extra)


def specs() -> list:
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("os_find_apps",
                        "Laptop ke installed apps index mein naam search karo "
                        "(Start Menu, App Paths, Store).",
                        tool_find_apps,
                        parameters={"query": "app naam ka hissa (khaali = pehle 40)"}),
        cortex.ToolSpec("os_launch_app",
                        "Installed app ko uske indexed shortcut/exe se launch karo "
                        "(no shell, koi argument nahi).",
                        tool_launch_app,
                        parameters={"name": "app ka naam, jaise 'spotify'"},
                        requires_confirmation=True),
    ]


