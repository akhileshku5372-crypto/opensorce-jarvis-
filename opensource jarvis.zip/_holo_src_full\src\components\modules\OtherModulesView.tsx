/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ActiveModule } from '../layout/JarvisSidebar';
import {
  Brain as BrainIcon,
  Shield,
  Key,
  Database,
  Terminal,
  Cpu,
  Layers,
  Sparkles,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { soundFx } from '../../services/soundEffects';

interface OtherModulesViewProps {
  module: ActiveModule;
  onOpenBrain: () => void;
}

export const OtherModulesView: React.FC<OtherModulesViewProps> = ({
  module,
  onOpenBrain,
}) => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 font-rajdhani">
      {/* Top Banner */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-slate-950/80 border border-cyan-500/30 backdrop-blur">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-orbitron font-bold text-lg text-white capitalize">
              {module.replace('settings_', 'Settings / ').replace('_', ' ')}
            </h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code bg-cyan-950 text-cyan-300 border border-cyan-500/40">
              MODULE ONLINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            JARVIS Core Architecture • Subsystem Integration Active
          </p>
        </div>

        <button
          onClick={() => {
            onOpenBrain();
            soundFx.playSelect();
          }}
          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-cyan-600/30 border border-cyan-400/80 hover:bg-cyan-500/40 text-cyan-200 transition-all text-xs font-orbitron font-semibold shadow-[0_0_15px_rgba(6,182,212,0.3)]"
        >
          <BrainIcon className="w-4 h-4 text-cyan-300 animate-pulse" />
          <span>Switch to 3D Neural Brain</span>
        </button>
      </div>

      {/* Module-specific view content */}
      {module === 'dashboard' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-xs text-cyan-400 uppercase font-semibold">Active Agent Core</div>
            <div className="text-xl font-orbitron font-bold text-white mt-1">Autonomous JARVIS</div>
            <p className="text-xs text-slate-400 mt-2">
              Multi-model reasoning loop connected with Windows Bridge (127.0.0.1:7778).
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-xs text-emerald-400 uppercase font-semibold">Cognitive Status</div>
            <div className="text-xl font-orbitron font-bold text-white mt-1">Cognitive Hub Active</div>
            <p className="text-xs text-slate-400 mt-2">
              3D Neural holographic visualizer active in Settings &gt; Brain.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="text-xs text-purple-400 uppercase font-semibold">Local Memory Store</div>
            <div className="text-xl font-orbitron font-bold text-white mt-1">2.4 / 10 GB</div>
            <p className="text-xs text-slate-400 mt-2">
              Persistent ChromaDB vector partition in D:\JARVIS_DATA.
            </p>
          </div>
        </div>
      )}

      {module === 'memory_core' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-purple-500/30">
            <div className="flex items-center gap-2 text-purple-300 font-orbitron font-bold text-sm">
              <Database className="w-4 h-4" /> ChromaDB Local Vector Store
            </div>
            <div className="grid grid-cols-3 gap-3 mt-3 text-xs">
              <div className="p-3 bg-black/40 rounded border border-slate-800">
                <div className="text-slate-400">Partition Path</div>
                <div className="text-white font-mono-code font-bold mt-1">D:\JARVIS_DATA\jarvis\memory</div>
              </div>
              <div className="p-3 bg-black/40 rounded border border-slate-800">
                <div className="text-slate-400">Indexed Vectors</div>
                <div className="text-purple-300 font-mono-code font-bold mt-1">14,820 Embeddings</div>
              </div>
              <div className="p-3 bg-black/40 rounded border border-slate-800">
                <div className="text-slate-400">Quota Ceiling</div>
                <div className="text-cyan-300 font-mono-code font-bold mt-1">10.0 GB (Hard Cap)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {module === 'settings_apikeys' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="flex items-center gap-2 text-cyan-300 font-orbitron font-bold text-sm mb-3">
              <Key className="w-4 h-4" /> Safe Provider Credentials Metadata (.env)
            </div>
            <div className="space-y-2 text-xs font-mono-code">
              {[
                { name: 'GOOGLE_API_KEY / GEMINI', status: 'Configured (Active)', model: 'gemini-flash-latest' },
                { name: 'GROQ_API_KEY', status: 'Configured (Active)', model: 'openai/gpt-oss-120b' },
                { name: 'NVIDIA_API_KEY', status: 'Configured (Active)', model: 'meta/llama-3.1-70b-instruct' },
                { name: 'OPENROUTER_API_KEY', status: 'Configured (Active)', model: 'nex-agi/nex-n2.5-mini:free' },
                { name: 'FIRECRAWL_API_KEY', status: 'Configured (Active)', model: 'firecrawl-v1' },
                { name: 'EDGE_TTS_PORT', status: 'Port 7782 (Local)', model: 'en-GB-RyanNeural' },
                { name: 'WINDOWS_BRIDGE_PORT', status: 'Port 7778 (Local)', model: '127.0.0.1:7778' },
              ].map((prov, i) => (
                <div key={i} className="flex items-center justify-between p-2.5 rounded bg-black/40 border border-slate-800/80">
                  <div>
                    <span className="text-white font-bold">{prov.name}</span>
                    <span className="text-slate-400 ml-2">({prov.model})</span>
                  </div>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> {prov.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {module !== 'dashboard' && module !== 'memory_core' && module !== 'settings_apikeys' && (
        <div className="p-6 rounded-xl bg-slate-950/60 border border-slate-800 text-center space-y-3">
          <Cpu className="w-10 h-10 text-cyan-400 mx-auto" />
          <h3 className="text-white font-orbitron font-bold text-sm">
            {module.toUpperCase().replace('_', ' ')} SUBSYSTEM
          </h3>
          <p className="text-slate-400 text-xs max-w-md mx-auto">
            This module is connected to the primary JARVIS event bus and communicates directly with the neural cognitive visualizer.
          </p>
        </div>
      )}
    </div>
  );
};
