# KamiSensei Local Podcast Engine — Kokoro-82M installer (100% offline TTS).
# Run once:  powershell -NoProfile -ExecutionPolicy Bypass -File background/_install_kokoro.ps1
#
# NOTE: we deliberately install `kokoro --no-deps` and pull its runtime deps
# individually. `kokoro` pins `numpy==1.26.4` (no wheel for Python 3.13 -> the
# source build aborts the whole transaction) and `misaki[ja]` drags in `mojimoko`
# (a Cython/C-extension with no Python 3.13 wheel -> MSVC build failure), which
# is exactly why the previous `pip install kokoro soundfile "misaki[ja]"` stayed
# stuck / silent and leaves `import soundfile` / `import misaki` broken.
# Kokoro only needs: numpy (present), torch (present), transformers, scipy,
# loguru, soundfile, misaki + fugashi + unidic-lite (the JA G2P backend).
Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Path)
$log = "_pip_kokoro.log"
"=== kokoro install $(Get-Date -Format o) ===" | Out-File $log

function Step([string]$name, [scriptblock]$block) {
  Write-Host "[kokoro] $name ..."
  & $block *>> $log
  if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] $name FAILED — see $log"; exit $LASTEXITCODE }
}

Step "kokoro (no-deps, pure wheel)" { python -m pip install --no-deps kokoro }
Step "transformers + scipy + loguru + soundfile" { python -m pip install transformers scipy loguru soundfile }
Step "misaki + JA G2P backend (fugashi + unidic-lite, NO mojimomo)" { python -m pip install misaki fugashi unidic-lite }

# 3) Verify imports on the foreground interpreter.
& python _probe_kokoro.py
$ok = $LASTEXITCODE
if ($ok -ne 0) { Write-Error "[kokoro] import probe FAILED — see $log"; exit $ok }

Write-Host "[kokoro] Installed OK. Start the engine with:  python background/kokoro_podcast.py"
Write-Host "[kokoro] Health check:                 curl http://127.0.0.1:7779/health"
"DONE (rc=$ok)" | Out-File $log -Append