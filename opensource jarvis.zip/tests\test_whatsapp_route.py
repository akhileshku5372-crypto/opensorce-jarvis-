"""WhatsApp send route + confirm/deny gate + hard-fail fall-through.

Locks in the live 23-Sep transcript bugs:
  * "meine whatsapp open hai akhilesh koo hello send ka" died with
    "Exact English command boliye" (no route existed; the second-chance
    OS scan trapped the mid-sentence "open");
  * the brain only hallucinated a confirm — no pending task was staged;
  * the confirm gate was exact-match only, so real Hinglish confirmations
    ("haan bhej do") could never pass, and there was no deny/cancel path.

Stdlib only — no mic, no TTS, no network (brain + screen agent faked).

Run:  npm run test:whatsapp
"""
import importlib.util
import os
import sys
import tempfile
import unittest
import webbrowser
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Every test run targets a THROWAWAY ledger/recipes store - the owner's live
# artifacts/brain/*.json must never be written by a test process.
os.environ.setdefault(
    "JARVIS_RESULTS_STORE",
    os.path.join(tempfile.gettempdir(), "jarvis_test_results.json"))
os.environ.setdefault(
    "JARVIS_ROUTINES_STORE",
    os.path.join(tempfile.gettempdir(), "jarvis_test_routines.json"))


def _refuse(name):
    """No unit test may open a real app or window (see test_whatsapp_sender.py)."""
    def refuse(target, *args, **kwargs):
        raise AssertionError(
            "test tried to really %s %r - patch _open_desktop()/_open_browser()"
            % (name, str(target)[:90]))
    return refuse


if hasattr(os, "startfile"):
    os.startfile = _refuse("startfile")
webbrowser.open = _refuse("open in browser")
webbrowser.open_new = _refuse("open in browser")
webbrowser.open_new_tab = _refuse("open in browser")


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "voice_engine", ROOT / "background" / "voice_engine.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load_engine()

def _load_bg(name):
    """Load a background module under its plain name (voice_engine uses it)."""
    spec = importlib.util.spec_from_file_location(name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


WHATSAPP = _load_bg("whatsapp_sender")
WM = _load_bg("whatsapp_media")            # voice_engine imports it by plain name
ENGINE._wa_sender_mod = WHATSAPP          # one module identity for the tests

TURN2 = "meine whatsapp open hai akhilesh koo hello send ka"
TURN5 = ("ok soo joo tume karna hia open karolo but ajj tum akhilesh ko "
         "whatsapp pe ( i am ) ka message skae")


class _FakeAgent:
    """Records stage/confirm/cancel without pyautogui or the VLM."""

    def __init__(self):
        self.staged_task = None
        self.staged_prompt = None
        self.confirmed = 0
        self.cancelled = 0
        self._pending = False

    def stage_task(self, task, prompt=None):
        self.staged_task = str(task or "")
        self.staged_prompt = prompt
        self._pending = True
        return prompt or ("Sir, screen task staged hai: %s. Boliye confirm."
                          % self.staged_task[:80])

    def has_pending(self):
        return self._pending

    def confirm_pending(self):
        self._pending = False
        self.confirmed += 1
        return "Sir, task confirm hokar chala."

    def cancel_pending(self):
        self._pending = False
        self.cancelled += 1
        return "Theek hai Sir, staged task cancel kar diya."


class ParseTest(unittest.TestCase):
    POSITIVE = [
        (TURN2, "akhilesh", "hello"),
        (TURN5, "akhilesh", "i am"),
        ("whatsapp pe akhilesh ko hello bhejo", "akhilesh", "hello"),
        ("akhilesh ko whatsapp pe good morning bhej do", "akhilesh",
         "good morning"),
        ("send whatsapp message to amit saying on my way", "amit",
         "on my way"),
        # Live 2026-10-19, his two typed attempts. Both missed every pattern
        # because the app mention does not sit next to the send verb - the first
        # one reached the chat brain, which asked him to confirm an action that
        # did not exist, and nothing was ever sent.
        ("Vishesh ko hello bhej do WhatsApp par", "Vishesh", "hello"),
        ("vishesh ko mein offline hun bol do message on whatsapp", "vishesh",
         "mein offline hun"),
        # Send-command glue sits between the verb and the name in spoken form:
        # the recipient came back as "do akhilesh" / "kar do akhilesh" and the
        # search box would have been filled with that.
        ("whatsapp pe bhej do akhilesh ko hello", "akhilesh", "hello"),
        ("whatsapp pe kar do akhilesh ko hello bhejna", "akhilesh", "hello"),
    ]
    NEGATIVE = [
        "open whatsapp",
        "whatsapp kholo",
        "whatsapp pe akhilesh ka number kya hai",
        "kyu youtube open nahi ho raha",
        "whatsapp chal raha hai",
    ]
    # Live 2026-10-17 22:11 incident (jarvis-voice-out-2.log): the parser took a
    # slice of the MESSAGE as the RECIPIENT -
    #   [WHATSAPP] autosend start: recipient='yeh line bhejni hai tumh'
    #   [WHATSAPP] search results ready, pressing enter to open the first match
    #   [WHATSAPP] autosend DONE
    # i.e. it typed a stranger's sentence into the search box and sent it to
    # whatever chat came up first. A recipient that is really message text must
    # never parse; refusing is the only safe answer.
    MISPARSED_RECIPIENT = [
        "I am working tonight to this line, yeh line bhejni hai tumhe U ko "
        "WhatsApp par, U Y O U ko.",
        "yeh line bhejni hai tumhe U ko WhatsApp par",
        "i am working tonight to this line ko whatsapp par bhejo",
    ]

    def test_positive_parses(self):
        for raw, contact, message in self.POSITIVE:
            with self.subTest(raw=raw):
                self.assertEqual(ENGINE._parse_whatsapp_message(raw),
                                 (contact, message))

    def test_negatives_never_parse(self):
        for raw in self.NEGATIVE:
            with self.subTest(raw=raw):
                self.assertIsNone(ENGINE._parse_whatsapp_message(raw))

    def test_message_text_is_never_accepted_as_a_recipient(self):
        for raw in self.MISPARSED_RECIPIENT:
            with self.subTest(raw=raw):
                parsed = ENGINE._parse_whatsapp_message(raw)
                if parsed is not None:
                    self.fail("parsed a recipient out of message text: %r -> %r"
                              % (raw[:60], parsed))

    def test_contact_cleaner_refuses_message_text(self):
        for junk in ("yeh line bhejni hai tumhe U",
                     "i am working tonight to this line",
                     "message bhejna hai tumhe"):
            with self.subTest(junk=junk):
                self.assertEqual(ENGINE._clean_wa_target(junk), "")
        # A real saved name must still survive.
        for name in ("akhilesh", "Amit Kumar Sharma", "vishesh", "mummy"):
            with self.subTest(name=name):
                self.assertNotEqual(ENGINE._clean_wa_target(name), "")

    def test_a_body_that_is_only_command_noise_means_the_message_is_missing(self):
        """The body must never BE the command - or the app noun.

        "akhilesh ko whatsapp pe message bhej do" used to slice the body as
        "message" (and as "whatsapp" from another pattern), i.e. JARVIS would have
        sent that literal word to a real person. The route asks "kya bhejna hai?"
        when the body comes back empty.
        """
        for raw, name in (("akhilesh ko whatsapp pe message bhej do", "akhilesh"),
                          ("akhilesh ko message bhej do whatsapp pe", "akhilesh"),
                          ("akhilesh ko bhej do whatsapp par", "akhilesh"),
                          ("vishesh ko whatsapp par message bhejna hai", "vishesh")):
            with self.subTest(raw=raw):
                self.assertEqual(ENGINE._parse_whatsapp_message(raw), (name, ""))
        # A real one-word message is never all-noise and must survive.
        self.assertEqual(ENGINE._parse_whatsapp_message(
            "akhilesh ko ok bhej do whatsapp par"), ("akhilesh", "ok"))


class OpenChatParseTest(unittest.TestCase):
    """Open-chat is read-only and must not steal a real send."""

    def test_open_chat_phrases(self):
        for raw, contact in [
            ("WhatsApp pe Akhilesh ka chat kholo", "Akhilesh"),
            ("Open Akhilesh's chat on WhatsApp and see what message was sent",
             "Akhilesh"),
            ("open the whatsapp chat of Akhilesh", "Akhilesh"),
            ("Akhilesh ka chat kholo WhatsApp pe", "Akhilesh"),
            ("Akhilesh's chat on WhatsApp kholo", "Akhilesh"),
            ("Akhilesh ka chat WhatsApp pe open karo", "Akhilesh"),
            ("open the chat with Akhilesh on WhatsApp", "Akhilesh"),
        ]:
            with self.subTest(raw=raw):
                self.assertEqual(ENGINE._parse_whatsapp_open_chat(raw), contact)

    def test_app_launch_and_send_are_never_open_chat(self):
        for raw in [
            "open whatsapp",
            "open whatsapp chat",
            "reconnect whatsapp",
            "open whatsapp send hello to akhilesh",
            "Akhilesh ko whatsapp pe message bhejo",
        ]:
            with self.subTest(raw=raw):
                self.assertIsNone(ENGINE._parse_whatsapp_open_chat(raw))


class PhraseGateTest(unittest.TestCase):
    CONFIRM = ["confirm", "confirm karo", "haan", "han", "haan karo", "yes",
               "okay haan", "ok confirm", "chalo karo", "kar do", "bhej do",
               "haan bhej do", "execute", "bilkul", "go ahead", "ji"]
    DENY = ["no", "nahi", "nhi", "cancel", "cancel kar do", "mat karo",
            "rehne do", "not now", "nahi karo"]
    NEVER = ["kyu nahi ho paya", TURN2, TURN5,
             "whatsapp pe akhilesh ko hello bhejo", "open youtube"]

    def test_confirms_pass(self):
        for raw in self.CONFIRM:
            with self.subTest(raw=raw):
                self.assertIsNotNone(ENGINE._CONFIRM_PHRASE_RE.match(raw),
                                     "%r must confirm" % raw)

    def test_deny_wins(self):
        for raw in self.DENY:
            with self.subTest(raw=raw):
                self.assertIsNone(ENGINE._CONFIRM_PHRASE_RE.match(raw),
                                  "%r must NOT confirm" % raw)
                self.assertIsNotNone(ENGINE._DENY_PHRASE_RE.match(raw),
                                     "%r must deny" % raw)

    def test_long_sentences_never_confirm(self):
        for raw in self.NEVER:
            with self.subTest(raw=raw):
                self.assertIsNone(ENGINE._CONFIRM_PHRASE_RE.match(raw))



class RouteTest(unittest.TestCase):
    """run_command level: stage -> confirm / deny, plus brain fall-through."""

    def setUp(self):
        self.spoken = []
        self.opened = []
        self.agent = _FakeAgent()
        self._real_speak = ENGINE.speak
        self._real_agent_fn = ENGINE._screen_agent
        self._real_brain = ENGINE.brain
        # The phone-number contact book no longer exists (owner order), so there
        # is nothing to isolate here anymore.
        self._real = {"installed": WHATSAPP.desktop_app_installed,
                   "desktop": WHATSAPP._open_desktop,
                   "window": WHATSAPP._window_is_whatsapp,
                   "browser": WHATSAPP._open_browser,
                   "can": WHATSAPP.can_autosend}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)), True)[1]
        ENGINE._screen_agent = lambda: self.agent
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        # No real app/browser during tests: the link is only recorded.
        WHATSAPP.desktop_app_installed = lambda: (True, "test evidence")
        WHATSAPP.can_autosend = lambda force=False: (False, "autosend off in this test")
        ENGINE._WA_PENDING.clear()
        WHATSAPP._open_desktop = lambda url: (self.opened.append(url), True)[1]
        WHATSAPP._window_is_whatsapp = lambda timeout_s=3.0: True
        WHATSAPP._open_browser = lambda url: (self.opened.append(url), True)[1]
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real_speak
        ENGINE._screen_agent = self._real_agent_fn
        ENGINE.brain = self._real_brain
        WHATSAPP.desktop_app_installed = self._real["installed"]
        WHATSAPP._open_desktop = self._real["desktop"]
        WHATSAPP._window_is_whatsapp = self._real["window"]
        WHATSAPP._open_browser = self._real["browser"]
        WHATSAPP.can_autosend = self._real["can"]
        ENGINE._WA_PENDING.clear()

    def _route(self, text):
        self.spoken.clear()
        self.opened.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_turn2_reaches_whatsapp_route_with_the_message(self):
        # LIVE BUG (23-Sep): "meine whatsapp open hai akhilesh koo hello send ka"
        # died with "Exact English command boliye" and the brain only
        # hallucinated a confirm. It must now open a REAL deep link carrying the
        # parsed contact + message (browser recorded, not launched).
        handled, said = self._route(TURN2)
        self.assertTrue(handled)
        self.assertEqual(len(self.opened), 1, self.opened)
        self.assertEqual(self.opened[0], "whatsapp://send?text=hello")
        self.assertNotIn("Exact English", said)
        self.assertIn("Send", said)

    def test_turn5_reaches_route_not_hard_fail(self):
        handled, said = self._route(TURN5)
        self.assertTrue(handled)
        self.assertEqual(len(self.opened), 1, self.opened)
        self.assertIn("text=i%20am", self.opened[0])
        self.assertNotIn("Exact English", said)

    def test_open_chat_reaches_verified_desktop_driver(self):
        calls = []
        old_open = WHATSAPP.open_chat
        old_prev = WHATSAPP.last_preview
        WHATSAPP.open_chat = lambda name: (
            calls.append(name), (True, "Akhilesh", "header verified"))[1]
        WHATSAPP.last_preview = lambda name: "Akhilesh 12:22 pm hello"
        self.addCleanup(setattr, WHATSAPP, "open_chat", old_open)
        self.addCleanup(setattr, WHATSAPP, "last_preview", old_prev)

        handled, said = self._route("WhatsApp pe Akhilesh ka chat kholo")
        self.assertTrue(handled)
        self.assertEqual(calls, ["Akhilesh"])
        self.assertIn("Akhilesh", said)
        self.assertIn("khol diya", said)

    def test_open_chat_read_request_reports_only_observed_preview(self):
        old_open = WHATSAPP.open_chat
        old_prev = WHATSAPP.last_preview
        WHATSAPP.open_chat = lambda name: (True, "Akhilesh", "header verified")
        WHATSAPP.last_preview = lambda name: "Akhilesh 12:22 pm hello"
        self.addCleanup(setattr, WHATSAPP, "open_chat", old_open)
        self.addCleanup(setattr, WHATSAPP, "last_preview", old_prev)

        handled, said = self._route(
            "Open Akhilesh's chat on WhatsApp and see what message was sent")
        self.assertTrue(handled)
        self.assertIn("Last message preview", said)
        self.assertIn("hello", said)

    def test_hinglish_confirm_executes_staged_task(self):
        self.agent.stage_task("open WhatsApp and type hi")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.agent.confirmed, 1)
        self.assertIn("confirm", said.lower())

    def test_deny_cancels_staged_task(self):
        self.agent.stage_task("open WhatsApp and type hi")
        handled, said = self._route("nahi karo")
        self.assertTrue(handled)
        self.assertEqual(self.agent.cancelled, 1)
        self.assertEqual(self.agent.confirmed, 0)
        self.assertIn("cancel", said.lower())

    def test_unrelated_chat_never_gates_on_pending(self):
        self.agent.stage_task("open WhatsApp and type hi")
        handled, said = self._route("aaj kaisa mausam hai")
        self.assertTrue(handled)
        self.assertEqual(self.agent.confirmed, 0)
        self.assertEqual(self.agent.cancelled, 0)
        self.assertIn("BRAIN_FALLTHROUGH", said)

    def test_brain_can_never_claim_a_message_it_did_not_send(self):
        # Reaching the LLM means no deterministic action ran this turn, so a
        # send-claim out of the brain is fabricated. Live 2026-10-17 JARVIS told
        # Sir a WhatsApp message had gone out when nothing had been sent.
        ENGINE.brain = lambda raw, ui=None: "Sir, maine amit ko message bhej diya."
        handled, said = self._route("aaj kaisa mausam hai")
        self.assertTrue(handled)
        self.assertIn("nahi bheja", said)
        self.assertNotIn("bhej diya", said)

    def test_mid_sentence_open_falls_to_brain_not_hard_fail(self):
        # The exact trap that killed the live transcript: "open" mid-sentence
        # used to hard-fail with "Exact English command boliye".
        handled, said = self._route("kyu youtube open nahi ho raha yaar")
        self.assertTrue(handled)
        self.assertIn("BRAIN_FALLTHROUGH", said)
        self.assertNotIn("Exact English", said)

    def test_command_shape_keeps_exact_english_error(self):
        # Command-shaped utterances must still get the truthful error
        # (the LLM must never invent success for a missed OS action).
        handled, said = self._route("open")
        self.assertTrue(handled)
        self.assertIn("Exact English", said)



class RecipientListTest(unittest.TestCase):
    """'akhilesh aur amit ko hello bhejo' must reach BOTH chats.

    Live 2026-10-17: the list was parsed as ONE name, WhatsApp searched for
    "akhilesh aur amit", found nothing, and the reply still reported a send.
    """

    def test_list_is_split_into_names(self):
        self.assertEqual(ENGINE._wa_recipients("akhilesh aur amit"),
                         ["akhilesh", "amit"])
        self.assertEqual(ENGINE._wa_recipients("amit and rahul"),
                         ["amit", "rahul"])
        self.assertEqual(ENGINE._wa_recipients("amit, priya, rahul"),
                         ["amit", "priya", "rahul"])
        self.assertEqual(ENGINE._wa_recipients("akhilesh aur amit dono"),
                         ["akhilesh", "amit"])

    def test_message_text_is_still_refused_as_a_list(self):
        for junk in ("yeh line bhejni hai tumhe U",
                     "i am working tonight and this line",
                     "message bhejna hai tumhe"):
            with self.subTest(junk=junk):
                self.assertEqual(ENGINE._wa_recipients(junk), [])

    def test_too_many_recipients_are_refused(self):
        self.assertEqual(ENGINE._wa_recipients("a, b, c, d, e, f, g"), [])

    def test_parse_returns_every_name(self):
        self.assertEqual(
            ENGINE._parse_whatsapp_message(
                "whatsapp pe akhilesh aur amit ko hello bhejo"),
            ("akhilesh, amit", "hello"))


class VerifiedSendTest(unittest.TestCase):
    """Only the verified desktop path may claim a send.

    The screen agent (VLM + pyautogui) cannot prove delivery and narrates its
    own steps, so live JARVIS spoke an internal instruction - "click the chat
    named ..., type ..., and send" - and then reported the message as sent.
    """

    SEND = "whatsapp pe akhilesh aur amit ko hello bhejo"

    def setUp(self):
        self.spoken = []
        self.sent = []
        self.fail_names = set()
        self.agent = _FakeAgent()
        self._real = {"speak": ENGINE.speak, "agent": ENGINE._screen_agent,
                      "brain": ENGINE.brain, "sender": ENGINE._wa_sender_mod,
                      "can": WHATSAPP.can_autosend,
                      "autosend": WHATSAPP.autosend_to,
                      "send_to": WHATSAPP.send_to,
                      "skip": ENGINE._WA_SKIP_UNTIL["at"]}
        ENGINE.speak = lambda message, ui=None: (
            self.spoken.append(str(message)), True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._wa_sender_mod = WHATSAPP
        ENGINE._WA_SKIP_UNTIL["at"] = 0.0
        ENGINE._WA_PENDING.clear()
        WHATSAPP.can_autosend = lambda force=False: (True, "test ready")
        WHATSAPP.send_to = lambda recipient, message: (
            False, "Sir, draft bhi nahi bana (test).")

        def fake_autosend(recipient, message):
            self.sent.append((str(recipient), str(message)))
            if str(recipient) in self.fail_names:
                return (False, "Sir, %s ka chat nahi mila - kuch nahi bheja."
                        % recipient)
            return (True, "Sir, %s ko message bhej diya - preview pe verify hua."
                    % recipient)

        WHATSAPP.autosend_to = fake_autosend
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE.brain = self._real["brain"]
        ENGINE._wa_sender_mod = self._real["sender"]
        ENGINE._WA_SKIP_UNTIL["at"] = self._real["skip"]
        ENGINE._WA_PENDING.clear()
        WHATSAPP.can_autosend = self._real["can"]
        WHATSAPP.autosend_to = self._real["autosend"]
        WHATSAPP.send_to = self._real["send_to"]

    def _route(self, text, env=None):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        with patch.dict(os.environ, env or {}):
            handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_both_chats_get_the_message(self):
        handled, said = self._route(self.SEND, {"JARVIS_WHATSAPP_CONFIRM": "0"})
        self.assertTrue(handled)
        self.assertEqual(self.sent, [("akhilesh", "hello"), ("amit", "hello")])
        self.assertIn("akhilesh", said)
        self.assertIn("amit", said)

    def test_partial_failure_is_not_reported_as_a_send(self):
        self.fail_names = {"amit"}
        _handled, said = self._route(self.SEND, {"JARVIS_WHATSAPP_CONFIRM": "0"})
        self.assertEqual(len(self.sent), 2)
        self.assertIn("amit", said)
        self.assertIn("nahi", said.lower())
        self.assertNotIn("sab ko", said)

    def test_confirm_prompt_names_every_recipient_before_anything_is_sent(self):
        _handled, said = self._route(self.SEND)
        self.assertEqual(self.sent, [])
        self.assertIn("akhilesh", said)
        self.assertIn("amit", said)
        self.assertIn("confirm", said.lower())
        _handled, _said = self._route("haan bhej do")
        self.assertEqual(self.sent, [("akhilesh", "hello"), ("amit", "hello")])

    def test_unavailable_autosend_never_stages_a_screen_task(self):
        WHATSAPP.can_autosend = lambda force=False: (False, "pyautogui nahi mila")
        _handled, said = self._route("whatsapp pe akhilesh ko hello bhejo")
        self.assertIsNone(self.agent.staged_task)
        self.assertEqual(self.sent, [])
        for leaked in ("chat named", "press Enter", "message box"):
            self.assertNotIn(leaked, said)

    def test_no_sender_module_never_stages_a_screen_task(self):
        real = ENGINE._whatsapp_sender
        ENGINE._whatsapp_sender = lambda: None
        try:
            _handled, said = self._route("whatsapp pe akhilesh ko hello bhejo")
        finally:
            ENGINE._whatsapp_sender = real
        self.assertIsNone(self.agent.staged_task)
        self.assertEqual(self.sent, [])
        for leaked in ("chat named", "press Enter", "message box"):
            self.assertNotIn(leaked, said)


class MediaParseTest(unittest.TestCase):
    """'akhilesh ko photo bhejo whatsapp par' is a FILE request.

    It must parse BEFORE the text route (the text route would have typed the
    literal word "photo" into the chat), and a sentence that merely CONTAINS
    the word photo must stay out of the media route.
    """

    POSITIVE = [
        ("akhilesh ko photo bhejo whatsapp par", ("akhilesh", "photo", "", "")),
        ("whatsapp par akhilesh ko photo bhejo", ("akhilesh", "photo", "", "")),
        ("akhilesh ko ye photo bhejo whatsapp pe", ("akhilesh", "photo", "", "")),
        ("whatsapp pe bhej do akhilesh ko ye photo", ("akhilesh", "photo", "", "")),
        # "screenshot" means the Screenshots folder's newest image.
        ("screenshot bhejo akhilesh ko whatsapp pe",
         ("akhilesh", "photo", "", "Screenshots")),
        # A file name with an extension is explicit enough on its own. The word
        # "pdf" inside it names the kind document.
        ("akhilesh ko report.pdf bhejo whatsapp par",
         ("akhilesh", "document", "report.pdf", "")),
        # The jpg extension itself names the kind now (bare extensions speak).
        ("akhilesh ko IMG_2211.jpg whatsapp pe bhej do",
         ("akhilesh", "photo", "IMG_2211.jpg", "")),
        ("akhilesh ko downloads folder se video bhejo whatsapp par",
         ("akhilesh", "video", "", "downloads")),
        ("vishesh ko audio bhejo whatsapp pe", ("vishesh", "audio", "", "")),
        ("whatsapp pe akhilesh ko gana bhejo", ("akhilesh", "audio", "", "")),
        ("akhilesh ko file bhejo whatsapp par", ("akhilesh", "document", "", "")),
    ]
    NEGATIVE = [
        # a plain text send - the text route owns it
        "akhilesh ko hello bhejo whatsapp par",
        # refusal, never a media request
        "photo mat bhejo whatsapp par",
        # no send verb at all
        "whatsapp pe meri kal ki photo dekhi maine",
        # the media word is far from the verb and no 'ko' anchor - a story
        # about a photo, not a send command
        "whatsapp pe bhej do ye ki meri naya photo kaisa laga",
        # not whatsapp at all
        "telegram par photo bhej do",
    ]

    def test_positive_parses(self):
        for raw, want in self.POSITIVE:
            with self.subTest(raw=raw):
                self.assertEqual(ENGINE._parse_whatsapp_media(raw), want)

    def test_negatives_never_parse(self):
        for raw in self.NEGATIVE:
            with self.subTest(raw=raw):
                self.assertIsNone(ENGINE._parse_whatsapp_media(raw))

    def test_a_media_word_without_a_recipient_is_unreadable(self):
        self.assertTrue(ENGINE._wa_media_request_unread("photo bhejo whatsapp par"))
        self.assertFalse(ENGINE._wa_media_request_unread("akhilesh ko photo bhejo"))
        self.assertFalse(ENGINE._wa_media_request_unread("photo mat bhejo whatsapp par"))


class _FakeMediaSender:
    """Records autosend_file calls; nothing real is touched."""

    def __init__(self):
        self.calls = []

    def autosend_file(self, contact, path):
        self.calls.append((contact, path))
        return (True, "Sir, %s ko file bhej diya (fake)." % contact)

    def autosend_to(self, contact, message):
        return (True, "Sir, %s ko message bhej diya (fake)." % contact)

    def can_autosend(self, force=False):
        return (False, "off in test")

    def send_to(self, recipient, message):
        return (True, "draft (fake)")

    def list_contacts(self):
        return []


class MediaRouteTest(unittest.TestCase):
    """Route level: media request -> spoken confirm naming the REAL file ->
    'haan bhej do' sends through the sender, 'nahi karo' does not."""

    def setUp(self):
        import time as _time
        import tempfile
        self.spoken = []
        self.agent = _FakeAgent()
        self.sender = _FakeMediaSender()
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.folder = Path(self._tmp.name) / "JARVIS-Send"
        self.folder.mkdir()
        self.png = self.folder / "photo1.png"
        self.png.write_bytes(b"p" * 10)

        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender,
                      "folder": None}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: self.sender
        # Patch the module voice_engine ACTUALLY imports at runtime (the last
        # island loaded into sys.modules wins), not this file's own copy.
        self._wm_mod = sys.modules.get("whatsapp_media")
        if self._wm_mod is None:
            self._wm_mod = _load_bg("whatsapp_media")
        self._real["folder"] = self._wm_mod.default_folder
        self._wm_mod.default_folder = lambda: self.folder
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        self._wm_mod.default_folder = self._real["folder"]
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    def test_media_command_asks_confirm_and_names_the_real_file(self):
        handled, said = self._route("akhilesh ko photo bhejo whatsapp par")
        self.assertTrue(handled)
        self.assertIn("photo1.png", said, "the confirm must name the RESOLVED file")
        self.assertIn("confirm", said.casefold())
        self.assertEqual(self.sender.calls, [], "nothing is sent before confirm")
        self.assertEqual(ENGINE._WA_MEDIA_PENDING.get("chat"), "akhilesh")
        self.assertEqual(Path(ENGINE._WA_MEDIA_PENDING.get("path")),
                         self.png.resolve())

    def test_confirm_sends_through_the_sender(self):
        self._route("akhilesh ko photo bhejo whatsapp par")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls,
                         [("akhilesh", str(self.png.resolve()))])
        self.assertIn("fake", said)
        self.assertEqual(ENGINE._WA_MEDIA_PENDING, {})

    def test_deny_sends_nothing(self):
        self._route("vishesh ko photo bhejo whatsapp par")
        handled, said = self._route("nahi karo")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertIn("nahi bheja", said)

    def test_the_creating_sentence_can_never_confirm_itself(self):
        raw = "akhilesh ko photo bhejo whatsapp par"
        self._route(raw)
        handled, said = self._route(raw)
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertIn("haan bhej do", said)

    def test_an_expired_pending_is_dropped(self):
        import time as _time
        self._route("akhilesh ko photo bhejo whatsapp par")
        ENGINE._WA_MEDIA_PENDING["at"] = _time.time() - 300
        _handled, said = self._route("haan bhej do")
        self.assertEqual(self.sender.calls, [], "an expired pending never sends")
        self.assertEqual(ENGINE._WA_MEDIA_PENDING, {})

    def test_an_empty_folder_is_reported_not_sent(self):
        self.png.unlink()
        handled, said = self._route("akhilesh ko photo bhejo whatsapp par")
        self.assertTrue(handled)
        self.assertIn("khaali", said)
        self.assertEqual(ENGINE._WA_MEDIA_PENDING, {})

    def test_a_no_recipient_request_is_answered_by_the_router(self):
        handled, said = self._route("photo bhejo whatsapp par")
        self.assertTrue(handled)
        self.assertIn("kisko", said.casefold())
        self.assertEqual(ENGINE._WA_MEDIA_PENDING, {})

    def test_a_sentence_that_only_mentions_photo_reaches_the_brain(self):
        handled, said = self._route(
            "whatsapp pe bhej do ye ki meri naya photo kaisa laga")
        self.assertTrue(handled)
        self.assertIn("BRAIN_FALLTHROUGH", said)
        self.assertEqual(ENGINE._WA_MEDIA_PENDING, {})
        self.assertEqual(self.sender.calls, [])


class _FakeTextSender:
    """Records autosend_to calls; nothing real is touched."""
    def __init__(self):
        self.calls = []

    def autosend_to(self, contact, message):
        self.calls.append((contact, message))
        return (True, "Sir, %s ko message bhej diya (fake)." % contact)

    def can_autosend(self, force=False):
        return (True, "ready in test")

    def send_to(self, recipient, message):
        return (True, "draft (fake)")

    def list_contacts(self):
        return []


def _clean_or_raw(text):
    """The body the route stores for a dictated message - same rule as the
    last-text recovery in run_command (cleaned, raw kept when cleaning empties)."""
    return ENGINE._clean_wa_message(text) or " ".join(str(text).split())


class LongMessageAndAskTest(unittest.TestCase):
    """A long dictated body goes out WHOLE, and the two-step flow works both
    ways: command-first ("vishesh ko bhejo" -> kya bhejna hai? -> he dictates),
    and message-first (he dictates, then "vishesh ko bhejo" offers it back).
    In every path the confirm sentence shows the content before any send."""

    def setUp(self):
        self.spoken = []
        self.agent = _FakeAgent()
        self.sender = _FakeTextSender()
        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: self.sender
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()

    def _route(self, text, env=None):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        with patch.dict(os.environ, env or {}):
            handled = ENGINE.run_command(text, None, None, "typed")
        return handled, " ".join(self.spoken)

    # >160 chars: the old _clean_wa_message truncation would have cut it, and
    # the old .{1,200} parse caps would have refused it outright.
    LONG_BODY = ("office ka server kal raat crash ho gaya tha backup se "
                 "restore kiya hai phir dependency lock karke ek ghante me "
                 "build pass karai hai review bhi le liya deploy bas baki "
                 "hai subah tak sab chal jayega downtime ke baad sabse "
                 "pahale incident report post karunga")

    def test_a_long_body_is_parsed_whole(self):
        raw = "vishesh ko %s bhejo whatsapp par" % self.LONG_BODY
        parsed = ENGINE._parse_whatsapp_message(raw)
        self.assertIsNotNone(parsed)
        _contact, body = parsed
        expected = ENGINE._clean_wa_message(self.LONG_BODY)
        self.assertGreater(len(body), 200, "a long body must not be truncated")
        self.assertEqual(body, expected)

    def test_long_send_asks_confirm_with_the_real_length_and_sends_whole(self):
        raw = "vishesh ko %s bhejo whatsapp par" % self.LONG_BODY
        handled, said = self._route(raw)
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [], "nothing sent before confirm")
        self.assertIn("pura message", said)
        self.assertIn("vishesh", said)
        stored = ENGINE._WA_PENDING.get("message") or ""
        self.assertGreater(len(stored), 200, "pending keeps the WHOLE body")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [("vishesh", stored)])
        self.assertIn("vishesh", said)

    def test_command_first_then_dictation_becomes_the_message(self):
        _handled, said = self._route("vishesh ko bhejo")
        self.assertTrue(said)
        self.assertIn("kya bhejna hai", said)
        self.assertEqual(self.sender.calls, [])
        self.assertEqual(ENGINE._WA_PENDING, {})
        self.assertEqual(ENGINE._WA_MSG_ASK.get("recipient"), "vishesh")
        dictation = ("server ka backup ab poora chal gaya hai deployment "
                     "bhi clean ho gayi hai")
        handled, said = self._route(dictation)
        self.assertTrue(handled)
        expected = ENGINE._clean_wa_message(dictation)
        self.assertEqual(ENGINE._WA_PENDING.get("recipient"), "vishesh")
        self.assertEqual(ENGINE._WA_PENDING.get("message"), expected)
        self.assertEqual(ENGINE._WA_MSG_ASK, {})
        self.assertIn("confirm", said)
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [("vishesh", expected)])

    def test_a_confirm_word_during_the_ask_is_not_a_message(self):
        self._route("vishesh ko bhejo")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertIn("message boliye", said)
        self.assertEqual(ENGINE._WA_PENDING, {})

    def test_cancel_during_the_ask_sends_nothing(self):
        self._route("vishesh ko bhejo")
        handled, said = self._route("cancel kar do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertEqual(ENGINE._WA_PENDING, {})
        self.assertEqual(ENGINE._WA_MSG_ASK, {})
        self.assertIn("kuch nahi bheja", said)

    def test_a_plain_deny_also_cancels_the_ask(self):
        self._route("vishesh ko bhejo")
        handled, said = self._route("nahi karo")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertEqual(ENGINE._WA_PENDING, {})
        self.assertEqual(ENGINE._WA_MSG_ASK, {})

    def test_a_media_request_during_the_ask_is_a_new_command(self):
        # folder content is not staged here; what matters is that the ask is
        # CLEARED and the media flow owns the turn (it will refuse honestly
        # because the fake folder search would need a real one - so assert the
        # ask state, not the media reply).
        self._route("vishesh ko bhejo")
        self.assertEqual(ENGINE._WA_MSG_ASK.get("recipient"), "vishesh")
        self._route("akhilesh ko photo bhejo whatsapp par")
        self.assertNotEqual(ENGINE._WA_MSG_ASK.get("recipient"), "vishesh")

    def test_dictation_first_then_command_offers_it_back(self):
        dictation = ("aaj server crash hua tha backup se restore kiya hai "
                     "subah tak sab theek ho jayega")
        handled, said = self._route(dictation)
        self.assertTrue(handled)
        restored = _clean_or_raw(dictation)
        self.assertEqual(ENGINE._WA_LAST_TEXT.get("text"),
                         " ".join(dictation.split()),
                         "an utterance nothing handled is remembered")
        self.assertIn("BRAIN_FALLTHROUGH", said)
        handled, said = self._route("vishesh ko bhejo")
        self.assertTrue(handled)
        self.assertGreater(len(said), 0)
        self.assertIn("confirm", said)
        self.assertEqual(ENGINE._WA_PENDING.get("recipient"), "vishesh")
        self.assertEqual(self.sender.calls, [], "confirm first, never a blind send")
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(len(self.sender.calls), 1)
        self.assertEqual(self.sender.calls[0][0], "vishesh")
        self.assertEqual(self.sender.calls[0][1], restored)


class BareExtensionMediaTest(unittest.TestCase):
    """'vishesh ko testing png bhej doo' (no 'whatsapp' word) is a FILE request.

    Live 2026-10-19: that exact owner sentence reached the chat brain because a
    bare extension was no media word at all."""

    def test_bare_extension_parses_without_an_app_word(self):
        parsed = ENGINE._parse_whatsapp_media("vishesh ko testing png bhej doo")
        self.assertIsNotNone(parsed)
        contact, kind, _name, _folder = parsed
        self.assertEqual(contact, "vishesh")
        self.assertEqual(kind, "photo")

    def test_a_photo_word_alone_still_needs_the_app_word(self):
        self.assertIsNone(
            ENGINE._parse_whatsapp_media("vishesh ko photo bhej doo"))

    def test_a_file_token_routes_without_an_app_word(self):
        parsed = ENGINE._parse_whatsapp_media("akhilesh ko report.pdf bhejo")
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed[0], "akhilesh")
        self.assertEqual(parsed[2], "report.pdf")


if __name__ == "__main__":
    unittest.main(verbosity=2)



OWNER_MSG = ("hello likh ke bhej do aur bol do ki aaj raat ho gayi hai "
             "aur mai Jarvis hu")
OWNER_SENT = "vishesh ko '%s' bhejni hai" % OWNER_MSG        # his real typing
OWNER_SENT_STT = "vishesh ko '%s' bhejni ha" % OWNER_MSG     # STT cut the tail


class OwnerShapesAndRetryTest(unittest.TestCase):
    """Live 2026-10-19, the evening when WhatsApp silently stopped sending:

    * "vishesh ko '<body>' bhejni hai" (+ STT's own "bhejni ha" cut) fell
      through the deterministic parser entirely, so the chat brain answered
      with a tool call it invented ("recipient_data parameter missing");
    * "haa bhej" was not a recogniseable confirm, so the pending expired;
    * after a REAL failure ("window nahi khuli") the natural next word -
      "abb bhejo / phir se bhejo" - had no path at all and the honesty
      guard told the owner "kuch nahi kiya".
    """

    def setUp(self):
        self.spoken = []
        self.sender = _FakeTextSender()
        self.agent = _FakeAgent()
        self._real = {"speak": ENGINE.speak, "brain": ENGINE.brain,
                      "agent": ENGINE._screen_agent,
                      "sender": ENGINE._whatsapp_sender}
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)),
                                                 True)[1]
        ENGINE.brain = lambda raw, ui=None: "BRAIN_FALLTHROUGH"
        ENGINE._screen_agent = lambda: self.agent
        ENGINE._whatsapp_sender = lambda: self.sender
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        ENGINE._WA_RETRY.clear()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real["speak"]
        ENGINE.brain = self._real["brain"]
        ENGINE._screen_agent = self._real["agent"]
        ENGINE._whatsapp_sender = self._real["sender"]
        ENGINE._WA_PENDING.clear()
        ENGINE._WA_MEDIA_PENDING.clear()
        ENGINE._WA_MSG_ASK.clear()
        ENGINE._WA_LAST_TEXT.clear()
        ENGINE._WA_RETRY.clear()

    def _route(self, text):
        self.spoken.clear()
        with ENGINE._recent_lock:
            ENGINE._recent.clear()
        with ENGINE._action_stamps_lock:
            ENGINE._action_stamps.clear()
        return ENGINE.run_command(text, None, None, "typed"), " ".join(self.spoken)

    def test_the_owner_sentence_parses_whole_body_no_quote_leakage(self):
        for raw in (OWNER_SENT, OWNER_SENT_STT):
            wa = ENGINE._parse_whatsapp_message(raw)
            self.assertIsNotNone(wa, "owner's real shape must parse: %r" % raw)
            contact, body = wa
            self.assertEqual(contact, "vishesh")
            self.assertEqual(body, _clean_or_raw(OWNER_MSG))

    def test_confirm_ask_shows_body_and_each_haa_shape_sends_it(self):
        for confirm in ("haa bhej", "haa bhej do"):
            ask = self._route(OWNER_SENT)[1]     # fresh pending per shape
            self.assertIn("hello", ask)          # the ask shows the real body
            self.assertEqual(self.sender.calls, [], "nothing before confirm")
            handled, said = self._route(confirm)
            self.assertTrue(handled)
            self.assertEqual(self.sender.calls, [("vishesh", _clean_or_raw(OWNER_MSG))])
            self.assertIn("bhej diya", said)
            ENGINE._WA_PENDING.clear()
            ENGINE._WA_RETRY.clear()
            self.sender.calls.clear()

    def test_nahi_shapes_still_never_confirm(self):
        for deny in ("nahi bhejo", "mat bhejo", "nahi karo"):
            with self.subTest(deny=deny):
                self._route(OWNER_SENT)
                handled, said = self._route(deny)
                self.assertTrue(handled)
                self.assertEqual(self.sender.calls, [])
                self.assertEqual(ENGINE._WA_PENDING, {})
                self.sender.calls.clear()

    def test_nahi_shapes_still_never_confirm(self):
        for deny in ("nahi bhejo", "mat bhejo", "nahi karo"):
            with self.subTest(deny=deny):
                self._route(OWNER_SENT)
                handled, said = self._route(deny)
                self.assertTrue(handled)
                self.assertEqual(self.sender.calls, [])
                self.assertEqual(ENGINE._WA_PENDING, {})
                self.sender.calls.clear()

    def test_the_old_confirm_shapes_still_work(self):
        self._route(OWNER_SENT)
        handled, said = self._route("haan bhej do")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [("vishesh", _clean_or_raw(OWNER_MSG))])

    def test_a_failed_send_is_retried_by_the_same_words(self):
        class _WindowsClosed(_FakeTextSender):
            def __init__(self):
                _FakeTextSender.__init__(self)
                self.fail = True

            def autosend_to(self, contact, message):
                self.calls.append((contact, message))
                if self.fail:
                    self.fail = False
                    return (False, "WhatsApp app chal raha hai par window nahi "
                                   "khuli - app ko taskbar se open kijiye")
                return (True, "Sir, %s ko message bhej diya, preview verify."
                              % contact)
        failing = _WindowsClosed()
        self.sender = failing
        ENGINE._whatsapp_sender = lambda: failing
        handled, said = self._route(OWNER_SENT)
        self.assertTrue(handled)
        handled, said = self._route("haa bhej do")
        self.assertTrue(handled)
        self.assertIn("nahi", said)                       # the real reason
        cached = ENGINE._WA_RETRY.get("message") or ""
        self.assertIn("Jarvis hu", cached)                # SAME authorized body
        handled, said = self._route("phir se bhejo")      # natural next word
        self.assertTrue(handled)
        self.assertEqual(len(failing.calls), 2, "retry re-sends ONCE")
        self.assertEqual(failing.calls[1], ("vishesh", _clean_or_raw(OWNER_MSG)))
        self.assertIn("verify", said)
        # success clears the retry so a stale message is never sent again
        self.assertEqual(ENGINE._WA_RETRY, {})

    def test_abb_bhejo_after_a_failure_also_retries(self):
        class _Refused(_FakeTextSender):
            def autosend_to(self, contact, message):
                self.calls.append((contact, message))
                self.counter = getattr(self, "counter", 0) + 1
                if self.counter == 1:
                    return (False, "search me koi chat match nahi hui")
                return (True, "Sir, %s ko message bhej diya." % contact)
        refused = _Refused()
        ENGINE._whatsapp_sender = lambda: refused
        self.sender = refused
        self._route(OWNER_SENT)
        self._route("haa bhej do")
        handled, said = self._route("abb bhejo")
        self.assertTrue(handled, "the failed-send retry path must exist")
        self.assertEqual(len(refused.calls), 2)
        self.assertIn("bhej diya", said)

    def test_retry_without_any_prior_attempt_is_honest(self):
        handled, said = self._route("phir se bhejo")
        self.assertTrue(handled)
        self.assertEqual(self.sender.calls, [])
        self.assertIn("dobara chala", said)
