"""Professional Content Writer (background/content_writer.py) + the Co-work ->
Agents template that drives it.

Network calls are monkeypatched, so this suite is deterministic and offline: it
proves the pipeline wiring, the real bytes on disk, and the honesty rules - not
that a provider happens to be reachable today.
"""
import importlib.util
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(name, path):
    """Load a background module under the shared cowork key (one identity)."""
    full = "jarvis_cowork_" + name
    existing = sys.modules.get(full)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(full, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[full] = mod
    spec.loader.exec_module(mod)
    return mod


CW = _load("content_writer", ROOT / "background" / "content_writer.py")
TOOLS = _load("cowork_tools", ROOT / "background" / "cowork_tools.py")
EXT = _load("extensions", ROOT / "background" / "extensions.py")
AF = _load("agent_flow", ROOT / "background" / "agent_flow.py")


DOC_SAMPLE = {
    "title": "Test Document",
    "subtitle": "A subtitle",
    "executive_summary": "Executive summary text.",
    "sections": [{"heading": "Section One", "body": "Body text. " * 60},
                 {"heading": "Section Two", "body": "More body text." * 30}],
    "key_findings": ["Finding one", "Finding two"],
    "conclusion": "Closing statement.",
    "_sources": [{"title": "Example", "url": "https://example.com"}],
}


class TopicParsingTest(unittest.TestCase):
    def test_single_topic(self):
        self.assertEqual(CW.parse_topics("quantum computing"),
                         ["quantum computing"])

    def test_comma_separated(self):
        self.assertEqual(CW.parse_topics("AI, robotics"), ["AI", "robotics"])

    def test_list_input(self):
        self.assertEqual(CW.parse_topics(["a", "b"]), ["a", "b"])

    def test_duplicates_are_dropped(self):
        self.assertEqual(CW.parse_topics(["AI", "ai", "AI"]), ["AI"])

    def test_empty_input_yields_nothing(self):
        self.assertEqual(CW.parse_topics(""), [])
        self.assertEqual(CW.parse_topics(None), [])

    def test_topic_cap_is_enforced(self):
        topics = ", ".join("t%d" % i for i in range(40))
        self.assertEqual(len(CW.parse_topics(topics)), CW.MAX_TOPICS)


class JsonExtractionTest(unittest.TestCase):
    def test_plain_json(self):
        self.assertEqual(CW._json_object('{"a": 1}')["a"], 1)

    def test_fenced_json(self):
        self.assertEqual(CW._json_object('```json\n{"a": 2}\n```')["a"], 2)

    def test_json_embedded_in_prose(self):
        self.assertEqual(CW._json_object('Sure!\n{"a": 3}\nDone.')["a"], 3)

    def test_brace_inside_string_does_not_break_scanner(self):
        got = CW._json_object('noise {"a": "x}y", "b": 4} tail')
        self.assertEqual(got.get("b"), 4)

    def test_garbage_returns_empty(self):
        self.assertEqual(CW._json_object("no json here"), {})


class PdfSafeTextTest(unittest.TestCase):
    """Base-14 Helvetica is single-byte; anything else prints as U+FFFD."""

    def test_smart_quotes_are_folded(self):
        out = CW._pdf_safe("it\u2019s a \u201ctest\u201d")
        self.assertNotIn("\u2019", out)
        self.assertIn("'", out)

    def test_dashes_are_folded(self):
        out = CW._pdf_safe("multi\u2011agent and end\u2013to\u2014end")
        self.assertEqual(out, "multi-agent and end-to-end")

    def test_ellipsis_is_folded(self):
        self.assertEqual(CW._pdf_safe("wait\u2026"), "wait...")

    def test_non_latin_is_dropped_not_mangled(self):
        out = CW._pdf_safe("emoji \U0001F600 here")
        self.assertTrue(all(ord(ch) < 256 for ch in out))
class RenderTest(unittest.TestCase):
    """The renderers must produce REAL, re-openable files."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="cw_test_"))

    def test_pdf_is_written_and_readable(self):
        out = self.tmp / "d.pdf"
        ok, note = CW.render_pdf(DOC_SAMPLE, out)
        self.assertTrue(ok, note)
        self.assertTrue(out.is_file())
        self.assertGreater(out.stat().st_size, 500)
        try:
            import fitz
        except Exception:
            self.skipTest("PyMuPDF not installed")
        doc = fitz.open(str(out))
        self.assertGreaterEqual(doc.page_count, 1)
        text = "\n".join(p.get_text() for p in doc)
        doc.close()
        self.assertIn("Test Document", text)
        self.assertIn("Finding one", text)
        self.assertNotIn("\ufffd", text)

    def test_pdf_wraps_across_pages_when_long(self):
        long_doc = {"title": "Long", "sections": [
            {"heading": "S%d" % i, "body": "word " * 900} for i in range(4)]}
        out = self.tmp / "long.pdf"
        ok, note = CW.render_pdf(long_doc, out)
        self.assertTrue(ok, note)
        try:
            import fitz
        except Exception:
            self.skipTest("PyMuPDF not installed")
        doc = fitz.open(str(out))
        self.assertGreater(doc.page_count, 1)
        doc.close()

    def test_docx_is_a_valid_zip_with_the_right_parts(self):
        out = self.tmp / "d.docx"
        ok, note = CW.render_docx(DOC_SAMPLE, out)
        self.assertTrue(ok, note)
        self.assertTrue(zipfile.is_zipfile(str(out)))
        with zipfile.ZipFile(str(out)) as z:
            names = z.namelist()
            self.assertIn("[Content_Types].xml", names)
            self.assertIn("word/document.xml", names)
            xml = z.read("word/document.xml").decode("utf-8")
        self.assertIn("Test Document", xml)
        self.assertIn("https://example.com", xml)

    def test_docx_escapes_xml_metacharacters(self):
        risky = {"title": "A & B <tag> \"quoted\"",
                 "sections": [{"heading": "h", "body": "5 < 6 & 7 > 2"}]}
        out = self.tmp / "risk.docx"
        ok, note = CW.render_docx(risky, out)
        self.assertTrue(ok, note)
        with zipfile.ZipFile(str(out)) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        self.assertIn("&amp;", xml)
        self.assertNotIn("<tag>", xml)

    def test_empty_document_is_refused(self):
        out = self.tmp / "empty.docx"
        ok, note = CW.render_docx({}, out)
        self.assertFalse(ok)
        self.assertIn("empty", note)


class ValidationTest(unittest.TestCase):
    def test_no_topic_is_an_error_with_a_hint(self):
        res = CW.write_document("")
        self.assertFalse(res["ok"])
        self.assertIn("topic", res["error"].lower())
        self.assertIn("hint", res)

    def test_bad_format_is_refused(self):
        res = CW.write_document("AI", fmt="xlsx")
        self.assertFalse(res["ok"])
        self.assertIn("xlsx", res["error"])
class OfflinePipelineTest(unittest.TestCase):
    """Full pipeline with the network stubbed - proves wiring, not luck."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="cw_pipe_"))
        self._doc_dir = CW.DOC_DIR
        self._research = CW.research
        self._compose = CW.compose
        self._pdf = CW.render_pdf
        CW.DOC_DIR = self.tmp

    def tearDown(self):
        CW.DOC_DIR = self._doc_dir
        CW.research = self._research
        CW.compose = self._compose
        CW.render_pdf = self._pdf

    def _fake_research(self, topics):
        return {"notes": "NOTE: real excerpt",
                "sources": [{"title": "Src", "url": "https://example.com/a"}],
                "errors": []}

    def _fake_compose(self, topics, notes, sources, tone, audience,
                      length="standard"):
        doc = dict(DOC_SAMPLE)
        doc["_sources"] = sources
        return doc, {"model": "test-model", "provider": "stub",
                     "attempted": ["test-model"], "fallbacks": []}

    def test_end_to_end_writes_both_formats(self):
        CW.research = self._fake_research
        CW.compose = self._fake_compose
        res = CW.write_document("AI agents", fmt="both")
        self.assertTrue(res["ok"], res)
        self.assertEqual(sorted(res["formats"]), ["docx", "pdf"])
        for entry in res["files"]:
            path = self.tmp / entry["name"]
            self.assertTrue(path.is_file(), entry)
            self.assertGreater(path.stat().st_size, 300)

    def test_result_reports_the_model_that_answered(self):
        CW.research = self._fake_research
        CW.compose = self._fake_compose
        self.assertEqual(CW.write_document("AI")["model"], "test-model")

    def test_fallbacks_are_surfaced_not_hidden(self):
        CW.research = self._fake_research

        def compose_with_fallback(*a, **kw):
            doc, meta = self._fake_compose(*a, **kw)
            meta["fallbacks"] = ["minimax/minimax-m3.1-flash:free: HTTP 429 rate limited"]
            return doc, meta

        CW.compose = compose_with_fallback
        res = CW.write_document("AI")
        self.assertTrue(res["fallbacks"])
        self.assertIn("429", res["fallbacks"][0])

    def test_research_errors_are_reported(self):
        CW.research = lambda topics: {"notes": "", "sources": [],
                                      "errors": ["topic: no results"]}
        CW.compose = self._fake_compose
        self.assertIn("topic: no results",
                      CW.write_document("AI")["research_errors"])

    def test_model_failure_never_produces_a_fake_document(self):
        CW.research = self._fake_research
        CW.compose = lambda *a, **kw: ({}, {"model": "", "provider": "",
                                            "attempted": ["a"],
                                            "fallbacks": ["a: HTTP 500"]})
        res = CW.write_document("AI")
        self.assertFalse(res["ok"])
        self.assertEqual(res["error"], "no model produced content")
        self.assertFalse(list(self.tmp.glob("*.pdf")))

    def test_render_failure_reports_instead_of_claiming_success(self):
        CW.research = self._fake_research
        CW.compose = self._fake_compose
        CW.render_pdf = lambda doc, path: (False, "boom")
        res = CW.write_document("AI", fmt="pdf")
        self.assertFalse(res["ok"])
        self.assertIn("boom", res["details"][0])

    def test_prose_reply_is_kept_not_discarded(self):
        CW.research = lambda t: {"notes": "", "sources": [], "errors": []}
        orig_llm = CW.llm
        CW.llm = lambda messages, max_tokens=1800: (
            "Plain prose, not JSON.", {"model": "m", "provider": "p",
                                       "attempted": ["m"], "fallbacks": []})
        try:
            res = CW.write_document("AI")
            self.assertTrue(res["ok"], res)
            self.assertIn("degraded", json.dumps(res))
        finally:
            CW.llm = orig_llm


class ToolHandlerTest(unittest.TestCase):
    def test_capabilities_handler_returns_ok(self):
        self.assertTrue(CW._tool_capabilities({})["ok"])

    def test_write_handler_without_topic_reports_error(self):
        self.assertFalse(CW._tool_write_document({})["ok"])

    def test_write_handler_passes_format_through(self):
        captured = {}
        original = CW.write_document

        def fake_write(topics_raw, fmt="pdf", **kw):
            captured["fmt"] = fmt
            return {"ok": False, "error": "stop-here"}

        CW.write_document = fake_write
        try:
            CW._tool_write_document({"topics": "AI", "format": "docx"})
            self.assertEqual(captured["fmt"], "docx")
        finally:
            CW.write_document = original


class RegistryIntegrationTest(unittest.TestCase):
    """UI-advertised == agent-discoverable == runtime-callable."""

    def setUp(self):
        self.registry = TOOLS.build_default_registry()
        EXT.register_plugin_tools(self.registry)

    def _name(self, suffix):
        return next(n for n in self.registry.names() if n.endswith(suffix))

    def test_both_writer_tools_are_registered(self):
        self.assertTrue(self._name("write_document"))
        self.assertTrue(self._name("writer_capabilities"))

    def test_write_is_confirmation_gated(self):
        spec = self.registry.get(self._name("write_document"))
        self.assertTrue(spec.requires_confirmation)
        self.assertIn("edit_files", spec.tags)

    def test_capabilities_probe_is_not_gated(self):
        spec = self.registry.get(self._name("writer_capabilities"))
        self.assertFalse(spec.requires_confirmation)

    def test_capabilities_tool_executes_for_real(self):
        out = self.registry.execute(self._name("writer_capabilities"), {})
        self.assertTrue(out["ok"], out)

    def test_tools_are_declared_in_the_plugin_manifest(self):
        manifest = json.loads((ROOT / "extensions" / "plugins" / "jarvis-modules"
                               / "plugin.json").read_text(encoding="utf-8"))
        declared = {t["name"] for t in manifest["tools"]}
        self.assertIn("write_document", declared)
        self.assertIn("writer_capabilities", declared)

    def test_write_tool_declares_its_parameters(self):
        spec = self.registry.get(self._name("write_document"))
        for key in ("topics", "format", "tone", "audience", "length"):
            self.assertIn(key, spec.parameters)

    def test_write_tool_outlives_the_20s_cortex_default(self):
        """Regression lock: the Content Writer flow used to ALWAYS fail.

        `write_document` does live web search + an LLM write + a PDF/DOCX
        render, which legitimately takes far longer than the cortex ToolSpec
        default of 20s. `_execute_with_timeout` joins the handler thread with
        `spec.timeout_s` and returns
        "tool 'plug_jarvis_modules_write_document' timed out after 20.0s",
        so every real run reported a failed node and an empty Artifacts list
        even though the identical pipeline succeeded when called directly.

        The fix declares an explicit `timeout_s` on the tool spec. Keep it far
        above the default so this cannot silently regress to 20s.
        """
        spec = self.registry.get(self._name("write_document"))
        self.assertGreater(
            spec.timeout_s, 60.0,
            "write_document needs a multi-minute budget (web search + LLM + "
            "PDF render); the 20s cortex default kills real runs.")


class TemplateTest(unittest.TestCase):
    def setUp(self):
        self.registry = TOOLS.build_default_registry()
        EXT.register_plugin_tools(self.registry)
        AF.configure(registry=lambda: self.registry, confirm=lambda n, a: True,
                     planner=None, complete=lambda p: "", skills=None, mcp=None,
                     models=lambda: [], cortex=None, permissions=None,
                     memory=None)

    def test_content_writer_template_is_listed(self):
        self.assertIn("content-writer", [t["id"] for t in AF.template_list()])

    def test_template_builds_input_tool_output(self):
        built = AF.template_build("content-writer")
        self.assertTrue(built)
        self.assertEqual([n["type"] for n in built["nodes"]],
                         ["input", "tool", "output"])

    def test_template_binds_the_real_registered_tool(self):
        cfg = next(n for n in AF.template_build("content-writer")["nodes"]
                   if n["type"] == "tool")["config"]
        self.assertTrue(cfg["tool"].endswith("write_document"))
        self.assertIsNotNone(self.registry.get(cfg["tool"]))

    def test_unknown_template_builds_nothing(self):
        self.assertEqual(AF.template_build("does-not-exist"), {})

    def test_binding_resolves_the_run_input(self):
        cfg = next(n for n in AF.template_build("content-writer")["nodes"]
                   if n["type"] == "tool")["config"]
        parsed = json.loads(AF._render(cfg["args_text"],
                                       {"topic": "quantum computing"}))
        self.assertEqual(parsed["topics"], "quantum computing")

    def test_created_template_agent_validates(self):
        ok, agent = AF.create_agent({"template": "content-writer"})
        self.assertTrue(ok, agent)
        try:
            report = AF.validate(agent)
            self.assertTrue(report.get("ok"), report)
            self.assertEqual(report.get("errors"), [])
            self.assertEqual(AF.plan_preview(agent)["unavailable_tools"], [])
        finally:
            AF.delete_agent(agent["id"])

    def test_created_agent_keeps_the_template_graph(self):
        ok, agent = AF.create_agent({"template": "content-writer"})
        self.assertTrue(ok, agent)
        try:
            ids = [n["id"] for n in agent["flow"]["nodes"]]
            self.assertIn("cw_in", ids)
            self.assertIn("cw_write", ids)
        finally:
            AF.delete_agent(agent["id"])

    def test_unknown_template_is_refused(self):
        ok, message = AF.create_agent({"template": "nope"})
        self.assertFalse(ok)
        self.assertIn("unknown template", str(message))


if __name__ == "__main__":
    unittest.main(verbosity=2)