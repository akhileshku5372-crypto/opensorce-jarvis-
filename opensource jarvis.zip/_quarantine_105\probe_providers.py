﻿import os, json, time, requests
for line in open(".env", encoding="utf-8"):
    line=line.strip()
    if line and not line.startswith("#") and "=" in line:
        k,v=line.split("=",1); os.environ.setdefault(k.strip(), v.strip())
out={}
def probe(name, url, headers, payload, timeout=30):
    t0=time.time()
    try:
        r=requests.post(url, headers=headers, json=payload, timeout=timeout)
        dt=time.time()-t0
        body=r.text[:200].replace("\n"," ")
        out[name]={"status":r.status_code,"secs":round(dt,1),"body":body}
    except Exception as e:
        out[name]={"error":type(e).__name__+": "+str(e)[:120]}
gm=os.environ.get("GOOGLE_MODEL","gemini-2.5-flash")
for keyname in ("GOOGLE_API_KEY","GOOGLE_API_KEY_2"):
    k=os.environ.get(keyname)
    if not k: continue
    probe(keyname, "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"%gm,
          {"x-goog-api-key":k}, {"contents":[{"parts":[{"text":"say OK"}]}],"generationConfig":{"maxOutputTokens":900}})
probe("groq","https://api.groq.com/openai/v1/chat/completions",
      {"Authorization":"Bearer "+os.environ.get("GROQ_API_KEY","")},
      {"model":os.environ.get("GROQ_MODEL","llama-3.3-70b-versatile"),"max_tokens":900,
       "messages":[{"role":"user","content":"say OK"}]})
probe("openrouter","https://openrouter.ai/api/v1/chat/completions",
      {"Authorization":"Bearer "+os.environ.get("OPENROUTER_API_KEY","")},
      {"model":os.environ.get("OPENROUTER_MODEL",""),"max_tokens":200,
       "messages":[{"role":"user","content":"say OK"}]})
probe("nvidia","https://integrate.api.nvidia.com/v1/chat/completions",
      {"Authorization":"Bearer "+os.environ.get("NVIDIA_API_KEY","")},
      {"model":os.environ.get("NVIDIA_MODEL","meta/llama-3.1-70b-instruct"),"max_tokens":100,
       "messages":[{"role":"user","content":"say OK"}]})
probe("xkiro","https://api.xkiro.com/v1/chat/completions",
      {"Authorization":"Bearer "+os.environ.get("XKIRO_API_KEY",""),
       "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"},
      {"model":os.environ.get("XKIRO_MODEL","qwen/qwen3.7-flash:free"),"max_tokens":100,
       "messages":[{"role":"user","content":"say OK"}]})
print(json.dumps(out, indent=1))
