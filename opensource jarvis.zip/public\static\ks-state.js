/* ══════════════════════════════════════════════════════════════════════════
 * KamiSensei State Core — artifact registry, persistence, notebook prefs
 * ────────────────────────────────────────────────────────────────────────────
 * Centralized state layer for the Studio workspace (loaded BEFORE app.js).
 *
 *  - `KS.artifacts` : typed artifact registry persisted in IndexedDB so large
 *                     generated bodies never bloat localStorage.
 *  - `KS.prefs`     : lightweight UI prefs (studio width, last artifact,
 *                     selected sources) persisted in the same IndexedDB meta
 *                     store — survives reloads and frontend state resets.
 *  - `KS.bus`       : tiny pub/sub so the Studio panel, library and viewer
 *                     stay in sync without DOM coupling.
 *
 * Artifact model (mirrors src/artifacts.ts on the server):
 *   { id, type: 'note'|'mind_map'|'report'|'flashcard_set'|'quiz'|'data_table',
 *     title, createdAt, updatedAt, sourceIds: string[], sourceCount,
 *     content: object|null, status: 'generating'|'ready'|'failed', error? }
 * ══════════════════════════════════════════════════════════════════════════ */
;(() => {
  const DB_NAME = 'kamisensei'
  const DB_VERSION = 1
  const ARTIFACT_STORE = 'artifacts'
  const META_STORE = 'meta'

  const ARTIFACT_TYPES = ['note', 'mind_map', 'report', 'flashcard_set', 'quiz', 'data_table', 'audio_overview', 'study_guide', 'briefing_doc', 'faq', 'timeline']

  /* ── Event bus ─────────────────────────────────────────────────────────── */
  const listeners = new Map()
  const bus = {
    on(event, fn) {
      if (!listeners.has(event)) listeners.set(event, new Set())
      listeners.get(event).add(fn)
      return () => bus.off(event, fn)
    },
    off(event, fn) {
      const set = listeners.get(event)
      if (set) set.delete(fn)
    },
    emit(event, payload) {
      const set = listeners.get(event)
      if (!set) return
      set.forEach((fn) => {
        try { fn(payload) } catch (err) { console.error(`[KS] listener for "${event}" failed:`, err) }
      })
    }
  }

  /* ── IndexedDB core ────────────────────────────────────────────────────── */
  let dbPromise = null

  function openDb() {
    if (dbPromise) return dbPromise
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB is not available in this browser.'))
        return
      }
      const req = indexedDB.open(DB_NAME, DB_VERSION)
      req.onupgradeneeded = () => {
        const db = req.result
        if (!db.objectStoreNames.contains(ARTIFACT_STORE)) {
          const store = db.createObjectStore(ARTIFACT_STORE, { keyPath: 'id' })
          store.createIndex('updatedAt', 'updatedAt')
          store.createIndex('type', 'type')
        }
        if (!db.objectStoreNames.contains(META_STORE)) {
          db.createObjectStore(META_STORE, { keyPath: 'key' })
        }
      }
      req.onsuccess = () => resolve(req.result)
      req.onerror = () => reject(req.error || new Error('Failed to open IndexedDB.'))
      req.onblocked = () => reject(new Error('IndexedDB open blocked by another tab.'))
    })
    return dbPromise
  }

  function tx(storeName, mode) {
    return openDb().then((db) => db.transaction(storeName, mode).objectStore(storeName))
  }

  function requestAsPromise(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error || new Error('IndexedDB request failed.'))
    })
  }

  /* ── Artifact registry ─────────────────────────────────────────────────── */
  const artifacts = {
    /** All artifacts sorted newest-updated first. */
    async all() {
      try {
        const store = await tx(ARTIFACT_STORE, 'readonly')
        const items = await requestAsPromise(store.getAll())
        return items
          .filter((a) => a && ARTIFACT_TYPES.includes(a.type))
          .sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
      } catch (err) {
        console.error('[KS] Failed to load artifacts:', err)
        return []
      }
    },

    async get(id) {
      if (!id) return null
      try {
        const store = await tx(ARTIFACT_STORE, 'readonly')
        return (await requestAsPromise(store.get(id))) || null
      } catch (err) {
        console.error('[KS] Failed to load artifact:', err)
        return null
      }
    },

    /** Insert or update an artifact, stamping updatedAt and notifying the UI. */
    async put(artifact) {
      if (!artifact || !artifact.id) throw new Error('Artifact requires an id.')
      if (!ARTIFACT_TYPES.includes(artifact.type)) throw new Error(`Unknown artifact type "${artifact.type}".`)
      const now = new Date().toISOString()
      const record = {
        createdAt: now,
        sourceIds: [],
        sourceCount: 0,
        content: null,
        ...artifact,
        updatedAt: now
      }
      const store = await tx(ARTIFACT_STORE, 'readwrite')
      await requestAsPromise(store.put(record))
      bus.emit('artifacts:changed', { id: record.id })
      bus.emit('artifact:updated', record)
      return record
    },

    /** Put without emitting (used for batch migration). */
    async putSilent(artifact) {
      if (!artifact || !artifact.id) throw new Error('Artifact requires an id.')
      const now = new Date().toISOString()
      const record = { createdAt: now, sourceIds: [], sourceCount: 0, content: null, ...artifact, updatedAt: now }
      const store = await tx(ARTIFACT_STORE, 'readwrite')
      await requestAsPromise(store.put(record))
      return record
    },

    /** Create a new artifact (defaults to a generating note envelope). */
    async create(partial) {
      const now = new Date().toISOString()
      const id = (partial && partial.id) || ('art-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8))
      const record = {
        id,
        type: 'note',
        title: 'Untitled Artifact',
        status: 'generating',
        error: null,
        sourceIds: [],
        sourceCount: 0,
        content: null,
        ...(partial || {}),
        id,
        createdAt: partial && partial.createdAt ? partial.createdAt : now,
        updatedAt: now
      }
      if (!ARTIFACT_TYPES.includes(record.type)) throw new Error(`Unknown artifact type "${record.type}".`)
      const store = await tx(ARTIFACT_STORE, 'readwrite')
      await requestAsPromise(store.put(record))
      bus.emit('artifacts:changed', { id: record.id })
      bus.emit('artifact:updated', record)
      return record
    },

    /** Shallow merge a patch onto an existing artifact (status/content/title). */
    async update(id, patch) {
      const existing = await artifacts.get(id)
      if (!existing) throw new Error('Artifact not found: ' + id)
      const record = { ...existing, ...(patch || {}), id: existing.id, updatedAt: new Date().toISOString() }
      const store = await tx(ARTIFACT_STORE, 'readwrite')
      await requestAsPromise(store.put(record))
      bus.emit('artifacts:changed', { id: record.id })
      bus.emit('artifact:updated', record)
      return record
    },

    async remove(id) {
      const store = await tx(ARTIFACT_STORE, 'readwrite')
      await requestAsPromise(store.delete(id))
      bus.emit('artifacts:changed', { id, removed: true })
    },

    async rename(id, title) {
      const existing = await artifacts.get(id)
      if (!existing) throw new Error('Artifact not found.')
      return artifacts.put({ ...existing, title: String(title || '').trim() || existing.title })
    },

    async duplicate(id) {
      const existing = await artifacts.get(id)
      if (!existing) throw new Error('Artifact not found.')
      const copy = {
        ...JSON.parse(JSON.stringify(existing)),
        id: 'art-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8),
        title: existing.title + ' (copy)',
        status: existing.status === 'generating' ? 'failed' : existing.status
      }
      return artifacts.put(copy)
    },

    /** Content-only update (user edits, saved notes). */
    async saveContent(id, content) {
      const existing = await artifacts.get(id)
      if (!existing) throw new Error('Artifact not found.')
      return artifacts.put({ ...existing, content })
    }
  }

  /* ── Notebook / UI preferences (IndexedDB-backed key/value) ────────────── */
  const memoryPrefs = new Map()
  const prefs = {
    async get(key, fallback = null) {
      try {
        const store = await tx(META_STORE, 'readonly')
        const row = await requestAsPromise(store.get(key))
        return row ? row.value : fallback
      } catch (err) {
        console.warn('[KS] Pref read failed, using session value:', err)
        return memoryPrefs.has(key) ? memoryPrefs.get(key) : fallback
      }
    },
    async set(key, value) {
      memoryPrefs.set(key, value)
      try {
        const store = await tx(META_STORE, 'readwrite')
        await requestAsPromise(store.put({ key, value }))
        bus.emit('prefs:changed', { key, value })
      } catch (err) {
        console.warn('[KS] Pref write failed (kept in memory):', err)
      }
    }
  }

  /* ── Legacy localStorage migration ─────────────────────────────────────── */
  // The previous studio stored unstructured {id, action, topic, content, timestamp}
  // objects in localStorage. Migrate them into the typed registry once, then
  // remove the old key. Unparsable bodies are preserved honestly as markdown
  // notes — nothing is faked or dropped.
  const LEGACY_ACTION_MAP = {
    flashcards: 'flashcard_set', flashcard_set: 'flashcard_set',
    mindmap: 'mind_map', mind_map: 'mind_map',
    reports: 'report', report: 'report',
    datatable: 'data_table', data_table: 'data_table',
    quiz: 'quiz', note: 'note', notes: 'note',
    slidedeck: 'note', infographic: 'note', grammar_logs: 'note',
    audio_overview: 'note', video_overview: 'note'
  }

  function legacyContentToTyped(type, rawContent) {
    if (rawContent && typeof rawContent === 'object') return rawContent
    if (typeof rawContent !== 'string' || !rawContent.trim()) return { markdown: rawContent || '' }
    const cleaned = rawContent.trim().replace(/```json/gi, '').replace(/```/g, '').trim()
    const jsonMatch = cleaned.match(/\{[\s\S]*\}|\[[\s\S]*\]/)
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0])
        if (parsed && typeof parsed === 'object') {
          if (type === 'mind_map' && Array.isArray(parsed.nodes)) {
            // Legacy mindmap shape {category, items:[{term, meaning}]} → flat nodes.
            if (parsed.nodes.length && parsed.nodes[0] && Array.isArray(parsed.nodes[0].items)) {
              const flat = [{ id: 'root', label: parsed.title || 'Mind Map', parentId: null }]
              parsed.nodes.forEach((branch, bi) => {
                const branchId = 'b' + bi
                flat.push({ id: branchId, label: String(branch.category || 'Branch'), parentId: 'root' })
                ;(branch.items || []).forEach((item, ii) => {
                  flat.push({ id: branchId + '-' + ii, label: `${item.term ?? ''}${item.meaning ? ' — ' + item.meaning : ''}`, parentId: branchId })
                })
              })
              return { title: parsed.title || 'Mind Map', nodes: flat }
            }
            return parsed
          }
          if (type === 'flashcard_set' && Array.isArray(parsed)) return { title: 'Flashcards', cards: parsed }
          if (type === 'quiz' && Array.isArray(parsed.questions)) return parsed
          if (type === 'data_table' && Array.isArray(parsed.columns)) return parsed
          return parsed
        }
      } catch (err) {
        console.debug('[KS] Legacy artifact was not JSON; preserving it as markdown:', err)
      }
    }
    return { markdown: rawContent }
  }

  async function migrateLegacyArtifacts() {
    const raw = localStorage.getItem('kami_artifacts')
    if (!raw) return
    let legacy = []
    try { legacy = JSON.parse(raw) } catch (err) {
      console.error('[KS] Legacy artifact store was corrupt; discarding.', err)
      localStorage.removeItem('kami_artifacts')
      return
    }
    if (!Array.isArray(legacy) || !legacy.length) { localStorage.removeItem('kami_artifacts'); return }
    let migrated = 0
    for (const item of legacy) {
      try {
        if (!item || !item.id) continue
        const type = LEGACY_ACTION_MAP[item.action] || 'note'
        await artifacts.putSilent({
          id: 'legacy-' + item.id,
          type,
          title: item.topic || 'Imported artifact',
          createdAt: item.timestamp || new Date().toISOString(),
          updatedAt: item.timestamp || new Date().toISOString(),
          sourceIds: [],
          sourceCount: 0,
          status: 'ready',
          content: legacyContentToTyped(type, item.content)
        })
        migrated++
      } catch (err) {
        console.error('[KS] Failed to migrate legacy artifact:', err)
      }
    }
    localStorage.removeItem('kami_artifacts')
    if (migrated) console.info(`[KS] Migrated ${migrated} legacy artifact(s) into IndexedDB.`)
  }

  /* ── Boot ──────────────────────────────────────────────────────────────── */
  const ready = openDb()
    .then(() => migrateLegacyArtifacts())
    .catch((err) => console.error('[KS] State core init failed:', err))

  window.KS = { ready, bus, artifacts, prefs, ARTIFACT_TYPES }
})()
