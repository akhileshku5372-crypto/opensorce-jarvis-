"""Prove which audio backend actually plays on THIS machine, with timing.
1) edge-tts -> real mp3
2) ffplay default / directsound / wasapi / dsdummy  (timed)
3) Windows MCI via winmm (the native fallback voice_engine already has)
"""
import os, sys, time, ctypes, uuid, asyncio, tempfile, subprocess
sys.path.insert(0, 'background')
import edge_tts

async def _syn():
    c = edge_tts.Communicate('Hello Sir. JARVIS audio backend test. One two three.',
                             'en-GB-RyanNeural')
    fd, path = tempfile.mkstemp(suffix='.mp3'); os.close(fd)
    await c.save(path)
    return path

path = asyncio.run(_syn())
print('mp3 bytes:', os.path.getsize(path), flush=True)

def timed_ffplay(label, env=None):
    e = dict(os.environ)
    if env: e.update(env)
    t0 = time.time()
    try:
        p = subprocess.Popen(['ffplay','-nodisp','-autoexit','-loglevel','error', path],
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                             creationflags=0x08000000, env=e)
        _, err = p.communicate(timeout=10)
        print('  ffplay %-14s rc=%s  %.2fs  %r' % (label, p.returncode, time.time()-t0, (err or b'')[:80]), flush=True)
    except subprocess.TimeoutExpired:
        p.kill()
        print('  ffplay %-14s HUNG >10s' % label, flush=True)

print('=== FFPLAY (default) ===', flush=True); timed_ffplay('default')
print('=== FFPLAY SDL_AUDIODRIVER=directsound ===', flush=True); timed_ffplay('directsound', {'SDL_AUDIODRIVER':'directsound'})
print('=== FFPLAY SDL_AUDIODRIVER=wasapi ===', flush=True); timed_ffplay('wasapi', {'SDL_AUDIODRIVER':'wasapi'})
print('=== FFPLAY SDL_AUDIODRIVER=winmm ===', flush=True); timed_ffplay('winmm', {'SDL_AUDIODRIVER':'winmm'})

print('=== WINDOWS MCI (native winmm) ===', flush=True)
alias = 'jarvis_' + uuid.uuid4().hex
mci = ctypes.windll.winmm.mciSendStringW
def send(cmd, res=None):
    err = mci(cmd, res, 128 if res is not None else 0, None)
    if err: raise RuntimeError('MCI error %s' % err)
t0 = time.time()
try:
    send('open "%s" type mpegvideo alias %s' % (path, alias))
    send('play ' + alias)
    while time.time() - t0 < 10:
        buf = ctypes.create_unicode_buffer(128)
        send('status %s mode' % alias, buf)
        if buf.value == 'stopped':
            print('  MCI PLAYED OK in %.2fs' % (time.time()-t0), flush=True)
            break
        time.sleep(0.05)
    else:
        print('  MCI HUNG >10s', flush=True)
except Exception as exc:
    print('  MCI FAILED: %r' % exc, flush=True)
finally:
    mci('close ' + alias, None, 0, None)
try: os.remove(path)
except OSError: pass
print('DONE', flush=True)
