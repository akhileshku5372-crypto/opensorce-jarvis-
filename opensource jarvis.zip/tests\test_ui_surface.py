"""Tests for background/ui_surface.py - the semantic gesture path.

The module is imported directly so these tests exercise the shipped guards.
Activation itself needs a real Windows desktop and is only smoke-tested through
`status()`; every refusal rule is pure and tested without UI Automation.
"""
import contextlib
import importlib.util
import io
import json
import sys
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "background" / "ui_surface.py"
spec = importlib.util.spec_from_file_location("jarvis_ui_surface", MODULE_PATH)
ui = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ui)


class SensitiveLabels(unittest.TestCase):
    def test_destructive_labels_are_refused(self):
        for label in ("Delete all", "Send message", "Confirm purchase", "Restart now", "Sign out", "Shut down",
                      "Clear conversation memory", "Lock PC", "Sleep", "Turn off display", "Log out"):
            self.assertTrue(ui.is_sensitive(label), label)
            self.assertNotEqual(ui.blocked_reason(label, "Button"), "")

    def test_safe_words_are_not_over_blocked(self):
        self.assertFalse(ui.is_sensitive("Unlock"))
        self.assertFalse(ui.is_sensitive("Clock settings"))

    def test_unicode_labels_are_refused(self):
        self.assertTrue(ui.is_sensitive("हटाएं"))
        self.assertTrue(ui.is_sensitive("削除"))

    def test_safe_labels_pass(self):
        for label in ("Open settings", "Next track", "Play", "Dashboard home", ""):
            self.assertFalse(ui.is_sensitive(label), label)

    def test_password_field_is_refused(self):
        self.assertEqual(ui.blocked_reason("Password", "Edit", True), "password field")
        self.assertNotEqual(ui.blocked_reason("", "Edit", True), "")


class ControlTypes(unittest.TestCase):
    def test_only_reversible_patterns_are_activatable(self):
        self.assertEqual(ui.control_action("Button"), "invoke")
        self.assertEqual(ui.control_action("MenuItem"), "invoke")
        self.assertEqual(ui.control_action("TabItem"), "select")
        self.assertEqual(ui.control_action("CheckBox"), "toggle")
        self.assertEqual(ui.control_action("Slider"), "range_value")
        self.assertEqual(ui.control_action("ComboBox"), "expand")
        self.assertEqual(ui.control_action("Edit"), "")
        self.assertEqual(ui.control_action("Document"), "")

    def test_non_interactive_control_names_its_refusal(self):
        self.assertNotEqual(ui.blocked_reason("Some label", "Text"), "")
        self.assertEqual(ui.blocked_reason("Save", "Button"), "")

    def test_bounded_name_collapses_and_caps(self):
        self.assertEqual(ui.bounded_name("  Save\n  file  "), "Save file")
        long_name = "x" * 400
        result = ui.bounded_name(long_name)
        self.assertLessEqual(len(result), ui.MAX_NAME)
        self.assertTrue(result.endswith("..."))


class Geometry(unittest.TestCase):
    def test_range_value_follows_the_pointed_position(self):
        box = (100, 0, 200, 20)
        self.assertAlmostEqual(ui.range_value(box, 0, 100, 100), 0.0)
        self.assertAlmostEqual(ui.range_value(box, 0, 100, 200), 50.0)
        self.assertAlmostEqual(ui.range_value(box, 0, 100, 300), 100.0)
        self.assertAlmostEqual(ui.range_value(box, 100, 0, 200), 50.0)

    def test_choose_control_prefers_the_smallest_activatable_target(self):
        candidates = [
            {"name": "pane", "box": (0, 0, 500, 500), "activatable": False},
            {"name": "button", "box": (10, 10, 100, 40), "activatable": True},
            {"name": "label", "box": (20, 20, 30, 15), "activatable": False},
            {"name": "outside", "box": (900, 900, 20, 20), "activatable": True},
        ]
        chosen = ui.choose_control(candidates, 30, 5 + 10)
        self.assertIsNotNone(chosen)
        self.assertEqual(chosen["name"], "button")

    def test_choose_control_refuses_a_point_with_no_activatable_target(self):
        candidates = [{"name": "label", "box": (0, 0, 50, 50), "activatable": False}]
        self.assertIsNone(ui.choose_control(candidates, 10, 10))


class Status(unittest.TestCase):
    def test_status_is_json_and_never_claims_success_off_windows(self):
        result = ui.status()
        self.assertIsInstance(result, dict)
        self.assertIs(result["ok"], True)
        self.assertIn("available", result)
        self.assertIn("reason", result)
        if sys.platform != "win32":
            self.assertFalse(result["available"])

    def test_cli_status_emits_one_json_object(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = ui.main(["--json", "--op", "status"])
        payload = json.loads(buffer.getvalue())
        self.assertEqual(code, 0)
        self.assertIn("available", payload)


class Rect:
    def __init__(self, left, top, width, height):
        self.left = left
        self.top = top
        self.right = left + width
        self.bottom = top + height


class FakeSpec:
    """A window object shaped like the pywinauto wrapper ui_surface talks to."""

    def __init__(self, title="Qoder", handle=42, box=(10, 20, 800, 600),
                 minimized=False, maximized=False, fail=None):
        self.title = title
        self.handle = handle
        self.box = box
        self.minimized = minimized
        self.maximized = maximized
        self.fail = fail
        self.calls = []

    def _act(self, name):
        self.calls.append(name)
        if self.fail == name:
            raise RuntimeError("the window refused " + name)

    def window_text(self):
        return self.title

    def is_minimized(self):
        return self.minimized

    def is_maximized(self):
        return self.maximized

    def rectangle(self):
        return Rect(*self.box)

    def set_focus(self):
        self._act("focus")

    def minimize(self):
        self._act("minimize")
        self.minimized = True

    def maximize(self):
        self._act("maximize")
        self.maximized = True

    def restore(self):
        self._act("restore")
        self.minimized = False
        self.maximized = False


class FakeDesktop:
    def __init__(self, specs=(), specs_error=None):
        self.specs = list(specs)
        self.specs_error = specs_error
        self.opened = []

    def windows(self):
        if self.specs_error:
            raise self.specs_error
        return list(self.specs)

    def window(self, handle=0):
        self.opened.append(handle)
        for spec in self.specs:
            if spec.handle == handle:
                return spec
        raise RuntimeError("no such window")


class WindowActions(unittest.TestCase):
    """The window-control contract: allowlisted, handle-based, never guessed."""

    def setUp(self):
        self.original = ui._desktop
        self.addCleanup(lambda: setattr(ui, "_desktop", self.original))

    def use(self, specs=(), specs_error=None):
        desktop = FakeDesktop(specs, specs_error)
        ui._desktop = lambda: desktop
        return desktop

    def stub_move(self, spec=None):
        """Replace the Win32 SetWindowPos call; the resolver logic stays real."""
        moves = []
        original = ui.move_window

        def fake(handle, left, top, width, height):
            moves.append((handle, left, top, width, height))
            if spec is not None:
                spec.box = (left, top, width, height)
            return None

        ui.move_window = fake
        self.addCleanup(lambda: setattr(ui, "move_window", original))
        return moves

    def test_the_action_allowlist_has_no_destructive_verb(self):
        self.assertEqual(ui.WINDOW_ACTIONS, {"focus", "minimize", "maximize", "restore", "move"})
        for name in ui.WINDOW_ACTIONS:
            self.assertNotRegex(name, r"close|kill|terminate|set_text|shutdown|power")

    def test_an_unknown_action_is_refused_before_the_desktop_is_touched(self):
        desktop = self.use([FakeSpec()])
        for action in ("close", "terminate", "set_text", "", "minimise", "MINIMIZE?"):
            result = ui.window(action, 42)
            self.assertIs(result["ok"], False, action)
            self.assertEqual(desktop.opened, [], action)

    def test_action_casing_and_padding_are_normalised(self):
        spec = FakeSpec(handle=42)
        self.use([spec])
        self.assertIs(ui.window("  Minimize ", 42)["ok"], True)
        self.assertEqual(spec.calls, ["minimize"])

    def test_the_handle_must_be_a_positive_number(self):
        desktop = self.use([FakeSpec()])
        self.assertIn("not a number", ui.window("minimize", "abc")["error"])
        self.assertIn("positive window handle", ui.window("minimize", 0)["error"])
        self.assertIn("positive window handle", ui.window("minimize", -5)["error"])
        self.assertEqual(desktop.opened, [], "an invalid handle must not open a window")

    def test_an_inaccessible_window_is_reported_not_faked(self):
        self.use([FakeSpec(handle=7)])
        result = ui.window("minimize", 999)
        self.assertIs(result["ok"], False)
        self.assertIn("not accessible", result["error"])

    def test_minimize_maximize_focus_restore_touch_the_real_spec(self):
        spec = FakeSpec(handle=42, title="Qoder")
        self.use([spec])
        result = ui.window("minimize", 42)
        self.assertEqual(spec.calls, ["minimize"])
        self.assertIs(result["ok"], True)
        self.assertIs(result["window"]["minimized"], True, "the answer must carry the state it read back")
        self.assertEqual(result["window"]["title"], "Qoder")
        self.assertEqual(result["window"]["handle"], 42)

        result = ui.window("focus", 42)
        self.assertIn("focus", spec.calls)
        self.assertIs(result["ok"], True)

        self.use([spec])
        result = ui.window("restore", 42)
        self.assertEqual(result["window"]["minimized"], False)
        self.assertEqual(result["window"]["maximized"], False)

    def test_move_requires_a_full_usable_rectangle(self):
        spec = FakeSpec(handle=42)
        self.use([spec])
        moves = self.stub_move(spec)
        missing = ui.window("move", 42)
        self.assertIs(missing["ok"], False)
        self.assertIn("needs x, y, width and height", missing["error"])
        self.assertEqual(moves, [])

        too_small = ui.window("move", 42, rect=(0, 0, 100, 80))
        self.assertIs(too_small["ok"], False)
        self.assertIn("too small", too_small["error"])
        self.assertEqual(moves, [], "a refused rectangle must not move the window")

        moved = ui.window("move", 42, x=50, y=60, width=900, height=700)
        self.assertEqual(moves, [(42, 50, 60, 900, 700)], "the resolved rect must reach the Win32 call")
        self.assertEqual(moved["window"]["box"], [50, 60, 900, 700], "the readback must be the real rectangle")

    def test_a_maximised_window_is_restored_before_it_is_moved(self):
        spec = FakeSpec(handle=42, maximized=True)
        self.use([spec])
        moves = self.stub_move(spec)
        result = ui.window("move", 42, rect=(10, 20, 900, 700))
        self.assertIs(result["ok"], True, result)
        self.assertEqual(spec.calls, ["restore"], "a maximised window cannot be positioned before restoring it")
        self.assertEqual(moves, [(42, 10, 20, 900, 700)])

    def test_a_refused_move_is_reported_and_never_claims_success(self):
        spec = FakeSpec(handle=42)
        self.use([spec])
        original = ui.move_window
        ui.move_window = lambda handle, left, top, width, height: "the window manager refused the move"
        self.addCleanup(lambda: setattr(ui, "move_window", original))
        result = ui.window("move", 42, rect=(10, 20, 900, 700))
        self.assertIs(result["ok"], False)
        self.assertIn("refused the move", result["error"])
        self.assertEqual(result["window"]["title"], "Qoder")

    def test_move_window_really_talks_to_the_windows_api(self):
        if sys.platform != "win32":
            self.skipTest("Windows only")
        # Handle 0 is not a window: the real SetWindowPos must say so instead of
        # pretending a move happened.
        self.assertIn("refused", ui.move_window(0, 0, 0, 400, 300))

    def test_a_fractional_move_is_resolved_in_the_uia_pixel_space(self):
        # 0..1 of the desktop crosses the process boundary instead of pixels:
        # the pointer path is virtualised (1536x864 here) while UIA rectangles
        # are physical (1920x1080), so only this process can do the conversion.
        original = ui._screen_rect
        ui._screen_rect = lambda: (0, 0, 1920, 1080)
        self.addCleanup(lambda: setattr(ui, "_screen_rect", original))
        spec = FakeSpec(handle=42)
        self.use([spec])
        moves = self.stub_move(spec)
        result = ui.window("move", 42, x=0.1, y=0.1, width=0.5, height=0.5, fraction=True)
        self.assertIs(result["ok"], True, result)
        self.assertEqual(moves, [(42, 192, 108, 960, 540)])
        self.assertEqual(result["window"]["box"], [192, 108, 960, 540], "the readback must be the resolved rectangle")

    def test_out_of_range_fractions_are_refused_before_the_window_moves(self):
        original = ui._screen_rect
        ui._screen_rect = lambda: (0, 0, 1920, 1080)
        self.addCleanup(lambda: setattr(ui, "_screen_rect", original))
        spec = FakeSpec(handle=42)
        self.use([spec])
        moves = self.stub_move(spec)
        for fractions in ((1.4, 0.0, 0.5, 0.5), (0.0, -0.1, 0.5, 0.5), (0.0, 0.0, 0.0, 0.5), (0.0, 0.0, 0.5, 0.01)):
            result = ui.window("move", 42, x=fractions[0], y=fractions[1], width=fractions[2], height=fractions[3], fraction=True)
            self.assertIs(result["ok"], False, fractions)
        self.assertEqual(moves, [], "a refused fraction must not move the window")

    def test_fractional_rect_stays_inside_the_screen(self):
        original = ui._screen_rect
        ui._screen_rect = lambda: (0, 0, 1920, 1080)
        self.addCleanup(lambda: setattr(ui, "_screen_rect", original))
        resolved, reason = ui.fractional_rect((0.9, 0.9, 0.5, 0.5))
        self.assertIsNone(reason)
        left, top, width, height = resolved
        self.assertEqual((width, height), (960, 540))
        self.assertEqual((left, top), (960, 540), "the rect must be clamped so the window stays reachable")
        self.assertEqual(ui.fractional_rect((0.1, 0.1, 0.5, 0.5))[0], (192, 108, 960, 540))

    def test_a_missing_screen_rectangle_is_reported_not_guessed(self):
        original = ui._screen_rect
        ui._screen_rect = lambda: None
        self.addCleanup(lambda: setattr(ui, "_screen_rect", original))
        spec = FakeSpec(handle=42)
        self.use([spec])
        result = ui.window("move", 42, x=0.1, y=0.1, width=0.5, height=0.5, fraction=True)
        self.assertIs(result["ok"], False)
        self.assertIn("screen rectangle is unavailable", result["error"])
        self.assertEqual(spec.calls, [])

    def test_windows_reports_the_pixel_space_its_rectangles_use(self):
        original = ui._screen_rect
        ui._screen_rect = lambda: (0, 0, 1920, 1080)
        self.addCleanup(lambda: setattr(ui, "_screen_rect", original))
        self.use([FakeSpec(handle=1, title="Qoder")])
        result = ui.windows()
        self.assertEqual(result["screen"], [0, 0, 1920, 1080],
                         "callers must be able to tell which pixel space the boxes are in")

    def test_a_refused_action_names_the_failure_and_the_window(self):
        spec = FakeSpec(handle=42, title="Qoder", fail="minimize")
        self.use([spec])
        result = ui.window("minimize", 42)
        self.assertIs(result["ok"], False)
        self.assertIn("minimize failed (RuntimeError)", result["error"])
        self.assertEqual(result["window"]["title"], "Qoder")

    def test_windows_lists_only_titled_windows_and_caps_the_list(self):
        specs = [FakeSpec(handle=index + 1, title="Window %d" % (index + 1)) for index in range(ui.MAX_WINDOWS + 5)]
        specs.append(FakeSpec(handle=99, title=""))
        specs.append(FakeSpec(handle=98, title="   \n  "))
        self.use(specs)
        result = ui.windows()
        self.assertIs(result["ok"], True)
        self.assertEqual(result["count"], ui.MAX_WINDOWS)
        self.assertEqual(len(result["windows"]), ui.MAX_WINDOWS)
        for row in result["windows"]:
            self.assertTrue(row["title"].strip(), row)
            self.assertGreater(row["handle"], 0)

    def test_an_enumeration_failure_is_a_reason_not_an_empty_list(self):
        self.use(specs_error=RuntimeError("access denied"))
        result = ui.windows()
        self.assertIs(result["ok"], False)
        self.assertIn("could not enumerate windows", result["error"])
        self.assertNotIn("windows", result)

    def test_the_cli_refuses_an_unknown_window_action(self):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = ui.main(["--json", "--op", "window", "--action", "close", "--handle", "42"])
        payload = json.loads(buffer.getvalue())
        self.assertEqual(code, 1)
        self.assertIs(payload["ok"], False)

    def test_non_ascii_window_titles_survive_a_cp1252_stdout(self):
        # The bridge reads JSON from a pipe, and Windows pipes default to the
        # ANSI code page. A window title outside cp1252 used to make json.dumps
        # raise UnicodeEncodeError, so the bridge got a traceback instead of a
        # reason and every window action failed.
        self.use([FakeSpec(handle=1, title="Проводник — Документы")])
        stream = io.TextIOWrapper(io.BytesIO(), encoding="cp1252", errors="strict")
        original = sys.stdout
        sys.stdout = stream
        try:
            code = ui.main(["--json", "--op", "windows"])
            stream.flush()
            raw = stream.buffer.getvalue()
        finally:
            sys.stdout = original
        self.assertEqual(code, 0)
        payload = json.loads(raw.decode("utf-8"))
        self.assertEqual(payload["windows"][0]["title"], "Проводник — Документы")


if __name__ == "__main__":
    unittest.main()
