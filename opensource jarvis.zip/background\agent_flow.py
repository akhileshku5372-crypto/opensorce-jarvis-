"""Agent + Sub-Agent Flow Builder runtime (Co-work -> Agents). ADDITIVE.

This module owns three things and nothing else:

  1. SCHEMA + STORE  - what an agent/flow *is*, and where it is saved.
  2. VALIDATION      - whether a flow can actually run right now.
  3. EXECUTION       - walking the graph by calling the EXISTING systems.

It is deliberately NOT a second agent framework. Every capability it exposes
comes from a module that already exists, injected by the caller
(``background/voice_engine.py``) so there is exactly one of each:

    tools   -> cortex.ToolRegistry  (the same one the planner sees)
    gate    -> the cortex confirm callback -> the real permission engine
    skills  -> background/skill_loader.py
    mcp     -> background/mcp_client.py (only allow_call + online servers)
    models  -> the voice engine's own provider list
    planner -> the voice engine's real LLM caller

REGISTRY INVARIANT: ``catalog()`` only ever returns names that resolve inside
those injected systems. A node the user cannot bind is a node that will refuse
to run, and ``validate()`` says so before anything executes.

Safety (AGENTS.md): no shell, no subprocess, no eval, no arbitrary path. A
planner reply is parsed as JSON data and validated by cortex - never executed
as code. Every tool call goes through ``ToolRegistry.execute`` so the confirm
gate and the permission engine remain authoritative.

Storage: ``artifacts/agents/agents.json`` - one JSON document, written
atomically. A corrupt file is reported, never silently overwritten.
"""
from __future__ import annotations

import concurrent.futures
import json
import re
import threading
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STORE_DIR = ROOT / "artifacts" / "agents"
STORE = STORE_DIR / "agents.json"
RUN_STORE = STORE_DIR / "last_run.json"

MAX_AGENTS = 60
MAX_NODES = 60
MAX_EDGES = 120
MAX_NAME = 64
MAX_TEXT = 4000

# ── node types ───────────────────────────────────────────────────────────────
# `agent` is the entry point, `subagent` is a nested agent with its own prompt,
# tool allowlist and budget. Everything else is a real call into a real module.
NODE_TYPES = ("input", "agent", "subagent", "tool", "mcp", "skill", "model",
              "condition", "approval", "output",
              # ── orchestration primitives (see _run_* handlers) ──
              "router", "parallel", "merge", "loop", "validator", "evaluator",
              "memory", "transform", "http", "workflow", "error", "checkpoint")

# Which upstream node types each node may legally receive an edge from.
# This is the "valid connections" rule from the spec, enforced server-side
# rather than trusted to the browser.
#   * `input` is the universal entry point - a flow may run straight from a
#     tool to an output with no orchestrator at all.
#   * `approval` is a human gate and may guard ANY node that does work, so a
#     user can put a confirmation in front of a tool, an MCP call or an agent.
#   * `merge` is the only node that may legally be fed by `parallel` (and by
#     anything else, so a fan-in still works without the parallel node).
#   * `error` may be fed by ANY node: it is the graph's failure sink, which is
#     what makes a fallback edge drawable.
_ANY_UPSTREAM = NODE_TYPES
ALLOWED_INBOUND = {
    "input": (),
    "agent": ("input", "approval", "condition", "router", "agent", "subagent", "merge"),
    "subagent": ("input", "approval", "agent", "subagent", "condition", "router",
                 "tool", "mcp", "skill", "model", "merge", "parallel"),
    "tool": ("input", "approval", "agent", "subagent", "condition", "router",
             "tool", "mcp", "validator", "parallel"),
    "mcp": ("input", "approval", "agent", "subagent", "condition", "router", "tool",
            "parallel"),
    "skill": ("input", "approval", "agent", "subagent", "condition"),
    "model": ("input", "approval", "agent", "subagent", "condition", "validator",
              "merge", "parallel"),
    "condition": ("input", "approval", "agent", "subagent", "tool", "mcp", "condition"),
    "approval": ("input", "agent", "subagent", "tool", "mcp", "condition"),
    "output": ("input", "agent", "subagent", "tool", "mcp", "skill", "condition",
               "approval", "merge", "router", "loop", "validator", "evaluator",
               "transform", "http", "workflow", "memory", "checkpoint", "error"),
    # orchestration
    "router": ("input", "approval", "agent", "subagent", "tool", "mcp",
               "condition", "model", "skill", "merge"),
    "parallel": ("input", "approval", "agent", "subagent", "tool", "mcp",
                 "condition", "router", "merge", "model"),
    "merge": _ANY_UPSTREAM,
    "loop": ("input", "approval", "agent", "subagent", "tool", "mcp",
             "condition", "model", "merge", "transform"),
    "validator": ("input", "approval", "agent", "subagent", "tool", "mcp",
                  "model", "merge", "transform", "condition"),
    "evaluator": ("input", "approval", "agent", "subagent", "tool", "mcp",
                  "model", "merge", "transform", "output"),
    "memory": _ANY_UPSTREAM,
    "transform": _ANY_UPSTREAM,
    "http": ("input", "approval", "agent", "subagent", "tool", "mcp",
             "condition", "model", "merge", "transform"),
    "workflow": ("input", "approval", "agent", "subagent", "tool", "mcp",
                 "condition", "model", "merge", "transform"),
    "error": _ANY_UPSTREAM,
    "checkpoint": _ANY_UPSTREAM,
}

SUBAGENT_DEFAULTS = {
    "name": "Sub-agent",
    "description": "",
    "system_prompt": "",
    "model": "",
    "tools": [],
    "skills": [],
    "permissions": "inherit",  # inherit | ask | deny
    "memory": "none",          # none | session
    "input_schema": "",
    "output_schema": "",
    "max_steps": 3,
    "retries": 1,
    "on_failure": "continue",
}

_lock = threading.RLock()
_run = None
_runner = None
_cancel = threading.Event()
_deps: dict = {}


# ── dependency injection ─────────────────────────────────────────────────────
DEPS = ("registry", "confirm", "planner", "complete", "skills", "mcp", "models",
        "cortex", "permissions", "memory")


def configure(**kwargs) -> None:
    """Bind the real subsystems. Called by the voice engine on every route hit.

    Anything not injected is reported as unavailable by ``catalog()`` rather
    than replaced with a stand-in, so the builder can never advertise a
    capability the runtime does not have.
    """
    with _lock:
        for key in DEPS:
            if key in kwargs:
                _deps[key] = kwargs[key]


def deps_ready() -> dict:
    """Which injected subsystems are live right now (honest, never assumed)."""
    with _lock:
        return {key: _deps.get(key) is not None for key in DEPS}


def _registry():
    """The ONE cortex ToolRegistry, or None.

    ``registry`` may be injected as the object itself or as a provider callable
    (``voice_engine._cortex_registry``). A provider is preferred because the
    default registry is rebuilt on demand; caching a stale one would advertise
    tools a plugin toggle has already removed.
    """
    value = _deps.get("registry")
    if value is None:
        return None
    if callable(value) and not hasattr(value, "execute"):
        try:
            value = value()
        except Exception:
            return None
    return value if hasattr(value, "execute") else None


def _call_confirm(name, args):
    gate = _deps.get("confirm")
    if not callable(gate):
        return False
    try:
        return bool(gate(str(name), dict(args or {})))
    except Exception:
        return False
def _empty_store() -> dict:
    return {"agents": [], "updated_at": 0.0}


def _read_store() -> dict:
    try:
        data = json.loads(STORE.read_text(encoding="utf-8", errors="ignore") or "{}")
    except FileNotFoundError:
        return _empty_store()
    except Exception:
        # A corrupt store is reported, never silently replaced.
        return {"agents": [], "updated_at": 0.0, "error": "store unreadable"}
    if not isinstance(data, dict) or not isinstance(data.get("agents"), list):
        return {"agents": [], "updated_at": 0.0, "error": "store shape invalid"}
    return data


def _write_store(data: dict) -> bool:
    try:
        STORE_DIR.mkdir(parents=True, exist_ok=True)
        temp = STORE.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                        encoding="utf-8")
        temp.replace(STORE)
        return True
    except Exception:
        return False


def _normalize_viewport(raw) -> dict:
    src = raw if isinstance(raw, dict) else {}
    try:
        zoom = float(src.get("zoom") or 1.0)
    except (TypeError, ValueError):
        zoom = 1.0
    return {"x": _int(src.get("x"), 0, -20000, 20000),
            "y": _int(src.get("y"), 0, -20000, 20000),
            "zoom": round(min(2.5, max(0.25, zoom)), 3)}


def _string_list(value, limit=24) -> list:
    if not isinstance(value, (list, tuple)):
        return []
    out = []
    for item in value[:limit]:
        text = _clean(item, 80)
        if text and text not in out:
            out.append(text)
    return out


def _pick(value, allowed, default):
    return value if value in allowed else default


def _now() -> float:
    return time.time()


# ── small helpers ────────────────────────────────────────────────────────────
def _clean(value, limit=MAX_TEXT) -> str:
    return str(value if value is not None else "").strip()[:limit]


def _slug(prefix: str) -> str:
    return "%s_%s" % (prefix, uuid.uuid4().hex[:10])


def _int(value, default: int, low: int, high: int) -> int:
    try:
        num = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(num, high))


# ── flow normalization ────────────────────────────────────────────────────────
# The browser is never trusted with shape. Every node/edge that arrives is
# re-built here against the limits above, so a hand-crafted POST cannot smuggle
# an arbitrary handler, an unbounded string, or a 10k-node graph into the store.
NODE_W_MIN, NODE_W_MAX = 160, 460
NODE_H_MIN, NODE_H_MAX = 62, 340

DEFAULT_NODE_SIZE = {"input": (220, 96), "agent": (250, 132), "subagent": (250, 132),
                     "tool": (226, 100), "mcp": (226, 100), "skill": (226, 96),
                     "model": (226, 96), "condition": (226, 116), "approval": (226, 108),
                     "output": (226, 100),
                     "router": (236, 128), "parallel": (236, 112), "merge": (226, 104),
                     "loop": (236, 124), "validator": (236, 112), "evaluator": (240, 128),
                     "memory": (226, 100), "transform": (226, 100), "http": (240, 124),
                     "workflow": (236, 112), "error": (226, 104), "checkpoint": (226, 96)}

# Which node types carry a free-form argument/template payload.
ARG_NODE_TYPES = ("tool", "mcp", "subagent", "skill", "model")

# Node types whose real work is executed by the WALKER rather than by a
# single handler: `parallel` drives concurrent branches and `loop` re-runs a
# body. They are excluded from the plain per-node handler map.
ORCHESTRATOR_TYPES = ("parallel", "loop")


def _default_node(node_type: str, title: str = "") -> dict:
    width, height = DEFAULT_NODE_SIZE.get(node_type, (226, 100))
    node = {"id": _slug("n"), "type": node_type, "title": title or node_type.title(),
            "x": 60, "y": 60, "w": width, "h": height, "config": {}}
    if node_type in ARG_NODE_TYPES:
        node["config"]["args_text"] = ""
    if node_type == "condition":
        node["config"] = {"expression": "", "true_branch": "true",
                          "false_branch": "false"}
    if node_type == "approval":
        node["config"] = {"prompt": "Approve this action?", "remember": False}
    if node_type == "input":
        node["config"] = {"label": "Task input", "placeholder": ""}
    if node_type == "output":
        node["config"] = {"label": "Final result", "template": ""}
    if node_type == "router":
        node["config"] = {"key": "last", "rules_text": "", "default_branch": "default"}
    if node_type == "parallel":
        node["config"] = {"mode": "all", "settle_ms": 250}
    if node_type == "merge":
        node["config"] = {"strategy": "object", "keys_text": "", "label": "Merged"}
    if node_type == "loop":
        node["config"] = {"body_text": "", "max_iterations": 2,
                          "until": "", "item_key": "item"}
    if node_type == "validator":
        node["config"] = {"expression": "", "on_fail": "fail", "message": "Validation failed"}
    if node_type == "evaluator":
        node["config"] = {"criteria": "", "threshold": 7, "subject_key": "last",
                          "score_key": "score"}
    if node_type == "memory":
        node["config"] = {"op": "set", "key": "", "value": "", "scope": "workflow"}
    if node_type == "transform":
        node["config"] = {"mode": "template", "template": "", "regex": "", "replacement": ""}
    if node_type == "http":
        node["config"] = {"url": "", "method": "GET", "headers_text": "{}",
                          "body_text": "", "timeout": 15, "allow_hosts_text": ""}
    if node_type == "workflow":
        node["config"] = {"agent_id": "", "input_key": "input", "depth": 1}
    if node_type == "error":
        node["config"] = {"message": "Step failed", "label": "Fallback"}
    if node_type == "checkpoint":
        node["config"] = {"label": "Checkpoint", "persist": True}
    return node


def _normalize_config(node_type: str, raw) -> dict:
    src = raw if isinstance(raw, dict) else {}
    out = {}
    # Typed dataflow: any node may publish its result under a named context key
    # so downstream nodes reference {{research_report}} instead of the ambiguous
    # {{last}}. Empty means "use {{last}}" (fully backward compatible).
    out["output_key"] = re.sub(r"[^a-z0-9_]", "",
                               str(src.get("output_key") or "").lower())[:40]
    if node_type == "router":
        out["key"] = _clean(src.get("key"), 40) or "last"
        out["rules_text"] = _clean(src.get("rules_text"), 1200)
        out["default_branch"] = _clean(src.get("default_branch"), 40) or "default"
        return out
    if node_type == "parallel":
        out["mode"] = _pick(src.get("mode"), ("all", "race"), "all")
        out["settle_ms"] = _int(src.get("settle_ms"), 250, 0, 5000)
        return out
    if node_type == "merge":
        out["strategy"] = _pick(src.get("strategy"), ("object", "concat", "last"), "object")
        out["keys_text"] = _clean(src.get("keys_text"), 400)
        out["label"] = _clean(src.get("label"), MAX_NAME) or "Merged"
        return out
    if node_type == "loop":
        out["body_text"] = _clean(src.get("body_text"), 400)
        out["max_iterations"] = _int(src.get("max_iterations"), 2, 1, 10)
        out["until"] = _clean(src.get("until"), 200)
        out["item_key"] = _clean(src.get("item_key"), 40) or "item"
        return out
    if node_type == "validator":
        out["expression"] = _clean(src.get("expression"), 400)
        out["on_fail"] = _pick(src.get("on_fail"), ("fail", "route"), "fail")
        out["message"] = _clean(src.get("message"), 200) or "Validation failed"
        return out
    if node_type == "evaluator":
        out["criteria"] = _clean(src.get("criteria"), 1000)
        out["threshold"] = _int(src.get("threshold"), 7, 0, 10)
        out["subject_key"] = _clean(src.get("subject_key"), 40) or "last"
        out["score_key"] = _clean(src.get("score_key"), 40) or "score"
        return out
    if node_type == "memory":
        out["op"] = _pick(src.get("op"), ("set", "get", "append", "delete"), "set")
        out["key"] = re.sub(r"[^a-z0-9_.\-]", "",
                            str(src.get("key") or "").lower())[:60]
        out["value"] = _clean(src.get("value"), 2000)
        out["scope"] = _pick(src.get("scope"), ("workflow", "session"), "workflow")
        return out
    if node_type == "transform":
        out["mode"] = _pick(src.get("mode"),
                            ("template", "json", "regex", "upper", "lower"), "template")
        out["template"] = _clean(src.get("template"), MAX_TEXT)
        out["regex"] = _clean(src.get("regex"), 200)
        out["replacement"] = _clean(src.get("replacement"), 200)
        return out
    if node_type == "http":
        out["url"] = _clean(src.get("url"), 500)
        out["method"] = _pick(str(src.get("method") or "GET").upper(),
                             ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"), "GET")
        out["headers_text"] = _clean(src.get("headers_text"), 600)
        out["body_text"] = _clean(src.get("body_text"), 2000)
        out["timeout"] = _int(src.get("timeout"), 15, 1, 60)
        out["allow_hosts_text"] = _clean(src.get("allow_hosts_text"), 300)
        return out
    if node_type == "workflow":
        out["agent_id"] = _clean(src.get("agent_id"), 64)
        out["input_key"] = _clean(src.get("input_key"), 40) or "input"
        out["depth"] = _int(src.get("depth"), 1, 1, 3)
        return out
    if node_type == "error":
        out["message"] = _clean(src.get("message"), 300) or "Step failed"
        out["label"] = _clean(src.get("label"), MAX_NAME) or "Fallback"
        return out
    if node_type == "checkpoint":
        out["label"] = _clean(src.get("label"), MAX_NAME) or "Checkpoint"
        out["persist"] = src.get("persist", True) is not False
        return out
    if node_type == "subagent":
        out["name"] = _clean(src.get("name"), MAX_NAME) or SUBAGENT_DEFAULTS["name"]
        out["description"] = _clean(src.get("description"), 600)
        out["system_prompt"] = _clean(src.get("system_prompt"), MAX_TEXT)
        out["model"] = _clean(src.get("model"), 80)
        out["tools"] = _string_list(src.get("tools"))
        out["skills"] = _string_list(src.get("skills"))
        out["permissions"] = _pick(src.get("permissions"), ("inherit", "ask", "deny"),
                                   SUBAGENT_DEFAULTS["permissions"])
        out["memory"] = _pick(src.get("memory"), ("none", "session"),
                              SUBAGENT_DEFAULTS["memory"])
        out["input_schema"] = _clean(src.get("input_schema"), 800)
        out["output_schema"] = _clean(src.get("output_schema"), 800)
        out["max_steps"] = _int(src.get("max_steps"), SUBAGENT_DEFAULTS["max_steps"], 1, 8)
        out["retries"] = _int(src.get("retries"), SUBAGENT_DEFAULTS["retries"], 0, 3)
        out["on_failure"] = _pick(src.get("on_failure"), ("continue", "stop", "fallback"),
                                  SUBAGENT_DEFAULTS["on_failure"])
        out["args_text"] = _clean(src.get("args_text"), 1200)
        return out
    if node_type == "tool":
        out["tool"] = _clean(src.get("tool"), 80)
        out["args_text"] = _clean(src.get("args_text"), 2000)
        out["retries"] = _int(src.get("retries"), 0, 0, 3)
        out["continue_on_error"] = bool(src.get("continue_on_error"))
        return out
    if node_type == "mcp":
        out["server"] = _clean(src.get("server"), 80)
        out["tool"] = _clean(src.get("tool"), 80)
        out["args_text"] = _clean(src.get("args_text"), 2000)
        out["retries"] = _int(src.get("retries"), 0, 0, 3)
        out["continue_on_error"] = bool(src.get("continue_on_error"))
        return out
    if node_type == "skill":
        out["skill"] = _clean(src.get("skill"), 80)
        out["args_text"] = _clean(src.get("args_text"), 1200)
        return out
    if node_type == "model":
        out["model"] = _clean(src.get("model"), 80)
        out["prompt"] = _clean(src.get("prompt"), MAX_TEXT)
        return out
    if node_type == "agent":
        out["system_prompt"] = _clean(src.get("system_prompt"), MAX_TEXT)
        out["goal"] = _clean(src.get("goal"), 1000)
        out["max_steps"] = _int(src.get("max_steps"), 4, 1, 8)
        out["retries"] = _int(src.get("retries"), 1, 0, 3)
        return out
    if node_type == "condition":
        out["expression"] = _clean(src.get("expression"), 400)
        out["true_branch"] = _clean(src.get("true_branch"), 40) or "true"
        out["false_branch"] = _clean(src.get("false_branch"), 40) or "false"
        return out
    if node_type == "approval":
        out["prompt"] = _clean(src.get("prompt"), 300) or "Approve this action?"
        out["remember"] = bool(src.get("remember"))
        return out
    if node_type == "input":
        out["label"] = _clean(src.get("label"), MAX_NAME) or "Task input"
        out["placeholder"] = _clean(src.get("placeholder"), 200)
        return out
    if node_type == "output":
        out["label"] = _clean(src.get("label"), MAX_NAME) or "Final result"
        out["template"] = _clean(src.get("template"), MAX_TEXT)
        return out
    return out


def _normalize_node(raw) -> dict:
    src = raw if isinstance(raw, dict) else {}
    node_type = str(src.get("type") or "").strip().lower()
    if node_type not in NODE_TYPES:
        node_type = "tool"
    node = _default_node(node_type)
    node["id"] = _clean(src.get("id"), 64) or node["id"]
    node["title"] = _clean(src.get("title"), MAX_NAME) or node["title"]
    node["x"] = _int(src.get("x"), node["x"], -20000, 20000)
    node["y"] = _int(src.get("y"), node["y"], -20000, 20000)
    node["w"] = _int(src.get("w"), node["w"], NODE_W_MIN, NODE_W_MAX)
    node["h"] = _int(src.get("h"), node["h"], NODE_H_MIN, NODE_H_MAX)
    node["config"] = _normalize_config(node_type, src.get("config"))
    return node

def _normalize_edge(raw, node_ids) -> dict:
    src = raw if isinstance(raw, dict) else {}
    source = _clean(src.get("from"), 64)
    target = _clean(src.get("to"), 64)
    if source not in node_ids or target not in node_ids or source == target:
        return {}
    # `map` renames/aliases the upstream value as it crosses this edge, so a
    # connection transfers real typed data instead of relying on the ambient
    # {{last}}. Format: "source_key:target_key" (target_key defaults to the
    # source key). Pure data - never evaluated.
    mapping = _clean(src.get("map"), 120)
    if mapping and ":" not in mapping:
        mapping = ""
    return {"id": _clean(src.get("id"), 64) or _slug("e"), "from": source,
            "to": target, "label": _clean(src.get("label"), 40),
            "branch": _clean(src.get("branch"), 40), "map": mapping}


def _adjacency(edges) -> dict:
    out = {}
    for edge in edges:
        out.setdefault(edge["from"], []).append(edge["to"])
    return out


def _strip_cycles(nodes, edges) -> list:
    """Drop back-edges so the saved graph is a DAG the executor can walk.

    n8n-style graphs are user-drawn, so a cycle is an easy accidental save. A
    flow that cannot terminate would hang the runner thread, so cycles are
    removed at save time rather than discovered mid-run.
    """
    adjacency = _adjacency(edges)
    kept, dropped = [], []
    for edge in edges:
        stack, seen, cyclic = [edge["to"]], set(), False
        while stack:
            current = stack.pop()
            if current == edge["from"]:
                cyclic = True
                break
            if current in seen:
                continue
            seen.add(current)
            stack.extend(adjacency.get(current, ()))
        if cyclic:
            dropped.append(edge)
        else:
            kept.append(edge)
            adjacency.setdefault(edge["from"], []).append(edge["to"])
    return kept


def _normalize_flow(raw, agent_name="") -> dict:
    src = raw if isinstance(raw, dict) else {}
    nodes, seen = [], set()
    for item in (src.get("nodes") or [])[:MAX_NODES]:
        node = _normalize_node(item)
        if node["id"] in seen:
            node["id"] = _slug("n")
        seen.add(node["id"])
        nodes.append(node)
    node_ids = {n["id"] for n in nodes}
    edges, used = [], set()
    for item in (src.get("edges") or [])[:MAX_EDGES]:
        edge = _normalize_edge(item, node_ids)
        if not edge or edge["id"] in used:
            continue
        used.add(edge["id"])
        edges.append(edge)
    meta = src.get("meta") if isinstance(src.get("meta"), dict) else {}
    return {"nodes": nodes, "edges": _strip_cycles(nodes, edges),
            "viewport": _normalize_viewport(src.get("viewport")),
            "meta": {"notes": _clean(meta.get("notes"), 600)}}


def _node_index(nodes) -> dict:
    return {n["id"]: n for n in nodes}


def _entry_ids(flow) -> list:
    """Nodes nothing feeds: the run starts here."""
    nodes = flow.get("nodes") or []
    targeted = {e["to"] for e in (flow.get("edges") or [])}
    return [n["id"] for n in nodes if n["id"] not in targeted]


def default_flow(agent_name="") -> dict:
    """A minimal, RUNNABLE skeleton: input -> agent -> output."""
    src = _default_node("input", "User Input")
    src["x"], src["y"] = 60, 200
    agent = _default_node("agent", agent_name or "Main Agent")
    agent["x"], agent["y"] = 340, 190
    out = _default_node("output", "Final Output")
    out["x"], out["y"] = 650, 200
    return {"nodes": [src, agent, out],
            "edges": [{"id": _slug("e"), "from": src["id"], "to": agent["id"],
                       "label": "", "branch": "", "map": ""},
                      {"id": _slug("e"), "from": agent["id"], "to": out["id"],
                       "label": "", "branch": "", "map": ""}],
            "viewport": {"x": 0, "y": 0, "zoom": 1.0},
            "meta": {"notes": ""}}


def _normalize_agent(raw) -> dict:
    src = raw if isinstance(raw, dict) else {}
    name = _clean(src.get("name"), MAX_NAME) or "Untitled Agent"
    flow = _normalize_flow(src.get("flow"), name)
    if not flow["nodes"]:
        flow = default_flow(name)
    return {"id": _clean(src.get("id"), 64) or _slug("ag"),
            "name": name,
            "description": _clean(src.get("description"), 600),
            "objective": _clean(src.get("objective"), 600),
            "category": _clean(src.get("category"), 40) or "custom",
            "enabled": src.get("enabled", True) is not False,
            "model": _clean(src.get("model"), 80),
            "flow": flow,
            "plan": src.get("plan") if isinstance(src.get("plan"), dict) else {},
            "missing_capabilities": [
                m for m in (src.get("missing_capabilities") or [])
                if isinstance(m, dict)][:12],
            "created_at": float(src.get("created_at") or 0.0),
            "updated_at": float(src.get("updated_at") or 0.0)}

# ── CRUD over the persisted store ─────────────────────────────────────────────
def list_agents(query="", include_disabled=True) -> list:
    """Saved agents, newest first."""
    data = _read_store()
    rows = [a for a in (data.get("agents") or []) if isinstance(a, dict)]
    text = str(query or "").strip().lower()
    if text:
        rows = [a for a in rows
                if text in str(a.get("name") or "").lower()
                or text in str(a.get("description") or "").lower()
                or text in str(a.get("category") or "").lower()]
    if not include_disabled:
        rows = [a for a in rows if a.get("enabled", True)]
    rows.sort(key=lambda a: float(a.get("updated_at") or 0.0), reverse=True)
    return rows


def get_agent(agent_id) -> dict:
    wanted = str(agent_id or "").strip()
    for agent in list_agents():
        if agent.get("id") == wanted:
            return agent
    return {}


def _save_agents(agents) -> bool:
    with _lock:
        data = _read_store()
        data["agents"] = list(agents)
        data["updated_at"] = _now()
        return _write_store(data)


def template_list() -> list:
    """Ready-made starter flows shown in Co-work -> Agents.

    Each entry is a REAL graph of node types the runtime already executes; the
    write_document node binds to the registered plugin tool, so the same
    template works whether or not that plugin is enabled - ``validate()`` says
    so explicitly when the tool is missing instead of the run failing silently.
    """
    return [
        {
            "id": "content-writer",
            "name": "Content Writer",
            "description": "Topic(s) in, researched professional PDF/DOCX out.",
            "objective": ("Research one or more topics on the live web and write a "
                          "professional document, then publish it to the "
                          "Artifacts list."),
            "build": "_content_writer_template",
        },
    ]


def _content_writer_template() -> dict:
    """input -> write_document -> output, bound to the real writer tool."""
    # Prefer the name the LIVE registry reports, so a rename in the plugin is
    # picked up automatically. Fall back to the registered contract name so the
    # graph is still complete when the registry has not been injected yet (for
    # example while the store is being built during boot). validate() reports
    # the truth either way - if the tool really is absent the flow is refused
    # instead of silently running without writing anything.
    writer_tool = next((t["name"] for t in _tool_rows()
                        if t["name"].endswith("write_document")), "") or "write_document"
    nodes = [
        {"id": "cw_in", "type": "input", "title": "Topic(s)",
         "config": {"output_key": "topic",
                    "placeholder": "topic, or topics separated by commas",
                    "label": "Topic or comma-separated topics"}},
        {"id": "cw_write", "type": "tool", "title": "Research + Write + Render",
         "config": {"tool": writer_tool,
                    # _render substitutes {{key}} from the RUN CONTEXT, so the
                    # input node's text is addressed as {{ topic }} (the
                    # output_key above). Parsed as JSON DATA, never executed.
                    "args_text": '{"topics": "{{ topic }}", "format": "both", '
                                 '"length": "standard"}',
                    "output_key": "document"}},
        {"id": "cw_out", "type": "output", "title": "Artifact",
         "config": {"label": "Document"}},
    ]
    edges = [{"from": "cw_in", "to": "cw_write"},
             {"from": "cw_write", "to": "cw_out"}]
    return {"name": "Content Writer", "enabled": True,
            "description": template_list()[0]["objective"],
            "nodes": nodes, "edges": edges}


def template_build(template_id: str) -> dict:
    """Return a built template graph, or {} when the id is unknown."""
    for tpl in template_list():
        if tpl["id"] == str(template_id or "").strip():
            builder = globals().get(tpl["build"])
            return builder() if callable(builder) else {}
    return {}


# Keywords that mean "build me the Content Writer flow". This is the request the
# builder failed on most often, and it needs no model at all: the graph already
# exists in _content_writer_template(), which is bound to the real registered
# tool. Matching it here makes text -> runnable workflow deterministic.
_WRITER_INTENTS = ("content writer", "content writer agent", "write a document",
                   "write a report", "generate a pdf", "generate a docx",
                   "create a pdf", "create a docx", "pdf or doc", "pdf and doc",
                   "research and write", "research topic and write",
                   "write article", "blog writer", "document generator")


def _template_from_intent(request: str) -> dict:
    """Map a plain-English request onto a real starter flow, or {} for none.

    Only fires on an explicit, unambiguous match. Anything else falls through to
    the model so the builder never quietly substitutes a template the user did
    not ask for.
    """
    text = str(request or "").lower()
    if not text:
        return {}
    if not any(k in text for k in _WRITER_INTENTS):
        return {}
    built = template_build("content-writer")
    if not built or not built.get("nodes"):
        return {}
    draft = _normalize_agent({
        "name": "Content Writer",
        "description": built.get("description", ""),
        "objective": built.get("description", ""),
        "flow": {"nodes": built.get("nodes") or [],
                 "edges": built.get("edges") or []},
    })
    draft["source"] = "template match (content writer)"
    return draft
def create_agent(payload) -> tuple:
    """Create an agent. Returns (ok, agent|message).

    A payload with a flow keeps it (this is how the natural-language draft is
    materialised); a payload without one gets the runnable input->agent->output
    skeleton so a brand new agent can be run immediately.
    """
    payload = payload if isinstance(payload, dict) else {}
    existing = list_agents()
    if len(existing) >= MAX_AGENTS:
        return (False, "agent limit reached (%d). Delete one first." % MAX_AGENTS)
    submitted = payload.get("flow")
    has_flow = isinstance(submitted, dict) and bool(submitted.get("nodes"))
    # A template request builds a real graph before normalisation, so the
    # created agent is immediately runnable and editable.
    tpl_id = str(payload.get("template") or "").strip()
    if tpl_id and not has_flow:
        built = template_build(tpl_id)
        if not built:
            return (False, "unknown template '%s'" % tpl_id[:64])
        payload = dict(payload)
        # The graph has to arrive under "flow": _normalize_agent reads a full
        # flow from there, and top-level nodes/edges would be dropped.
        payload["flow"] = {"nodes": built.get("nodes") or [],
                           "edges": built.get("edges") or []}
        for key in ("name", "description", "objective"):
            if built.get(key) and not payload.get(key):
                payload[key] = built[key]
        has_flow = True
    agent = _normalize_agent(payload)
    agent["created_at"] = agent["updated_at"] = _now()
    if not has_flow:
        agent["flow"] = default_flow(agent["name"])
    if not _save_agents([agent] + existing):
        return (False, "could not write artifacts/agents/agents.json")
    return (True, agent)


def save_agent(agent_id, payload) -> tuple:
    """Overwrite one agent's definition/flow. Returns (ok, agent|message).

    An id that is NOT in the store is INSERTED, not refused. This is what makes
    "Generate, review, Save" work at all: the NL builder hands the canvas an
    unsaved draft that owns a real id but has never been written, so the first
    Save had nowhere to write to and answered "no agent with id ''". Insert still
    runs the payload through _normalize_agent, so a first save is sanitised
    exactly like every later one - it is not a bypass.
    """
    agents = list_agents()
    wanted = str(agent_id or "").strip()
    for index, agent in enumerate(agents):
        if agent.get("id") != wanted:
            continue
        merged = dict(agent)
        merged.update(payload if isinstance(payload, dict) else {})
        merged["id"] = agent["id"]
        merged["created_at"] = agent.get("created_at") or _now()
        updated = _normalize_agent(merged)
        updated["updated_at"] = _now()
        agents[index] = updated
        if not _save_agents(agents):
            return (False, "could not write artifacts/agents/agents.json")
        return (True, updated)
    # First save of a draft: mint the record instead of dropping it on the floor.
    if not wanted:
        return (False, "no agent id was supplied")
    if len(agents) >= MAX_AGENTS:
        return (False, "agent limit reached (%d). Delete one first." % MAX_AGENTS)
    seeded = dict(payload) if isinstance(payload, dict) else {}
    seeded["id"] = wanted
    seeded["created_at"] = _now()
    inserted = _normalize_agent(seeded)
    inserted["updated_at"] = _now()
    if not _save_agents([inserted] + agents):
        return (False, "could not write artifacts/agents/agents.json")
    return (True, inserted)


def delete_agent(agent_id) -> tuple:
    agents = list_agents()
    wanted = str(agent_id or "").strip()
    remaining = [a for a in agents if a.get("id") != wanted]
    if len(remaining) == len(agents):
        return (False, "no agent with id '%s'" % wanted[:64])
    if not _save_agents(remaining):
        return (False, "could not write artifacts/agents/agents.json")
    return (True, "agent deleted")


def duplicate_agent(agent_id) -> tuple:
    """Deep copy an agent with fresh node ids - the 'duplicate' action."""
    source = get_agent(agent_id)
    if not source:
        return (False, "no agent with id '%s'" % str(agent_id or "")[:64])
    if len(list_agents()) >= MAX_AGENTS:
        return (False, "agent limit reached (%d)" % MAX_AGENTS)
    clone = json.loads(json.dumps(source))
    clone["id"] = _slug("ag")
    clone["name"] = ("%s (copy)" % str(source.get("name") or "Agent"))[:MAX_NAME]
    clone["created_at"] = clone["updated_at"] = _now()
    id_map = {}
    for node in (clone.get("flow") or {}).get("nodes") or []:
        old = node.get("id")
        node["id"] = _slug("n")
        id_map[old] = node["id"]
    for edge in (clone.get("flow") or {}).get("edges") or []:
        edge["id"] = _slug("e")
        edge["from"] = id_map.get(edge.get("from"), edge.get("from"))
        edge["to"] = id_map.get(edge.get("to"), edge.get("to"))
    clone["flow"] = _normalize_flow(clone.get("flow"), clone["name"])
    if not _save_agents([clone] + list_agents()):
        return (False, "could not write artifacts/agents/agents.json")
    return (True, clone)


def set_enabled(agent_id, enabled) -> tuple:
    """Active/Disabled toggle. A disabled agent is kept but refuses to run."""
    agents = list_agents()
    wanted = str(agent_id or "").strip()
    for index, agent in enumerate(agents):
        if agent.get("id") == wanted:
            agents[index]["enabled"] = bool(enabled)
            agents[index]["updated_at"] = _now()
            if not _save_agents(agents):
                return (False, "could not write the store")
            return (True, agents[index])
    return (False, "no agent with id '%s'" % wanted[:64])


def rename_agent(agent_id, name) -> tuple:
    clean = _clean(name, MAX_NAME)
    if not clean:
        return (False, "name cannot be empty")
    return save_agent(agent_id, {"name": clean})


def store_status() -> dict:
    """Honest store health - the Modules probe and the builder both read this."""
    data = _read_store()
    return {"path": str(STORE), "agents": len(data.get("agents") or []),
            "updated_at": float(data.get("updated_at") or 0.0),
            "error": str(data.get("error") or "")}

# ── live capability catalog ───────────────────────────────────────────────────
# REGISTRY INVARIANT (AGENTS.md): a node type is only offered when its target
# actually resolves right now. ``catalog()`` reads the SAME registry the planner
# reads, the same skill folder and the same mcp/servers.json - so a card in the
# builder and a callable tool are the same fact, not two lists that drift.
_CATEGORY_HINTS = (
    ("media", ("video", "audio", "image", "photo", "media", "subtitle", "caption")),
    ("web", ("web_", "search", "firecrawl", "scrape", "crawl", "browser")),
    ("files", ("file", "read", "write", "list_", "dir", "artifact", "path")),
    ("system", ("os_", "app_", "launch", "window", "process", "power", "volume")),
    ("memory", ("memory", "remember", "recall", "forget")),
    ("automation", ("timer", "schedule", "cron", "focus", "telemetry", "battery")),
    ("messaging", ("whatsapp", "mail", "message", "send", "notify")),
)


def _tool_category(name) -> str:
    lowered = str(name or "").lower()
    for category, hints in _CATEGORY_HINTS:
        if any(hint in lowered for hint in hints):
            return category
    return "core"


def _tool_rows() -> list:
    registry = _registry()
    if registry is None:
        return []
    try:
        specs = registry.list()
    except Exception:
        return []
    rows = []
    for spec in specs:
        try:
            rows.append({"name": spec.name,
                         "description": str(spec.description or "")[:200],
                         "gated": bool(spec.requires_confirmation),
                         "params": sorted(getattr(spec, "parameters", {}) or {}),
                         "category": _tool_category(spec.name)})
        except Exception:
            continue
    rows.sort(key=lambda r: r["name"])
    return rows


def _skill_rows() -> list:
    loader = _deps.get("skills")
    if loader is None or not hasattr(loader, "load"):
        return []
    try:
        skills = loader.load() or []
    except Exception:
        return []
    rows = []
    for skill in skills:
        if not isinstance(skill, dict):
            continue
        rows.append({"name": str(skill.get("name") or ""),
                     "description": str(skill.get("description") or "")[:200],
                     "triggers": [str(t) for t in (skill.get("triggers") or [])][:8]})
    rows.sort(key=lambda r: r["name"])
    return rows


def _mcp_rows() -> list:
    client = _deps.get("mcp")
    if client is None or not hasattr(client, "tools_snapshot"):
        return []
    try:
        rows = client.tools_snapshot() or []
    except Exception:
        return []
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        # Registry invariant: a list-only server is NOT offered as a runnable
        # node - allowCall=False means mcp_client refuses the call anyway.
        out.append({"server": str(row.get("server") or ""),
                    "tool": str(row.get("tool") or ""),
                    "description": str(row.get("description") or "")[:200],
                    "callable": bool(row.get("allow_call")),
                    "read_only": bool(row.get("read_only"))})
    out.sort(key=lambda r: (r["server"], r["tool"]))
    return out


def _model_rows() -> list:
    provider = _deps.get("models")
    listed = []
    if callable(provider):
        try:
            listed = provider() or []
        except Exception:
            listed = []
    elif isinstance(provider, (list, tuple)):
        listed = list(provider)
    rows, seen = [], set()
    for item in listed:
        if isinstance(item, dict):
            row = {"id": str(item.get("id") or ""),
                   "label": str(item.get("label") or item.get("id") or "")}
        else:
            row = {"id": str(item), "label": str(item)}
        if row["id"] and row["id"] not in seen:
            seen.add(row["id"])
            rows.append(row)
    return rows


def plan_preview(agent) -> dict:
    """The Phase 12 WORKFLOW PLAN shown BEFORE anything is saved or run.

    Describes the architecture that was generated - objective, agents,
    sub-agents, real bound capabilities, execution pattern and dependencies -
    plus every capability the runtime cannot provide. Purely descriptive: it
    executes nothing and mutates nothing.
    """
    flow = agent.get("flow") or {}
    nodes = flow.get("nodes") or []
    edges = flow.get("edges") or []
    cat = catalog()
    by_type = {}
    for node in nodes:
        by_type.setdefault(str(node.get("type") or "?"), []).append(node)
    tools, mcps, skills, models = [], [], [], []
    for node in nodes:
        config = node.get("config") or {}
        ntype = str(node.get("type") or "")
        if ntype == "tool" and config.get("tool"):
            tools.append(str(config["tool"]))
        elif ntype == "mcp" and config.get("server"):
            mcps.append("%s.%s" % (config.get("server"), config.get("tool") or ""))
        elif ntype == "skill" and config.get("skill"):
            skills.append(str(config["skill"]))
        elif ntype == "model" and config.get("model"):
            models.append(str(config["model"]))
    adjacency = _adjacency(edges)
    report = validate(agent)
    # An honest pattern read straight from the graph, not from the model's claim.
    if any(n.get("type") == "parallel" for n in nodes):
        pattern = "parallel"
    elif any(n.get("type") == "router" for n in nodes):
        pattern = "router"
    elif any(n.get("type") == "loop" for n in nodes):
        pattern = "evaluator-loop"
    elif any(n.get("type") == "workflow" for n in nodes):
        pattern = "nested"
    elif any(n.get("type") == "approval" for n in nodes):
        pattern = "approval-gated"
    elif any(n.get("type") == "subagent" for n in nodes):
        pattern = "manager-workers"
    else:
        pattern = "sequential"
    known_tools = {t["name"] for t in cat["tools"]}
    return {
        "name": str(agent.get("name") or ""),
        "objective": str(agent.get("objective") or agent.get("description") or ""),
        "pattern": pattern,
        "rationale": str((agent.get("plan") or {}).get("rationale") or ""),
        "agents": [{"id": n.get("id"), "title": n.get("title")}
                   for n in by_type.get("agent", [])],
        "sub_agents": [{"id": n.get("id"), "title": n.get("title"),
                        "responsibility": str((n.get("config") or {}).get("description")
                                              or (n.get("config") or {}).get("goal") or ""),
                        "tools": list((n.get("config") or {}).get("tools") or [])}
                       for n in by_type.get("subagent", [])],
        "tools": sorted(set(tools)),
        "skills": sorted(set(skills)),
        "mcp": sorted(set(mcps)),
        "models": sorted(set(models)),
        "node_counts": {k: len(v) for k, v in sorted(by_type.items())},
        "edges": len(edges),
        "unavailable_tools": sorted(set(tools) - known_tools),
        "missing_capabilities": list(agent.get("missing_capabilities") or []),
        "validation": report,
    }


def catalog() -> dict:
    """Everything the builder may bind to, resolved against the live runtime."""
    tools = _tool_rows()
    skills = _skill_rows()
    mcp = _mcp_rows()
    models = _model_rows()
    return {"tools": tools, "skills": skills, "mcp": mcp, "models": models,
            "node_types": list(NODE_TYPES),
            "inbound": {k: list(v) for k, v in ALLOWED_INBOUND.items()},
            "deps": deps_ready(),
            "counts": {"tools": len(tools), "skills": len(skills),
                       "mcp_callable": len([r for r in mcp if r["callable"]]),
                       "models": len(models)}}


def capability_report() -> dict:
    """Honest per-node-type availability for the builder toolbar."""
    cat = catalog()
    counts, deps = cat["counts"], cat["deps"]
    return {"node_types": list(NODE_TYPES), "deps": deps, "counts": counts,
            "available": {
                "input": True, "agent": bool(deps.get("planner")),
                "subagent": bool(deps.get("cortex") and deps.get("planner")),
                "tool": counts["tools"] > 0,
                "mcp": counts["mcp_callable"] > 0,
                "skill": counts["skills"] > 0,
                "model": bool(deps.get("complete") or counts["models"]),
                "condition": True, "approval": True, "output": True,
                # Orchestration primitives: pure engine work, no external
                # capability needed, so they are always available.
                "router": True, "parallel": True, "merge": True, "loop": True,
                "validator": True, "transform": True, "memory": True,
                "error": True, "checkpoint": True, "http": True,
                # These two really do depend on a live subsystem.
                "evaluator": bool(deps.get("complete")),
                "workflow": bool(list_agents())}}

# ── validation ────────────────────────────────────────────────────────────────
def validate(agent) -> dict:
    """Can this flow ACTUALLY run right now? Returns {ok, errors, warnings}.

    Every binding is resolved against the live catalog, so a node bound to a
    tool that a plugin toggle removed is reported HERE, not discovered when the
    run is already halfway through the graph.
    """
    errors, warnings = [], []
    agent = agent if isinstance(agent, dict) else {}
    flow = agent.get("flow") if isinstance(agent.get("flow"), dict) else {}
    nodes = [n for n in (flow.get("nodes") or []) if isinstance(n, dict)]
    edges = [e for e in (flow.get("edges") or []) if isinstance(e, dict)]
    if not nodes:
        return {"ok": False, "errors": ["flow has no nodes"], "warnings": []}
    if not agent.get("enabled", True):
        warnings.append("agent is disabled - it will refuse to run until enabled")

    index = _node_index(nodes)
    if len(index) != len(nodes):
        errors.append("duplicate node ids in the graph")
    cat = catalog()
    tool_names = {t["name"] for t in cat["tools"]}
    skill_names = {s["name"] for s in cat["skills"]}
    mcp_callable = {(m["server"], m["tool"]) for m in cat["mcp"] if m["callable"]}
    model_names = {m["id"] for m in cat["models"]}

    for node in nodes:
        config = node.get("config") or {}
        label = "%s '%s'" % (node.get("type"), node.get("title") or node.get("id"))
        ntype = node.get("type")
        if ntype == "tool":
            name = str(config.get("tool") or "")
            if not name:
                errors.append("%s: no tool selected" % label)
            elif name not in tool_names:
                errors.append("%s: tool '%s' is not in the live registry" % (label, name))
        elif ntype == "mcp":
            server, tool = str(config.get("server") or ""), str(config.get("tool") or "")
            if not server or not tool:
                errors.append("%s: pick an MCP server and tool" % label)
            elif (server, tool) not in mcp_callable:
                errors.append("%s: MCP %s.%s is missing or list-only (allowCall)"
                              % (label, server, tool))
        elif ntype == "skill":
            name = str(config.get("skill") or "")
            if not name:
                errors.append("%s: no skill selected" % label)
            elif name not in skill_names:
                errors.append("%s: skill '%s' has no SKILL.md in skills/" % (label, name))
        elif ntype == "model":
            name = str(config.get("model") or "")
            if name and model_names and name not in model_names:
                warnings.append("%s: model '%s' is not in the provider chain"
                                % (label, name))
            if not str(config.get("prompt") or "").strip():
                errors.append("%s: model node needs a prompt" % label)
        elif ntype == "subagent":
            if not str(config.get("system_prompt") or config.get("goal") or "").strip():
                warnings.append("%s: sub-agent has no system prompt yet" % label)
            if not config.get("tools"):
                warnings.append("%s: sub-agent has an empty tool allowlist" % label)
            if config.get("permissions") == "deny":
                warnings.append("%s: permissions=deny blocks every tool call" % label)
        elif ntype == "condition":
            if not str(config.get("expression") or "").strip():
                errors.append("%s: condition has no expression" % label)
        elif ntype == "router":
            if not str(config.get("key") or "").strip():
                errors.append("%s: router needs a context key" % label)
            if not str(config.get("rules_text") or "").strip():
                warnings.append("%s: router has no rules - everything takes the "
                                "default branch" % label)
        elif ntype == "validator":
            if not str(config.get("expression") or "").strip():
                errors.append("%s: validator needs an expression" % label)
        elif ntype == "evaluator":
            if not str(config.get("criteria") or "").strip():
                errors.append("%s: evaluator needs criteria" % label)
        elif ntype == "transform":
            if str(config.get("mode")) == "regex" and not str(config.get("regex") or ""):
                errors.append("%s: regex transform needs a pattern" % label)
        elif ntype == "memory":
            if not str(config.get("key") or "").strip():
                errors.append("%s: memory node needs a key" % label)
        elif ntype == "loop":
            body = [b.strip() for b in str(config.get("body_text") or "").split(",")
                    if b.strip()]
            unknown = [b for b in body if b not in index]
            if not body:
                errors.append("%s: loop needs a body (list the node ids to repeat)"
                              % label)
            elif unknown:
                errors.append("%s: loop body references unknown node id(s) %s"
                              % (label, ", ".join(unknown[:3])))
        elif ntype == "parallel":
            if not [e for e in edges if e.get("from") == node.get("id")
                    and not e.get("branch")]:
                errors.append("%s: parallel node has no outgoing branches" % label)
        elif ntype == "http":
            if not str(config.get("url") or "").strip():
                errors.append("%s: http node needs a url" % label)
            elif not str(config.get("allow_hosts_text") or "").strip():
                errors.append("%s: http node is locked until you name an allowed host"
                              % label)
        elif ntype == "workflow":
            target = str(config.get("agent_id") or "")
            if not target:
                errors.append("%s: workflow node needs a target agent" % label)
            elif not get_agent(target):
                errors.append("%s: no saved agent with id '%s'" % (label, target))
        elif ntype == "error":
            if not str(config.get("message") or "").strip():
                warnings.append("%s: fallback node has no message" % label)

    for edge in edges:
        source = index.get(edge.get("from"))
        target = index.get(edge.get("to"))
        if not source or not target:
            errors.append("edge %s -> %s points at a missing node"
                          % (edge.get("from"), edge.get("to")))
            continue
        if source.get("type") not in ALLOWED_INBOUND.get(target.get("type"), ()):
            errors.append("%s -> %s is not a legal connection"
                          % (source.get("type"), target.get("type")))

    if not _entry_ids({"nodes": nodes, "edges": edges}):
        errors.append("flow has no entry node (every node has an input)")
    if not any(n.get("type") == "agent" for n in nodes):
        warnings.append("no orchestrator node - the flow runs as a plain pipeline")
    if not any(n.get("type") == "output" for n in nodes):
        warnings.append("no output node - the last node's result is returned anyway")
    return {"ok": not errors, "errors": errors[:24], "warnings": warnings[:12]}

# ── natural-language draft ────────────────────────────────────────────────────
# The planner is asked for a FLOW, not for text to run. Its reply is parsed as
# JSON data, every id/type/binding is re-normalized through the same code path a
# hand-drawn node uses, and the result is returned as a DRAFT the user reviews.
# Nothing here executes and no destructive node is auto-connected.
_NL_SYSTEM = (
    "You design visual agent workflows for a desktop assistant. Reply with ONE "
    "JSON object and nothing else. Shape: "
    '{"name":"...","description":"...","objective":"one sentence restating the '
    'goal","plan":{"pattern":"sequential|parallel|router|handoff|manager-workers|'
    'nested|evaluator-loop","rationale":"why this shape fits"},"missing":'
    '[{"capability":"...","reason":"...","suggestion":"..."}],'
    '"nodes":[{"id":"n1","type":'
    '"input|agent|subagent|tool|mcp|skill|model|condition|approval|output|'
    'router|parallel|merge|loop|validator|evaluator|memory|transform|http|'
    'workflow|error|checkpoint",'
    '"title":"...","config":{}}],"edges":[{"from":"n1","to":"n2","branch":'
    '"true|false|", "map":"src_key:dst_key"}]}. '
    # ── architecture reasoning (was missing: it emitted one node per sentence) ──
    "DESIGN THE ARCHITECTURE, do not transcribe the sentence. Decide how many "
    "distinct RESPONSIBILITIES the task really has, and make exactly one node per "
    "responsibility. Rules: (1) prefer the SIMPLEST architecture that can finish "
    "the task - one sub-agent is usually enough, seven is almost always wrong; "
    "(2) create a subagent ONLY when that work needs its own instructions, its "
    "own tool allowlist, or runs independently; (3) use a parallel node + merge "
    "ONLY when branches are genuinely independent; (4) use a router + branch "
    "labels ONLY when the path depends on a value; (5) use an evaluator + loop "
    "ONLY when quality must be checked and improved; (6) put an approval node "
    "in front of anything destructive or that publishes/spends; (7) add a "
    "validator where a downstream node would otherwise run on bad input. "
    "Allowed connections: input->agent|parallel; agent->subagent|tool|mcp|skill|"
    "model|condition|approval|output|router|parallel; subagent->subagent|tool|"
    "mcp|condition|approval|output; tool->subagent|condition|approval|output|"
    "merge; parallel->tool|mcp|model|subagent; tool|mcp->merge; merge->agent|"
    "output|condition; condition|validator->agent|subagent|tool|output; "
    "router->tool|agent|subagent|output; agent|subagent|tool|mcp|condition|"
    "approval->output. Start with an input node and an agent node, and finish "
    "with an output node. "
    # ── honesty: the catalog is the ONLY source of real capabilities ──
    "Only bind capabilities that appear in the CATALOG below - if the task needs "
    "something that is not listed, do NOT invent a tool: add an entry to "
    '"missing" naming the capability, why it is needed, and how it could be '
    "integrated, and build the rest of the flow without it. Use real tool names "
    "from the catalog; never invent one. Never include shell commands, code "
    "execution or destructive operations. Put any side effect behind an "
    "approval node.\n"
    'BINDING RULES - a node of type tool, mcp, skill or model is INCOMPLETE '
    'unless its config names the capability. Populate config exactly like this:\n'
    '  tool:    {"type":"tool","config":{"tool":"<exact tool name>","args_text":"..."}}\n'
    '  mcp:     {"type":"mcp","config":{"server":"<server>","tool":"<tool>"}}\n'
    '  skill:   {"type":"skill","config":{"skill":"<exact skill name>"}}\n'
    '  model:   {"type":"model","config":{"model":"<model id>","prompt":"..."}}\n'
    '  condition: {"type":"condition","config":{"expression":"last contains error"}}\n'
    '  router:  {"type":"router","config":{"key":"last","rules_text":"contains:x -> a",'
    '"default_branch":"default"}}\n'
    '  parallel:{"type":"parallel","config":{"mode":"all"}}\n'
    '  merge:   {"type":"merge","config":{"strategy":"object","keys_text":"a,b"}}\n'
    '  loop:    {"type":"loop","config":{"body_text":"<node ids>","max_iterations":2,'
    '"until":"score >= 8"}}\n'
    '  validator:{"type":"validator","config":{"expression":"...","on_fail":"fail"}}\n'
    '  evaluator:{"type":"evaluator","config":{"criteria":"...","threshold":7}}\n'
    '  memory:  {"type":"memory","config":{"op":"set","key":"name","value":"{{last}}"}}\n'
    '  transform:{"type":"transform","config":{"mode":"template","template":"..."}}\n'
    '  http:    {"type":"http","config":{"url":"https://...","allow_hosts_text":"host"}}\n'
    '  workflow:{"type":"workflow","config":{"agent_id":"<saved agent id>"}}\n'
    '  error:   {"type":"error","config":{"message":"..."}}\n'
    '  checkpoint:{"type":"checkpoint","config":{"label":"stage-1"}}\n'
    '  approval:{"type":"approval","config":{"prompt":"..."}}\n'
    'ANY node may also carry "output_key":"<snake_case_name>" so downstream '
    'nodes can read {{that_key}} instead of {{last}}. '
    'Use "{{input}}" inside args_text/prompt/template for the run input. Never '
    'leave config empty for the bound node types - a node whose title says '
    '"Invoke X" must carry "tool":"X" with the real catalog name.'
)


def _catalog_text() -> str:
    cat = catalog()
    parts = ["TOOLS: %s" % ", ".join("%s(%s)%s" % (
        t["name"], "/".join(t["params"][:4]) or "-",
        " [needs approval]" if t["gated"] else "") for t in cat["tools"][:26])]
    if cat["skills"]:
        parts.append("SKILLS: %s" % ", ".join(s["name"] for s in cat["skills"][:16]))
    if cat["mcp"]:
        parts.append("MCP: %s" % ", ".join(
            "%s.%s%s" % (m["server"], m["tool"],
                         "" if m["callable"] else " (list-only, do not use)")
            for m in cat["mcp"][:16]))
    if cat["models"]:
        parts.append("MODELS: %s" % ", ".join(m["id"] for m in cat["models"][:8]))
    return " | ".join(parts)


def _nl_prompt_raw(request: str, catalog_text: str) -> str:
    """Real LLM call through the injected provider chain (same one as brain)."""
    complete = _deps.get("complete")
    if not callable(complete):
        return ""
    lines = [_NL_SYSTEM, "", "AVAILABLE CAPABILITIES (bind to these only):",
             catalog_text[:2200], "", "USER REQUEST:", str(request or "")[:1200]]
    try:
        return str(complete("\n".join(lines)) or "")
    except Exception as exc:
        return "__error__%s: %s" % (type(exc).__name__, exc)


def _nl_repair_raw(request: str, bad_reply: str, catalog_text: str) -> str:
    """Second, stricter attempt after the model answered with prose.

    The first call frequently returns a chatty explanation plus a fenced block,
    which is why this exists: rather than telling the user to rephrase, the
    builder asks once more, quoting the unusable reply and naming the exact
    shape it needs.
    """
    complete = _deps.get("complete")
    if not callable(complete):
        return ""
    lines = [_NL_SYSTEM,
             "",
             "Your previous reply could not be used because it was not a single "
             "JSON object. Reply AGAIN with ONLY the JSON object. No prose "
             "before it, no prose after it, no markdown code fence.",
             "",
             "PREVIOUS UNUSABLE REPLY:",
             str(bad_reply or "")[:600],
             "",
             "AVAILABLE CAPABILITIES (bind to these only):",
             catalog_text[:1600],
             "",
             "USER REQUEST:",
             str(request or "")[:1000]]
    try:
        return str(complete("\n".join(lines)) or "")
    except Exception as exc:
        return "__error__%s: %s" % (type(exc).__name__, exc)


def _parse_json_object(text: str) -> dict:
    """Extract the first JSON object from a model reply. Data only, never code.

    Brace-balanced scanning that tolerates prose around the object and a
    markdown fence, because "explain then ```json{...}```" is the single most
    common way a model answers a JSON request.
    """
    raw = str(text or "").strip()
    if not raw:
        return {}
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\s*", "", raw)
        raw = re.sub(r"\s*```\s*$", "", raw)
    start = raw.find("{")
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(raw)):
            ch = raw[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        parsed = json.loads(raw[start:i + 1])
                    except Exception:
                        break
                    return parsed if isinstance(parsed, dict) else {}
        start = raw.find("{", start + 1)
    return {}

# Title keywords -> the real registered tool that does the job. Used only to
# repair a drafted `tool` node that forgot to name a capability; it never invents
# a tool and never overrides a name the model DID supply.
_TOOL_HINTS = (
    ("write_document", ("document", "docx", "pdf", "report", "briefing", "article", "write")),
    ("writer_capabilities", ("writer_capabilit",)),
    ("read_document", ("read document", "open document")),
    ("telemetry_snapshot", ("telemetry", "cpu", "ram", "disk", "system stats")),
    ("telemetry_top_processes", ("top process", "process")),
    ("focus_analytics", ("focus", "productivity")),
    ("ocr_status", ("ocr",)),
    ("modules_status", ("module", "capability status")),
    ("scheduler_set_timer", ("timer", "reminder", "alarm")),
    ("scheduler_cancel", ("cancel timer", "cancel reminder")),
    ("scheduler_status", ("schedule status",)),
    ("video_cut_silence", ("cut silence", "trim silence")),
    ("video_caption", ("caption",)),
)


def _bind_unbound_tools(nodes) -> None:
    """Give a titled-but-empty tool node a real capability, in place.

    A drafted node like {"type":"tool","title":"Save Briefing"} with no tool is
    refused at run time, which made the generated flow a dead end. When exactly
    one registered tool matches the title, it is bound. When nothing matches the
    node is left unbound on purpose - validate() then names the exact problem
    instead of the flow silently doing nothing.
    """
    registry_tools = {row["name"] for row in _tool_rows()}
    if not registry_tools:
        return
    for node in nodes:
        if node.get("type") != "tool":
            continue
        config = node.setdefault("config", {})
        if str(config.get("tool") or "").strip():
            continue
        title = str(node.get("title") or "").strip().lower()
        if not title:
            continue
        for tool_name, keywords in _TOOL_HINTS:
            if tool_name not in registry_tools:
                continue
            if any(word in title for word in keywords):
                config["tool"] = tool_name
                break


def _sanitize_draft(draft: dict, requested_name: str = "") -> dict:
    """Re-normalize an LLM draft through the SAME path as a hand-drawn flow.

    This is what makes the NL builder safe to trust: a node of an unknown type
    is dropped rather than coerced into a tool, every id is regenerated, an
    illegal edge is refused, and every string is re-bounded. The user then edits
    the draft before anything runs.
    """
    draft = draft if isinstance(draft, dict) else {}
    raw_nodes = [n for n in (draft.get("nodes") or []) if isinstance(n, dict)]
    raw_nodes = raw_nodes[:MAX_NODES]
    kept = [n for n in raw_nodes
            if str(n.get("type") or "").strip().lower() in NODE_TYPES]
    nodes = [_normalize_node(n) for n in kept]
    if not any(n["type"] == "input" for n in nodes):
        lead = _default_node("input", "User Input")
        lead["x"], lead["y"] = 40, 220
        nodes.insert(0, lead)
    if not any(n["type"] == "agent" for n in nodes):
        lead = _default_node("agent", requested_name or "Main Agent")
        lead["x"], lead["y"] = 330, 200
        nodes.insert(1, lead)
    if not any(n["type"] == "output" for n in nodes):
        tail = _default_node("output", "Final Output")
        tail["x"] = max([n["x"] for n in nodes] + [500]) + 90
        tail["y"] = 220
        nodes.append(tail)
    remap = {}
    for original, node in zip(kept, nodes):
        node["id"] = _slug("n")
        remap[str(original.get("id") or "")] = node["id"]
    # A model that invents a `tool` node without naming a real capability, or
    # wires an edge the runtime forbids, used to produce a draft that looked
    # plausible on the canvas and then refused to run. Both are resolved here so
    # "generate" produces a flow that actually executes.
    _bind_unbound_tools(nodes)
    by_id = {n["id"]: n for n in nodes}
    edges = []
    for raw_edge in (draft.get("edges") or [])[:MAX_EDGES]:
        if not isinstance(raw_edge, dict):
            continue
        source = remap.get(str(raw_edge.get("from") or ""), "")
        target = remap.get(str(raw_edge.get("to") or ""), "")
        if not source or not target or source == target:
            continue
        src_type = (by_id.get(source) or {}).get("type")
        dst_type = (by_id.get(target) or {}).get("type")
        if not src_type or not dst_type:
            continue
        # An edge the runtime would reject at run time is dropped, not carried
        # into a draft the user then has to debug by hand.
        if src_type not in ALLOWED_INBOUND.get(dst_type, ()):
            continue
        branch = str(raw_edge.get("branch") or "").strip().lower()
        edges.append({"id": _slug("e"), "from": source, "to": target, "label": "",
                      "branch": branch if branch in ("true", "false") else ""})
    flow = _normalize_flow({"nodes": nodes, "edges": edges}, requested_name)
    name = _clean(draft.get("name"), MAX_NAME) or requested_name or "New Agent"
    plan = draft.get("plan") if isinstance(draft.get("plan"), dict) else {}
    # Phase 7: capabilities the planner wanted but the live catalog cannot
    # provide. These are surfaced, never silently faked into a node.
    missing = []
    for item in (draft.get("missing") or [])[:12]:
        if not isinstance(item, dict):
            continue
        capability = _clean(item.get("capability"), 120)
        if not capability:
            continue
        missing.append({"capability": capability,
                        "reason": _clean(item.get("reason"), 400),
                        "suggestion": _clean(item.get("suggestion"), 400)})
    # An `id` is minted HERE, not left to the store. The client renders this
    # draft as an unsaved preview and then POSTs it to /agents/save by that id -
    # a draft without one was unsavable and unrunnable (save and run both failed
    # with "no agent with id ''"). `create_agent` preserves an incoming id, so
    # this also keeps save:true and save:false on the SAME identity.
    return {"id": _slug("ag"),
            "name": name, "description": _clean(draft.get("description"), 600),
            "objective": _clean(draft.get("objective"), 600),
            "category": "custom", "flow": flow,
            "plan": {"pattern": _clean(plan.get("pattern"), 40) or "sequential",
                     "rationale": _clean(plan.get("rationale"), 600)},
            "missing_capabilities": missing,
            "sub_agents": [{"title": n.get("title"), "id": n.get("id")}
                           for n in nodes if n.get("type") == "subagent"],
            "source": "natural-language draft"}


def draft_from_text(request: str, current_name: str = "") -> tuple:
    """Turn one English instruction into an EDITABLE flow draft.

    Returns (ok, draft|message). This never executes anything - the caller
    persists it as a normal agent that the user then reviews and runs by hand.
    """
    text = str(request or "").strip()[:1200]
    if not text:
        return (False, "describe the agent you want first")

    # Fast path first: a request that plainly names one of the known starter
    # flows is built from the REAL template graph instead of being handed to a
    # model that may answer in prose, time out, or 402. The result has the same
    # shape as a drafted flow but is guaranteed runnable.
    #
    # This must run BEFORE the provider check below. A template needs no model
    # at all, so requiring a provider first made a deterministic request fail
    # with "no AI provider is wired" - exactly the case where the template was
    # about to succeed without one.
    templated = _template_from_intent(text)
    if templated:
        templated["validation"] = validate(templated)
        return (True, templated)

    if not callable(_deps.get("complete")):
        return (False, "no AI provider is wired for the natural-language builder")

    catalog = _catalog_text()
    reply = _nl_prompt_raw(text, catalog)
    if reply.startswith("__error__"):
        return (False, "AI provider failed: %s" % reply[9:][:160])
    draft = _parse_json_object(reply)
    # One repair attempt. The old behaviour gave up here and told the user to
    # rephrase, which is what made this builder look permanently broken.
    if not draft:
        retry = _nl_repair_raw(text, reply, catalog)
        if retry and not retry.startswith("__error__"):
            draft = _parse_json_object(retry)
    if not draft:
        if not str(reply or "").strip():
            return (False, "no AI provider answered the builder request - check "
                           "provider keys/quota in .env/.dev.vars")
        return (False, "the model did not return a workflow JSON object - "
                       "try rephrasing the request")
    cleaned = _sanitize_draft(draft, current_name)
    cleaned["validation"] = validate(cleaned)
    return (True, cleaned)

# ── execution ─────────────────────────────────────────────────────────────────
# Node execution is a THIN DRIVER. Each handler performs one primitive and
# returns data; ordering, retries, branching and the last-value context live in
# the walker, and all real thinking stays inside cortex. There is deliberately no
# second agent loop here (AGENTS.md).
MAX_RESULT_CHARS = 2000
_PLACEHOLDER_RE = re.compile(r"\{\{\s*([a-z0-9_.-]{1,40})\s*\}\}", re.I)


def _clip(text, limit=MAX_RESULT_CHARS) -> str:
    return str(text if text is not None else "")[:limit]


def _render(template: str, context: dict) -> str:
    """Substitute {{key}} from the run context. Never evaluates anything."""
    text = str(template or "")
    if "{{" not in text:
        return text

    def _sub(match):
        value = context.get(match.group(1).strip().lower())
        return "" if value is None else str(value)[:MAX_RESULT_CHARS]

    return _PLACEHOLDER_RE.sub(_sub, text)


def _parse_args(text: str, context: dict, label: str) -> tuple:
    """Node arguments: rendered template, parsed as JSON DATA (never executed)."""
    raw = _render(text, context).strip()
    if not raw:
        return (True, {})
    try:
        parsed = json.loads(raw)
    except Exception:
        return (False, '%s: arguments are not valid JSON. Use {"key": "value"}.'
                % label)
    if not isinstance(parsed, dict):
        return (False, "%s: arguments must be a JSON object" % label)
    if len(json.dumps(parsed, ensure_ascii=False)) >= 2000:
        return (False, "%s: arguments exceed the 2000 char budget" % label)
    return (True, parsed)


def _run_tool_node(node, context) -> dict:
    """Execute one REAL registered tool through the real permission gate."""
    config = node.get("config") or {}
    name = str(config.get("tool") or "")
    registry = _registry()
    if registry is None:
        return {"ok": False, "output": "tool registry unavailable", "fatal": True}
    if registry.get(name) is None:
        return {"ok": False,
                "output": "tool '%s' is not registered in the live registry" % name}
    ok, args = _parse_args(config.get("args_text"), context, "Tool '%s'" % name)
    if not ok:
        return {"ok": False, "output": args}
    # The confirm gate is the SAME callback cortex uses. A tool marked
    # requires_confirmation still parks for a real user approval, and the
    # permission engine's own category check still runs inside the plugin
    # wrapper - nothing in the builder bypasses either.
    result = registry.execute(name, args, confirm=_call_confirm)
    return {"ok": bool(result.get("ok")),
            "output": _clip(result.get("output") or result.get("error")),
            "denied": bool(result.get("denied"))}


def _run_mcp_node(node, context) -> dict:
    """Call a configured MCP server tool (allowCall gate enforced by the client)."""
    config = node.get("config") or {}
    server, tool = str(config.get("server") or ""), str(config.get("tool") or "")
    client = _deps.get("mcp")
    if client is None or not hasattr(client, "call_tool"):
        return {"ok": False, "output": "MCP client unavailable", "fatal": True}
    ok, args = _parse_args(config.get("args_text"), context,
                           "MCP %s.%s" % (server, tool))
    if not ok:
        return {"ok": False, "output": args}
    try:
        out = client.call_tool(server, tool, args)
    except Exception as exc:
        return {"ok": False, "output": "%s: %s" % (type(exc).__name__, exc)}
    if not isinstance(out, dict):
        return {"ok": False, "output": "MCP returned a non-dict result"}
    return {"ok": bool(out.get("ok")), "output": _clip(out.get("text") or out.get("error"))}


def _run_skill_node(node, context) -> dict:
    """Load a real SKILL.md body into the run context (instructions, not code)."""
    name = str((node.get("config") or {}).get("skill") or "")
    loader = _deps.get("skills")
    if loader is None or not hasattr(loader, "get"):
        return {"ok": False, "output": "skill loader unavailable", "fatal": True}
    skill = loader.get(name)
    if not skill:
        return {"ok": False, "output": "no SKILL.md found for '%s'" % name}
    body = skill.get("body") or skill.get("description") or ""
    return {"ok": True, "output": _clip(body, 1200),
            "meta": {"skill": str(skill.get("name") or name)}}


def _run_input_node(node, context) -> dict:
    """Publish the run's real text, or fail honestly.

    The old contract returned ``ok=True`` with the literal string "no input
    supplied" when the run had no text. That is a fabricated success: the
    walker published the placeholder into the context, the agent node passed
    it to cortex as a goal, the model replied with a conversational question
    in the user's language, and the run finished ``done``. An input node with
    nothing to say must fail so the branch is pruned and the run reports
    ``failed`` - silence is not a result.

    A configured placeholder is still honoured: it is an explicit author
    default ("topic, or topics separated by commas"), not a missing value.
    """
    config = node.get("config") or {}
    text = str(context.get("run_input") or "").strip() \
        or str(context.get("input") or "").strip()
    if not text:
        text = str(config.get("placeholder") or "").strip()
    if not text:
        return {"ok": False, "fatal": True,
                "output": "input node has no text - type what this agent "
                          "should do and run it again",
                "meta": {"label": str(config.get("label") or "Task input")}}
    return {"ok": True, "output": _clip(text),
            "meta": {"label": str(config.get("label") or "Task input")}}


def _run_output_node(node, context) -> dict:
    config = node.get("config") or {}
    template = _render(config.get("template"), context).strip()
    text = template or str(context.get("last") or context.get("input") or "")
    return {"ok": True, "output": _clip(text, MAX_RESULT_CHARS),
            "meta": {"label": str(config.get("label") or "Final result"),
                     "terminal": True}}

def _agent_prompt(node, context) -> str:
    """Assemble the goal text for a node - no judgement logic lives here."""
    config = node.get("config") or {}
    parts = []
    system = _render(config.get("system_prompt"), context).strip()
    if system:
        parts.append(system)
    goal = _render(config.get("goal"), context).strip()
    if not goal:
        goal = str(context.get("input") or context.get("last") or "").strip()
    parts.append(goal)
    return " ".join(p for p in parts if p)[:2000]


def _run_agent_node(node, context) -> dict:
    """Orchestrator node: run the REAL cortex Plan->Act->Observe loop.

    ``cortex.start`` is asynchronous and owns its own module-level run slot, so
    for an agent embedded inside a flow we use ``cortex.run_subagent`` with the
    full registry - the same loop, guards, confirm gate and loop detection,
    scoped in-line. That is what keeps a nested agent from corrupting or blocking
    the top-level run the user started from another tab.
    """
    cortex = _deps.get("cortex")
    planner = _deps.get("planner")
    registry = _registry()
    if cortex is None or not callable(planner) or registry is None:
        return {"ok": False, "output": "agent runtime unavailable", "fatal": True}
    config = node.get("config") or {}
    goal = _agent_prompt(node, context)
    if not goal:
        return {"ok": False, "output": "agent node has no goal text"}
    result = cortex.run_subagent(
        goal, planner, registry, confirm=_call_confirm, allowed=None,
        max_steps=int(config.get("max_steps") or 4),
        skill_context=str(context.get("skill_context") or "")[:600], on_step=None)
    if not isinstance(result, dict):
        return {"ok": False, "output": "sub-agent returned no result"}
    return {"ok": bool(result.get("ok")), "output": _clip(result.get("answer") or ""),
            "meta": {"reason": str(result.get("reason") or ""),
                     "steps": len(result.get("steps") or [])}}


def _run_subagent_node(node, context) -> dict:
    """Sub-agent node: its own prompt, tool allowlist, budget and policy."""
    cortex = _deps.get("cortex")
    planner = _deps.get("planner")
    registry = _registry()
    if cortex is None or not callable(planner) or registry is None:
        return {"ok": False, "output": "agent runtime unavailable", "fatal": True}
    config = node.get("config") or {}
    name = str(config.get("name") or "sub-agent")
    goal = _agent_prompt(node, context)
    if not goal:
        return {"ok": False, "output": "sub-agent '%s' has no goal text" % name}
    if config.get("permissions") == "deny":
        return {"ok": False,
                "output": "sub-agent '%s' has permissions=deny, so every tool "
                          "call would be refused" % name}
    allowed = [t for t in (config.get("tools") or []) if registry.get(t) is not None]
    skill_context = ""
    loader = _deps.get("skills")
    if loader is not None and hasattr(loader, "context_for"):
        try:
            skill_context = loader.context_for(goal)[:600]
        except Exception:
            skill_context = ""
    result = cortex.run_subagent(
        goal, planner, registry, confirm=_call_confirm, allowed=allowed or None,
        max_steps=int(config.get("max_steps") or 3),
        skill_context=skill_context, on_step=None)
    if not isinstance(result, dict):
        return {"ok": False, "output": "sub-agent '%s' returned no result" % name}
    answer = _clip(result.get("answer") or "")
    ok = bool(result.get("ok"))
    if not ok and not answer:
        answer = " (%s)" % str(result.get("reason") or "failed")
    return {"ok": ok, "output": answer,
            "meta": {"reason": str(result.get("reason") or ""),
                     "steps": len(result.get("steps") or []),
                     "allowed": len(allowed)}}


def _run_model_node(node, context) -> dict:
    """One real LLM completion through the injected provider chain."""
    complete = _deps.get("complete")
    if not callable(complete):
        return {"ok": False, "output": "no AI provider wired", "fatal": True}
    config = node.get("config") or {}
    prompt = _render(config.get("prompt"), context).strip()
    if not prompt:
        return {"ok": False, "output": "model node has no prompt"}
    try:
        text = str(complete(prompt) or "")
    except Exception as exc:
        return {"ok": False, "output": "%s: %s" % (type(exc).__name__, exc)}
    return {"ok": bool(text.strip()), "output": _clip(text)}

# The right-hand side is deliberately restrictive: a quoted string or a bare
# token/number with no statement separators. `1 == 1; drop table` therefore
# fails to parse instead of quietly comparing against "1; drop table" - the
# grammar has no room for a second clause.
_CONDITION_RE = re.compile(
    r"^\s*([a-z0-9_.-]{1,40})\s*(==|!=|not contains|contains|>=|<=|>|<)\s*"
    r"(?:\"([^\"]{0,120})\"|'([^']{0,120})'|([A-Za-z0-9_.:@/+ -]{0,120}?))\s*$",
    re.I)


def _run_condition_node(node, context) -> dict:
    """Tiny, TOTAL expression evaluator.

    Deliberately not eval(): it understands exactly one comparison against the
    run context. Anything it cannot parse is an honest error, never a guess.
    """
    expression = _render((node.get("config") or {}).get("expression"), context).strip()
    if not expression:
        return {"ok": False, "output": "condition has no expression"}
    match = _CONDITION_RE.match(expression)
    if not match:
        return {"ok": False, "output": "cannot parse '%s'. Try: last contains error"
                % expression[:80]}
    key = match.group(1).lower()
    operator = re.sub(r"\s+", " ", match.group(2).strip().lower())
    # Groups 3/4 are the quoted forms (quotes already stripped by the regex);
    # group 5 is the bare form.
    right = match.group(3)
    if right is None:
        right = match.group(4)
    if right is None:
        right = match.group(5) or ""
    right = right.strip()
    left = context.get(key)
    if operator in (">", "<", ">=", "<="):
        try:
            left_value, right_value = float(left), float(right)
        except (TypeError, ValueError):
            return {"ok": False, "output": "'%s' needs numbers on both sides" % operator}
        result = {">": left_value > right_value, "<": left_value < right_value,
                  ">=": left_value >= right_value, "<=": left_value <= right_value}[operator]
    else:
        left_text = "" if left is None else str(left)
        if operator == "==":
            result = left_text == right
        elif operator == "!=":
            result = left_text != right
        elif operator == "contains":
            result = right.lower() in left_text.lower()
        else:
            result = right.lower() not in left_text.lower()
    branch = "true" if result else "false"
    return {"ok": True, "branch": branch,
            "output": "%s -> %s" % (expression[:80], branch)}


def _run_approval_node(node, context) -> dict:
    """Park the run until the user approves in the UI.

    Unlike a tool's confirm gate, an approval NODE is a visible step in the
    graph: the run reports status 'waiting' and stays on this node. A deny is
    recorded honestly and never silently treated as approval.
    """
    config = node.get("config") or {}
    prompt = _render(config.get("prompt"), context) or "Approve this step?"
    node_id = str(node.get("id"))
    with _lock:
        run = _run or {}
        entry = run.setdefault("approvals", {}).setdefault(node_id, {})
        entry.update({"node": node_id, "prompt": _clip(prompt, 300), "at": _now(),
                      "decision": ""})
        _run["status"] = "running"
        _persist_run(run)
    _emit("approval_requested", node=node_id, prompt=_clip(prompt, 200))
    _set_node_state(node_id, status="waiting")
    deadline = _now() + 900.0        # 15 minutes; a stale approval is a deny
    while _now() < deadline:
        if _cancel.is_set():
            return {"ok": False, "output": "cancelled while waiting for approval"}
        decision = _approval_decision(node_id)
        if decision == "approved":
            return {"ok": True, "output": "approved by user",
                    "meta": {"approval": "approved"}}
        if decision == "denied":
            return {"ok": False, "output": "denied by user",
                    "meta": {"approval": "denied"}}
        time.sleep(0.25)
    return {"ok": False, "output": "approval timed out - treated as denied",
            "meta": {"approval": "timeout"}}


# ── orchestration node handlers ────────────────────────────────────────────────
# Every handler performs ONE real primitive and returns data. Nothing here
# fabricates success: an http node really performs the request, an evaluator
# really calls the injected LLM, a workflow node really executes the saved
# sub-flow through this same engine.


def _inbound_keys(node, context) -> list:
    """Context keys published by this node's inbound parents (typed dataflow)."""
    keys = []
    for edge in (context.get("__inbound_edges") or []):
        if edge.get("to") != node.get("id"):
            continue
        source_key = context.get("__output_keys", {}).get(edge.get("from"))
        if source_key and source_key not in keys:
            keys.append(source_key)
    return keys


def _run_router_node(node, context) -> dict:
    """N-way branch on a context value.

    rules_text holds one `value -> branch` rule per line; the FIRST match wins,
    so line order is priority. Unmatched input takes default_branch. The chosen
    name comes back in `branch` and the walker only lets the edge carrying that
    label continue.
    """
    config = node.get("config") or {}
    key = str(config.get("key") or "last")
    value = context.get(key, context.get("last", ""))
    value_text = "" if value is None else str(value)
    lowered = value_text.strip().lower()
    branch = str(config.get("default_branch") or "default")
    for raw in str(config.get("rules_text") or "").splitlines():
        line = raw.strip()
        if not line or "->" not in line:
            continue
        needle, _, label = line.partition("->")
        needle = needle.strip().strip('"\'').lower()
        label = label.strip()
        if not needle or not label:
            continue
        try:
            if needle.startswith("contains:"):
                hit = needle.split(":", 1)[1].strip() in lowered
            elif needle.startswith("regex:"):
                hit = bool(re.search(needle.split(":", 1)[1].strip(), value_text, re.I))
            else:
                hit = lowered == needle
        except re.error:
            continue
        if hit:
            branch = label
            break
    return {"ok": True, "branch": branch,
            "output": "%s=%r -> %s" % (key, value_text[:60], branch),
            "meta": {"router_key": key, "router_branch": branch}}


def _run_merge_node(node, context) -> dict:
    """Fan-in. Collects named context keys into one value.

    `keys_text` is comma separated; empty means "every inbound parent's
    published output key". strategy=object emits JSON, concat joins the
    strings, last takes the final value.
    """
    config = node.get("config") or {}
    strategy = str(config.get("strategy") or "object")
    parents = _inbound_keys(node, context)
    keys = [k.strip() for k in str(config.get("keys_text") or "").split(",")
            if k.strip()] or parents or ["last"]
    collected = {k: context.get(k) for k in keys}
    if strategy == "concat":
        merged = "\n".join(str(v) for v in collected.values() if v not in (None, ""))
    elif strategy == "last":
        values = [v for v in collected.values() if v not in (None, "")]
        merged = values[-1] if values else ""
    else:
        merged = json.dumps(collected, ensure_ascii=False, default=str)[:MAX_RESULT_CHARS]
    return {"ok": True, "output": _clip(merged),
            "meta": {"merged_keys": keys, "strategy": strategy,
                     "values": {k: _clip(v, 400) for k, v in collected.items()}}}


def _eval_expression(expression, context):
    """Total comparison evaluator. NOT eval(): exactly one comparison against
    the run context. Returns (ok, passed_bool, error_message)."""
    match = _CONDITION_RE.match(str(expression or "").strip())
    if not match:
        return (False, False, "cannot parse '%s'. Try: last contains error"
                % str(expression)[:80])
    key = match.group(1).lower()
    operator = re.sub(r"\s+", " ", match.group(2).strip().lower())
    right = match.group(3)
    if right is None:
        right = match.group(4)
    if right is None:
        right = match.group(5) or ""
    right = right.strip()
    left = context.get(key)
    if operator in (">", "<", ">=", "<="):
        try:
            lv, rv = float(left), float(right)
        except (TypeError, ValueError):
            return (False, False, "'%s' needs numbers on both sides" % operator)
        return (True, {">": lv > rv, "<": lv < rv,
                       ">=": lv >= rv, "<=": lv <= rv}[operator], "")
    lt = "" if left is None else str(left)
    low = lt.lower()
    if operator == "==":
        passed = lt == right
    elif operator == "!=":
        passed = lt != right
    elif operator == "contains":
        passed = right.lower() in low
    else:
        passed = right.lower() not in low
    return (True, passed, "")


def _run_validator_node(node, context) -> dict:
    """Assert a condition using the shared total evaluator.

    on_fail=fail  -> the node fails and its downstream branch is pruned.
    on_fail=route -> the node stays ok but returns branch=invalid so an edge
                     labelled `invalid` can take a repair path.
    """
    config = node.get("config") or {}
    expression = _render(str(config.get("expression") or ""), context).strip()
    if not expression:
        return {"ok": False, "output": "validator has no expression"}
    ok, passed, error = _eval_expression(expression, context)
    if not ok:
        return {"ok": False, "output": error}
    if passed:
        return {"ok": True, "branch": "valid",
                "output": "%s -> valid" % expression[:80],
                "meta": {"validator": "valid"}}
    message = _render(str(config.get("message") or "Validation failed"), context)
    if str(config.get("on_fail")) == "route":
        return {"ok": True, "branch": "invalid", "output": message,
                "meta": {"validator": "invalid"}}
    return {"ok": False, "output": message, "meta": {"validator": "invalid"}}


_EVALUATOR_JSON_RE = re.compile(r"\{.*\}", re.S)


def _run_evaluator_node(node, context) -> dict:
    """Real LLM judge: scores the subject against explicit criteria.

    The reply is parsed as JSON DATA ({score, notes}) and never executed. The
    score is published into the context under `score_key` so a `condition` or
    `loop` node can route on it - this is what makes evaluator -> optimizer
    loops possible.
    """
    config = node.get("config") or {}
    criteria = str(config.get("criteria") or "").strip()
    if not criteria:
        return {"ok": False, "output": "evaluator needs criteria"}
    subject_key = str(config.get("subject_key") or "last")
    subject = context.get(subject_key, context.get("last", ""))
    if not str(subject).strip():
        return {"ok": False, "output": "nothing to evaluate (key '%s' is empty)"
                % subject_key}
    complete = _deps.get("complete")
    if not callable(complete):
        return {"ok": False, "output": "no AI provider wired for the evaluator",
                "fatal": True}
    threshold = _int(config.get("threshold"), 7, 0, 10)
    prompt = (
        "You are a strict quality evaluator. Score the SUBJECT from 0 to 10 "
        "against the CRITERIA. Reply with ONE JSON object and nothing else:\n"
        '{"score": <0-10 integer>, "notes": "<one short sentence>"}\n\n'
        "CRITERIA:\n%s\n\nSUBJECT:\n%s" % (criteria[:1000], str(subject)[:2500]))
    try:
        reply = str(complete(prompt) or "")
    except Exception as exc:
        return {"ok": False, "output": "evaluator call failed: %s" % type(exc).__name__}
    score, notes = None, ""
    match = _EVALUATOR_JSON_RE.search(reply)
    if match:
        try:
            parsed = json.loads(match.group(0))
            if isinstance(parsed, dict):
                score = float(parsed.get("score"))
                notes = str(parsed.get("notes") or "")[:300]
        except Exception:
            score = None
    if score is None:
        # An unparsable reply is an honest failure, never a guessed pass.
        return {"ok": False,
                "output": "evaluator did not return a score: %s" % _clip(reply, 120)}
    score = max(0.0, min(10.0, score))
    score_key = str(config.get("score_key") or "score")
    context[score_key] = score
    context[score_key + "_notes"] = notes
    passed = score >= threshold
    return {"ok": True, "branch": "pass" if passed else "retry",
            "output": "score %.1f/10 (threshold %d) %s"
                      % (score, threshold, notes or ("- pass" if passed else "- below bar")),
            "meta": {"score": score, "threshold": threshold, "passed": passed,
                     "score_key": score_key}}


_TRANSFORM_JSON_RE = re.compile(r"\{.*\}", re.S)


def _run_transform_node(node, context) -> dict:
    """Deterministic data shaping. No eval, no code - five fixed modes only."""
    config = node.get("config") or {}
    mode = str(config.get("mode") or "template")
    source = context.get("last", "")
    if mode == "template":
        return {"ok": True, "output": _render(str(config.get("template") or ""), context)}
    if mode in ("upper", "lower"):
        text = _render(str(config.get("template") or "{{last}}"), context)
        return {"ok": True, "output": text.upper() if mode == "upper" else text.lower()}
    if mode == "regex":
        pattern = str(config.get("regex") or "")
        if not pattern:
            return {"ok": False, "output": "regex mode needs a pattern"}
        try:
            compiled = re.compile(pattern, re.S)
        except re.error as exc:
            return {"ok": False, "output": "bad regex: %s" % exc}
        found = compiled.search(str(source))
        if not found:
            return {"ok": False, "output": "regex matched nothing in the upstream value"}
        return {"ok": True, "output": _clip(found.group(1) if compiled.groups
                                            else found.group(0))}
    if mode == "json":
        raw = _render(str(config.get("template") or "{{last}}"), context).strip()
        match = _TRANSFORM_JSON_RE.search(raw)
        if not match:
            return {"ok": False, "output": "no JSON object in the upstream value"}
        try:
            parsed = json.loads(match.group(0))
        except Exception as exc:
            return {"ok": False, "output": "upstream value is not valid JSON: %s" % exc}
        if not isinstance(parsed, dict):
            return {"ok": False, "output": "upstream JSON is not an object"}
        # In json mode the "regex" field is reused as a comma separated key list.
        picks = [k.strip() for k in str(config.get("regex") or "").split(",")
                 if k.strip()]
        if picks:
            missing = [k for k in picks if k not in parsed]
            if missing:
                return {"ok": False,
                        "output": "key(s) not in upstream JSON: %s" % ", ".join(missing[:4])}
            parsed = {k: parsed[k] for k in picks}
        return {"ok": True,
                "output": _clip(json.dumps(parsed, ensure_ascii=False))}
    return {"ok": False, "output": "unknown transform mode '%s'" % mode}


def _run_memory_node(node, context) -> dict:
    """Workflow-scoped state read/write (Phase 14).

    Values live in the run context, so only the keys a node declares are ever
    carried forward - a node never has to re-send the whole conversation.
    """
    config = node.get("config") or {}
    op = str(config.get("op") or "set")
    key = str(config.get("key") or "").strip()
    if not key:
        return {"ok": False, "output": "memory node needs a key"}
    store = context.get("memory")
    if not isinstance(store, dict):
        store = {}
        context["memory"] = store
    if op == "set":
        store[key] = _render(str(config.get("value") or ""), context)
        return {"ok": True, "output": _clip(store[key]),
                "meta": {"op": "set", "key": key}}
    if op == "get":
        value = store.get(key, context.get(key, ""))
        return {"ok": True, "output": _clip(value), "meta": {"op": "get", "key": key}}
    if op == "append":
        prior = str(store.get(key, ""))
        addition = _render(str(config.get("value") or ""), context)
        store[key] = (prior + "\n" + addition).strip() if prior else addition
        return {"ok": True, "output": _clip(store[key]),
                "meta": {"op": "append", "key": key}}
    store.pop(key, None)
    return {"ok": True, "output": "cleared '%s'" % key, "meta": {"op": "delete", "key": key}}


def _run_error_node(node, context) -> dict:
    """Structured failure / fallback sink (Phase 4L).

    Reaching this node means an upstream branch failed and the graph routed the
    error here. The NODE succeeds so the workflow can continue, but it publishes
    an explicit failure payload - never a fabricated result.
    """
    config = node.get("config") or {}
    message = _render(str(config.get("message") or "Step failed"), context)
    payload = {"ok": False, "fallback": True, "reason": _clip(message, 300),
               "failed_node": str(context.get("last_failed_node") or "")}
    return {"ok": True,
            "output": _clip(json.dumps(payload, ensure_ascii=False)),
            "meta": {"fallback": True, "reason": _clip(message, 200)}}


def _run_checkpoint_node(node, context) -> dict:
    """Save a resumable snapshot of the run context (Phase 4K)."""
    config = node.get("config") or {}
    label = str(config.get("label") or "Checkpoint")
    snapshot = {k: _clip(v, 2000) for k, v in context.items()
                if isinstance(v, (str, int, float, bool))}
    memory = context.get("memory")
    if isinstance(memory, dict):
        snapshot["memory"] = {k: _clip(v, 2000) for k, v in memory.items()}
    with _lock:
        run = _run or {}
        run.setdefault("checkpoints", {})[label] = {
            "label": label, "at": _now(), "context": snapshot,
            "node": str(node.get("id") or "")}
        if config.get("persist", True):
            _persist_run(run)
    _emit("checkpoint_saved", label=label, keys=len(snapshot))
    return {"ok": True, "output": "checkpoint '%s' saved (%d keys)"
                                 % (label, len(snapshot)),
            "meta": {"checkpoint": label, "keys": sorted(snapshot.keys())[:20]}}


def _run_http_node(node, context) -> dict:
    """Real outbound HTTP, host-allowlisted.

    Safety (AGENTS.md): no shell, no arbitrary destination. The node only runs
    when `allow_hosts_text` explicitly names the host, so a hand-crafted POST
    cannot turn this into an open proxy.
    """
    config = node.get("config") or {}
    url = _render(str(config.get("url") or ""), context).strip()
    if not url:
        return {"ok": False, "output": "http node needs a url"}
    if not re.match(r"^https?://", url, re.I):
        return {"ok": False, "output": "url must start with http:// or https://"}
    host = re.sub(r"^https?://", "", url, flags=re.I).split("/")[0].split(":")[0].lower()
    allowed = [h.strip().lower() for h in
               re.split(r"[,\s]+", str(config.get("allow_hosts_text") or "")) if h.strip()]
    if not allowed:
        return {"ok": False,
                "output": "http node is locked: add the target host to 'allowed hosts'"}
    if not any(host == a or host.endswith("." + a) for a in allowed):
        return {"ok": False, "output": "host '%s' is not in the allowed host list" % host}
    method = str(config.get("method") or "GET")
    headers = {"Accept": "application/json, text/plain, */*",
               "User-Agent": "JARVIS-AgentFlow/1.0"}
    raw_headers = _render(str(config.get("headers_text") or "{}"), context).strip()
    if raw_headers and raw_headers != "{}":
        try:
            parsed = json.loads(raw_headers)
        except Exception:
            return {"ok": False, "output": "headers must be a JSON object"}
        if isinstance(parsed, dict):
            for key, value in list(parsed.items())[:12]:
                if re.match(r"^[A-Za-z0-9-]{1,40}$", str(key)):
                    headers[str(key)] = _clip(value, 300)
    body = _render(str(config.get("body_text") or ""), context).strip()
    try:
        import requests
    except Exception:
        return {"ok": False, "output": "requests is not installed", "fatal": True}
    timeout = _int(config.get("timeout"), 15, 1, 60)
    try:
        response = requests.request(method, url, headers=headers,
                                    data=body.encode("utf-8") if body else None,
                                    timeout=timeout)
    except Exception as exc:
        return {"ok": False, "output": "http %s failed: %s" % (method, type(exc).__name__)}
    return {"ok": response.status_code < 400, "output": _clip(response.text or ""),
            "meta": {"status": response.status_code, "url": _clip(url, 200),
                     "content_type": str(response.headers.get("Content-Type", ""))[:80]}}


def _run_workflow_node(node, context) -> dict:
    """Nested workflow: run another SAVED agent through this same engine.

    Not a second runtime - `_execute_subflow` re-enters this module's executor
    with a depth guard, so a saved flow becomes a bounded capability of another
    flow (Phase 4G).
    """
    config = node.get("config") or {}
    agent_id = str(config.get("agent_id") or "")
    if not agent_id:
        return {"ok": False, "output": "workflow node needs a target agent"}
    depth = _int(context.get("__depth"), 0, 0, 3) + 1
    if depth > _int(config.get("depth"), 1, 1, 3):
        return {"ok": False, "output": "nested workflow depth limit reached (%d)" % depth,
                "fatal": True}
    target = get_agent(agent_id)
    if not target:
        return {"ok": False, "output": "no saved agent with id '%s'" % agent_id}
    report = validate(target)
    if not report.get("ok"):
        return {"ok": False, "output": "nested agent cannot run: %s"
                % "; ".join(report.get("errors") or [])[:200]}
    source_key = str(config.get("input_key") or "input")
    payload = context.get(source_key, context.get("last", ""))
    child = _execute_subflow(target, str(payload or ""), depth)
    if not child.get("ok"):
        return {"ok": False, "output": "nested workflow failed: %s"
                % _clip(child.get("result") or child.get("reason"), 200)}
    return {"ok": True, "output": _clip(child.get("result")),
            "meta": {"nested_agent": str(target.get("name") or agent_id),
                     "nested_nodes": child.get("nodes_run", 0)}}


NODE_HANDLERS = {
    "input": _run_input_node, "agent": _run_agent_node,
    "subagent": _run_subagent_node, "tool": _run_tool_node, "mcp": _run_mcp_node,
    "skill": _run_skill_node, "model": _run_model_node,
    "condition": _run_condition_node, "approval": _run_approval_node,
    "output": _run_output_node,
    "router": _run_router_node, "merge": _run_merge_node,
    "validator": _run_validator_node, "evaluator": _run_evaluator_node,
    "transform": _run_transform_node, "memory": _run_memory_node,
    "error": _run_error_node, "checkpoint": _run_checkpoint_node,
    "http": _run_http_node, "workflow": _run_workflow_node,
}

# ── run state ─────────────────────────────────────────────────────────────────
def _empty_run(agent_id="", agent_name="", input_text="") -> dict:
    return {"id": _slug("run"), "agent_id": agent_id, "agent": agent_name,
            "input": _clip(input_text, 2000), "status": "pending", "reason": "",
            "nodes": [], "events": [], "approvals": {}, "result": "", "output": "",
            "current": "", "created_at": _now(), "updated_at": _now()}


def _persist_run(run: dict) -> None:
    try:
        STORE_DIR.mkdir(parents=True, exist_ok=True)
        temp = RUN_STORE.with_suffix(".tmp")
        temp.write_text(json.dumps(run, ensure_ascii=False, default=str)[:400000],
                        encoding="utf-8")
        temp.replace(RUN_STORE)
    except Exception:
        pass


def _read_run() -> dict:
    try:
        data = json.loads(RUN_STORE.read_text(encoding="utf-8", errors="ignore") or "{}")
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _emit(event: str, **data) -> None:
    """Append one run event. The UI polls these; nothing is invented."""
    with _lock:
        run = _run or {}
        events = run.setdefault("events", [])
        events.append({"at": _now(), "event": event, **data})
        del events[:-400]
        run["updated_at"] = _now()
        _persist_run(run)


def _set_node_state(node_id: str, **fields) -> None:
    with _lock:
        run = _run or {}
        for entry in run.get("nodes") or []:
            if entry.get("id") == node_id:
                entry.update(fields)
                break
        if run:
            run["updated_at"] = _now()
            _persist_run(run)


def _approval_decision(node_id: str) -> str:
    with _lock:
        pending = ((_run or {}).get("approvals") or {}).get(node_id)
        if pending and pending.get("decision"):
            return str(pending["decision"])
    return ""


def approve(node_id: str, approved: bool) -> tuple:
    """UI action for an approval node (POST /agents/approve)."""
    with _lock:
        run = _run or {}
        if not run or run.get("status") not in ("running", "pending"):
            return (False, "no flow is waiting for approval")
        approvals = run.setdefault("approvals", {})
        entry = approvals.get(str(node_id))
        if entry is None:
            return (False, "no approval is pending on that node")
        if entry.get("decision"):
            return (False, "that approval was already answered")
        decision = "approved" if approved else "denied"
        entry["decision"] = decision
        entry["answered_at"] = _now()
        run["updated_at"] = _now()
        _persist_run(run)
    _emit("approval", node=str(node_id), decision=decision)
    return (True, "approval %s" % decision)


def pending_approvals() -> list:
    """Approval nodes the UI should render buttons for right now."""
    with _lock:
        run = _run or {}
        return [{"node": nid, "prompt": str(entry.get("prompt") or "Approve this step?")}
                for nid, entry in (run.get("approvals") or {}).items()
                if isinstance(entry, dict) and not entry.get("decision")
                and run.get("status") in ("running", "pending")]


def cancel_run() -> tuple:
    """Stop the running flow. A parked approval is released too."""
    with _lock:
        if not _run or _run.get("status") not in ("running", "pending"):
            return (False, "no flow is running")
        _run["status"] = "cancelled"
        _run["reason"] = "cancelled by user"
        _run["updated_at"] = _now()
        for entry in _run.get("nodes") or []:
            if entry.get("status") in ("running", "waiting", "pending"):
                entry["status"] = "cancelled"
        for entry in (_run.get("approvals") or {}).values():
            if isinstance(entry, dict) and not entry.get("decision"):
                entry["decision"] = "denied"
        _persist_run(_run)
    _cancel.set()
    _emit("cancelled")
    return (True, "flow cancelled")


def current_run() -> dict:
    """The live run view for the builder (honest: empty when nothing ran)."""
    with _lock:
        return json.loads(json.dumps(_run, default=str)) if _run else {}


def load_persisted() -> dict:
    """Restore the last run; a restart turns 'running' into 'interrupted'."""
    global _run
    run = _read_run()
    if not run.get("id"):
        return {}
    if run.get("status") in ("running", "pending"):
        run["status"] = "interrupted"
        run["reason"] = "interrupted by process restart"
        for entry in run.get("nodes") or []:
            if entry.get("status") in ("pending", "running", "waiting"):
                entry["status"] = "skipped"
        _persist_run(run)
    with _lock:
        _run = run
    return current_run()

# ── the walker ────────────────────────────────────────────────────────────────
def _order_flow(flow) -> list:
    """Topological order (Kahn). Cycles were already stripped at save time."""
    nodes = flow.get("nodes") or []
    edges = flow.get("edges") or []
    indegree = {n["id"]: 0 for n in nodes}
    adjacency = _adjacency(edges)
    for edge in edges:
        if edge["to"] in indegree:
            indegree[edge["to"]] += 1
    queue = [nid for nid in _entry_ids(flow) if indegree.get(nid, 0) == 0]
    queue += [n["id"] for n in nodes if n["id"] not in queue and indegree.get(n["id"]) == 0]
    order, seen = [], set()
    while queue:
        current = queue.pop(0)
        if current in seen or current not in indegree:
            continue
        seen.add(current)
        order.append(current)
        for target in adjacency.get(current, ()):
            if target in indegree:
                indegree[target] -= 1
                if indegree[target] <= 0:
                    queue.append(target)
    for node in nodes:                       # stragglers (should not happen)
        if node["id"] not in seen:
            order.append(node["id"])
    return order


def _can_retry(outcome) -> bool:
    """Never retry a refusal: a denied permission is the user's answer."""
    if outcome.get("denied"):
        return False
    return not outcome.get("fatal")


def _descendants(node_id, adjacency) -> list:
    out, stack = [], [node_id]
    while stack:
        current = stack.pop()
        for edge in adjacency.get(current, ()):
            if edge["to"] not in out:
                out.append(edge["to"])
                stack.append(edge["to"])
    return out

MAX_PARALLEL_BRANCHES = 6


def _edges_into(adjacency, node_id) -> list:
    """Every edge whose target is node_id (adjacency is keyed by source)."""
    found = []
    for edges in adjacency.values():
        for edge in edges:
            if edge.get("to") == node_id:
                found.append(edge)
    return found


def _branch_region(start_id, adjacency, inbound_counts, stop_types) -> list:
    """Nodes owned by one branch leaving a `parallel` node.

    A branch runs from its target until it reaches a convergence point - a
    `merge` node, or any node with more than one inbound edge - so two branches
    never execute the same node twice.
    """
    region, stack, seen = [], [start_id], set()
    while stack:
        current = stack.pop()
        if current in seen:
            continue
        seen.add(current)
        region.append(current)
        if current != start_id and (current in stop_types
                                    or inbound_counts.get(current, 0) > 1):
            continue          # convergence point belongs to no single branch
        for edge in adjacency.get(current, ()):
            stack.append(edge["to"])
    return region


def _merge_branch_context(context, source) -> None:
    """Copy a branch's published keys back onto the shared context."""
    for key, value in (source or {}).items():
        if key.startswith("__") or key in ("input", "run_input", "agent"):
            continue
        if isinstance(value, (str, int, float, bool)):
            context[key] = value
    memory = (source or {}).get("memory")
    if isinstance(memory, dict):
        context.setdefault("memory", {}).update(memory)
    outcomes = (source or {}).get("__outcomes")
    if isinstance(outcomes, dict):
        context.setdefault("__outcomes", {}).update(outcomes)


def _order_subset(node_ids, adjacency) -> list:
    """Topological order restricted to an explicit id list."""
    wanted = [nid for nid in node_ids if nid]
    indegree = {nid: 0 for nid in wanted}
    for nid in wanted:
        for edge in adjacency.get(nid, ()):
            if edge["to"] in indegree and edge["to"] != nid:
                indegree[edge["to"]] += 1
    queue = [nid for nid in wanted if indegree[nid] == 0]
    order, seen = [], set()
    while queue:
        current = queue.pop(0)
        if current in seen:
            continue
        seen.add(current)
        order.append(current)
        for edge in adjacency.get(current, ()):
            if edge["to"] in indegree and edge["to"] not in seen:
                indegree[edge["to"]] -= 1
                if indegree[edge["to"]] <= 0:
                    queue.append(edge["to"])
    order += [nid for nid in wanted if nid not in seen]
    return order


def _run_parallel_node(node, context, nodes, adjacency, inbound_counts) -> dict:
    """Execute every outbound branch CONCURRENTLY through the shared walker.

    mode=all -> run every branch to completion and collect the results.
    mode=race-> keep the first successful branch.
    Each branch gets its own context copy so one branch cannot clobber another
    branch's typed keys; the winning values are merged back on success.
    """
    config = node.get("config") or {}
    mode = str(config.get("mode") or "all")
    node_id = str(node.get("id") or "")
    targets = []
    for edge in adjacency.get(node_id, ()):
        if not edge.get("branch") and edge["to"] not in targets:
            targets.append(edge["to"])
    if not targets:
        return {"ok": False, "output": "parallel node has no outgoing branches"}
    targets = targets[:MAX_PARALLEL_BRANCHES]
    regions = [(t, _branch_region(t, adjacency, inbound_counts, {"merge"}))
               for t in targets]
    _emit("parallel_started", node=node_id, branches=len(regions), mode=mode)
    results, errors = {}, []
    lock = threading.Lock()

    def _branch(entry):
        target, region = entry
        branch_context = dict(context)
        branch_context["memory"] = dict(context.get("memory") or {})
        _walk_region(nodes, adjacency, region, branch_context,
                     inbound_counts=inbound_counts, quiet=True)
        outcome = (branch_context.get("__outcomes") or {}).get(target, {})
        with lock:
            if outcome.get("ok"):
                results[target] = branch_context
            else:
                errors.append("%s: %s" % (str((nodes.get(target) or {}).get("title")
                                              or target)[:40],
                                          _clip(outcome.get("output"), 120)))
        return bool(outcome.get("ok"))

    workers = 1 if mode == "race" else min(MAX_PARALLEL_BRANCHES, len(regions))
    pool = concurrent.futures.ThreadPoolExecutor(
        max_workers=max(1, workers), thread_name_prefix="jarvis-flow-branch")
    try:
        list(pool.map(_branch, regions))
    finally:
        pool.shutdown(wait=True)
    if results:
        for branch_context in results.values():
            _merge_branch_context(context, branch_context)
    _emit("parallel_finished", node=node_id, ok_branches=len(results),
          failed_branches=len(errors))
    if not results:
        return {"ok": False,
                "output": "all %d parallel branch(es) failed: %s"
                          % (len(regions), "; ".join(errors[:3]) or "no detail")}
    return {"ok": True,
            "output": "%d/%d branch(es) succeeded" % (len(results), len(regions)),
            "meta": {"branches": len(regions), "succeeded": len(results),
                     "failed": errors[:6]}}


def _run_loop_node(node, context, nodes, adjacency, inbound_counts) -> dict:
    """Bounded repeat of a body region (Phase 4J / 4H evaluator-optimizer).

    body_text lists the node ids to repeat. `until` uses the same total
    expression syntax as a condition and is checked AFTER each pass, so an
    evaluator -> optimizer pair genuinely iterates until the score clears the
    bar. Hard-capped at max_iterations so a flow can never spin forever.
    """
    config = node.get("config") or {}
    node_id = str(node.get("id") or "")
    body = [nid.strip() for nid in str(config.get("body_text") or "").split(",")
            if nid.strip() in nodes]
    if not body:
        return {"ok": False,
                "output": "loop node needs a body: list the node ids to repeat"}
    max_iterations = _int(config.get("max_iterations"), 2, 1, 10)
    until = str(config.get("until") or "").strip()
    context[str(config.get("item_key") or "item")] = context.get("item", "")
    body_region = _order_subset(body, adjacency)
    _emit("loop_started", node=node_id, iterations=max_iterations, body=body_region)
    passes, stop_reason, last = 0, "max_iterations", ""
    for iteration in range(1, max_iterations + 1):
        if _cancel.is_set():
            stop_reason = "cancelled"
            break
        passes = iteration
        context["iteration"] = iteration
        # A fresh body each pass, so a failed pass cannot poison the next one.
        for nid in body_region:
            (context.get("__outcomes") or {}).pop(nid, None)
        _walk_region(nodes, adjacency, body_region, context,
                     inbound_counts=inbound_counts, quiet=True)
        outcomes = context.get("__outcomes") or {}
        failed = [nid for nid in body_region
                  if nid in outcomes and not outcomes[nid].get("ok")]
        if failed:
            stop_reason = "body node '%s' failed" % (
                str((nodes.get(failed[0]) or {}).get("title") or failed[0])[:40])
            break
        last = _clip(context.get("last", ""), 200)
        if until:
            ok, passed, _ = _eval_expression(_render(until, context), context)
            if ok and passed:
                stop_reason = "until satisfied"
                break
    _emit("loop_finished", node=node_id, passes=passes, reason=stop_reason)
    return {"ok": True,
            "output": "loop ran %d/%d pass(es) - %s" % (passes, max_iterations, stop_reason),
            "meta": {"passes": passes, "max_iterations": max_iterations,
                     "body": body_region, "reason": stop_reason, "last": last}}


def _walk_region(nodes, adjacency, region, context, inbound_counts=None, quiet=False):
    """Execute one region of nodes in dependency order. THE shared executor.

    Used by the top-level run, by every parallel branch, by every loop body and
    by every nested workflow, so ordering / retries / branching / dataflow have
    exactly ONE implementation in the process (AGENTS.md: no second runtime).

    quiet=True is used for sub-regions: the region still runs and still returns
    real outcomes, it just does not re-announce every node to the top-level run
    view (a loop body may run the same node several times).
    """
    inbound_counts = inbound_counts or {}
    outcomes = context.setdefault("__outcomes", {})
    # Edge list in from->to form, so handlers (merge) can see their parents.
    context.setdefault("__inbound_edges",
                       [edge for edges in adjacency.values() for edge in edges])
    skipped, branch_map = set(), {}
    for node_id in region:
        if _cancel.is_set():
            break
        node = nodes.get(node_id)
        if node is None or node_id in skipped:
            continue
        incoming = _edges_into(adjacency, node_id)
        parents = [e["from"] for e in incoming]
        # A node whose every parent failed or was skipped does not run.
        if parents and all((p in skipped)
                           or (outcomes.get(p, {}).get("ok") is False)
                           for p in parents):
            skipped.add(node_id)
            outcomes[node_id] = {"ok": False, "output": "upstream did not succeed"}
            if not quiet:
                _set_node_state(node_id, status="skipped",
                                output="upstream node failed or was skipped")
                _emit("node_skipped", node=node_id, title=str(node.get("title") or ""))
            continue
        # A router/condition/validator that chose another branch prunes this edge.
        pruned = False
        for parent in parents:
            taken = branch_map.get(parent)
            if not taken:
                continue
            for edge in adjacency.get(parent, ()):
                if edge["to"] == node_id:
                    label = str(edge.get("branch") or "")
                    if label and label != taken:
                        pruned = True
                        break
            if pruned:
                break
        if pruned:
            skipped.add(node_id)
            outcomes[node_id] = {"ok": False, "output": "branch not taken"}
            if not quiet:
                _set_node_state(node_id, status="skipped",
                                output="condition chose another branch")
                _emit("node_skipped", node=node_id, title=str(node.get("title") or ""))
            continue
        ntype = str(node.get("type") or "")
        config = node.get("config") or {}

        def _announce(attempt):
            """Publish a real start/attempt for this node (Phase 9 states)."""
            if quiet:
                return
            with _lock:
                if _run:
                    _run["current"] = node_id
                    _persist_run(_run)
            _set_node_state(node_id, status="running", started_at=_now(),
                            attempts=attempt + 1)
            _emit("node_started", node=node_id, type=ntype,
                  title=str(node.get("title") or ""), attempt=attempt + 1)

        outcome = {"ok": False, "output": "not executed"}
        if ntype == "parallel":
            _announce(0)
            outcome = _run_parallel_node(node, context, nodes, adjacency, inbound_counts)
        elif ntype == "loop":
            _announce(0)
            outcome = _run_loop_node(node, context, nodes, adjacency, inbound_counts)
        else:
            handler = NODE_HANDLERS.get(ntype)
            if handler is None:
                _announce(0)
                outcome = {"ok": False, "output": "no handler for node type '%s'" % ntype}
            else:
                retries = _int(config.get("retries"),
                               1 if ntype in ("agent", "subagent") else 0, 0, 3)
                for attempt in range(retries + 1):
                    _announce(attempt)
                    try:
                        outcome = handler(node, context)
                    except Exception as exc:
                        outcome = {"ok": False,
                                   "output": "%s: %s" % (type(exc).__name__, exc)}
                    if outcome.get("ok") or not _can_retry(outcome):
                        break
                    _emit("node_retry", node=node_id, attempt=attempt + 1,
                          detail=_clip(outcome.get("output"), 200))
        # Record the real outcome BEFORE settling: `_settle_node` and the
        # downstream skip test both read it from here.
        outcomes[node_id] = outcome
        _settle_node(node_id, node, ntype, config, adjacency, nodes, region,
                     context, outcomes, branch_map, skipped, quiet)


def _settle_node(node_id, node, ntype, config, adjacency, nodes, region,
                 context, outcomes, branch_map, skipped, quiet) -> None:
    """Publish a finished node's value, record its branch, and prune on failure."""
    outcome = outcomes.get(node_id) or {}
    ok = bool(outcome.get("ok"))
    output = _clip(outcome.get("output"))
    # Typed dataflow: publish under the node's declared key, then refresh the
    # ambient {{last}} so hand-drawn flows that rely on it keep working.
    if output:
        context["last"] = output
        context["node_" + node_id[-6:]] = output
        # A loaded SKILL.md body is instruction context for the agents that
        # follow, so it accumulates rather than replacing {{last}}.
        if ntype == "skill" and ok:
            context["skill_context"] = (
                context.get("skill_context", "") + "\n" + output)[:2000]
        output_key = str(config.get("output_key") or "")
        if output_key:
            context[output_key] = output
            context.setdefault("__output_keys", {})[node_id] = output_key
    if outcome.get("branch"):
        branch_map[node_id] = str(outcome["branch"])
    # An edge-level `map` renames the value as it crosses the connection, so a
    # wire carries real typed data instead of only relying on {{last}}.
    for edge in adjacency.get(node_id, ()):
        mapping = str(edge.get("map") or "")
        if mapping and ":" in mapping:
            src_key, _, dst_key = mapping.partition(":")
            src_key, dst_key = src_key.strip(), dst_key.strip()
            if src_key and dst_key and src_key in context:
                context[dst_key] = context[src_key]
    if not ok:
        context["last_failed_node"] = node_id
    if not quiet:
        _set_node_state(node_id, status="done" if ok else "failed", output=output,
                        finished_at=_now(), meta=outcome.get("meta") or {})
        _emit("node_finished", node=node_id, type=ntype,
              status="done" if ok else "failed", output=output[:400])
    # A failed node stops its own downstream branch: running those nodes anyway
    # would invent a result from a missing input. An `error` node is the
    # deliberate exception - it is the graph's fallback sink.
    if not ok and ntype != "error":
        for pruned_id in _descendants(node_id, adjacency):
            if pruned_id in skipped or pruned_id not in region:
                continue
            skipped.add(pruned_id)
            outcomes[pruned_id] = {"ok": False, "output": "upstream failed"}
            if not quiet:
                _set_node_state(pruned_id, status="skipped", finished_at=_now(),
                                output="upstream node '%s' did not succeed"
                                       % str(node.get("title") or node_id)[:48])
                _emit("node_skipped", node=pruned_id,
                      title=str((nodes.get(pruned_id) or {}).get("title") or ""))


def _execute_subflow(agent: dict, run_input: str, depth: int) -> dict:
    """Run a saved agent as a nested sub-flow and return its real result.

    Used by the `workflow` node (Phase 4G). It re-enters THIS module's walker,
    so nesting cannot fork a second runtime; `depth` is the only guard.
    """
    flow = agent.get("flow") or {}
    nodes = _node_index(flow.get("nodes") or [])
    adjacency = {}
    for edge in (flow.get("edges") or []):
        adjacency.setdefault(edge["from"], []).append(edge)
    inbound_counts = {}
    for edges in adjacency.values():
        for edge in edges:
            inbound_counts[edge["to"]] = inbound_counts.get(edge["to"], 0) + 1
    context = {"input": _clip(run_input, 2000), "run_input": _clip(run_input, 2000),
               "last": "", "skill_context": "", "memory": {},
               "agent": str(agent.get("name") or ""), "__depth": depth}
    order = _order_flow(flow)
    _walk_region(nodes, adjacency, order, context,
                 inbound_counts=inbound_counts, quiet=True)
    outcomes = context.get("__outcomes") or {}
    outputs = [_clip((outcomes.get(nid) or {}).get("output")) for nid in order
               if (nodes.get(nid) or {}).get("type") == "output"]
    outputs = [o for o in outputs if o]
    failures = [nid for nid in order if outcomes.get(nid, {}).get("ok") is False]
    return {"ok": not failures,
            "result": outputs[-1] if outputs else _clip(context.get("last")),
            "reason": "%d node(s) failed" % len(failures) if failures else "",
            "nodes_run": len(order)}


def _execute_flow(agent: dict, run_input: str, resume_context=None) -> None:
    """Walk one saved graph. Runs on its own thread; never raises out.

    All real work lives in `_walk_region`, which is also what parallel branches,
    loop bodies and nested workflows use - one executor, not four.

    `resume_context` seeds the run from a saved checkpoint so a long workflow
    continues instead of restarting.
    """
    global _run
    flow = agent.get("flow") or {}
    nodes = _node_index(flow.get("nodes") or [])
    adjacency = {}
    for edge in (flow.get("edges") or []):
        adjacency.setdefault(edge["from"], []).append(edge)
    inbound_counts = {}
    for edges in adjacency.values():
        for edge in edges:
            inbound_counts[edge["to"]] = inbound_counts.get(edge["to"], 0) + 1
    order = _order_flow(flow)
    context = {"input": _clip(run_input, 2000), "run_input": _clip(run_input, 2000),
               "last": "", "skill_context": "", "memory": {},
               "agent": str(agent.get("name") or "")}
    if isinstance(resume_context, dict):
        # Real restored state, not a placeholder: typed keys and memory both
        # come back so downstream nodes see what they produced last time.
        for key, value in resume_context.items():
            if key == "memory":
                continue
            if isinstance(value, (str, int, float, bool)):
                context[key] = value
        if isinstance(resume_context.get("memory"), dict):
            context["memory"] = dict(resume_context["memory"])
    with _lock:
        _run["status"] = "running"
        _run["current"] = order[0] if order else ""
        _run["nodes"] = [{"id": nid, "type": (nodes.get(nid) or {}).get("type", "?"),
                          "title": (nodes.get(nid) or {}).get("title", ""),
                          "status": "pending", "output": "", "started_at": 0.0,
                          "finished_at": 0.0, "attempts": 0}
                         for nid in order]
        _persist_run(_run)
    _emit("run_started", agent=str(agent.get("name") or ""), nodes=len(order))
    try:
        _walk_region(nodes, adjacency, order, context,
                     inbound_counts=inbound_counts, quiet=False)
    except Exception as exc:          # the runner thread must never die quietly
        with _lock:
            if _run:
                _run["status"] = "failed"
                _run["reason"] = "runner error: %s" % type(exc).__name__
                _run["current"] = ""
                _persist_run(_run)
        _emit("run_finished", status="failed",
              result="runner error: %s" % type(exc).__name__)
        return
    outcomes = context.get("__outcomes") or {}
    terminal = [_clip((outcomes.get(nid) or {}).get("output")) for nid in order
                if (nodes.get(nid) or {}).get("type") == "output"
                and (outcomes.get(nid) or {}).get("ok")]
    with _lock:
        if _cancel.is_set():
            _run["status"] = "cancelled"
            _run["reason"] = "cancelled by user"
        else:
            failed = [n for n in (_run.get("nodes") or []) if n.get("status") == "failed"]
            if terminal:
                _run["status"] = "done"
                _run["reason"] = ""
            elif failed:
                _run["status"] = "failed"
                _run["reason"] = "%d node(s) failed: %s" % (
                    len(failed), ", ".join(str(n.get("title") or n.get("id"))
                                          for n in failed[:3]))
            else:
                _run["status"] = "done"
                _run["reason"] = "flow finished without reaching an output node"
        _run["result"] = terminal[-1] if terminal else _clip(context.get("last"),
                                                              MAX_RESULT_CHARS)
        _run["output"] = _run["result"]
        # Workflow-scoped state (Phase 14): which typed keys exist and what the
        # memory nodes stored, so the run view can show real dataflow.
        _run["context_keys"] = sorted(
            [k for k in context if not k.startswith("__") and k != "memory"])[:60]
        _run["memory"] = {k: _clip(v, 400)
                          for k, v in (context.get("memory") or {}).items()}
        _run["current"] = ""
        _run["updated_at"] = _now()
        _persist_run(_run)
        final_status = str(_run.get("status"))
    _emit("run_finished", status=final_status, result=_clip(_run.get("result"), 300))


def run_agent(agent_id, input_text="", resume_from=None) -> tuple:
    """Run a SAVED flow through the real registry. Returns (ok, message|run).

    Refuses honestly when the flow does not resolve against the live runtime:
    ``validate()`` runs first, so the UI shows the exact broken binding instead
    of a run that fails halfway through with a vague error.

    ``resume_from`` names a checkpoint: the run continues from that saved
    context instead of a fresh one, so a long workflow resumes from its last
    successful checkpoint (Phase 4K) rather than starting over.
    """
    global _run, _runner
    agent = get_agent(agent_id)
    if not agent:
        return (False, "no agent with id '%s'" % str(agent_id or "")[:64])
    if not agent.get("enabled", True):
        return (False, "agent '%s' is disabled" % str(agent.get("name") or "")[:64])
    report = validate(agent)
    if not report.get("ok"):
        return (False, "flow cannot run: %s" % "; ".join(report.get("errors") or [])[:400])
    resume_context = None
    if resume_from:
        with _lock:
            saved = ((_run or {}).get("checkpoints") or {}).get(str(resume_from)) or {}
            resume_context = saved.get("context") if isinstance(saved, dict) else None
        if not resume_context:
            return (False, "no checkpoint named '%s' in the current run"
                    % str(resume_from)[:40])
    with _lock:
        if _run and _run.get("status") in ("running", "pending"):
            # A run only counts as occupying the slot while its thread is
            # actually alive. Checking the flag alone wedged the builder
            # permanently: a thread that died (or a state file restored from a
            # crashed process) left status="running" forever, and every later
            # Run was refused with "cancel it first" when there was nothing to
            # cancel. A dead thread means nothing is executing, so the stale
            # slot is reclaimed and the refusal is never shown.
            alive = getattr(_runner, "is_alive", None)
            if callable(alive) and alive():
                return (False, "a flow is already running - stop it first, or "
                               "wait for it to finish")
            _run["status"] = "interrupted"
            _run["reason"] = "previous run's thread is no longer alive"
            _run["updated_at"] = _now()
            _persist_run(_run)
        _cancel.clear()
        _run = _empty_run(agent.get("id"), str(agent.get("name") or ""), input_text)
        if resume_context:
            _run["resumed_from"] = str(resume_from)
        run_id = _run["id"]
    _runner = threading.Thread(target=_execute_flow,
                               args=(agent, str(input_text or ""), resume_context),
                               name="jarvis-agent-flow", daemon=True)
    _runner.start()
    return (True, {"run_id": run_id, "status": "running",
                   "agent": str(agent.get("name") or ""),
                   "resumed_from": str(resume_from or "")})


# Standard alias for orchestrators and capability probes
run_flow = run_agent

