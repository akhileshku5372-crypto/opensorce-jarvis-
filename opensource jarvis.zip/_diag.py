import pathlib
p = pathlib.Path("src/index.tsx")
txt = p.read_text(encoding="utf-8", errors="replace")
lines = txt.splitlines()
for i,l in enumerate(lines,1):
    if 3780 <= i <= 3900:
        # safe ascii replace
        safe = l.encode("ascii","backslashreplace").decode()
        print(f"{i:4d}: {safe[:220]}")
print("--- dump 3784-3880 raw start ---")
for i in range(3783,3885):
    if 0 <= i < len(lines):
        open("_tmp_raw.txt","a",encoding="utf-8").write(lines[i]+"\n")
print("wrote _tmp_raw.txt")
