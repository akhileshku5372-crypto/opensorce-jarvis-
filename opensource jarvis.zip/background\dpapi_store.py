"""Windows DPAPI encrypted store for OAuth bearer tokens (Phase 4).

Why this exists
---------------
A Google refresh token is a bearer secret: whoever holds it can read the user's
mailbox from anywhere until it is revoked, so storing it as plain JSON next to
the data root (which is synced/backed up in places) is not acceptable. The
Windows Data Protection API encrypts a blob so that only the *same Windows user
account on the same machine* can decrypt it - a copied token file, another
account or a stolen drive yields nothing.

Honesty rules for this module
-----------------------------
* **No plaintext fallback, ever.** If pywin32 is missing or DPAPI refuses, a
  save reports the failure instead of writing the secret in the clear. A
  "convenient" plaintext path is exactly the bug this module exists to prevent.
* `available()` reports the real capability so the Modules card can say
  BLOCKED (no pywin32 / non-Windows) instead of pretending.
* Reads never raise for callers: a corrupt or foreign blob is reported as
  ``ok: False`` with the reason, because "no token yet" and "unreadable token"
  need different answers from the owner.
"""

from __future__ import annotations

import base64
import json
import time
from pathlib import Path

# The description marker written into every blob. Not configurable on purpose:
# changing it would make previously written tokens unreadable. No optional
# entropy is used, because this pywin32 binding exposes no entropy argument on
# CryptUnprotectData - encrypting with entropy here would make the token
# impossible to read back.
DESCRIPTION = "JARVIS OAuth token"


def _win32crypt():
    try:
        import win32crypt                     # type: ignore
        return win32crypt
    except Exception:
        return None


def available() -> bool:
    """True when this machine can actually encrypt with DPAPI."""
    return _win32crypt() is not None


def unavailable_reason() -> str:
    """Why DPAPI cannot be used here (empty string when it can)."""
    if available():
        return ""
    import sys
    if sys.platform != "win32":
        return ("DPAPI is Windows-only and this host is %s; the token store is "
                "not available" % sys.platform)
    return ("pywin32 (win32crypt) is not installed, so tokens cannot be "
            "encrypted; install pywin32 rather than storing secrets in clear")


def _protect(crypto, raw: bytes) -> bytes:
    """CryptProtectData, tolerating both pywin32 return shapes.

    The installed binding returns the ciphertext bytes; older ones return a
    (description, data) tuple. Both are accepted so a binding upgrade cannot
    silently turn every stored token into an unreadable file.
    """
    blob = crypto.CryptProtectData(raw, DESCRIPTION, None, None, None, 0)
    return bytes(blob[-1]) if isinstance(blob, tuple) else bytes(blob)


def _unprotect(crypto, blob: bytes) -> bytes:
    """CryptUnprotectData with the same tolerance (keyword form verified live)."""
    try:
        out = crypto.CryptUnprotectData(blob, Flags=0)
    except TypeError:                     # older bindings need the positional form
        out = crypto.CryptUnprotectData(blob, None, None, None, 0)
    return bytes(out[-1]) if isinstance(out, tuple) else bytes(out)


def save(path: Path, payload: dict) -> dict:
    """Encrypt `payload` (JSON) to `path`. Returns an honest result dict."""
    crypto = _win32crypt()
    if crypto is None:
        return {"ok": False, "error": unavailable_reason()}
    try:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        blob = _protect(crypto, raw)
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    try:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Write-then-replace so a crash mid-write cannot leave a half blob that
        # looks like a corrupt authorization.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(blob)
        tmp.replace(path)
    except OSError as exc:
        return {"ok": False, "error": "cannot write %s: %s" % (path, exc)}
    return {"ok": True, "path": str(path), "bytes": len(blob),
            "protected": True}


def load(path: Path):
    """Decrypt and return the stored dict, or ``None`` when there is none.

    Never raises: an unreadable blob returns None and records the reason in
    `last_error()` so the caller can report "re-authorize" instead of silently
    behaving like a fresh install.
    """
    path = Path(path)
    if not path.is_file():
        return None
    crypto = _win32crypt()
    if crypto is None:
        _state["error"] = unavailable_reason()
        return None
    try:
        blob = path.read_bytes()
        raw = _unprotect(crypto, blob)
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        _state["error"] = ("stored token at %s could not be decrypted (%s: %s); "
                           "re-authorize the account" % (path, type(exc).__name__,
                                                        exc))
        return None
    return data if isinstance(data, dict) else None


def clear(path: Path) -> bool:
    """Delete a stored token. True when a file is gone afterwards."""
    try:
        Path(path).unlink()
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False


_state = {"error": ""}


def last_error() -> str:
    """Reason the most recent load() failed ("" when nothing failed)."""
    return _state["error"]


def status(path: Path) -> dict:
    """Real on-disk state for the Modules card and the /apps/status endpoint."""
    path = Path(path)
    info = {
        "path": str(path),
        "exists": path.is_file(),
        "dpapi_available": available(),
        "encrypted": False,
        "bytes": 0,
        "mtime": 0.0,
        "error": unavailable_reason(),
    }
    if path.is_file():
        try:
            stat = path.stat()
            info.update(bytes=stat.st_size, mtime=stat.st_mtime)
        except OSError:
            pass
        # A DPAPI blob starts with a version header; plaintext JSON would start
        # with '{'. Checking that keeps the "encrypted" claim honest.
        try:
            head = path.read_bytes()[:1]
            info["encrypted"] = head not in (b"{", b"[")
        except OSError:
            pass
    return info


def encode(blob: bytes) -> str:
    """base64url for a blob - Google's token endpoint speaks base64url."""
    return base64.urlsafe_b64encode(blob).decode("ascii").rstrip("=")


def decode(text: str) -> bytes:
    """Inverse of :func:`encode` (padding restored)."""
    padded = text + "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode(padded.encode("ascii"))


def now() -> float:
    """Single clock seam so tests can reason about expiry."""
    return time.time()