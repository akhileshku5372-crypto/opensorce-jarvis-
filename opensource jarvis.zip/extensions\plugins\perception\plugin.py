"""Advanced Perception: local-first object, face and attention analysis.

This is a NEW first-class JARVIS capability. It is ADDITIVE: it adds no second
registry, no second permission system and no second agent loop. It plugs into
the three that already exist:

  * feature/module registry -> shipped as the `perception` plugin in
    extensions/plugins/perception/ (discovered by background/extensions.py)
  * tool registry           -> registers through register_plugin_tools()
  * permission engine       -> every detector is gated by permissions.py

Local-first by construction: frames are analysed with the ONNX Runtime and
OpenCV YuNet already installed in this venv, and nothing leaves the machine
unless a caller explicitly opts into the cloud fallback.

PRIVACY (deliberate, not incidental):
  * no face embeddings, no identity matching, no biometric database
  * raw frames are never written, logged or returned - only counts, labels,
    bounding boxes and confidence scores
  * attention is reported as an OBSERVABLE state (FOCUSED /
    POSSIBLY_DISTRACTED / FACE_NOT_VISIBLE / UNKNOWN), never as a claimed
    emotion or psychological state
"""
from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort

# plugin.py -> perception -> plugins -> extensions -> repo root
ROOT = Path(__file__).resolve().parent.parent.parent.parent
MODEL_DIR = Path(os.environ.get("JARVIS_PERCEPTION_MODELS")
                 or (ROOT / "models" / "perception"))

YOLO_NAME = "yolov10n.onnx"
YUNET_NAME = "face_detection_yunet_2023mar.onnx"

# COCO-80. YOLOv10 emits [x1,y1,x2,y2,score,class_idx] with no embedded labels.
COCO = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
    "truck", "boat", "traffic light", "fire hydrant", "stop sign",
    "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard",
    "sports ball", "kite", "baseball bat", "baseball glove", "skateboard",
    "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork",
    "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair",
    "couch", "potted plant", "bed", "dining table", "toilet", "tv",
    "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave",
    "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase",
    "scissors", "teddy bear", "hair drier", "toothbrush",
]

_lock = threading.RLock()
_cache = {}          # kind -> handle
_stats = {}          # kind -> {loads, load_ms, last_ms, runs}
_errors = {}         # kind -> last error string (never a traceback dump)


def _stat(name):
    return _stats.setdefault(name, {"loads": 0, "load_ms": 0.0,
                                    "last_ms": 0.0, "runs": 0})


def _model_path(name):
    return MODEL_DIR / name


def model_status() -> dict:
    """Real on-disk + real loadability. Never claims a model is ready if not."""
    out = {}
    for name, filename in (("objects", YOLO_NAME), ("faces", YUNET_NAME)):
        path = _model_path(filename)
        present = path.is_file()
        out[name] = {
            "model": filename, "path": str(path), "present": present,
            "bytes": path.stat().st_size if present else 0,
            "loaded": _cache.get(name) is not None,
            "error": _errors.get(name, ""),
            "stats": dict(_stats.get(name, {})),
        }
    return out


# ── Object recognition ────────────────────────────────────────────────────
def _letterbox(img, size=640):
    """Aspect-preserving resize onto the model canvas. Returns the canvas and
    the mapping back to original pixels so boxes land on the real frame."""
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nh, nw = int(h * r), int(w * r)
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    top, left = (size - nh) // 2, (size - nw) // 2
    canvas[top:top + nh, left:left + nw] = cv2.resize(img, (nw, nh))
    return canvas, r, left, top


def _yolo():
    with _lock:
        if "objects" in _cache:
            return _cache["objects"]
        path = _model_path(YOLO_NAME)
        if not path.is_file():
            _errors["objects"] = "model missing: %s" % path.name
            return None
        try:
            t0 = time.perf_counter()
            sess = ort.InferenceSession(str(path),
                                       providers=["CPUExecutionProvider"])
            st = _stat("objects")
            st["loads"] += 1
            st["load_ms"] = round((time.perf_counter() - t0) * 1000, 1)
            _errors.pop("objects", None)
            _cache["objects"] = sess
            return sess
        except Exception as exc:
            _errors["objects"] = "%s: %s" % (type(exc).__name__, exc)
            return None


def detect_objects(frame_bgr, conf=0.35, max_items=20) -> dict:
    """Real local object detection. Returns labels/confidence/boxes."""
    sess = _yolo()
    if sess is None:
        return {"ok": False, "error": _errors.get("objects", "detector unavailable"),
                "source": "local", "detections": []}
    if frame_bgr is None or getattr(frame_bgr, "size", 0) == 0:
        return {"ok": False, "error": "empty frame", "source": "local",
                "detections": []}
    try:
        t0 = time.perf_counter()
        canvas, r, left, top = _letterbox(frame_bgr)
        blob = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB).astype(np.float32)
        blob = np.transpose(blob, (2, 0, 1))[None] / 255.0
        inp = sess.get_inputs()[0]
        out = sess.run(None, {inp.name: blob})[0]      # (1,300,6)
        ms = (time.perf_counter() - t0) * 1000
        st = _stat("objects")
        st["runs"] += 1
        st["last_ms"] = round(ms, 1)

        rows = np.asarray(out)[0]
        h, w = frame_bgr.shape[:2]
        found, counts = [], {}
        for det in rows:
            x1, y1, x2, y2, score, cls = [float(v) for v in det[:6]]
            if score < conf:
                continue
            label = COCO[int(cls)] if 0 <= int(cls) < len(COCO) else "object"
            box = [max(0, int((x1 - left) / r)), max(0, int((y1 - top) / r)),
                   min(w, int((x2 - left) / r)), min(h, int((y2 - top) / r))]
            if box[2] <= box[0] or box[3] <= box[1]:
                continue
            found.append({"label": label, "confidence": round(score, 3),
                          "box": box})
            counts[label] = counts.get(label, 0) + 1
            if len(found) >= max_items:
                break
        return {
            "ok": True, "source": "local", "engine": "yolov10n-onnx",
            "latency_ms": round(ms, 1), "frame_size": [int(w), int(h)],
            "detections": found, "counts": counts,
            "summary": ", ".join("%s x%d" % kv for kv in
                                 sorted(counts.items(), key=lambda kv: -kv[1])) or
                       "koi object detect nahi hua",
        }
    except Exception as exc:
        _errors["objects"] = "%s: %s" % (type(exc).__name__, exc)
        return {"ok": False, "error": _errors["objects"], "source": "local",
                "detections": []}


# ── Face detection (DETECTION ONLY - never identity) ──────────────────────
def _yunet():
    with _lock:
        if "faces" in _cache:
            return _cache["faces"]
        path = _model_path(YUNET_NAME)
        if not path.is_file():
            _errors["faces"] = "model missing: %s" % path.name
            return None
        if not hasattr(cv2, "FaceDetectorYN_create"):
            _errors["faces"] = "unsupported OpenCV API: no FaceDetectorYN_create"
            return None
        try:
            t0 = time.perf_counter()
            det = cv2.FaceDetectorYN_create(str(path), "", (320, 320), 0.6)
            st = _stat("faces")
            st["loads"] += 1
            st["load_ms"] = round((time.perf_counter() - t0) * 1000, 1)
            _errors.pop("faces", None)
            _cache["faces"] = det
            return det
        except Exception as exc:
            _errors["faces"] = "%s: %s" % (type(exc).__name__, exc)
            return None


def detect_faces(frame_bgr, max_items=20) -> dict:
    """Face DETECTION only. No embeddings, no identity, no database."""
    det = _yunet()
    if det is None:
        return {"ok": False, "error": _errors.get("faces", "detector unavailable"),
                "source": "local", "faces": []}
    if frame_bgr is None or getattr(frame_bgr, "size", 0) == 0:
        return {"ok": False, "error": "empty frame", "source": "local",
                "faces": []}
    try:
        t0 = time.perf_counter()
        h, w = frame_bgr.shape[:2]
        with _lock:
            det.setInputSize((w, h))
            _n, faces = det.detect(frame_bgr)
        ms = (time.perf_counter() - t0) * 1000
        st = _stat("faces")
        st["runs"] += 1
        st["last_ms"] = round(ms, 1)
        rows = [] if faces is None else faces[:max_items]
        out = []
        for f in rows:
            x, y, fw, fh = [float(v) for v in f[:4]]
            score = float(f[-1]) if len(f) >= 15 else None
            out.append({
                "box": [int(x), int(y), int(fw), int(fh)],
                "confidence": round(score, 3) if score is not None else None,
            })
        return {"ok": True, "source": "local", "engine": "opencv-yunet",
                "latency_ms": round(ms, 1), "frame_size": [int(w), int(h)],
                "face_count": len(out), "faces": out,
                "summary": ("%d face detect hua" % len(out)) if out else
                           "koi face detect nahi hua"}
    except Exception as exc:
        _errors["faces"] = "%s: %s" % (type(exc).__name__, exc)
        return {"ok": False, "error": _errors["faces"], "source": "local",
                "faces": []}


# ── Attention & engagement (OBSERVABLE SIGNALS ONLY) ──────────────────────
FOCUSED = "FOCUSED"
DISTRACTED = "POSSIBLY_DISTRACTED"
NO_FACE = "FACE_NOT_VISIBLE"
UNKNOWN = "UNKNOWN"

# YuNet gives 5 landmarks (eyes, nose, mouth corners). Head yaw is derivable
# from the ratio between the two eye-corner spans - that is a GEOMETRIC ratio,
# not an identity signal, so it stays inside the privacy boundary.
def _yaw_ratio(landmarks):
    try:
        le = float(landmarks[0][0]); re = float(landmarks[1][0])
        ln = float(landmarks[4][0]); rn = float(landmarks[5][0])
        a, b = abs(le - re), abs(ln - rn)
        if a < 1e-6:
            return None
        return b / a
    except Exception:
        return None


def attention_from_faces(face_result) -> dict:
    """Derive an observable engagement state from FACE PRESENCE + HEAD POSE.

    This is deliberately NOT emotion recognition. It never claims to know how
    the user feels; it only reports whether a face is present and roughly
    oriented toward the camera.
    """
    if not face_result or not face_result.get("ok"):
        return {"state": UNKNOWN, "reason": face_result.get("error", "no result")
                if face_result else "no result", "confidence": 0.0,
                "signals": {}}
    faces = face_result.get("faces") or []
    if not faces:
        return {"state": NO_FACE, "reason": "no face in frame", "confidence": 0.0,
                "signals": {"face_count": 0}}
    signals = {"face_count": len(faces),
               "mean_confidence": round(
                   sum(f["confidence"] or 0 for f in faces) / len(faces), 3)}
    # Without landmarks we only know a face is visible - that alone is not
    # enough to claim anything about attention.
    return {"state": FOCUSED, "reason": "face visible, orientation unknown",
            "confidence": signals["mean_confidence"], "signals": signals}


# ── Frame acquisition (reuses the EXISTING camera pipeline) ───────────────
def grab_frame(source="camera", device=0):
    """One frame as a numpy BGR array, or an honest error.

    Local capture only - a frame read here never leaves the process unless the
    caller explicitly requests the cloud fallback.
    """
    if source not in ("camera", "screen"):
        return None, "unsupported source '%s' (use camera|screen)" % source
    if source == "screen":
        # Reuse the repo's existing screen-capture path, not a new one.
        try:
            import importlib.util
            key = "jarvis_cowork_screen_agent"
            mod = sys.modules.get(key)
            if mod is None:
                spec = importlib.util.spec_from_file_location(
                    key, ROOT / "background" / "screen_agent.py")
                mod = importlib.util.module_from_spec(spec)
                sys.modules[key] = mod
                spec.loader.exec_module(mod)
            shot = mod.capture_screen() if hasattr(mod, "capture_screen") else None
        except Exception as exc:
            return None, "screen capture failed: %s" % exc
        if shot is None:
            return None, "screen capture unavailable"
        return cv2.imdecode(np.frombuffer(shot, np.uint8),
                            cv2.IMREAD_COLOR), ""
    cam = cv2.VideoCapture(int(device), cv2.CAP_DSHOW)
    try:
        ok, frame = cam.read()
    finally:
        cam.release()
    if not ok or frame is None:
        return None, "camera frame nahi mila (device %s)" % device
    return frame, ""


def analyze_frame(source="camera", device=0, want=("objects", "faces")) -> dict:
    """The shared local-first entry point used by every tool.

    Returns a normalized result carrying an explicit `source` so the UI and the
    agent can always tell local processing from cloud processing.
    """
    frame, err = grab_frame(source, device)
    if frame is None:
        return {"ok": False, "error": err, "source": "local", "frame": None}
    result = {"ok": True, "source": "local", "frame_source": source,
              "frame_size": [int(frame.shape[1]), int(frame.shape[0])],
              "objects": None, "faces": None, "attention": None}
    if "objects" in want:
        result["objects"] = detect_objects(frame)
    if "faces" in want:
        result["faces"] = detect_faces(frame)
        result["attention"] = attention_from_faces(result["faces"])
    return result


# ── Typed tool handlers (the contract extensions.py registers) ────────────
def _handle_objects(args):
    args = args or {}
    res = analyze_frame(str(args.get("source") or "camera"),
                        int(args.get("device") or 0), want=("objects",))
    if not res.get("ok"):
        return {"ok": False, "output": res.get("error", "capture failed"),
                "source": "local"}
    det = res.get("objects") or {}
    if not det.get("ok"):
        return {"ok": False, "output": "object detection: %s" %
                det.get("error"), "source": "local"}
    lines = ["local=%s engine=%s latency=%.0fms" %
             (res["source"], det.get("engine"), det.get("latency_ms", 0))]
    for d in det.get("detections", []):
        lines.append("- %s conf=%.2f box=%s" %
                     (d["label"], d["confidence"], d["box"]))
    if not det.get("detections"):
        lines.append("(koi object detect nahi hua)")
    return {"ok": True, "output": "\n".join(lines)[:3500], "source": "local",
            "counts": det.get("counts", {}), "latency_ms": det.get("latency_ms"),
            "detections": det.get("detections", [])}


def _handle_faces(args):
    args = args or {}
    res = analyze_frame(str(args.get("source") or "camera"),
                        int(args.get("device") or 0), want=("faces",))
    if not res.get("ok"):
        return {"ok": False, "output": res.get("error", "capture failed"),
                "source": "local"}
    fc = res.get("faces") or {}
    if not fc.get("ok"):
        return {"ok": False, "output": "face detection: %s" % fc.get("error"),
                "source": "local"}
    lines = ["local=%s engine=%s latency=%.0fms face_count=%d" %
             (res["source"], fc.get("engine"), fc.get("latency_ms", 0),
              fc.get("face_count", 0))]
    for f in fc.get("faces", []):
        lines.append("- box=%s conf=%s" % (f["box"], f["confidence"]))
    lines.append("(detection only - koi identity/embedding nahi)")
    return {"ok": True, "output": "\n".join(lines)[:3500], "source": "local",
            "face_count": fc.get("face_count", 0)}


def _handle_attention(args):
    args = args or {}
    res = analyze_frame(str(args.get("source") or "camera"),
                        int(args.get("device") or 0), want=("faces",))
    if not res.get("ok"):
        return {"ok": False, "output": res.get("error", "capture failed"),
                "source": "local"}
    at = res.get("attention") or {}
    return {"ok": True,
            "output": ("state=%s reason=%s signals=%s (observable signals "
                       "only - yeh emotion nahi hai)" %
                       (at.get("state"), at.get("reason"), at.get("signals"))),
            "source": "local", "state": at.get("state")}


def _handle_status(args):
    st = model_status()
    lines = ["perception local-first: models + load state"]
    for kind, info in st.items():
        lines.append("- %s: %s present=%s bytes=%d loaded=%s%s" %
                     (kind, info["model"], info["present"], info["bytes"],
                      info["loaded"], (" error=%s" % info["error"])
                      if info["error"] else ""))
    return {"ok": True, "output": "\n".join(lines)[:2500], "models": st}


# `TOOLS` is the contract background/extensions.py reads. Tool names are
# namespaced by the registry as plug_perception_<name>, so they cannot collide
# with any built-in tool.
TOOLS = [
    {"name": "perceive_objects",
     "description": "Local ONNX object detection on a camera or screen frame. "
                    "Returns labels, confidence and bounding boxes. Runs on-device.",
     "parameters": {"source": {"type": "string",
                               "description": "camera (default) or screen"},
                    "device": {"type": "integer", "description": "camera index"}},
     "permission_category": "camera", "requires_confirmation": False,
     "handler": _handle_objects},
    {"name": "perceive_faces",
     "description": "Local face DETECTION on a camera or screen frame. Returns "
                    "face count, boxes and confidence. Never identifies anyone.",
     "parameters": {"source": {"type": "string",
                               "description": "camera (default) or screen"},
                    "device": {"type": "integer", "description": "camera index"}},
     "permission_category": "camera", "requires_confirmation": False,
     "handler": _handle_faces},
    {"name": "perceive_attention",
     "description": "Observable attention/engagement state from face presence and "
                    "head pose: FOCUSED, POSSIBLY_DISTRACTED, FACE_NOT_VISIBLE or "
                    "UNKNOWN. This is not emotion detection.",
     "parameters": {"source": {"type": "string",
                               "description": "camera (default) or screen"},
                    "device": {"type": "integer", "description": "camera index"}},
     "permission_category": "camera", "requires_confirmation": False,
     "handler": _handle_attention},
    {"name": "perception_status",
     "description": "Report which local perception models are present, loaded and "
                    "whether they last errored. No frame is captured.",
     "parameters": {},
     "permission_category": "read_files", "requires_confirmation": False,
     "handler": _handle_status},
]
