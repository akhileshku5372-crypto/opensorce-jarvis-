﻿import os, json, time, requests
for line in open(".env", encoding="utf-8"):
    line=line.strip()
    if line and not line.startswith("#") and "=" in line:
        k,v=line.split("=",1); os.environ.setdefault(k.strip(), v.strip())
t0=time.time()
try:
    r=requests.post("https://api.groq.com/openai/v1/chat/completions",
      headers={"Authorization":"Bearer "+os.environ.get("GROQ_API_KEY","")},
      json={"model":os.environ.get("GROQ_MODEL",""),"max_tokens":1500,
            "messages":[{"role":"user","content":"Return ONLY a JSON object {\"ok\":true}"}]},
      timeout=25)
    print("GROQ", r.status_code, round(time.time()-t0,1), r.text[:150])
except Exception as e:
    print("GROQ ERR", type(e).__name__, str(e)[:150])
