"""Memory-command execution path: intent -> phase1 memory route -> REAL stores.

Locks the live bug: a memory-save request ("save and split and also chunk by
chunk storage in your memory and save for long term") fell through to the LLM
and could come back as the power-action deny instead of reaching the memory
system.

Every test redirects JARVIS_DATA_ROOT at a temp dir BEFORE loading the engine,
so assertions run against REAL ChromaDB writes that are read back, superseded
and deleted - never a mocked success. The brain is replaced with a marker
reply so any fall-through is loud, and the power-deny strings are asserted
absent so the reported regression can never reappear silently.

Run:  node run_py.cjs -m unittest discover -s tests -p test_memory_commands.py
"""
import importlib
import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

FAILING_PHRASE = ("save and split and also chunk by chunk storage in your "
                  "memory and save for long term")


class _TempRoot:
    """Temp dir that tolerates Windows file locks (ChromaDB keeps handles)."""

    def __init__(self):
        self._tmp = tempfile.TemporaryDirectory()

    @property
    def path(self) -> Path:
        return Path(self._tmp.name)

    def cleanup(self):
        try:
            self._tmp.cleanup()
        except (PermissionError, OSError):
            pass


def _load_engine():
    spec = importlib.util.spec_from_file_location(
        "voice_engine", ROOT / "background" / "voice_engine.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class MemoryCommandTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = _TempRoot()
        cls.addClassCleanup(cls.tmp.cleanup)
        os.environ["JARVIS_DATA_ROOT"] = str(cls.tmp.path)
        sys.path.insert(0, str(ROOT / "background"))
        # Purge plain AND _load_bg shared-key identities so every store
        # resolves against THIS temp root, never a stale one.
        for name in list(sys.modules):
            if (name in ("conversation_store", "conversation_memory",
                         "jarvis_memory", "storage_paths", "voice_engine",
                         "memory_protocol")
                    or name.startswith("jarvis_cowork_")):
                sys.modules.pop(name, None)
        cls.voice = _load_engine()
        cls.explicit = importlib.import_module("jarvis_memory")
        cls.learned = importlib.import_module("conversation_memory")
        if not cls.explicit.status()["available"]:
            raise unittest.SkipTest("chromadb unavailable")

    def setUp(self):
        self.spoken = []
        self._diag = self.voice._diag
        self.voice._diag = lambda *a, **k: None
        self.addCleanup(setattr, self.voice, "_diag", self._diag)
        self.voice.speak = lambda text, ui=None: self.spoken.append(str(text))
        # A brain call for a memory phrase is a ROUTING MISS - keep it loud.
        self.voice.brain = lambda text, ui=None: (
            self.spoken.append("BRAIN_FALLTHROUGH: %s" % text) or "x")
        self.voice.bridge_command = lambda cmd, bridge=None: None
        with self.voice._recent_lock:
            self.voice._recent.clear()
        with self.voice._action_stamps_lock:
            self.voice._action_stamps.clear()
        self.voice._history.clear()
        self.voice._CONTEXT_CONV_ID = ""
        self.voice.STATE["cortex_confirm"] = None
        self.voice._WA_PENDING.clear()
        # Fresh real stores per test.
        self.explicit.clear()
        for row in self.learned.all_memories():
            self.learned.forget(key=row.get("key") or "")

    def _say(self, text):
        self.spoken.clear()
        handled = self.voice.run_command(text, None, None, "typed")
        return handled, " | ".join(self.spoken)

    def _assert_no_fallthrough(self, said):
        self.assertNotIn("BRAIN_FALLTHROUGH", said,
                         "memory request fell through to the LLM")
        low = said.lower()
        self.assertNotIn("permanently", low,
                         "memory request came back as the power-action deny")
        self.assertNotIn("blocked on purpose", low,
                         "memory request came back as the bridge power deny")

    # ── the exact failing phrase ──────────────────────────────────────────
    def test_exact_failing_phrase_reaches_memory_not_power(self):
        handled, said = self._say(FAILING_PHRASE)
        self.assertTrue(handled, "phrase was not routed at all")
        self._assert_no_fallthrough(said)
        # REAL write: read the record back out of ChromaDB.
        rows = self.explicit.all_memories()
        self.assertTrue(rows, "no record was actually written")
        self.assertTrue(
            any("chunk by chunk" in str(r.get("text", "")).lower()
                for r in rows),
            "stored rows do not contain the requested content: %r"
            % [r.get("text") for r in rows])

    # ── save / retrieve ───────────────────────────────────────────────────
    def test_remember_then_retrieve_roundtrip(self):
        handled, said = self._say("remember my favourite car is a black Thar")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertTrue(any("Thar" in str(r.get("text"))
                            for r in self.explicit.all_memories()),
                        "remember() did not persist the record")
        handled, said = self._say("what do you remember about me?")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("Thar", said, "retrieve did not read the record back")
        # "explain ..." phrasing routes to the same list.
        handled, said = self._say("explain what you remember about me")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("Thar", said, "explain/list phrasing did not route")

    def test_power_guard_carves_out_memory_but_still_blocks_power(self):
        # The reported regression: memory requests must never be treated as
        # laptop/system actions...
        for phrase in (FAILING_PHRASE, "remember this", "delete this memory",
                       "what do you remember about me?",
                       "update this memory",
                       "remember to shutdown laptop tomorrow"):
            self.assertFalse(self.voice.power_guard(phrase)[0],
                             "memory request was power-blocked: %r" % phrase)
        # ...while genuine power commands keep their protection, untouched.
        for phrase in ("shutdown laptop", "restart my pc", "laptop band karo",
                       "put my laptop to sleep", "log off"):
            self.assertTrue(self.voice.power_guard(phrase)[0],
                            "power command no longer blocked: %r" % phrase)

    def test_save_this_extracts_splits_dedupes_long_message(self):
        # A large previous message -> referential save -> selective
        # extraction into separate keyed records, duplicates superseded.
        big = ("Meeting notes: my name is Prateek. I prefer concise Hinglish "
               "replies. I live in Pune. ") * 8
        self.voice._remember_turn(big, "")
        handled, said = self._say("save this in your memory")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("save ki", said, "no honest record count reported")
        texts = [str(m.get("text")) for m in self.learned.all_memories()]
        self.assertTrue(any("Prateek" in t for t in texts),
                        "name fact was not extracted: %r" % texts)
        self.assertTrue(any("Pune" in t for t in texts),
                        "location fact was not extracted: %r" % texts)
        # Dedup: 8 repeats of the same fact must yield ONE record, not eight.
        names = [m for m in self.learned.all_memories()
                 if m.get("key") == "user.name"]
        self.assertEqual(len(names), 1, "dedup failed: %r" % names)

    def test_save_without_content_asks_honestly(self):
        handled, said = self._say("save this")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("save karna kya hai", said)
        self.assertFalse(self.explicit.all_memories(),
                         "a record was written without content")

    # ── update ────────────────────────────────────────────────────────────
    def test_update_supersedes_old_value(self):
        self.assertTrue(self.learned.remember(
            "user.city", "User's city is Pune.", source="test")["ok"])
        handled, said = self._say("update memory: my city is Delhi")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("update ho gayi", said)
        cities = [m["text"] for m in self.learned.all_memories()
                  if m.get("key") == "user.city"]
        self.assertEqual(cities, ["User's city is Delhi."],
                         "old value was not superseded: %r" % cities)

    # ── delete ────────────────────────────────────────────────────────────
    def test_delete_removes_real_record(self):
        self._say("remember my favourite car is a black Thar")
        self.assertTrue(self.explicit.all_memories())
        handled, said = self._say("forget black Thar")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertIn("delete ho gayi", said)
        self.assertFalse(
            [r for r in self.explicit.all_memories()
             if "Thar" in str(r.get("text"))],
            "record still present after delete")

    def test_referential_delete_with_single_candidate_deletes_it(self):
        self._say("remember my favourite car is a black Thar")
        handled, said = self._say("delete this memory")
        self.assertTrue(handled)
        self._assert_no_fallthrough(said)
        self.assertFalse(self.explicit.all_memories(),
                         "referential delete did not remove the record")


if __name__ == "__main__":
    unittest.main(verbosity=2)