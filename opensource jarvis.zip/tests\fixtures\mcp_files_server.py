"""Read-only MCP fixture: workspace reader sandboxed to the JARVIS repository.

Real newline-delimited JSON-RPC 2.0 over stdio. Two tools:
  * list_files(path, limit) - repo-relative paths (never outside the repo)
  * read_file(path, max_lines) - first lines of a text file inside the repo

No writes, no network, no shell: this is a safe connector to demo and test MCP.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TOOLS = [
    {
        "name": "list_files",
        "description": "List files inside the JARVIS repository (read-only).",
        "inputSchema": {"type": "object",
                        "properties": {"path": {"type": "string"}, "limit": {"type": "number"}}},
    },
    {
        "name": "read_file",
        "description": "Return the first lines of a text file inside the repository.",
        "inputSchema": {"type": "object",
                        "properties": {"path": {"type": "string"}, "max_lines": {"type": "number"}},
                        "required": ["path"]},
    },
]


def _inside(raw):
    """Repo-rooted path or None when the request tries to escape the sandbox."""
    candidate = (ROOT / str(raw or ".")).resolve()
    try:
        candidate.relative_to(ROOT)
    except ValueError:
        return None
    return candidate


def _reply(request_id, result):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result}) + "\n")
    sys.stdout.flush()


def _text(request_id, message, is_error=False):
    _reply(request_id, {"content": [{"type": "text", "text": message}], "isError": is_error})


def handle_tool_call(request_id, params):
    arguments = params.get("arguments") or {}
    tool = params.get("name")
    if tool == "list_files":
        target = _inside(arguments.get("path") or ".")
        if target is None or not target.exists():
            return _text(request_id, "path is outside the repository sandbox", True)
        limit = max(1, min(int(arguments.get("limit") or 50), 200))
        rows = []
        for path in sorted(target.rglob("*")):
            if path.is_file() and ".git" not in path.parts and "node_modules" not in path.parts:
                rows.append(str(path.relative_to(ROOT)).replace("\\", "/"))
            if len(rows) >= limit:
                break
        return _text(request_id, "\n".join(rows) or "(no files)")
    if tool == "read_file":
        target = _inside(arguments.get("path"))
        if target is None or not target.is_file():
            return _text(request_id, "file is outside the repository sandbox", True)
        limit = max(1, min(int(arguments.get("max_lines") or 40), 200))
        try:
            lines = target.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception as exc:
            return _text(request_id, "read failed: %s" % type(exc).__name__, True)
        return _text(request_id, "\n".join(lines[:limit]))
    return _text(request_id, "unknown tool: %s" % tool, True)


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except Exception:
            continue
        method, request_id = message.get("method"), message.get("id")
        if method == "initialize":
            _reply(request_id, {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}},
                                "serverInfo": {"name": "jarvis-files", "version": "1.0.0"}})
        elif method == "tools/list":
            _reply(request_id, {"tools": TOOLS})
        elif method == "tools/call":
            handle_tool_call(request_id, message.get("params") or {})
        elif request_id is not None:
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": request_id,
                                         "error": {"code": -32601,
                                                   "message": "method not found: %s" % method}}) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
