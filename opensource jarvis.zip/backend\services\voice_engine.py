"""
[VOICE STACK REMOVED]
=====================
The voice-assistant code that lived in this file (STT / TTS / wake-word /
microphone loops / assistant brain / memory) was intentionally deleted so the
voice stack can be rewritten from scratch with a different approach.

Deliberately untouched:
  * Podcast pipeline  : background/podcast_engine.py, background/kokoro_podcast.py
  * Server API        : src/index.tsx  (/api/tts /api/stt /api/vision stay as-is)
  * Dashboard UI      : public/static/*
  * Windows bridge    : local-bridge/server.cjs
  * Floating HUD shell: background/floating_ui.pyw
"""
