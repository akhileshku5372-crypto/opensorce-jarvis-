import pathlib, re
p=pathlib.Path("public/static/brain-holo.js")
s=p.read_text(encoding="utf-8")
old="  window.__JARVIS_BRAIN_HOLO__={init:initIfNeeded,setBrain,setAuto,reset,setExploded,isReady:()=>initialized,get activeLobe(){return activeLobe},get activeColor(){return activeColor},get hoverId(){return hoveredNode?hoveredNode.id:null},get pinnedId(){return selectedSubsystemId},set pinnedId(v){selectedSubsystemId=v;},CAPS,LOBE_TO_CAP,LOBE_COLOR,SUBSYSTEMS,_onSelect:null};"
new="  window.__JARVIS_BRAIN_HOLO__={init:initIfNeeded,setBrain,setAuto,reset,setExploded,isReady:()=>initialized, get initialized(){return initialized;}, get hasRenderer(){return !!renderer;}, status:()=>({initialized, hasRenderer:!!renderer, hasScene:!!scene, hasThree:!!getThree(), wrap:!!wrap, container:!!container, threeRev:(getThree()&&getThree().REVISION)||'?' }), get activeLobe(){return activeLobe},get activeColor(){return activeColor},get hoverId(){return hoveredNode?hoveredNode.id:null},get pinnedId(){return selectedSubsystemId},set pinnedId(v){selectedSubsystemId=v;},CAPS,LOBE_TO_CAP,LOBE_COLOR,SUBSYSTEMS,_onSelect:null};"
if old in s:
    s=s.replace(old,new)
    print("p3 export patched")
else:
    print("p3 miss")
    print(s.count("__JARVIS_BRAIN_HOLO__"))
p.write_text(s,encoding="utf-8")
import pathlib as pl
dp=pl.Path("dist/static/brain-holo.js")
if dp.parent.exists(): dp.write_text(s,encoding="utf-8")
print("len",len(s))
