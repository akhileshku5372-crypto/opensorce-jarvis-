"""Semantic UI Automation for JARVIS gesture control.

The peace-sign gesture asks this module to activate the accessible control under
the Windows cursor. That is deliberately NOT a blind mouse click:

  * the control is resolved through the UI Automation tree of the top-level
    window under the point;
  * password fields, confirmation dialogs and destructive labels are refused;
  * only control types with a safe, reversible pattern are activated
    (invoke / select / toggle / expand / range-value);
  * a slider is set from the ratio of the pointed position inside its own
    rectangle, so the value comes from where the user pointed instead of a
    guessed midpoint;
  * every failure is reported as a failure with a reason.

Three operations exist, and no command string is ever accepted:

    python background/ui_surface.py --json --op status
    python background/ui_surface.py --json --op snapshot
    python background/ui_surface.py --json --op activate --x 640 --y 400

Window control (Phase 2) adds two more, still handle-based, never by command:

    python background/ui_surface.py --json --op windows
    python background/ui_surface.py --json --op window --action minimize --handle 1234
    python background/ui_surface.py --json --op window --action move --handle 1234 --x 100 --y 100 --width 800 --height 600

`move` is the only geometry-writing action; there is deliberately no `close`,
`terminate` or `set_text` operation, so a gesture can never end a program or
type into one.

The module is imported by tests for its pure helpers; importing it has no
side effects and does not require pywinauto to be installed.
"""
from __future__ import annotations

import argparse
import json
import re
import sys

MAX_CONTROLS = 60
MAX_WINDOWS = 30
MAX_NAME = 120

# Same guard as public/static/gesture-control.js: a gesture alone must never
# confirm, send, pay, delete, restart or sign out.
SENSITIVE_WORDS = re.compile(
    r"\b(?:delete|remove|uninstall|erase|format|purchase|buy|checkout|pay|transfer|"
    r"send|submit|confirm|approve|allow|grant|admin|password|shutdown|shut down|"
    r"restart|reboot|clear|wipe|lock|sleep|hibernate|sign out|log out|log off|"
    r"turn off|power off|factory reset|reset all)\b",
    re.IGNORECASE,
)
SENSITIVE_UNICODE = re.compile(
    r"(?:हटाएं|हटाओ|मिटाएं|डिलीट|भेजें|भेजो|खरीदें|भुगतान|रीस्टार्ट|बंद करें|"
    r"削除|送信|購入|支払|再起動|ログアウト)"
)

INVOKE_TYPES = {"Button", "MenuItem", "SplitButton", "Hyperlink"}
SELECT_TYPES = {"TabItem", "ListItem", "TreeItem", "RadioButton", "DataItem"}
TOGGLE_TYPES = {"CheckBox"}
RANGE_TYPES = {"Slider", "Spinner"}
EXPAND_TYPES = {"ComboBox"}

INTERACTIVE_TYPES = INVOKE_TYPES | SELECT_TYPES | TOGGLE_TYPES | RANGE_TYPES | EXPAND_TYPES


def is_sensitive(name) -> bool:
    """True when a gesture must not activate a control with this label."""
    value = str(name or "").strip()
    if not value:
        return False
    return bool(SENSITIVE_WORDS.search(value) or SENSITIVE_UNICODE.search(value))


def bounded_name(value, limit=MAX_NAME) -> str:
    """Collapse whitespace and cap the label so JSON output stays bounded."""
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) > limit:
        text = text[: max(0, limit - 3)].rstrip() + "..."
    return text


def blocked_reason(name, control_type, is_password=False) -> str:
    """The exact reason an activation is refused, or '' when it is allowed."""
    if is_password:
        return "password field"
    if is_sensitive(name):
        return "destructive or confirmation label"
    kind = str(control_type or "")
    if not kind:
        return "unknown control type"
    if kind not in INTERACTIVE_TYPES:
        return "%s does not expose a safe gesture activation" % kind
    return ""


def control_action(control_type) -> str:
    """The UIA pattern used for a control type, or '' when unsupported."""
    kind = str(control_type or "")
    if kind in INVOKE_TYPES:
        return "invoke"
    if kind in SELECT_TYPES:
        return "select"
    if kind in TOGGLE_TYPES:
        return "toggle"
    if kind in RANGE_TYPES:
        return "range_value"
    if kind in EXPAND_TYPES:
        return "expand"
    return ""


def is_password_info(info) -> bool:
    """Read UIA's IsPassword flag without touching the field's value."""
    try:
        return bool(info._element.CurrentIsPassword)
    except Exception:
        return False


def geometry(info):
    """(left, top, width, height) for a UIA element, or None."""
    try:
        rect = info.rectangle
        left = int(rect.left)
        top = int(rect.top)
        right = int(rect.right)
        bottom = int(rect.bottom)
    except Exception:
        return None
    width = right - left
    height = bottom - top
    if width <= 0 or height <= 0:
        return None
    return (left, top, width, height)


def contains(box, x, y) -> bool:
    if not box:
        return False
    left, top, width, height = box
    return left <= x <= left + width and top <= y <= top + height


def area(box) -> int:
    return int(box[2]) * int(box[3]) if box else 0


def choose_control(candidates, x, y):
    """Smallest ACTIVATABLE control containing the point.

    ``candidates`` is a list of dicts with ``box`` and ``activatable`` keys.
    A text label painted inside a button must not win over the button itself,
    so non-activatable descendants are skipped.
    """
    best = None
    for item in candidates or []:
        if not item.get("activatable"):
            continue
        if not contains(item.get("box"), x, y):
            continue
        if best is None or area(item["box"]) < area(best["box"]):
            best = item
    return best


def range_value(box, minimum, maximum, x):
    """Map the pointed x position across a slider to its real range."""
    left, _, width, _ = box
    span = max(1, int(width))
    ratio = min(1.0, max(0.0, (float(x) - left) / span))
    low = float(minimum)
    high = float(maximum)
    if high < low:
        low, high = high, low
    return low + (high - low) * ratio


def _foreground_hwnd() -> int:
    try:
        import ctypes
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def _root_hwnd_at(x, y) -> int:
    """Top-level window under a screen point (popups stay their own root)."""
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        hwnd = user32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
        if not hwnd:
            return 0
        root = user32.GetAncestor(hwnd, 2)  # GA_ROOT
        return int(root or hwnd)
    except Exception:
        return 0


def _window_title(hwnd) -> str:
    try:
        import ctypes
        user32 = ctypes.windll.user32
        length = user32.GetWindowTextLengthW(hwnd)
        buffer = ctypes.create_unicode_buffer(length + 2)
        user32.GetWindowTextW(hwnd, buffer, length + 2)
        return bounded_name(buffer.value)
    except Exception:
        return ""


def _desktop():
    from pywinauto import Desktop
    return Desktop(backend="uia")


def _control_row(element, info, x=None, y=None):
    control_type = str(getattr(info, "control_type", "") or "")
    name = bounded_name(getattr(info, "name", ""))
    password = control_type == "Edit" and is_password_info(info)
    box = geometry(info)
    reason = blocked_reason(name, control_type, password)
    return {
        "element": element,
        "name": name,
        "control_type": control_type,
        "enabled": bool(getattr(info, "is_enabled", True)),
        "password": password,
        "sensitive": is_sensitive(name),
        "box": box,
        "activatable": not reason,
        "reason": reason,
        "action": control_action(control_type),
    }


def status() -> dict:
    """Whether the UIA stack can actually run here, with the honest reason."""
    if sys.platform != "win32":
        return {"ok": True, "available": False, "reason": "UI Automation works on Windows only"}
    try:
        version = __import__("pywinauto", fromlist=["__version__"]).__version__
        _desktop()
    except Exception as exc:
        return {"ok": True, "available": False, "reason": "pywinauto/UIA unavailable (%s)" % type(exc).__name__}
    return {"ok": True, "available": True, "reason": "UI Automation ready (pywinauto %s)" % version}


def _open_window(hwnd):
    if not hwnd:
        raise RuntimeError("no foreground window")
    desktop = _desktop()
    return desktop.window(handle=hwnd)


WINDOW_ACTIONS = {"focus", "minimize", "maximize", "restore", "move"}


def _screen_rect():
    """The virtual screen, in the same pixel space as the window rectangles.

    This matters on any scaled display (125% here): the bridge's pointer space is
    virtualised (a DPI-unaware PowerShell reports 1536x864 for a 1920x1080
    desktop), while UIA's BoundingRectangle is physical. Resolving a 0..1
    fraction HERE keeps pixels from crossing that boundary: an absolute
    dashboard rectangle used to move windows 25% too small and too far left.
    """
    try:
        import ctypes
        user32 = ctypes.windll.user32
        left = int(user32.GetSystemMetrics(76))    # SM_XVIRTUALSCREEN
        top = int(user32.GetSystemMetrics(77))     # SM_YVIRTUALSCREEN
        width = int(user32.GetSystemMetrics(78))   # SM_CXVIRTUALSCREEN
        height = int(user32.GetSystemMetrics(79))  # SM_CYVIRTUALSCREEN
        if width > 0 and height > 0:
            return (left, top, width, height)
    except Exception:
        pass
    return None


def fractional_rect(fractions):
    """Resolve (x, y, width, height) 0..1 fractions into screen pixels."""
    values = [float(value) for value in fractions]
    if not all(0.0 <= value <= 1.0 for value in values):
        return None, "fractional coordinates must be between 0 and 1"
    if values[2] < 0.05 or values[3] < 0.05:
        return None, "that fraction of the screen is too small to be usable"
    screen = _screen_rect()
    if not screen:
        return None, "the screen rectangle is unavailable"
    left, top, width, height = screen
    wide = min(width, int(round(values[2] * width)))
    tall = min(height, int(round(values[3] * height)))
    x = left + int(round(values[0] * width))
    y = top + int(round(values[1] * height))
    return (max(left, min(x, left + width - wide)), max(top, min(y, top + height - tall)), wide, tall), None


def _try(fn, fallback):
    try:
        return fn()
    except Exception:
        return fallback


def move_window(handle, left, top, width, height):
    """Move and resize a top-level window with the Win32 API.

    pywinauto 0.6.9's UIA wrapper has no move_window(), so the previous
    `spec.move_window(...)` raised AttributeError and every window move failed
    while minimize/maximize/focus worked. UIA has no move pattern at all: the
    honest way to move a window is SetWindowPos on its handle. Coordinates are
    in this process's pixel space, the same one UIA reports rectangles in.
    """
    try:
        import ctypes
        SWP_NOZORDER = 0x0004
        SWP_NOACTIVATE = 0x0010
        moved = ctypes.windll.user32.SetWindowPos(
            int(handle), 0, int(left), int(top), int(width), int(height), SWP_NOZORDER | SWP_NOACTIVATE
        )
        if not moved:
            return "the window manager refused the move"
        return None
    except Exception as exc:
        return "the window could not be moved (%s)" % type(exc).__name__


def window_state(spec) -> dict:
    """Minimised / maximised / rectangle for a window specification."""
    state = {"minimized": False, "maximized": False, "box": None}
    try:
        state["minimized"] = bool(spec.is_minimized())
    except Exception:
        pass
    try:
        state["maximized"] = bool(spec.is_maximized())
    except Exception:
        pass
    try:
        rect = spec.rectangle()
        state["box"] = (int(rect.left), int(rect.top), int(rect.right - rect.left), int(rect.bottom - rect.top))
    except Exception:
        pass
    return state


def windows() -> dict:
    """Top-level windows in z-order, so the dashboard can name the real target.

    A window with no title, or one the accessibility layer refuses to open, is
    skipped rather than guessed at.
    """
    try:
        desktop = _desktop()
        specs = desktop.windows()
    except Exception as exc:
        return {"ok": False, "error": "could not enumerate windows (%s)" % type(exc).__name__}
    rows = []
    for spec in specs:
        try:
            handle = int(spec.handle)
        except Exception:
            continue
        try:
            title = bounded_name(spec.window_text())
        except Exception:
            title = ""
        if not title:
            continue
        state = window_state(spec)
        rows.append({
            "handle": handle,
            "title": title,
            "minimized": state["minimized"],
            "maximized": state["maximized"],
            "box": list(state["box"]) if state["box"] else None,
        })
        if len(rows) >= MAX_WINDOWS:
            break
    return {"ok": True, "windows": rows, "count": len(rows), "screen": list(_screen_rect() or [])}


def window(action, handle, x=None, y=None, width=None, height=None, rect=None, fraction=False) -> dict:
    """Minimise / maximise / restore / focus / move one window by handle.

    With fraction=True the move rectangle is (x, y, width, height) as 0..1 of the
    desktop and is resolved in this process's pixel space; otherwise absolute
    pixels are used as given.
    """
    action = str(action or "").strip().lower()
    if action not in WINDOW_ACTIONS:
        return {"ok": False, "error": "unsupported window action"}
    try:
        handle = int(handle)
    except Exception:
        return {"ok": False, "error": "the window handle is not a number"}
    if handle <= 0:
        return {"ok": False, "error": "a positive window handle is required"}
    try:
        spec = _desktop().window(handle=handle)
    except Exception as exc:
        return {"ok": False, "error": "that window is not accessible (%s)" % type(exc).__name__}
    title = bounded_name(_try(lambda: spec.window_text(), "") or _window_title(handle))
    try:
        if action in ("minimize", "maximize", "restore", "focus"):
            getattr(spec, action if action != "focus" else "set_focus")()
        else:
            if fraction:
                if not all(value is not None for value in (x, y, width, height)):
                    return {"ok": False, "error": "move needs x, y, width and height", "window": {"title": title, "handle": handle}}
                resolved, reason = fractional_rect((x, y, width, height))
                if resolved is None:
                    return {"ok": False, "error": reason, "window": {"title": title, "handle": handle}}
                left, top, wide, tall = resolved
            else:
                if rect is None:
                    rect = (x, y, width, height)
                if not all(value is not None for value in rect):
                    return {"ok": False, "error": "move needs x, y, width and height", "window": {"title": title, "handle": handle}}
                left, top, wide, tall = (int(value) for value in rect)
                if wide < 200 or tall < 120:
                    return {"ok": False, "error": "that window size is too small to be usable", "window": {"title": title, "handle": handle}}
            # A maximised or minimised window cannot be positioned: restore it
            # first, otherwise the move silently applies to the restored frame.
            if _try(lambda: spec.is_maximized() or spec.is_minimized(), False):
                spec.restore()
            reason = move_window(handle, left, top, wide, tall)
            if reason:
                return {"ok": False, "action": action, "error": reason, "window": {"title": title, "handle": handle}}
    except Exception as exc:
        return {
            "ok": False,
            "action": action,
            "error": "%s failed (%s)" % (action, type(exc).__name__),
            "window": {"title": title, "handle": handle},
        }
    state = window_state(spec)
    return {
        "ok": True,
        "action": action,
        "window": {
            "title": title,
            "handle": handle,
            "minimized": state["minimized"],
            "maximized": state["maximized"],
            "box": list(state["box"]) if state["box"] else None,
        },
    }


def snapshot() -> dict:
    """Accessible, non-password controls of the foreground window."""
    hwnd = _foreground_hwnd()
    try:
        window = _open_window(hwnd)
    except Exception as exc:
        return {"ok": False, "error": "the foreground window is not accessible (%s)" % type(exc).__name__, "available": status()["available"]}
    title = bounded_name(window.window_text()) or _window_title(hwnd)
    rows = []
    seen = 0
    try:
        descendants = window.descendants()
    except Exception as exc:
        return {"ok": False, "error": "could not walk the accessibility tree (%s)" % type(exc).__name__, "window": {"title": title, "handle": int(hwnd)}}
    for element in descendants:
        try:
            info = element.element_info
        except Exception:
            continue
        row = _control_row(element, info)
        if row["password"]:
            continue
        if not row["name"] and row["control_type"] != "Edit":
            continue
        seen += 1
        if len(rows) >= MAX_CONTROLS:
            continue
        rows.append({
            "name": row["name"] or "(unnamed)",
            "control_type": row["control_type"],
            "enabled": row["enabled"],
            "sensitive": row["sensitive"],
            "activatable": row["activatable"],
            "reason": row["reason"],
        })
    rows.sort(key=lambda item: (item["control_type"], item["name"]))
    return {
        "ok": True,
        "window": {"title": title, "handle": int(hwnd)},
        "controls": rows,
        "count": seen,
    }


def activate(x, y) -> dict:
    """Activate the accessible control at a screen point, or say why not."""
    try:
        x = int(x)
        y = int(y)
    except Exception:
        return {"ok": False, "error": "screen coordinates are not numbers"}
    if not (0 <= x <= 100000 and 0 <= y <= 100000):
        return {"ok": False, "error": "screen coordinates are out of range"}
    hwnd = _root_hwnd_at(x, y) or _foreground_hwnd()
    try:
        window = _open_window(hwnd)
    except Exception as exc:
        return {"ok": False, "error": "the window under the pointer is not accessible (%s)" % type(exc).__name__}
    title = bounded_name(window.window_text()) or _window_title(hwnd)
    candidates = []
    try:
        descendants = window.descendants()
    except Exception as exc:
        return {"ok": False, "error": "could not walk the accessibility tree (%s)" % type(exc).__name__}
    for element in descendants:
        try:
            info = element.element_info
        except Exception:
            continue
        row = _control_row(element, info, x, y)
        if row["password"]:
            # Only the field under the pointer blocks this activation; another
            # form's password box elsewhere in the window must not.
            if row["box"] and contains(row["box"], x, y):
                return {
                    "ok": False, "sensitive": True, "name": row["name"] or "(password field)",
                    "control_type": row["control_type"], "error": "password fields are refused",
                    "window": {"title": title, "handle": int(hwnd)},
                }
            continue
        if row["box"]:
            candidates.append(row)
    chosen = choose_control(candidates, x, y)
    if not chosen:
        return {
            "ok": False, "error": "no activatable accessible control at that point",
            "window": {"title": title, "handle": int(hwnd)},
        }
    if not chosen["enabled"]:
        return {
            "ok": False, "name": chosen["name"], "control_type": chosen["control_type"],
            "error": "the control is disabled", "window": {"title": title, "handle": int(hwnd)},
        }
    if chosen["sensitive"]:
        return {
            "ok": False, "sensitive": True, "name": chosen["name"],
            "control_type": chosen["control_type"],
            "error": "destructive or confirmation controls are refused",
            "window": {"title": title, "handle": int(hwnd)},
        }
    if not chosen["activatable"]:
        return {
            "ok": False, "name": chosen["name"], "control_type": chosen["control_type"],
            "error": chosen["reason"], "window": {"title": title, "handle": int(hwnd)},
        }
    element = chosen["element"]
    action = chosen["action"]
    try:
        if action == "invoke":
            element.invoke()
        elif action == "select":
            element.select()
        elif action == "toggle":
            element.iface_toggle.Toggle()
        elif action == "expand":
            element.iface_expand_collapse.Expand()
        elif action == "range_value":
            pattern = element.iface_range_value
            value = range_value(chosen["box"], pattern.CurrentMinimum, pattern.CurrentMaximum, x)
            pattern.SetValue(value)
        else:
            return {
                "ok": False, "name": chosen["name"], "control_type": chosen["control_type"],
                "error": "no safe activation pattern", "window": {"title": title, "handle": int(hwnd)},
            }
    except Exception as exc:
        return {
            "ok": False, "name": chosen["name"], "control_type": chosen["control_type"],
            "error": "%s failed (%s)" % (action, type(exc).__name__),
            "window": {"title": title, "handle": int(hwnd)},
        }
    return {
        "ok": True,
        "name": chosen["name"] or "(unnamed)",
        "control_type": chosen["control_type"],
        "action": action,
        "window": {"title": title, "handle": int(hwnd)},
    }


def _force_utf8_stdout() -> None:
    """Windows consoles and pipes default to the ANSI code page.

    Without this, any window title or control name outside cp1252 (a browser
    with an emoji in the tab title is enough) made json.dumps raise
    UnicodeEncodeError while writing: the bridge received no JSON at all and
    every semantic activation failed with a traceback instead of a reason.
    """
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def main(argv=None) -> int:
    _force_utf8_stdout()
    parser = argparse.ArgumentParser(description="JARVIS semantic UI Automation (read-only + allowlisted activation)")
    parser.add_argument("--json", action="store_true", help="kept for the bridge; output is always JSON")
    parser.add_argument("--op", choices=("status", "snapshot", "activate", "windows", "window"), required=True)
    parser.add_argument("--x", type=float, default=None)
    parser.add_argument("--y", type=float, default=None)
    parser.add_argument("--width", type=float, default=None)
    parser.add_argument("--height", type=float, default=None)
    parser.add_argument("--handle", type=int, default=0)
    parser.add_argument("--action", default="")
    parser.add_argument("--fraction", action="store_true", help="treat x/y/width/height as 0..1 of the desktop")
    args = parser.parse_args(argv)
    if args.op == "status":
        result = status()
    elif args.op == "snapshot":
        result = snapshot()
    elif args.op == "windows":
        result = windows()
    elif args.op == "window":
        result = window(args.action, args.handle, args.x, args.y, args.width, args.height, fraction=args.fraction)
    else:
        result = activate(int(args.x or 0), int(args.y or 0))
    sys.stdout.write(json.dumps(result, ensure_ascii=False) + "\n")
    sys.stdout.flush()
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
