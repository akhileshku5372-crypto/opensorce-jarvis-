module.exports = {
  apps: [
    {
      name: 'jarvis-ui',
      script: 'node_modules/vite/bin/vite.js',
      args: '--host 127.0.0.1 --port 7777 --strictPort',
      env: { NODE_ENV: 'development', PORT: 7777 },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      name: 'jarvis-windows-bridge',
      script: 'local-bridge/server.cjs',
      env: { NODE_ENV: 'development', JARVIS_BRIDGE_PORT: 7778 },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      name: 'jarvis-edge-tts',
      script: 'run_py.cjs',
      args: 'background/edge_tts_http.py',
      env: { EDGE_TTS_PORT: 7782 },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      name: 'jarvis-podcast',
      script: 'run_py.cjs',
      args: 'background/podcast_engine.py',
      env: { PODCAST_PORT: 7781 },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      name: 'jarvis-voice',
      script: 'run_py.cjs',
      args: 'background/voice_engine.py',
      env: { JARVIS_STATE_PORT: 7780 },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      // Phase 1 item 1.4: the production HUD was a manual `pythonw
      // background/floating_ui.pyw` launch, so after a reboot the Modules card
      // honestly reported "on disk but not running" and the Ctrl+Shift+J hub
      // was dead. Supervised like every other service now.
      name: 'jarvis-hud',
      script: 'run_py.cjs',
      args: 'background/floating_ui.pyw',
      env: { JARVIS_HUD_SUPERVISED: '1' },
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    },
    {
      // Real n8n (v2.41.6, installed globally via `npm i -g n8n`). It is a
      // separate Node application, NOT a JARVIS module: it owns its own
      // database, its own workflow engine and its own Vue UI. JARVIS only
      // surfaces it inside the Agents panel through an <iframe> pointed at
      // this loopback port, so nothing about n8n is reimplemented here.
      //
      // Loopback only (N8N_HOST=127.0.0.1) to match the repo's security rule:
      // no unauthenticated workflow engine exposed on the LAN.
      // `script: 'n8n'` does NOT work on Windows: npm creates a `n8n.cmd`
      // batch shim, and PM2 hands that shim to Node, which then dies with
      // "SyntaxError: Invalid or unexpected token" on the `@ECHO off` line.
      // Pointing at the real Node entry inside the global package fixes it.
      name: 'jarvis-n8n',
      script: 'C:/Users/PRATEEK/AppData/Roaming/npm/node_modules/n8n/bin/n8n',
      args: 'start',
      interpreter: 'node',
      env: {
        N8N_HOST: '127.0.0.1',
        N8N_PORT: '5678',
        N8N_PROTOCOL: 'http',
        N8N_USER_FOLDER: __dirname,
        N8N_DIAGNOSTICS_ENABLED: 'false',
        N8N_VERSION_NOTIFICATIONS_ENABLED: 'false',
        N8N_TEMPLATES_ENABLED: 'false',
        N8N_HIRING_BANNER_ENABLED: 'false',
        N8N_PERSONALIZATION_ENABLED: 'false',
        EXECUTIONS_DATA_PRUNE: 'true',
        EXECUTIONS_DATA_MAX_AGE: '336',
        N8N_ENFORCE_SETTINGS_FILE_PERMISSIONS: 'true'
      },
      cwd: __dirname,
      watch: false,
      instances: 1,
      exec_mode: 'fork'
    }
    // TTS is MS Edge neural voices everywhere: edge_tts_http.py serves the
    // browser/HUD (7782), podcast_engine.py renders KamiSensei episodes (7781),
    // voice_engine.py speaks the live conversation. The retired Kokoro-82M
    // offline engine is no longer part of this stack.
  ].map(app => ({ ...app, cwd: __dirname, min_uptime: '5s', max_restarts: 10, restart_delay: 2000 }))
}
