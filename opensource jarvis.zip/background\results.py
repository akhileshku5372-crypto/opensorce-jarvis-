"""Result ledger (Phase 2 of self-learning) - JARVIS knows its own scorecard.

The honest mechanics: when Sir asks for something and it fails, JARVIS must
never claim "nahi kar pa raha" out of a habit or a fear - the claim must come
from REAL measured outcomes of the actual tools on THIS machine. This module
keeps a bounded on-device ledger under artifacts/brain/results.json:

  * one entry per executed tool: {tool, ok, denied, ms, why, at};
  * per-tool rolling stats (last 30 runs) + lifetime ok/fail counters;
  * a prompt clause the brain sees on every turn, so "can I do X" is answered
    from evidence - a tool that failed its last 3 runs is reported as not
    working NOW, and one with a clean streak is not unjustly apologized for;
  * a readoff() audit trail.

Recording is best-effort and additive: if this module is missing, unreadable
or the disk refuses, tool execution is unaffected - an observability failure
must never turn into a functional one.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# A test run must never touch the owner's live store: JARVIS_RESULTS_STORE
# redirects the file for that process (roped in by the test suites).
STORE = Path(os.environ.get(
    "JARVIS_RESULTS_STORE",
    str(ROOT / "artifacts" / "brain" / "results.json")))
MAX_EVENTS = 400
WINDOW = 30          # per-tool rolling window used for the live verdict
MAX_SCORES = 60      # tools kept in the rollup

_LOCK = threading.RLock()

_CURRENT_TASK = [""]          # the phrase recorded before the action ran


def saw_task(text):
    """Run-command registers the user's phrase; actions land against it."""
    _CURRENT_TASK[0] = str(text or "").strip()[:160]


def current_task():
    return _CURRENT_TASK[0]


def _load():
    try:
        if STORE.is_file():
            return json.loads(STORE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STORE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STORE)


def record(name, ok, why="", ms=0.0, denied=False, task=""):
    """One executed action. Returns (ok, tool_total). Never raises."""
    tool = str(name or "").strip()[:80]
    if not tool:
        return (False, 0)
    routine_task = str(task or "").strip()[:160] or _CURRENT_TASK[0]
    with _LOCK:
        data = _load()
        events = data.get("events") or []
        events.append({"tool": tool, "ok": bool(ok), "denied": bool(denied),
                       "ms": round(float(ms or 0.0), 1),
                       "why": " ".join(str(why or "").split())[:160],
                       "at": time.strftime("%Y-%m-%d %H:%M:%S")})
        events = events[-MAX_EVENTS:]
        scores = data.get("scores") or {}
        s = scores.get(tool) or {"ok": 0, "fail": 0, "denied": 0, "last_at": ""}
        if denied:
            s["denied"] = int(s.get("denied") or 0) + 1
        elif ok:
            s["ok"] = int(s.get("ok") or 0) + 1
        else:
            s["fail"] = int(s.get("fail") or 0) + 1
        s["last_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        scores[tool] = s
        if len(scores) > MAX_SCORES:
            ordered = sorted(scores.items(), key=lambda kv: kv[1].get("last_at", ""))
            scores = dict(ordered[-MAX_SCORES:])
        data["events"] = events
        data["scores"] = scores
        data["updated_at"] = time.time()
        try:
            _save(data)
        except Exception:
            return (False, int(s.get("ok") or 0) + int(s.get("fail") or 0))
        # P3: a confirmed outcome is teaching material. Successes strengthen
        # the task's recipe; real failures matter too - three true loses retire
        # it. Observing must never break recording or the tool itself.
        if routine_task and not denied:
            try:
                import routines
                routines.observe(routine_task, tool, bool(ok))
            except Exception:
                pass
        return (True, int(s.get("ok") or 0) + int(s.get("fail") or 0))


def _series(tool):
    """The tool's last WINDOW events, oldest first."""
    ser = []
    for e in (data_events()):
        if str(e.get("tool")) == str(tool):
            ser.append(bool(e.get("ok")) and not bool(e.get("denied")))
    return ser[-WINDOW:]


def data_events():
    with _LOCK:
        data = _load()
    return data.get("events") or []


def stats(tool):
    """The LIVE verdict for one tool, from its rolling window.

    status is exactly one of working / broken / idle:
      working - the streak has real successes (and no failures after them);
      broken  - the tool ran but its recent window shows real failures;
      idle    - never recorded (unknown, and the brain may not claim either way).
    """
    ser = _series(tool)
    if not ser:
        return {"tool": tool, "status": "idle", "window": 0, "events": None,
                "why": "abhi koi record nahi hai"}
    events = _last_whys(tool, 2)
    if ser[-1]:
        clean = True
        for ok_prev in reversed(ser[:-1]):
            if ok_prev:
                break
            clean = False
            break
        return {"tool": tool,
                "status": "working" if clean else "flaky",
                "window": len(ser), "events": events,
                "why": ""}
    return {"tool": tool, "status": "broken", "window": len(ser),
            "events": events,
            "why": " or ".join(e for _, e in events if e) or ""}


def _last_whys(tool, k=2):
    out = []
    for e in reversed(data_events()):
        if str(e.get("tool")) == str(tool):
            out.append((bool(e.get("ok")), str(e.get("why") or "")))
            if len(out) >= k:
                break
    return out


def rollup(k=5):
    """Top tools by activity with their live verdicts (newest activity first)."""
    with _LOCK:
        data = _load()
        scores = data.get("scores") or {}
    ordered = sorted(scores.items(),
                     key=lambda kv: kv[1].get("last_at") or "",
                     reverse=True)
    out = []
    for tool, s in ordered[:max(1, int(k))]:
        total = int(s.get("ok") or 0) + int(s.get("fail") or 0)
        out.append({"tool": tool, "ok": int(s.get("ok") or 0),
                    "fail": int(s.get("fail") or 0),
                    "denied": int(s.get("denied") or 0), "total": total,
                    "status": stats(tool).get("status")})
    return out


def prompt_line(k=5):
    """"The honest capability clause for the system prompt ("" when idle)."""
    rows = rollup(k)
    rows = [r for r in rows if r["status"] != "idle"]
    if not rows:
        return ""
    parts = []
    for r in rows:
        if r["status"] == "broken":
            parts.append("%s FAILING (%d ok / %d fail)" % (r["tool"], r["ok"],
                                                           r["fail"]))
        elif r["status"] == "flaky":
            parts.append("%s flaky (%d ok / %d fail)" % (r["tool"], r["ok"],
                                                         r["fail"]))
        else:
            parts.append("%s working" % r["tool"])
    return (" TOOL RESULTS (this machine's real scorecard - when deciding "
            "whether JARVIS can do X, judge from these, never claim a "
            "capability it lacks; do not recite unless asked): %s." % "; ".join(parts))


def readoff(k=8):
    """The audit trail: per-tool lifetime counters + last outcome."""
    with _LOCK:
        data = _load()
        scores = data.get("scores") or {}
    ordered = sorted(scores.items(),
                     key=lambda kv: kv[1].get("last_at") or "", reverse=True)
    return {"tools": [{"tool": t, "ok": int(s.get("ok") or 0),
                       "fail": int(s.get("fail") or 0),
                       "denied": int(s.get("denied") or 0),
                       "status": stats(t).get("status")}
                      for t, s in ordered[:max(1, int(k))]],
            "path": str(STORE)}


def purge():
    """Test hook: forget everything."""
    with _LOCK:
        _save({"events": [], "scores": {}, "updated_at": time.time()})
