---
name: communication-psychology
description: Human communication, negotiation, assertive speaking, leadership, and psychological reasoning syllabus.
triggers: communication, psychology, soft skills, negotiation, assertiveness, leadership, public speaking, persuasion
---

# Communication & Applied Psychology Syllabus

This track provides practical frameworks for interpersonal communication, workplace negotiation, cognitive psychology, and leadership influence.

## Track 1: Assertive Communication & Active Listening
- **The SBI Model**: Situation, Behavior, Impact. Frame feedback factually without accusations.
- **Active Listening Protocol**: Paraphrasing, emotional validation, and non-interruptive acknowledgment.
- **De-escalation**: Lowering pitch and pacing during conflict; separating intent from impact.

## Track 2: Principled Negotiation (Harvard Negotiation Project)
- **Separate People from Problem**: Attack the structural dilemma, protect the relationship.
- **Focus on Interests, Not Positions**: Uncover the underlying "Why" beneath rigid demands.
- **Invent Options for Mutual Gain**: Brainstorm multi-variable trades (timeline vs scope vs cost).
- **Insist on Objective Criteria**: Benchmark against market rates, precedent, or verified metrics.
- **BATNA**: Always define your Best Alternative To a Negotiated Agreement before dialogue.

## Track 3: Cognitive Psychology & Cognitive Biases
- **Confirmation Bias & Anchoring**: Detecting initial reference point distortion in discussions.
- **Fundamental Attribution Error**: Distinguishing situational constraints from character traits.
- **Loss Aversion & Framing**: Presenting initiatives as risk-mitigation versus speculative gains.

## Track 4: Executive Presence & Rhetoric
- **The Minto Pyramid Principle**: State the governing recommendation first, followed by supporting pillars.
- **Ethos, Pathos, Logos**: Balancing credibility, emotional resonance, and rigorous logic.
- **Vocal Delivery**: Deliberate pausing, diaphragmatic breathing, and eliminating fillers.
