"""WhatsApp Web two-way controller (THIN DRIVER, no brain).

Unlike background/whatsapp_sender.py - which is ONE-WAY (opens a desktop
deep-link with a pre-filled message the user must Send) - this module READS
and WRITES WhatsApp Web through the SAME Playwright engine browser_agent
already uses, but with a PERSISTENT Chromium profile so the QR login survives
restarts. It is deliberately NOT built on brittle PyAutoGUI coordinate clicks.

Architecture (AGENTS.md compliance):
  * THIN DRIVER, not a second brain. No LLM call and no agent loop lives here.
    It executes one DOM primitive and returns data; every decision stays in the
    single Cortex planner behind the single confirm gate.
  * It reuses the existing Playwright install; it downloads no second browser
    and starts no second session manager.
  * "Loopback only" governs the LOCAL bridge/API endpoints. Browsing
    web.whatsapp.com is the same outbound HTTPS browser_agent already performs.
  * READ tools (status, unread, read) are ungated, like browser_agent's
    navigate/read. The SEND tool declares requires_confirmation=True so the
    existing cortex confirm gate AND the permission category both apply, and it
    RE-READS the DOM to confirm the message actually left. It never claims a
    send it did not verify - a silent/phantom send is the worst failure mode.

Honesty: WhatsApp Web changes its DOM often, so every selector lives in ONE
place (SELECTORS). When a selector stops matching, the tool fails HONESTLY
("selector se match nahi hua - WhatsApp ne DOM badla hoga") instead of faking
a result. There are no demo turns and no fabricated transcripts.
"""
from __future__ import annotations

import importlib.util
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# A browser profile, not memory data, so it lives under artifacts/ alongside
# artifacts/browser/ (screenshots) - never in the D: memory/DB store.
PROFILE_DIR = ROOT / "artifacts" / "whatsapp_web_profile"

WA_URL = "https://web.whatsapp.com"
LOGIN_WAIT_S = 150.0          # QR scan budget (the user needs time to scan)
ACTION_TIMEOUT_MS = 15000
SEND_VERIFY_S = 8.0           # how long to wait for the sent bubble to appear

_lock = threading.RLock()
_pw = None
_context = None
_page = None
_last_error = ""

# One place to fix when WhatsApp Web drifts. Keys are logical; values are CSS.
SELECTORS = {
    "chat_list": "#pane-side, div[aria-label='Chat list'], div[role='grid']",
    "search_box": "div[contenteditable='true'][data-tab='3']",
    "chat_row": "div[role='listitem'], #pane-side div[role='row']",
    "chat_title": "span[title]",
    "unread_badge": "span[aria-label*='unread' i], span[data-testid='icon-unread-count']",
    "msg_row": "div.message-in, div.message-out",
    "msg_text": "span.selectable-text, div.copyable-text span, span.copyable-text",
    "msg_time": "div.copyable-text[data-pre-plain-text]",
    "composer": "div[contenteditable='true'][data-tab='10'], footer div[contenteditable='true']",
    "send_btn": "button[aria-label='Send'], span[data-icon='send']",
    "qr": "canvas[aria-label*='Scan' i], div[data-ref], div[data-testid='qrcode']",
}


def _load_cortex():
    """Shared cowork key - never a second cortex module instance."""
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = ROOT / "background" / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def _err(message: str) -> dict:
    return {"ok": False, "error": str(message)[:300]}


# ── availability (same checks browser_agent documents) ────────────────────────
def playwright_installed() -> bool:
    return importlib.util.find_spec("playwright") is not None


def chromium_installed() -> bool:
    if not playwright_installed():
        return False
    cache = Path.home() / "AppData" / "Local" / "ms-playwright"
    try:
        return (cache.is_dir()
                and any(p.name.startswith("chromium") for p in cache.iterdir()))
    except Exception:
        return False


def capabilities() -> dict:
    """Honest report - the Modules card reads THIS, never a guess."""
    if not playwright_installed():
        return {"available": False, "ready": False,
                "reason": "pip install playwright (missing in this venv)"}
    if not chromium_installed():
        return {"available": False, "ready": False,
                "reason": "python -m playwright install chromium "
                          "(browser binary not downloaded yet)"}
    return {"available": True,
            "ready": PROFILE_DIR.exists(),
            "reason": "" if PROFILE_DIR.exists()
                      else "Playwright+Chromium ready; WhatsApp Web login pending "
                           "(run whatsapp_web_login once to scan the QR)",
            "profile": str(PROFILE_DIR),
            "two_way": True,
            "actions": ["status", "login", "unread", "read", "send"]}


def describe() -> str:
    caps = capabilities()
    if not caps["available"]:
        return "Sir, WhatsApp Web two-way unavailable: %s." % caps["reason"]
    if not caps["ready"]:
        return ("Sir, WhatsApp Web engine ready, par login pending - ek baar QR "
                "scan kar lijiye, phir main unread padh kar batata hoon.")
    return ("Sir, WhatsApp Web two-way ready: main unread padh sakta hoon, "
            "batata hoon, aur aapki permission par reply bhej sakta hoon.")



# ── persistent context singleton ──────────────────────────────────────────────
def _ensure(headless: bool = True):
    """Launch/reuse the persistent Chromium profile. Returns (page, error)."""
    global _pw, _context, _page, _last_error
    with _lock:
        if _page is not None:
            try:
                if not _page.is_closed():
                    return _page, ""
            except Exception:
                _page = None
        if not playwright_installed():
            return None, "playwright is not installed in this venv"
        try:
            from playwright.sync_api import sync_playwright  # type: ignore
        except Exception as exc:
            return None, "playwright import failed: %s" % type(exc).__name__
        try:
            if _pw is None:
                _pw = sync_playwright().start()
            if _context is None:
                PROFILE_DIR.mkdir(parents=True, exist_ok=True)
                _context = _pw.chromium.launch_persistent_context(
                    str(PROFILE_DIR), headless=headless,
                    args=["--disable-dev-shm-usage", "--no-sandbox"])
                _page = (_context.pages[0] if _context.pages
                         else _context.new_page())
            if _page is None or _page.is_closed():
                _page = (_context.pages[0] if _context.pages
                         else _context.new_page())
            _page.set_default_timeout(ACTION_TIMEOUT_MS)
            return _page, ""
        except Exception as exc:
            _last_error = "%s: %s" % (type(exc).__name__, exc)
            return None, ("could not launch WhatsApp Web profile - is another "
                          "context using it? (%s)" % _last_error[:140])


def close() -> dict:
    """Release the profile handle. Safe when nothing is open."""
    global _pw, _context, _page
    with _lock:
        for obj in (_context,):
            try:
                if obj is not None:
                    obj.close()
            except Exception:
                pass
        try:
            if _pw is not None:
                _pw.stop()
        except Exception:
            pass
        _pw = _context = _page = None
    return {"ok": True}


def _logged_in(page) -> bool:
    """True when the chat list (post-login) is present and the QR is gone."""
    try:
        if page.query_selector(SELECTORS["qr"]):
            return False
        return page.query_selector(SELECTORS["chat_list"]) is not None
    except Exception:
        return False


def _goto(page) -> bool:
    try:
        if WA_URL not in (page.url or ""):
            page.goto(WA_URL, wait_until="domcontentloaded",
                      timeout=ACTION_TIMEOUT_MS)
        return True
    except Exception:
        return False


def login(timeout_s: float = LOGIN_WAIT_S) -> tuple:
    """Open WhatsApp Web and wait for a QR scan. Returns (ok, message).

    Uses a HEADED profile (headless=False) ONLY for this one call so the user
    can actually scan the QR; the session then persists for headless use.
    """
    with _lock:
        page, err = _ensure(headless=False)
        if page is None:
            return (False, "Sir, WhatsApp Web launch fail: %s." % err)
        if not _goto(page):
            return (False, "Sir, web.whatsapp.com khul nahi paya - internet "
                           "check kijiye.")
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            if _logged_in(page):
                return (True, "Sir, WhatsApp Web login ho gaya. Ab main unread "
                              "padh kar bata sakta hoon aur permission par reply "
                              "bhej sakta hoon.")
            time.sleep(1.0)
    return (False, "Sir, QR scan nahi hua (timeout). Dobara 'WhatsApp login' "
                   "boliye aur phone se QR scan kar lijiye.")


def list_unread() -> tuple:
    """Read the chat list, return (rows, error). rows=[{name, unread, preview}]."""
    with _lock:
        page, err = _ensure()
        if page is None:
            return ([], err)
        if not _goto(page):
            return ([], "web.whatsapp.com khul nahi paya")
        if not _logged_in(page):
            return ([], "not_logged_in")
        try:
            rows = []
            for row in page.query_selector_all(SELECTORS["chat_row"]):
                name_el = row.query_selector(SELECTORS["chat_title"])
                name = ((name_el.get_attribute("title") or
                         name_el.inner_text() or "").strip() if name_el else "")
                badge = row.query_selector(SELECTORS["unread_badge"])
                count = 0
                if badge:
                    label = (badge.get_attribute("aria-label") or
                             badge.inner_text() or "").strip()
                    digits = "".join(c for c in label if c.isdigit())
                    count = int(digits) if digits else 1
                if count and name:
                    rows.append({"name": name[:60], "unread": count})
            return (rows[:40], "")
        except Exception as exc:
            return ([], "unread padhne me error: %s" % type(exc).__name__)


def _open_chat(page, contact: str) -> bool:
    """Open a chat by searching its name in the box. Returns success."""
    name = str(contact or "").strip()
    if not name:
        return False
    box = page.query_selector(SELECTORS["search_box"])
    if box is None:
        return False
    try:
        box.click(timeout=ACTION_TIMEOUT_MS)
        box.fill("")
        time.sleep(0.3)
        box.fill(name)
        time.sleep(1.2)  # let the contact results render
        first = page.query_selector(SELECTORS["chat_title"])
        if first is not None:
            first.click(timeout=ACTION_TIMEOUT_MS)
            time.sleep(0.8)
            return True
    except Exception:
        return False
    return False


def read_chat(contact: str, limit: int = 15) -> tuple:
    """Open a chat and read its last messages. Returns (rows, error).

    rows=[{who:'in'|'out', text, time}] newest-last. Read-only, ungated.
    """
    with _lock:
        page, err = _ensure()
        if page is None:
            return ([], err)
        if not _goto(page):
            return ([], "web.whatsapp.com khul nahi paya")
        if not _logged_in(page):
            return ([], "not_logged_in")
        if not _open_chat(page, contact):
            return ([], "chat '%s' nahi mila" % str(contact)[:40])
        try:
            rows = []
            for row in page.query_selector_all(SELECTORS["msg_row"])[-limit:]:
                cls = (row.get_attribute("class") or "")
                who = "out" if "message-out" in cls else "in"
                txt_el = row.query_selector(SELECTORS["msg_text"])
                text = (txt_el.inner_text() or "").strip() if txt_el else ""
                time_el = row.query_selector(SELECTORS["msg_time"])
                stamp = ""
                if time_el:
                    stamp = (time_el.get_attribute("data-pre-plain-text")
                             or "").strip().strip("[]")
                if text:
                    rows.append({"who": who, "text": text[:300], "time": stamp})
            return (rows, "")
        except Exception as exc:
            return ([], "messages padhne me error: %s" % type(exc).__name__)


def send_message(contact: str, text: str) -> tuple:
    """Open a chat, paste+send, then RE-READ the DOM to verify the outgoing
    bubble actually appeared. Returns (ok, message). Never claims a phantom
    send - a silent send is the worst failure mode.
    """
    with _lock:
        page, err = _ensure()
        if page is None:
            return (False, err)
        if not _goto(page):
            return (False, "web.whatsapp.com khul nahi paya")
        if not _logged_in(page):
            return (False, "not_logged_in")
        if not _open_chat(page, contact):
            return (False, "chat '%s' nahi mila" % str(contact)[:40])
        try:
            outs_before = len(page.query_selector_all(
                "div[class*='message-out']"))
        except Exception:
            outs_before = 0
        composer = page.query_selector(SELECTORS["composer"])
        if composer is None:
            return (False, "message box nahi mila - WhatsApp ne DOM badla hoga")
        body = str(text or "").strip()[:1000]
        if not body:
            return (False, "Sir, message khaali hai.")
        try:
            composer.click(timeout=ACTION_TIMEOUT_MS)
            composer.fill(body)
            time.sleep(0.3)
            page.keyboard.press("Enter")
        except Exception as exc:
            return (False, "type/send fail: %s" % type(exc).__name__)
        deadline = time.monotonic() + SEND_VERIFY_S
        while time.monotonic() < deadline:
            try:
                outs_now = len(page.query_selector_all(
                    "div[class*='message-out']"))
                if outs_now > outs_before:
                    return (True, "Sir, message '%s' ko bhej diya (DOM pe verify "
                                  "ho gaya)." % str(contact)[:40])
            except Exception:
                pass
            time.sleep(0.5)
    return (False, "message bheja nahi ja saka - DOM pe sent bubble nahi dikha. "
                   "Confirm nahi hai ki gaya; dobara try kijiye.")


# ── tool handlers (called through the real permission engine + confirm gate) ──
def tool_status(args: dict) -> dict:
    cortex = _load_cortex()
    return cortex.ok_result(describe(), data=capabilities())


def tool_login(args: dict) -> dict:
    cortex = _load_cortex()
    ok, message = login()
    if not ok:
        return cortex.fail_result(message)
    return cortex.ok_result(message)


def tool_unread(args: dict) -> dict:
    cortex = _load_cortex()
    rows, err = list_unread()
    if err:
        if err == "not_logged_in":
            return cortex.fail_result(
                "Sir, WhatsApp Web login nahi hai - ek baar 'WhatsApp login' "
                "boliye aur QR scan kar lijiye.")
        return cortex.fail_result("Sir, unread nahi padh paya: %s" % err)
    if not rows:
        return cortex.ok_result("Sir, koi unread message nahi hai.", count=0)
    lines = ["%s (%d)" % (r["name"], r["unread"]) for r in rows]
    return cortex.ok_result("Sir, unread chats:\n" + "\n".join(lines),
                            count=len(rows), data=rows)


def tool_read(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        contact = cortex.read_str_param(args, "contact", max_chars=60)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    rows, err = read_chat(contact)
    if err:
        if err == "not_logged_in":
            return cortex.fail_result(
                "Sir, WhatsApp Web login nahi hai - ek baar 'WhatsApp login' "
                "boliye aur QR scan kar lijiye.")
        return cortex.fail_result("Sir, chat padh nahi paya: %s" % err)
    if not rows:
        return cortex.ok_result("Sir, is chat me kuch nahi mila.", count=0)
    lines = ["%s: %s" % ("aap" if r["who"] == "out" else str(contact)[:20],
                         r["text"]) for r in rows]
    return cortex.ok_result("\n".join(lines), count=len(rows), data=rows)


def tool_send(args: dict) -> dict:
    cortex = _load_cortex()
    try:
        contact = cortex.read_str_param(args, "contact", max_chars=60)
        text = cortex.read_str_param(args, "text", max_chars=1000)
    except cortex.ToolInputError as exc:
        return cortex.fail_result(str(exc))
    if not str(text or "").strip():
        return cortex.fail_result("Sir, kya bhejna hai bataiye.")
    ok, message = send_message(contact, text)
    if not ok:
        return cortex.fail_result(message)
    return cortex.ok_result(message, contact=str(contact)[:40])


def specs() -> list:
    """Cortex ToolSpecs for the WhatsApp Web two-way surface.

    Read tools (status/login/unread/read) are ungated like browser reads.
    The SEND tool declares requires_confirmation=True so the existing cortex
    confirm gate AND the permission category both apply before anything leaves.
    """
    cortex = _load_cortex()
    if cortex is None:
        return []
    return [
        cortex.ToolSpec("whatsapp_web_status",
                        "WhatsApp Web two-way engine ki honest status "
                        "(playwright, chromium, login).",
                        tool_status,
                        parameters={}, requires_confirmation=False, timeout_s=15.0,
                        tags=("whatsapp", "web", "status")),
        cortex.ToolSpec("whatsapp_web_login",
                        "WhatsApp Web QR login kholo (ek baar QR scan; session "
                        "save rehta hai).",
                        tool_login,
                        parameters={}, requires_confirmation=False,
                        timeout_s=LOGIN_WAIT_S + 10.0,
                        tags=("whatsapp", "web", "login")),
        cortex.ToolSpec("whatsapp_web_unread",
                        "Unread WhatsApp chats aur unka count padho aur batao "
                        "(read-only).",
                        tool_unread,
                        parameters={}, requires_confirmation=False, timeout_s=30.0,
                        tags=("whatsapp", "web", "unread", "read")),
        cortex.ToolSpec("whatsapp_web_read",
                        "Ek contact ke WhatsApp Web messages padho (read-only).",
                        tool_read,
                        parameters={"contact": "contact ka naam"},
                        requires_confirmation=False, timeout_s=35.0,
                        tags=("whatsapp", "web", "read")),
        cortex.ToolSpec("whatsapp_web_send",
                        "WhatsApp Web par contact ko reply bhejo, phir DOM se "
                        "verify karo ki gaya. Confirm-gated.",
                        tool_send,
                        parameters={"contact": "contact ka naam",
                                    "text": "bhejne wala message"},
                        requires_confirmation=True, timeout_s=60.0,
                        tags=("whatsapp", "web", "send", "reply")),
    ]
