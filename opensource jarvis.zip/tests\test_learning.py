"""Self-learning P1: corrections recorded durably and injected into prompts.

Contract: only clear correction/instruction shapes become memory; a bare
"nahi karo", a refusal verb or an opinion never does. Recording is on-device
(JSON), bounded, and the brain prompt clause is strictly additive.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "background"))

import learning  # noqa: E402


class ClassifyTest(unittest.TestCase):
    def test_clear_corrections_are_learned(self):
        for text in ("nahi, aise bolo",
                     "aisa mat karo",
                     "aise nahi, aise naam se bulao",
                     "nahi, short me bolo",
                     "nahi short me bolo",
                     "galat ho gaya, wo aise kar",
                     "galat tarika use kar raha hai"):
            self.assertEqual(learning.classify(text), "correction", text)

    def test_explicit_remember_instructions_are_learned(self):
        self.assertEqual(learning.classify("yaad rakh mera name PRATEEK hai"),
                         "instruct")
        self.assertEqual(learning.classify("remember short replies only"),
                         "instruct")

    def test_a_bare_deny_or_refusal_is_never_a_correction(self):
        for text in ("nahi karo", "nahi bhejo", "mat bhejna",
                     "nahi, kuch nahi", "confirm nahi kiya"):
            self.assertIsNone(learning.classify(text), text)

    def test_an_opinion_is_not_a_correction(self):
        for text in ("photo achhi nahi lagi", "mera photo kaisa laga",
                     "kal server nahi chala", "bore ho raha hun"):
            self.assertIsNone(learning.classify(text), text)


class StoreTest(unittest.TestCase):
    def setUp(self):
        learning.purge()
        self.addCleanup(learning.purge)

    def test_record_grows_bounded_and_readoff_reports(self):
        ok, total = learning.record("nahi, short bolo", "correction")
        self.assertTrue(ok)
        self.assertEqual(total, 1)
        learning.record("yaad rakh mera naam PRATEEK", "instruct")
        stats = learning.readoff()
        self.assertEqual(stats.get("total"), 2)
        self.assertEqual(stats.get("corrections"), 1)
        self.assertEqual(stats.get("instructs"), 1)
        self.assertTrue(any("short bolo" in s for s in stats.get("latest", [])))

    def test_prompt_line_carries_the_standing_order(self):
        learning.record("nahi, short bolo", "correction")
        line = learning.prompt_line()
        self.assertIn("STANDING CORRECTIONS", line)
        self.assertIn("short bolo", line)

    def test_prompt_line_empty_when_nothing_learned(self):
        self.assertEqual(learning.prompt_line(), "")

    def test_newest_first_with_a_cap(self):
        learning.purge()
        for i in range(8):
            learning.record("correction number %d" % i, "correction")
        entries = learning.items_for_prompt(k=3)
        self.assertEqual(len(entries), 3)
        self.assertIn("correction number 7", entries[0])

    def test_record_refuses_an_empty_body(self):
        ok, _total = learning.record("   ", "correction")
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main(verbosity=2)
