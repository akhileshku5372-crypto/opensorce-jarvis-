import json
import sys

transcript_path = r'C:\Users\PRATEEK\.gemini\antigravity-ide\brain\0849d4df-d39f-4273-8e2a-47b0d589e625\.system_generated\logs\transcript_full.jsonl'

lines = []
with open(transcript_path, 'r', encoding='utf-8') as f:
    for line in f:
        try:
            data = json.loads(line)
            if data.get('type') == 'PLANNER_RESPONSE':
                tool_calls = data.get('tool_calls', [])
                for call in tool_calls:
                    if call.get('name') in ['replace_file_content', 'write_to_file', 'multi_replace_file_content']:
                        args = call.get('arguments', {})
                        if 'app.js' in args.get('TargetFile', ''):
                            lines.append(call)
        except Exception as e:
            pass

print(f'Found {len(lines)} modifications.')
for i, call in enumerate(lines[-5:]):
    name = call.get('name')
    args = call.get('arguments', {})
    print(f'{i}: {name}')
    if name == 'write_to_file':
        print(f'Length of code: {len(args.get("CodeContent", ""))}')
    elif name == 'replace_file_content':
        print(f'Length of target: {len(args.get("TargetContent", ""))}')
        print(f'Length of replace: {len(args.get("ReplacementContent", ""))}')
    elif name == 'multi_replace_file_content':
        chunks = args.get('ReplacementChunks', [])
        print(f'Chunks: {len(chunks)}')
