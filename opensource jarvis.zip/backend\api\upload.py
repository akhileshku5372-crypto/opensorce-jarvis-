"""
KamiSensei Upload Bridge — backend/api/upload.py
================================================
Canonical local ingestion controller wired to the '+ Add sources' flow and
directory intake. Responsibilities:

  1. FORCE-CREATE ./knowledge_base synchronously at the boot entry point.
  2. ``write_stream_file(filename, data_bytes)`` — chunked stream pipe that
     pushes raw data blocks straight onto disk at ./knowledge_base/<name>
     (fixed 1 MiB write window; guaranteed flush + fsync before returning).
  3. ``ingest_local_paths(paths)`` — local file / folder intake: copies every
     supported source (pdf/txt/md/json) into ./knowledge_base/.
  4. ``run_ingestion()`` — once streaming terminates, immediately spawns the
     PyMuPDF (fitz) extraction engine backend/services/ingestion.py with
     --ingest --json and returns its vector-index result (ChromaDB commit).

Pure standard library. CLI:
    python backend/api/upload.py --path C:\\files\\genki1.pdf --json
    python backend/api/upload.py --data-b64 <base64> --filename genki1.pdf --json
"""

import os
import sys
import json
import base64
import shutil
import argparse
import subprocess
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
KNOWLEDGE_BASE_DIR = ROOT_DIR / "knowledge_base"
INGESTION_SCRIPT = ROOT_DIR / "backend" / "services" / "ingestion.py"

SUPPORTED_EXTENSIONS = {".pdf", ".txt", ".md", ".json"}
STREAM_CHUNK_BYTES = 1024 * 1024  # 1 MiB per write block

# ── Zero-failure boot: force-create the physical target directory. ──────────
try:
    os.makedirs(str(KNOWLEDGE_BASE_DIR), exist_ok=True)
except Exception as _boot_error:
    sys.stderr.write(f"[upload] knowledge_base boot failed: {_boot_error}\n")


def sanitize_filename(name: str) -> str:
    """Strip path separators / traversal so raw names can never escape the KB."""
    clean = os.path.basename(str(name or "japanese_material.pdf"))
    return "".join(ch for ch in clean if ch not in '<>:"|?*').strip() or "japanese_material.pdf"


def write_stream_file(filename: str, data_bytes: bytes) -> dict:
    """
    Forcefully dump the raw incoming byte array into ./knowledge_base/<name>.

    Uses a fixed-size synchronous write loop (stream-pipe semantics): the data
    is flushed in 1 MiB blocks and fsync'd before this returns, so a completed
    write is guaranteed to be physically persisted before ingestion starts.
    """
    target_name = sanitize_filename(filename)
    target_path = KNOWLEDGE_BASE_DIR / target_name
    os.makedirs(str(KNOWLEDGE_BASE_DIR), exist_ok=True)

    total = len(data_bytes or b"")
    with open(str(target_path), "wb") as fh:
        for offset in range(0, total, STREAM_CHUNK_BYTES):
            fh.write(data_bytes[offset : offset + STREAM_CHUNK_BYTES])
        fh.flush()
        os.fsync(fh.fileno())

    return {
        "status": "success",
        "filename": target_name,
        "path": str(target_path),
        "size_bytes": total,
        "target_dir": str(KNOWLEDGE_BASE_DIR),
    }
def ingest_local_paths(paths) -> dict:
    """
    Local path / folder intake. Copies each supported source found at the given
    paths into ./knowledge_base/. Files already present with identical size are
    skipped to avoid redundant overwrite prompts.
    """
    copied: list = []
    failures: list = []

    if isinstance(paths, str):
        paths = [paths]

    for raw in paths or []:
        src = Path(str(raw).strip())
        if not src.exists():
            failures.append({"path": str(raw), "error": "Path does not exist"})
            continue
        targets = [src] if src.is_file() else [p for p in src.rglob("*") if p.is_file()]
        for item in targets:
            if not item or item.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            dest = KNOWLEDGE_BASE_DIR / item.name
            try:
                if dest.exists() and dest.stat().st_size == item.stat().st_size:
                    copied.append(dest.name)  # already on disk, nothing to do
                    continue
                shutil.copyfile(str(item), str(dest))
                copied.append(dest.name)
            except Exception as exc:
                failures.append({"path": str(item), "error": str(exc)})

    return {"status": "success" if not failures else "partial", "copied": sorted(set(copied)), "failures": failures}


def run_ingestion(force: bool = False, timeout: int = 180) -> dict:
    """
    Trigger backend/services/ingestion.py (PyMuPDF fitz extraction + ChromaDB
    chunk commit). Returns the parsed JSON response or a guarded failure dict.
    """
    args = [str(INGESTION_SCRIPT), "--ingest", "--json"]
    if force:
        args.append("--force")
    try:
        proc = subprocess.run(
            [sys.executable, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(ROOT_DIR),
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Ingestion timed out."}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

    raw = (proc.stdout or "").strip()
    first_brace, last_brace = raw.find("{"), raw.rfind("}")
    if first_brace != -1 and last_brace >= first_brace:
        try:
            parsed = json.loads(raw[first_brace : last_brace + 1])
            parsed["ok"] = proc.returncode == 0
            return parsed
        except Exception:
            pass
    return {
        "ok": proc.returncode == 0,
        "returncode": proc.returncode,
        "error": (proc.stderr or "").strip()[:2000] or "Ingestion produced no JSON output.",
        "stdout": raw[:2000],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="KamiSensei Upload Bridge")
    parser.add_argument("--filename", type=str, default="", help="Target filename for raw data")
    parser.add_argument("--data-b64", type=str, default="", help="Base64-encoded file data")
    parser.add_argument("--path", type=str, action="append", default=[], help="Local file/folder path(s) to ingest")
    parser.add_argument("--no-ingest", action="store_true", help="Skip auto ingestion (write only)")
    parser.add_argument("--force", action="store_true", help="Force re-index in ingestion")
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    args = parser.parse_args()

    result = {}
    if args.path:
        result["write"] = ingest_local_paths(args.path)
    elif args.data_b64:
        try:
            raw_bytes = base64.b64decode(args.data_b64.replace("data:;base64,", "").replace("data:application/octet-stream;base64,", ""))
            result["write"] = write_stream_file(args.filename, raw_bytes)
        except Exception as exc:
            result["write"] = {"status": "error", "error": str(exc)}
    else:
        result["write"] = {"status": "error", "error": "Nothing to write. Provide --path or --data-b64."}

    if not args.no_ingest:
        result["ingestion"] = run_ingestion(force=args.force)

    if args.json:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()