/* Headless tests for the shipped two-hand gesture engine (public/static/gesture-control.js).
 *
 * Run: node tests/test_gesture_engine.cjs
 *
 * The recognition math is pure and has no camera/CDN dependency, so every case
 * below runs without MediaPipe. The controller itself is exercised through the
 * same file, but its DOM/camera paths need a browser and are not pretended here.
 */
const assert = require('assert')
const fs = require('fs')
const path = require('path')

const source = fs.readFileSync(
  path.join(__dirname, '..', 'public', 'static', 'gesture-control.js'), 'utf8')
const sandbox = { localStorage: null }
// eslint-disable-next-line no-new-func
const gesture = new Function('window', source + '\n;return window.__JARVIS_GESTURE_ENGINE__')(sandbox)
if (!gesture || typeof gesture.handPose !== 'function') {
  throw new Error('gesture-control.js did not publish __JARVIS_GESTURE_ENGINE__')
}

let passed = 0
const suite = []
function test (name, fn) {
  suite.push({ name: name, fn: fn })
}

// The gesture path involves promises (every bridge call is acked
// asynchronously), so tests run in a queue and report after each settles.
async function runSuite () {
  for (const entry of suite) {
    try {
      await entry.fn()
      passed += 1
      console.log('  ok -', entry.name)
    } catch (err) {
      console.error('  FAIL -', entry.name)
      console.error('   ', err.message)
      process.exitCode = 1
    }
  }
  console.log(`\n${passed} gesture-engine tests passed${process.exitCode ? ' (with failures)' : ''}`)
}

// Build a 21-point hand. The wrist is at (0.5, 0.9) and the middle MCP at
// (0.5, 0.6), so the engine's size normaliser is exactly 0.3. Extended fingers
// reach far from the wrist; curled fingers stay next to the palm.
function hand (options = {}) {
  const opts = Object.assign({ index: false, middle: false, ring: false, pinky: false, thumbUp: false, thumbAt: null }, options)
  const lm = Array.from({ length: 21 }, () => ({ x: 0.5, y: 0.9, z: 0 }))
  lm[0] = { x: 0.5, y: 0.9, z: 0 }
  lm[1] = { x: 0.44, y: 0.82, z: 0 }
  lm[2] = { x: 0.4, y: 0.74, z: 0 }
  lm[3] = { x: 0.36, y: 0.68, z: 0 }
  // Thumb tip. The "up" position is far from both the wrist and the index MCP
  // (the two tests fingersUp uses); the folded position sits clear of every
  // curled fingertip so a fist is not mistaken for a pinch.
  lm[4] = opts.thumbAt || (opts.thumbUp ? { x: 0.2, y: 0.2, z: 0 } : { x: 0.22, y: 0.66, z: 0 })
  lm[5] = { x: 0.42, y: 0.62, z: 0 }
  const base = { index: [5, 0.42], middle: [9, 0.5], ring: [13, 0.58], pinky: [17, 0.66] }
  Object.keys(base).forEach((name) => {
    const [mcp, x] = base[name]
    lm[mcp] = { x, y: 0.62, z: 0 }
    lm[mcp + 1] = { x, y: 0.54, z: 0 }
    lm[mcp + 2] = { x, y: 0.46, z: 0 }
    lm[mcp + 3] = opts[name] ? { x, y: 0.27, z: 0 } : { x, y: 0.67, z: 0 }
  })
  return lm
}

function poseOf (options) {
  const lm = hand(options)
  return gesture.handPose(lm)
}

test('version and profiles are published', () => {
  assert.strictEqual(gesture.version, '2.1.0')
  assert.ok(gesture.PROFILES.precision && gesture.PROFILES.balanced && gesture.PROFILES.fast)
  assert.strictEqual(gesture.DEFAULT_CONFIG.pointerHand, 'right')
})

test('the tightened pinch thresholds and the new gesture constants ship as defaults', () => {
  // 0.42 (the old default) classified a normal pointing hand as a pinch, which
  // is why clicks fired on their own. The shipped default must stay strict.
  assert.strictEqual(gesture.DEFAULT_CONFIG.pinchOn, 0.3)
  assert.ok(gesture.DEFAULT_CONFIG.pinchOff > gesture.DEFAULT_CONFIG.pinchOn, 'hysteresis needs a wider release threshold')
  assert.ok(gesture.DEFAULT_CONFIG.dragHoldMs >= 200, 'a drag needs a real hold time')
  assert.ok(gesture.DEFAULT_CONFIG.clickMaxMove > 0, 'a click needs a movement slop')
  assert.ok(gesture.DEFAULT_CONFIG.fistScrollStep > 0, 'fist scrolling needs a real travel step')
})

test('fingersUp reads extended and curled fingers', () => {
  assert.deepStrictEqual(gesture.fingersUp(hand({ index: true })), [0, 1, 0, 0, 0])
  assert.deepStrictEqual(gesture.fingersUp(hand({ index: true, middle: true })), [0, 1, 1, 0, 0])
  assert.deepStrictEqual(gesture.fingersUp(hand({ index: true, middle: true, ring: true, pinky: true, thumbUp: true })), [1, 1, 1, 1, 1])
  assert.deepStrictEqual(gesture.fingersUp(hand()), [0, 0, 0, 0, 0])
})

test('handPose reports pointing, peace, palm and fist exactly', () => {
  assert.strictEqual(poseOf({ index: true }).pointing, true)
  assert.strictEqual(poseOf({ index: true }).palm, false)
  assert.strictEqual(poseOf({ index: true, middle: true }).peace, true)
  assert.strictEqual(poseOf({ index: true, middle: true, ring: true, pinky: true, thumbUp: true }).palm, true)
  assert.strictEqual(poseOf({}).fist, true)
  assert.strictEqual(poseOf({}).thumbsUp, false)
  assert.strictEqual(poseOf({ thumbUp: true }).thumbsUp, true)
})

test('classifyPose names the built-in gestures', () => {
  assert.strictEqual(gesture.classifyPose(hand({ index: true }), poseOf({ index: true }), 0.9).name, 'point')
  assert.strictEqual(gesture.classifyPose(hand({ index: true, middle: true }), poseOf({ index: true, middle: true }), 0.9).name, 'peace')
  assert.strictEqual(gesture.classifyPose(hand({ index: true, middle: true, ring: true, pinky: true, thumbUp: true }), poseOf({ index: true, middle: true, ring: true, pinky: true, thumbUp: true }), 0.9).name, 'open_palm')
  assert.strictEqual(gesture.classifyPose(hand({}), poseOf({}), 0.9).name, 'fist')
})

test('pinch and double-pinch win over the finger count', () => {
  const pinchHand = hand({ index: true, thumbAt: { x: 0.42, y: 0.27, z: 0 } })
  const pinch = gesture.handPose(pinchHand)
  assert.ok(pinch.pinchI < 0.42, 'thumb and index must be close')
  assert.strictEqual(gesture.classifyPose(pinchHand, pinch, 0.9).name, 'pinch')

  const doubleHand = hand({ index: true, middle: true, thumbAt: { x: 0.58, y: 0.67, z: 0 } })
  const double = gesture.handPose(doubleHand)
  assert.ok(double.pinchDouble, 'thumb and ring must be close while index/middle stay away')
  assert.strictEqual(gesture.classifyPose(doubleHand, double, 0.9).name, 'double_pinch')
})

test('unknown poses carry a reduced confidence, never a fake name', () => {
  const lm = hand({ index: true, middle: true, ring: true })
  const pose = gesture.handPose(lm)
  const result = gesture.classifyPose(lm, pose, 0.8)
  assert.strictEqual(result.name, 'three')
  const unknown = gesture.classifyPose(lm, Object.assign({}, pose, {
    three: false, peace: false, pointing: false, palm: false, fist: false,
    thumbsUp: false, ok: false, pinchDouble: false, pinchI: 1, pinchM: 1
  }), 0.8)
  assert.strictEqual(unknown.name, 'unknown')
  assert.ok(unknown.confidence <= 0.8 * 0.35 + 1e-9)
})

test('normalizeLandmarks is wrist-relative, scale-invariant and 63 values', () => {
  const lm = hand({ index: true })
  const vector = gesture.normalizeLandmarks(lm)
  assert.strictEqual(vector.length, 63)
  assert.ok(Math.abs(vector[0]) < 1e-9 && Math.abs(vector[1]) < 1e-9 && Math.abs(vector[2]) < 1e-9)
  assert.ok(Math.abs(vector[9 * 3]) < 1e-9)
  assert.ok(Math.abs(vector[9 * 3 + 1] + 1) < 1e-9)
})

test('templateDistance and matchTemplates use pose mappings only', () => {
  const vector = gesture.normalizeLandmarks(hand({ index: true }))
  assert.strictEqual(gesture.templateDistance(vector, vector), 0)
  assert.ok(Number.isFinite(gesture.templateDistance(vector, gesture.mirrorTemplate(vector))))
  const mapping = { id: 'g1', kind: 'pose', name: 'point', action: 'click', template: vector }
  const sequence = { id: 'g2', kind: 'sequence', name: 'seq', action: 'click', sequence: ['right:point'] }
  const match = gesture.matchTemplates(vector, [sequence, mapping])
  assert.ok(match && match.mapping.id === 'g1')
  assert.ok(match.distance < 1e-9)
  assert.strictEqual(gesture.matchTemplates(vector, [sequence]), null)
})

test('mirrorTemplate flips only the x axis', () => {
  const vector = new Array(63).fill(0)
  vector[0] = 0.25
  vector[1] = -0.5
  vector[2] = 0.75
  const mirrored = gesture.mirrorTemplate(vector)
  assert.strictEqual(mirrored[0], -0.25)
  assert.strictEqual(mirrored[1], -0.5)
  assert.strictEqual(mirrored[2], 0.75)
})

test('a foreshortened pointing hand is measured in 3D, not in the image plane', () => {
  // A hand pointing AT the camera collapses towards the wrist in x/y. The old
  // 2D-only reading called that a curled finger; the 3D reading recovers it.
  const lm = hand({ index: true })
  lm[6] = { x: 0.44, y: 0.66, z: 0 }
  lm[8] = { x: 0.5, y: 0.75, z: -0.42 }
  const wrist = lm[0]
  const size = gesture.distance(lm[0], lm[9])
  const flat = gesture.distance(lm[8], wrist) / size
  assert.ok(flat < 1.35, 'in 2D this hand looks curled (got ' + flat.toFixed(2) + ')')
  assert.ok(gesture.distance3(lm[8], wrist) / size > 1.35, 'in 3D the finger is extended')
  assert.deepStrictEqual(gesture.fingersUp(lm), [0, 1, 0, 0, 0])
})

test('classifyPose honours the caller config instead of the shipped default', () => {
  // This was a real bug: classifyPose read DEFAULT_CONFIG.pinchOn, so the pinch
  // slider in the console did nothing at all.
  const lm = hand({ index: true, thumbAt: { x: 0.42, y: 0.42, z: 0 } })
  const pose = gesture.handPose(lm)
  assert.ok(pose.pinchI > 0.3 && pose.pinchI < 0.6, 'the pose sits between the two thresholds')
  assert.strictEqual(gesture.classifyPose(lm, pose, 0.9).name, 'point', 'strict default: not a pinch')
  const loose = Object.assign({}, gesture.DEFAULT_CONFIG, { pinchOn: 0.6, pinchOff: 0.75 })
  assert.strictEqual(gesture.classifyPose(lm, pose, 0.9, loose).name, 'pinch', 'the configured threshold must win')
})

test('candidatePoses names the closest template and only from measured geometry', () => {
  const cases = [
    ['open_palm', { index: true, middle: true, ring: true, pinky: true, thumbUp: true }],
    ['fist', {}],
    ['thumbs_up', { thumbUp: true }],
    ['point', { index: true }],
    ['peace', { index: true, middle: true }]
  ]
  for (const [name, options] of cases) {
    const candidates = gesture.candidatePoses(poseOf(options), 3)
    assert.ok(candidates.length > 0 && candidates.length <= 3, name + ' must report a short candidate list')
    for (let i = 1; i < candidates.length; i += 1) {
      assert.ok(candidates[i - 1].confidence >= candidates[i].confidence, 'candidates must be sorted')
    }
    for (const candidate of candidates) {
      assert.ok(Number.isFinite(candidate.confidence) && candidate.confidence >= 0 && candidate.confidence <= 1, 'confidence must be a real fraction')
    }
    const match = candidates.find((candidate) => candidate.name === name)
    assert.ok(match && match.confidence >= 0.8, name + ' must be the (or a) strong candidate, got ' +
      JSON.stringify(candidates.map((c) => c.name + ':' + c.confidence)))
  }
  // A pinch candidate is scored by how close the fingertips really are, so the
  // same finger layout scores differently when only the thumb moves.
  const near = gesture.candidatePoses(poseOf({ index: true, thumbAt: { x: 0.42, y: 0.27, z: 0 } }), 3)
  assert.ok(near.some((candidate) => candidate.name === 'pinch'),
    'a thumb touching the index tip must be reported as a pinch candidate')
})

test('the motion tracker measures direction, speed and travel', () => {
  const tracker = gesture.makeMotionTracker()
  assert.strictEqual(gesture.describeMotion(tracker), 'not measured')
  assert.strictEqual(gesture.updateMotion(tracker, { x: 0.2, y: 0.5 }, 0).direction, 'still')
  for (let i = 1; i <= 10; i += 1) gesture.updateMotion(tracker, { x: 0.2 + i * 0.05, y: 0.5 }, i * 100)
  assert.strictEqual(tracker.direction, 'right')
  assert.ok(tracker.speed > 0.32, 'a real movement must clear the still threshold')
  assert.ok(Math.abs(tracker.lastDx - 0.05) < 1e-9, 'the per-frame travel must be kept for the scroll integrator')
  assert.ok(/moving right/.test(gesture.describeMotion(tracker)))

  const steady = gesture.makeMotionTracker()
  for (let i = 0; i <= 6; i += 1) gesture.updateMotion(steady, { x: 0.4, y: 0.4 }, i * 100)
  assert.strictEqual(steady.direction, 'still')
  assert.strictEqual(gesture.describeMotion(steady), 'steady')

  const diagonal = gesture.makeMotionTracker()
  for (let i = 0; i <= 10; i += 1) gesture.updateMotion(diagonal, { x: i * 0.05, y: i * 0.05 }, i * 100)
  assert.strictEqual(diagonal.direction, 'down-right')
})

test('mapToScreen honours calibration and clamps to the viewport', () => {
  const lm = hand({ index: true })
  lm[8] = { x: 0.2, y: 0.5, z: 0 }
  const calibration = { minX: 0.2, maxX: 0.8, minY: 0.2, maxY: 0.8 }
  const point = gesture.mapToScreen(lm, calibration, { width: 1000, height: 500 }, 1, 8)
  assert.deepStrictEqual({ x: Math.round(point.x), y: Math.round(point.y) }, { x: 1000, y: 250 })
  const plain = gesture.mapToScreen(lm, null, { width: 1000, height: 500 }, 1, 8)
  assert.deepStrictEqual({ x: Math.round(plain.x), y: Math.round(plain.y) }, { x: 800, y: 250 })
  lm[8] = { x: 1.2, y: -0.2, z: 0 }
  const clamped = gesture.mapToScreen(lm, null, { width: 1000, height: 500 }, 2, 8)
  assert.ok(clamped.x >= 0 && clamped.x <= 1000 && clamped.y >= 0 && clamped.y <= 500)
})

test('OneEuroFilter converges and rejects impossible output', () => {
  const filter = new gesture.OneEuroFilter({ minCutoff: 1.2, beta: 0.02 })
  let value = filter.filter(0, 0)
  assert.strictEqual(value, 0)
  for (let i = 1; i <= 80; i += 1) value = filter.filter(1, i * 0.016)
  assert.ok(Math.abs(value - 1) < 0.02, 'filter must converge to the steady input, got ' + value)
  assert.ok(Number.isFinite(value))
})

test('SequenceMatcher fires once per cooldown and resets cleanly', () => {
  const mapping = { id: 's1', name: 'point then pinch', action: 'click' }
  const matcher = new gesture.SequenceMatcher(
    [{ id: 's1', sequence: ['right:point', 'right:pinch'], mapping, cooldownMs: 1500 }],
    { windowMs: 2600 })
  assert.strictEqual(matcher.push('right:point', 0), null)
  const hit = matcher.push('right:pinch', 100)
  assert.ok(hit && hit.mapping === mapping)
  assert.strictEqual(matcher.push('right:point', 200), null)
  assert.strictEqual(matcher.push('right:pinch', 300), null, 'cooldown must suppress an immediate repeat')
  assert.strictEqual(matcher.push('right:point', 3000), null)
  assert.ok(matcher.push('right:pinch', 3100))
  matcher.reset()
  assert.strictEqual(matcher.buffer.length, 0)
})

test('controller exposes the draw/latency methods the camera loop calls', () => {
  const control = new Function('window', source + '\n;return window.__JARVIS_GESTURE_CONTROL__')({ localStorage: null })
  const controller = control.create({ state: { bridgeOnline: false } })
  for (const name of ['draw', 'onResults', 'loop', 'handleCameraLost', 'markActionLatency', 'start', 'stop', 'pause', 'resume', 'emergencyStop', 'semanticActivate', 'activateVoiceTarget']) {
    assert.strictEqual(typeof controller[name], 'function', name + ' must exist')
  }
  controller.draw([]) // no document in this sandbox: must be a safe no-op
  controller.frameCaptureAt = 0.5
  controller.markActionLatency(1)
  assert.ok(controller.metrics.actionMs > 0, 'dispatch latency must be measured')
  assert.ok(controller.metrics.captureToActionMs >= controller.metrics.actionMs, 'capture-to-action must start at the frame')
  assert.ok('captureToActionMs' in controller.snapshotStatus().metrics)
})

test('a live frame classifies, draws and two fists pause', () => {
  // The camera loop needs a browser, but the per-frame path (hand in -> pose
  // out -> overlay draw -> action routing) must run end to end without one.
  const drawn = { clearRect: 0, arc: 0, stroke: 0 }
  const context = {
    setTransform: () => {},
    clearRect: () => { drawn.clearRect += 1 },
    arc: () => { drawn.arc += 1 },
    stroke: () => { drawn.stroke += 1 },
    beginPath: () => {}, moveTo: () => {}, lineTo: () => {},
    fill: () => {}, fillText: () => {}, save: () => {}, restore: () => {}
  }
  const canvas = {
    width: 0,
    height: 0,
    clientWidth: 1280,
    clientHeight: 720,
    getBoundingClientRect: () => ({ width: 1280, height: 720 }),
    getContext: () => context
  }
  const win = {
    localStorage: null,
    innerWidth: 1280,
    innerHeight: 720,
    devicePixelRatio: 1,
    HAND_CONNECTIONS: [[0, 1], [1, 2]],
    addEventListener: () => {},
    document: {
      getElementById: () => null,
      querySelectorAll: () => [],
      createElement: () => ({ style: {} }),
      body: { appendChild: () => {} },
      hasFocus: () => false,
      addEventListener: () => {}
    }
  }
  const control = new Function('window', source + '\n;return window.__JARVIS_GESTURE_CONTROL__')(win)
  const controller = control.create({ state: { bridgeOnline: false } })
  controller.active = true
  controller.panel = { querySelector: () => canvas }
  // The tracker only ever runs against a playing <video>; its intrinsic size is
  // what the cover mapping needs.
  controller.video = { videoWidth: 1280, videoHeight: 720, closest: () => controller.panel }

  controller.onResults({
    multiHandLandmarks: [hand({ index: true })],
    multiHandedness: [{ label: 'Right', score: 0.95 }]
  })
  assert.strictEqual(controller.lastGesture.name, 'point')
  assert.ok(drawn.clearRect >= 1, 'the overlay must clear the previous frame')
  assert.ok(drawn.arc >= 21, 'every landmark must be drawn')
  assert.strictEqual(win.__JARVIS_HANDS__.length, 1)

  controller.onResults({
    multiHandLandmarks: [hand({}), hand({})],
    multiHandedness: [{ label: 'Right', score: 0.95 }, { label: 'Left', score: 0.95 }]
  })
  assert.strictEqual(controller.paused, true, 'both fists must pause control')
})

test('sensitive labels are refused in every supported language', () => {
  for (const label of ['Delete all', 'Send message', 'Confirm purchase', 'Restart now', 'Sign out',
    'Clear conversation memory', 'Lock PC', 'Sleep', 'Turn off display', 'Log out', 'lock pc']) {
    assert.strictEqual(gesture.isSensitiveLabel(label), true, label)
  }
  assert.strictEqual(gesture.isSensitiveLabel('Unlock'), false)
  assert.strictEqual(gesture.isSensitiveLabel('Clock settings'), false)
  assert.strictEqual(gesture.isSensitiveLabel('हटाएं'), true)
  assert.strictEqual(gesture.isSensitiveLabel('削除'), true)
  for (const label of ['Open settings', 'Next track', 'Pause controls', 'Dashboard home', '']) {
    assert.strictEqual(gesture.isSensitiveLabel(label), false, label)
  }
})

/* ── controller behaviour: landmarks in, real Windows actions out ──────────
 * The camera loop needs a browser, but everything between "a frame arrived"
 * and "an action left the machine" is plain JS. These tests drive the shipped
 * controller with a fake clock (so hold times are deterministic, not flaky)
 * and a recording bridge, which is how the press-release rules are proven
 * instead of merely described in a comment.
 */
const flush = () => new Promise((resolve) => setImmediate(resolve))

function shifted (lm, dx, dy) {
  return lm.map((point) => ({ x: point.x + dx, y: point.y + dy, z: point.z }))
}

function pinchHand () {
  return hand({ index: true, thumbAt: { x: 0.42, y: 0.27, z: 0 } })
}

function rightPinchHand () {
  // A real thumb-middle pinch: the index is curled out of the way, so the thumb
  // tip meets the middle tip at (0.5, 0.27).
  return hand({ middle: true, thumbAt: { x: 0.5, y: 0.27, z: 0 } })
}

function harness (options = {}) {
  const opts = options || {}
  const desktop = opts.desktop || { left: 0, top: 0, width: 1536, height: 864 }
  const clock = { t: 1000, now: () => clock.t }
  const calls = []
  const toasts = []
  // The big gesture label is a DOM element in the real page. Capturing it here
  // is what lets a test assert whether CLICK was shown before the bridge said
  // the Windows click really happened.
  const feedback = {
    textContent: '',
    offsetWidth: 0,
    classList: { remove: () => {}, add: () => {} }
  }
  const win = {
    localStorage: null,
    innerWidth: 1536,
    innerHeight: 864,
    outerWidth: 1536,
    outerHeight: 864,
    screenX: 0,
    screenY: 0,
    screen: opts.screen || { width: 1536, height: 864 },
    // Timers run immediately: the only deferred work in the controller is the
    // second half of a double click (90 ms), and the assertion here is that a
    // double click really sends two clicks, not that the delay is 90 ms.
    setTimeout: (fn) => { if (typeof fn === 'function') fn(); return 0 },
    clearTimeout: () => {},
    requestAnimationFrame: () => 0,
    cancelAnimationFrame: () => {},
    addEventListener: () => {},
    HAND_CONNECTIONS: [],
    document: {
      getElementById: () => null,
      querySelectorAll: (selector) => selector === '.gesture-feedback' ? [feedback] : [],
      createElement: () => ({ style: {} }),
      body: { appendChild: () => {} },
      hasFocus: () => false,
      addEventListener: () => {}
    }
  }
  const ctx = {
    state: {
      bridgeOnline: true,
      bridgeDesktop: desktop,
      bridgeMouse: { reported: true, ready: true, supported: true, error: '' },
      activeWindow: 'Qoder'
    },
    bridgeMouse: opts.mouse || ((body) => {
      calls.push(Object.assign({ at: clock.t }, body))
      return Promise.resolve({ ok: true, x: body.x || 0, y: body.y || 0, action: body.action })
    }),
    bridgeAction: () => Promise.resolve({ handled: true }),
    uiRequest: () => Promise.resolve({ ok: true }),
    showToast: (text) => { toasts.push(String(text)) },
    navigateTo: () => {},
    activePanel: () => null,
    videoFor: () => null,
    stopCamera: () => {},
    startCamera: () => Promise.resolve(true),
    ensureCamera: () => Promise.resolve(true),
    toggleCamera: () => {},
    applyHudScale: () => {},
    toggleListening: () => {},
    refreshBridge: () => {}
  }
  const control = new Function('window', 'performance', source + '\n;return window.__JARVIS_GESTURE_CONTROL__')(win, clock)
  const controller = control.create(ctx)
  controller.active = true
  controller.desktop = desktop
  controller.mouseInput = { reported: true, ready: true, error: '', supported: true }
  const frame = (landmarks, handedness, advance = 40) => {
    clock.t += advance
    controller.onResults({
      multiHandLandmarks: landmarks,
      multiHandedness: handedness || landmarks.map(() => ({ label: 'Right', score: 0.95 }))
    })
  }
  return { controller, calls, clock, frame, toasts, feedback }
}

const of = (action) => (call) => call.action === action

test('a pointing hand drives the real bridge cursor and follows the hand', async () => {
  const h = harness()
  h.frame([hand({ index: true })])
  const first = h.calls.find(of('move'))
  assert.ok(first, 'the pointer must reach the bridge, not just the DOM dot')
  assert.ok(first.x >= 0 && first.x <= 1535 && first.y >= 0 && first.y <= 863, 'the move must land inside the bridge desktop')
  // The camera faces the user, so the hand moving right on screen means the
  // landmark x DECREASES (the mapping is mirrored). The cursor must follow it
  // right anyway.
  for (let i = 1; i <= 6; i += 1) h.frame([shifted(hand({ index: true }), -0.03 * i, 0)])
  const last = h.calls.filter(of('move')).pop()
  assert.ok(last.x > first.x, 'moving the hand right must move the real cursor right (' + first.x + ' -> ' + last.x + ')')
  assert.strictEqual(h.controller.lastGesture.name, 'point')
})

test('a quick pinch clicks once on release, a held pinch becomes a drag', async () => {
  const h = harness()
  const clicks = () => h.calls.filter(of('lclick')).length
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500) // settle past armDelayMs
  h.frame([pinchHand()])
  assert.strictEqual(clicks(), 0, 'seeing a pinch must not fire a click')
  h.frame([hand({ index: true })], null, 120)
  assert.strictEqual(clicks(), 1, 'the release is the click')

  // A held pinch must press the real button and hold it.
  h.frame([pinchHand()], null, 900)
  h.frame([pinchHand()], null, 300)
  h.frame([pinchHand()], null, 200)
  assert.strictEqual(h.calls.filter(of('ldown')).length, 1, 'holding the pinch must press the button once')
  h.frame([hand({ index: true })], null, 100)
  assert.strictEqual(h.calls.filter(of('lup')).length, 1, 'releasing the pinch must drop the button')
  assert.strictEqual(clicks(), 1, 'a drag must never end as a click')
  assert.strictEqual(h.controller.drag, null)
})

test('a pinch that travels is a drag, and a long hold is not a click', async () => {
  const h = harness()
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500)
  // Pinch, then travel far beyond the click slop while still pinched.
  for (let i = 1; i <= 6; i += 1) h.frame([shifted(pinchHand(), i * 0.03, 0)], null, 50)
  assert.ok(h.calls.filter(of('ldown')).length >= 1, 'travel while pinched must start a real drag')
  h.frame([shifted(hand({ index: true }), 0.18, 0)], null, 60)
  assert.strictEqual(h.calls.filter(of('lclick')).length, 0, 'a travelling pinch is never a click')
  assert.strictEqual(h.calls.filter(of('lup')).length, 1)

  // A right pinch held past the click window must fire nothing at all.
  const right = hand({ index: true, middle: true })
  h.frame([rightPinchHand()], null, 900)
  h.frame([rightPinchHand()], null, 1000)
  h.frame([right], null, 100)
  assert.strictEqual(h.calls.filter(of('rclick')).length, 0, 'a pinch held for seconds is not a right click')
})

test('a quick middle pinch right-clicks and a ring pinch double-clicks', async () => {
  const h = harness()
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500)
  h.frame([rightPinchHand()])
  h.frame([hand({ index: true, middle: true })], null, 120)
  assert.strictEqual(h.calls.filter(of('rclick')).length, 1, 'a released middle pinch is a right click')

  h.frame([hand({ index: true, middle: true, thumbAt: { x: 0.58, y: 0.67, z: 0 } })], null, 900)
  h.frame([hand({ index: true, middle: true })], null, 110)
  assert.strictEqual(h.calls.filter(of('lclick')).length, 2, 'a released ring pinch is a double click')
})

test('a moving fist scrolls the real wheel and never flings the cursor', async () => {
  const h = harness()
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500)
  const movesBefore = h.calls.filter(of('move')).length
  for (let i = 0; i < 12; i += 1) h.frame([shifted(hand({}), 0, i * 0.03)], null, 40)
  const scrolls = h.calls.filter(of('scroll'))
  assert.ok(scrolls.length >= 1, 'fist travel must produce real wheel notches')
  assert.ok(scrolls.every((call) => call.delta < 0), 'a downward hand must scroll down (negative wheel delta)')
  assert.strictEqual(h.calls.filter(of('ldown')).length, 0, 'a fist must never hold a mouse button')
  assert.strictEqual(h.calls.filter(of('move')).length, movesBefore, 'scrolling must not move the pointer')

  // Upward travel must invert the wheel.
  const before = h.calls.filter(of('scroll')).length
  for (let i = 12; i > 0; i -= 1) h.frame([shifted(hand({}), 0, i * 0.03)], null, 40)
  const after = h.calls.filter(of('scroll'))
  assert.ok(after.length > before, 'an upward hand must keep scrolling')
  assert.ok(after.slice(before).some((call) => call.delta > 0), 'upward travel must scroll up')
})

test('an open palm freezes the pointer while it is held and releases it when closed', async () => {
  const h = harness()
  const palm = () => hand({ index: true, middle: true, ring: true, pinky: true, thumbUp: true })
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500)
  const moves = h.calls.filter(of('move')).length
  // Hold the palm and keep moving the hand: the real cursor must not budge.
  for (let i = 1; i <= 4; i += 1) h.frame([shifted(palm(), -0.04 * i, 0.02 * i)], null, 80)
  assert.strictEqual(h.calls.filter(of('move')).length, moves, 'an open palm must freeze the pointer')
  assert.strictEqual(h.calls.filter(of('ldown')).length, 0)
  assert.ok(/OPEN PALM/.test(h.controller.lastStatus))
  // Closing the hand hands the pointer back.
  h.frame([shifted(hand({ index: true }), -0.16, 0.08)], null, 200)
  assert.ok(h.calls.filter(of('move')).length > moves, 'closing the palm must resume the pointer')
})

test('losing the camera releases a held button instead of latching it', async () => {
  const h = harness()
  h.frame([hand({ index: true })])
  h.frame([hand({ index: true })], null, 500)
  h.frame([pinchHand()], null, 50)
  h.frame([pinchHand()], null, 500)
  assert.strictEqual(h.calls.filter(of('ldown')).length, 1)
  h.controller.handleCameraLost('camera unplugged')
  assert.strictEqual(h.calls.filter(of('lup')).length, 1, 'a lost camera must release the Windows button')
  assert.strictEqual(h.controller.drag, null)
})

test('a rejected move is counted and reported, never silently successful', async () => {
  const h = harness({ mouse: () => Promise.resolve({ ok: false, error: 'the PowerShell input worker is not answering' }) })
  h.frame([hand({ index: true })])
  await flush()
  assert.ok(h.controller.metrics.failures >= 1, 'the failure must be counted')
  assert.ok(/PowerShell input worker/.test(h.controller.lastStatus), 'the real reason must be shown, got: ' + h.controller.lastStatus)
  assert.ok('failures' in h.controller.snapshotStatus().metrics)
})

test('a dead input worker stops the move flood', async () => {
  const h = harness()
  h.controller.mouseInput = { reported: true, ready: false, error: 'worker exited', supported: true }
  h.frame([hand({ index: true })])
  h.frame([shifted(hand({ index: true }), 0.06, 0)], null, 40)
  assert.strictEqual(h.calls.filter(of('move')).length, 0, 'no doomed requests while the worker is known dead')
})

test('the pointer is mapped into the bridge desktop, bottom row included', async () => {
  const h = harness()
  h.controller.pointer = { x: 0, y: 0 }
  assert.deepStrictEqual(h.controller.desktopPoint(), { x: 0, y: 0 })
  // A maximized window: the viewport IS the desktop, so the last visible row
  // must reach the last desktop row. screen.availHeight used to stop 40 px
  // short (the taskbar), which made the bottom of the screen unreachable.
  h.controller.pointer = { x: 1536, y: 864 }
  assert.deepStrictEqual(h.controller.desktopPoint(), { x: 1535, y: 863 })
  // A monitor left of the primary: the bridge origin is negative and must be
  // honoured instead of clamped to zero.
  h.controller.desktop = { left: -1920, top: 0, width: 3840, height: 1080 }
  h.controller.pointer = { x: 0, y: 0 }
  assert.deepStrictEqual(h.controller.desktopPoint(), { x: -1920, y: 0 })
  // No bridge geometry: the viewport fraction is the fallback, never a crash.
  h.controller.desktop = null
  h.controller.pointer = { x: 0, y: 0 }
  assert.deepStrictEqual(h.controller.desktopPoint(), { x: 0, y: 0 })
})

test('window control drives the real UIA ops and reports refusal honestly', async () => {
  const requests = []
  const h = harness()
  h.controller.ctx.uiRequest = (payload) => {
    requests.push(payload)
    return Promise.resolve(payload.op === 'windows'
      ? { ok: true, windows: [{ handle: 42, title: 'Qoder', minimized: false, maximized: true }] }
      : { ok: true, window: { handle: 42, title: 'Qoder', minimized: true } })
  }
  await h.controller.windowAction('minimize', 42)
  assert.deepStrictEqual(requests[0], { op: 'window', action: 'minimize', handle: 42 })
  assert.strictEqual(h.controller.lastAction.ok, true)
  assert.ok(/Qoder/.test(h.controller.lastAction.label))

  await h.controller.windowAction('move', 42)
  const move = requests.find((request) => request.action === 'move')
  assert.ok(move, 'a move must reach the bridge with the real action name')
  assert.ok(move.rect, 'a move must send desktop fractions, not pixels')
  for (const key of ['x', 'y', 'width', 'height']) {
    assert.ok(move.rect[key] > 0 && move.rect[key] <= 1, key + ' must be a 0..1 desktop fraction (' + move.rect[key] + ')')
  }
  assert.ok(Math.abs(move.rect.x - (1 - move.rect.width) / 2) < 0.01, 'the action labelled "to the centre" must actually centre the window')
  assert.ok(Math.abs(move.rect.y - (1 - move.rect.height) / 2) < 0.01, 'the action labelled "to the centre" must actually centre the window')
  assert.strictEqual(move.x, undefined, 'no absolute pixel may cross into UIA space')
  assert.strictEqual(move.width, undefined, 'no absolute pixel may cross into UIA space')
  assert.strictEqual(move.handle, 42)

  h.controller.ctx.uiRequest = () => Promise.resolve({ ok: false, error: 'UI Automation could not reach that window' })
  await h.controller.windowAction('maximize', 42)
  assert.strictEqual(h.controller.lastAction.ok, false, 'a refusal must be recorded as a failure')
  assert.ok(/could not reach/.test(h.controller.lastAction.detail))
})

test('the gesture action list exposes window control without close or terminate', () => {
  const actions = new Function('window', source + '\n;return window.__JARVIS_GESTURE_CONTROL__.ACTIONS')({ localStorage: null })
  for (const name of ['window_focus_uia', 'window_minimize_uia', 'window_maximize_uia', 'window_restore_uia', 'window_move_center']) {
    assert.ok(actions[name] && actions[name].label, name + ' must be a real, labelled action')
  }
  const names = Object.keys(actions).join(' ')
  assert.ok(!/close|kill|terminate|shutdown/i.test(names), 'no destructive window action may be exposed')
})

test('gesture control is local and deterministic: no network or AI call in the control loop', () => {
  const loop = source
  assert.ok(!/\bfetch\s*\(/.test(loop), 'the control loop must never issue an HTTP request')
  assert.ok(!/XMLHttpRequest|WebSocket|EventSource/.test(loop), 'the control loop must not open a socket')
  assert.ok(!/openai|gemini|groq|anthropic|api\.openai/i.test(loop), 'no AI provider may be called from the control loop')
})

// ── Overlay geometry and real-dispatch regressions ─────────────────────
// The canvas is a plain drawing surface here: these tests assert the exact
// pixels the shipped draw() asks for, plus the callbacks it does or does not
// fire before the bridge acknowledges an action.
const HAND_LINKS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20], [0, 17]
]

function recordingCanvas (width, height) {
  const ops = []
  const context = {
    setTransform: (...args) => ops.push({ op: 'setTransform', args }),
    clearRect: (...args) => ops.push({ op: 'clearRect', args }),
    save: () => {},
    restore: () => {},
    beginPath: () => {},
    moveTo: (x, y) => ops.push({ op: 'moveTo', x, y }),
    lineTo: (x, y) => ops.push({ op: 'lineTo', x, y }),
    stroke: () => ops.push({ op: 'stroke' }),
    arc: (x, y, r) => ops.push({ op: 'arc', x, y, r }),
    fill: () => ops.push({ op: 'fill' }),
    fillText: (text, x, y) => ops.push({ op: 'fillText', text, x, y }),
    lineCap: 'butt',
    shadowBlur: 0,
    shadowColor: '',
    strokeStyle: '',
    fillStyle: '',
    font: ''
  }
  const canvas = {
    width: 300,
    height: 150,
    cssWidth: width,
    cssHeight: height,
    getContext: () => context,
    getBoundingClientRect: () => ({ width: canvas.cssWidth, height: canvas.cssHeight })
  }
  return { canvas, ops, context }
}

function overlayHarness (options = {}) {
  const display = options.display || { width: 800, height: 500 }
  const frame = options.frame || { width: 1280, height: 720 }
  const dpr = options.dpr || 1
  const view = recordingCanvas(display.width, display.height)
  const panel = { querySelector: () => view.canvas }
  const video = {
    videoWidth: frame.width,
    videoHeight: frame.height,
    closest: () => panel,
    getClientRects: () => [{ width: display.width, height: display.height }]
  }
  const session = { textContent: '', dataset: {} }
  const clock = options.clock || { now: () => 0 }
  const win = {
    localStorage: null,
    devicePixelRatio: dpr,
    innerWidth: 1536,
    innerHeight: 864,
    HAND_CONNECTIONS: options.connections || HAND_LINKS,
    setTimeout: (fn) => { if (typeof fn === 'function') fn(); return 0 },
    requestAnimationFrame: () => 0,
    cancelAnimationFrame: () => {},
    addEventListener: () => {},
    document: {
      getElementById: (id) => id === 'gesture-session' ? session : null,
      querySelectorAll: (selector) => {
        if (selector.indexOf('canvas.gesture-canvas') === 0) return [view.canvas]
        return []
      },
      hasFocus: () => false,
      createElement: () => ({ style: {} }),
      body: { appendChild: () => {} },
      addEventListener: () => {}
    }
  }
  const control = new Function('window', 'performance', source + '\n;return window.__JARVIS_GESTURE_CONTROL__')(win, clock)
  const controller = control.create({ state: { bridgeOnline: false, cameraStream: null } })
  controller.video = video
  controller.panel = panel
  return { controller, win, video, canvas: view.canvas, ops: view.ops, session }
}

test('coverTransform reproduces the object-fit:cover crop for any aspect', () => {
  // 16:9 source in a 16:10 panel: height wins, sides are cropped.
  const wide = gesture.coverTransform(1280, 720, 800, 500)
  assert.ok(Math.abs(wide.scale - (500 / 720)) < 1e-12)
  assert.ok(Math.abs(wide.offsetX - ((800 - 1280 * (500 / 720)) / 2)) < 1e-9)
  assert.ok(Math.abs(wide.offsetY) < 1e-12)
  // Same aspect: no crop and no offset.
  const same = gesture.coverTransform(1280, 720, 800, 450)
  assert.ok(Math.abs(same.scale - 0.625) < 1e-12)
  assert.ok(Math.abs(same.offsetX) < 1e-12 && Math.abs(same.offsetY) < 1e-12)
  // Tall panel: width wins, top/bottom are cropped.
  const tall = gesture.coverTransform(1280, 720, 600, 600)
  assert.ok(Math.abs(tall.scale - (600 / 720)) < 1e-12)
  assert.ok(Math.abs(tall.offsetY - ((600 - 720 * (600 / 720)) / 2)) < 1e-12)
  // Nothing to map without a real size.
  assert.strictEqual(gesture.coverTransform(0, 720, 800, 500), null)
  assert.strictEqual(gesture.coverTransform(1280, 0, 800, 500), null)
  assert.strictEqual(gesture.coverTransform(1280, 720, 0, 500), null)
})

test('a known normalized landmark lands on the same pixel a covered video would', () => {
  const transform = gesture.coverTransform(1280, 720, 800, 500)
  const renderedWidth = 1280 * transform.scale
  const offsetX = (800 - renderedWidth) / 2
  const projected = gesture.projectLandmark({ x: 0.25, y: 0.5 }, transform, true)
  // Mirrored: the left-of-centre landmark appears right of centre.
  assert.ok(Math.abs(projected.x - (800 - (offsetX + 0.25 * renderedWidth))) < 1e-9)
  assert.ok(Math.abs(projected.y - (0.5 * 720 * transform.scale)) < 1e-9)
  // Centre stays centre under the mirror.
  const centre = gesture.projectLandmark({ x: 0.5, y: 0.5 }, transform, true)
  assert.ok(Math.abs(centre.x - 400) < 1e-9)
  assert.ok(Math.abs(centre.y - 250) < 1e-9)
})

test('mirrored and unmirrored mappings are exact mirror images', () => {
  const transform = gesture.coverTransform(1280, 720, 800, 500)
  for (const x of [0, 0.1, 0.25, 0.5, 0.9, 1]) {
    const mirrored = gesture.projectLandmark({ x, y: 0.3 }, transform, true)
    const plain = gesture.projectLandmark({ x, y: 0.3 }, transform, false)
    assert.ok(Math.abs((mirrored.x + plain.x) - 800) < 1e-9, 'x=' + x + ' must mirror inside the panel')
    assert.ok(Math.abs(mirrored.y - plain.y) < 1e-12, 'y must never be mirrored')
  }
  // The tracker's raw x is unmirrored; the pointer uses 1 - x. Both describe
  // the same physical hand, so a landmark at x=0.2 must project to the right
  // side of the panel and drive the cursor right of centre.
  const handPoint = { x: 0.2, y: 0.5 }
  assert.ok(gesture.projectLandmark(handPoint, transform, true).x > 400)
  assert.ok(gesture.mapToScreen([{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 },
    { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }, handPoint], null,
  { width: 800, height: 500 }, 1).x > 400)
})

test('draw() sizes the canvas from its displayed box and DPR, then resets the transform', () => {
  const h = overlayHarness({ display: { width: 726.421875, height: 453.25 }, dpr: 1.25 })
  h.controller.draw([{ side: 'right', lm: hand({ index: true }) }])
  assert.strictEqual(h.canvas.width, Math.round(726.421875 * 1.25))
  assert.strictEqual(h.canvas.height, Math.round(453.25 * 1.25))
  assert.deepStrictEqual(h.ops.find((op) => op.op === 'setTransform').args, [1.25, 0, 0, 1.25, 0, 0])
  assert.deepStrictEqual(h.ops.find((op) => op.op === 'clearRect').args, [0, 0, 726.421875, 453.25])
  // Resize the panel after the fact: the next frame follows the new box and
  // maps the index tip to the new pixels.
  h.canvas.cssWidth = 400
  h.canvas.cssHeight = 300
  h.ops.length = 0
  h.controller.draw([{ side: 'right', lm: hand({ index: true }) }])
  assert.strictEqual(h.canvas.width, 500)
  assert.strictEqual(h.canvas.height, 375)
  assert.deepStrictEqual(h.ops.find((op) => op.op === 'setTransform').args, [1.25, 0, 0, 1.25, 0, 0])
  const tip = h.ops.find((op) => op.op === 'arc' && op.r === 7)
  const t = gesture.coverTransform(1280, 720, 400, 300)
  const expected = gesture.projectLandmark(hand({ index: true })[8], t, true)
  assert.ok(Math.abs(tip.x - expected.x) < 1e-9 && Math.abs(tip.y - expected.y) < 1e-9)
})

test('repeated frames reset the DPR transform instead of accumulating it', () => {
  const h = overlayHarness({ dpr: 2 })
  for (let i = 0; i < 3; i += 1) h.controller.draw([{ side: 'right', lm: hand() }])
  const transforms = h.ops.filter((op) => op.op === 'setTransform')
  assert.strictEqual(transforms.length, 3)
  for (const transform of transforms) assert.deepStrictEqual(transform.args, [2, 0, 0, 2, 0, 0])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 63)
})

test('a drawn hand uses exactly 21 landmarks and the valid MediaPipe connections', () => {
  assert.strictEqual(HAND_LINKS.length, 21)
  for (const [a, b] of HAND_LINKS) {
    assert.ok(a >= 0 && a < 21 && b >= 0 && b < 21, 'connection indices must address the 21-point hand')
  }
  const h = overlayHarness()
  h.controller.draw([{ side: 'right', lm: hand({ index: true }) }])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 21)
  // Two passes (glow + core) over every connection, and nothing else.
  assert.strictEqual(h.ops.filter((op) => op.op === 'moveTo').length, HAND_LINKS.length * 2)
  assert.strictEqual(h.ops.filter((op) => op.op === 'lineTo').length, HAND_LINKS.length * 2)
  assert.strictEqual(h.ops.filter((op) => op.op === 'fillText').length, 1)
})

test('an out-of-range connection is skipped instead of reaching another hand', () => {
  const h = overlayHarness({ connections: [[0, 1], [20, 99], [0, 17]] })
  h.controller.draw([{ side: 'right', lm: hand() }])
  assert.strictEqual(h.ops.filter((op) => op.op === 'moveTo').length, 4, 'only the two valid pairs may be drawn')
})

test('two hands are two separate skeletons, never joined together', () => {
  const h = overlayHarness()
  const leftHand = hand({ index: true })
  const rightHand = shifted(hand({ index: true }), 0.3, 0)
  h.controller.draw([{ side: 'left', lm: leftHand }, { side: 'right', lm: rightHand }])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 42)
  const segments = []
  let pending = null
  for (const op of h.ops) {
    if (op.op === 'moveTo') pending = { x: op.x, y: op.y }
    if (op.op === 'lineTo' && pending) {
      segments.push([pending, { x: op.x, y: op.y }])
      pending = null
    }
  }
  assert.strictEqual(segments.length, 84, 'two passes over each hand\'s 21 connections')
  const transform = gesture.coverTransform(1280, 720, 800, 500)
  const leftPoints = leftHand.map((point) => gesture.projectLandmark(point, transform, true))
  const rightPoints = rightHand.map((point) => gesture.projectLandmark(point, transform, true))
  const belongs = (point, list) => list.some((candidate) => Math.hypot(point.x - candidate.x, point.y - candidate.y) < 1e-9)
  for (const [from, to] of segments) {
    const withinLeft = belongs(from, leftPoints) && belongs(to, leftPoints)
    const withinRight = belongs(from, rightPoints) && belongs(to, rightPoints)
    assert.ok(withinLeft || withinRight, 'a connection must stay inside the hand that owns it')
  }
})

test('a disappearing hand clears the overlay and a reappearing hand draws fresh', () => {
  const h = overlayHarness()
  h.controller.draw([{ side: 'right', lm: hand() }])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 21)
  h.ops.length = 0
  h.controller.draw([])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 0)
  assert.ok(h.ops.some((op) => op.op === 'clearRect'), 'an empty frame must erase the old skeleton')
  h.ops.length = 0
  h.controller.draw([{ side: 'right', lm: hand() }])
  assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 21, 'the next real hand must be drawn, not reused')
})

test('partial, non-finite and out-of-range landmarks are rejected', () => {
  const bad = [
    hand().slice(0, 20),
    hand().concat([{ x: 0.5, y: 0.5, z: 0 }]),
    Object.assign(hand(), {}),
    null
  ]
  bad[2][3] = { x: NaN, y: 0.5, z: 0 }
  bad.push((() => { const lm = hand(); lm[4] = { x: 4, y: 0.5, z: 0 }; return lm })())
  bad.push((() => { const lm = hand(); lm[5] = null; return lm })())
  for (const landmarks of bad) {
    const h = overlayHarness()
    h.controller.draw([{ side: 'right', lm: landmarks }])
    assert.strictEqual(h.ops.filter((op) => op.op === 'arc').length, 0, 'no dot may be drawn from an invalid set')
    assert.ok(h.ops.some((op) => op.op === 'clearRect'), 'the previous skeleton must still be cleared')
  }
})

test('a crossed pair keeps its previous sides when both labels collapse to one', () => {
  const previous = {
    left: { side: 'left', lm: shifted(hand({ index: true }), 0.3, 0) },
    right: { side: 'right', lm: hand({ index: true }) }
  }
  // The hands swapped screen positions (the user crossed them) and MediaPipe
  // reported the same label for both. The hand nearest the previous LEFT pose
  // must remain left, so the pointer does not jump between hands.
  const nowLeft = { side: 'left', lm: shifted(hand({ index: true }), 0.3, 0) }
  const nowRight = { side: 'left', lm: hand({ index: true }) }
  const resolved = gesture.resolveHandSides([nowRight, nowLeft], previous)
  assert.strictEqual(resolved.find((entry) => entry.lm[8].x > 0.5).side, 'left')
  assert.strictEqual(resolved.find((entry) => entry.lm[8].x < 0.5).side, 'right')
  // Without history the mirrored index tip decides: the user's left hand is
  // on the image right in an unmirrored frame.
  const geometric = gesture.resolveHandSides([
    { side: 'left', lm: shifted(hand({ index: true }), 0.3, 0) },
    { side: 'left', lm: hand({ index: true }) }
  ], null)
  assert.strictEqual(geometric.find((entry) => entry.lm[8].x > 0.5).side, 'left')
  // Distinct labels are already authoritative and must not be rewritten.
  const distinct = gesture.resolveHandSides([
    { side: 'right', lm: hand({ index: true }) },
    { side: 'left', lm: shifted(hand({ index: true }), 0.3, 0) }
  ], previous)
  assert.strictEqual(distinct[0].side, 'right')
  assert.strictEqual(distinct[1].side, 'left')
})

test('CLICK appears only after the bridge acknowledges the real Windows click', async () => {
  const pending = []
  const h = harness({ mouse: (body) => new Promise((resolve) => { pending.push({ body, resolve }) }) })
  h.controller.clickAtPointer('left', 'right')
  const click = pending.find((entry) => entry.body.action === 'lclick')
  assert.ok(click, 'the click must be sent through the bridge')
  assert.strictEqual(h.feedback.textContent, '', 'no success label may appear before the bridge answers')
  assert.strictEqual(h.controller.lastAction.ok, null, 'nothing may be claimed while the click is in flight')
  click.resolve({ ok: true, action: 'lclick' })
  await Promise.resolve()
  await Promise.resolve()
  assert.strictEqual(h.feedback.textContent, 'CLICK')
  assert.strictEqual(h.controller.lastAction.ok, true)
  assert.strictEqual(h.controller.metrics.failures, 0)
})

test('a refused click shows CLICK FAILED and records the real error', async () => {
  const pending = []
  const h = harness({ mouse: (body) => new Promise((resolve) => { pending.push({ body, resolve }) }) })
  h.controller.clickAtPointer('left', 'right')
  const click = pending.find((entry) => entry.body.action === 'lclick')
  assert.ok(click)
  click.resolve({ ok: false, error: 'mouse worker exited' })
  await Promise.resolve()
  await Promise.resolve()
  assert.strictEqual(h.feedback.textContent, 'CLICK FAILED')
  assert.strictEqual(h.controller.lastAction.ok, false)
  assert.ok(/mouse worker exited/.test(h.controller.lastAction.detail))
  assert.strictEqual(h.controller.metrics.failures, 1)
})

test('an offline bridge refuses a click visibly and never shows CLICK', () => {
  const h = harness()
  h.controller.state.bridgeOnline = false
  h.controller.clickAtPointer('left', 'right')
  assert.strictEqual(h.feedback.textContent, '')
  assert.ok(/Windows bridge is offline/i.test(h.toasts.join(' ')))
})

test('drag labels follow the real button events, not the pinch', async () => {
  const pending = []
  const h = harness({ mouse: (body) => new Promise((resolve) => { pending.push({ body, resolve }) }) })
  h.controller.beginDrag({ side: 'right' }, 'pinch hold')
  const down = pending.find((entry) => entry.body.action === 'ldown')
  assert.ok(down, 'the drag must press the real button through the bridge')
  assert.strictEqual(h.feedback.textContent, '', 'DRAG STARTED must wait for the real ldown')
  assert.ok(h.controller.drag, 'the drag state is held while the button request is in flight')
  down.resolve({ ok: true, action: 'ldown' })
  await Promise.resolve()
  await Promise.resolve()
  assert.strictEqual(h.feedback.textContent, 'DRAG STARTED')

  h.controller.releaseDrag('pinch released')
  const up = pending.find((entry) => entry.body.action === 'lup')
  assert.ok(up, 'releasing the pinch must release the real button')
  assert.strictEqual(h.feedback.textContent, 'DRAG STARTED', 'the release label waits for lup')
  up.resolve({ ok: true, action: 'lup' })
  await Promise.resolve()
  await Promise.resolve()
  assert.strictEqual(h.feedback.textContent, 'DRAG RELEASED')
})

test('tracking lost clears every overlay and says LOST, and a real frame recovers', () => {
  const h = overlayHarness()
  h.controller.active = true
  h.controller.draw([{ side: 'right', lm: hand() }])
  h.ops.length = 0
  h.controller.markTrackingLost('no landmarks for 2.4 s')
  assert.strictEqual(h.controller.trackingLost, true)
  assert.strictEqual(h.session.textContent, 'LOST')
  assert.strictEqual(h.session.dataset.state, 'lost')
  assert.deepStrictEqual(h.win.__JARVIS_HANDS__, [])
  assert.ok(h.ops.some((op) => op.op === 'setTransform' && op.args[0] === 1), 'the overlay is cleared with an identity transform')

  h.controller.onResults({
    multiHandLandmarks: [hand({ index: true })],
    multiHandedness: [{ label: 'Left', score: 0.95 }]
  })
  assert.strictEqual(h.controller.trackingLost, false)
  h.controller.updateUi(true)
  assert.strictEqual(h.session.textContent, 'LIVE')
  assert.strictEqual(h.session.dataset.state, 'live')
})

test('the loop watchdog declares loss only after real silence, not while frames flow', () => {
  const clock = { t: 0, now: () => clock.t }
  const h = overlayHarness({ clock })
  h.controller.active = true
  h.controller.startedAt = 1000
  // Before the first answer the tracker gets a longer grace period: a cold
  // WASM start is slow, and a premature LOST would be a lie.
  clock.t = 10500
  h.controller.loop()
  assert.strictEqual(h.controller.trackingLost, false, '9.5 s without a first result is still startup')
  clock.t = 11500
  h.controller.loop()
  assert.strictEqual(h.controller.trackingLost, true, '10.5 s without a first result is a real loss')
  assert.strictEqual(h.session.dataset.state, 'lost')

  // A real result clears the lost state...
  h.controller.onResults({ multiHandLandmarks: [], multiHandedness: [] })
  assert.strictEqual(h.controller.trackingLost, false)

  // ...and then 1.5 s of silence after a result is a loss again.
  h.controller.metrics.lastResultsAt = 11500
  clock.t = 12500
  h.controller.loop()
  assert.strictEqual(h.controller.trackingLost, false, '1 s of silence is normal frame jitter')
  clock.t = 13100
  h.controller.loop()
  assert.strictEqual(h.controller.trackingLost, true, '1.6 s without a result is a loss')
})

test('a tracker that throws is counted, never latches the frame gate and reports lost', () => {
  const h = overlayHarness()
  h.controller.active = true
  h.controller.startedAt = 0
  h.controller.tracker = { send: () => { throw new Error('tracker closed') } }
  h.controller.sendFrame()
  assert.strictEqual(h.controller.sending, false, 'a synchronous throw must release the frame gate')
  assert.strictEqual(h.controller.trackerFailures, 1)
  for (let i = 0; i < 10; i += 1) h.controller.sendFrame()
  assert.strictEqual(h.controller.trackingLost, false, 'eleven failures is not yet twelve')
  h.controller.sendFrame()
  assert.strictEqual(h.controller.trackingLost, true, 'twelve consecutive throws is a lost tracker')
  assert.strictEqual(h.session.dataset.state, 'lost')
})

runSuite()
