"""Read-only workspace MCP server for JARVIS Co-work.

Speaks newline-delimited JSON-RPC 2.0 over stdio and exposes bounded list/read/
search tools. Every path is resolved inside this repository; credentials, VCS
internals, dependency trees, virtual environments and artifact caches are denied.
No shell, writes, process control, network or arbitrary command support.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DENIED_PARTS = {".git", "node_modules", ".venv", "venv", "__pycache__", ".pytest_cache"}
DENIED_NAMES = {".env", ".dev.vars", "servers.json", "id_rsa", "id_ed25519"}
MAX_BYTES = 256 * 1024
MAX_RESULTS = 100
TOOLS = [
    {
        "name": "list_files",
        "description": "List files inside the JARVIS repository (read-only).",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string", "description": "Repo-relative directory"},
            "limit": {"type": "number", "description": "Maximum rows (1-100)"},
        }},
    },
    {
        "name": "read_file",
        "description": "Read bounded lines from a safe text file inside the repository.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string", "description": "Repo-relative file"},
            "max_lines": {"type": "number", "description": "Maximum lines (1-200)"},
        }, "required": ["path"]},
    },
    {
        "name": "search_text",
        "description": "Search safe text files inside the repository for a literal query.",
        "annotations": {"readOnlyHint": True, "destructiveHint": False},
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string"}, "path": {"type": "string"},
            "max_results": {"type": "number"},
        }, "required": ["query"]},
    },
]


def _safe_path(raw):
    try:
        target = (ROOT / str(raw or ".")).resolve()
        target.relative_to(ROOT)
    except (ValueError, OSError):
        return None
    parts = {part.lower() for part in target.parts}
    if parts & DENIED_PARTS or target.name.lower() in DENIED_NAMES:
        return None
    if target.is_file() and (target.suffix.lower() in {
            ".pem", ".key", ".pfx", ".p12", ".crt", ".cer"} or
            target.name.lower().startswith("id_")):
        return None
    return target


def _number(value, default, maximum):
    try:
        return max(1, min(int(value or default), maximum))
    except (TypeError, ValueError):
        return default


def _walk(target, skip_parts=()):
    denied = DENIED_PARTS | {str(part).lower() for part in skip_parts}
    if target.is_file():
        yield target
        return
    for path in sorted(target.rglob("*")):
        if not path.is_file() or any(part.lower() in denied for part in path.parts):
            continue
        safe = _safe_path(path.relative_to(ROOT))
        if safe is not None:
            yield safe


def _reply(request_id, result):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result}) + "\n")
    sys.stdout.flush()


def _text(request_id, message, is_error=False):
    _reply(request_id, {"content": [{"type": "text", "text": message}],
                       "isError": bool(is_error)})


def _handle(request_id, params):
    args = params.get("arguments") or {}
    name = params.get("name")
    if name == "list_files":
        target = _safe_path(args.get("path") or ".")
        if target is None or not target.exists():
            return _text(request_id, "path is blocked or outside the repository", True)
        limit = _number(args.get("limit"), 50, MAX_RESULTS)
        rows = [str(path.relative_to(ROOT)).replace("\\", "/") for path in _walk(target)]
        return _text(request_id, "\n".join(rows[:limit]) or "(no files)")
    if name == "read_file":
        target = _safe_path(args.get("path"))
        if target is None or not target.is_file():
            return _text(request_id, "file is blocked, missing, or outside the repository", True)
        try:
            if target.stat().st_size > MAX_BYTES:
                return _text(request_id, "file exceeds the 256 KiB MCP read limit", True)
            lines = target.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError as exc:
            return _text(request_id, "read failed: %s" % type(exc).__name__, True)
        count = _number(args.get("max_lines"), 40, 200)
        return _text(request_id, "\n".join(lines[:count]))
    if name == "search_text":
        query = str(args.get("query") or "")
        if not query or len(query) > 200:
            return _text(request_id, "query must contain 1-200 characters", True)
        target = _safe_path(args.get("path") or ".")
        if target is None or not target.exists():
            return _text(request_id, "path is blocked or outside the repository", True)
        limit = _number(args.get("max_results"), 20, MAX_RESULTS)
        rows = []
        needle = query.casefold()
        for path in _walk(target, skip_parts=("artifacts", "dist")):
            try:
                if path.stat().st_size > MAX_BYTES:
                    continue
                for number, line in enumerate(path.read_text(
                        encoding="utf-8", errors="ignore").splitlines(), 1):
                    if needle in line.casefold():
                        shown = str(path.relative_to(ROOT)).replace("\\", "/")
                        rows.append("%s:%d: %s" % (shown, number, line.strip()[:300]))
                        if len(rows) >= limit:
                            return _text(request_id, "\n".join(rows))
            except OSError:
                continue
        return _text(request_id, "\n".join(rows) or "(no matches)")
    return _text(request_id, "unknown tool: %s" % name, True)


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, request_id = message.get("method"), message.get("id")
        if method == "initialize":
            _reply(request_id, {"protocolVersion": "2024-11-05",
                                "capabilities": {"tools": {}},
                                "serverInfo": {"name": "jarvis-workspace", "version": "1.0.0"}})
        elif method == "tools/list":
            _reply(request_id, {"tools": TOOLS})
        elif method == "tools/call":
            _handle(request_id, message.get("params") or {})
        elif request_id is not None:
            _reply(request_id, {"error": {"code": -32601,
                        "message": "method not found: %s" % method}})


if __name__ == "__main__":
    main()

