"""Correction learner (Phase 1 of self-learning) - Sir's corrections become memory.

The honest mechanics of "self-learning" on this machine: JARVIS cannot retrain
model weights, and it should never pretend to. What it CAN do is make Sir's
corrections durable: "nahi, aise bolo", "aisa mat karo", "galat hai - tarika
ye hai" are STANDING ORDERS, not chat. This module:

  * classifies one utterance as a correction / instruction (deterministic,
    narrow regexes - a normal "nahi" reply is never a correction);
  * records it to artifacts/brain/learnings.json (on-device, bounded, no
    network) with a timestamp;
  * injects the recent standing orders into every brain prompt (via
    voice_engine._memory_context) so the very next reply obeys them;
  * reports what was learned so the learning stays auditable ("kya seekha").

Everything is additive: if this file is missing or unreadable, the old brain
behaviour is unchanged - a learning failure must never cost a working reply.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STORE = ROOT / "artifacts" / "brain" / "learnings.json"
MAX_ITEMS = 200
MAX_TEXT = 400

_LOCK = threading.RLock()

# A correction names the WRONG behaviour AND (usually) the desired one, or an
# explicit standing order. Deliberately narrow: "nahi karo" (a pending deny),
# "nahi bhejo" (a refusal verb) and "photo achhi nahi lagi" (an opinion) are
# NOT corrections, and a false standing order would poison every future reply.
_CORRECT_RE = [
    # "nahi, aise bolo" / "aisa mat karo" / "aise nahi, aise"
    re.compile(r"(?:ais[ae]|isi\s+tara[hk]|wais[ea])\s*(?:\w{0,6}\s*)?(?:mat|nahi|nar)\b", re.I),
    re.compile(r"(?:nahi|nahin)\s*[,]\s*ais[ae]\b", re.I),
    re.compile(r"(?:nahi|nahin)\s*[,:\s]+(?:ais[ae]|isi|wo|wahi)\b", re.I),
    # "galat ho gaya, wo aise kar" / "galat tarika"
    re.compile(r"\bgalat\b[^.?!]{0,60}?\b(?:ais[ae]|tareeka|tarika|sahi|wo|wahi)\b", re.I),
    # "nahi [2..6 words] bolo/karo/likho" - a HOW-fact follows the negation.
    # A bare one-word refusal ("nahi karo", "nahi bhejo") never matches, so a
    # pending deny is never mistaken for a standing order.
    re.compile(r"^nahi?[,:!\s]+(?=(?:\w+[,:\s]+){1,5}\b(?:bol|kar|kr|likh|dikh|chala)\w*)", re.I),
]
_INSTRUCT_RE = re.compile(r"^(?:yaad\s+rakh\w*|remember)\b", re.I)


def classify(text):
    """('correction'|'instruct'|None). Narrow on purpose - None is the default."""
    s = " ".join(str(text or "").split())
    if not s or len(s) > 2000:
        return None
    if _INSTRUCT_RE.match(s):
        return "instruct"
    if any(rx.search(s) for rx in _CORRECT_RE):
        return "correction"
    return None


def _load():
    try:
        if STORE.is_file():
            return json.loads(STORE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STORE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STORE)


def record(text, kind, reply=""):
    """One durable learning. Returns (ok, total). Bounded by MAX_ITEMS."""
    body = " ".join(str(text or "").split())[:MAX_TEXT]
    if not body:
        return (False, 0)
    with _LOCK:
        data = _load()
        items = data.get("items") or []
        items.append({"text": body, "kind": str(kind or "correction")[:16],
                      "at": time.strftime("%Y-%m-%d %H:%M:%S"),
                      "ts": time.time(),
                      "reply": " ".join(str(reply or "").split())[:160]})
        items = items[-MAX_ITEMS:]
        data["items"] = items
        data["updated_at"] = time.time()
        try:
            _save(data)
        except Exception:
            return (False, len(items))
        return (True, len(items))


def items_for_prompt(k=5):
    """The recent standing orders, newest application-relevant first.

    Corrections apply across topics, so recency beats similarity here - the
    list is short (bounded) and always visible to the brain.
    """
    with _LOCK:
        data = _load()
    out = []
    for item in reversed((data.get("items") or [])):
        text = str(item.get("text") or "").strip()
        if text:
            out.append("%s: %s" % (item.get("kind", "correction"), text))
        if len(out) >= max(1, int(k)):
            break
    return out


def prompt_line(k=5):
    """"Insert into the system prompt ('' when nothing has been learned)."""
    entries = items_for_prompt(k)
    if not entries:
        return ""
    return (" SIR'S STANDING CORRECTIONS (learned from his feedback - obey in "
            "every reply, never recite unless asked): %s"
            % "; ".join(entries))


def readoff():
    """What JARVIS actually learned - the audit trail, newest first."""
    with _LOCK:
        data = _load()
    entries = data.get("items") or []
    corrections = sum(1 for e in entries if e.get("kind") == "correction")
    instructs = sum(1 for e in entries if e.get("kind") == "instruct")
    latest = [str(e.get("text") or "")[:160] for e in reversed(entries[-3:])]
    return {"total": len(entries), "corrections": corrections,
            "instructs": instructs, "latest": latest, "path": str(STORE)}


def purge():
    """Test hook: forget everything (writes an empty store)."""
    with _LOCK:
        _save({"items": [], "updated_at": time.time()})
