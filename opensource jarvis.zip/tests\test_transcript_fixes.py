"""Tests for the fixes driven by the owner's live transcript (2026-10-19).

Every case below is a sentence the owner actually said and JARVIS got wrong:

  * "open notepad and explain your introduction in 5 lines"
        -> "'notepad and explain your introduction in' installed-app index mein
            nahi mila" (the whole sentence was treated as an app name)
  * "open youtbe"
        -> "'youtbe' installed-app index mein nahi mila" (a one-letter STT slip)
  * "open youtube and search minecraft ep 1"
        -> searched YouTube for "and minecraft ep 1"
  * "baatao kisi na name and number saved kiye hoo"
        -> "Sir, noted -" followed by Hindi drift, from the chat brain
  * "notepad me kya likha hai"
        -> no answer, because the typed string is not what is on screen

These need no screen: every UIA/window object is a fake, and the on-screen read
is exercised against real Notepad only in tests/test_screen_readback.py.
"""
import importlib.util
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


# Every test run targets a THROWAWAY ledger/recipes store - the owner's live
# artifacts/brain/*.json must never be written or wiped by a test process.
import os as _os, tempfile as _tempfile
_os.environ.setdefault("JARVIS_RESULTS_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_results.json"))
_os.environ.setdefault("JARVIS_ROUTINES_STORE", _os.path.join(
    _tempfile.gettempdir(), "jarvis_test_routines.json"))
sys.path.insert(0, str(ROOT / "background"))


def _load(key, rel):
    spec = importlib.util.spec_from_file_location(key, Path(ROOT) / Path(rel))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


VE = _load("voice_engine_tx19", "background/voice_engine.py")


class AppNounExtractionTest(unittest.TestCase):
    """A second instruction is not part of the app name."""

    def _target(self, text):
        return VE._strict_launch_target(text.casefold().strip())

    def test_write_clause_is_not_swallowed_into_the_app_name(self):
        self.assertEqual(self._target("open notepad and write an essay in 3 lines"),
                         "notepad")

    def test_explain_clause_is_not_swallowed_into_the_app_name(self):
        self.assertEqual(self._target("open notepad and explain your introduction in 5 lines"),
                         "notepad")

    def test_search_clause_is_not_swallowed_into_the_app_name(self):
        self.assertEqual(self._target("open youtube and search minecraft ep 1"),
                         "youtube")

    def test_plain_launches_still_work(self):
        for text, want in (("open notepad", "notepad"), ("open chrome", "chrome"),
                           ("open file explorer", "file explorer"),
                           ("open task manager", "task manager"),
                           ("open calculator", "calculator")):
            self.assertEqual(self._target(text), want, text)

    def test_stt_loop_still_extracts_one_noun(self):
        self.assertEqual(self._target("open notepad, zirvis, press open notepad"),
                         "notepad")

    def test_close_and_click_phrases_still_do_not_launch(self):
        self.assertEqual(self._target("close notepad"), "")
        self.assertEqual(self._target("click notepad"), "")


class TypoToleranceTest(unittest.TestCase):
    """A transcript one or two letters off a known app is the same request."""

    def test_youtube_misspellings_are_recognised(self):
        for typo in ("youtbe", "youtub", "utube"):
            self.assertEqual(VE._strict_launch_target("open " + typo),
                             "youtube", typo)

    def test_youtube_site_route_accepts_the_same_typos(self):
        for typo in ("youtbe", "youtub", "utube"):
            self.assertTrue(VE._YT_SITE_RE.search(typo), typo)

    def test_typo_tolerance_does_not_match_arbitrary_words(self):
        for word in ("notebook", "youtubeer", "rouTube"):
            # Not a launch target; recognition must stay narrow.
            self.assertNotEqual(VE._strict_launch_target("open " + word),
                                "youtube", word)


class YouTubeQueryTest(unittest.TestCase):
    """The search must contain the query, not the conjunction that introduced it."""

    def test_and_is_not_part_of_the_query(self):
        self.assertEqual(VE._youtube_query("open youtube and search minecraft ep 1"),
                         "minecraft ep 1")

    def test_query_after_the_site_still_works(self):
        self.assertEqual(VE._youtube_query("youtbe pe minecraft search karo"),
                         "minecraft")

    def test_plain_open_has_no_query(self):
        self.assertIsNone(VE._youtube_query("open youtbe"))


class SavedContactsRouteTest(unittest.TestCase):
    """"batao kis ka number save kiya hai" must not reach the chat brain."""

    ASK = [
        "baatao kisi na name and number saved kiye hoo",
        "batao kis ka number save kiya hai",
        "mere saved contacts batao",
        "kaun ka number saved hai",
        "list karo saved numbers",
        "kiska number yaad rakha hai",
        "saved number list do",
        "contacts ki list dikhao",
    ]

    def test_every_owner_phrasing_is_recognised(self):
        for ask in self.ASK:
            self.assertTrue(VE._WA_LIST_ASK_RE.search(ask), ask)

    def test_a_real_send_is_never_stolen(self):
        for send in ("akhilesh ko hello bhejo",
                     "whatsapp pe amit ko hello bhejo",
                     "kya kar rahe ho bhejo akhilesh ko",
                     "hello message bhejo"):
            self.assertIsNone(VE._WA_LIST_ASK_RE.search(send), send)

    def test_the_answer_is_the_honest_no_book_line(self):
        said = VE._wa_list_reply(None)
        self.assertIn("contact book ab nahi hai", said)
        self.assertIn("naam", said)
        self.assertNotIn("919", said)
        self.assertNotIn("saved hai", said)

    def test_it_never_invents_any_number(self):
        sender = mock.Mock()
        sender.list_contacts.return_value = [("ghost", "919812345678")]
        said = VE._wa_list_reply(sender)
        self.assertNotIn("919812345678", said,
                         "the number book no longer exists - no number is spoken")


class ScreenReadBackRouteTest(unittest.TestCase):
    """'notepad me kya likha hai' is answered from the real window."""

    ASK = ["notepad me kya likha hai", "notepad mein kya likha hai",
           "kya likha hai notepad me", "screen par kya hai",
           "notepad me kya hai", "kitna likha hai", "ye text padh do"]

    def test_owner_phrasings_route_to_read_back(self):
        for ask in self.ASK:
            self.assertTrue(VE._READ_ASK_RE.search(ask), ask)

    def test_it_does_not_steal_unrelated_commands(self):
        for other in ("akhilesh ko hello bhejo",
                      "open youtube and search minecraft ep 1",
                      "notepad kholo", "timer lagao 5 minute",
                      "screenshot lo"):
            self.assertIsNone(VE._READ_ASK_RE.search(other), other)

    def test_the_module_loads_and_reports_availability(self):
        rb = VE._screen_readback()
        self.assertIsNotNone(rb)
        ok, why = rb.available()
        self.assertTrue(ok, why)


if __name__ == "__main__":
    unittest.main()