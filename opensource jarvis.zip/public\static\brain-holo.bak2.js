/* JARVIS Brain — DIRECT PORT of BrainCanvas.tsx (4200 pts, 8 centroids, 36 pulses) */
(()=>{const SUBSYSTEMS={
    vision: {id:'vision',title:'vision',subtitle:'Camera • Screen • Image',providers:'Gemini / Groq / NVIDIA',color:'#06b6d4',lobeRegion:'Occipital Lobe & Visual Cortex',clusterPosition:[0.9, 0.2, -1.2]},
    language: {id:'language',title:'language',subtitle:'Conversation • Translation',providers:'Groq / Gemini / xKiro',color:'#10b981',lobeRegion:'Temporal Lobe & Broca / Wernicke Area',clusterPosition:[-1.4, -0.3, 0.2]},
    memory: {id:'memory',title:'memory',subtitle:'Long-term • Context • Facts',providers:'ChromaDB + SQLite + Mem0',color:'#a855f7',lobeRegion:'Hippocampus & Limbic Core',clusterPosition:[0.0, -0.7, -0.1]},
    planning: {id:'planning',title:'planning',subtitle:'Task Analysis • Decision',providers:'Qwen / Mixtral / NVIDIA',color:'#f59e0b',lobeRegion:'Prefrontal Cortex (Executive Hub)',clusterPosition:[-0.9, 0.8, 1.1]},
    audio: {id:'audio',title:'audio',subtitle:'Speech • STT • TTS',providers:'Whisper + Piper / Edge-TTS',color:'#ef4444',lobeRegion:'Superior Temporal Gyrus (Auditory Cortex)',clusterPosition:[1.4, -0.3, 0.2]},
    tools: {id:'tools',title:'tools',subtitle:'Browser • Files • Apps',providers:'Claude / OpenRouter / n8n',color:'#0ea5e9',lobeRegion:'Parietal Lobe (Tool Manipulation Network)',clusterPosition:[0.8, 0.9, -0.5]},
    coding: {id:'coding',title:'coding',subtitle:'Code • Debug • Git',providers:'Qwen / Gemini / DeepSeek',color:'#8b5cf6',lobeRegion:'Left Hemisphere Angular Gyrus (Symbolic Logic)',clusterPosition:[-0.6, 0.4, -0.9]},
    computer_use: {id:'computer_use',title:'computer_use',subtitle:'Mouse • Keyboard • OS',providers:'Agent-S / Playwright / Bridge',color:'#14b8a6',lobeRegion:'Primary Motor Cortex & Cerebellum',clusterPosition:[0.0, -1.1, -1.2]},
  };
  SUBSYSTEMS.vision.title='Vision';SUBSYSTEMS.language.title='Language';SUBSYSTEMS.memory.title='Memory';SUBSYSTEMS.planning.title='Planning';SUBSYSTEMS.audio.title='Audio';SUBSYSTEMS.tools.title='Tools';SUBSYSTEMS.coding.title='Coding';SUBSYSTEMS.computer_use.title='Computer Use';
  const CAPS=Object.values(SUBSYSTEMS).map(s=>({id:s.id,label:s.title,color:s.color}));
  const LOBE_TO_CAP={prefrontal_cortex:'planning',cerebrum:'coding',motor_cortex:'tools',hippocampus:'memory',broca_area:'audio',vision:'vision',language:'language',memory:'memory',planning:'planning',audio:'audio',tools:'tools',coding:'coding',computer_use:'computer_use'};
  const LOBE_COLOR={prefrontal_cortex:'#f59e0b',cerebrum:'#8b5cf6',motor_cortex:'#0ea5e9',hippocampus:'#a855f7',broca_area:'#ef4444',vision:'#06b6d4',language:'#10b981',memory:'#a855f7',planning:'#f59e0b',audio:'#ef4444',tools:'#0ea5e9',coding:'#8b5cf6',computer_use:'#14b8a6'};
  const DEFAULT_COLOR='#06b6d4';
  let THREE=null,wrap=null,container=null,scene=null,camera=null,renderer=null;
  let brainRoot=null,pointsMesh=null,linesGroup=null,pulsesGroup=null,centroidsGroup=null,reticlesGroup=null;
  let nodes=[],centroidMeshes=new Map(),fiberCurves=[],pulseSpheres=[],originalPositions=null;
  let explodeAmount=0,isExploded=false,isRotating=true,reduceMotion=false;
  let isDragging=false,prevMouse={x:0,y:0},rotationVel={x:0,y:0.002},targetCamPos=null;
  let clock=null,raf=0,initialized=false,ro=null,selectedSubsystemId=null,activeLobe='prefrontal_cortex',activeColor=DEFAULT_COLOR,hoveredNode=null;
  const getThree=()=>window.__JARVIS_THREE__||null;
  function ensureDom(){wrap=document.getElementById('brain-canvas-wrap');if(!wrap)return false;if(!container){container=document.createElement('div');container.id='brain-holo-mount';container.style.cssText='position:absolute;inset:0;z-index:1;width:100%;height:100%;cursor:grab';wrap.appendChild(container);wrap.classList.add('brain-holo-ready');const c=document.getElementById('brain-canvas');if(c)c.style.display='none';}return true;}

// ---- generateBrainGeometry EXACT from zip (4200 pts) ----
function generateBrainGeometry() {
  const pointsCount = 4200;
  const positions = [];
  const colors = [];
  const nodes = [];

  // Register centroid nodes for the 8 JARVIS subsystems
  Object.values(SUBSYSTEMS).forEach((sub) => {
    const [cx, cy, cz] = sub.clusterPosition;
    nodes.push({
      id: `node-${sub.id}-centroid`,
      label: sub.title,
      subsystemId: sub.id,
      position: [cx, cy, cz],
      color: sub.color,
      size: 0.16,
      activityLevel: 0.95,
      isCentroid: true,
      connections: [],
      description: `${sub.title} neural processing hub (${sub.lobeRegion})`,
    });
  });

  // Interconnect centroids into a coherent neural graph
  const centroidList = nodes.filter((n) => n.isCentroid);
  for (let i = 0; i < centroidList.length; i++) {
    for (let j = i + 1; j < centroidList.length; j++) {
      centroidList[i].connections.push(centroidList[j].id);
      centroidList[j].connections.push(centroidList[i].id);
    }
  }

  // Generate thousands of cortical surface and deep neural points
  for (let i = 0; i < pointsCount; i++) {
    // Hemispheric separation: left hemisphere (u < 0.5) vs right (u >= 0.5)
    const isLeft = Math.random() < 0.5;
    const hemiSign = isLeft ? -1 : 1;

    // Spherical coordinates
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);

    // Base brain dimensions (ellipsoid stretched along Z-axis)
    const rx = 1.15;
    const ry = 0.95;
    const rz = 1.45;

    // Cortex gyri & sulci undulating waves
    const gyrusFolds =
      1 +
      0.09 * Math.sin(theta * 7) * Math.cos(phi * 9) +
      0.05 * Math.sin(phi * 16) +
      0.04 * Math.cos(theta * 12);

    let x = rx * Math.sin(phi) * Math.cos(theta) * gyrusFolds;
    let y = ry * Math.sin(phi) * Math.sin(theta) * gyrusFolds;
    let z = rz * Math.cos(phi) * gyrusFolds;

    // Hemispheric split: push apart laterally and pinch medial longitudinal fissure
    x = hemiSign * (0.07 + Math.abs(x) * 0.94);

    // Anatomical shaping:
    // 1. Flatten bottom, taper cerebellum and brainstem
    if (y < -0.3 && z < -0.3) {
      // Cerebellum bulge
      y = y * 0.9 - 0.2;
      x = x * 0.85;
    }
    if (y < -0.7 && Math.abs(x) < 0.4 && z > -0.5 && z < 0.2) {
      // Brainstem stalk
      x = x * 0.45;
      z = z * 0.5 - 0.1;
    }
    // 2. Prefrontal cortex curvature
    if (z > 0.8) {
      y = y * 0.95;
      x = x * 0.92;
    }

    // Assign to nearest subsystem cluster for coloring
    let nearestSub = SUBSYSTEMS.planning;
    let minDistance = Infinity;

    Object.values(SUBSYSTEMS).forEach((sub) => {
      const [cx, cy, cz] = sub.clusterPosition;
      const dist = Math.hypot(x - cx, y - cy, z - cz);
      if (dist < minDistance) {
        minDistance = dist;
        nearestSub = sub;
      }
    });

    positions.push(x, y, z);

    // Color gradient blending
    const baseColor = new THREE.Color(nearestSub.color);
    // Subtle bioluminescent variation
    baseColor.offsetHSL(0, (Math.random() - 0.5) * 0.15, (Math.random() - 0.5) * 0.2);
    colors.push(baseColor.r, baseColor.g, baseColor.b);

    // Sample occasional secondary synapse nodes
    if (i % 60 === 0) {
      nodes.push({
        id: `node-synapse-${i}`,
        label: `${nearestSub.title} Synapse #${i}`,
        subsystemId: nearestSub.id,
        position: [x, y, z],
        color: nearestSub.color,
        size: 0.08,
        activityLevel: 0.5 + Math.random() * 0.4,
        connections: [`node-${nearestSub.id}-centroid`],
      });
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

  const material = new THREE.PointsMaterial({
    size: 0.045,
    vertexColors: true,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
  });

  const pointsMesh = new THREE.Points(geometry, material);

  return {
    pointsMesh,
    nodes,
    originalPositions: new Float32Array(positions),
  };
}
  function buildScene(){
    THREE=getThree(); if(!THREE) return false;
    if(!ensureDom()) return false;
    reduceMotion=!!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    const W=Math.max(320,Math.round(wrap.getBoundingClientRect().width)||640);
    const H=Math.max(300,Math.round(wrap.getBoundingClientRect().height)||520);
    scene=new THREE.Scene(); scene.fog=new THREE.FogExp2(0x020617,0.06);
    camera=new THREE.PerspectiveCamera(45,W/H,0.1,100); camera.position.set(0,0.4,5.2);
    targetCamPos=new THREE.Vector3(0,0.4,5.2);
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
    renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
    renderer.setClearColor(0x000000,0);
    container.innerHTML=''; container.appendChild(renderer.domElement);
    renderer.domElement.style.width='100%'; renderer.domElement.style.height='100%'; renderer.domElement.style.display='block';
    brainRoot=new THREE.Group(); scene.add(brainRoot);
    const genR=generateBrainGeometry(); pointsMesh=genR.pointsMesh; nodes=genR.nodes; originalPositions=genR.originalPositions;
    brainRoot.add(pointsMesh);
    linesGroup=new THREE.Group(); brainRoot.add(linesGroup);
    pulsesGroup=new THREE.Group(); brainRoot.add(pulsesGroup);
    centroidsGroup=new THREE.Group(); brainRoot.add(centroidsGroup);
    centroidMeshes=new Map();
    nodes.forEach(node=>{
      if(node.isCentroid){
        const sub=SUBSYSTEMS[node.subsystemId];
        const geom=new THREE.SphereGeometry(0.12,16,16);
        const mat=new THREE.MeshBasicMaterial({color:new THREE.Color(sub.color),transparent:true,opacity:0.9,wireframe:true});
        const mesh=new THREE.Mesh(geom,mat); mesh.position.set(...node.position);
        mesh.userData={nodeId:node.id,subsystemId:node.subsystemId,node}; centroidsGroup.add(mesh); centroidMeshes.set(node.id,mesh);
        const ringGeom=new THREE.RingGeometry(0.14,0.18,24);
        const ringMat=new THREE.MeshBasicMaterial({color:new THREE.Color(sub.color),side:THREE.DoubleSide,transparent:true,opacity:0.5});
        const ring=new THREE.Mesh(ringGeom,ringMat); ring.position.set(...node.position); centroidsGroup.add(ring);
      }
    });
    fiberCurves=[];
    nodes.forEach(n1=>{
      n1.connections.forEach(connId=>{
        const n2=nodes.find(n=>n.id===connId);
        if(n2 && n1.id < n2.id){
          const p1=new THREE.Vector3(...n1.position),p2=new THREE.Vector3(...n2.position);
          const mid=new THREE.Vector3().addVectors(p1,p2).multiplyScalar(0.5);
          mid.y+=(Math.random()-0.5)*0.3; mid.x*=0.7; mid.z*=0.8;
          const curve=new THREE.CatmullRomCurve3([p1,mid,p2]);
          fiberCurves.push({curve,subsystemId:n1.subsystemId});
          const pts=curve.getPoints(24);
          const lineGeom=new THREE.BufferGeometry().setFromPoints(pts);
          const sub=SUBSYSTEMS[n1.subsystemId];
          const lineMat=new THREE.LineBasicMaterial({color:new THREE.Color(sub.color),transparent:true,opacity:0.28,blending:THREE.AdditiveBlending});
          const line=new THREE.Line(lineGeom,lineMat); linesGroup.add(line);
        }
      });
    });
    pulseSpheres=[];
    const pulseGeom=new THREE.SphereGeometry(0.04,8,8);
    for(let i=0;i<36&&fiberCurves.length>0;i++){
      const {curve,subsystemId}=fiberCurves[i%fiberCurves.length];
      const sub=SUBSYSTEMS[subsystemId];
      const pMat=new THREE.MeshBasicMaterial({color:new THREE.Color(sub.color),transparent:true,opacity:0.95});
      const pMesh=new THREE.Mesh(pulseGeom,pMat); pulsesGroup.add(pMesh);
      pulseSpheres.push({mesh:pMesh,curve,progress:Math.random(),speed:0.003+Math.random()*0.007});
    }
    reticlesGroup=new THREE.Group(); scene.add(reticlesGroup);
    const r1=new THREE.Mesh(new THREE.RingGeometry(2.4,2.45,64),new THREE.MeshBasicMaterial({color:0x06b6d4,side:THREE.DoubleSide,transparent:true,opacity:0.22}));
    r1.rotation.x=Math.PI/2; r1.position.y=-1.6; reticlesGroup.add(r1);
    const r2=new THREE.Mesh(new THREE.RingGeometry(3.1,3.12,64),new THREE.MeshBasicMaterial({color:0x0ea5e9,side:THREE.DoubleSide,transparent:true,opacity:0.15}));
    r2.rotation.x=Math.PI/2; r2.position.y=-1.6; reticlesGroup.add(r2);
    const axisMat=new THREE.LineBasicMaterial({color:0x06b6d4,transparent:true,opacity:0.15});
    const ax=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-3.2,-1.6,0),new THREE.Vector3(3.2,-1.6,0)]);
    const az=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,-1.6,-3.2),new THREE.Vector3(0,-1.6,3.2)]);
    reticlesGroup.add(new THREE.Line(ax,axisMat)); reticlesGroup.add(new THREE.Line(az,axisMat));
    const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();
    function onMove(e){
      const rect=container.getBoundingClientRect(); const cx=e.clientX-rect.left,cy=e.clientY-rect.top;
      mouse.x=(cx/rect.width)*2-1; mouse.y=-(cy/rect.height)*2+1;
      raycaster.setFromCamera(mouse,camera);
      const hits=raycaster.intersectObjects(centroidsGroup.children);
      if(hits.length>0 && hits[0].object.userData && hits[0].object.userData.node){
        const node=hits[0].object.userData.node; const sub=SUBSYSTEMS[node.subsystemId];
        hoveredNode=node; container.style.cursor='pointer';
        const tip=document.getElementById('brain-tooltip');
        if(tip){ tip.innerHTML='<strong style="color:'+sub.color+'">'+node.label+'</strong><br><small>'+sub.lobeRegion+'</small><br><small style="color:#5ee">Click to inspect</small>'; tip.style.left=(e.clientX+12)+'px'; tip.style.top=(e.clientY-28)+'px'; tip.style.position='fixed'; tip.style.zIndex='50'; tip.style.background='rgba(2,6,23,0.92)'; tip.style.border='1px solid '+sub.color+'80'; tip.style.padding='6px 10px'; tip.style.borderRadius='8px'; tip.style.fontSize='11px'; tip.hidden=false; }
        return;
      }
      hoveredNode=null; container.style.cursor=isDragging?'grabbing':'grab'; const t=document.getElementById('brain-tooltip'); if(t) t.hidden=true;
    }
    container.addEventListener('mousemove',onMove);
    container.addEventListener('mouseleave',()=>{ hoveredNode=null; const t=document.getElementById('brain-tooltip'); if(t) t.hidden=true; container.style.cursor='grab'; });
    container.addEventListener('mousedown',e=>{ isDragging=true; prevMouse={x:e.clientX,y:e.clientY}; container.style.cursor='grabbing'; });
    window.addEventListener('mouseup',()=>{ isDragging=false; if(container) container.style.cursor='grab'; });
    container.addEventListener('mousemove',e=>{
      if(!isDragging||!brainRoot) return;
      const dx=e.clientX-prevMouse.x,dy=e.clientY-prevMouse.y;
      brainRoot.rotation.y+=dx*0.007; brainRoot.rotation.x+=dy*0.007;
      rotationVel={x:dy*0.002,y:dx*0.002}; prevMouse={x:e.clientX,y:e.clientY};
    });
    container.addEventListener('wheel',e=>{
      e.preventDefault(); const d=e.deltaY*0.003; const dir=targetCamPos.clone().normalize();
      const len=THREE.MathUtils.clamp(targetCamPos.length()+d,1.8,8.5);
      targetCamPos=dir.multiplyScalar(len);
    },{passive:false});
    container.addEventListener('click',e=>{
      const rect=container.getBoundingClientRect();
      const x=((e.clientX-rect.left)/rect.width)*2-1,y=-((e.clientY-rect.top)/rect.height)*2+1;
      const rc=new THREE.Raycaster(); rc.setFromCamera(new THREE.Vector2(x,y),camera);
      const hs=rc.intersectObjects(centroidsGroup.children);
      if(hs.length>0 && hs[0].object.userData && hs[0].object.userData.subsystemId){
        selectSubsystem(hs[0].object.userData.subsystemId,hs[0].object.userData.node);
        try{ window.__JARVIS_BRAIN_SELECT__&&window.__JARVIS_BRAIN_SELECT__(hs[0].object.userData.subsystemId);}catch{}
      }
    });
    window.addEventListener('resize',()=>{
      if(!container||!renderer||!camera) return;
      const w=container.clientWidth,h=container.clientHeight;
      camera.aspect=w/h; camera.updateProjectionMatrix(); renderer.setSize(w,h);
    });
    if(typeof ResizeObserver==='function' && !ro){
      ro=new ResizeObserver(()=>{
        if(!renderer||!camera||!container) return;
        const r=wrap.getBoundingClientRect(); const ww=Math.max(320,Math.round(r.width)||640),hh=Math.max(300,Math.round(r.height)||520);
        renderer.setSize(ww,hh,false); camera.aspect=ww/hh; camera.updateProjectionMatrix();
      }); ro.observe(wrap);
    }
    clock=new THREE.Clock(); initialized=true; return true;
  }
  function selectSubsystem(id,node){
    selectedSubsystemId=id;
    if(pointsMesh){ const m=pointsMesh.material; const o=m.size; m.size=0.08; setTimeout(()=>m.size=o,300); }
    centroidMeshes.forEach((mesh,key)=>{ const sel=key===('node-'+id+'-centroid'); mesh.scale.setScalar(sel?1.35:1); mesh.material.opacity=sel?1:0.9; });
  }
  function setBrain(brain){
    const lobe=String((brain&&brain.lobe)||'prefrontal_cortex').toLowerCase();
    activeLobe=LOBE_COLOR[lobe]?lobe:'prefrontal_cortex'; activeColor=LOBE_COLOR[activeLobe]||DEFAULT_COLOR;
    try{ window.__BRAIN_LAST__=brain||window.__BRAIN_LAST__||null;}catch{}
    const cap=LOBE_TO_CAP[lobe]||lobe;
    if(SUBSYSTEMS[cap]) selectSubsystem(cap,null);
    if(pointsMesh){ const m=pointsMesh.material; const o=m.size; m.size=0.08; setTimeout(()=>m.size=o,360); }
  }
  function setAuto(v){ isRotating=!!v; }
  function setExploded(v){ isExploded=!!v; }
  function reset(){ targetCamPos=new THREE.Vector3(0,0.4,5.2); if(brainRoot) brainRoot.rotation.set(0,0,0); if(camera) camera.position.set(0,0.4,5.2); }
  function animate(){
    cancelAnimationFrame(raf);
    const loop=()=>{
      raf=requestAnimationFrame(loop);
      if(!clock||!scene||!camera||!renderer) return;
      const time=clock.getElapsedTime();
      const tgt=isExploded?0.75:0; explodeAmount=THREE.MathUtils.lerp(explodeAmount,tgt,0.08);
      if(pointsMesh && originalPositions){
        const arr=pointsMesh.geometry.attributes.position.array;
        for(let i=0;i<originalPositions.length;i+=3){ const f=1+explodeAmount*0.45; arr[i]=originalPositions[i]*f; arr[i+1]=originalPositions[i+1]*f; arr[i+2]=originalPositions[i+2]*f; }
        pointsMesh.geometry.attributes.position.needsUpdate=true;
      }
      if(camera) camera.position.lerp(targetCamPos,0.05);
      if(brainRoot){
        if(!isDragging && isRotating) brainRoot.rotation.y+=0.0035;
        else { brainRoot.rotation.y+=rotationVel.y; brainRoot.rotation.x+=rotationVel.x; rotationVel.y*=0.94; rotationVel.x*=0.94; }
      }
      if(reticlesGroup) reticlesGroup.rotation.y-=0.001;
      pulseSpheres.forEach(p=>{ p.progress+=p.speed; if(p.progress>1) p.progress=0; const pt=p.curve.getPoint(p.progress); const f=1+explodeAmount*0.45; p.mesh.position.set(pt.x*f,pt.y*f,pt.z*f); const s=0.8+Math.sin(time*8+p.progress*10)*0.3; p.mesh.scale.set(s,s,s); });
      centroidMeshes.forEach(m=>{ const s=1+Math.sin(time*3+m.position.x*2)*0.08; m.scale.set(s,s,s); });
      renderer.render(scene,camera);
    }; loop();
  }
  function initIfNeeded(){ if(initialized) return; const ok=buildScene(); if(!ok){ setTimeout(initIfNeeded,200); return; } animate(); }
  window.__JARVIS_BRAIN_HOLO__={init:initIfNeeded,setBrain,setAuto,reset,setExploded,isReady:()=>initialized,get activeLobe(){return activeLobe},get activeColor(){return activeColor},get hoverId(){return hoveredNode?hoveredNode.id:null},get pinnedId(){return selectedSubsystemId},set pinnedId(v){selectedSubsystemId=v;},CAPS,LOBE_TO_CAP,LOBE_COLOR,SUBSYSTEMS,_onSelect:null};
  window.__brainHoloDraw=setBrain; window.__JARVIS_BRAIN_SELECT__=selectSubsystem;
  const explodeButton=document.getElementById('brain-explode');
  if(explodeButton) explodeButton.addEventListener('click',()=>{ const exploded=explodeButton.getAttribute('aria-pressed')!=='true'; explodeButton.setAttribute('aria-pressed',String(exploded)); explodeButton.classList.toggle('active',exploded); setExploded(exploded); });
  function whenReady(cb){ if(getThree()) cb(); else window.addEventListener('jarvis:three-ready',cb,{once:true}); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>whenReady(initIfNeeded),{once:true}); else whenReady(initIfNeeded);
})();
