/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SubsystemId =
  | 'vision'
  | 'language'
  | 'memory'
  | 'planning'
  | 'audio'
  | 'tools'
  | 'coding'
  | 'computer_use';

export interface SubsystemInfo {
  id: SubsystemId;
  title: string;
  subtitle: string;
  providers: string;
  color: string;
  glowColor: string;
  accentBg: string;
  borderColor: string;
  lobeRegion: string;
  status: 'active' | 'idle' | 'standby' | 'processing';
  models: string[];
  description: string;
  registeredTools: string[];
  recentAction: string;
  latencyMs: number;
  position: 'left' | 'right';
  clusterPosition: [number, number, number];
  synapticRateHz: number;
  dataFlowRateMBs: number;
}

export interface BrainNode {
  id: string;
  label: string;
  subsystemId: SubsystemId;
  position: [number, number, number];
  color: string;
  size: number;
  activityLevel: number;
  isCentroid?: boolean;
  connections: string[];
  description?: string;
  activePulse?: number;
}

export interface NeuralFiberPath {
  id: string;
  fromId: string;
  toId: string;
  points: [number, number, number][];
  color: string;
  subsystemId: SubsystemId;
  intensity: number;
}

export interface JarvisEvent {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  timeAgo: string;
  subsystemId?: SubsystemId;
  type: 'model' | 'memory' | 'voice' | 'system' | 'tool' | 'vision' | 'code';
  status: 'success' | 'info' | 'warning' | 'active';
  isLive?: boolean;
}

export type HologramTheme =
  | 'arc_cyan'
  | 'stark_gold'
  | 'quantum_violet'
  | 'tactical_emerald'
  | 'neural_crimson';

export type ZoomLevel = 'overview' | 'region' | 'network' | 'node';

export interface SystemTelemetry {
  cpuUsage: number;
  ramUsage: number;
  diskUsage: number;
  gpuUsage: number;
  memoryUsedGB: number;
  memoryMaxGB: number;
  activeModel: string;
  modelBadge: string;
  routerMode: string;
  bridgeConnected: boolean;
  hudConnected: boolean;
  cameraActive: boolean;
}
