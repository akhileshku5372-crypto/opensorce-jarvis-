"""RadoxAI writer pool - the prose engine for research output ONLY.

Why a separate writer: Sir's rule is that Groq / Gemini / NVIDIA / OpenRouter /
xKiro quota is the brain's, and must not be burned summarising web pages. These
four keys (5M tokens/month across them) do the writing instead.

Two measured facts this module exists around:
  * Python's urllib gets HTTP 403 "error code: 1010" from the CDN in front of
    radoxai.com - a browser-signature rule, not an auth failure. curl with a
    browser User-Agent gets 200. So the transport is curl, keys on stdin.
  * These endpoints reason before answering: max_tokens=30 returns
    finish_reason=length with content=null. Every call needs >=1200 tokens, and
    a null content is treated as a failed attempt, not as an empty answer.

Nothing here logs a key. meta["slot"] is 1-based and refers to the Nth key in
.dev.vars, never to the secret itself.
"""

import json
import os
import subprocess
import threading
import time
import urllib.parse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36")
MIN_TOKENS = 1200
MAX_TOKENS = 6000
RETRIES_PER_KEY = 2
PARK_AFTER_FAILS = 3
PARK_SECONDS = 900
_LOCK = threading.Lock()
_STATE = {"next": 0, "fails": {}, "parked": {}}


def _env(name, default=""):
    for fname in (".dev.vars", ".env"):
        try:
            with open(os.path.join(ROOT, fname), "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if line.startswith(name + "="):
                        return line.split("=", 1)[1].strip()
        except OSError:
            continue
    return default


def keys():
    return [k for k in (_env("RADOX_API_KEY"), _env("RADOX_API_KEY_2"),
                        _env("RADOX_API_KEY_3"), _env("RADOX_API_KEY_4")) if k]


def base_url():
    return (_env("RADOX_BASE_URL", "https://radoxai.com/v1").rstrip("/")
            + "/chat/completions")


def model():
    return _env("RADOX_MODEL", "gpt-5.6-luna")


def available():
    return bool(keys())


def _parked(slot, now=None):
    now = time.time() if now is None else now
    return _STATE["parked"].get(slot, 0.0) > now


def _note(slot, ok):
    with _LOCK:
        if ok:
            _STATE["fails"][slot] = 0
            _STATE["parked"].pop(slot, None)
            return
        _STATE["fails"][slot] = _STATE["fails"].get(slot, 0) + 1
        if _STATE["fails"][slot] >= PARK_AFTER_FAILS:
            _STATE["parked"][slot] = time.time() + PARK_SECONDS


def _curl_once(key, payload, timeout):
    """One POST via curl --config -, so the key never reaches the process list."""
    cfg = "\n".join([
        "# curl config", "silent", "show-error", "location",
        'request = "POST"',
        'url = "%s"' % base_url(),
        'header = "Content-Type: application/json"',
        'header = "Authorization: Bearer %s"' % key,
        'header = "User-Agent: %s"' % BROWSER_UA,
        "data = %s" % json.dumps(json.dumps(payload)),
        "",
    ])
    try:
        proc = subprocess.run(["curl", "--config", "-"], input=cfg,
                              capture_output=True, text=True, timeout=timeout,
                              encoding="utf-8", errors="replace")
    except Exception as exc:
        return {"http": 0, "error": "curl %s: %s" % (type(exc).__name__, str(exc)[:120])}
    if proc.returncode != 0:
        return {"http": 0, "error": "curl rc=%s %s" % (proc.returncode, (proc.stderr or "")[:120])}
    out = (proc.stdout or "").strip()
    try:
        doc = json.loads(out)
    except Exception:
        return {"http": 0, "error": "non-JSON response: " + out[:160]}
    choice = (doc.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    return {"http": 200,
            "content": (message.get("content") or "").strip(),
            "finish": choice.get("finish_reason") or "",
            "usage": doc.get("usage") or {},
            "error": str(doc.get("error") or doc.get("message") or "")[:160]}


def write(prompt, system="", max_tokens=MIN_TOKENS, timeout=150, want=None):
    """Return (text, meta). text is None when no key produced usable prose.

    Every live key in the pool is tried once per call, starting from a rotating
    offset so the four keys share the load instead of draining one.
    """
    pool = keys()
    meta = {"slot": 0, "ms": 0, "tokens": 0, "model": model(), "attempts": [],
            "error": "", "finish": ""}
    if not pool:
        meta["error"] = "no RADOX_API_KEY configured"
        return None, meta
    tokens = max(int(max_tokens or 0), MIN_TOKENS)
    with _LOCK:
        start = _STATE["next"]
        _STATE["next"] = (start + 1) % len(pool)
    started = time.time()
    for offset in range(len(pool)):
        index = (start + offset) % len(pool)
        slot = index + 1
        if _parked(slot):
            meta["attempts"].append({"slot": slot, "ok": False, "error": "parked"})
            continue
        messages = ([{"role": "system", "content": system}] if system else [])                    + [{"role": "user", "content": prompt}]
        budget = tokens
        # Measured on this host: a longer prompt spends its whole budget
        # reasoning and answers with finish_reason=length and content=null. That
        # is not an empty answer, so the same key gets one doubled budget before
        # the pool rotates - otherwise every useful call looks like a dead key.
        for attempt in range(RETRIES_PER_KEY):
            payload = {"model": meta["model"], "max_tokens": budget, "messages": messages}
            res = _curl_once(pool[index], payload, timeout)
            usable = bool(res.get("content")) and res.get("http") == 200
            if usable and want:
                usable = want(res["content"])
            meta["attempts"].append({"slot": slot, "ok": usable, "http": res.get("http"),
                                     "finish": res.get("finish", ""), "budget": budget,
                                     "error": "" if usable else (res.get("error")
                                                                 or "empty content (%s)" % res.get("finish"))})
            if usable:
                _note(slot, True)
                meta.update({"slot": slot, "ms": int((time.time() - started) * 1000),
                             "tokens": int((res.get("usage") or {}).get("total_tokens") or 0),
                             "finish": res.get("finish", ""), "error": ""})
                return res["content"], meta
            if res.get("finish") == "length" and budget < MAX_TOKENS and attempt + 1 < RETRIES_PER_KEY:
                budget = min(budget * 2, MAX_TOKENS)
                continue
            break
        _note(slot, False)
    meta["ms"] = int((time.time() - started) * 1000)
    meta["error"] = "all %d keys failed (last: %s)" % (
        len(pool), (meta["attempts"][-1].get("error") if meta["attempts"] else "none") or "?")
    return None, meta


def pool_status():
    """Non-secret health for /state and the console's provider rows."""
    pool = keys()
    return {"configured": len(pool), "model": model(), "base": base_url(),
            "parked_slots": sorted(s for s in range(1, max(4, len(pool)) + 1) if _parked(s)),
            "fail_counts": {str(k): v for k, v in _STATE["fails"].items() if v}}


if __name__ == "__main__":
    text, meta = write("Reply with exactly: POING")
    print("text=%r slot=%s ms=%s tokens=%s error=%s" % (
        (text or "")[:60], meta.get("slot"), meta.get("ms"), meta.get("tokens"), meta.get("error")))
