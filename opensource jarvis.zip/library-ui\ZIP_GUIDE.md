# JARVIS Research Archive — Agent Implementation Guide

This `.zip` archive contains the complete, self-contained **JARVIS Research Archive** frontend application (React 19 + TypeScript + Tailwind CSS v4 + Vite) along with all 3D Atrium textures, procedural Web Audio synthesis, and Python/JS bridge hooks.

## 1. Directory Structure
- `src/App.tsx` — Main 3-column JARVIS Research Archive HUD (Top telemetry bar, Left navigation & JARVIS voice avatar, Center 3D Archive Atrium, Right "ASK THE SOURCE" inspector & TTS/Q&A panel).
- `src/components/AtriumBackdropCanvas.tsx` — 3D Atrium canvas renderer that cleanly removes static baked-in cards and renders uploaded PDFs/Books as recessed 3D physical volumes inside the golden shelf compartments with dynamic under-shelf bounce lighting.
- `src/components/ShelfBookRack.tsx` — Interactive 3D perspective shelf hotspots with a volumetric **under-shelf glow effect** that intensifies when a book is hovered or selected.
- `src/components/AddMaterialModal.tsx` — Local file uploader (`.pdf`, `.txt`, `.md`, `.docx`, images) + custom source creator with live 3D cover title preview.
- `src/data/archiveData.ts` — Deterministic filename cleaner (`formatCleanShelfTitle`), 3D physical appearance resolver (`resolvePhysicalAppearance`), and preset archive materials.
- `src/utils/soundEngine.ts` — Zero-API Web Audio synthesizer providing 432Hz + Alpha/Gamma binaural study/relaxation soundscapes and crystalline UI chimes.
- `public/assets/aistudio/` — Required 3D Atrium background textures (`image_1d494883.png` and `image_9ffe2923.png`).
- `jarvis_main.py` — Ready-to-run Python `pywebview` desktop wrapper to embed this UI inside a Python JARVIS agent.

## 2. Quick Start for Coding Agents
```bash
# 1. Install dependencies
npm install

# 2. Start the development server on port 3000
npm run dev

# 3. Or build static production bundle into dist/
npm run build
```

## 3. Connecting Your JARVIS Agent / Backend
You can control the UI or pass real LLM responses from your Python/Node JARVIS agent via `window` events or by replacing the local synthesis handler in `src/App.tsx` (`handleAskQuestion`):

```javascript
// Dispatch events from Python pywebview / Electron / WebSocket into the UI:
window.dispatchEvent(new CustomEvent('jarvis:external-command', {
  detail: {
    action: 'ASK_SOURCE',
    payload: {
      question: 'Summarize the key architecture insights',
      online: true
    }
  }
}));
```
