import React, { useState } from 'react';
import { X } from 'lucide-react';
import { MaterialItem } from '../data/archiveData';
import { LEFT_SHELF_SLOTS, RIGHT_SHELF_SLOTS } from './AtriumBackdropCanvas';

interface ShelfBookRackProps {
  side: 'left' | 'right';
  items: MaterialItem[];
  selectedSourceId?: string | null;
  onSelectBook: (item: MaterialItem) => void;
  onRemoveBook: (id: string) => void;
  onRenameBook?: (id: string, newTitle: string) => void;
  onHoverBook?: (id: string | null) => void;
  onAddClick?: () => void;
}

/**
 * Interactive 3D Shelf Book Rack with an 'under-shelf' volumetric glow effect
 * that subtly illuminates the shelf ledge at rest and intensifies when a book
 * is hovered or selected, emphasizing the 3D physical depth of the archive.
 */
export const ShelfBookRack: React.FC<ShelfBookRackProps> = ({
  side,
  items,
  selectedSourceId,
  onSelectBook,
  onRemoveBook,
  onHoverBook,
}) => {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  if (items.length === 0) return null;

  const slots = side === 'left' ? LEFT_SHELF_SLOTS : RIGHT_SHELF_SLOTS;
  const visibleItems = items.slice(0, slots.length);

  return (
    <div className="absolute inset-0 pointer-events-none z-10">
      {visibleItems.map((item, idx) => {
        const slot = slots[idx];
        const isSelected = selectedSourceId === item.id;
        const isHovered = hoveredId === item.id;
        const skewDeg = (slot.slopeY * 180) / Math.PI;

        return (
          <div
            key={item.id}
            style={{
              left: `${slot.x * 100}%`,
              top: `${slot.y * 100}%`,
              width: `${slot.w * 100}%`,
              height: `${slot.h * 100}%`,
            }}
            onClick={() => onSelectBook(item)}
            onMouseEnter={() => {
              setHoveredId(item.id);
              onHoverBook?.(item.id);
            }}
            onMouseLeave={() => {
              setHoveredId(null);
              onHoverBook?.(null);
            }}
            className="group absolute pointer-events-auto cursor-pointer select-none"
            title={`${item.title} (${item.type}) — Click to select`}
          >
            {/* =================================================================
                3D UNDER-SHELF VOLUMETRIC GLOW EFFECT
                - Subtle warm-amber/cyan under-shelf illumination at rest
                - Intensifies on hover/select with upward bounce light & downward
                  under-shelf volumetric bloom to emphasize 3D archive depth
            ================================================================== */}
            <div
              style={{
                transform: `skewY(${skewDeg.toFixed(2)}deg)`,
              }}
              className="pointer-events-none absolute -bottom-2.5 -left-2 -right-2 h-7 flex flex-col items-center justify-start transition-all duration-300"
            >
              {/* 1. Upward Shelf-Plank Bounce Glow onto the Book Base */}
              <div
                className={`w-[96%] h-2.5 rounded-full transition-all duration-300 ${
                  isHovered || isSelected
                    ? 'opacity-100 bg-gradient-to-r from-amber-300/75 via-cyan-300/80 to-amber-300/75 blur-[4px] scale-x-105'
                    : 'opacity-45 bg-gradient-to-r from-amber-400/35 via-amber-200/40 to-amber-400/35 blur-[3px]'
                }`}
              />

              {/* 2. Precision Golden/Cyan Shelf Lip Specular Filament */}
              <div
                className={`w-full h-[2px] rounded-full transition-all duration-300 ${
                  isHovered || isSelected
                    ? 'opacity-100 bg-gradient-to-r from-transparent via-cyan-200 to-transparent shadow-[0_0_12px_rgba(34,211,238,0.95),0_0_20px_rgba(251,191,36,0.85)]'
                    : 'opacity-60 bg-gradient-to-r from-transparent via-amber-300/75 to-transparent'
                }`}
              />

              {/* 3. Deep Under-Shelf Downward Volumetric Light Cast */}
              <div
                className={`w-[108%] rounded-b-full transition-all duration-300 ${
                  isHovered || isSelected
                    ? 'h-5 opacity-95 bg-gradient-to-b from-amber-400/65 via-cyan-400/35 to-transparent blur-[7px] scale-x-110'
                    : 'h-3 opacity-35 bg-gradient-to-b from-amber-500/40 via-amber-400/15 to-transparent blur-[5px]'
                }`}
              />
            </div>

            {/* Subtle 3D Depth Backlight Behind the Book on Hover */}
            <div
              style={{
                transform: `skewY(${skewDeg.toFixed(2)}deg)`,
              }}
              className={`pointer-events-none absolute inset-0 rounded transition-opacity duration-300 ${
                isHovered || isSelected
                  ? 'opacity-100 shadow-[0_10px_28px_-4px_rgba(251,191,36,0.45),0_0_18px_rgba(34,211,238,0.3)]'
                  : 'opacity-0'
              }`}
            />

            {/* Discreet Remove (×) button only on direct hover */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemoveBook(item.id);
              }}
              className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-2 -right-2 w-4 h-4 rounded-full bg-rose-600/95 text-white flex items-center justify-center hover:bg-rose-500 shadow cursor-pointer z-20"
              title="Remove from shelf"
            >
              <X className="w-2.5 h-2.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
