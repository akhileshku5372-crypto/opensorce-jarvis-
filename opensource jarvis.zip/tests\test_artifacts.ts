/* ══════════════════════════════════════════════════════════════════════
 * Unit tests for the KamiSensei Artifact Engine (src/artifacts.ts)
 * Pure-node — run with:  npx tsx tests/test_artifacts.ts
 * ══════════════════════════════════════════════════════════════════════ */
import {
  ARTIFACT_TYPES,
  assembleDeepScanContext,
  buildArtifactPrompt,
  buildMindMapCardsPrompt,
  buildMindMapPrompt,
  buildRepairPrompt,
  extractJson,
  extractTopicKeyPhrases,
  flattenMindMapInput,
  isMetaLabel,
  mindMapDepthLimit,
  normalizeLabel,
  normalizeMindMapCards,
  scoreRagChunk,
  validateMindMapCards,
  salvageArtifact,
  validateArtifact,
  validateMindMapTree
} from '../src/artifacts'

let pass = 0
let fail = 0
function ok(cond: boolean, msg: string) {
  if (cond) { pass++; console.log('  ✓ ' + msg) }
  else { fail++; console.error('  ✗ ' + msg) }
}

console.log('exported types:', ARTIFACT_TYPES.join(', '))
ok(ARTIFACT_TYPES.length === 10, 'ten artifact types exported')

// ── extractJson ─────────────────────────────────────────────────────
console.log('\nextractJson')
ok(extractJson('{"a":1}') && (extractJson('{"a":1}') as any).a === 1, 'parses plain JSON')
ok(extractJson('```json\n{"a":1}\n```') && (extractJson('```json\n{"a":1}\n```') as any).a === 1, 'parses fenced JSON')
ok(extractJson('Here is your result:\n{"title":"x","type":"note"}\nEnjoy.') && (extractJson('Prose\n{"title":"x"}\nmore') as any).title === 'x', 'extracts object from surrounding prose')
ok(extractJson('[1,2,3]') && Array.isArray(extractJson('[1,2,3]')), 'parses arrays')
ok(extractJson('garbage') === null, 'returns null on garbage')
ok(extractJson('object with escaped quotes {"a":"sa\\"y \\" hi"}') && (extractJson('object with escaped quotes {"a":"sa\\"y \\" hi"}') as any).a === 'sa"y " hi', 'handles escaped quotes inside string while scanning')

// ── validateArtifact: valid NOTE ────────────────────────────────────
console.log('\nvalidateArtifact')
const validNote = {
  type: 'note',
  title: 'Japanese Particles',
  summary: 'Overview of は and が.',
  sections: [{ title: 'Wa', body: 'Topic marker.' }],
  keyPoints: ['は marks the topic'],
  examples: [{ japanese: '私は学生です', romaji: 'watashi wa gakusei desu', english: 'I am a student.' }],
  sources: ['minna-no-nihongo.pdf']
}
{
  const v = validateArtifact('note', validNote)
  ok(v.ok === true, 'valid note passes')
}

// ── validateArtifact: invalid QUIZ fails with detailed errors ────────
{
  const badQuiz = {
    type: 'flashcard_set', // wrong type on purpose
    title: 'Quiz',
    questions: [
      { question: 'Q1', options: ['a', 'b'], correctAnswer: 5, explanation: '' }
    ]
  }
  const v = validateArtifact('quiz', badQuiz)
  ok(v.ok === false, 'invalid quiz rejected')
  ok(v.ok === false && v.errors.some((e) => e.includes('"type" must equal "quiz"')), 'reports wrong type')
  ok(v.ok === false && v.errors.some((e) => e.includes('correctAnswer')), 'reports out-of-range correctAnswer')
  ok(v.ok === false && v.errors.some((e) => e.includes('explanation')), 'reports missing explanation')
}

// ── validateArtifact: valid FLASHCARD_SET ────────────────────────────
{
  const v = validateArtifact('flashcard_set', {
    type: 'flashcard_set', title: 'Set', cards: [{ front: '学生', back: 'student' }]
  })
  ok(v.ok === true, 'valid flashcard_set passes')
}

// ── validateArtifact: valid MIND_MAP ─────────────────────────────────
{
  const v = validateArtifact('mind_map', {
    type: 'mind_map', title: 'MM', nodes: [
      { id: 'n1', label: 'Particles', parentId: null },
      { id: 'n2', label: 'は', description: 'topic', parentId: 'n1' }
    ]
  })
  ok(v.ok === true, 'valid mind_map passes')
}

// ── validateArtifact: DATA_TABLE ────────────────────────────────────
{
  // Cells are individually validated (string/number); row width is left
  // to the renderer so slightly ragged model output stays usable.
  const v = validateArtifact('data_table', {
    type: 'data_table', title: 'DT', columns: ['A'], rows: [['x', 1]], sources: []
  })
  ok(v.ok === true, 'data_table with numeric cells passes')
  const v2 = validateArtifact('data_table', {
    type: 'data_table', title: 'DT', columns: ['A'], rows: [[{ bad: true }]], sources: []
  })
  ok(v2.ok === false && v2.errors.some((e) => e.includes('must be a string or number')), 'rejects object cells')
  const v3 = validateArtifact('data_table', {
    type: 'data_table', title: 'DT', columns: ['A'], rows: [], sources: []
  })
  ok(v3.ok === false && v3.errors.some((e) => e.includes('rows[]')), 'rejects empty rows')
}

// ── buildArtifactPrompt ─────────────────────────────────────────────
console.log('\nbuildArtifactPrompt')
const ctx = '\n\nCURRENT DOCUMENT CONTEXT:\n[Source 1: book.pdf (Page 4)]: は marks topic'
const prompt = buildArtifactPrompt('note', 'particles', ctx, ['book.pdf'])
ok(prompt.includes('note') && prompt.includes('particles'), 'includes type + topic')
ok(prompt.includes('book.pdf'), 'includes selected source scope')
ok(prompt.includes('CURRENT DOCUMENT CONTEXT'), 'includes retrieved context')
ok(/({[^}]*"type":\s*"note")/.test(prompt), 'schema embedded for json mode')
const noCtx = buildArtifactPrompt('quiz', 'x', '', [])
ok(noCtx.includes('No source chunks were retrieved'), 'no-context fallback message present')

// ── buildRepairPrompt ───────────────────────────────────────────────
const repair = buildRepairPrompt('quiz', 'x', '{"broken"', ['Field "type" must equal "quiz".'], ctx)
ok(repair.includes('failed validation') && repair.includes('Field "type" must equal "quiz".'), 'repair prompt carries errors')
ok(repair.includes('book.pdf (Page 4)') && repair.includes('never invent citations'), 'repair prompt preserves verified source context')

const invalidPage = validateArtifact('flashcard_set', {
  type: 'flashcard_set', title: 'Set', cards: [{ front: '学生', back: 'student', source: 'book.pdf', page: 0 }]
})
ok(invalidPage.ok === false && invalidPage.errors.some((e) => e.includes('.page')), 'rejects fabricated or invalid page numbers')


// ── salvageArtifact ────────────────────────────────────────────────────
console.log('\nsalvageArtifact')
{
  const raw = {
    type: 'flashcard_set',
    title: 'Quiz mishap',
    questions: [
      { question: 'Q1', options: ['は', 'が', 'を', 'に'], correct_answer: 2, reasoning: 'を marks the object' },
      { question: 'Q2', options: ['A', 'B', 'C', 'D'], correctAnswer: 'C', explanation: '' }
    ]
  }
  const s = salvageArtifact('quiz', raw)
  const v = validateArtifact('quiz', s)
  ok(v.ok === true, 'salvage maps correct_answer alias + fills explanation, then validates')
  const q0 = (s as any).questions[0]
  const q1 = (s as any).questions[1]
  ok(q0.correctAnswer === 2, 'correct_answer alias becomes numeric index')
  ok(q0.explanation === 'を marks the object', 'reasoning alias becomes explanation')
  ok(q1.correctAnswer === 2, 'option-string "C" becomes index 2')
  ok(String(q1.explanation).includes('C'), 'empty explanation gets honest derived fallback')
}
{
  const s = salvageArtifact('data_table', { type: 'data_table', title: 'T', columns: 'wrong', rows: [[1, 2], 'bad'], sources: 'x' })
  const v = validateArtifact('data_table', s)
  ok(v.ok === false, 'still reports missing columns after salvage (no fabrication)')
  const s2 = salvageArtifact('data_table', { type: 'data_table', title: 'T', columns: ['A', 'B'], rows: [[1, 'ok']], sources: [] })
    ok(validateArtifact('data_table', s2).ok === true, 'valid table passes after salvage round-trip')
}

// ── mindMapDepthLimit ───────────────────────────────────────────────────
console.log('\\nmindMapDepthLimit')
ok(mindMapDepthLimit('brief') === 2, 'Brief maps to depth limit 2')
ok(mindMapDepthLimit('Brief') === 2, 'Case-insensitive Brief')
ok(mindMapDepthLimit('detailed') === 4, 'Detailed maps to depth limit 4')
ok(mindMapDepthLimit('complete') === Number.POSITIVE_INFINITY, 'Complete maps to Infinity')
ok(mindMapDepthLimit('exhaustive') === Number.POSITIVE_INFINITY, 'Exhaustive also Infinity')
ok(mindMapDepthLimit() === 4, 'Default (undefined) maps to depth limit 4')

// ── normalizeLabel ──────────────────────────────────────────────────────
console.log('\\nnormalizeLabel')
ok(normalizeLabel('  Hello   World  ') === 'hello world', 'collapses whitespace and lowercases')
ok(normalizeLabel('は！が？を。') === 'はがを', 'strips Japanese punctuation')
ok(normalizeLabel('Noun,  particle  —  case') === 'noun particle case', 'strips ascii punctuation + extra spaces')
ok(normalizeLabel(null) === '', 'null → empty string')

// ── validateMindMapTree ──────────────────────────────────────────────────
console.log('\\nvalidateMindMapTree')
{
  const validTree = {
    type: 'mind_map', title: 'Test',
    root: { id: 'r1', label: 'Root', description: 'the root', type: 'root',
      children: [
        { id: 'c1', label: 'Child A', description: 'first child', type: 'topic',
          children: [
            { id: 'g1', label: 'Grandchild', description: 'leaf', type: 'concept' }
          ]
        },
        { id: 'c2', label: 'Child B', description: 'second child', type: 'subtopic' }
      ]
    }
  }
  const errs = validateMindMapTree(validTree)
  ok(errs.length === 0, 'valid nested tree produces zero errors')
}
{
  const errs = validateMindMapTree(null)
  ok(errs.length > 0 && errs[0].includes('not a JSON object'), 'null input errors')
}
{
  const errs = validateMindMapTree({ root: {} })
  ok(errs.some((e) => e.includes('title')), 'missing title reported')
  ok(errs.some((e) => e.includes('root')), 'missing/malformed root reported')
}
{
  const errs = validateMindMapTree({ title: 'T', root: { id: '', label: 'X' } })
  ok(errs.some((e) => e.includes('root.id')), 'empty root id reported')
}
{
  const errs = validateMindMapTree({ title: 'T', root: { id: 'r', label: '' } })
  ok(errs.some((e) => e.includes('root.label')), 'empty root label reported')
}
{
  const errs = validateMindMapTree({ title: 'T', root: { id: 'r', label: 'Root', description: 'ok', type: 'root',
    children: [ { label: 'NoId' } ] } })
        ok(errs.some((e) => e.includes('children[0].id')), 'child missing id reported')
}

// ── flattenMindMapInput ──────────────────────────────────────────────────
console.log('\\nflattenMindMapInput')
{
  const tree = {
    type: 'mind_map', title: 'Flatten Test',
    root: { id: 'root', label: 'Root Concept', type: 'root',
      children: [
        { id: 'a', label: 'Topic A', description: 'desc A', type: 'topic',
          children: [
            { id: 'b', label: 'Concept B', description: 'desc B', type: 'concept' }
          ]
        },
        { id: 'c', label: 'Topic C', description: 'desc C', type: 'subtopic' }
      ]
    }
  }
    const flat = flattenMindMapInput(tree, 4)
  ok(flat.length === 4, 'flattens 1 root + Topic A + Concept B + Topic C = 4 nodes')
  ok(flat[0].label === 'Root Concept' && flat[0].type === 'root', 'root node preserved with correct type')
  ok(flat[1].parentId === flat[0].id, 'Topic A parentId links to root')
  ok(flat[2].parentId === flat[1].id, 'Concept B links to Topic A')
  ok(flat[3].parentId === flat[0].id, 'Topic C links to root')
  ok(flat.every((n) => n.id.startsWith('mm-')), 'every node gets a hash id (mm- prefix)')
}
{
  const tree = {
    type: 'mind_map', title: 'Depth Prune',
    root: { id: 'root', label: 'Root', type: 'root',
      children: [
        { id: 'a', label: 'A', type: 'topic',
          children: [
            { id: 'b', label: 'B', type: 'subtopic',
              children: [{ id: 'c', label: 'C', type: 'concept' }]
            }
          ]
        }
      ]
    }
  }
    const flat2 = flattenMindMapInput(tree, 1)
  ok(flat2.length === 2, 'depth limit 1 prunes beyond level 0 (root + 1 topic)')
  ok(flat2.every((n) => n.id.startsWith('mm-')), 'depth-pruned nodes still get hash ids')
}
{
  const tree = {
    type: 'mind_map', title: 'Dedup',
    root: { id: 'root', label: 'Root', type: 'root',
      children: [
        { id: 'a', label: 'Japanese Particles', type: 'topic' },
        { id: 'b', label: 'particles Japanese', type: 'topic' }
      ]
    }
  }
  const flat = flattenMindMapInput(tree, 4)
  ok(flat.length === 2, 'root + 1 deduped topic = 2 nodes (semantic dedup of leaf labels)')
}
{
  const flat = flattenMindMapInput(null, 4)
  ok(flat.length === 0, 'null input → empty array')
}
{
  // Meta/file-statistics noise ban: "212 Study Pages Workbook" and
  // "English Language Medium" are DROPPED; real lesson nodes survive.
  const tree = {
    type: 'mind_map', title: 'ML1: 212 pages',
    root: { id: 'root', label: 'Root', type: 'root',
      children: [
        { id: 'm1', label: '212 Study Pages Workbook', type: 'topic' },
        { id: 'm2', label: 'English Language Medium', type: 'subtopic' },
        { id: 'g', label: 'は (wa) Particle — Topic Marker', type: 'rule',
          children: [{ id: 'g1', label: 'Watashi wa gakusei desu', type: 'example' }]
        }
      ]
    }
  }
  const flat = flattenMindMapInput(tree, 4)
  const labels = flat.map((n) => n.label)
  ok(!labels.includes('212 Study Pages Workbook'), 'drops meta "Study Pages Workbook" node')
  ok(!labels.includes('English Language Medium'), 'drops meta "English Language Medium" node')
  ok(labels.includes('は (wa) Particle — Topic Marker'), 'keeps real grammar-rule node')
  ok(labels.includes('Watashi wa gakusei desu'), 'keeps real example leaf')
}
{
  // A meta-level ROOT is relabeled from the artifact title, keeping the lesson topic as root.
  const tree = {
    type: 'mind_map', title: 'Minna no Nihongo Lesson 1 Grammar Rules',
    root: { id: 'root', label: '212 Study Pages Workbook', type: 'root',
      children: [
        { id: 'a', label: '〜は 〜です (wa... desu)', type: 'rule' }
      ]
    }
  }
  const flat = flattenMindMapInput(tree, 4)
  ok(flat.length === 2, 'meta root relabeled + real child = 2 nodes')
  ok(flat[0].label === 'Minna no Nihongo Lesson 1 Grammar Rules', 'meta root relabeled from title')
  ok(flat[1].label.includes('wa'), 'real child preserved')
}

// ── buildMindMapPrompt ──────────────────────────────────────────────────
console.log('\nbuildMindMapPrompt')
{
  const ctx = '[Source 1: book.pdf (Page 4)]: は marks the topic'
  const prompt = buildMindMapPrompt('mind_map', 'Japanese Particles', ctx, ['book.pdf'])
  ok(prompt.includes('mind map') || prompt.includes('MIND MAP'), 'prompt mentions mind map')
  ok(prompt.includes('Japanese Particles'), 'prompt includes the topic')
  ok(prompt.includes('book.pdf'), 'prompt includes selected source scope')
  ok(prompt.includes('gakusei desu'), 'prompt includes real leaf-example guidance (wa... desu)')
  ok(prompt.includes('educational visualizer'), 'prompt states the educational-visualizer MISSION')
  ok(prompt.includes('ABSOLUTE BAN'), 'prompt bans meta-level file-statistics nodes')
  ok(prompt.includes('language medium') && prompt.includes('study pages'), 'prompt names the exact banned meta labels')
  ok(/[Nn]ever emit generic/.test(prompt) && prompt.includes('Vocabulary'), 'prompt includes anti-template guidance (Vocabulary, Grammar, etc. must be grounded)')
  ok(prompt.includes('root') && prompt.includes('children') && prompt.includes('sourceReferences'), 'prompt embeds nested root-children schema')
  ok(/root.*topic.*subtopic.*concept.*rule.*example.*definition.*reference/.test(prompt.replace(/\s+/g, ' ')), 'prompt lists all 8 node types')
}
{
  const brief = buildMindMapPrompt('mind_map', 'particles', '[Source 1: book.pdf]: context', ['book.pdf'], { requestedDepth: 'brief' })
  ok(brief.includes('BRIEF'), 'brief depth produces BRIEF contract text')
  const complete = buildMindMapPrompt('mind_map', 'particles', '[Source 1: book.pdf]: context', ['book.pdf'], { requestedDepth: 'complete' })
  ok(complete.includes('COMPLETE'), 'complete depth produces COMPLETE contract text')
}
{
  const noCtx = buildMindMapPrompt('mind_map', 'x', '', [], {})
  ok(noCtx.includes('ERROR: No source chunks were retrieved'), 'no-context fallback message present')
}
/* ── Dynamic generative CARD SCHEME (schema v2) ────────────────────────── */
{
  const prompt = buildMindMapCardsPrompt('mind_map', 'Minna no Nihongo Lesson 1', '[Source 1: book.pdf]: context', ['book.pdf'], {})
  ok(prompt.includes('DYNAMIC TAXONOMY, ZERO FIXED CATEGORIES'), 'cards prompt demands an AI-determined taxonomy')
  ok(prompt.includes('Grammar Keys') && prompt.includes('Core Particles'), 'cards prompt bans fixed template category names')
  ok(prompt.includes('headerTitle') && prompt.includes('themeColor') && prompt.includes('iconType') && prompt.includes('bulletPoints') && prompt.includes('hasCheckbox'), 'cards prompt embeds the exact card schema fields')
  ok(prompt.includes('history') && prompt.includes('coding') && prompt.includes('math'), 'cards prompt states non-language domains are first-class')
  ok(prompt.includes('book.pdf'), 'cards prompt embeds source-grounded context')
}
{
  const errors = validateMindMapCards(null)
  ok(errors.length >= 1, 'validateMindMapCards rejects null')
  ok(validateMindMapCards({ title: 'T', cards: [] }).some((e) => e.includes('cards')), 'validateMindMapCards rejects empty cards array')
  ok(validateMindMapCards({ cards: [{ id: 'c1', headerTitle: 'H', bulletPoints: [{ text: 'x' }] }] }).some((e) => e.includes('title')), 'validateMindMapCards requires title')
  ok(validateMindMapCards({ title: 'T', cards: [{ id: 'c1', bulletPoints: [{ text: 'x' }] }] }).some((e) => e.includes('headerTitle')), 'validateMindMapCards requires headerTitle')
  ok(validateMindMapCards({ title: 'T', cards: [{ id: 'c1', headerTitle: 'H', bulletPoints: [{}] }] }).some((e) => e.includes('text')), 'validateMindMapCards requires bullet text')
  const enumErr = validateMindMapCards({ title: 'T', cards: [{ id: 'c1', headerTitle: 'H', themeColor: 'chartreuse', iconType: 'rocket', bulletPoints: [{ text: 'x', hasCheckbox: 'yes' }] }] })
  ok(enumErr.some((e) => e.includes('themeColor')) && enumErr.some((e) => e.includes('iconType')) && enumErr.some((e) => e.includes('hasCheckbox')), 'validateMindMapCards enforces theme/icon enums and boolean hasCheckbox')
  ok(validateMindMapCards({ title: 'T', cards: [{ id: 'c1', headerTitle: 'H', themeColor: 'teal', iconType: 'list', bulletPoints: [{ text: 'x', hasCheckbox: true }] }] }).length === 0, 'validateMindMapCards accepts a fully valid card')
}
{
  const good = {
    title: 'WWII Pacific Theater',
    cards: [
      { id: 'card_1', headerTitle: 'Key Treaties', themeColor: 'pink', iconType: 'list', bulletPoints: [{ text: 'Treaty of Portsmouth (1905) ended the Russo-Japanese War' }, { text: 'Treaty of Portsmouth (1905) ended the Russo-Japanese War' }] },
      { id: 'card_2', headerTitle: 'key treaties', themeColor: 'pink', iconType: 'list', bulletPoints: [{ text: 'duplicate card body' }] },
      { id: 'card_3', headerTitle: '112 Study Pages Workbook', bulletPoints: [{ text: 'meta' }] },
      { id: 'card_4', headerTitle: 'Turning-Point Battles', bulletPoints: [{ text: 'Midway (June 1942) — Pacific carrier supremacy shifted to the US', hasCheckbox: true }, { text: '  ' }] },
      { id: 'card_5', headerTitle: 'Orphan Card', bulletPoints: [] }
    ]
  }
  const norm = normalizeMindMapCards(good)
  ok(!!norm && norm.cards.length === 2, 'normalizeMindMapCards drops meta/duplicate/orphan cards, keeps 2')
  ok(!!norm && norm.cards[0].bulletPoints.length === 1, 'normalizeMindMapCards dedups semantic duplicate bullets')
  ok(!!norm && norm.cards[1].bulletPoints[0].hasCheckbox === true, 'normalizeMindMapCards preserves hasCheckbox=true drills')
  ok(!!norm && norm.cards.every((c) => c.themeColor && c.iconType), 'normalizeMindMapCards fills enum defaults for missing theme/icon')
  ok(normalizeMindMapCards({ title: '212 Study Pages Workbook', cards: [{ id: 'c', headerTitle: 'H', bulletPoints: [{ text: 'x' }] }] }) === null, 'normalizeMindMapCards rejects meta-level board titles')
  ok(normalizeMindMapCards({ title: 'T' }) === null, 'normalizeMindMapCards rejects missing cards array')
  const clamp = normalizeMindMapCards({ title: 'T', cards: [{ id: 'c1', headerTitle: 'H', themeColor: 'magenta', bulletPoints: [{ text: 'x' }] }, { id: 'c2', headerTitle: 'H2', iconType: 'plane', bulletPoints: [{ text: 'y' }] }] })
  ok(!!clamp && clamp.cards[0].themeColor !== 'magenta' && clamp.cards[1].iconType !== 'plane', 'normalizeMindMapCards clamps invalid enum values to valid ones')
  const dupIds = normalizeMindMapCards({ title: 'T', cards: [{ id: 'c1', headerTitle: 'A', bulletPoints: [{ text: 'x' }] }, { id: 'c1', headerTitle: 'B', bulletPoints: [{ text: 'y' }] }] })
  ok(!!dupIds && new Set(dupIds.cards.map((c) => c.id)).size === dupIds.cards.length, 'normalizeMindMapCards guarantees unique card ids')
}

/* ── RAG deep-scan helpers: dense raw lesson-text extraction ─────────── */
console.log('RAG deep-scan (extractTopicKeyPhrases / scoreRagChunk / assembleDeepScanContext):')
{
  const phrases = extractTopicKeyPhrases('Create a mind map for Lesson 6 grammar and particles from the book')
  ok(phrases.some((p) => p.toLowerCase() === 'lesson 6'), 'extractTopicKeyPhrases finds "Lesson 6" pattern')
  ok(phrases.includes('grammar') && phrases.includes('particles'), 'extractTopicKeyPhrases keeps significant topic words')
  const cjk = extractTopicKeyPhrases('MINNA NO NIHONGO レッスン6 の mind map')
  ok(cjk.some((p) => /[^\u0000-\u007f]/.test(p)), 'extractTopicKeyPhrases captures non-ASCII (kana/kanji) runs')
  const phrases2 = extractTopicKeyPhrases('all about the book content please')
  ok(!phrases2.some((p) => ['book', 'content', 'please', 'about'].includes(p)), 'extractTopicKeyPhrases drops generic stopwords')

  const lessonChunk = { text: 'Lesson 6: The particle で marks the location of action. Watashi wa toshokan de benkyou shimasu. — Main library mein padhta hoon. The particle に marks destination with movement verbs. Iku, kuru, kaeru take に for destination. Example: Nichiyoubi ni eiga ni ikimasu.' }
  const tocChunk = { text: 'Table of Contents ............ 3' }
  const phrasesL6 = extractTopicKeyPhrases('Lesson 6 particles')
  ok(scoreRagChunk(lessonChunk, phrasesL6) > scoreRagChunk(tocChunk, phrasesL6), 'scoreRagChunk ranks dense lesson text far above TOC boilerplate')
  ok(scoreRagChunk(tocChunk, phrasesL6) < 0, 'scoreRagChunk penalizes TOC/boilerplate chunks negatively')
  ok(scoreRagChunk({ text: '   ' }, phrasesL6) === -Infinity, 'scoreRagChunk rejects empty chunks outright')

  const chunks = [
    tocChunk,
    { text: 'Index' },
    lessonChunk,
    { text: 'Preface: about this book' },
    { text: 'Lesson 6 dialogue: Tanaka-san wa ashita Kyoto ni ikimasu. Shinkansen de Osaka made iku node, eki de kippu o kaimasu. Main: Tanaka kal Kyoto ja raha hai.' },
    { text: 'ichidan verbs and godan verbs conjugate differently; tabemasu is ichidan, kaku is godan. Examples with Romaji and Hinglish gloss for each form.' },
    { text: 'Page 112' }
  ]
  const assembled = assembleDeepScanContext(chunks, phrasesL6, 400, 14000, 3)
  const texts = assembled.selected.map((c) => c.text)
  ok(texts.indexOf(tocChunk.text) === -1, 'assembleDeepScanContext prefers content chunks over boilerplate')
  ok(assembled.contextChars >= Math.min(400, chunks.reduce((a, c) => a + c.text.length, 0)), 'assembleDeepScanContext reaches the density floor (bypass tops up if needed)')
  const deepField = assembleDeepScanContext(chunks, phrasesL6, 400, 14000, 10)
  ok(deepField.selected.length >= Math.min(10, chunks.length), 'assembleDeepScanContext enforces the 8-10+ chunk field-depth floor (tops up from remaining pool)')
  const dedup = assembleDeepScanContext([lessonChunk, Object.assign({}, lessonChunk)], phrasesL6, 10, 14000, 10)
  ok(dedup.selected.length === 1, 'assembleDeepScanContext deduplicates identical chunks')

  const cardsPrompt = buildMindMapCardsPrompt('mind_map', 'Lesson 6 particles', 'RAW CONTEXT', ['book.pdf'])
  ok(cardsPrompt.includes('ultimate multi-lingual Japanese Sensei protocol inside J.A.R.V.I.S'), 'cards prompt carries the Japanese Sensei protocol directive')
  ok(cardsPrompt.includes('strictly prohibited from generating placeholders or passive text strings'), 'cards prompt bans placeholders/passive strings outright')
  ok(cardsPrompt.includes('Pan o tabemasu'), 'cards prompt embeds the premium bullet structure example (particle + Kanji verb + Romaji + Hinglish)')
  ok(cardsPrompt.includes('CRITICAL RULE'), 'cards prompt carries the CRITICAL RULE meta-description ban')
  ok(cardsPrompt.includes('Watashi wa Rahul desu - Main Rahul hoon'), 'cards prompt embeds the Japanese+Romaji+Hinglish bullet example')
  ok(cardsPrompt.includes('RAW CONTEXT'), 'cards prompt passes the dense context through to the model')
}

console.log('\n' + pass + ' passed, ' + fail + ' failed')
process.exit(fail ? 1 : 0)
