"""JARVIS routing benchmark harness.

Measures the REAL voice_engine.run_command() intent router with its action
layer mocked: nothing is opened, typed, closed, moved, or sent to an LLM and
no network call is made. That keeps measurement honest (we are measuring
routing, not the action) and safe (a benchmark must never touch your desktop).

Usage (from the repo root):
  node run_py.cjs tests/benchmark_harness.py                  # full dry-run
  node run_py.cjs tests/benchmark_harness.py --live           # live_safe only
  node run_py.cjs tests/benchmark_harness.py --calibrate      # print actual routes
  node run_py.cjs tests/benchmark_harness.py --filter close   # subset
  node run_py.cjs tests/benchmark_harness.py --strict         # exit 1 on failure

Metrics: route accuracy, LLM-free share (cost proxy), brain calls, p50/p95
router latency, per-class breakdown. Report: tests/benchmark_report.json.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import statistics
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'background'))

TASKS_FILE = HERE / 'benchmark_tasks.json'
REPORT_FILE = HERE / 'benchmark_report.json'

# Engine order: the lowest-priority entry is the LLM fallback, so a task that
# both generates text and writes it (write route) is attributed to "write".
PRIORITY = ['stop', 'clear', 'screen_vision', 'camera', 'mode', 'phase1',
            'site', 'write', 'close', 'screen_task', 'research', 'bridge',
            'launch', 'brain']


class Recorder:
    """Collects what the mocked action layer was asked to do."""

    def __init__(self):
        self.events = []          # (route, target, detail)
        self.network = []         # any URL the engine tried to reach
        self.brain_calls = []

    def add(self, route, target=None, detail=None):
        self.events.append((route, target, detail))

    def routes(self):
        return [e[0] for e in self.events]

    def route(self):
        for name in PRIORITY:
            if name in self.routes():
                return name
        return 'none'

    def target(self):
        want = self.route()
        for route, target, _ in self.events:
            if route == want and target:
                return target
        return None


class _FakeSkills:
    """Stands in for phase1_skills.py: records the skill, performs nothing."""

    def __init__(self, rec):
        self._rec = rec

    def _mark(self, name, reply):
        self._rec.add('phase1', name)
        return reply

    def time_date(self):
        return self._mark('time_date', 'Sir, time is 12:00 PM, 01 January 2026.')

    def save_note(self, text):
        return self._mark('save_note', 'Note save kar diya, Sir (bench).')

    def read_last_note(self):
        return self._mark('read_last_note', 'Last note (bench): hello.')

    def clipboard_set(self, text):
        return self._mark('clipboard_set', 'Clipboard me copy kar diya, Sir.')

    def clipboard_get(self):
        return self._mark('clipboard_get', 'Clipboard me hai: bench.')

    def type_text(self, text):
        return self._mark('type_text', 'Type kar diya, Sir (bench).')

    def take_screenshot(self):
        return self._mark('take_screenshot', 'Screenshot save ho gaya, Sir.')


class _FakeAgent:
    """Stands in for screen_agent.py: records the call, touches no window."""

    def __init__(self, rec):
        self._rec = rec

    def screen_task(self, task, ui=None, lang='en', confirmed=False,
                    write_text=None):
        text = str(task or '')
        if write_text is not None:
            app = text
            m = None
            import re as _re
            m = _re.match(r'^(?:open|launch|kholo?|chalao)\s+(.+?)\s+and\s+write$',
                          text, _re.I)
            app = m.group(1).strip() if m else text
            self._rec.add('write', app, 'body=%d chars' % len(str(write_text)))
            return "Sir, '%s' launch ho gaya (bench). typed." % app
        self._rec.add('screen_task', text[:40])
        return 'Sir, screen task chalaya (bench).'

    def close_app(self, name, force=False):
        self._rec.add('close', str(name))
        return 'Sir, "%s" band karna hai? Boliye "confirm".' % name

    def launch_app(self, app):
        self._rec.add('launch', str(app))
        return "Sir, '%s' launch ho gaya (bench)." % app

    # Read-only helpers some routes may touch.
    def has_pending(self):
        return False

    def confirm_pending(self):
        return 'Sir, koi pending task nahi hai.'


def load_tasks():
    data = json.loads(TASKS_FILE.read_text(encoding='utf-8'))
    return data.get('tasks', [])


def install_mocks(voice, rec, use_real_skills=False):
    """Swap the action layer for recorders. Returns restore().

    Everything that could touch the desktop, the clipboard, the network, the
    audio device, or a paid LLM is replaced. The router itself is untouched.
    """
    saved = {}
    real_requests = voice.requests
    real_post, real_get = real_requests.post, real_requests.get

    def put(name, value):
        saved[name] = getattr(voice, name)
        setattr(voice, name, value)

    def fake_set_state(**kw):
        if kw.get('mode'):
            rec.add('mode', str(kw['mode']))
        if kw.get('action_name'):
            rec.add('__action__', str(kw['action_name']))

    def fake_speak(text, ui=None, *a, **k):
        return None

    def fake_bridge(command, bridge=None):
        rec.add('bridge', str(command))
        if getattr(rec, 'bridge_handles', False):
            return 'Ho gaya, Sir (bench bridge).'
        return None

    def fake_open_url(url):
        rec.add('site', None, str(url))
        return 'Opening it, Sir (bench).'

    def fake_brain(user_text, ui=None):
        rec.brain_calls.append(str(user_text))
        return 'Bench reply, Sir.'

    def fake_query(*a, **k):
        rec.network.append(str(a[0] if a else '?'))
        raise RuntimeError('bench: network disabled')

    put('set_state', fake_set_state)
    put('speak', fake_speak)
    put('interrupt_playback', lambda *a, **k: None)
    put('clear_chat', lambda *a, **k: None)
    put('bridge_command', fake_bridge)
    put('_open_url', fake_open_url)
    put('brain', fake_brain)
    put('analyze_screen', lambda *a, **k: 'Bench: screen described.')
    put('analyze_camera', lambda *a, **k: 'Bench: camera described.')
    put('_screen_agent', lambda: _FakeAgent(rec))
    if not use_real_skills:
        put('_phase1', lambda: _FakeSkills(rec))

    def fake_research_search(query, ui, reply, style=None):
        rec.add('research', 'search', str(query)[:40])
        reply('Bench: search results.')
        return True

    def fake_research_deep(topic, ui, reply, style=None):
        rec.add('research', 'deep', str(topic)[:40])
        reply('Bench: deep research.')
        return True

    put('_run_research_search', fake_research_search)
    put('_run_research_deep', fake_research_deep)
    real_requests.post = fake_query
    real_requests.get = fake_query

    def restore():
        for name, value in saved.items():
            setattr(voice, name, value)
        real_requests.post, real_requests.get = real_post, real_get

    return restore


def run_one(voice, task, rec, use_real_skills=False):
    """Run a single task through the real router and classify the outcome."""
    rec.events, rec.network, rec.brain_calls = [], [], []
    # A task only expects the bridge to answer when the bridge IS the route.
    rec.bridge_handles = (task['expect']['route'] == 'bridge')
    restore = install_mocks(voice, rec, use_real_skills)
    started = time.perf_counter()
    handled = None
    error = None
    try:
        handled = voice.run_command(task['text'], 'http://127.0.0.1:7777',
                                    'http://127.0.0.1:7778', source='bench')
    except Exception as exc:                      # never let one task kill the run
        error = '%s: %s' % (type(exc).__name__, str(exc)[:120])
    finally:
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        restore()

    exp_route = task['expect']['route']
    exp_target = task['expect'].get('target')
    actual = rec.route()
    actual_target = rec.target()
    ok_route = (actual == exp_route)
    ok_target = True
    if exp_target and actual_target:
        ok_target = (str(exp_target).lower() == str(actual_target).lower())
    return {
        'id': task['id'], 'class': task['class'], 'text': task['text'],
        'expect_route': exp_route, 'expect_target': exp_target,
        'actual': actual, 'actual_target': actual_target,
        'ok': bool(ok_route and ok_target and not error),
        'ok_route': ok_route, 'ok_target': ok_target,
        'handled': bool(handled), 'error': error,
        'llm_calls': len(rec.brain_calls),
        'latency_ms': round(elapsed_ms, 2),
        'events': [list(e) for e in rec.events],
        'network_calls': rec.network,
        'live_safe': bool(task.get('live_safe')),
        'note': task.get('note', ''),
    }

def _p95(values):
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, int(round(0.95 * (len(ordered) - 1))))
    return ordered[idx]


def build_summary(rows, mode):
    n = len(rows)
    passed = sum(1 for r in rows if r['ok'])
    llm_rows = [r for r in rows if r['llm_calls'] > 0]
    latency = [r['latency_ms'] for r in rows]
    by_class = {}
    for r in rows:
        c = by_class.setdefault(r['class'], {'n': 0, 'pass': 0,
                                             'llm_calls': 0, 'ms': []})
        c['n'] += 1
        c['pass'] += 1 if r['ok'] else 0
        c['llm_calls'] += r['llm_calls']
        c['ms'].append(r['latency_ms'])
    for c in by_class.values():
        c['p50_ms'] = round(statistics.median(c['ms']), 2)
        del c['ms']
    return {
        'mode': mode,
        'tasks': n,
        'passed': passed,
        'failed': n - passed,
        'route_accuracy_pct': round(100.0 * passed / n, 1) if n else 0.0,
        'llm_free_tasks': n - len(llm_rows),
        'llm_free_pct': round(100.0 * (n - len(llm_rows)) / n, 1) if n else 0.0,
        'llm_calls_total': sum(r['llm_calls'] for r in rows),
        'latency_p50_ms': round(statistics.median(latency), 2) if latency else 0,
        'latency_p95_ms': round(_p95(latency), 2) if latency else 0,
        'latency_max_ms': round(max(latency), 2) if latency else 0,
        'errors': [r['id'] for r in rows if r['error']],
        'network_calls': sorted({u for r in rows for u in r['network_calls']}),
        'by_class': by_class,
    }


def print_report(summary, rows, calibrate=False):
    if calibrate:
        print('%-28s %-18s %-10s %s' % ('id', 'actual', 'target',
                                        'expectation'))
        print('-' * 96)
        for r in rows:
            mark = 'ok' if r['ok'] else 'MISMATCH want %s%s' % (
                r['expect_route'],
                '/' + str(r['expect_target']) if r['expect_target'] else '')
            print('%-28s %-18s %-10s %s'
                  % (r['id'], r['actual'], r['actual_target'] or '-', mark))
        print('')

    print('%-22s %5s %5s %10s %8s' % ('class', 'n', 'pass', 'llm_calls',
                                      'p50_ms'))
    print('-' * 56)
    for name, c in sorted(summary['by_class'].items()):
        print('%-22s %5d %5d %10d %8.2f'
              % (name, c['n'], c['pass'], c['llm_calls'], c['p50_ms']))
    print('-' * 56)
    print('%-22s %5d %5d %10d %8.2f'
          % ('TOTAL', summary['tasks'], summary['passed'],
             summary['llm_calls_total'], summary['latency_p50_ms']))

    failures = [r for r in rows if not r['ok']]
    if failures:
        print('')
        print('FAILURES (%d):' % len(failures))
        for r in failures:
            reason = 'error=' + r['error'] if r['error'] else ''
            if not reason and not r['ok_route']:
                reason = ('routed to %r, expected %r'
                          % (r['actual'], r['expect_route']))
            if not reason and not r['ok_target']:
                reason = ('target %r, expected %r'
                          % (r['actual_target'], r['expect_target']))
            print('  %-28s %-52s %s' % (r['id'], r['text'][:50], reason))

    print('')
    print('=' * 64)
    print('%s benchmark (router only)' % summary['mode'])
    print('  route accuracy      : %s%%  (%d/%d)'
          % (summary['route_accuracy_pct'], summary['passed'],
             summary['tasks']))
    print('  LLM-free commands   : %s%%  (%d/%d)  <- cost proxy'
          % (summary['llm_free_pct'], summary['llm_free_tasks'],
             summary['tasks']))
    print('  brain calls total   : %d' % summary['llm_calls_total'])
    print('  router latency      : p50 %.2f ms | p95 %.2f ms | max %.2f ms'
          % (summary['latency_p50_ms'], summary['latency_p95_ms'],
             summary['latency_max_ms']))
    print('  unexpected network  : %s'
          % (summary['network_calls'] or 'none'))
    if summary['errors']:
        print('  task errors         : %s' % summary['errors'])
    print('=' * 64)
