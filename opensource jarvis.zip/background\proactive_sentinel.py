"""
Proactive Sentinel & Cinematic System Diagnostics
=================================================
Transforms JARVIS into an autonomous, proactive Stark-level companion.

Features:
1. Cinematic System Diagnostic Routine:
   Generates a full Stark-style status report (CPU, RAM, Battery, AC state, Bridge, Models)
   invoked via voice commands like:
     - "system status" / "status report"
     - "run diagnostics" / "vitals report" / "diagnostic report"
     - "system kaisa hai" / "kaisa chal raha hai"

2. Autonomous Proactive Vitals Sentinel:
   A lightweight background watchdog loop (runs every 30s) that monitors hardware
   telemetry and proactively advises the user via spoken voice:
     - Low Battery Warning (<20% on DC power)
     - Critical Battery Advisory (<10%)
     - AC Power Restoration confirmation
     - Sustained CPU / Memory runaway thread alerts (>90%)
     - Session welcome / initial diagnostic greeting

Architecture Rules (AGENTS.md):
- Strictly additive. Never creates a second voice or mic pipeline.
- Uses existing voice_engine speak callback.
- Guarded by sleep mode and speaking state: never interrupts or spams.
- Anti-spam hysteresis: strict independent cooldowns per advisory category.
"""
from __future__ import annotations

import os
import sys
import time
import threading
from typing import Callable, Optional, Dict, Any

try:
    from . import telemetry
except ImportError:
    try:
        import telemetry  # type: ignore
    except ImportError:
        telemetry = None


# Advisory cooldowns in seconds
COOLDOWN_LOW_BATTERY = 25 * 60       # 25 minutes
COOLDOWN_CRITICAL_BATTERY = 10 * 60  # 10 minutes
COOLDOWN_AC_RESTORED = 5 * 60        # 5 minutes
COOLDOWN_RESOURCE_SPIKE = 30 * 60    # 30 minutes
COOLDOWN_SESSION_GREETING = 60 * 60  # 1 hour

_LOCK = threading.RLock()
_LAST_ALERTS: Dict[str, float] = {}
_WAS_LOW_BATTERY = False
_CPU_SPIKE_COUNT = 0
_PROACTIVE_ENABLED = True
_SENTINEL_THREAD: Optional[threading.Thread] = None
_STOP_EVENT = threading.Event()


def is_proactive_enabled() -> bool:
    global _PROACTIVE_ENABLED
    with _LOCK:
        return _PROACTIVE_ENABLED


def set_proactive_enabled(enabled: bool) -> bool:
    global _PROACTIVE_ENABLED
    with _LOCK:
        _PROACTIVE_ENABLED = bool(enabled)
        return _PROACTIVE_ENABLED


def _can_fire(alert_key: str, cooldown_s: float) -> bool:
    now = time.monotonic()
    last = _LAST_ALERTS.get(alert_key, 0.0)
    if now - last >= cooldown_s:
        _LAST_ALERTS[alert_key] = now
        return True
    return False


def generate_diagnostic_report(lang: str = "en") -> str:
    """Generate a crisp, cinematic Stark diagnostic voice report."""
    parts = []
    
    # 1. Telemetry Snapshot
    bat_info = {}
    cpu_pct = None
    mem_pct = None
    if telemetry is not None:
        try:
            bat_info = telemetry.battery()
        except Exception:
            bat_info = {}
        try:
            c = telemetry.cpu()
            cpu_pct = c.get("percent") if isinstance(c, dict) else None
        except Exception:
            cpu_pct = None
        try:
            m = telemetry.memory()
            mem_pct = m.get("percent") if isinstance(m, dict) else None
        except Exception:
            mem_pct = None

    is_hindi = lang in ("hi", "hinglish")

    if is_hindi:
        intro = "Sir, all subroutines nominal hain."
        details = []
        if cpu_pct is not None:
            details.append(f"CPU {int(cpu_pct)} percent par chal raha hai")
        if mem_pct is not None:
            details.append(f"RAM {int(mem_pct)} percent use ho rahi hai")
        if bat_info.get("available") and bat_info.get("percent") is not None:
            pct = int(bat_info["percent"])
            plugged = bat_info.get("plugged")
            state_str = "charging" if plugged else "battery par"
            details.append(f"Battery {pct} percent {state_str} hai")
        
        detail_msg = ", ".join(details) if details else "Hardware telemetry live hai"
        return f"{intro} {detail_msg}. Voice core aur OS bridge active hain. Main aadesh ke liye taiyar hoon."
    else:
        intro = "All subroutines nominal, Sir."
        details = []
        if cpu_pct is not None:
            details.append(f"CPU load is at {int(cpu_pct)} percent")
        if mem_pct is not None:
            details.append(f"memory utilization is {int(mem_pct)} percent")
        if bat_info.get("available") and bat_info.get("percent") is not None:
            pct = int(bat_info["percent"])
            plugged = bat_info.get("plugged")
            p_str = "on external AC power" if plugged else "discharging on internal cell"
            details.append(f"battery level is {pct} percent {p_str}")
        
        detail_msg = ", ".join(details) if details else "telemetry channels reporting nominal"
        return f"{intro} Voice core and OS action bridge online. {detail_msg.capitalize()}. Standing by for your instructions."


def evaluate_sentinel_tick(
    speak_fn: Callable[[str], Any],
    is_sleeping_fn: Callable[[], bool],
    is_speaking_fn: Callable[[], bool],
    lang: str = "en"
) -> Optional[str]:
    """Single tick evaluation for proactive hardware alerts."""
    global _WAS_LOW_BATTERY, _CPU_SPIKE_COUNT

    if not is_proactive_enabled():
        return None

    # Never interrupt if user/JARVIS is speaking, listening, or sleeping
    if is_sleeping_fn() or is_speaking_fn():
        return None

    if telemetry is None:
        return None

    # 1. Battery Health Check
    try:
        bat = telemetry.battery()
    except Exception:
        bat = {}

    if bat.get("available") and bat.get("percent") is not None:
        pct = float(bat["percent"])
        plugged = bool(bat.get("plugged"))

        # Low battery advisory (< 20% and not plugged in)
        if not plugged and pct <= 20.0:
            _WAS_LOW_BATTERY = True
            if pct <= 10.0 and _can_fire("battery_critical", COOLDOWN_CRITICAL_BATTERY):
                msg = (
                    f"Sir, critical power warning: battery is at {int(pct)} percent. "
                    "System shutdown is imminent without external AC connection."
                    if lang == "en" else
                    f"Sir, emergency power alert: battery sirf {int(pct)} percent bachi hai. "
                    "Kripya turant laptop charger connect kijiye."
                )
                speak_fn(msg)
                return "battery_critical"
            elif pct > 10.0 and _can_fire("battery_low", COOLDOWN_LOW_BATTERY):
                msg = (
                    f"Pardon the intrusion, Sir: power reserves have dropped to {int(pct)} percent. "
                    "Connecting to external power is strongly advised."
                    if lang == "en" else
                    f"Sir, battery {int(pct)} percent par aa gayi hai. Charger connect kar lijiye."
                )
                speak_fn(msg)
                return "battery_low"

        # AC Power Restored
        elif plugged and _WAS_LOW_BATTERY:
            _WAS_LOW_BATTERY = False
            if _can_fire("ac_restored", COOLDOWN_AC_RESTORED):
                msg = (
                    f"External power restored, Sir. System battery is charging at {int(pct)} percent."
                    if lang == "en" else
                    f"Sir, AC power connect ho gayi hai. Battery {int(pct)} percent par charge ho rahi hai."
                )
                speak_fn(msg)
                return "ac_restored"

    # 2. Sustained Resource Spike Watchdog
    try:
        cpu_data = telemetry.cpu()
        cpu_val = float(cpu_data.get("percent") or 0.0) if isinstance(cpu_data, dict) else 0.0
    except Exception:
        cpu_val = 0.0

    if cpu_val >= 90.0:
        _CPU_SPIKE_COUNT += 1
    else:
        _CPU_SPIKE_COUNT = 0

    if _CPU_SPIKE_COUNT >= 3:  # ~90 seconds of sustained 90%+ CPU
        _CPU_SPIKE_COUNT = 0
        if _can_fire("cpu_spike", COOLDOWN_RESOURCE_SPIKE):
            top_name = "an active background process"
            try:
                procs = telemetry.top_processes(limit=1)
                if procs and isinstance(procs[0], dict) and procs[0].get("name"):
                    top_name = procs[0]["name"]
            except Exception:
                pass
            msg = (
                f"Sir, sustained CPU utilization has crossed 90 percent, primarily consumed by {top_name}."
                if lang == "en" else
                f"Sir, system CPU usage 90 percent se upar ja chuka hai, mukhya roop se {top_name} ke dwara."
            )
            speak_fn(msg)
            return "cpu_spike"

    return None


def start_sentinel_background(
    speak_fn: Callable[[str], Any],
    is_sleeping_fn: Callable[[], bool],
    is_speaking_fn: Callable[[], bool],
    lang: str = "en"
) -> bool:
    """Start the autonomous proactive guardian watchdog daemon."""
    global _SENTINEL_THREAD, _STOP_EVENT

    with _LOCK:
        if _SENTINEL_THREAD is not None and _SENTINEL_THREAD.is_alive():
            return True
        _STOP_EVENT.clear()

        def _sentinel_loop():
            # Initial boot welcome delay (allow audio/services 8 seconds to settle)
            time.sleep(8.0)
            if not _STOP_EVENT.is_set() and is_proactive_enabled() and not is_sleeping_fn():
                if _can_fire("session_greeting", COOLDOWN_SESSION_GREETING):
                    hour = time.localtime().tm_hour
                    greeting = "Good morning" if 5 <= hour < 12 else ("Good afternoon" if 12 <= hour < 18 else "Good evening")
                    bat_str = ""
                    try:
                        b = telemetry.battery() if telemetry else {}
                        if b.get("available") and b.get("percent") is not None:
                            bat_str = f" Power reserves at {int(b['percent'])} percent."
                    except Exception:
                        pass
                    msg = (
                        f"{greeting}, Sir. Diagnostic subroutines nominal.{bat_str} J.A.R.V.I.S standing by."
                        if lang == "en" else
                        f"Namaste Sir. JARVIS systems active hain.{bat_str} Main aapki sewa ke liye taiyar hoon."
                    )
                    speak_fn(msg)

            # Continuous 30s hardware polling loop
            while not _STOP_EVENT.is_set():
                try:
                    evaluate_sentinel_tick(speak_fn, is_sleeping_fn, is_speaking_fn, lang=lang)
                except Exception:
                    pass
                for _ in range(30):
                    if _STOP_EVENT.is_set():
                        break
                    time.sleep(1.0)

        _SENTINEL_THREAD = threading.Thread(
            target=_sentinel_loop,
            daemon=True,
            name="jarvis-proactive-sentinel"
        )
        _SENTINEL_THREAD.start()
        return True


def stop_sentinel_background():
    """Stop the sentinel thread gracefully."""
    global _STOP_EVENT, _SENTINEL_THREAD
    with _LOCK:
        _STOP_EVENT.set()
        _SENTINEL_THREAD = None
