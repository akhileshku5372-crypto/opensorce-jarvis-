  function drawBrain(brain) {
    const canvas = $('#brain-canvas')
    if (!canvas || !canvas.getContext) return
    const reduce = Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
    const ctx = canvas.getContext('2d')
    const lobe = String(brain?.lobe || (_lastBrain?.lobe)|| '').toLowerCase()
    cancelAnimationFrame(_brainRaf)
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const rect = canvas.getBoundingClientRect()
    const W = Math.max(360, Math.round(rect.width * dpr))
    const H = Math.round(360 * dpr)
    canvas.width = W; canvas.height = H
    canvas.style.width = rect.width + 'px'
    canvas.style.height = '360px'
    function frame() {
      _brainPhase += reduce ? 0.006 : 0.016
      if (_brainAuto && !_brainDragging && !reduce) _brainYaw += 0.0032
      _brainDist += (_brainTargetDist - _brainDist) * 0.12
      ctx.clearRect(0,0,W,H)
      const g = ctx.createRadialGradient(W/2, H/2 - 10*dpr, 20*dpr, W/2, H/2 - 10*dpr, 260*dpr)
      g.addColorStop(0,'rgba(25,230,255,0.16)'); g.addColorStop(0.45,'rgba(13,60,80,0.18)'); g.addColorStop(1,'rgba(0,0,0,0)')
      ctx.fillStyle = g; ctx.fillRect(0,0,W,H)
      if (!reduce) {
        ctx.fillStyle = 'rgba(142,232,255,0.18)'
        for (let i=0;i<28;i++){
          const a = (i* 137.5 + _brainPhase*18) % 360
          const r = 160 + (i%4)*18
          const th = a*Math.PI/180
          const sx = W/2 + Math.cos(th)*r*dpr*0.55
          const sy = H/2 + Math.sin(th)*r*dpr*0.38 - 18*dpr
          const op = 0.12 + 0.10*Math.sin(_brainPhase*0.9 + i)
          ctx.globalAlpha = op
          ctx.beginPath(); ctx.arc(sx,sy, (i%3===0?1.2:0.7)*dpr, 0, Math.PI*2); ctx.fill()
        }
        ctx.globalAlpha = 1
      }
      _brainWireframe(ctx, _brainYaw, _brainPitch, _brainDist, W, H, dpr)
      const active = lobe || 'prefrontal_cortex'
      const proj = _BRAIN_NODES_3D.map(n=>{ const p = _brainProject(n, _brainYaw, _brainPitch, _brainDist, W, H); return { ...n, px: p.x, py: p.y, scale: p.scale, z: p.z, visible: p.visible } })
      _brainProjectCache = proj
      ctx.lineWidth = 1.5 * dpr
      for (const [a,b] of _BRAIN_EDGES) {
        const na = proj.find(n=>n.id===a), nb = proj.find(n=>n.id===b)
        if (!na || !nb || !na.visible || !nb.visible) continue
        const isActive = (a===active || b===active)
        const avgZ = (na.z + nb.z)/2
        const depthFade = Math.max(0.28, Math.min(1, 1 - (avgZ+120)/420))
        ctx.globalAlpha = depthFade
        ctx.strokeStyle = isActive ? 'rgba(25,230,255,'+(0.55+0.35*depthFade)+')' : 'rgba(111,145,160,'+(0.22+0.18*depthFade)+')'
        ctx.beginPath(); ctx.moveTo(na.px, na.py); ctx.lineTo(nb.px, nb.py); ctx.stroke()
        ctx.globalAlpha = 1
        if (isActive && !reduce) {
          const t = (_brainPhase % 1)
          const x = na.px + (nb.px-na.px)*t, y = na.py + (nb.py-na.py)*t
          const col = _BRAIN_NODES_3D.find(n=>n.id===active)?.color || '#19e6ff'
          ctx.fillStyle = col; ctx.shadowColor = col; ctx.shadowBlur = 10*dpr
          ctx.beginPath(); ctx.arc(x,y, 3.0*dpr, 0, Math.PI*2); ctx.fill(); ctx.shadowBlur = 0
        }
      }
      const sorted = [...proj].sort((a,b)=>a.z-b.z)
      for (const n of sorted) {
        if (!n.visible) continue
        const isActive = n.id === active
        const isHover = n.id === _brainHover
        const isPinned = n.id === _brainPinned
        const pulse = (isActive || isHover) && !reduce ? 1 + Math.sin(_brainPhase*2.4 + n.x*0.01)*0.07 : 1
        const r = n.r * dpr * n.scale * pulse
        const depthAlpha = Math.max(0.35, Math.min(1, 1.15 - (n.z+130)/380))
        ctx.globalAlpha = depthAlpha
        if (isActive || isHover || isPinned) { ctx.fillStyle = isPinned ? n.color+'30' : n.color+'22'; ctx.beginPath(); ctx.arc(n.px, n.py, r+14*dpr*n.scale, 0, Math.PI*2); ctx.fill(); if (isPinned) { ctx.strokeStyle = n.color; ctx.lineWidth = 1.2*dpr; ctx.stroke() } }
        const grad = ctx.createRadialGradient(n.px - r*0.32, n.py - r*0.42, r*0.18, n.px, n.py, r)
        if (isActive || isHover || isPinned) { grad.addColorStop(0, '#ffffff'); grad.addColorStop(0.22, n.color); grad.addColorStop(1, '#081019') }
        else { grad.addColorStop(0, '#1a3242'); grad.addColorStop(1, '#0a1a24') }
        ctx.fillStyle = grad
        ctx.strokeStyle = (isActive || isHover || isPinned) ? '#e6fbff' : 'rgba(111,145,160,'+(0.42+0.22*depthAlpha)+')'
        ctx.lineWidth = (isActive || isHover || isPinned) ? 1.8*dpr : 1.05*dpr
        ctx.beginPath(); ctx.arc(n.px, n.py, r, 0, Math.PI*2); ctx.fill(); ctx.stroke()
        if (n.scale > 0.52) {
          ctx.fillStyle = (isActive || isHover || isPinned) ? '#021018' : '#b7d5e0'
          const fs = Math.max(7, Math.round(7.5 * n.scale * dpr)) 
          ctx.font = `700 ${fs}px Rajdhani, Inter, sans-serif`
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
          const lab = n.scale < 0.72 ? n.abbr : n.label
          ctx.fillText(lab, n.px, n.py)
        }
        ctx.globalAlpha = 1
      }
      if (!reduce) {
        const vg = ctx.createRadialGradient(W/2,H/2, Math.min(W,H)*0.38, W/2,H/2, Math.min(W,H)*0.72)
        vg.addColorStop(0,'rgba(0,0,0,0)'); vg.addColorStop(1,'rgba(0,0,0,0.42)')
        ctx.fillStyle = vg; ctx.fillRect(0,0,W,H)
      }
      if (!reduce) _brainRaf = requestAnimationFrame(frame)
    }
    frame()
    if (_brainHover) {
      const h = _brainProjectCache.find(n=>n.id===_brainHover)
      if (h) _showBrainTooltip(_BRAIN_NODES_3D.find(n=>n.id===_brainHover), h.px/dpr, h.py/dpr)
    }
  }
  function _brainPick(px, py, dpr) {
    let best = null, bestD = 1e9
    for (const n of _brainProjectCache) {
      if (!n.visible) continue
      const dx = px - n.px, dy = py - n.py
      const r = (n.r * dpr * n.scale) + 12*dpr
      const d = Math.hypot(dx, dy)
      if (d < r && d < bestD) { best = n.id; bestD = d }
    }
    return best
  }
  function bindBrain() {
    const canvas = document.getElementById('brain-canvas')
    const wrap = document.getElementById('brain-canvas-wrap')
    const resetBtn = document.getElementById('brain-orbit-reset')
    const autoChk = document.getElementById('brain-autorotate')
    if (autoChk) { autoChk.checked = _brainAuto; autoChk.addEventListener('change', ()=>{ _brainAuto = autoChk.checked }) }
    if (resetBtn) resetBtn.addEventListener('click', ()=>{
      _brainYaw = -0.42; _brainPitch = -0.16; _brainTargetDist = 180; _brainPinned = null; _brainHover=null; _hideBrainTooltip();
      const ins=$('#brain-inspector'); if(ins) ins.hidden=true;
      drawBrain(_lastBrain)
      showToast('Hologram reset')
    })
    document.getElementById('brain-inspector-close')?.addEventListener('click', ()=>{
      _brainPinned=null; _hideBrainTooltip(); const ins=$('#brain-inspector'); if(ins) ins.hidden=true; drawBrain(_lastBrain)
    })
    $('#brain-refresh')?.addEventListener('click', async () => {
      try {
        const r = await fetch('http://127.0.0.1:7780/brain', { cache:'no-store', signal: AbortSignal.timeout(2000) })
        const j = await r.json()
        renderBrain({ brain: j.brain, brain_revision: j.brain_revision })
        showToast('Brain refreshed')
      } catch { showToast('Brain refresh failed — core offline', true) }
    })
    $('#brain-topology')?.addEventListener('click', async ()=>{
      const mini=$('#brain-topology-mini')
      if(!mini) return
      const open = !mini.hidden
      if(open){ mini.hidden=true; return }
      mini.hidden=false; mini.textContent='Loading topology…'
      try{
        const [b, s] = await Promise.all([
          fetch('http://127.0.0.1:7780/brain', {cache:'no-store', signal: AbortSignal.timeout(2000)}).then(r=>r.json()).catch(()=>null),
          fetch('http://127.0.0.1:7780/state', {cache:'no-store', signal: AbortSignal.timeout(2000)}).then(r=>r.json()).catch(()=>null),
        ])
        _brainTopology = { ...(b||{}), ...(s||{}) }
        const lines=[]
        const brain=(b&&b.brain)|| (s&&s.brain) || _lastBrain
        if(brain) lines.push('Last lobe: '+(brain.lobe||'—')+'  lang='+ (brain.language||'—')+'  w='+(brain.token_weight||'—'))
        if(s && s.revision!=null) lines.push('State rev: '+s.revision+'  brain_rev: '+(s.brain_revision||0))
        if(b && b.brain) lines.push('Brain: '+ JSON.stringify(b.brain, null, 2).slice(0,900))
        if(!lines.length) lines.push('Topology: core offline — showing hologram only.')
        mini.textContent=lines.join('\n\n')
        _updateInspector(_lastBrain)
      }catch(e){ mini.textContent='Topology unavailable: '+ String(e).slice(0,180) }
    })
    const getPos = (ev)=>{
      const rect = canvas.getBoundingClientRect()
      const src = ev.touches ? ev.touches[0] : ev
      return { x: (src.clientX - rect.left), y: (src.clientY - rect.top), rect }
    }
    const onDown = (ev)=>{
      const p=getPos(ev)
      _brainDragging=true
      _brainDragStart={ x:p.x, y:p.y, yaw:_brainYaw, pitch:_brainPitch }
      if(wrap) wrap.style.cursor='grabbing'
      ev.preventDefault()
    }
    const onMove = (ev)=>{
      const p=getPos(ev)
      if(_brainDragging){
        const dx=p.x - _brainDragStart.x, dy=p.y - _brainDragStart.y
        _brainYaw = _brainDragStart.yaw + dx * 0.0085
        _brainPitch = Math.max(-0.92, Math.min(0.92, _brainDragStart.pitch + dy * 0.0085))
        return
      }
      const dpr=Math.min(window.devicePixelRatio||1,2)
      const px=p.x*dpr, py=p.y*dpr
      const pick=_brainPick(px, py, 1)
      if(pick!==_brainHover){
        _brainHover=pick
        if(pick){
          const node=_BRAIN_NODES_3D.find(n=>n.id===pick)
          const proj=_brainProjectCache.find(n=>n.id===pick)
          if(node && proj) _showBrainTooltip(node, proj.px/dpr, proj.py/dpr)
          canvas.style.cursor='pointer'
        } else { _hideBrainTooltip(); canvas.style.cursor='grab' }
        _updateInspector(_lastBrain)
      } else if(pick){
        const proj=_brainProjectCache.find(n=>n.id===pick)
        if(proj) { const tip=$('#brain-tooltip'); if(tip){ tip.style.left=proj.px/dpr+'px'; tip.style.top=proj.py/dpr+'px' } }
      }
    }
    const onUp=(ev)=>{
      if(_brainDragging){
        _brainDragging=false
        if(wrap) wrap.style.cursor='grab'
        if(ev && ev.type==='mouseup'){
          const p=getPos(ev)
          const moved=Math.hypot(p.x-_brainDragStart.x, p.y-_brainDragStart.y)
          if(moved<6){
            const dpr=Math.min(window.devicePixelRatio||1,2)
            const pick=_brainPick(p.x*dpr, p.y*dpr, 1)
            if(pick){ _brainPinned = _brainPinned===pick? null : pick; _updateInspector(_lastBrain) }
          }
        }
      }
    }
    if(canvas){
      canvas.addEventListener('mousedown', onDown)
      window.addEventListener('mousemove', onMove)
      window.addEventListener('mouseup', onUp)
      canvas.addEventListener('touchstart', onDown, {passive:false})
      window.addEventListener('touchmove', onMove, {passive:false})
      window.addEventListener('touchend', onUp)
      canvas.addEventListener('wheel', (ev)=>{
        ev.preventDefault()
        const delta = Math.sign(ev.deltaY) * 22
        _brainTargetDist = Math.max(60, Math.min(360, _brainTargetDist + delta))
      }, {passive:false})
      canvas.addEventListener('mouseleave', ()=>{ _hideBrainTooltip(); _brainHover=null; _updateInspector(_lastBrain) })
    }
    drawBrain(null)
    let _brainRsz = 0
    window.addEventListener('resize', () => {
      clearTimeout(_brainRsz)
      _brainRsz = setTimeout(() => drawBrain(_lastBrain), 180)
    })
  }

  async function checkBridge() {
    const url = state.settings.bridgeUrl || 'http://127.0.0.1:7778'
    try {
      const response = await fetch(`${url.replace(/\/$/, '')}/api/status`, { signal: AbortSignal.timeout(1600) })
      if (!response.ok) throw new Error()
      const data = await response.json()
      setBridgeStatus(true, data)
    } catch { setBridgeStatus(false) }
  }

  function setBridgeStatus(online, data = {}) {
    state.bridgeOnline = online
    const supported = online && data.platformSupported !== false
    if (!state.coreOnline) $('#bridge-label').textContent = supported ? 'BRIDGE ONLINE' : online ? 'COMPATIBILITY MODE' : 'BRIDGE OFFLINE'
    $('#connection-chip').textContent = supported ? 'Windows bridge connected' : online ? 'Bridge connected — Windows actions unavailable' : 'Local bridge disconnected'
    $('#connection-chip').classList.toggle('offline', !online)
    if (online) {
      const metrics = data.metrics || data.system || {}
      updateMetric('cpu', metrics.cpu)
      updateMetric('ram', metrics.ram || metrics.memory)
      updateMetric('disk', metrics.disk)
      updateMetric('batt', metrics.battery)
      $('#system-note').textContent = data.active_window ? `Active: ${data.active_window}` : 'Live system telemetry connected.'
    }
    updateStatusReadouts()
  }

  function updateMetric(name, value) {
    if (value == null) return
    const number = Math.max(0, Math.min(100, Number(value)))
    const readout = $(`#${name}-value`)
    if (readout) readout.textContent = `${Math.round(number)}%`
    const bar = $(`#${name}-bar`)
    if (bar) bar.style.width = `${number}%`
    // Rail gauge rings share the SAME bridge numbers — no invented telemetry.
    const ring = $(`#ring-${name}`)
    if (ring) {
      ring.style.strokeDashoffset = String(113.1 * (1 - number / 100))
      const wrap = ring.closest('.ring')
      if (wrap) {
        wrap.classList.toggle('warn', number >= 75 && number < 90)
        wrap.classList.toggle('hot', number >= 90)
      }
    }
    const ringValue = $(`#ring-${name}-value`)
    if (ringValue) ringValue.textContent = `${Math.round(number)}%`
    updateMiniSystem()
  }

  function updateMiniSystem() {
    const mini = $('#mini-system')
    if (!mini) return
    const read = (id) => $(`#${id}-value`)?.textContent || '--%'
    mini.textContent = `CPU ${read('cpu')} · RAM ${read('ram')} · DISK ${read('disk')}`
  }

  function bindStorageFeatures() {
    $('#save-note')?.addEventListener('click', () => {
      const value = $('#note-input').value.trim()
      if (!value) return
      const notes = JSON.parse(localStorage.getItem('jarvis-notes') || '[]')
      notes.unshift({ id: Date.now(), text: value })
      localStorage.setItem('jarvis-notes', JSON.stringify(notes.slice(0, 20)))
      $('#note-input').value = ''
      renderSavedItems()
      showToast('Note saved on this device.')
    })
    $('#save-reminder')?.addEventListener('click', () => {
      const text = $('#reminder-text').value.trim(), time = $('#reminder-time').value
      if (!text || !time) return showToast('Add reminder details and time.', true)
      const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
      reminders.push({ id: Date.now(), text, time })
      localStorage.setItem('jarvis-reminders', JSON.stringify(reminders))
      $('#reminder-text').value = ''; $('#reminder-time').value = ''
      renderSavedItems(); showToast('Reminder saved on this device.')
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {})
    })
    document.addEventListener('click', (event) => {
      const button = event.target.closest('[data-delete-type]')
      if (!button) return
      const key = button.dataset.deleteType === 'note' ? 'jarvis-notes' : 'jarvis-reminders'
      const items = JSON.parse(localStorage.getItem(key) || '[]').filter((item) => String(item.id) !== button.dataset.deleteId)
      localStorage.setItem(key, JSON.stringify(items)); renderSavedItems()
    })
  }

  function checkDueReminders() {
    const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
    let changed = false
    for (const reminder of reminders) {
      if (!reminder.notified && new Date(reminder.time).getTime() <= Date.now()) {
        reminder.notified = true; changed = true
        showToast(`Reminder: ${reminder.text}`); speak(`Reminder. ${reminder.text}`)
        if ('Notification' in window && Notification.permission === 'granted') new Notification('JARVIS reminder', { body: reminder.text })
      }
    }
    if (changed) localStorage.setItem('jarvis-reminders', JSON.stringify(reminders))
  }

  function renderSavedItems() {
    const notes = JSON.parse(localStorage.getItem('jarvis-notes') || '[]')
    const reminders = JSON.parse(localStorage.getItem('jarvis-reminders') || '[]')
    if ($('#notes-list')) $('#notes-list').innerHTML = notes.map((item) => `<div class="saved-item"><span>${escapeHtml(item.text)}</span><button data-delete-type="note" data-delete-id="${item.id}">×</button></div>`).join('')
    if ($('#reminders-list')) $('#reminders-list').innerHTML = reminders.map((item) => `<div class="saved-item"><span>${escapeHtml(item.text)}<br><small>${new Date(item.time).toLocaleString()}</small></span><button data-delete-type="reminder" data-delete-id="${item.id}">×</button></div>`).join('')
    if ($('#dashboard-reminders') && reminders.length) $('#dashboard-reminders').innerHTML = `<i data-lucide="calendar-clock"></i><strong>${escapeHtml(reminders[0].text)}</strong><small>${new Date(reminders[0].time).toLocaleString()}</small>`
    if (window.lucide) window.lucide.createIcons()
  }

  // ── Memory Core: persistent ChromaDB store (voice engine :7780 /memory) ──
  // The browser panel mirrors the server-side `jarvis_memory` collection.
  // localStorage remains a read cache when the voice engine is offline.
  const MEMORY_CORE_URL = 'http://127.0.0.1:7780'

  async function refreshMemoryCore() {
    // R