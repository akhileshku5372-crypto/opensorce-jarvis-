import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  FileText,
  BookOpen,
  Globe,
  StickyNote,
  FolderOpen,
  Plus,
  Upload,
  Check,
  Sparkles,
} from 'lucide-react';
import {
  MaterialItem,
  SourceType,
  SkillCategory,
  SoftSubcategory,
  HardSubcategory,
  SOFT_SUBCATEGORIES,
  HARD_SUBCATEGORIES,

  formatCleanShelfTitle,
} from '../data/archiveData';

interface AddMaterialModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCategory?: SkillCategory;
  initialType?: SourceType;
  existingMaterials: MaterialItem[];
  onAddMaterial: (item: MaterialItem, selectImmediately?: boolean) => void;
  onLoadAllPresets: () => void;
  onSelectExisting: (item: MaterialItem) => void;
}

export const AddMaterialModal: React.FC<AddMaterialModalProps> = ({
  isOpen,
  onClose,
  initialCategory = 'soft',
  initialType = 'PDF',
  existingMaterials,
  onAddMaterial,
  onLoadAllPresets,
  onSelectExisting,
}) => {
  const [tab, setTab] = useState<'upload' | 'presets'>('upload');
  const [category, setCategory] = useState<SkillCategory>(initialCategory);
  const [sourceType, setSourceType] = useState<SourceType>(initialType);
  const [subcategory, setSubcategory] = useState<SoftSubcategory | HardSubcategory>(
    initialCategory === 'soft' ? 'COMMUNICATION' : 'TECH'
  );
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [contentBody, setContentBody] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setCategory(initialCategory);
      setSourceType(initialType);
      setSubcategory(initialCategory === 'soft' ? 'COMMUNICATION' : 'TECH');
    }
  }, [isOpen, initialCategory, initialType]);

  if (!isOpen) return null;

  const handleCategoryChange = (cat: SkillCategory) => {
    setCategory(cat);
    setSubcategory(cat === 'soft' ? 'COMMUNICATION' : 'TECH');
  };

  // Direct file upload from PC — cleans messy filenames and mounts in 3D physical form on the shelf
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeMb =
      file.size > 1024 * 1024
        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
        : `${Math.max(1, Math.round(file.size / 1024))} KB`;

    let detectedType: SourceType = sourceType;
    if (file.name.toLowerCase().endsWith('.pdf')) detectedType = 'PDF';
    else if (file.name.toLowerCase().endsWith('.md') || file.name.toLowerCase().endsWith('.txt'))
      detectedType = 'Notes';

    // Use custom title if user already typed one, otherwise clean the uploaded filename
    const cleanName = title.trim()
      ? title.trim()
      : formatCleanShelfTitle(file.name, category, detectedType);

    setTitle(cleanName);
    setSourceType(detectedType);
    setFileSize(sizeMb);
    setAuthor('Local Device Upload');

    const reader = new FileReader();
    reader.onload = (ev) => {
      const rawText = typeof ev.target?.result === 'string' ? ev.target.result : '';
      const cleanParagraphs =
        rawText && !file.name.toLowerCase().endsWith('.pdf')
          ? rawText
              .slice(0, 3000)
              .split(/\n+/)
              .map((p) => p.trim())
              .filter(Boolean)
          : [
              `Prepare thoroughly — Review the core concepts and chapters inside "${cleanName}".`,
              `Start small — Test key takeaways in focused practical exercises.`,
              `Focus on the message — Synthesize the high-value insights from "${cleanName}".`,
            ];

      const newItem: MaterialItem = {
        id: `${category}-${Date.now()}`,
        title: cleanName,
        subtitle: `${subcategory} · ${detectedType}`,
        type: detectedType,
        category,
        subcategory,
        author: 'Uploaded Document · 12 Chapters',
        dateAdded: 'Oct 19, 2026',
        durationOrPages: '12 Chapters',
        fileSize: sizeMb,
        physicalLook:
          detectedType === 'PDF'
            ? 'pdf-binder'
            : detectedType === 'Notes'
            ? 'cream-notebook'
            : 'dark-book',
        summary: `Based on the selected source "${cleanName}", here are the key techniques and insights extracted from your uploaded ${detectedType}:`,
        paragraphs: cleanParagraphs,
        keyTakeaways: [
          `Prepare thoroughly — Master the core sections of ${cleanName}.`,
          `Start small — Apply the foundational steps incrementally.`,
          `Focus on the message — Keep your attention on practical outcomes.`,
        ],
        linkedIds: [],
      };

      onAddMaterial(newItem, true);
      setTitle('');
      setContentBody('');
      onClose();
    };
    reader.readAsText(file);
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const cleanTitle = title.trim();
    const paragraphs = contentBody
      .split(/\n+/)
      .map((p) => p.trim())
      .filter(Boolean);

    const newItem: MaterialItem = {
      id: `${category}-${Date.now()}`,
      title: cleanTitle,
      subtitle: `${subcategory} · ${sourceType}`,
      type: sourceType,
      category,
      subcategory,
      author: author.trim() || 'Archive Source · 10 Chapters',
      dateAdded: 'Oct 19, 2026',
      durationOrPages: '10 Chapters',
      fileSize: fileSize || '2.4 MB',
      physicalLook:
        sourceType === 'PDF'
          ? 'pdf-binder'
          : sourceType === 'Notes'
          ? 'cream-notebook'
          : 'dark-book',
      summary:
        paragraphs[0] ||
        `Based on the selected source "${cleanTitle}", here are the key techniques and insights:`,
      paragraphs:
        paragraphs.length > 0
          ? paragraphs
          : [
              `1. Prepare thoroughly — Master the core concepts of ${cleanTitle}.`,
              `2. Start small — Apply ${subcategory.toLowerCase()} techniques in focused steps.`,
              `3. Focus on the message — Prioritize clarity and measurable outcomes.`,
            ],
      keyTakeaways: [
        `Prepare thoroughly — Know the core principles of ${cleanTitle} deeply.`,
        'Start small — Build mastery through consistent daily practice.',
        'Focus on the message — Concentrate on the value and practical application.',
      ],
      linkedIds: [],
    };

    onAddMaterial(newItem, true);
    setTitle('');
    setContentBody('');
    onClose();
  };

  const getTypeIcon = (type: SourceType) => {
    switch (type) {
      case 'PDF':
        return <FileText className="w-4 h-4" />;
      case 'Book':
        return <BookOpen className="w-4 h-4" />;
      case 'Web':
        return <Globe className="w-4 h-4" />;
      case 'Notes':
        return <StickyNote className="w-4 h-4" />;
      case 'Course':
        return <FolderOpen className="w-4 h-4" />;
    }
  };

  const existingIds = new Set(existingMaterials.map((m) => m.id));
  const previewTitle =
    title.trim() ||
    (category === 'soft'
      ? sourceType === 'PDF'
        ? 'Public Speaking PDF'
        : 'Better Communication'
      : sourceType === 'PDF'
      ? 'Physics Formulas PDF'
      : 'Python & AI');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4">
      <div className="w-full max-w-xl rounded-2xl border border-cyan-400/50 bg-[#061325] shadow-[0_0_50px_rgba(6,182,212,0.3)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/25 bg-[#08192f]">
          <div>
            <h2 className="font-display text-lg font-bold tracking-wider text-white">
              UPLOAD / ADD MATERIAL TO 3D SHELF
            </h2>
            <p className="text-xs text-slate-400">
              Mounts onto the golden shelf ledge in 3D physical form with companion books & side title
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-cyan-500/15 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="flex items-center justify-between px-6 py-2.5 border-b border-cyan-500/15 bg-[#071528]">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTab('upload')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                tab === 'upload'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Upload PDF / Custom Material
            </button>
            <button
              onClick={() => setTab('presets')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                tab === 'presets'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              2nd Image Reference Books
            </button>
          </div>

          <button
            onClick={() => {
              onLoadAllPresets();
              onClose();
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500/15 border border-amber-400/50 text-amber-300 hover:bg-amber-500/25 text-[11px] font-semibold cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Load 2nd Image Shelf</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {tab === 'upload' ? (
            <form onSubmit={handleCreateCustom} className="space-y-4">
              {/* Target Shelf Selector */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => handleCategoryChange('soft')}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                    category === 'soft'
                      ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200 shadow-[0_0_15px_rgba(34,211,238,0.2)]'
                      : 'border-cyan-500/20 bg-[#081729] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  LEFT SHELF: SOFT SKILLS
                </button>
                <button
                  type="button"
                  onClick={() => handleCategoryChange('hard')}
                  className={`py-2 px-3 rounded-xl border text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                    category === 'hard'
                      ? 'border-cyan-400 bg-cyan-500/20 text-cyan-200 shadow-[0_0_15px_rgba(34,211,238,0.2)]'
                      : 'border-cyan-500/20 bg-[#081729] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  RIGHT SHELF: HARD SKILLS
                </button>
              </div>

              {/* Optional Cover Title Input BEFORE or AFTER Upload + Live 3D Physical Preview */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center p-3.5 rounded-xl border border-cyan-500/25 bg-[#07162b]">
                {/* Live 3D Physical Book Cover Preview */}
                <div className="sm:col-span-5 flex items-end justify-center pt-2 pb-1 px-3 border-b-2 border-amber-400/80 bg-[#040c18] rounded-lg shadow-inner">
                  {/* Single Standalone 3D Physical PDF / Book Cover Preview */}
                  <div className="relative w-[132px] h-[86px] rounded-r-[4px] rounded-l-[2px] bg-gradient-to-br from-[#132540] via-[#0b1628] to-[#060c17] border border-slate-500/40 p-2.5 flex items-center gap-2.5 shadow-[0_6px_14px_rgba(0,0,0,0.9)]">
                    <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-b from-slate-700 to-slate-950 rounded-l-[2px]" />
                    <div className="flex flex-col justify-between h-full py-0.5 pl-1 shrink-0">
                      <span className="px-1.5 py-0.5 rounded bg-rose-600 text-white text-[8px] font-extrabold uppercase shadow">
                        {sourceType}
                      </span>
                      <span className="w-3.5 h-3.5 rounded-full bg-rose-600 border-2 border-white/80 block mx-auto" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-bold text-slate-100 leading-tight line-clamp-3 break-words">
                        {previewTitle}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cover Title & Format Controls */}
                <div className="sm:col-span-7 space-y-2.5">
                  <div>
                    <label className="block text-[11px] text-cyan-200 font-semibold mb-1">
                      3D Book / PDF Cover Name (Printed on Shelf)
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g., Public Speaking PDF, Python, JEE..."
                      className="w-full px-3 py-1.5 rounded-lg border border-cyan-400/50 bg-[#051020] text-xs font-semibold text-white focus:outline-none focus:border-cyan-300"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Format</label>
                      <select
                        value={sourceType}
                        onChange={(e) => setSourceType(e.target.value as SourceType)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-cyan-500/30 bg-[#051020] text-xs text-white focus:outline-none"
                      >
                        <option value="PDF">PDF</option>
                        <option value="Book">Book</option>
                        <option value="Notes">Notes</option>
                        <option value="Web">Web</option>
                        <option value="Course">Course</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5">Sub-Category</label>
                      <select
                        value={subcategory}
                        onChange={(e) =>
                          setSubcategory(e.target.value as SoftSubcategory | HardSubcategory)
                        }
                        className="w-full px-2.5 py-1.5 rounded-lg border border-cyan-500/30 bg-[#051020] text-xs text-white focus:outline-none"
                      >
                        {(category === 'soft' ? SOFT_SUBCATEGORIES : HARD_SUBCATEGORIES).map(
                          (sub) => (
                            <option key={sub} value={sub}>
                              {sub}
                            </option>
                          )
                        )}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* 1-Click File Upload Box */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-4 rounded-xl border-2 border-dashed border-cyan-400/50 bg-[#081a30]/70 hover:bg-[#09203a] hover:border-cyan-300 flex flex-col items-center justify-center text-center gap-1.5 cursor-pointer transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(34,211,238,0.25)]">
                  <Upload className="w-4 h-4" />
                </div>
                <div className="text-xs sm:text-sm font-bold text-white">
                  Click to Select PDF / File from Your Computer
                </div>
                <div className="text-[11px] text-slate-400">
                  Automatically cleans raw filenames & places the 3D physical book onto the{' '}
                  {category === 'soft' ? 'Soft Skills' : 'Hard Skills'} shelf
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.txt,.md,.json,.csv,.doc,.docx,.png,.jpg,.jpeg"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  onClick={(e) => {
                    if (!title.trim()) {
                      e.preventDefault();
                      setTitle(previewTitle);
                      setTimeout(() => {
                        const item: MaterialItem = {
                          id: `${category}-${Date.now()}`,
                          title: previewTitle,
                          subtitle: `${subcategory} · ${sourceType}`,
                          type: sourceType,
                          category,
                          subcategory,
                          author: 'Archive Source · 12 Chapters',
                          dateAdded: 'Oct 19, 2026',
                          durationOrPages: '12 Chapters',
                          fileSize: '4.2 MB',
                          physicalLook:
                            sourceType === 'PDF'
                              ? 'pdf-binder'
                              : sourceType === 'Notes'
                              ? 'cream-notebook'
                              : 'dark-book',
                          summary: `Based on "${previewTitle}", here are the key techniques and insights:`,
                          paragraphs: [
                            `1. Prepare thoroughly — Master the core concepts of ${previewTitle}.`,
                            `2. Start small — Apply ${subcategory.toLowerCase()} techniques in focused steps.`,
                            `3. Focus on the message — Prioritize clarity and measurable outcomes.`,
                          ],
                          keyTakeaways: [
                            `Prepare thoroughly — Know the core principles of ${previewTitle} deeply.`,
                            'Start small — Build mastery through consistent daily practice.',
                            'Focus on the message — Concentrate on the value and practical application.',
                          ],
                          linkedIds: [],
                        };
                        onAddMaterial(item, true);
                        onClose();
                      }, 10);
                    }
                  }}
                  className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-[0_0_20px_rgba(34,211,238,0.4)] cursor-pointer"
                >
                  Place on 3D Shelf
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCategoryChange('soft')}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                    category === 'soft'
                      ? 'border-cyan-400 bg-cyan-500/15 text-cyan-200'
                      : 'border-cyan-500/20 bg-[#081729] text-slate-400'
                  }`}
                >
                  Soft Skills (Left Shelf)
                </button>
                <button
                  onClick={() => handleCategoryChange('hard')}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                    category === 'hard'
                      ? 'border-cyan-400 bg-cyan-500/15 text-cyan-200'
                      : 'border-cyan-500/20 bg-[#081729] text-slate-400'
                  }`}
                >
                  Hard Skills (Right Shelf)
                </button>
              </div>

              <div className="space-y-2">
                {// The real shelf the core returned, filtered by the tab he is on. It used to
                // list the zip's invented sample cards, which he could then "add".
                existingMaterials.filter((m) => m.category === category).map((item) => {
                  const alreadyOnShelf = existingIds.has(item.id);
                  return (
                    <div
                      key={item.id}
                      className="flex items-center justify-between gap-3 p-3 rounded-xl border border-cyan-500/25 bg-[#08192e]/80 hover:border-cyan-400/60"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shrink-0">
                          {getTypeIcon(item.type)}
                        </div>
                        <div className="min-w-0">
                          <div className="text-[10px] text-cyan-300 font-medium">
                            {item.subcategory} · {item.type}
                          </div>
                          <div className="text-xs font-bold text-white truncate">{item.title}</div>
                        </div>
                      </div>

                      {alreadyOnShelf ? (
                        <button
                          onClick={() => {
                            onSelectExisting(item);
                            onClose();
                          }}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 text-xs font-medium cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          Select
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            onAddMaterial(item, true);
                            onClose();
                          }}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/60 text-cyan-200 text-xs font-medium hover:bg-cyan-500/30 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Add to Shelf
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
