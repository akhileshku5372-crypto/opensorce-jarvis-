import pathlib
p=pathlib.Path("public/static/brain-holo.js")
s=p.read_text(encoding="utf-8")
old="function ensureDom(){wrap=document.getElementById('brain-canvas-wrap');if(!wrap)return false;if(!container){container=document.createElement('div');container.id='brain-holo-mount';container.style.cssText='position:absolute;inset:0;z-index:1;width:100%;height:100%;cursor:grab';wrap.appendChild(container);wrap.classList.add('brain-holo-ready');const c=document.getElementById('brain-canvas');if(c)c.style.display='none';}return true;}"
new="""function ensureDom(){wrap=document.getElementById('brain-canvas-wrap');if(!wrap)return false;
try{ const cs=getComputedStyle(wrap); if(cs.position==='static') wrap.style.position='relative'; }catch{}
if(!wrap.style.minHeight) wrap.style.minHeight='520px';
if(wrap.clientHeight<12) wrap.style.minHeight='520px';
if(!container){
  container=document.createElement('div');
  container.id='brain-holo-mount';
  container.style.cssText='position:absolute;inset:0;z-index:2;width:100%;height:100%;cursor:grab;display:block;background:radial-gradient(ellipse at 50% 42%, #0a2230 0, #061018 58%, #020608 100%)';
  wrap.appendChild(container);
  try{ wrap.classList.add('brain-holo-ready'); }catch{}
  const c=document.getElementById('brain-canvas'); if(c) c.style.display='none';
  const w=document.getElementById('brain-wires'); if(w) w.style.display='none';
  if(!document.getElementById('brain-tooltip')){
    const t=document.createElement('div'); t.id='brain-tooltip'; t.className='brain-tooltip'; t.hidden=true;
    t.style.cssText='position:fixed;z-index:50;pointer-events:none;background:rgba(2,6,23,0.92);border:1px solid #22c7f280;padding:6px 10px;border-radius:8px;font-size:11px;color:#e5f7fc;max-width:220px';
    document.body.appendChild(t);
  }
} else { try{ wrap.classList.add('brain-holo-ready'); }catch{} }
return true;}"""
if old in s:
    s=s.replace(old,new)
    print("p1 ensureDom patched")
else:
    print("p1 miss")
    # fallback search
    import re
    m=re.search(r"function ensureDom\(\)\{.*?return true;\}",s,re.S)
    if m:
        s=s.replace(m.group(0),new)
        print("p1 regex patched")
p.write_text(s,encoding="utf-8")
# copy to dist if exists
import pathlib as pl
dp=pl.Path("dist/static/brain-holo.js")
if dp.parent.exists():
    dp.write_text(s,encoding="utf-8")
    print("copied to dist")
print("len",len(s))
