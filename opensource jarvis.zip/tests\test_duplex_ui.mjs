// Live UI proof for the duplex voice chip. Read-only and SILENT: it never asks
// the core to enter live mode (that would put audio in the room). Instead it
// proves the two things that matter about the surface:
//   1. the chip renders what /state really reports - a stubbed live session
//      shows LIVE with the measured numbers, and
//   2. with the untouched /state it must say CLASSIC, i.e. the UI can never
//      claim a duplex session that is not open.
//
// Requires the running stack (vite :7777 + voice core :7780).
// Run: node tests/test_duplex_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const UI = 'http://127.0.0.1:7777/'
const CORE = 'http://127.0.0.1:7780'
const PORT = 9223

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-duplex-ui-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
  '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { }
  try { rmSync(profile, { recursive: true, force: true }) } catch { }
}
setTimeout(() => { cleanup(); process.exit(124) }, 120000).unref()

async function connect() {
  for (let i = 0; i < 40; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) {
        const page = await res.json()
        if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
      }
    } catch { }
    await wait(500)
  }
  throw new Error('CDP did not come up')
}

function cdp(ws) {
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id) }
  })
  return (method, params = {}) => new Promise((resolve) => {
    const mid = ++id
    pending.set(mid, resolve)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
}

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

// Reused across both loads: read the chip's own text back out of the DOM.
const READ_CHIP = `(() => {
  const chip = document.getElementById('duplex-toggle')
  const mode = document.getElementById('duplex-mode')
  const meta = document.getElementById('duplex-meta')
  const block = document.querySelector('.core-status')
  let spill = null
  if (chip && block) {
    const c = chip.getBoundingClientRect(), b = block.getBoundingClientRect()
    spill = Math.round(c.right - b.right)
  }
  return {
    exists: Boolean(chip),
    mode: mode ? mode.textContent.trim() : null,
    meta: meta ? meta.textContent.trim() : null,
    live: chip ? chip.getAttribute('data-live') : null,
    isButton: chip ? chip.tagName === 'BUTTON' : false,
    // The first version of this chip was clipped to "DUPLE" inside the narrow
    // voice block: it fitted its container and still showed nothing. Ellipsis
    // on the readout is a bug, not a design.
    clipped: meta ? (meta.scrollWidth > meta.clientWidth + 1) : null,
    chipWidth: chip ? Math.round(chip.getBoundingClientRect().width) : null,
    spill,
  }
})()`

const STUB = `(() => {
  const realFetch = window.fetch
  window.__duplexStubbed = false
  window.fetch = async (input, init) => {
    const url = String(typeof input === 'string' ? input : (input && input.url) || '')
    const res = await realFetch(input, init)
    if (!url.includes('${CORE}/state')) return res
    const body = await res.clone().json()
    Object.assign(body, {
      voice_mode: 'live', live_stage: 'live_ready', live_first_audio_s: 0.73,
      live_turns: 4, live_barge_in: 2, live_dropped_chunks: 9,
      live_frames_sent: 120, live_error: ''
    })
    window.__duplexStubbed = true
    return new Response(JSON.stringify(body), {
      status: 200, headers: { 'content-type': 'application/json' }
    })
  }
})()`

async function loadPage(send, { stub }) {
  await send('Page.navigate', { url: 'about:blank' })
  await wait(400)
  await send('Page.setExtraHTTPHeaders', { headers: {} })
  if (stub) {
    await send('Page.removeScriptToEvaluateOnNewDocument', { identifier: stubId }).catch(() => { })
    const res = await send('Page.addScriptToEvaluateOnNewDocument', { source: stub })
    stubId = res.result && res.result.identifier
  } else {
    await send('Page.removeScriptToEvaluateOnNewDocument', { identifier: stubId }).catch(() => { })
    stubId = null
  }
  await send('Page.navigate', { url: UI })
  await wait(6000)
}

let stubId = null
const problems = []

try {
  const wsUrl = await connect()
  const ws = new WebSocket(wsUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', reject)
  })
  const send = cdp(ws)
  await send('Page.enable')
  await send('Runtime.enable')
  await send('Log.enable')
  await send('Console.enable')
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
      problems.push((msg.params.args || []).map((a) => a.value || a.description || '').join(' '))
    }
    if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') {
      // entry.url carries the resource that failed; without it a refused poll
      // of another subsystem is indistinguishable from a real page error.
      problems.push([msg.params.entry.url || '', msg.params.entry.text].join(' '))
    }
  })

  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })
    return r.result && r.result.result ? r.result.result.value : undefined
  }

  const coreState = await (await fetch(`${CORE}/state`, { signal: AbortSignal.timeout(3000) })).json()

  // 1. The honest default: whatever the core actually reports, the chip says too.
  await loadPage(send, { stub: null })
  const plain = await evaluate(READ_CHIP)
  if (!plain || !plain.exists) bad('the duplex chip is missing from the topbar')
  else ok('duplex chip exists in the voice block')
  const wantMode = String(coreState.voice_mode || 'classic').toUpperCase()
  if (plain.mode !== wantMode) bad(`chip says ${plain.mode} but /state says ${coreState.voice_mode}`)
  else ok(`chip matches /state (${wantMode})`)
  if (wantMode === 'CLASSIC' && plain.live === '1') bad('chip claims a live session that /state denies')
  else ok('chip does not claim duplex it does not have')
  if (!plain.isButton) bad('the chip must be a real button - the toggle has to be reachable by click')
  else ok('chip is a button (one command path, like the research chips)')
  if (plain.spill > 2) bad(`chip spills ${plain.spill}px past the voice block - the topbar stays laptop-sized`)
  else ok(`chip fits inside the core-status card (${plain.spill}px)`)
  if (plain.clipped) bad(`standby readout is clipped at ${plain.chipWidth}px - ellipsis here means he cannot read it`)
  else ok(`standby readout is fully readable (${plain.chipWidth}px)`)

  // 2. A duplex session, stubbed into /state: the measured numbers must show.
  await loadPage(send, { stub: STUB })
  await wait(2500)
  const stubbed = await evaluate(READ_CHIP)
  const wasStubbed = await evaluate('window.__duplexStubbed === true')
  if (!wasStubbed) bad('the /state stub never ran, so this load proves nothing')
  else ok('core /state intercepted for the duplex case')
  if (stubbed.mode !== 'LIVE') bad(`stubbed live session rendered as ${stubbed.mode}`)
  else ok('renders LIVE when the core reports a duplex session')
  const meta = String(stubbed.meta || '')
  if (!/0\.73/.test(meta)) bad(`first-audio latency not shown (meta="${meta}") - the number that decides the feel`)
  else ok('shows the measured first-audio latency')
  if (!/2/.test(meta) || !/4/.test(meta)) bad(`turn/barge-in counts not shown (meta="${meta}")`)
  else ok('shows turn and barge-in counts from the run itself')
  if (stubbed.live !== '1') bad('chip must mark data-live="1" so CSS can show the state, not just the words')
  else ok('chip carries the state as an attribute')
  if (stubbed.spill > 2) bad(`with the longest readout the chip spills ${stubbed.spill}px out of the card`)
  else ok(`chip fits with the full duplex readout (${stubbed.spill}px)`)
  if (stubbed.clipped) bad(`duplex readout clipped at ${stubbed.chipWidth}px - the measured numbers are the point of this chip`)
  else ok(`duplex readout is fully readable (${stubbed.chipWidth}px)`)

  const foreign = problems.filter((p) => /5678|favicon/i.test(p))
  const realErrors = problems.filter((p) => !/favicon|Failed to load resource.*favicon|5678/i.test(p))
  if (foreign.length) console.log(`  note the dashboard also polls :5678 (n8n, another session's integration) - ${foreign.length} refused requests ignored here, not duplex-related`)
  if (realErrors.length) bad(`console was not clean (${realErrors.length}): ${realErrors.slice(0, 2).join(' | ')}`)
  else ok('zero console errors from this surface across both loads')
} catch (err) {
  bad('harness threw: ' + (err && err.stack ? err.stack : err))
} finally {
  cleanup()
}

console.log('')
console.log(`${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
