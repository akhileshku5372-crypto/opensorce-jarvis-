STUB = '''"""
[VOICE STACK REMOVED]
Tests for the deleted voice runtime (background/jarvis_core.py) were removed
together with it. New tests will be written for the new voice stack.
"""
import unittest


class VoiceStackRemovedPlaceholder(unittest.TestCase):
    def test_voice_stack_was_removed(self):
        # Placeholder so the suite stays runnable while the new voice stack
        # is written from scratch.
        self.assertTrue(True)


if __name__ == "__main__":
    unittest.main()
'''

with open("tests/test_core.py", "w", encoding="utf-8") as f:
    f.write(STUB)
print("test_core.py truncated to stub")

import os
for junk in ("temp/_voice_engine_probe.py", "temp/_listpy.ps1", "tools/_gut_voice.py"):
    if os.path.exists(junk):
        os.remove(junk)
        print("removed:", junk)
print("CLEANUP DONE")
