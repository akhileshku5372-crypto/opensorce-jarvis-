﻿"""Firecrawl multi-key credit pool for JARVIS.

Treats N Firecrawl API keys as ONE logical provider so the voice pipeline
never has to know how many keys exist.

Two behaviours, chosen by the caller:

  failover  - one key at a time, automatic rotation. Used by `search()` and
              `extract()` so a dead/exhausted key silently rolls over to the
              next one instead of failing the request.
  fanout    - every healthy key works in parallel on a DISJOINT slice of the
              work. Used by deep research: key 1 takes the first N sources,
              key 2 the next N, and so on. Every source is extracted
              exactly once, so two keys never pay for the same page.

Credit-exhaustion detection is deliberately conservative. Only errors that
explicitly mention credits/balance/quota/billing are treated as exhaustion;
a 401 is an auth problem, and a 5xx or timeout is transient. A key is parked
for a cooldown instead of being disabled forever, so a monthly top-up or a
temporary provider blip recovers on its own.
"""
from __future__ import annotations

import os
import re
import threading
import time

# Env vars that may hold a key, in priority order. FIRECRAWL_API_KEY is the
# original single-key slot and stays first so existing setups keep working.
_KEY_VARS = (
    "FIRECRAWL_API_KEY",
    "FIRECRAWL_API_KEY_2",
    "FIRECRAWL_API_KEY_3",
    "FIRECRAWL_API_KEY_4",
)

# Park duration when a key reports exhausted credits. Long enough that we do
# not hammer a dead key on every request, short enough that a topped-up
# account comes back within the same session.
_COOLDOWN_S = 900.0

# Patterns that mean "this account has no credits left". Deliberately narrow:
# a generic 5xx or a rate-limit blip must NOT retire a working key.
_EXHAUSTED_RE = re.compile(
    r"(?:credit|quota|balance|billing|payment|insufficient|"
    r"exhaust|out\s+of\s+credit|upgrade\s+your\s+plan|402)",
    re.IGNORECASE,
)

_lock = threading.RLock()
# key -> {"parked_until": float, "reason": str, "uses": int, "ok": int}
_state = {}


def _load_keys():
    """Collect every configured, non-empty key, de-duplicated, order kept."""
    found, seen = [], set()
    for var in _KEY_VARS:
        value = (os.environ.get(var) or "").strip()
        # A pasted multi-key list ("fc-a,fc-b") is also accepted.
        for key in [p.strip() for p in value.split(",")]:
            if key and key not in seen:
                seen.add(key)
                found.append(key)
    return found


def _slot(key):
    """Stable, non-secret label for a key (never log the key itself)."""
    tail = key[-4:] if len(key) >= 4 else "????"
    return "fc-***%s" % tail


def keys():
    """All configured keys in priority order."""
    return _load_keys()


def healthy_keys():
    """Keys not currently parked, in priority order."""
    now = time.time()
    out = []
    with _lock:
        for key in _load_keys():
            info = _state.get(key) or {}
            if float(info.get("parked_until") or 0) > now:
                continue
            out.append(key)
    return out


def _park(key, reason):
    with _lock:
        info = _state.setdefault(key, {})
        info["parked_until"] = time.time() + _COOLDOWN_S
        info["reason"] = str(reason)[:160]
        info["parked_at"] = time.time()


def _credit_ok(key):
    with _lock:
        info = _state.setdefault(key, {})
        info["parked_until"] = 0.0
        info["reason"] = ""
        info["ok"] = int(info.get("ok") or 0) + 1


def next_key(exclude=()):
    """Return the next usable key, or "" when every key is parked.

    This is the failover primitive: callers retry with the next key while an
    exhaustion error keeps coming back.
    """
    skip = set(exclude or ())
    for key in healthy_keys():
        if key not in skip:
            with _lock:
                _state.setdefault(key, {})
                _state[key]["uses"] = int(_state[key].get("uses") or 0) + 1
            return key
    return ""


def report_failure(key, error_text):
    """Classify a failure. Returns True when the key was parked for credits."""
    text = str(error_text or "")
    if _EXHAUSTED_RE.search(text):
        _park(key, text)
        return True
    return False


def report_success(key):
    _credit_ok(key)


def reset():
    """Clear all parking (used by tests and manual recovery)."""
    with _lock:
        _state.clear()


def split_evenly(items, keys_list=None):
    """Partition `items` into one contiguous slice per key, no overlap.

    Key 1 takes the first chunk, key 2 the second, and so on - exactly the
    "key 1 reads 20 sources, key 2 reads the next 20" behaviour. The union of
    all slices is the original list, and no item appears twice.
    """
    pool = list(keys_list if keys_list is not None else healthy_keys())
    if not pool:
        return []
    items = list(items or [])
    if not items:
        return [(key, []) for key in pool]
    per = -(-len(items) // len(pool))  # ceil division
    out, cursor = [], 0
    for key in pool:
        chunk = items[cursor:cursor + per]
        cursor += len(chunk)
        out.append((key, chunk))
    return out


def pool_status():
    """Non-secret health snapshot for /state and the dashboard."""
    now = time.time()
    rows = []
    for key in _load_keys():
        info = _state.get(key) or {}
        parked_until = float(info.get("parked_until") or 0)
        rows.append({
            "slot": _slot(key),
            "parked": parked_until > now,
            "cooldown_s": max(0, int(parked_until - now)),
            "reason": info.get("reason", ""),
            "uses": int(info.get("uses") or 0),
            "ok": int(info.get("ok") or 0),
        })
    healthy = [r for r in rows if not r["parked"]]
    return {
        "keys": rows,
        "total": len(rows),
        "healthy": len(healthy),
        "fanout": len(healthy) > 1,
    }

