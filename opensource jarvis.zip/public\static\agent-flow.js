/* ══════════════════════════════════════════════════════════════════════════
   AGENT FLOW BUILDER — Co-work -> Agents (n8n-style visual builder)

   This is a THIN CLIENT over background/agent_flow.py. It never executes a
   tool, never invents a capability, and never decides what a node means:

     * every node/edge shown came from GET /agents (or a real draft),
     * every option in a dropdown came from GET /agents/catalog, which the
       server resolved against the live ToolRegistry / skills/ / servers.json,
     * Run POSTs the SAVED agent id and renders whatever the real executor
       reports back from GET /agents/run.

   So the canvas can only ever display capabilities the runtime can execute.
   ══════════════════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════════════════
   AGENT FLOW BUILDER — Co-work -> Agents (n8n-style visual builder)

   RETIRED IN THE UI. The Agents tab now embeds the REAL n8n editor via
   public/static/n8n-panel.js. This file is intentionally kept on disk and
   still passes tests/test_agent_flow.py, because background/agent_flow.py and
   the /agents/* routes remain live for the voice path. The guard below makes it
   a no-op when its markup is absent, so it cannot throw.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict'

  // The af-* markup is gone from the Agents panel. Every selector below would
  // return null, so exit before touching the DOM.
  if (!document.getElementById('af-builder')) {
    return
  }

  const CORE = 'http://127.0.0.1:7780'
  const GRID = 24
  const NODE_H_MIN = 62
  const HISTORY_MAX = 60

  // Node type -> visual identity. One place, so the canvas, palette, minimap
  // and config panel can never disagree about what a node looks like.
  const KINDS = {
    input: { label: 'Input', icon: 'message-square', color: '#00e5a8', hint: 'Task input' },
    agent: { label: 'Agent', icon: 'cpu', color: '#19e6ff', hint: 'Orchestrator' },
    subagent: { label: 'Sub-Agent', icon: 'bot', color: '#a78bfa', hint: 'Nested agent' },
    tool: { label: 'Tool', icon: 'wrench', color: '#00d9ff', hint: 'Registry tool' },
    mcp: { label: 'MCP', icon: 'plug', color: '#2dd4bf', hint: 'MCP connector' },
    skill: { label: 'Skill', icon: 'book-open', color: '#f59e0b', hint: 'SKILL.md' },
    model: { label: 'Model', icon: 'brain', color: '#f472b6', hint: 'LLM call' },
    condition: { label: 'Condition', icon: 'git-branch', color: '#fbbf24', hint: 'Router' },
    approval: { label: 'Approval', icon: 'shield-check', color: '#ff6b8a', hint: 'Human gate' },
    output: { label: 'Output', icon: 'package', color: '#22d3ee', hint: 'Final result' },
    // Orchestration primitives. Each maps to a real handler in
    // background/agent_flow.py - none of these is a visual-only node.
    router: { label: 'Router', icon: 'shuffle', color: '#fbbf24', hint: 'N-way branch' },
    parallel: { label: 'Parallel', icon: 'git-fork', color: '#34d399', hint: 'Run branches at once' },
    merge: { label: 'Merge', icon: 'combine', color: '#34d399', hint: 'Join branch results' },
    loop: { label: 'Loop', icon: 'repeat', color: '#c084fc', hint: 'Repeat a body' },
    validator: { label: 'Validator', icon: 'check-circle', color: '#22d3ee', hint: 'Assert input' },
    evaluator: { label: 'Evaluator', icon: 'star', color: '#f472b6', hint: 'LLM quality score' },
    memory: { label: 'Memory', icon: 'database', color: '#60a5fa', hint: 'Workflow state' },
    transform: { label: 'Transform', icon: 'shuffle', color: '#94a3b8', hint: 'Shape data' },
    http: { label: 'HTTP', icon: 'globe', color: '#38bdf8', hint: 'Allowlisted request' },
    workflow: { label: 'Workflow', icon: 'workflow', color: '#a78bfa', hint: 'Run a saved agent' },
    error: { label: 'Fallback', icon: 'alert-triangle', color: '#f87171', hint: 'Failure sink' },
    checkpoint: { label: 'Checkpoint', icon: 'save', color: '#94a3b8', hint: 'Resumable snapshot' }
  }
  const ORDER = Object.keys(KINDS)

  const state = {
    agents: [],
    catalog: null,
    capabilities: null,
    catalogError: null,
    agent: null,
    selected: '',
    viewport: { x: 0, y: 0, zoom: 1 },
    run: null,
    approvals: [],
    past: [],
    future: [],
    drag: null,
    link: null,
    pan: null,
    resize: null,
    dirty: false,
    pollTimer: null,
    lastRunId: ''
  }

  const $ = (sel, root) => (root || document).querySelector(sel)
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel))

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;')
  }

  function toast(message, bad) {
    const region = $('#toast-region')
    const text = String(message || '')
    if (!region) return
    const node = document.createElement('div')
    node.className = 'toast' + (bad ? ' error' : '')
    node.textContent = text.length > 220 ? text.slice(0, 217) + '…' : text
    region.appendChild(node)
    setTimeout(() => node.remove(), 4200)
  }

  async function api(path, body, timeout) {
    const options = body
      ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
      : {}
    const signal = AbortSignal.timeout(timeout || 12000)
    const response = await fetch(CORE + path, { ...options, signal })
    const payload = await response.json().catch(() => ({}))
    if (!response.ok || payload.ok === false) {
      throw new Error(payload.error || payload.message || ('HTTP ' + response.status))
    }
    return payload
  }

/* ── geometry ─────────────────────────────────────────────────────────── */
  function nodes() {
    return (state.agent && state.agent.flow && state.agent.flow.nodes) || []
  }

  function edges() {
    return (state.agent && state.agent.flow && state.agent.flow.edges) || []
  }

  function nodeById(id) {
    return nodes().find((n) => n.id === id) || null
  }

  function snap(value) {
    return Math.round(Number(value || 0) / GRID) * GRID
  }

  // Port positions derive from the node box, so a node moved or resized in the
  // config panel re-routes its edges with no extra bookkeeping.
  function ports(node) {
    const h = Number(node.h) || 100
    const w = Number(node.w) || 226
    return { out: { x: node.x + w, y: node.y + h / 2 }, in: { x: node.x, y: node.y + h / 2 } }
  }

  function edgePath(a, b) {
    const p1 = ports(a)
    const p2 = ports(b)
    const start = p1.out
    const end = p2.in
    const dx = Math.max(46, Math.abs(end.x - start.x) * 0.45)
    return 'M ' + start.x + ' ' + start.y + ' C ' + (start.x + dx) + ' ' + start.y +
      ', ' + (end.x - dx) + ' ' + end.y + ', ' + end.x + ' ' + end.y
  }

  // Connection legality comes from the SERVER's table, so the canvas can never
  // offer an edge the executor would later refuse.
  function canConnect(fromType, toType) {
    const inbound = (state.catalog && state.catalog.inbound) || {}
    return Array.isArray(inbound[toType]) && inbound[toType].indexOf(fromType) !== -1
  }

  function nodeSummary(node) {
    const config = node.config || {}
    switch (node.type) {
      case 'tool': return config.tool || 'no tool selected'
      case 'mcp': return (config.server && config.tool) ? config.server + '.' + config.tool : 'no connector selected'
      case 'skill': return config.skill || 'no skill selected'
      case 'model': return config.model || 'auto model'
      case 'condition': return config.expression || 'no expression'
      case 'subagent': return config.name || 'sub-agent'
      case 'approval': return config.prompt || 'Approve this step?'
      case 'output': return config.label || 'Final result'
      case 'router': return (config.rules_text || 'no rules').split('\n')[0]
      case 'parallel': return config.mode === 'race' ? 'first to finish wins' : 'run all branches'
      case 'merge': return config.strategy || 'object'
      case 'loop': return 'max ' + (config.max_iterations || 1) + ' pass(es)'
      case 'validator': return config.expression || 'no expression'
      case 'evaluator': return 'threshold ' + (config.threshold != null ? config.threshold : 7) + '/10'
      case 'memory': return (config.key || 'no key') + ' = ' + (config.op || 'set')
      case 'transform': return config.mode || 'template'
      case 'http': return config.url ? String(config.url).slice(0, 40) : 'no url'
      case 'workflow': return config.agent_id || 'no target agent'
      case 'error': return config.message || 'Step failed'
      case 'checkpoint': return config.label || 'Checkpoint'
      default: return (KINDS[node.type] && KINDS[node.type].hint) || ''
    }
  }

  function nodeStatus(id) {
    if (!state.run || state.run.id !== state.lastRunId) return ''
    const entry = (state.run.nodes || []).find((n) => n.id === id)
    return entry ? entry.status : ''
  }

  function render() {
    renderList(); renderHeader(); renderNodes(); renderEdges()
    renderMinimap(); renderConfig(); renderPalette(); renderRunLog()
  }

  function renderHeader() {
    const title = $('#af-title')
    const status = $('#af-status')
    const stats = $('#af-stats')
    if (title) title.textContent = state.agent ? state.agent.name : 'No agent selected'
    if (status && state.agent) {
      status.dataset.state = state.agent.enabled === false ? 'disabled' : 'active'
      status.textContent = state.agent.enabled === false ? 'disabled' : 'active'
    }
    if (stats) {
      const run = state.run || {}
      stats.textContent = state.agent
        ? nodes().length + ' nodes · ' + edges().length + ' edges' +
          (run.id && run.id !== state.lastRunId ? ' · ' + (run.status || 'idle') : '')
        : ''
    }
    const save = $('#af-save')
    if (save) save.classList.toggle('af-dirty', state.dirty)
  }

  function renderList() {
    const box = $('#af-list')
    if (!box) return
    // The registry line reports what the CORE can actually execute, so it must
    // be painted even with zero agents saved. Binding it after the early return
    // made a fresh install claim "registry 0 tools" until the first agent.
    const store = $('#af-store')
    const counts = (state.catalog && state.catalog.counts) || {}
    if (store) {
      // "0 tools" would be a false claim: it reads as a real empty registry when
      // it actually means the catalog never loaded. Say which one it is.
      if (!state.catalog) {
        store.innerHTML = '<span class="panel-note">registry unavailable'
          + (state.catalogError ? ' (' + esc(state.catalogError) + ')' : '') + '</span>'
      } else {
        store.innerHTML = '<span>registry ' + (counts.tools || 0) + ' tools</span>' +
          '<span>skills ' + (counts.skills || 0) + '</span>' +
          '<span>mcp ' + (counts.mcp_callable || 0) + '</span>'
      }
    }
    if (!state.agents.length) {
      box.innerHTML = '<span class="panel-note">No agents yet. Create one, or describe one below.</span>'
      return
    }
    box.innerHTML = state.agents.map((agent) => {
      const active = state.agent && state.agent.id === agent.id
      const count = agent.flow && agent.flow.nodes ? agent.flow.nodes.length : 0
      return '<button type="button" class="af-item' + (active ? ' active' : '') +
        '" data-af-agent="' + esc(agent.id) + '">' +
        '<span class="af-item-name">' + esc(agent.name) + '</span>' +
        '<span class="af-item-meta">' + count + ' nodes</span>' +
        '<span class="af-dot" data-state="' + (agent.enabled === false ? 'off' : 'on') + '"></span></button>'
    }).join('')
  }

  function renderNodes() {
    const layer = $('#af-nodes')
    if (!layer) return
    const zoom = state.viewport.zoom
    layer.style.transform = 'translate(' + state.viewport.x + 'px,' + state.viewport.y +
      'px) scale(' + zoom + ')'
    layer.innerHTML = nodes().map((node) => {
      const kind = KINDS[node.type] || KINDS.tool
      const status = nodeStatus(node.id)
      return '<div class="af-node' + (state.selected === node.id ? ' selected' : '') +
        (status ? ' run-' + status : '') + '" data-af-node="' + esc(node.id) + '"' +
        ' style="left:' + node.x + 'px;top:' + node.y + 'px;width:' + node.w +
        'px;min-height:' + node.h + 'px;--k:' + kind.color + '">' +
        '<button type="button" class="af-port in" data-af-in="' + esc(node.id) + '" aria-label="input port"></button>' +
        '<div class="af-node-head"><i data-lucide="' + kind.icon + '"></i>' +
        '<span class="af-node-kind">' + esc(kind.label) + '</span>' +
        (status ? '<span class="af-node-status">' + esc(status) + '</span>' : '') + '</div>' +
        '<div class="af-node-title">' + esc(node.title) + '</div>' +
        '<div class="af-node-sub">' + esc(nodeSummary(node)) + '</div>' +
        '<button type="button" class="af-port out" data-af-out="' + esc(node.id) + '" aria-label="output port"></button>' +
        '</div>'
    }).join('')
    if (window.lucide && window.lucide.createIcons) {
      window.lucide.createIcons({ attrs: { 'stroke-width': 1.7 } })
    }
  }

  function renderEdges() {
    const svg = $('#af-edges')
    if (!svg) return
    const box = $('#af-canvas-wrap')
    const width = (box && box.clientWidth) || 1200
    const height = (box && box.clientHeight) || 700
    svg.setAttribute('viewBox', '0 0 ' + width + ' ' + height)
    svg.setAttribute('width', width)
    svg.setAttribute('height', height)
    svg.style.transform = 'translate(' + state.viewport.x + 'px,' + state.viewport.y +
      'px) scale(' + state.viewport.zoom + ')'
    const live = state.run && state.run.id === state.lastRunId
    const paths = edges().map((edge) => {
      const a = nodeById(edge.from)
      const b = nodeById(edge.to)
      if (!a || !b) return ''
      const active = live && (state.run.current === edge.from || state.run.current === edge.to)
      const marker = edge.branch === 'false' ? 'af-arrow-false' : 'af-arrow'
      return '<path class="af-edge' + (edge.branch === 'false' ? ' false' : '') +
        (active ? ' active' : '') + '" d="' + edgePath(a, b) +
        '" marker-end="url(#' + marker + ')"></path>'
    }).join('')
    let pending = ''
    if (state.link) {
      const from = nodeById(state.link.from)
      if (from) {
        const start = ports(from).out
        const end = state.link.point
        pending = '<path class="af-edge pending" d="M ' + start.x + ' ' + start.y +
          ' C ' + (start.x + 60) + ' ' + start.y + ', ' + (end.x - 60) + ' ' + end.y +
          ', ' + end.x + ' ' + end.y + '"/>'
      }
    }
    svg.innerHTML = EDGE_DEFS + paths + pending
  }

  const EDGE_DEFS = '<defs>' +
    '<marker id="af-arrow" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">' +
    '<path d="M0,0 L9,4.5 L0,9 z" fill="#00e5ff"/></marker>' +
    '<marker id="af-arrow-false" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">' +
    '<path d="M0,0 L9,4.5 L0,9 z" fill="#ff6b8a"/></marker></defs>'

  function renderMinimap() {
    const svg = $('#af-minimap-svg')
    if (!svg || !state.agent) return
    const list = nodes()
    if (!list.length) { svg.innerHTML = ''; return }
    const minX = Math.min.apply(null, list.map((n) => n.x))
    const minY = Math.min.apply(null, list.map((n) => n.y))
    const maxX = Math.max.apply(null, list.map((n) => n.x + n.w))
    const maxY = Math.max.apply(null, list.map((n) => n.y + n.h))
    const scale = Math.min(168 / Math.max(1, maxX - minX), 108 / Math.max(1, maxY - minY)) * 0.86
    const rects = list.map((node) => {
      const kind = KINDS[node.type] || KINDS.tool
      return '<rect x="' + ((node.x - minX) * scale + 4).toFixed(1) + '" y="' +
        ((node.y - minY) * scale + 4).toFixed(1) + '" width="' +
        Math.max(3, node.w * scale).toFixed(1) + '" height="' +
        Math.max(2, node.h * scale).toFixed(1) + '" fill="' + kind.color +
        '" opacity="' + (node.id === state.selected ? '1' : '0.5') + '" rx="1.5"/>'
    }).join('')
    // The viewport rect must be clamped into the viewBox. Left raw, it is sized
    // from the real canvas and expands to fill the whole minimap, which makes the
    // panel look like a stray empty box floating over the graph.
    const VB_W = 176
    const VB_H = 116
    const PAD = 4
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))
    const view = $('#af-canvas-wrap')
    const vx = (-state.viewport.x / state.viewport.zoom) - minX
    const vy = (-state.viewport.y / state.viewport.zoom) - minY
    const vw = (view ? view.clientWidth : 900) / state.viewport.zoom
    const vh = (view ? view.clientHeight : 600) / state.viewport.zoom
    // Undo the +PAD offset, clamp to the viewBox, then re-apply it.
    const rx = clamp(vx * scale, -PAD, VB_W - 2 * PAD)
    const ry = clamp(vy * scale, -PAD, VB_H - 2 * PAD)
    const rw = clamp(vw * scale, 6, VB_W - 2 * PAD - rx)
    const rh = clamp(vh * scale, 5, VB_H - 2 * PAD - ry)
    svg.setAttribute('viewBox', '0 0 ' + VB_W + ' ' + VB_H)
    svg.innerHTML = rects + '<rect x="' + (rx + PAD).toFixed(1) + '" y="' +
      (ry + PAD).toFixed(1) + '" width="' + rw.toFixed(1) +
      '" height="' + rh.toFixed(1) +
      '" fill="rgba(0,229,255,.08)" stroke="#19e6ff" stroke-width="1"/>'
  }

  function renderPalette() {
    const box = $('#af-palette')
    if (!box) return
    const available = (state.capabilities && state.capabilities.available) || {}
    box.innerHTML = ORDER.map((type) => {
      const kind = KINDS[type]
      const live = available[type] !== false
      const title = live ? kind.hint : kind.hint + ' — unavailable right now'
      return '<button type="button" class="af-chip' + (live ? '' : ' off') +
        '" data-af-add="' + type + '" title="' + esc(title) + '"' +
        (live ? '' : ' disabled') + ' style="--k:' + kind.color + '">' +
        '<i data-lucide="' + kind.icon + '"></i>' + esc(kind.label) + '</button>'
    }).join('')
    if (window.lucide && window.lucide.createIcons) {
      window.lucide.createIcons({ attrs: { 'stroke-width': 1.7 } })
    }
  }

/* ── node configuration panel ─────────────────────────────────────────── */
  function field(label, control, hint) {
    return '<label class="af-field"><span>' + esc(label) + '</span>' + control +
      (hint ? '<small>' + esc(hint) + '</small>' : '') + '</label>'
  }

  function textInput(path, value, placeholder) {
    return '<input class="field" data-af-set="' + esc(path) + '" value="' + esc(value) +
      '" placeholder="' + esc(placeholder || '') + '"/>'
  }

  function textArea(path, value, rows, placeholder) {
    return '<textarea class="field-area" data-af-set="' + esc(path) + '" rows="' +
      (rows || 3) + '" placeholder="' + esc(placeholder || '') + '">' + esc(value) + '</textarea>'
  }

  function selectInput(path, value, options) {
    return '<select class="field" data-af-set="' + esc(path) + '">' +
      options.map((opt) => '<option value="' + esc(opt.value) + '"' +
        (opt.value === value ? ' selected' : '') + '>' + esc(opt.label) + '</option>').join('') +
      '</select>'
  }

  function numberInput(path, value, min, max) {
    return '<input class="field" type="number" data-af-set="' + esc(path) + '" value="' +
      esc(value) + '" min="' + min + '" max="' + max + '"/>'
  }

  function multiSelect(path, value, options) {
    const chosen = Array.isArray(value) ? value : []
    return '<select class="field" multiple size="5" data-af-multi="' + esc(path) + '">' +
      options.map((opt) => '<option value="' + esc(opt.value) + '"' +
        (chosen.indexOf(opt.value) !== -1 ? ' selected' : '') + '>' +
        esc(opt.label) + '</option>').join('') + '</select>'
  }

  function optionLists() {
    const cat = state.catalog || {}
    return {
      tools: (cat.tools || []).map((t) => ({
        value: t.name, label: t.name + (t.gated ? '  [approval]' : '') + ' — ' + (t.description || '')
      })),
      skills: (cat.skills || []).map((s) => ({ value: s.name, label: s.name + ' — ' + (s.description || '') })),
      mcp: (cat.mcp || []).filter((m) => m.callable)
        .map((m) => ({ value: m.server + '.' + m.tool, label: m.server + '.' + m.tool + ' — ' + (m.description || '') })),
      models: [{ value: '', label: 'auto (provider chain)' }].concat(
        (cat.models || []).map((m) => ({ value: m.id, label: m.label || m.id })))
    }
  }

function configFields(node) {
    const config = node.config || {}
    const opts = optionLists()
    switch (node.type) {
      case 'input':
        return field('Label', textInput('label', config.label, 'Task input')) +
          field('Placeholder', textInput('placeholder', config.placeholder, 'shown when empty'))
      case 'agent':
        return field('System prompt', textArea('system_prompt', config.system_prompt, 4, 'You are…')) +
          field('Goal', textArea('goal', config.goal, 3, 'use {{input}} for the run input')) +
          field('Max steps', numberInput('max_steps', config.max_steps == null ? 4 : config.max_steps, 1, 8)) +
          field('Retries', numberInput('retries', config.retries == null ? 1 : config.retries, 0, 3))
      case 'subagent':
        return field('Name', textInput('name', config.name, 'Analysis Agent')) +
          field('Description', textInput('description', config.description, 'what it is for')) +
          field('System prompt', textArea('system_prompt', config.system_prompt, 4, 'You analyse…')) +
          field('Model', selectInput('model', config.model, opts.models)) +
          field('Allowed tools', multiSelect('tools', config.tools, opts.tools), 'Only these may be called') +
          field('Skills', multiSelect('skills', config.skills, opts.skills)) +
          field('Permissions', selectInput('permissions', config.permissions || 'inherit', [
            { value: 'inherit', label: 'inherit engine default' },
            { value: 'ask', label: 'ask before each call' },
            { value: 'deny', label: 'deny every tool call' }])) +
          field('Memory', selectInput('memory', config.memory || 'none', [
            { value: 'none', label: 'none' }, { value: 'session', label: 'session' }])) +
          field('Max steps', numberInput('max_steps', config.max_steps == null ? 3 : config.max_steps, 1, 8)) +
          field('Retries', numberInput('retries', config.retries == null ? 1 : config.retries, 0, 3)) +
          field('On failure', selectInput('on_failure', config.on_failure || 'continue', [
            { value: 'continue', label: 'stop this branch' },
            { value: 'stop', label: 'stop the whole flow' },
            { value: 'fallback', label: 'fallback' }])) +
          field('Input schema', textArea('input_schema', config.input_schema, 2, 'free-form note')) +
          field('Output schema', textArea('output_schema', config.output_schema, 2, 'free-form note'))
      case 'tool':
        return field('Registry tool', selectInput('tool', config.tool,
          [{ value: '', label: '— select a registered tool —' }].concat(opts.tools)),
          'Only tools in the live registry are listed') +
          field('Arguments (JSON)', textArea('args_text', config.args_text, 4, '{"text": "{{input}}"}'),
            'Supports {{input}}, {{last}} and {{node_xxxxxx}}') +
          field('Retries', numberInput('retries', config.retries == null ? 0 : config.retries, 0, 3))
      case 'mcp':
        return field('MCP tool', selectInput('_mcp_combo', (config.server && config.tool) ? config.server + '.' + config.tool : '',
          [{ value: '', label: '— select a callable connector —' }].concat(opts.mcp)),
          'List-only servers are not offered') +
          field('Arguments (JSON)', textArea('args_text', config.args_text, 4, '{"q": "hello"}')) +
          field('Retries', numberInput('retries', config.retries == null ? 0 : config.retries, 0, 3))
      case 'skill':
        return field('Skill', selectInput('skill', config.skill,
          [{ value: '', label: '— select an installed skill —' }].concat(opts.skills)),
          'Only skills with a real SKILL.md are listed')
      case 'model':
        return field('Model', selectInput('model', config.model, opts.models)) +
          field('Prompt', textArea('prompt', config.prompt, 5, 'Summarise {{input}}'))
      case 'condition':
        return field('Expression', textInput('expression', config.expression, 'last contains error'),
          'One comparison: key == value, key != value, key contains text, key > number') +
          field('True branch label', textInput('true_branch', config.true_branch || 'true')) +
          field('False branch label', textInput('false_branch', config.false_branch || 'false'))
      case 'router':
        return field('Context key', textInput('key', config.key || 'last', 'last'),
          'Which workflow value to branch on') +
          field('Rules (one per line)', textArea('rules_text', config.rules_text, 4,
            'contains:urgent -> fast\ncontains:low -> slow'),
          'First match wins. Use contains: or regex: for partial matching') +
          field('Default branch', textInput('default_branch', config.default_branch || 'default'))
      case 'parallel':
        return field('Mode', selectInput('mode', config.mode || 'all', [
          { value: 'all', label: 'Run every branch' },
          { value: 'race', label: 'First successful branch wins' }]),
          'Branches run concurrently through the same executor')
      case 'merge':
        return field('Strategy', selectInput('strategy', config.strategy || 'object', [
          { value: 'object', label: 'JSON object of the named keys' },
          { value: 'concat', label: 'Join as text' },
          { value: 'last', label: 'Last value only' }])) +
          field('Keys (comma separated)', textInput('keys_text', config.keys_text, 'a, b'),
          'Leave empty to merge every inbound parent output key')
      case 'loop':
        return field('Body node ids (comma separated)', textInput('body_text', config.body_text, 'n_abc123, n_def456'),
          'These nodes repeat until the until-condition passes') +
          field('Max passes', numberInput('max_iterations', config.max_iterations || 2, 1, 10),
          'Hard cap so a flow can never spin forever') +
          field('Until condition', textInput('until', config.until, 'score >= 8'),
          'Checked after each pass, e.g. score >= 8')
      case 'validator':
        return field('Expression', textInput('expression', config.expression, 'last contains error'),
          'One comparison against the workflow state') +
          field('On failure', selectInput('on_fail', config.on_fail || 'fail', [
            { value: 'fail', label: 'Fail this branch' },
            { value: 'route', label: 'Route to an "invalid" edge' }])) +
          field('Failure message', textInput('message', config.message, 'Validation failed'))
      case 'evaluator':
        return field('Criteria', textArea('criteria', config.criteria, 4, 'is accurate, clear and complete'),
          'The judge scores the subject 0-10 against this') +
          field('Pass threshold', numberInput('threshold', config.threshold == null ? 7 : config.threshold, 0, 10)) +
          field('Subject key', textInput('subject_key', config.subject_key || 'last', 'last'),
          'Which workflow value to score') +
          field('Score key', textInput('score_key', config.score_key || 'score', 'score'),
          'Score is published here so a condition or loop can route on it')
      case 'memory':
        return field('Operation', selectInput('op', config.op || 'set', [
          { value: 'set', label: 'Set' }, { value: 'get', label: 'Read' },
          { value: 'append', label: 'Append' }, { value: 'delete', label: 'Clear' }])) +
          field('Key', textInput('key', config.key, 'topic')) +
          field('Value', textArea('value', config.value, 2, '{{last}}'),
          'Supports {{key}} references to upstream output')
      case 'transform':
        return field('Mode', selectInput('mode', config.mode || 'template', [
          { value: 'template', label: 'Template' }, { value: 'json', label: 'Pick JSON keys' },
          { value: 'regex', label: 'Regex extract' },
          { value: 'upper', label: 'UPPERCASE' }, { value: 'lower', label: 'lowercase' }])) +
          field('Template', textArea('template', config.template, 3, 'RESULT: {{last}}')) +
          field('Pattern / keys', textInput('regex', config.regex, 'group-1 pattern, or key1, key2 in json mode'))
      case 'http':
        return field('URL', textInput('url', config.url, 'https://api.example.com/v1/data')) +
          field('Method', selectInput('method', config.method || 'GET',
            ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD'].map((m) => ({ value: m, label: m })))) +
          field('Allowed hosts (required)', textInput('allow_hosts_text', config.allow_hosts_text, 'api.example.com'),
          'The node stays locked until you name the host. Nothing else is reachable.') +
          field('Headers (JSON)', textArea('headers_text', config.headers_text, 2, '{}')) +
          field('Body', textArea('body_text', config.body_text, 3, '')) +
          field('Timeout (s)', numberInput('timeout', config.timeout || 15, 1, 60))
      case 'workflow':
        return field('Saved agent', selectInput('agent_id', config.agent_id,
          [{ value: '', label: '— select a saved agent —' }].concat(
            (state.agents || []).map((a) => ({ value: a.id, label: a.name })))),
          'Runs another saved flow through this same engine') +
          field('Input key', textInput('input_key', config.input_key || 'input', 'input'),
          'Which workflow value is passed in')
      case 'error':
        return field('Message', textInput('message', config.message, 'Step failed'),
          'Published as a structured failure so the run can continue honestly')
      case 'checkpoint':
        return field('Label', textInput('label', config.label, 'stage-1'),
          'Resume later with this checkpoint name')
      case 'approval':
        return field('Prompt', textInput('prompt', config.prompt, 'Run the next step?'))
      case 'output':
        return field('Label', textInput('label', config.label, 'Final result')) +
          field('Template', textArea('template', config.template, 3, '{{last}}'))
      default:
        return '<span class="panel-note">Nothing to configure.</span>'
    }
  }

function renderConfig() {
    const body = $('#af-config-body')
    if (!body) return
    const title = $('#af-config-title')
    const kind = $('#af-config-kind')
    const flag = $('#af-validation')
    const node = nodeById(state.selected)
    if (!node) {
      if (title) title.textContent = 'Node'
      if (kind) kind.textContent = ''
      if (flag) flag.textContent = ''
      body.innerHTML = '<span class="panel-note">Select a node on the canvas to edit it.</span>'
      return
    }
    const info = KINDS[node.type] || KINDS.tool
    if (title) title.textContent = node.title
    if (kind) kind.textContent = info.label
    if (flag) {
      const errors = (state.validation && state.validation.errors) || []
      flag.textContent = errors.length ? errors.length + ' issue(s)' : 'valid'
      flag.dataset.state = errors.length ? 'bad' : 'ok'
    }
    body.innerHTML =
      '<div class="af-config-name"><input class="field" data-af-set="__title" value="' +
      esc(node.title) + '" aria-label="Node title"/></div>' +
      // Typed dataflow (Phase 8): publish this node's result under a named key
      // so downstream nodes read {{that_key}} instead of the ambient {{last}}.
      '<label class="af-config-field"><span>Output key</span><input class="field" ' +
      'data-af-set="output_key" value="' + esc(node.config.output_key || '') +
      '" placeholder="e.g. research_report" aria-label="Output key"/></label>' +
      configFields(node) +
      '<div class="af-config-geo">' +
      '<label><span>X</span><input class="field" type="number" data-af-geo="x" value="' + node.x + '"/></label>' +
      '<label><span>Y</span><input class="field" type="number" data-af-geo="y" value="' + node.y + '"/></label>' +
      '<label><span>W</span><input class="field" type="number" data-af-geo="w" value="' + node.w + '"/></label>' +
      '<label><span>H</span><input class="field" type="number" data-af-geo="h" value="' + node.h + '"/></label>' +
      '</div>'
  }

  /* ── history (undo/redo) ────────────────────────────────────────────── */
  function snapshot() {
    return state.agent ? JSON.stringify({ flow: state.agent.flow, name: state.agent.name,
      description: state.agent.description }) : ''
  }

  function pushHistory() {
    const current = snapshot()
    if (!current) return
    state.past.push(current)
    if (state.past.length > HISTORY_MAX) state.past.shift()
    state.future.length = 0
  }

  function applySnapshot(json) {
    const parsed = JSON.parse(json)
    state.agent.flow = parsed.flow
    state.agent.name = parsed.name
    state.agent.description = parsed.description
  }

  function undo() {
    if (!state.past.length) return
    state.future.push(snapshot())
    applySnapshot(state.past.pop())
    state.dirty = true
    render()
  }

  function redo() {
    if (!state.future.length) return
    state.past.push(snapshot())
    applySnapshot(state.future.pop())
    state.dirty = true
    render()
  }

/* ── graph mutations ────────────────────────────────────────────────── */
  function touch() {
    state.dirty = true
    renderHeader()
  }

  function newId(prefix) {
    return prefix + '_' + Math.random().toString(16).slice(2, 12)
  }

  const NODE_SIZE = {
    input: [220, 96], agent: [250, 132], subagent: [250, 132], tool: [226, 100],
    mcp: [226, 100], skill: [226, 96], model: [226, 96], condition: [226, 116],
    approval: [226, 108], output: [226, 100],
    router: [236, 128], parallel: [236, 112], merge: [226, 104], loop: [236, 124],
    validator: [236, 112], evaluator: [240, 128], memory: [226, 100],
    transform: [226, 100], http: [240, 124], workflow: [236, 112],
    error: [226, 104], checkpoint: [226, 96]
  }

  function addNode(type, x, y) {
    if (!state.agent) return
    const available = (state.capabilities && state.capabilities.available) || {}
    if (available[type] === false) {
      toast(((KINDS[type] || {}).hint || type) + ' is not available right now.', true)
      return
    }
    pushHistory()
    const size = NODE_SIZE[type] || [226, 100]
    const node = { id: newId('n'), type, title: (KINDS[type] || {}).label || type,
      x: snap(x), y: snap(y), w: size[0], h: size[1], config: {} }
    if (type === 'condition') node.config = { expression: '', true_branch: 'true', false_branch: 'false' }
    if (type === 'approval') node.config = { prompt: 'Approve this step?', remember: false }
    if (type === 'input') node.config = { label: 'Task input', placeholder: '' }
    if (type === 'output') node.config = { label: 'Final result', template: '' }
    if (type === 'subagent') {
      node.config = { name: 'Sub-agent', description: '', system_prompt: '', model: '',
        tools: [], skills: [], permissions: 'inherit', memory: 'none',
        input_schema: '', output_schema: '', max_steps: 3, retries: 1, on_failure: 'continue' }
    }
    state.agent.flow.nodes.push(node)
    state.selected = node.id
    touch()
    render()
  }

  function deleteNode(id) {
    if (!state.agent) return
    pushHistory()
    state.agent.flow.nodes = nodes().filter((n) => n.id !== id)
    state.agent.flow.edges = edges().filter((e) => e.from !== id && e.to !== id)
    if (state.selected === id) state.selected = ''
    touch()
    render()
  }

  function connect(fromId, toId, branch) {
    if (!state.agent || fromId === toId) return
    const from = nodeById(fromId)
    const to = nodeById(toId)
    if (!from || !to) return
    if (!canConnect(from.type, to.type)) {
      toast(((KINDS[from.type] || {}).label || from.type) + ' → ' +
        ((KINDS[to.type] || {}).label || to.type) + ' is not a legal connection.', true)
      return
    }
    const exists = edges().some((e) => e.from === fromId && e.to === toId &&
      (e.branch || '') === (branch || ''))
    if (exists) return
    pushHistory()
    state.agent.flow.edges.push({ id: newId('e'), from: fromId, to: toId, label: '', branch: branch || '' })
    touch()
    render()
  }

  function removeEdge(id) {
    if (!state.agent) return
    pushHistory()
    state.agent.flow.edges = edges().filter((e) => e.id !== id)
    touch()
    render()
  }

  function fitView() {
    const list = nodes()
    if (!list.length || !state.agent) return
    const minX = Math.min.apply(null, list.map((n) => n.x))
    const minY = Math.min.apply(null, list.map((n) => n.y))
    const maxX = Math.max.apply(null, list.map((n) => n.x + n.w))
    const maxY = Math.max.apply(null, list.map((n) => n.y + n.h))
    const box = $('#af-canvas-wrap')
    const width = (box && box.clientWidth) || 900
    const height = (box && box.clientHeight) || 600
    const zoom = Math.max(0.25, Math.min(1.6, Math.min(
      width / Math.max(1, maxX - minX + 120), height / Math.max(1, maxY - minY + 120))))
    state.viewport.zoom = Math.round(zoom * 100) / 100
    state.viewport.x = (width - (maxX - minX) * state.viewport.zoom) / 2 - minX * state.viewport.zoom
    state.viewport.y = (height - (maxY - minY) * state.viewport.zoom) / 2 - minY * state.viewport.zoom
    render()
  }

/* ── run log ─────────────────────────────────────────────────────────── */
  function renderRunLog() {
    const box = $('#af-runlog-body')
    if (!box) return
    const run = state.run
    if (!run || !run.id) {
      box.innerHTML = '<span class="panel-note">No run yet.</span>'
      const gate = $('#af-approve')
      if (gate) gate.hidden = true
      return
    }
    const rows = []
    rows.push('<div class="af-run-head"><span class="af-chip" data-state="' +
      esc(run.status) + '">' + esc(run.status) + '</span>' +
      '<span>' + esc(run.agent || '') + '</span>' +
      (run.reason ? '<span class="panel-note">' + esc(run.reason) + '</span>' : '') + '</div>')
    if (run.input) rows.push('<div class="af-run-input">in: ' + esc(run.input) + '</div>')
    for (const entry of (run.nodes || [])) {
      const out = String(entry.output || '').replace(/\s+/g, ' ').slice(0, 240)
      rows.push('<div class="af-run-row" data-state="' + esc(entry.status || '') + '">' +
        '<span class="af-run-dot"></span><strong>' + esc(entry.title || entry.type) + '</strong>' +
        '<span class="af-run-type">' + esc(entry.type) + '</span>' +
        '<span class="af-run-status">' + esc(entry.status || '') +
        (entry.attempts > 1 ? ' ×' + entry.attempts : '') + '</span>' +
        (out ? '<pre>' + esc(out) + '</pre>' : '') + '</div>')
    }
    if (run.result) rows.push('<div class="af-run-result">result: ' + esc(run.result) + '</div>')
    const events = (run.events || []).slice(-8).map((e) =>
      '<div class="af-run-event">' + new Date((e.at || 0) * 1000).toLocaleTimeString() +
      ' · ' + esc(e.event) + '</div>').join('')
    if (events) rows.push('<div class="af-run-events">' + events + '</div>')
    box.innerHTML = rows.join('')

    const gate = $('#af-approve')
    const text = $('#af-approve-text')
    if (gate && text) {
      if (state.approvals.length) {
        gate.hidden = false
        text.textContent = state.approvals[0].prompt
        gate.dataset.node = state.approvals[0].node
      } else {
        gate.hidden = true
      }
    }
    renderNodes()
    renderEdges()
  }

  /* ── API operations ────────────────────────────────────────────────── */
  async function loadCatalog() {
    // A cold catalog resolves the live ToolRegistry + MCP handshake and has been
    // measured above 5s, so a single tight timeout latched `catalog = null` and the
    // store line kept claiming "registry 0 tools". Retry once with a wider budget
    // and let a genuine failure stay visibly unavailable instead of reporting 0.
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const payload = await api('/agents/catalog', null, attempt ? 25000 : 15000)
        state.catalog = payload.catalog || null
        state.capabilities = payload.capabilities || null
        state.catalogError = null
        return
      } catch (error) {
        state.catalogError = error.message
        if (attempt === 0) await new Promise((r) => setTimeout(r, 800))
      }
    }
    // Never invent options the core cannot execute.
    state.catalog = null
    state.capabilities = null
    const hint = $('#af-hint')
    if (hint) hint.textContent = 'Core offline - capability list unavailable: ' + state.catalogError
  }

  async function loadAgents(selectId) {
    const payload = await api('/agents', null, 9000)
    state.agents = payload.agents || []
    if (payload.store && payload.store.error) {
      toast('Agent store problem: ' + payload.store.error, true)
    }
    const target = selectId || (state.agent && state.agent.id)
    if (target && state.agents.some((a) => a.id === target)) {
      await openAgent(target)
    } else if (state.agents.length) {
      await openAgent(state.agents[0].id)
    } else {
      state.agent = null
      render()
    }
  }

  async function openAgent(id) {
    const payload = await api('/agents/' + encodeURIComponent(id), null, 9000)
    state.agent = payload.agent || null
    state.validation = payload.validation || null
    state.selected = ''
    state.dirty = false
    state.past.length = 0
    state.future.length = 0
    state.viewport = (state.agent.flow && state.agent.flow.viewport) || { x: 0, y: 0, zoom: 1 }
    render()
    fitView()
  }

  async function saveAgent({ quiet = false } = {}) {
    if (!state.agent) return
    state.agent.flow.viewport = state.viewport
    const payload = await api('/agents/save',
      { id: state.agent.id, agent: state.agent }, 12000)
    state.agent = payload.agent
    state.validation = payload.validation || null
    state.dirty = false
    render()
    // `quiet` is used by Run, which has already told the user what it did.
    if (quiet) return
    toast(state.validation && state.validation.ok ? 'Flow saved.' :
      'Saved with issues: ' + ((state.validation.errors || [])[0] || ''),
      state.validation && !state.validation.ok)
  }

  async function refreshValidation() {
    if (!state.agent) return
    try {
      const payload = await api('/agents/validate', { id: state.agent.id }, 9000)
      state.validation = payload.validation
      renderConfig()
    } catch (error) { /* offline: keep the last known report */ }
  }

/* ── run control ───────────────────────────────────────────────────── */
  async function runFlow() {
    if (!state.agent) { toast('Select an agent first.', true); return }
    // Run executes the SAVED flow, so unsaved edits are saved first instead of
    // being refused. Refusing here was a dead end with no way forward: the
    // Save button is in the header, the toast named no control, and the user
    // was left clicking Run against a permanently "dirty" canvas. Saving is
    // not destructive - it writes the flow the user is looking at - so Run
    // does it and then says so. If the save fails, nothing is executed.
    if (state.dirty) {
      try {
        await saveAgent({ quiet: true })
      } catch (error) {
        toast('Not run — the flow could not be saved: ' + error.message, true)
        return
      }
      toast('Saved your changes, then ran the flow.')
    }
    const input = ($('#af-input') && $('#af-input').value) || ''
    // Pre-flight the empty-input case instead of letting the run start and
    // finish green. The input node used to publish "no input supplied" as a
    // SUCCESS, the agent node handed that sentence to the model, and the flow
    // reported "done" carrying a chat reply instead of a result. The backend
    // now fails that node honestly; this stops it before any model is called.
    if (!input.trim() && _needsInput()) {
      const field = $('#af-input')
      if (field) field.focus()
      toast('Type what this agent should do first — the Run box is empty.', true)
      return
    }
    try {
      await api('/agents/run', { id: state.agent.id, input }, 10000)
      startPolling()
      openLog(true)
    } catch (error) {
      // A refusal must name the control that clears it. "cancel it first"
      // with the Stop button hidden inside a closed panel was a dead end.
      const busy = /already running/i.test(error.message || '')
      if (busy) openLog(true)
      toast('Run refused: ' + error.message +
        (busy ? ' — press Stop to clear it.' : ''), true)
    }
  }

  // True when the graph starts at an input node, so an empty Run box is a
  // user error rather than a legitimately input-free flow (a bare tool node
  // bound to fixed args can run with nothing typed).
  function _needsInput() {
    const list = nodes()
    if (!list.length) return true
    const inbound = new Set(edges().map((e) => e.to))
    const entry = list.find((n) => n.type === 'input' && !inbound.has(n.id))
    return !!entry
  }

  function startPolling() {
    if (state.pollTimer) return
    state.pollTimer = setInterval(pollRun, 900)
  }

  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null }
  }

  async function pollRun() {
    try {
      const payload = await api('/agents/run', null, 6000)
      const run = payload.run || null
      state.approvals = payload.approvals || []
      if (!run || !run.id) { stopPolling(); render(); return }
      const previous = state.run
      state.run = run
      if (run.id !== state.lastRunId) state.lastRunId = run.id
      renderNodes(); renderEdges(); renderHeader()
      if (run.status !== 'running' && run.status !== 'pending' &&
          (!previous || previous.status === 'running' || previous.status === 'pending')) {
        stopPolling()
        renderRunLog()
        toast('Flow ' + run.status + (run.reason ? ' — ' + run.reason : ''),
          run.status === 'failed')
      }
    } catch (error) {
      stopPolling()
    }
  }

  function openLog(open) {
    const panel = $('#af-runlog')
    if (panel) panel.classList.toggle('open', open !== false)
  }

  /* ── natural language builder ───────────────────────────────────────── */
  async function buildFromText() {
    const input = $('#af-nl')
    const prompt = (input && input.value || '').trim()
    if (!prompt) { toast('Describe the agent you want first.', true); return }
    const button = $('#af-nl-build')
    if (button) button.disabled = true
    try {
      // save:false is deliberate: the draft lands on the canvas as an UNSAVED
      // preview, so nothing is persisted or executed until the user accepts it.
      const payload = await api('/agents/draft', { prompt, save: false }, 60000)
      state.agent = payload.draft
      state.validation = payload.validation || null
      state.selected = ''
      state.dirty = true
      state.past.length = 0
      state.future.length = 0
      render()
      fitView()
      toast('Draft built — review it, then Save. Nothing has run.')
    } catch (error) {
      toast('Could not build that flow: ' + error.message, true)
    } finally {
      if (button) button.disabled = false
    }
  }

/* ── pointer interactions ───────────────────────────────────────────── */
  function canvasPoint(event) {
    const wrap = $('#af-canvas-wrap')
    if (!wrap) return { x: 0, y: 0 }
    const rect = wrap.getBoundingClientRect()
    return {
      x: (event.clientX - rect.left - state.viewport.x) / state.viewport.zoom,
      y: (event.clientY - rect.top - state.viewport.y) / state.viewport.zoom
    }
  }

  function onPointerDown(event) {
    if (!state.agent) return
    const portOut = event.target.closest('[data-af-out]')
    const portIn = event.target.closest('[data-af-in]')
    const nodeEl = event.target.closest('[data-af-node]')
    if (portOut) {
      event.preventDefault()
      event.stopPropagation()
      state.link = { from: portOut.dataset.afOut, point: canvasPoint(event) }
      renderEdges()
      return
    }
    if (portIn) {
      event.preventDefault()
      event.stopPropagation()
      const target = portIn.dataset.afIn
      const source = state.link && state.link.from
      if (source) {
        const from = nodeById(source)
        // A condition's two outgoing edges are tagged true/false so the server
        // routes only the branch that was actually taken.
        const branch = from && from.type === 'condition'
          ? (event.shiftKey ? 'false' : 'true') : ''
        connect(source, target, branch)
        state.link = null
        renderEdges()
      }
      return
    }
    if (nodeEl) {
      const node = nodeById(nodeEl.dataset.afNode)
      if (!node) return
      state.selected = node.id
      const point = canvasPoint(event)
      state.drag = { id: node.id, dx: point.x - node.x, dy: point.y - node.y, moved: false }
      nodeEl.classList.add('dragging')
      renderConfig()
      render()
      return
    }
    const wrap = $('#af-canvas-wrap')
    if (wrap && wrap.contains(event.target)) {
      state.pan = { x: event.clientX, y: event.clientY, vx: state.viewport.x, vy: state.viewport.y }
      state.selected = ''
      renderConfig()
      render()
    }
  }

  function onPointerMove(event) {
    if (state.link) {
      state.link.point = canvasPoint(event)
      renderEdges()
      return
    }
    if (state.drag) {
      const point = canvasPoint(event)
      const node = nodeById(state.drag.id)
      if (!node) return
      node.x = snap(point.x - state.drag.dx)
      node.y = snap(point.y - state.drag.dy)
      state.drag.moved = true
      renderNodes(); renderEdges(); renderMinimap()
      return
    }
    if (state.pan) {
      state.viewport.x = state.pan.vx + (event.clientX - state.pan.x)
      state.viewport.y = state.pan.vy + (event.clientY - state.pan.y)
      renderNodes(); renderEdges(); renderMinimap()
    }
  }

  function onPointerUp() {
    if (state.link) { state.link = null; renderEdges() }
    if (state.drag) {
      if (state.drag.moved) { state.dirty = true; renderHeader() }
      state.drag = null
      $$('.af-node.dragging').forEach((el) => el.classList.remove('dragging'))
    }
    state.pan = null
  }

  function onWheel(event) {
    const wrap = $('#af-canvas-wrap')
    if (!wrap || !wrap.contains(event.target)) return
    event.preventDefault()
    const before = canvasPoint(event)
    const factor = event.deltaY < 0 ? 1.1 : 0.9
    state.viewport.zoom = Math.max(0.25, Math.min(2.5, state.viewport.zoom * factor))
    const after = canvasPoint(event)
    state.viewport.x += (after.x - before.x) * state.viewport.zoom
    state.viewport.y += (after.y - before.y) * state.viewport.zoom
    renderNodes(); renderEdges(); renderMinimap()
  }

/* ── config panel writes back to the real flow ───────────────────────── */
  function applyConfigChange(target) {
    const node = nodeById(state.selected)
    if (!node) return
    if (target.dataset.afSet !== undefined) {
      const path = target.dataset.afSet
      if (path === '__title') {
        node.title = String(target.value || '').slice(0, 64) || (KINDS[node.type] || {}).label
      } else if (path === '_mcp_combo') {
        const combo = String(target.value || '')
        if (!combo) { node.config.server = ''; node.config.tool = '' }
        else {
          const dot = combo.indexOf('.')
          node.config.server = combo.slice(0, dot)
          node.config.tool = combo.slice(dot + 1)
        }
      } else {
        node.config[path] = target.value
      }
      touch()
      renderNodes(); renderEdges()
      refreshValidation()
      return
    }
    if (target.dataset.afMulti !== undefined) {
      const chosen = Array.from(target.selectedOptions || []).map((o) => o.value)
      node.config[target.dataset.afMulti] = chosen
      touch()
      renderNodes()
      return
    }
    if (target.dataset.afGeo !== undefined) {
      const key = target.dataset.afGeo
      let value = Number(target.value)
      if (!isFinite(value)) return
      if (key === 'x' || key === 'y') value = snap(value)
      if (key === 'w') value = Math.max(160, Math.min(460, value))
      if (key === 'h') value = Math.max(62, Math.min(340, value))
      node[key] = value
      touch()
      renderNodes(); renderEdges(); renderMinimap()
    }
  }

  /* ── init ──────────────────────────────────────────────────────────── */
  // Starter templates as real, clickable cards. The server exposes
  // /agents/templates; before this existed the Content Writer flow existed in
  // the backend but was unreachable from the panel, so the Agents tab opened
  // empty and looked broken.
  async function loadTemplates() {
    const host = $('#af-templates')
    if (!host) return
    try {
      const payload = await api('/agents/templates', {}, 9000)
      const list = Array.isArray(payload.templates) ? payload.templates : []
      if (!list.length) { host.innerHTML = ''; return }
      host.innerHTML = '<h4 class="af-templates-title">Start from a template</h4>' +
        '<div class="af-templates-grid">' + list.map((tpl) =>
          '<button type="button" class="af-template-card" data-af-template="' +
            String(tpl.id || '').replace(/"/g, '&quot;') + '" title="' +
            String(tpl.description || '').replace(/"/g, '&quot;') + '">' +
            '<i data-lucide="' + (tpl.id === 'content-writer' ? 'file-text' : 'sparkles') + '"></i>' +
            '<strong>' + String(tpl.name || tpl.id) + '</strong>' +
            '<span>' + String(tpl.description || '') + '</span>' +
          '</button>').join('') + '</div>'
      window.lucide?.createIcons()
    } catch { /* templates are a convenience; failing to list them is not fatal */ }
  }

  // Create a real agent from a template. This is the one-click path to a
  // runnable Content Writer: the graph is built server-side from the live
  // registry, then opened for editing.
  async function createFromTemplate(templateId) {
    const id = String(templateId || '').trim()
    if (!id) return
    try {
      const payload = await api('/agents/create', { template: id }, 15000)
      await loadAgents(payload.agent.id)
      toast(payload.validation && payload.validation.ok === false
        ? 'Created — check the validation warnings before running.'
        : 'Created from template. Type a topic below and press Run.')
    } catch (error) { toast(error.message, true) }
  }

  function bind() {
    const wrap = $('#af-canvas-wrap')
    if (wrap) {
      wrap.addEventListener('pointerdown', onPointerDown)
      wrap.addEventListener('pointermove', onPointerMove)
      window.addEventListener('pointerup', onPointerUp)
      wrap.addEventListener('wheel', onWheel, { passive: false })
      wrap.addEventListener('contextmenu', (event) => {
        // Right-click deletes an edge so a connection can be rewired.
        const path = event.target.closest('path.af-edge')
        if (!path) return
        event.preventDefault()
        const hit = edges().find((e) =>
          edgePath(nodeById(e.from) || {}, nodeById(e.to) || {}) === path.getAttribute('d'))
        if (hit) removeEdge(hit.id)
      })
      wrap.addEventListener('dblclick', (event) => {
        if (event.target.closest('[data-af-node]')) return
        const point = canvasPoint(event)
        addNode('tool', point.x - 100, point.y - 40)
      })
    }

    $('#af-palette')?.addEventListener('click', (event) => {
      const chip = event.target.closest('[data-af-add]')
      if (!chip) return
      const box = $('#af-canvas-wrap')
      const rect = box ? box.getBoundingClientRect() : { width: 800, height: 600 }
      const x = (rect.width / 2 - state.viewport.x) / state.viewport.zoom
      const y = (rect.height / 2 - state.viewport.y) / state.viewport.zoom
      addNode(chip.dataset.afAdd, x - 100, y - 40)
    })

    $('#af-list')?.addEventListener('click', (event) => {
      const item = event.target.closest('[data-af-agent]')
      if (!item) return
      if (state.dirty && !window.confirm('Unsaved changes on this flow. Switch anyway?')) return
      openAgent(item.dataset.afAgent).catch((error) => toast(error.message, true))
    })

    $('#af-search')?.addEventListener('input', (event) => {
      const term = String(event.target.value || '').toLowerCase()
      const all = state.agents
      state.agents = term ? all.filter((a) =>
        String(a.name || '').toLowerCase().includes(term) ||
        String(a.description || '').toLowerCase().includes(term)) : all
      renderList()
    })

    $('#af-new')?.addEventListener('click', async () => {
      try {
        const payload = await api('/agents/create', { name: 'New Agent' }, 10000)
        await loadAgents(payload.agent.id)
        toast('Agent created.')
      } catch (error) { toast(error.message, true) }
    })
    // Template cards create a real, immediately-runnable agent.
    $('#af-templates')?.addEventListener('click', (event) => {
      const card = event.target.closest('[data-af-template]')
      if (card) createFromTemplate(card.dataset.afTemplate)
    })

    $('#af-delete')?.addEventListener('click', async () => {
      if (!state.agent) return
      if (!window.confirm('Delete "' + state.agent.name + '" permanently?')) return
      try {
        await api('/agents/delete', { id: state.agent.id }, 10000)
        state.agent = null
        await loadAgents()
        toast('Agent deleted.')
      } catch (error) { toast(error.message, true) }
    })

    $('#af-duplicate')?.addEventListener('click', async () => {
      if (!state.agent) return
      try {
        const payload = await api('/agents/duplicate', { id: state.agent.id }, 12000)
        await loadAgents(payload.agent.id)
        toast('Duplicated.')
      } catch (error) { toast(error.message, true) }
    })

    $('#af-rename')?.addEventListener('click', async () => {
      if (!state.agent) return
      const name = window.prompt('Agent name', state.agent.name)
      if (!name || name === state.agent.name) return
      try {
        const payload = await api('/agents/rename', { id: state.agent.id, name }, 10000)
        state.agent = payload.agent
        state.dirty = false
        await loadAgents(state.agent.id)
        toast('Renamed.')
      } catch (error) { toast(error.message, true) }
    })

    $('#af-toggle')?.addEventListener('click', async () => {
      if (!state.agent) return
      const next = state.agent.enabled === false
      try {
        const payload = await api('/agents/toggle', { id: state.agent.id, enabled: next }, 10000)
        state.agent = payload.agent
        renderHeader(); renderList()
        toast(next ? 'Agent active.' : 'Agent disabled — it will refuse to run.')
      } catch (error) { toast(error.message, true) }
    })


    $('#af-save')?.addEventListener('click', () => {
      saveAgent().catch((error) => toast(error.message, true))
    })
    $('#af-run')?.addEventListener('click', runFlow)
    $('#af-cancel')?.addEventListener('click', async () => {
      try {
        const payload = await api('/agents/cancel', {}, 8000)
        toast(payload.message || 'Stop requested.', !payload.ok)
      } catch (error) { toast(error.message, true) }
    })
    $('#af-nl-build')?.addEventListener('click', buildFromText)
    $('#af-nl')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') { event.preventDefault(); buildFromText() }
    })
    $('#af-undo')?.addEventListener('click', undo)
    $('#af-redo')?.addEventListener('click', redo)
    $('#af-fit')?.addEventListener('click', fitView)
    $('#af-zoom-in')?.addEventListener('click', () => {
      state.viewport.zoom = Math.min(2.5, Math.round((state.viewport.zoom * 1.15) * 100) / 100)
      renderNodes(); renderEdges(); renderMinimap()
    })
    $('#af-zoom-out')?.addEventListener('click', () => {
      state.viewport.zoom = Math.max(0.25, Math.round((state.viewport.zoom * 0.87) * 100) / 100)
      renderNodes(); renderEdges(); renderMinimap()
    })
    $('#af-node-delete')?.addEventListener('click', () => {
      if (state.selected) deleteNode(state.selected)
    })
    $('#af-runlog-close')?.addEventListener('click', () => openLog(false))

    const decide = (approve) => api('/agents/approve',
      { node: $('#af-approve').dataset.node, approve }, 8000)
      .then(() => { toast(approve ? 'Approved.' : 'Denied.'); pollRun() })
      .catch((error) => toast(error.message, true))
    $('#af-approve-yes')?.addEventListener('click', () => decide(true))
    $('#af-approve-no')?.addEventListener('click', () => decide(false))

    $('#af-config-body')?.addEventListener('change', (event) => {
      if (event.target.matches('[data-af-set],[data-af-multi],[data-af-geo]')) {
        pushHistory()
        applyConfigChange(event.target)
      }
    })
    $('#af-config-body')?.addEventListener('input', (event) => {
      const target = event.target
      if (target.matches('[data-af-geo]')) return
      if (target.matches('[data-af-set],[data-af-multi]')) applyConfigChange(target)
    })

    document.addEventListener('keydown', (event) => {
      const panel = $('[data-cowork-panel="agents"]')
      if (!panel || !panel.classList.contains('active')) return
      const tag = (document.activeElement && document.activeElement.tagName) || ''
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return
      const key = event.key.toLowerCase()
      if ((event.ctrlKey || event.metaKey) && key === 'z') {
        event.preventDefault()
        event.shiftKey ? redo() : undo()
      } else if ((event.ctrlKey || event.metaKey) && key === 'y') {
        event.preventDefault(); redo()
      } else if (event.key === 'Delete' && state.selected) {
        event.preventDefault(); deleteNode(state.selected)
      } else if (event.key === 'Escape') {
        state.selected = ''
        renderConfig(); render()
      }
    })
  }

  async function init() {
    if (!$('#af-builder')) return
    bind()
    render()
    try {
      await loadCatalog()
      await loadAgents()
      // Templates load independently of the agent list: they are the one-click
      // entry point when the rail is empty, which is exactly when the panel
      // looked broken.
      loadTemplates()
      await pollRun()
      const run = state.run
      if (run && run.id && (run.status === 'running' || run.status === 'pending')) {
        startPolling()
        openLog(true)
      }
    } catch (error) {
      const hint = $('#af-hint')
      if (hint) hint.textContent = 'Core offline — start the JARVIS core to build flows.'
      render()
    }
  }

  window.JarvisAgentFlow = { state, init, refresh: loadAgents, openAgent, render }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()
