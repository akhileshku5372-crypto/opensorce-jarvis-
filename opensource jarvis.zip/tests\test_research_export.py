"""Research exports: one file per topic+format, never a pile of duplicates.

Offline: every export goes into a temp folder, and no network or model is used.
"""
import glob
import importlib.util
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


rex = _load("research_export")

REPORT = ("Overview\nISRO crossed 100 launches with an 85 percent success rate.\n\n"
          "Key findings\n- PSLV-C62 missed its orbit on 2026-01-12\n"
          "- INR 76,000 crore outlay approved")


def payload(**over):
    base = {"type": "research", "topic": "ISRO launch record", "tier": "deep",
            "written_by": "free-writer", "report": REPORT, "ms": 33000,
            "scraped": 15, "attempted": 24, "hosts": 11, "cross_checked": 6,
            "single_source": 5, "found": 121, "unique": 78, "collapsed": 43,
            "answered": 5, "chain_size": 8,
            "sources_detail": [
                {"host": "a.com", "url": "https://a.com/1", "ok": True, "bytes": 9012, "ms": 1200},
                {"host": "b.com", "url": "https://b.com/2", "ok": False, "bytes": 0,
                 "ms": 300, "error": "HTTP 403"}]}
    base.update(over)
    return base


class ExportFolderTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="jarvis-export-")
        self._out = rex.OUT_DIR
        rex.OUT_DIR = self.dir

    def tearDown(self):
        rex.OUT_DIR = self._out
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_every_format_writes_exactly_one_file_per_topic(self):
        for fmt in rex.FORMATS:
            path, meta = rex.export(fmt, payload())
            self.assertTrue(path, meta.get("error"))
            self.assertTrue(os.path.exists(path))
            self.assertNotIn("2026", os.path.basename(path),
                             "a timestamped name means every export adds a new file")
        self.assertEqual(len(glob.glob(os.path.join(self.dir, "*"))), 4)

    def test_an_unchanged_re_export_is_not_written_again(self):
        pl = payload()
        path, meta = rex.export("md", pl)
        pl["export"] = {"md": {"path": path, "signature": meta["signature"],
                               "bytes": meta["bytes"]}}
        before = os.path.getmtime(path)
        again, meta2 = rex.export("md", pl)
        self.assertEqual(again, path)
        self.assertTrue(meta2.get("already"), "same content must not be rewritten")
        self.assertEqual(os.path.getmtime(path), before)
        self.assertEqual(len(glob.glob(os.path.join(self.dir, "*"))), 1)

    def test_changed_research_overwrites_the_same_file(self):
        pl = payload()
        path, meta = rex.export("md", pl)
        pl["export"] = {"md": {"path": path, "signature": meta["signature"]}}
        pl["report"] = REPORT + "\n\nCorrections\n- A later finding was added"
        path2, meta2 = rex.export("md", pl)
        self.assertEqual(path2, path)
        self.assertFalse(meta2.get("already"))
        self.assertEqual(len(glob.glob(os.path.join(self.dir, "*"))), 1)
        with open(path2, encoding="utf-8") as fh:
            self.assertIn("A later finding was added", fh.read())

    def test_nothing_to_export_is_refused_not_faked(self):
        for bad in (None, {}, {"error": "0 pages readable"}, {"topic": "x", "report": ""}):
            path, meta = rex.export("pdf", bad)
            self.assertIsNone(path)
            self.assertTrue(meta.get("error"))

    def test_unknown_format_names_the_valid_ones(self):
        path, meta = rex.export("exe", payload())
        self.assertIsNone(path)
        self.assertIn("md", meta["error"])


class ExportContentTest(unittest.TestCase):
    """The files must carry the run's honesty, not just its prose."""

    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="jarvis-export-")
        self._out = rex.OUT_DIR
        rex.OUT_DIR = self.dir

    def tearDown(self):
        rex.OUT_DIR = self._out
        shutil.rmtree(self.dir, ignore_errors=True)

    def _text(self, path):
        if path.endswith(".md"):
            with open(path, encoding="utf-8") as fh:
                return fh.read()
        if path.endswith(".pdf"):
            import pymupdf
            doc = pymupdf.open(path)
            try:
                return "".join(doc[i].get_text() for i in range(doc.page_count))
            finally:
                doc.close()
        if path.endswith(".docx"):
            from docx import Document
            doc = Document(path)
            parts = [p.text for p in doc.paragraphs]
            for table in doc.tables:
                for row in table.rows:
                    parts.extend(cell.text for cell in row.cells)
            return "\n".join(parts)
        if path.endswith(".pptx"):
            from pptx import Presentation
            pres = Presentation(path)
            parts = []
            for slide in pres.slides:
                for shape in slide.shapes:
                    if shape.has_text_frame:
                        parts.append(shape.text_frame.text)
            return "\n".join(parts)
        return ""

    def test_all_four_formats_carry_the_numbers_and_the_failed_source(self):
        for fmt in rex.FORMATS:
            path, meta = rex.export(fmt, payload())
            text = self._text(path)
            label = "%s: " % fmt
            self.assertIn("85 percent", text, label + "report prose missing")
            self.assertIn("15 of 24", text, label + "read/attempted counts missing")
            self.assertIn("https://b.com/2", text, label + "source list missing")
            self.assertIn("FAILED", text.upper(), label + "failed source not admitted")
            self.assertGreater(os.path.getsize(path), 400, label + "file too small")

    def test_pdf_paginates_instead_of_duplicating_pages(self):
        big = payload(report="Overview\n" + ("A long sentence with 42 percent. " * 900))
        path, meta = rex.export("pdf", big)
        import pymupdf
        doc = pymupdf.open(path)
        try:
            self.assertGreater(doc.page_count, 1)
            self.assertLess(doc.page_count, 40, "runaway pagination")
            first = doc[0].get_text()
            last = doc[doc.page_count - 1].get_text()
            self.assertNotIn(first[:60].strip(), last, "page 1 must not repeat on the last page")
            self.assertTrue(last.strip(), "last page must carry text")
        finally:
            doc.close()

    def test_japanese_output_survives_the_pdf(self):
        ja = payload(topic="半導体 調査",
                     report="概要\n固体電池は安全です。\n\n主要な発見\n- 数値は 42 パーセント")
        path, meta = rex.export("pdf", ja)
        import pymupdf
        doc = pymupdf.open(path)
        try:
            text = doc[0].get_text()
        finally:
            doc.close()
        self.assertIn("固体電池", text)


class FormatMatcherTest(unittest.TestCase):
    def test_sentences_map_to_formats(self):
        cases = {
            "export the last research as pdf": "pdf",
            "research ka report pptx banao": "pptx",
            "export report in word document": "docx",
            "last research markdown me nikalo": "md",
        }
        for text, want in cases.items():
            self.assertEqual(rex.formats_for(text), want, text)

    def test_a_research_request_is_not_an_export_request(self):
        # The voice route requires a verb AND an object; formats_for only picks
        # the format word, so check the route-level gate here too.
        voice = _load("voice_engine")
        self.assertIsNone(voice._export_request("gpt 6 astra ki report dikhao"))
        self.assertIsNone(voice._export_request("research quantum computing"))
        self.assertEqual(voice._export_request("export the last research as pdf"), "pdf")


if __name__ == "__main__":
    unittest.main()
