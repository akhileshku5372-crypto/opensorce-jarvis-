# -*- coding: utf-8 -*-
"""_google_or_ro.py — find the real free Google/OpenRouter model slugs."""
import json, os, urllib.request

def get(url, key=None, timeout=12):
    req = urllib.request.Request(url, headers={'User-Agent': 'Jarvis-probe/1.0'})
    if key:
        req.add_header('Authorization', 'Bearer ' + key)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(300000).replace(b'\n', b' ')[:290000]
    except Exception as e:
        return None, type(e).__name__ + ' ' + str(e)[:90]

print('== Google: list of free/flash models (key + no-key) ==')
for label, key in (('key', os.environ.get('GOOGLE_API_KEY')),
                   ('no-key', None)):
    st, body = get('https://generativelanguage.googleapis.com/v1/models', key, timeout=12)
    print('%s HTTP %s' % (label, st))
    if st == 200:
        try:
            names = [m['name'].split('/')[-1] for m in json.loads(body).get('models', [])]
            print('   flash:', [n for n in names if 'flash' in n][:14])
            print('   all:', names[:14])
        except Exception as e:
            print('   parse err:', e, body[:200])

print('\n== OpenRouter: free models (page 1) ==')
st, body = get('https://openrouter.ai/api/v1/models?params={"free":true}')
print('HTTP', st)
if st == 200:
    try:
        data = json.loads(body)
        rows = []
        for m in data.get('data', [])[:16]:
            pr = m.get('pricing', {}) or {}
            rows.append((m['id'], pr.get('prompt', {}).get('currency'),
                         pr.get('chat', {}).get('currency')))
        print(rows)
    except Exception as e:
        print('parse err:', e, body[:3000])

print('\n== XKiro domain retry (DNS) ==')
import time
time.sleep(15)
st, body = get('https://llm.eqium.com/v1/models')
print('https://llm.eqium.com/v1/models -> HTTP', st, body[:120])
