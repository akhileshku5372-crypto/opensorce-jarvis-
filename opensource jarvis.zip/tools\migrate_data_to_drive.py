"""Copy existing persistent data to the D: data root. NEVER deletes the source.

Run:  .venv\\Scripts\\python.exe tools\\migrate_data_to_drive.py [--dry-run]

Safety rules baked into this script
-----------------------------------
1. **Copy, never move.** The C: source is left untouched. If the app later proves
   unhappy, deleting the copy is enough to get the old behaviour back.
2. **Verify before reporting success.** Every file is compared by size and every
   SQLite database by row count. A file that does not verify is reported as
   FAILED, not quietly skipped.
3. **Idempotent.** Re-running re-copies and re-verifies.
4. **JSON stores are merged, not clobbered**, so migrating twice cannot lose a
   source that was added on D: in between.

Nothing here deletes anything. Removing the old C: copies is a separate,
deliberate step for the user to run after the app has proven itself.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "background"))

from background import storage_paths as sp  # noqa: E402


def _row_counts(db: Path):
    """(conversations, messages) for our schema, or None for a foreign DB."""
    try:
        conn = sqlite3.connect("file:%s?mode=ro" % db.as_posix(), uri=True)
        try:
            names = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"conversations", "messages"} <= names:
                return None
            c = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
            m = conn.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
            return (int(c), int(m))
        finally:
            conn.close()
    except Exception:
        return None


def copy_file(src: Path, dst: Path, dry: bool) -> dict:
    """Copy one file and verify size (and row counts for our SQLite schema)."""
    result = {"source": str(src), "target": str(dst), "ok": False,
              "bytes": 0, "verified": False, "note": ""}
    if not src.exists() or not src.is_file():
        result["note"] = "source missing"
        return result
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dry:
        result.update({"ok": True, "verified": True,
                       "note": "dry run: %d bytes" % src.stat().st_size})
        return result
    if src.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
        # Never plain-copy a live SQLite file: its WAL may hold newer pages than
        # the main file. Use SQLite's own backup API for a consistent snapshot.
        try:
            src_conn = sqlite3.connect(str(src))
            dst_conn = sqlite3.connect(str(dst))
            with dst_conn:
                src_conn.backup(dst_conn)
            src_conn.close()
            dst_conn.close()
        except Exception as exc:
            result["note"] = "sqlite backup failed: %s" % exc
            return result
    else:
        shutil.copy2(str(src), str(dst))

    if dst.exists():
        result["bytes"] = dst.stat().st_size
        if src.stat().st_size == dst.stat().st_size:
            src_rows, dst_rows = _row_counts(src), _row_counts(dst)
            if src_rows is None or dst_rows is None or src_rows == dst_rows:
                result["verified"] = True
                result["ok"] = True
                result["note"] = ("sqlite %s conv/%s msg" % dst_rows
                                  if src_rows else "")
            else:
                result["note"] = "row mismatch %s vs %s" % (src_rows, dst_rows)
        else:
            result["note"] = "size mismatch"
    else:
        result["note"] = "copy produced no file"
    return result


def merge_json(src: Path, dst: Path, dry: bool) -> dict:
    """Merge a {"sources": [...]} JSON store by id, never dropping entries."""
    result = {"source": str(src), "target": str(dst), "ok": False,
              "verified": False, "note": ""}
    if not src.exists():
        result["note"] = "source missing"
        return result
    try:
        incoming = json.loads(src.read_text(encoding="utf-8"))
    except Exception as exc:
        result["note"] = "unreadable source: %s" % exc
        return result
    existing = {"sources": []}
    if dst.exists():
        try:
            loaded = json.loads(dst.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                existing = loaded
        except Exception:
            pass
    have = {s.get("id") for s in (existing.get("sources") or [])
            if isinstance(s, dict)}
    merged = list(existing.get("sources") or [])
    added = 0
    for item in incoming.get("sources") or []:
        if isinstance(item, dict) and item.get("id") not in have:
            merged.append(item)
            have.add(item.get("id"))
            added += 1
    existing["sources"] = merged
    if dry:
        result.update({"ok": True, "verified": True,
                       "note": "dry run: would add %d source(s)" % added})
        return result
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(existing, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    result.update({"ok": True, "verified": True, "bytes": dst.stat().st_size,
                   "note": "merged %d new source(s), total %d"
                           % (added, len(merged))})
    return result


def copy_tree(src: Path, dst: Path, dry: bool) -> dict:
    """Copy a directory tree; verifies file count and total bytes."""
    result = {"source": str(src), "target": str(dst), "ok": False, "verified": False,
              "note": "", "files": 0, "bytes": 0}
    if not src.exists() or not src.is_dir():
        result["note"] = "source missing"
        return result
    files = [p for p in src.rglob("*") if p.is_file()]
    result["files"] = len(files)
    if dry:
        result.update({"ok": True, "verified": True,
                       "note": "dry run: %d file(s)" % len(files)})
        return result
    shutil.copytree(str(src), str(dst), dirs_exist_ok=True)
    copied = [p for p in dst.rglob("*") if p.is_file()]
    src_bytes = sum(p.stat().st_size for p in files)
    dst_bytes = sum(p.stat().st_size for p in copied)
    result["verified"] = len(copied) >= len(files) and dst_bytes >= src_bytes
    result.update({"ok": result["verified"], "bytes": dst_bytes,
                   "note": "%d/%d file(s), %d bytes"
                           % (len(copied), len(files), dst_bytes)})
    return result


def build_plan() -> list:
    """(label, kind, source, destination) for everything worth migrating."""
    plan = []
    plan.append(("jarvis conversations", "file",
                 ROOT / "jarvis" / "conversations.db",
                 sp.file_path("jarvis", "conversations.db")))
    plan.append(("kamisensei conversations", "file",
                 ROOT / "kamisensei" / "conversations.db",
                 sp.file_path("kamisensei", "conversations.db")))
    # Legacy pre-migration stores, if a previous build created them.
    plan.append(("legacy memory_vault.db", "file",
                 ROOT / "jarvis-core" / "memory_vault.db",
                 sp.file_path("jarvis", "memory_vault.db")))
    plan.append(("shared chroma_db (legacy)", "tree",
                 ROOT / "chroma_db", sp.jarvis_memory_dir()))
    plan.append(("kamisensei sources", "json",
                 ROOT / "kamisensei_db.json", sp.kamisensei_sources()))
    plan.append(("backend sources", "json",
                 ROOT / "backend" / "kamisensei_db.json", sp.kamisensei_sources()))
    plan.append(("notebooks", "tree",
                 ROOT / "notebooks", sp.kamisensei_notebooks()))
    return plan


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true",
                        help="report what would be copied without writing")
    args = parser.parse_args()

    root = sp.data_root()
    status = sp.status()
    print("data root : %s" % root)
    print("configured: %s" % status.get("configured"))
    if status.get("fallback"):
        print("!! FALLBACK ACTIVE - configured root unusable, using %s"
              % root)
    print("mode      : %s" % ("DRY RUN (nothing written)" if args.dry_run else "COPY"))
    print("-" * 72)

    results, failures = [], 0
    for label, kind, src, dst in build_plan():
        if kind == "file":
            res = copy_file(src, dst, args.dry_run)
        elif kind == "json":
            res = merge_json(src, dst, args.dry_run)
        else:
            res = copy_tree(src, dst, args.dry_run)
        res["label"] = label
        results.append(res)
        flag = "ok  " if res["ok"] else "SKIP" if "missing" in res["note"] else "FAIL"
        if not res["ok"] and "missing" not in res["note"]:
            failures += 1
        print("[%s] %-26s %s" % (flag, label, res["note"] or "-"))

    print("-" * 72)
    print("copied %d item(s), %d failure(s). Source on C: was NOT modified."
          % (sum(1 for r in results if r["ok"]), failures))
    print("Verify in the app that history and memory still work, then you may "
          "remove the old copies on C: manually.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())