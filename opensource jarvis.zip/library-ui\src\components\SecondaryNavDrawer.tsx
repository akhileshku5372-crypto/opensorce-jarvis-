import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  StickyNote,
  Folder,
  Settings,
  Plus,
  Trash2,
  Check,
  Sparkles,
  RotateCcw,
  Download,
  Volume2,
  X,
} from 'lucide-react';
import {
  MaterialItem,
  NoteItem,
  CollectionItem,
  NavSection,
  SkillCategory,
  SoftSubcategory,
  HardSubcategory,
} from '../data/archiveData';
import { downloadCompleteProjectZip } from '../utils/exportProjectZip';

interface SecondaryNavDrawerProps {
  activeNav: NavSection;
  onCloseToHome: () => void;
  materials: MaterialItem[];
  selectedSource: MaterialItem | null;
  onSelectSource: (item: MaterialItem) => void;
  onRemoveMaterial: (id: string) => void;
  onOpenAddModal: (cat?: SkillCategory) => void;
  onLoadAllPresets: () => void;
  onResetEmptyShelves: () => void;
  notes: NoteItem[];
  onAddNote: (note: NoteItem) => void;
  onDeleteNote: (id: string) => void;
  collections: CollectionItem[];
  onLoadCollection: (col: CollectionItem) => void;
  isOnline: boolean;
  onToggleOnline: () => void;
  cleanBackdrop: boolean;
  onToggleCleanBackdrop: () => void;
  onOpenExportModal: () => void;
  onSpeakText: (text: string) => void;
}

export const SecondaryNavDrawer: React.FC<SecondaryNavDrawerProps> = ({
  activeNav,
  onCloseToHome,
  materials,
  selectedSource,
  onSelectSource,
  onRemoveMaterial,
  onOpenAddModal,
  onLoadAllPresets,
  onResetEmptyShelves,
  notes,
  onAddNote,
  onDeleteNote,
  collections,
  onLoadCollection,
  isOnline,
  onToggleOnline,
  cleanBackdrop,
  onToggleCleanBackdrop,
  onOpenExportModal,
  onSpeakText,
}) => {
  const [libraryFilter, setLibraryFilter] = useState<'all' | 'soft' | 'hard'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteCat, setNewNoteCat] = useState<SkillCategory>('soft');

  if (activeNav === 'Home') return null;

  const filteredLibrary = materials.filter((m) =>
    libraryFilter === 'all' ? true : m.category === libraryFilter
  );

  const searchResults = materials.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.title.toLowerCase().includes(q) ||
      m.subtitle.toLowerCase().includes(q) ||
      m.subcategory.toLowerCase().includes(q) ||
      m.summary.toLowerCase().includes(q) ||
      m.paragraphs.some((p) => p.toLowerCase().includes(q))
    );
  });

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteTitle.trim() || !newNoteContent.trim()) return;
    const created: NoteItem = {
      id: `note-${Date.now()}`,
      title: newNoteTitle.trim(),
      content: newNoteContent.trim(),
      category: newNoteCat,
      subcategory: (newNoteCat === 'soft' ? 'THINKING' : 'TOOLS') as
        | SoftSubcategory
        | HardSubcategory,
      updatedAt: 'Oct 19, 2026 · Just now',
      linkedSourceId: selectedSource?.id,
    };
    onAddNote(created);
    setNewNoteTitle('');
    setNewNoteContent('');
  };

  return (
    <div className="absolute inset-4 z-30 rounded-2xl border border-cyan-400/50 bg-[#051120]/92 backdrop-blur-xl shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden">
      {/* Drawer Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/25 bg-[#07172b]/90">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            {activeNav === 'Library' && <BookOpen className="w-4 h-4" />}
            {activeNav === 'Search' && <Search className="w-4 h-4" />}
            {activeNav === 'Notes' && <StickyNote className="w-4 h-4" />}
            {activeNav === 'Collections' && <Folder className="w-4 h-4" />}
            {activeNav === 'Settings' && <Settings className="w-4 h-4" />}
          </div>
          <div>
            <h2 className="font-display text-xl font-bold tracking-wider text-white uppercase">
              JARVIS {activeNav}
            </h2>
            <p className="text-xs text-slate-400">
              {activeNav === 'Library' &&
                'Manage Soft Skills & Hard Skills shelf materials and active sources'}
              {activeNav === 'Search' &&
                'Deep full-text indexing across all mounted PDFs, Books, Notes & Courses'}
              {activeNav === 'Notes' &&
                'Capture research insights and convert notes directly into shelf sources'}
              {activeNav === 'Collections' &&
                'Curated cross-disciplinary research bundles ready for instant shelf mounting'}
              {activeNav === 'Settings' &&
                'Configure JARVIS HUD parameters, voice synthesis, and ZIP export'}
            </p>
          </div>
        </div>

        <button
          onClick={onCloseToHome}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-cyan-400/40 bg-cyan-500/10 text-cyan-200 hover:bg-cyan-500/20 text-xs font-medium transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
          Return to 3D Archive Atrium
        </button>
      </div>

      {/* Drawer Content */}
      <div className="flex-1 p-6 overflow-y-auto">
        {activeNav === 'Library' && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {(['all', 'soft', 'hard'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setLibraryFilter(f)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      libraryFilter === f
                        ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-200'
                        : 'border border-cyan-500/20 bg-[#08192e] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f === 'all'
                      ? `All Shelf Materials (${materials.length})`
                      : f === 'soft'
                      ? `Soft Skills (${materials.filter((m) => m.category === 'soft').length})`
                      : `Hard Skills (${materials.filter((m) => m.category === 'hard').length})`}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onLoadAllPresets}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-400/50 bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 text-xs font-medium cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Load All 9 Demo Sources
                </button>
                {materials.length > 0 && (
                  <button
                    onClick={onResetEmptyShelves}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900/80 hover:bg-slate-800 text-slate-300 text-xs font-medium cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset Empty Shelves
                  </button>
                )}
                <button
                  onClick={() => onOpenAddModal('soft')}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Material
                </button>
              </div>
            </div>

            {filteredLibrary.length === 0 ? (
              <div className="p-10 rounded-2xl border border-dashed border-cyan-500/30 bg-[#071628]/60 text-center space-y-3">
                <p className="text-sm font-medium text-white">
                  No materials currently mounted on the shelves
                </p>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Load the curated 9-document JARVIS Research Archive or add your own PDF, Book, Web article, Note, or Course.
                </p>
                <div className="flex items-center justify-center gap-3 pt-2">
                  <button
                    onClick={onLoadAllPresets}
                    className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer"
                  >
                    Populate Soft & Hard Skills Shelves
                  </button>
                  <button
                    onClick={() => onOpenAddModal('soft')}
                    className="px-4 py-2 rounded-xl border border-cyan-400/50 bg-cyan-500/10 text-cyan-200 text-xs font-medium cursor-pointer"
                  >
                    + Add Custom Source
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {filteredLibrary.map((item) => {
                  const isSelected = selectedSource?.id === item.id;
                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                        isSelected
                          ? 'border-cyan-400 bg-cyan-500/15 shadow-[0_0_20px_rgba(34,211,238,0.2)]'
                          : 'border-cyan-500/25 bg-[#071629]/85 hover:border-cyan-400/50'
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-cyan-300">
                          <span>
                            {item.category === 'soft' ? 'SOFT SKILLS' : 'HARD SKILLS'} ·{' '}
                            {item.subcategory} · {item.type}
                          </span>
                          <span className="text-slate-400">{item.durationOrPages}</span>
                        </div>
                        <h3 className="text-sm font-semibold text-white">{item.title}</h3>
                        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                          {item.summary}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-cyan-500/15">
                        <span className="text-[11px] text-slate-400">{item.author}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onSpeakText(`${item.title}. ${item.summary}`)}
                            className="p-1.5 rounded-lg border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 cursor-pointer"
                            title="Read Summary Aloud"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onRemoveMaterial(item.id)}
                            className="p-1.5 rounded-lg border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 cursor-pointer"
                            title="Remove from Shelf"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              onSelectSource(item);
                              onCloseToHome();
                            }}
                            className="flex items-center gap-1 px-3 py-1 rounded-lg bg-cyan-500/25 border border-cyan-400/60 text-cyan-200 text-xs font-medium hover:bg-cyan-500/35 cursor-pointer"
                          >
                            {isSelected && <Check className="w-3.5 h-3.5" />}
                            {isSelected ? 'Selected' : 'Ask Source'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeNav === 'Search' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 text-cyan-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search across Soft Skills, Hard Skills, paragraphs, citations, or topics..."
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-cyan-400/50 bg-[#071527] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-300"
              />
            </div>

            {materials.length === 0 && (
              <div className="p-4 rounded-xl border border-cyan-500/25 bg-[#08192e] flex items-center justify-between">
                <span className="text-xs text-slate-300">
                  Your shelves are currently in the initial empty state. Load preset materials to test full-text search:
                </span>
                <button
                  onClick={onLoadAllPresets}
                  className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-semibold text-xs cursor-pointer"
                >
                  Load 9 Demo Materials
                </button>
              </div>
            )}

            <div className="space-y-3">
              {searchResults.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectSource(item);
                    onCloseToHome();
                  }}
                  className="p-4 rounded-xl border border-cyan-500/25 bg-[#071629]/90 hover:border-cyan-400 cursor-pointer transition-all space-y-1.5"
                >
                  <div className="flex items-center justify-between text-xs text-cyan-300">
                    <span>
                      {item.category.toUpperCase()} SKILLS · {item.subcategory} · {item.type}
                    </span>
                    <span>Click to inspect in Ask The Source →</span>
                  </div>
                  <h4 className="text-sm font-semibold text-white">{item.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{item.paragraphs[0]}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeNav === 'Notes' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <form onSubmit={handleSaveNote} className="lg:col-span-5 space-y-3 p-4 rounded-xl border border-cyan-500/25 bg-[#071628]">
              <h3 className="text-sm font-semibold text-cyan-200">Create New Research Note</h3>
              <input
                type="text"
                required
                value={newNoteTitle}
                onChange={(e) => setNewNoteTitle(e.target.value)}
                placeholder="Note title..."
                className="w-full px-3 py-2 rounded-lg border border-cyan-500/30 bg-[#05101e] text-xs text-white focus:outline-none focus:border-cyan-400"
              />
              <select
                value={newNoteCat}
                onChange={(e) => setNewNoteCat(e.target.value as SkillCategory)}
                className="w-full px-3 py-2 rounded-lg border border-cyan-500/30 bg-[#05101e] text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="soft">Soft Skills Note</option>
                <option value="hard">Hard Skills Note</option>
              </select>
              <textarea
                rows={5}
                required
                value={newNoteContent}
                onChange={(e) => setNewNoteContent(e.target.value)}
                placeholder="Write synthesis notes, action items, or excerpts..."
                className="w-full px-3 py-2 rounded-lg border border-cyan-500/30 bg-[#05101e] text-xs text-white focus:outline-none focus:border-cyan-400 leading-relaxed"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer"
              >
                Save Research Note
              </button>
            </form>

            <div className="lg:col-span-7 space-y-3">
              {notes.map((n) => (
                <div
                  key={n.id}
                  className="p-4 rounded-xl border border-cyan-500/25 bg-[#071628]/90 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-cyan-300 font-medium">
                      {n.category.toUpperCase()} SKILLS · {n.subcategory} · {n.updatedAt}
                    </span>
                    <button
                      onClick={() => onDeleteNote(n.id)}
                      className="text-slate-400 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <h4 className="text-sm font-semibold text-white">{n.title}</h4>
                  <p className="text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                    {n.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeNav === 'Collections' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {collections.map((col) => (
              <div
                key={col.id}
                className="p-5 rounded-xl border border-cyan-500/30 bg-[#071629] flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="text-[11px] text-cyan-300 uppercase tracking-wider">
                    {col.category} Collection · {col.materialIds.length} Sources
                  </div>
                  <h3 className="text-base font-bold text-white">{col.name}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{col.description}</p>
                </div>
                <button
                  onClick={() => {
                    onLoadCollection(col);
                    onCloseToHome();
                  }}
                  className="w-full py-2 rounded-lg bg-cyan-500/20 border border-cyan-400/60 text-cyan-200 hover:bg-cyan-500/30 text-xs font-semibold cursor-pointer transition-colors"
                >
                  Mount Collection to 3D Shelves
                </button>
              </div>
            ))}
          </div>
        )}

        {activeNav === 'Settings' && (
          <div className="max-w-xl space-y-4">
            <div className="p-4 rounded-xl border border-cyan-500/25 bg-[#071628] flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-white">JARVIS Core Network Status</div>
                <div className="text-xs text-slate-400">
                  Toggle between Offline Local Archive and Online Live Synthesis
                </div>
              </div>
              <button
                onClick={onToggleOnline}
                className={`px-4 py-2 rounded-lg text-xs font-semibold border cursor-pointer ${
                  isOnline
                    ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300'
                    : 'border-cyan-400 bg-cyan-500/20 text-cyan-200'
                }`}
              >
                {isOnline ? 'ONLINE · ACTIVE' : 'OFFLINE · LOCAL'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-cyan-500/25 bg-[#071628] flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-white">
                  3D Atrium Smart Glass Cleaning
                </div>
                <div className="text-xs text-slate-400">
                  Automatically cleans static baked-in text behind the 3D shelves
                </div>
              </div>
              <button
                onClick={onToggleCleanBackdrop}
                className="px-4 py-2 rounded-lg text-xs font-semibold border border-cyan-400/50 bg-cyan-500/15 text-cyan-200 cursor-pointer"
              >
                {cleanBackdrop ? 'Enabled (Clean 3D Glass)' : 'Raw Original Image'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-cyan-400/50 bg-gradient-to-r from-cyan-500/15 to-blue-600/10 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold text-white">
                  Skill Library .ZIP
                </div>
                <div className="text-xs text-slate-300">
                  Shelf catalog, book.json per title, every chapter as markdown with its licence and attribution line
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => downloadCompleteProjectZip()}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs cursor-pointer shadow-[0_0_16px_rgba(34,211,238,0.4)]"
                >
                  <Download className="w-4 h-4" />
                  Download Library .ZIP
                </button>
                <button
                  onClick={onOpenExportModal}
                  className="px-3 py-2 rounded-lg border border-cyan-400/50 bg-cyan-500/15 text-cyan-200 hover:bg-cyan-500/25 text-xs font-medium cursor-pointer"
                >
                  Python / JS Bridge Code
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
