These files were salvaged from D:\jarvis 1.0.5 before deleting that old copy.
They are an older/experimental build (Kokoro offline TTS + Tavily search).
The current master uses edge-tts (podcast_engine.py, port 7781) + Firecrawl instead.
Kept only for reference - not wired into jarvis-2.0.
