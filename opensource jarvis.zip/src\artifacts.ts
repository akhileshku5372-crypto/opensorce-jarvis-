/* ══════════════════════════════════════════════════════════════════════════
 * KamiSensei Artifact Engine — strict schemas, prompt builders, validation
 * ───────────────────────────────────────────────────────────────────────────
 * Pure functions only (no Hono / network imports) so the exact same module
 * is used by the edge runtime and by offline unit tests. Every artifact is
 * a strictly typed JSON object; nothing renders arbitrary LLM prose.
 * ══════════════════════════════════════════════════════════════════════════ */

export type ArtifactType = 'note' | 'mind_map' | 'report' | 'flashcard_set' | 'quiz' | 'data_table' | 'study_guide' | 'briefing_doc' | 'faq' | 'timeline'

export const ARTIFACT_TYPES: ArtifactType[] = [
  'note', 'mind_map', 'report', 'flashcard_set', 'quiz', 'data_table',
  'study_guide', 'briefing_doc', 'faq', 'timeline'
]

export const ARTIFACT_LABELS: Record<ArtifactType, string> = {
  note: 'Notes',
  mind_map: 'Mind Map',
  report: 'Reports',
  flashcard_set: 'Flashcards',
  quiz: 'Quiz',
  data_table: 'Data Table',
  study_guide: 'Study Guide',
  briefing_doc: 'Briefing Doc',
  faq: 'FAQ',
  timeline: 'Timeline'
}

export const ARTIFACT_DEFAULTS: Record<ArtifactType, string> = {
  note: 'Essential JLPT N4 grammar points and vocabulary from the selected sources',
  mind_map: 'Japanese particles and their core functions',
  report: 'Japanese language mastery progress and study recommendations',
  flashcard_set: 'High-frequency JLPT vocabulary and phrases',
  quiz: 'Japanese grammar and vocabulary assessment',
  data_table: 'Japanese particles and verb conjugation patterns',
  study_guide: 'A comprehensive study guide covering the selected lesson material',
  briefing_doc: 'A structured briefing document on the selected topic',
  faq: 'Frequently asked questions about the selected material',
  timeline: 'A chronological timeline of the key events in the selected material'
}

/* ── Dynamic generation contract ─────────────────────────────────────── */

export interface ArtifactGenOptions {
  requestedCount?: number
  requestedDifficulty?: string
  requestedLanguage?: string
  requestedDepth?: string
}

export const FLASHCARD_CEILING = 150
export const FLASHCARD_BATCH_SIZE = 30
export const FLASHCARD_DEFAULT_COUNT = 12
export const QUIZ_CEILING = 50
export const QUIZ_BATCH_SIZE = 15
export const QUIZ_DEFAULT_COUNT = 10
export const MINDMAP_DEFAULT_NODES = 12

/** Depth slider → allowed node hierarchy tiers (Brief=2, Detailed=3-4, Complete=exhaustive). */
export function mindMapDepthLimit(depth?: string): number {
  const key = String(depth || '').toLowerCase()
  if (key.startsWith('bri')) return 2
  if (key.startsWith('com') || key.startsWith('exh')) return Number.POSITIVE_INFINITY
  return 4
}

export function clampRequestedCount(raw: unknown, fallback: number, ceiling: number): number {
  const n = Math.floor(Number(raw))
  if (!Number.isFinite(n)) return fallback
  return Math.min(Math.max(n, 1), ceiling)
}

/** Case-fold + strip punctuation + collapse whitespace for dedup comparisons. */
export function normalizeLabel(value: unknown): string {
  return String(value ?? '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N} ]/gu, '')
    .replace(/\s+/g, ' ')
    .trim()
}

let idSeed = 0
function uniqueId(prefix: string): string {
  idSeed = (idSeed + 1) % 0xffff
  const stamp = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6)
  return `${prefix}-${stamp}-${idSeed.toString(36)}`
}

/* ── Strict TypeScript interfaces ───────────────────────────────────────── */

export interface NoteSection { title: string; body: string }
export interface NoteArtifact {
  type: 'note'
  title: string
  summary: string
  sections: NoteSection[]
  keyPoints: string[]
  examples: Array<string | { japanese?: string; romaji?: string; english?: string }>
  sources: string[]
}

export interface SourceReference { source: string; page: number | null; snippet: string }
export type MindMapNodeType = 'root' | 'topic' | 'subtopic' | 'concept' | 'rule' | 'example' | 'definition' | 'reference'

export interface MindMapRootNode {
  id: string
  label: string
  description?: string
  type?: MindMapNodeType
  sourceReferences?: SourceReference[]
  children?: MindMapRootNode[]
}

export interface MindMapNode { id: string; label: string; description?: string; parentId?: string | null; type?: MindMapNodeType; sourceReferences?: SourceReference[] }
export interface MindMapArtifact {
  type: 'mind_map'
  title: string
  nodes: MindMapNode[]
}

export interface ReportSection { title: string; body: string }
export interface ReportArtifact {
  type: 'report'
  title: string
  summary: string
  sections: ReportSection[]
  keyFindings: string[]
  examples: string[]
  conclusions: string[]
  sources: string[]
}

export interface Flashcard { front: string; back: string; explanation?: string; example?: string; source?: string; page?: number | null }
export interface FlashcardSetArtifact {
  type: 'flashcard_set'
  title: string
  cards: Flashcard[]
}

export interface QuizQuestion { question: string; options: string[]; correctAnswer: number | string; explanation: string; source?: string; page?: number | null }
export interface QuizArtifact {
  type: 'quiz'
  title: string
  questions: QuizQuestion[]
}

export interface DataTableArtifact {
  type: 'data_table'
  title: string
  columns: string[]
  rows: (string | number)[][]
  sources: string[]
}

export interface StudyGuideSection { title: string; body: string }
export interface KeyTerm { term: string; definition: string }
export interface StudyGuideArtifact {
  type: 'study_guide'
  title: string
  overview: string
  sections: StudyGuideSection[]
  keyTerms: KeyTerm[]
  practicePrompts: Array<{ question: string; answer: string }>
  sources: string[]
}

export interface BriefingDocArtifact {
  type: 'briefing_doc'
  title: string
  overview: string
  background: Array<{ title: string; body: string }>
  keyDetails: string[]
  actionItems: string[]
  sources: string[]
}

export interface FaqEntry { question: string; answer: string; source?: string; page?: number | null }
export interface FaqArtifact {
  type: 'faq'
  title: string
  questions: FaqEntry[]
  sources: string[]
}

export interface TimelineEvent { date: string; title: string; description: string; source?: string; page?: number | null }
export interface TimelineArtifact {
  type: 'timeline'
  title: string
  events: TimelineEvent[]
  sources: string[]
}

export type ArtifactData =
  | NoteArtifact
  | MindMapArtifact
  | ReportArtifact
  | FlashcardSetArtifact
  | QuizArtifact
  | DataTableArtifact
  | StudyGuideArtifact
  | BriefingDocArtifact
  | FaqArtifact
  | TimelineArtifact

/* ── Small type guards ──────────────────────────────────────────────────── */

function isString(v: unknown): v is string {
  return typeof v === 'string' && v.trim().length > 0
}
function isStrArr(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((n) => isString(n))
}

/* ── JSON extraction (robust against code fences / prose around JSON) ───── */

export function extractJson(raw: string): unknown {
  if (!raw) return null
  let text = raw.trim()
  text = text.replace(/```(?:json)?/gi, '').replace(/```/g, '').trim()
  try {
    return JSON.parse(text)
  } catch (err) {
    console.debug('[KS] Artifact output was not plain JSON; scanning for an embedded object.')
  }

  for (const open of ['{', '['] as const) {
    const close = open === '{' ? '}' : ']'
    const start = text.indexOf(open)
    if (start === -1) continue
    let depth = 0
    let inStr = false
    let esc = false
    for (let i = start; i < text.length; i++) {
      const ch = text[i]
      if (inStr) {
        if (esc) esc = false
        else if (ch === '\\') esc = true
        else if (ch === '"') inStr = false
        continue
      }
      if (ch === '"') { inStr = true; continue }
      if (ch === open) depth++
      else if (ch === close) {
        depth--
        if (depth === 0) {
          try { return JSON.parse(text.slice(start, i + 1)) } catch { break }
        }
      }
    }
  }
  return null
}

/* ── Schema validation (returns collected errors, never throws) ─────────── */

export function validateArtifact(type: ArtifactType, data: unknown): ValidationResult {
  const errors: string[] = []
  if (!data || typeof data !== 'object') {
    return { ok: false, errors: ['Artifact is not a JSON object.'] }
  }
  const obj = data as Record<string, unknown>
  const t = obj.type as string
  if (!t || t !== type) errors.push(`Field "type" must equal "${type}" (got ${JSON.stringify(t) ?? 'missing'}).`)
  if (!isString(obj.title)) errors.push('Field "title" is required and must be a non-empty string.')

  switch (type) {
    case 'note': {
      if (!isString(obj.summary)) errors.push('Field "summary" is required.')
      if (!Array.isArray(obj.sections) || obj.sections.length === 0) {
        errors.push('Field "sections[]" is required with at least one section.')
      } else {
        obj.sections.forEach((s, i) => {
          if (!s || typeof s !== 'object' || !isString((s as NoteSection).title) || !isString((s as NoteSection).body)) {
            errors.push(`sections[${i}] must be an object with non-empty "title" and "body".`)
          }
        })
      }
      if (!isStrArr(obj.keyPoints)) errors.push('Field "keyPoints[]" must be a non-empty array of strings.')
      if (!Array.isArray(obj.examples)) errors.push('Field "examples[]" is required (may be empty).')
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
    case 'mind_map': {
      const nodes = obj.nodes
      if (!Array.isArray(nodes) || nodes.length === 0) {
        errors.push('Field "nodes[]" is required with at least one node.')
      } else {
        nodes.forEach((n, i) => {
          if (!n || typeof n !== 'object' || !isString((n as MindMapNode).id) || !isString((n as MindMapNode).label)) {
            errors.push(`nodes[${i}] must be an object with non-empty "id" and "label".`)
          } else {
            const node = n as MindMapNode
            if (node.parentId != null && typeof node.parentId !== 'string') {
              errors.push(`nodes[${i}].parentId must be a string or null.`)
            }
          }
        })
      }
      break
    }
    case 'report': {
      if (!isString(obj.summary)) errors.push('Field "summary" is required.')
      if (!Array.isArray(obj.sections) || obj.sections.length === 0) {
        errors.push('Field "sections[]" is required with at least one section.')
      } else {
        obj.sections.forEach((s, i) => {
          if (!s || typeof s !== 'object' || !isString((s as ReportSection).title) || !isString((s as ReportSection).body)) {
            errors.push(`sections[${i}] must be an object with non-empty "title" and "body".`)
          }
        })
      }
      if (!isStrArr(obj.keyFindings)) errors.push('Field "keyFindings[]" must be a non-empty array of strings.')
      if (!Array.isArray(obj.examples)) errors.push('Field "examples[]" is required (may be empty).')
      if (!isStrArr(obj.conclusions)) errors.push('Field "conclusions[]" must be a non-empty array of strings.')
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
case 'flashcard_set': {
      const cards = obj.cards
      if (!Array.isArray(cards) || cards.length === 0) {
        errors.push('Field "cards[]" is required with at least one card.')
      } else {
        cards.forEach((cd, i) => {
          if (!cd || typeof cd !== 'object' || !isString((cd as Flashcard).front) || !isString((cd as Flashcard).back)) {
            errors.push(`cards[${i}] must be an object with non-empty "front" and "back".`)
          } else {
            const page = (cd as Flashcard).page
            if (page != null && (!Number.isInteger(page) || page < 1)) errors.push(`cards[${i}].page must be a positive integer or null.`)
          }
        })
      }
      break
    }
    case 'quiz': {
      const qs = obj.questions
      if (!Array.isArray(qs) || qs.length === 0) {
        errors.push('Field "questions[]" is required with at least one question.')
      } else {
        qs.forEach((q, i) => {
          if (!q || typeof q !== 'object' || !isString((q as QuizQuestion).question)) {
            errors.push(`questions[${i}] must be an object with a non-empty "question".`)
            return
          }
          const qq = q as QuizQuestion
          if (!Array.isArray(qq.options) || qq.options.length < 2) {
            errors.push(`questions[${i}].options must be an array of at least 2 strings.`)
          } else {
            qq.options.forEach((o, j) => { if (!isString(o)) errors.push(`questions[${i}].options[${j}] must be a string.`) })
          }
          const correct = qq.correctAnswer
          if (typeof correct === 'number') {
            if (correct < 0 || correct >= (qq.options?.length ?? 0)) errors.push(`questions[${i}].correctAnswer (${correct}) is out of range.`)
          } else if (!isString(correct)) {
            errors.push(`questions[${i}].correctAnswer must be a numeric option index or the correct option string.`)
          } else if (Array.isArray(qq.options) && !qq.options.includes(correct)) {
            errors.push(`questions[${i}].correctAnswer must match one of the options.`)
          }
          if (!isString(qq.explanation)) errors.push(`questions[${i}].explanation is required.`)
          if (qq.page != null && (!Number.isInteger(qq.page) || qq.page < 1)) errors.push(`questions[${i}].page must be a positive integer or null.`)
        })
      }
      break
    }
    case 'data_table': {
      if (!isStrArr(obj.columns) || obj.columns.length === 0) errors.push('Field "columns[]" must be a non-empty array of strings.')
      const rows = obj.rows
      if (!Array.isArray(rows) || rows.length === 0) {
        errors.push('Field "rows[]" is required with at least one row.')
      } else {
        rows.forEach((r, i) => {
          if (!Array.isArray(r) || r.length === 0) {
            errors.push(`rows[${i}] must be a non-empty array.`)
            return
          }
          r.forEach((cell, j) => {
            if (typeof cell !== 'string' && typeof cell !== 'number') {
              errors.push(`rows[${i}] cell at column ${j} must be a string or number.`)
            }
          })
        })
      }
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
    case 'study_guide': {
      if (!isString(obj.overview)) errors.push('Field "overview" is required.')
      if (!Array.isArray(obj.sections) || obj.sections.length === 0) {
        errors.push('Field "sections[]" is required with at least one section.')
      } else {
        obj.sections.forEach((s, i) => {
          if (!s || typeof s !== 'object' || !isString((s as StudyGuideSection).title) || !isString((s as StudyGuideSection).body)) {
            errors.push(`sections[${i}] must be an object with non-empty "title" and "body".`)
          }
        })
      }
      if (!Array.isArray(obj.keyTerms)) errors.push('Field "keyTerms[]" is required (may be empty).')
      else {
        obj.keyTerms.forEach((k, i) => {
          if (!k || typeof k !== 'object' || !isString((k as KeyTerm).term) || !isString((k as KeyTerm).definition)) {
            errors.push(`keyTerms[${i}] must be an object with non-empty "term" and "definition".`)
          }
        })
      }
      if (!Array.isArray(obj.practicePrompts)) errors.push('Field "practicePrompts[]" is required (may be empty).')
      else {
        obj.practicePrompts.forEach((p, i) => {
          if (!p || typeof p !== 'object' || !isString((p as { question: string }).question) || !isString((p as { answer: string }).answer)) {
            errors.push(`practicePrompts[${i}] must be an object with non-empty "question" and "answer".`)
          }
        })
      }
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
    case 'briefing_doc': {
      if (!isString(obj.overview)) errors.push('Field "overview" is required.')
      if (!Array.isArray(obj.background) || obj.background.length === 0) {
        errors.push('Field "background[]" is required with at least one section.')
      } else {
        obj.background.forEach((s, i) => {
          if (!s || typeof s !== 'object' || !isString((s as { title: string }).title) || !isString((s as { body: string }).body)) {
            errors.push(`background[${i}] must be an object with non-empty "title" and "body".`)
          }
        })
      }
      if (!isStrArr(obj.keyDetails)) errors.push('Field "keyDetails[]" must be a non-empty array of strings.')
      if (!Array.isArray(obj.actionItems)) errors.push('Field "actionItems[]" is required (may be empty).')
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
    case 'faq': {
      const qs = obj.questions
      if (!Array.isArray(qs) || qs.length === 0) {
        errors.push('Field "questions[]" is required with at least one question.')
      } else {
        qs.forEach((q, i) => {
          if (!q || typeof q !== 'object' || !isString((q as FaqEntry).question) || !isString((q as FaqEntry).answer)) {
            errors.push(`questions[${i}] must be an object with non-empty "question" and "answer".`)
            return
          }
          const page = (q as FaqEntry).page
          if (page != null && (!Number.isInteger(page) || page < 1)) errors.push(`questions[${i}].page must be a positive integer or null.`)
        })
      }
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
    case 'timeline': {
      const evs = obj.events
      if (!Array.isArray(evs) || evs.length === 0) {
        errors.push('Field "events[]" is required with at least one event.')
      } else {
        evs.forEach((e, i) => {
          if (!e || typeof e !== 'object' || !isString((e as TimelineEvent).date) || !isString((e as TimelineEvent).title) || !isString((e as TimelineEvent).description)) {
            errors.push(`events[${i}] must be an object with non-empty "date", "title" and "description".`)
            return
          }
          const page = (e as TimelineEvent).page
          if (page != null && (!Number.isInteger(page) || page < 1)) errors.push(`events[${i}].page must be a positive integer or null.`)
        })
      }
      if (!isStrArr(obj.sources)) errors.push('Field "sources[]" must be an array of strings (may be empty).')
      break
    }
  }

  if (errors.length) return { ok: false, errors }
  return { ok: true, data: data as ArtifactData }
}

/* ── Artifact-specific generation prompts (Groq brain) ──────────────────── */

const RAG_GUARD =
  'Base ALL content strictly on the CURRENT DOCUMENT CONTEXT below. If the context cannot answer a point, say so explicitly rather than inventing facts. Use the exact file names given in the context when citing sources. Treat the user-provided instruction as the active topic.'

function contextBlock(context: string, sourceIds: string[]): string {
  const scope = (sourceIds && sourceIds.length)
    ? '\nAllowed source scope: ' + sourceIds.join(', ')
    : '\nSource scope: ALL indexed sources.'
  if (context && context.trim()) return context + scope
  return '\n\nERROR: No source chunks were retrieved or verified. Do not invent artifact content; generation must stop until indexed source context is available.' + scope
}

const SCHEMA_MAP: Record<string, string> = {
  note: '{ "type": "note", "title": string, "summary": string,\n  "sections": [ { "title": string, "body": string } ],\n  "keyPoints": [ string ], "examples": [ string | { "japanese": string, "romaji": string, "english": string } ],\n  "sources": [ string ] }',
mind_map: '{ "type": "mind_map", "title": string,\n  "root": { "id": string, "label": string, "description": string, "type": "root", "children": [ { "id": string, "label": string, "description": string, "type": "topic|subtopic|concept|rule|example|definition|reference", "children": [], "sourceReferences": [ { "source": string, "page": number|null, "snippet": string } ] } ] } }',
  report: '{ "type": "report", "title": string, "summary": string,\n  "sections": [ { "title": string, "body": string } ],\n  "keyFindings": [ string ], "examples": [ string ],\n  "conclusions": [ string ], "sources": [ string ] }',
  flashcard_set: '{ "type": "flashcard_set", "title": string,\n  "cards": [ { "front": string, "back": string, "explanation": string, "example": string, "source": string, "page": number | null } ] }',
  quiz: '{ "type": "quiz", "title": string,\n  "questions": [ { "question": string, "options": [ 4 strings ], "correctAnswer": number (index into options), "explanation": string, "source": string, "page": number | null } ] }',
  data_table: '{ "type": "data_table", "title": string,\n  "columns": [ string ], "rows": [ [ string | number ] ], "sources": [ string ] }',
  study_guide: '{ "type": "study_guide", "title": string, "overview": string,\n  "sections": [ { "title": string, "body": string } ],\n  "keyTerms": [ { "term": string, "definition": string } ],\n  "practicePrompts": [ { "question": string, "answer": string } ], "sources": [ string ] }',
  briefing_doc: '{ "type": "briefing_doc", "title": string, "overview": string,\n  "background": [ { "title": string, "body": string } ],\n  "keyDetails": [ string ], "actionItems": [ string ], "sources": [ string ] }',
  faq: '{ "type": "faq", "title": string,\n  "questions": [ { "question": string, "answer": string, "source": string, "page": number | null } ],\n  "sources": [ string ] }',
  timeline: '{ "type": "timeline", "title": string,\n  "events": [ { "date": string, "title": string, "description": string, "source": string, "page": number | null } ],\n  "sources": [ string ] }'

}

const GUIDANCE_MAP: Record<string, string> = {
  note: 'Create concise educational study notes: a clear title, an overall summary, themed sections with readable bodies, 4-8 key points, and 3-6 examples. For Japanese learning content, make examples objects with "japanese" (native script), "romaji", and "english" fields.',
  mind_map: 'Build a source-grounded educational knowledge graph from REAL Japanese lesson content: root = the exact requested lesson/topic (e.g. "Minna no Nihongo Lesson 1 Grammar Rules"), main branches = the actual sentence patterns and particles in the context (e.g. "\u301c\u306f \u301c\u3067\u3059 (wa...desu)", "\u301c\u3058\u3083\u3042\u308a\u307e\u305b\u3093 (ja arimasen)", "\u301c\u3082 (mo)", "\u301c\u306e (no)"), leaves = short real example sentences from the context with a one-line Hinglish/English explanation. NEVER create meta-level or file-statistics nodes (pages, page counts, study pages, workbook, language medium, PDF/document info, extraction stats, word counts) \u2014 such nodes are invalid and will be dropped. Attach sourceReferences wherever the source backs a node. Node count follows the source content \u2014 no fixed limits. Use duplicate-free unique identifiers.',
  report: 'Write a professional structured report: an executive summary, 3-6 titled sections with body text, 4-8 key findings, 2-5 examples, 3-5 conclusions, and the list of sources actually used.',
  flashcard_set: 'Create 6-12 memorization flashcards. Front holds the term (Japanese in native script for language content), back holds meaning/reading. Add explanation, example sentence, the exact source file name, and its real page number when page metadata is present; otherwise use null.',
  quiz: 'Create 5-8 assessment questions. Each question has exactly 4 options and "correctAnswer" as the zero-based index of the right option. Explain every answer (Hinglish/English mix is fine). Include the exact source file and real page number when available; otherwise use null.',
  data_table: 'Create a normalized data table with 6-15 rows. Include Source and Page columns whenever that metadata exists in context. Rows are arrays exactly aligned to columns. Only string or number cell values; use an empty string rather than inventing a page.',
  study_guide: 'Create a NotebookLM-style study guide: an "overview" paragraph, 4-8 titled "sections" with real body text extracted from the source, 6-12 "keyTerms" (term + concise definition, Japanese in native script for language content with romaji + meaning), and 4-8 "practicePrompts" (a practice question with its model answer). Cite the exact source file names used.',
  briefing_doc: 'Create a NotebookLM-style briefing doc: an "overview" executive summary, 3-6 "background" sections with titled body text, 4-8 concrete "keyDetails", and 2-6 suggested "actionItems" (next steps a learner/analyst could take). Ground everything strictly in the source context and list source file names.',
  faq: 'Create a source-grounded FAQ: a title and 5-10 questions with clear, accurate "answer" text drawn only from the context. Include the exact source file and real page number where available; otherwise use null. Keep each Q&A readable and practical.',
  timeline: 'Create a chronology of the key events/stages/lessons in the source: a title and an ordered "events[]" list. Each event has a "date" (a real period/lesson/label from the source, e.g. "Lesson 1", "Chapter 3", "Pre-War", "Week 2"), a short "title", a concise "description", and the exact source file + real page where available; otherwise use null. Order events chronologically.'
}

function contractLines(opts: ArtifactGenOptions): string {
  const lines: string[] = []
  if (opts.requestedCount) lines.push(`Requested item count: ${opts.requestedCount}`)
  if (opts.requestedDifficulty) lines.push(`Difficulty level: ${opts.requestedDifficulty}`)
  if (opts.requestedLanguage) lines.push(`Language: ${opts.requestedLanguage}`)
  if (opts.requestedDepth) lines.push(`Depth preference: ${opts.requestedDepth}`)
  return lines.length ? 'User options:\n' + lines.map((l) => '• ' + l).join('\n') : ''
}

export function buildArtifactPrompt(
  type: ArtifactType,
  topic: string,
  context: string,
  sourceIds: string[],
  opts: ArtifactGenOptions = {}
): string {
  const ctx = contextBlock(context, sourceIds)
  const label = type.toUpperCase().replace('_', ' ')
  return `You are the KamiSensei Artifact Engine inside JARVIS. Generate a ${label} artifact for the topic: "${topic}".

${RAG_GUARD}

Return ONLY valid JSON (no markdown fences, no commentary) matching this exact schema:
${SCHEMA_MAP[type]}

Generation guidance: ${GUIDANCE_MAP[type]}
Give every item a short unique id where the schema requires one.
${contractLines(opts)}

${ctx}`
}


export function buildRepairPrompt(
  type: ArtifactType,
  topic: string,
  previousOutput: string,
  errors: string[],
  context = ''
): string {
  return `Your previous JSON artifact failed validation for type "${type}". Topic: "${topic}".

The extracted JSON was:
${previousOutput.slice(0, 2000)}

Validation failed with these errors:
${errors.map((e, i) => `${i + 1}. ${e}`).join('\n')}

Return ONLY a corrected JSON object matching this exact schema:
${SCHEMA_MAP[type]}
Do not explain. No markdown fences. Preserve only facts and source/page metadata present in the verified context below; never invent citations.

${context.slice(0, 12000)}`
}

/* ── Strict nested mind-map tree validation ─────────────────────────────── */

export function validateMindMapTree(parsed: unknown): string[] {
  const errors: string[] = []
  if (!parsed || typeof parsed !== 'object') { errors.push('Mind map output is not a JSON object.'); return errors }
  const obj = parsed as Record<string, unknown>
  if (!isString(obj.title)) errors.push('Field "title" (non-empty string) is required.')
  const root = obj.root
  if (!root || typeof root !== 'object') { errors.push('Field "root" (object) is required.'); return errors }
  const visit = (node: MindMapRootNode, path: string, isRoot: boolean) => {
    if (!isString(node.id)) errors.push(`${path}.id must be a non-empty string.`)
    if (!isString(node.label)) errors.push(`${path}.label must be a non-empty string.`)
    if (!isRoot && !isString(node.description)) errors.push(`${path}.description must be a string (1-2 sentences).`)
    if (node.children != null && !Array.isArray(node.children)) errors.push(`${path}.children must be an array.`)
    if (node.sourceReferences != null && !Array.isArray(node.sourceReferences)) {
      errors.push(`${path}.sourceReferences must be an array.`)
    }
    ;(Array.isArray(node.children) ? node.children : []).forEach((child, i) => {
      if (!child || typeof child !== 'object') errors.push(`${path}.children[${i}] must be an object.`)
      else visit(child as MindMapRootNode, `${path}.children[${i}]`, false)
    })
  }
  visit(root as MindMapRootNode, 'root', true)
  return errors
}

/* Deterministic meta-level / file-statistics NOISE BAN. Labels like
 * "212 Study Pages Workbook" or "English Language Medium" describe the source
 * file, never the lesson content inside it \u2014 they are never allowed as nodes.
 * Mirrored in the browser renderer so stale persisted artifacts are also
 * cleaned before drawing. */
const META_LABEL_RE = /(study pages?|workbook|language medium|page count|book (length|size|info)|pdf|file (size|info|length)|document (info|length|stats?)|table of contents|extraction|ocr|scanned|word count|\d+\s*(pages?|sections?|chapters?|paragraphs?))/i
export function isMetaLabel(value: unknown): boolean {
  const s = String(value ?? '').toLowerCase().trim()
  if (!s) return false
  return META_LABEL_RE.test(s)
}

/* ── Dynamic generative CARD SCHEME (mind-map schema v2) ──────────────────
 * The MODEL — never a template — decides the categorical taxonomy from the
 * uploaded book's domain and the user's explicit request. Language, history,
 * coding and math notebooks are all first-class. Fixed category strings
 * ("Grammar Keys", "Core Particles", numbered slots) are banned. */

export const MINDMAP_THEME_COLORS = ['pink', 'purple', 'teal', 'green', 'orange', 'amber'] as const
export type MindMapThemeColor = (typeof MINDMAP_THEME_COLORS)[number]

export const MINDMAP_ICON_TYPES = ['grammar', 'settings', 'group', 'list', 'checklist', 'default'] as const
export type MindMapIconType = (typeof MINDMAP_ICON_TYPES)[number]

export interface MindMapBullet { text: string; hasCheckbox?: boolean }
export interface MindMapCard {
  id: string
  headerTitle: string
  themeColor?: MindMapThemeColor
  iconType?: MindMapIconType
  bulletPoints: MindMapBullet[]
}
export interface MindMapCardsArtifact {
  title: string
  cards: MindMapCard[]
}

/** Strict contract validation for the generative card schema. */
export function validateMindMapCards(parsed: unknown): string[] {
  const errors: string[] = []
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    errors.push('Mind map cards output is not a JSON object.')
    return errors
  }
  const obj = parsed as Record<string, unknown>
  if (!isString(obj.title)) errors.push('Field "title" (non-empty string) is required.')
  if (!Array.isArray(obj.cards) || !obj.cards.length) {
    errors.push('Field "cards" must be a non-empty array.')
    return errors
  }
  ;(obj.cards as unknown[]).forEach((rawCard, i) => {
    const path = `cards[${i}]`
    if (!rawCard || typeof rawCard !== 'object' || Array.isArray(rawCard)) {
      errors.push(`${path} must be an object.`)
      return
    }
    const card = rawCard as Record<string, unknown>
    if (!isString(card.id)) errors.push(`${path}.id must be a non-empty string.`)
    if (!isString(card.headerTitle)) errors.push(`${path}.headerTitle must be a non-empty string.`)
    if (card.themeColor != null && !(MINDMAP_THEME_COLORS as readonly string[]).includes(String(card.themeColor))) {
      errors.push(`${path}.themeColor must be one of: ${MINDMAP_THEME_COLORS.join(', ')}.`)
    }
    if (card.iconType != null && !(MINDMAP_ICON_TYPES as readonly string[]).includes(String(card.iconType))) {
      errors.push(`${path}.iconType must be one of: ${MINDMAP_ICON_TYPES.join(', ')}.`)
    }
    if (!Array.isArray(card.bulletPoints) || !card.bulletPoints.length) {
      errors.push(`${path}.bulletPoints must be a non-empty array.`)
      return
    }
    ;(card.bulletPoints as unknown[]).forEach((bRaw, j) => {
      const bp = `cards[${i}].bulletPoints[${j}]`
      if (!bRaw || typeof bRaw !== 'object' || Array.isArray(bRaw)) {
        errors.push(`${bp} must be an object with a "text" field.`)
        return
      }
      if (!isString((bRaw as Record<string, unknown>).text)) errors.push(`${bp}.text must be a non-empty string.`)
      const hc = (bRaw as Record<string, unknown>).hasCheckbox
      if (hc != null && typeof hc !== 'boolean') errors.push(`${bp}.hasCheckbox must be a boolean.`)
    })
  })
  return errors
}

/** Deterministic cleanup of a cards payload before persistence/rendering:
 * trim, meta/noise ban (isMetaLabel), within-card semantic bullet dedup,
 * themeColor/iconType clamped to the enums, unique card ids, sane size caps.
 * Never invents content — it only drops or normalizes what the model sent. */
export function normalizeMindMapCards(parsed: unknown, maxCards = 24, maxBulletsPerCard = 16): MindMapCardsArtifact | null {
  const obj = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
    ? parsed as Record<string, unknown>
    : null
  if (!obj) return null
  const title = String(obj.title ?? '').replace(/\s+/g, ' ').trim()
  if (!title || isMetaLabel(title)) return null

  const cards: MindMapCard[] = []
  const seenCardKeys = new Set<string>()
  const usedIds = new Set<string>()
  const rawCards = Array.isArray(obj.cards) ? obj.cards : []
  for (const rawCard of rawCards) {
    if (cards.length >= maxCards) break
    if (!rawCard || typeof rawCard !== 'object' || Array.isArray(rawCard)) continue
    const card = rawCard as Record<string, unknown>
    const headerTitle = String(card.headerTitle ?? '').replace(/\s+/g, ' ').trim()
    if (!headerTitle || isMetaLabel(headerTitle)) continue
    const key = normalizeLabel(headerTitle)
    if (key && seenCardKeys.has(key)) continue

    const bulletPoints: MindMapBullet[] = []
    const seenBullets = new Set<string>()
    const bulletsRaw = Array.isArray(card.bulletPoints) ? card.bulletPoints : []
    for (const bRaw of bulletsRaw) {
      if (bulletPoints.length >= maxBulletsPerCard) break
      const text = String(
        bRaw && typeof bRaw === 'object' && !Array.isArray(bRaw)
          ? (bRaw as Record<string, unknown>).text
          : bRaw ?? ''
      ).replace(/\s+/g, ' ').trim()
      if (!text || isMetaLabel(text)) continue
      const bKey = normalizeLabel(text)
      if (bKey && seenBullets.has(bKey)) continue
      seenBullets.add(bKey)
      const hasCheckbox = !!(bRaw && typeof bRaw === 'object' && (bRaw as Record<string, unknown>).hasCheckbox === true)
      bulletPoints.push(hasCheckbox ? { text, hasCheckbox: true } : { text })
    }
    if (!bulletPoints.length) continue

    if (key) seenCardKeys.add(key)
    const rawTheme = String(card.themeColor ?? '').toLowerCase()
    const themeColor: MindMapThemeColor = (MINDMAP_THEME_COLORS as readonly string[]).includes(rawTheme)
      ? rawTheme as MindMapThemeColor
      : MINDMAP_THEME_COLORS[cards.length % MINDMAP_THEME_COLORS.length]
    const rawIcon = String(card.iconType ?? '').toLowerCase()
    const iconType: MindMapIconType = (MINDMAP_ICON_TYPES as readonly string[]).includes(rawIcon)
      ? rawIcon as MindMapIconType
      : 'default'

    let id = String(card.id ?? '').trim().replace(/\s+/g, '_')
    if (!id) id = `card_${cards.length + 1}`
    let finalId = id
    let n = 2
    while (usedIds.has(finalId)) finalId = `${id}_${n++}`
    usedIds.add(finalId)

    cards.push({ id: finalId, headerTitle, themeColor, iconType, bulletPoints })
  }
  if (!cards.length) return null
  return { title, cards }
}

/* ── RAG deep-scan helpers (dense raw lesson-text extraction) ──────────────
 * The standard single-query semantic search tends to float intro/TOC/index
 * pages to the top. These helpers force raw lesson content: they extract the
 * concrete topic key phrases from the user's request, score every retrieved
 * chunk by real-content density (penalising boilerplate front/back matter),
 * and guarantee a dense minimum-character payload for the model context. */

const RAG_BOILERPLATE_RE = /^\s*(table of contents|contents\b|index\b|acknowledg|preface|foreword|about this (book|course)|how to use this (book|course))/i
const RAG_PAGE_NOISE_RE = /^\s*(page\s*)?\d{1,4}\s*$/i
const RAG_TOC_LEADER_RE = /\.{4,}\s*\d{1,4}\s*$/
const RAG_CJK_RE = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af]/

const RAG_STOPWORDS = new Set([
  'the', 'a', 'an', 'of', 'and', 'or', 'for', 'with', 'to', 'in', 'on', 'from',
  'all', 'about', 'create', 'make', 'generate', 'covering', 'please', 'using',
  'this', 'that', 'book', 'document', 'file', 'notebook', 'topic', 'content',
  'give', 'list', 'explain', 'full', 'complete', 'entire', 'whole'
])

/** Extract concrete target strings from the user's request: quoted spans,
 * lesson/chapter/unit patterns, non-ASCII runs (kana/kanji/hangul), and
 * significant ASCII words. These become the deep-scan queries AND the
 * chunk-ranking needles. */
export function extractTopicKeyPhrases(topic: string): string[] {
  const raw = String(topic || '')
  const phrases = new Set<string>()
  for (const m of raw.matchAll(/["'\u201c\u2018]([^"'\u201d\u2019]{2,60})["'\u201d\u2019]/g)) {
    phrases.add(m[1].trim())
  }
  for (const m of raw.matchAll(/\b((?:lesson|chapter|unit|section|part|kapitel|lektion)\s*\d{1,3}|chapter\s+[ivxlcdm]{1,6})\b/gi)) {
    phrases.add(m[1].trim())
  }
  for (const m of raw.matchAll(/[^\u0000-\u007f]{2,}/g)) {
    phrases.add(m[0].trim())
  }
  for (const m of raw.toLowerCase().matchAll(/[a-z][a-z'-]{2,}/g)) {
    if (!RAG_STOPWORDS.has(m[0])) phrases.add(m[0])
  }
  return [...phrases].slice(0, 10)
}

export interface RagChunkInput { text: string; source?: string; page?: number | null }

/** Relevance score for one retrieved chunk. High = dense raw lesson content
 * matching the topic; low/negative = boilerplate, TOC, index, page noise. */
export function scoreRagChunk(chunk: RagChunkInput, phrases: string[]): number {
  const text = String(chunk.text || '')
  if (!text.trim()) return -Infinity
  const lower = text.toLowerCase()
  let score = 0
  for (const p of phrases) {
    if (!p) continue
    const needle = p.toLowerCase()
    let hits = 0
    let idx = lower.indexOf(needle)
    while (idx >= 0 && hits < 4) { hits++; idx = lower.indexOf(needle, idx + needle.length) }
    score += hits * 3
  }
  const len = text.length
  if (len >= 200 && len <= 2400) score += 4
  else if (len > 2400) score += 2
  else if (len < 80) score -= 4
  if (RAG_CJK_RE.test(text)) score += 3
  if (RAG_BOILERPLATE_RE.test(text)) score -= 8
  if (RAG_PAGE_NOISE_RE.test(text)) score -= 8
  if (RAG_TOC_LEADER_RE.test(text)) score -= 6
  return score
}

/** Assemble the dense context payload: highest-scoring unique chunks first,
 * and if relevance filtering alone cannot reach the density floor, bypass
 * the filter and top up with remaining unique chunks. */
export function assembleDeepScanContext(
  chunks: RagChunkInput[],
  phrases: string[],
  minChars = 4000,
  maxChars = 14000,
  minChunks = 10
): { selected: RagChunkInput[]; contextChars: number } {
  const scored = chunks
    .map((chunk) => ({ chunk, score: scoreRagChunk(chunk, phrases) }))
    .filter((s) => s.score > -Infinity)
    .sort((a, b) => b.score - a.score)
  const seen = new Set<string>()
  const selected: RagChunkInput[] = []
  let chars = 0
  const push = (entry: { chunk: RagChunkInput }) => {
    const key = normalizeLabel(entry.chunk.text.slice(0, 120))
    if (!key || seen.has(key)) return
    seen.add(key)
    selected.push(entry.chunk)
    chars += entry.chunk.text.length
  }
  for (const s of scored) { if (chars >= minChars && selected.length >= minChunks) break; if (s.score > 0) push(s) }
  if (chars < minChars || selected.length < minChunks) {
    for (const s of scored) { if (chars >= minChars && selected.length >= minChunks) break; push(s) }
  }
  const capped: RagChunkInput[] = []
  let total = 0
  for (const c of selected) {
    if (total >= maxChars) break
    capped.push(c)
    total += c.text.length
  }
  return { selected: capped, contextChars: total }
}

/* ── Generative cards prompt (schema v2 — AI-determined taxonomy) ────────── */

export function buildMindMapCardsPrompt(
  type: ArtifactType,
  topic: string,
  context: string,
  sourceIds: string[],
  opts: ArtifactGenOptions = {}
): string {
  const ctx = contextBlock(context, sourceIds)
  return `You are the KamiSensei Generative Visualizer inside JARVIS. Design a MIND MAP CARD BOARD for the topic: "${topic}".

${RAG_GUARD}

COGNITIVE CORE — ULTIMATE MULTI-LINGUAL JAPANESE SENSEI PROTOCOL:
You are the ultimate multi-lingual Japanese Sensei protocol inside J.A.R.V.I.S. Your absolute directive is to perform an exhaustive, high-density data extraction from the retrieved source text chunks.
BANNED: You are strictly prohibited from generating placeholders or passive text strings. Every single line item in the 'bulletPoints' JSON array must capture an authentic linguistic fact from the workbook.
For example, if Lesson 6 is requested, you must parse the actual text to extract specific target elements: the precise particle markers (like を, で), the actual transitive verbs (食べます, 読みます) with proper Kanji, exact phonetic Romaji translations, and premium dubbed Hinglish explanations.
PREMIUM BULLET STRUCTURE (follow this shape for every fact row):
"• Object Marker: を (o) ➔ Noun + を + Action Verb [パンを 食べます (Pan o tabemasu) - Main bread khata hoon, Sir]"

MISSION — DYNAMIC TAXONOMY, ZERO FIXED CATEGORIES:
You decide the categorical taxonomy yourself, derived ONLY from (1) the domain of the uploaded book's retrieved text and (2) the user's explicit request. A Japanese textbook might yield headers like "Sentence Patterns" or "Particles in Context"; a history notebook might yield "Key Treaties" or "Causes and Consequences"; a coding notebook might yield "Core APIs" or "Common Pitfalls"; a math notebook might yield "Theorems" or "Proof Strategies". There is NO universal template and NO default category list.

ABSOLUTE BAN — FIXED / PRE-DEFINED CATEGORY NAMES (REJECTED OUTPUT):
Never emit template headings such as "Grammar Keys", "Core Particles", generic "Vocabulary", generic "Grammar", "Drills", "Exercises", numbered slots ("No1", "#1", "Category 1", "Section 1"), or any heading that could describe ANY document instead of THIS document. Every "headerTitle" must name a category that genuinely exists in the retrieved text. Every "bulletPoints[].text" must be a concrete content line grounded in the source document text — never a file statistic (page counts, "study pages", "language medium", PDF info) and never generic advice.

CRITICAL RULE: You are completely banned from creating empty meta-descriptions like "Detailed entries for vocabulary" or "Overview of grammar points". You must output ACTUAL, RAW educational rows directly from the book text.

CONTENT DENSITY REQUIREMENT — EVERY bullet point in "bulletPoints" MUST carry the real content itself, never a description of what the category would contain. For a language book that means the actual Japanese characters, its phonetic Romaji, and a clear Hinglish definition, exactly like:
{ "text": "は (wa) - Topic Marker. [Watashi wa Rahul desu - Main Rahul hoon]", "hasCheckbox": true }
For any other domain the bullet must quote or tightly paraphrase the concrete rule, fact, formula, date, API, or event from the source text. If a bullet you are about to write could apply to ANY book in the world, it is invalid — replace it with the specific row from the context.

MINE THE CONTEXT EXHAUSTIVELY: the context below contains raw lesson pages. Ignore any table-of-contents, index, or running-header lines that slipped in, and extract the densest possible content rows from the actual lesson body.

Return ONLY valid JSON (no markdown fences, no commentary) matching this exact schema:
{
  "title": "Main Topic Heading",
  "cards": [
    {
      "id": "card_1",
      "headerTitle": "DYNAMIC_CATEGORY_NAME_FROM_AI",
      "themeColor": "pink | purple | teal | green | orange | amber",
      "iconType": "grammar | settings | group | list | checklist | default",
      "bulletPoints": [
        { "text": "Content line entry from source document text", "hasCheckbox": false }
      ]
    }
  ]
}

Generation contract:
- 3-8 cards; 3-8 bulletPoints per card; every bullet is one concrete fact, rule, or example taken from the context.
- "hasCheckbox": true ONLY for actionable drill/practice items the learner can tick off; false for reference facts.
- "iconType": "grammar" for structure/rule categories, "group" for clusters/taxonomies, "list" for enumerations, "checklist" for practice/drill categories, "settings" for configuration/procedure categories, else "default".
- "themeColor": pick from the enum and vary it across cards.

${ctx}`
}

/* ── Flatten nested tree → flat nodes with hash ids + semantic dedup ────── */

export function flattenMindMapInput(parsed: unknown, maxDepth: number): MindMapNode[] {
  const out: MindMapNode[] = []
  const byNorm = new Map<string, MindMapNode>()
  const obj = parsed as Record<string, unknown> | null
  if (!obj) return out

  const walk = (node: MindMapRootNode, parentId: string | null, depth: number) => {
    if (!node || typeof node !== 'object' || depth > maxDepth) return
    let label = String(node.label ?? '').replace(/\s+/g, ' ').trim()
    if (!label) return
    // Noise ban: a meta/file-statistics child is silently dropped. A meta-level
    // ROOT is relabeled from the artifact title so the lesson topic stays the root.
    if (isMetaLabel(label)) {
      if (parentId == null) {
        const title = String((parsed as Record<string, unknown>)?.title ?? '').replace(/\s+/g, ' ').trim()
        if (title && !isMetaLabel(title)) label = title
        else return
      } else {
        return
      }
    }
    const description = String(node.description ?? '').replace(/\s+/g, ' ').trim()
    const key = normalizeLabel(label)
    let canonical = byNorm.get(key)
    if (!canonical) {
      // Semantic (bag-of-words) dedup: labels like "Japanese Particles" and
      // "Particles Japanese" represent the same concept. Only merge when the
      // candidate is a leaf (no children) to avoid collapsing distinct branches.
      const words = key.split(' ').filter((w) => w.length > 2).sort()
      if (words.length >= 2) {
        const bowKey = words.join(' ')
        for (const [k, v] of byNorm) {
          const kw = k.split(' ').filter((w) => w.length > 2).sort()
          if (kw.length >= 2 && kw.join(' ') === bowKey && v && !(v.children && v.children.length)) {
            canonical = v
            break
          }
        }
      }
    }
    if (canonical) {
      if (!canonical.description && description) canonical.description = description
      ;(Array.isArray(node.children) ? node.children : []).forEach((c) => walk(c, canonical.id, depth + 1))
      return
    }
    const flat: MindMapNode = { id: uniqueId('mm'), label, parentId, type: node.type, sourceReferences: node.sourceReferences }
    if (description) flat.description = description
    byNorm.set(key, flat)
    out.push(flat)
    ;(Array.isArray(node.children) ? node.children : []).forEach((c) => walk(c, flat.id, depth + 1))
  }

  const root = (obj as Record<string, unknown>).root
  if (root && typeof root === 'object') walk(root as MindMapRootNode, null, 0)
  return out
}

/* ── Mind map dynamic prompt (source-grounded, no fixed template) ───────── */

export function buildMindMapPrompt(
  type: ArtifactType,
  topic: string,
  context: string,
  sourceIds: string[],
  opts: ArtifactGenOptions = {}
): string {
  const ctx = contextBlock(context, sourceIds)
  const limit = mindMapDepthLimit(opts.requestedDepth)
  const depthText = limit === 2
    ? 'DEPTH CONTRACT: BRIEF \u2014 root \u2192 major top-level concept (one tier of branches under root). Do NOT invent generic headings like "Vocabulary" or "Grammar" unless those concepts actually appear in the source.'
    : limit === 4
      ? 'DEPTH CONTRACT: DETAILED \u2014 root \u2192 major concept \u2192 sub-concept \u2192 leaf detail (3-4 tiers). Each level should reflect genuine conceptual relationships found in the source, not a fixed template.'
      : 'DEPTH CONTRACT: COMPLETE \u2014 exhaustive hierarchy: as many tiers as the material genuinely requires. Every distinct concept, definition, rule, example, and relationship present in the source must get its own node at the appropriate depth. Do NOT cap node count or force fixed branch headings; let the document structure determine the tree.'
  return `You are the KamiSensei Mind Map Visualizer inside JARVIS \u2014 an advanced educational visualizer. Generate a MIND MAP for the topic: "${topic}".

${RAG_GUARD}

MISSION \u2014 EXTRACT REAL LESSON CONTENT, NEVER FILE METADATA:
You are an advanced educational visualizer. Extract the ACTUAL, CONCRETE Japanese language grammar rules, particles, vocabulary structures, and contextual patterns from the retrieved text context of the selected book \u2014 never statistics about the file itself.

- ROOT NODE: the exact lesson/topic requested (e.g. "Minna no Nihongo Lesson 1 Grammar Rules").
- MAIN BRANCHES: the REAL core particles and sentence patterns actually present in the context,
  e.g. "\u301c\u306f \u301c\u3067\u3059 (wa... desu)", "\u301c\u3058\u3083\u3042\u308a\u307e\u305b\u3093 (ja arimasen)", "\u301c\u3082 (mo)", "\u301c\u306e (no)".
- LEAF DETAILS: short real-world example sentences from the context, each with a one-line
  Hinglish/English explanation, e.g. "Watashi wa gakusei desu \u2014 Main student hoon (I am a student)."
- Build the hierarchy from genuine lesson structure exactly as the source teaches it.

ABSOLUTE BAN \u2014 META-LEVEL & FILE-STATISTICS NODES (REJECTED OUTPUT):
NEVER emit nodes that describe the source FILE instead of the language inside it. Forbidden labels include:
page numbers / page counts / "study pages" / "workbook" / "book length or size" / "language medium"
(e.g. "English Language Medium") / PDF or document info / table of contents / extraction or OCR stats /
word counts / any count of pages, sections, chapters, or paragraphs. Such nodes are always wrong, are
silently dropped, and force a regeneration. Every node MUST describe Japanese language content.

${depthText}
Node count: produce as many nodes as the source material genuinely contains \u2014 there is no fixed minimum or maximum. Every branch label MUST come from real concepts found in the retrieved context. Never emit generic/templated branches (Vocabulary, Grammar, Particles, Kanji, Conversation) unless those terms are explicitly grounded in the source.

For EACH node, assign a "type" from: root, topic, subtopic, concept, rule, example, definition, reference.
Grant every node a short custom unique id (e.g. "n1", "wa-particle", "ja-arimasen") unique within the tree.

Return ONLY valid JSON (no markdown fences, no commentary) matching this exact nested schema:
${SCHEMA_MAP['mind_map']}

Generation guidance: ${GUIDANCE_MAP['mind_map']}
${contractLines(opts)}

${ctx}`
}
/* ── Deterministic salvage pass ────────────────────────────────────────────
 * Runs BEFORE the LLM repair attempt. Applies only lossless/trivial fixes:
 * type alignment, alias key mapping (e.g. correct_index -> correctAnswer),
 * option-string -> index conversion, and an honest fallback explanation
 * derived from the correct option. Never invents new content.
 */
export function salvageArtifact(type: ArtifactType, data: unknown): unknown {
  if (!data || typeof data !== 'object') return data
  const obj = data as Record<string, unknown>
  try {
    const copy = JSON.parse(JSON.stringify(obj)) as Record<string, unknown>
    copy.type = type
    if (typeof copy.title !== 'string' || !copy.title.trim()) copy.title = 'Untitled'

    if (type === 'quiz' && Array.isArray(copy.questions)) {
      (copy.questions as unknown[]).forEach((qRaw) => {
        const q = qRaw as Record<string, unknown>
        if (!q || typeof q !== 'object') return
        if (!Array.isArray(q.options)) q.options = []
        const opts = (q.options as unknown[]).filter((o) => typeof o === 'string') as string[]
        q.options = opts

        // Alias mapping for correctAnswer
        if (q.correctAnswer == null) {
          const alias = q.correct_index != null ? q.correct_index : q.correctIndex != null ? q.correctIndex : q.correct_answer
          if (alias != null) q.correctAnswer = alias
        }
        // Explanation aliases
        if (!q.explanation || !String(q.explanation).trim()) {
          const ex = q.reasoning != null ? q.reasoning : q.explanation_en != null ? q.explanation_en : q.notes
          if (ex != null) q.explanation = ex
        }

        let ca = q.correctAnswer as unknown
        if (typeof ca === 'string') {
          const trimmed = ca.trim()
          const exact = opts.findIndex((o) => o.trim().toLowerCase() === trimmed.toLowerCase())
          if (exact !== -1) { ca = exact }
          else {
            const asNum = Number(trimmed)
            if (!isNaN(asNum) && Number.isInteger(asNum) && asNum >= 0 && asNum < opts.length) { ca = asNum }
            else {
              const letter = trimmed.toUpperCase().replace(/[^A-D]/g, '')
              if (letter.length === 1) {
                const li = letter.charCodeAt(0) - 65
                if (li >= 0 && li < opts.length) ca = li
              }
            }
          }
        }
        if (typeof ca === 'number') ca = Math.floor(ca as number)
        if (typeof ca !== 'number' || ca < 0 || ca >= opts.length) ca = 0
        q.correctAnswer = ca as number
        if (!q.explanation || !String(q.explanation).trim()) {
          q.explanation = `Correct answer: ${String(opts[ca as number] ?? '')}.`
        }
      })
    }

    if (type === 'data_table') {
      if (!Array.isArray(copy.columns)) copy.columns = []
      if (!Array.isArray(copy.rows)) copy.rows = []
      else {
        copy.rows = ((copy.rows as unknown[]).filter((r) => Array.isArray(r)) as unknown[][]).map((r) =>
          (r as unknown[]).map((cell) => (typeof cell === 'string' || typeof cell === 'number' ? cell : String(cell)))
        )
      }
      if (!Array.isArray(copy.sources)) copy.sources = []
    }

    if (type === 'flashcard_set') {
      if (!Array.isArray(copy.cards)) copy.cards = []
      else copy.cards = (copy.cards as unknown[]).filter((c) => c && typeof c === 'object')
    }
    if (type === 'mind_map') {
      if (!Array.isArray(copy.nodes)) copy.nodes = []
      else copy.nodes = (copy.nodes as unknown[]).filter((n) => n && typeof n === 'object')
    }
    return copy
  } catch {
    return data
  }
}