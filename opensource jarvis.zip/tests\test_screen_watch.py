"""Live Screen sampler tests: local-only, latest-frame-only, clear on off.

The real capture seam is patched with a tiny PIL image, so these tests never
read the owner's desktop and never write a screenshot to disk.
"""
import sys
import time
import unittest
from pathlib import Path
from unittest import mock

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from background import screen_agent as SA  # noqa: E402


def _image(color=(10, 20, 30)):
    return Image.new("RGB", (80, 60), color)


class ScreenWatcherTest(unittest.TestCase):
    def setUp(self):
        self.watcher = SA.ScreenWatcher()
        self.addCleanup(self.watcher.stop)

    def _wait_for(self, predicate, timeout=2.5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.01)
        return False

    def test_start_keeps_only_the_latest_jpeg_and_off_clears_everything(self):
        updates = []
        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()):
            started = self.watcher.start(scope="full_screen", fps=20,
                                         on_update=updates.append)
            self.assertTrue(started["enabled"])
            self.assertTrue(self._wait_for(
                lambda: self.watcher.status()["frames"] >= 1))
            frame = self.watcher.latest(max_age=5.0)
            self.assertIsNotNone(frame)
            self.assertTrue(frame["jpeg_b64"].startswith("/9j/"))
            self.assertGreater(self.watcher.status()["frame_kb"], 0)
            # Status published to the dashboard must never carry image bytes.
            self.assertTrue(updates)
            self.assertNotIn("jpeg_b64", updates[-1])

            stopped = self.watcher.stop()

        self.assertFalse(stopped["enabled"])
        self.assertEqual(stopped["frames"], 0)
        self.assertEqual(stopped["last_frame_at"], 0.0)
        self.assertEqual(stopped["foreground"], "")
        self.assertEqual(stopped["frame_kb"], 0.0)
        self.assertGreater(stopped["cleared_at"], 0.0)
        self.assertEqual(self.watcher._jpeg_b64, "")
        self.assertIsNone(self.watcher._signature)
        self.assertIsNone(self.watcher.latest(max_age=5.0))
        self.assertFalse(self.watcher.status()["enabled"])

    def test_foreground_title_change_counts_even_when_pixels_match(self):
        current = {"title": "Window A"}
        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()), \
             mock.patch.object(SA, "_foreground_title",
                               side_effect=lambda: current["title"]):
            self.watcher.start(fps=20)
            self.assertTrue(self._wait_for(
                lambda: self.watcher.status()["frames"] >= 1))
            before = self.watcher.status()["last_change_at"]
            current["title"] = "Window B"
            self.assertTrue(self._wait_for(
                lambda: (self.watcher.status()["last_change_at"] > before
                         and self.watcher.status()["foreground"] == "Window B")))
            self.watcher.stop()

    def test_a_title_change_during_capture_is_not_paired_with_the_old_image(self):
        calls = {"n": 0}

        def title():
            calls["n"] += 1
            return "Window A" if calls["n"] <= 1 else "Window B"

        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()), \
             mock.patch.object(SA, "_foreground_title", side_effect=title):
            self.watcher.start(fps=20)
            self.assertTrue(self._wait_for(
                lambda: self.watcher.status()["frames"] >= 1))
            frame = self.watcher.latest(max_age=5.0)
            self.assertIsNotNone(frame)
            self.assertEqual(frame["foreground"], "Window B")
            self.watcher.stop()

    def test_start_is_idempotent_and_uses_one_thread(self):
        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()):
            self.watcher.start(fps=20)
            first_thread = self.watcher._thread
            first = self.watcher.status()
            self.watcher.start(fps=20)
            second = self.watcher.status()
            self.assertIs(self.watcher._thread, first_thread)
            self.assertTrue(first["thread_alive"])
            self.assertTrue(second["thread_alive"])
            self.watcher.stop()

    def test_stale_frame_is_not_handed_to_vision(self):
        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()):
            self.watcher.start(fps=20)
            self.assertTrue(self._wait_for(
                lambda: self.watcher.status()["frames"] >= 1))
            time.sleep(0.05)
            self.assertIsNone(self.watcher.latest(max_age=0.0))
            self.watcher.stop()

    def test_a_capture_failure_is_reported_and_off_clears_the_error(self):
        with mock.patch.object(SA, "_watch_capture",
                               side_effect=RuntimeError("screen locked")):
            self.watcher.start(fps=20)
            self.assertTrue(self._wait_for(
                lambda: "screen locked" in self.watcher.status()["error"]))
            self.assertTrue(self.watcher.status()["enabled"])
            self.assertIsNone(self.watcher.latest(max_age=5.0))
            stopped = self.watcher.stop()
        self.assertEqual(stopped["error"], "")
        self.assertEqual(stopped["frames"], 0)
        self.assertIsNone(self.watcher.latest(max_age=5.0))

    def test_last_clear_timestamp_is_published(self):
        with mock.patch.object(SA, "_watch_capture", lambda _scope: _image()):
            self.watcher.start(fps=20)
            self.assertTrue(self._wait_for(
                lambda: self.watcher.status()["frames"] >= 1))
        before = time.time()
        status = self.watcher.stop()
        self.assertGreaterEqual(status["cleared_at"], before)
        self.assertFalse(status["enabled"])


if __name__ == "__main__":
    unittest.main()
