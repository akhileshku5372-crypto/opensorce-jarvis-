"""Tests for the Live bridge: the piece that lets a Gemini Live duplex session
share JARVIS's ONE microphone, ONE command path and ONE memory.

No network, no microphone, no speaker: the session is a fake. Real audio is
proven by `background/live_session.py --mic` after these pass.

The invariants these tests exist to protect:
  - the mic is never opened twice (the bridge is fed by voice_engine's existing
    `_audio_q` consumer, it does not create a stream);
  - local VAD/STT/wake go silent while Live owns a turn, and come back on stop;
  - a spoken action result is voiced by Live's native audio, not a TTS file, so
    barge-in works on it;
  - commands still travel through the single `submit_command` path, and a reply
    is never fed back in as if the user said it (no self-feeding loop).
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


LB = _load("live_bridge")
LS = _load("live_session")


class FakeSession:
    """Stands in for LiveSession; records what the bridge asks of it."""

    opens_ok = True
    close_raises = False

    def __init__(self, on_transcript=None, on_state=None, **kwargs):
        self.on_transcript = on_transcript or (lambda who, text: None)
        self.on_state = on_state or (lambda **kw: None)
        self.pcm = []
        self.texts = []
        self.opened = 0
        self.closed = 0

    def open(self, timeout=30.0):
        self.opened += 1
        return FakeSession.opens_ok

    def send_pcm(self, pcm_16k):
        if not FakeSession.opens_ok:
            return False
        self.pcm.append(pcm_16k)
        return True

    def send_text(self, text):
        self.texts.append(text)
        return True

    def close(self):
        self.closed += 1
        if FakeSession.close_raises:
            raise RuntimeError("socket already gone")


class FakePlayer:
    def __init__(self):
        self.speaking = False
        self.flushes = 0

    def flush(self):
        self.flushes += 1
        self.speaking = False


def chunks(n_samples, count, value=100):
    import array
    one = array.array("h", [value]) * n_samples
    return [one.tobytes()] * count


class BridgeTestCase(unittest.TestCase):
    def setUp(self):
        self.sessions = []

        def factory(on_transcript, on_state):
            s = FakeSession(on_transcript=on_transcript, on_state=on_state)
            self.sessions.append(s)
            return s

        self.submitted = []
        self.remembered = []
        self.turns = []
        FakeSession.opens_ok = True
        FakeSession.close_raises = False
        # Production wires voice_engine._live_route here: exactly ONE argument.
        # The old fake accepted (text, source) and masked a real TypeError that
        # killed the reader on the first turn.
        LB.configure(factory=factory,
                     submit_fn=lambda text: self.submitted.append(text),
                     remember_fn=lambda text: self.remembered.append(text),
                     turn_fn=lambda user, jarvis: self.turns.append((user, jarvis)))
        LB._last_speak_at = 0.0
        LB.stop()

    def tearDown(self):
        LB.stop()

    @property
    def session(self):
        self.assertTrue(self.sessions, "no session was created")
        return self.sessions[-1]


class StartStopTest(BridgeTestCase):
    def test_start_opens_one_session_and_takes_the_audio(self):
        self.assertFalse(LB.taking_audio())
        self.assertTrue(LB.start())
        self.assertTrue(LB.taking_audio())
        self.assertEqual(self.session.opened, 1)

    def test_start_refuses_when_the_session_cannot_open(self):
        FakeSession.opens_ok = False
        self.assertFalse(LB.start())
        self.assertFalse(LB.taking_audio())
        self.assertIn("live_error", LB.status()["live_stage"])

    def test_start_refuses_when_the_session_class_could_not_be_loaded(self):
        # live_session imports `websocket`; if the package is missing the factory
        # hands back None. That must degrade to classic mode, not crash the loop.
        LB.configure(factory=lambda on_transcript, on_state: None)
        self.assertFalse(LB.start())
        self.assertFalse(LB.taking_audio())
        self.assertIn("live_error", LB.status()["live_stage"])

    def test_stop_closes_the_session_and_gives_the_mic_back(self):
        LB.start()
        LB.stop()
        self.assertFalse(LB.taking_audio())
        self.assertEqual(self.session.closed, 1)

    def test_stop_still_gives_the_mic_back_when_close_raises(self):
        LB.start()
        FakeSession.close_raises = True
        LB.stop()
        self.assertFalse(LB.taking_audio())


class AudioFeedTest(BridgeTestCase):
    def test_feed_sends_one_32ms_frame_per_512_samples(self):
        LB.start()
        LB.feed(b"\x64\x00" * 512, 16000)
        self.assertEqual(len(self.session.pcm), 1)
        self.assertEqual(len(self.session.pcm[0]), 512 * 2,
                         "frame = 32 ms of PCM16, the mic's own block")

    def test_feed_holds_a_partial_frame_until_it_is_full(self):
        LB.start()
        LB.feed(b"\x64\x00" * 511, 16000)
        self.assertEqual(self.session.pcm, [], "must not send a sub-frame")
        LB.feed(b"\x64\x00", 16000)
        self.assertEqual(len(self.session.pcm), 1)
        self.assertEqual(len(self.session.pcm[0]), 512 * 2)

    def test_feed_downsamples_48k_to_16k_by_box_mean(self):
        import array
        LB.start()
        samples = array.array("h", [0]) * (512 * 10)
        for i in range(len(samples)):
            samples[i] = 300 if i % 3 == 0 else 0      # mean of each 3 = 100
        for payload in [samples[i * 512:(i + 1) * 512].tobytes() for i in range(10)]:
            LB.feed(payload, 48000)
        # 5120 samples at 48k = 1706 at 16k -> three 512-sample frames, with 170
        # samples carried for the next block (not dropped).
        self.assertEqual(len(self.session.pcm), 3)
        out = array.array("h")
        out.frombytes(self.session.pcm[0][:512 * 2])
        self.assertEqual(out[0], 100, "48 kHz must be averaged down, not decimated")
        self.assertEqual(LB.status()["samples_in_16k"], 1706,
                         "5120 samples at 48k = 1706 at 16k, remainder carried")

    def test_feed_is_a_no_op_when_live_is_not_owning_the_mic(self):
        LB.feed(b"\x00\x00" * 1600, 16000)
        self.assertEqual(self.sessions, [])

    def test_quiet_mic_during_reply_is_gated_to_silence(self):
        LB.start()
        self.session.player = FakePlayer()
        self.session.player.speaking = True
        LB._last_speak_at = 0.0
        LB.feed(b"\x01\x00" * LB.FRAME_SAMPLES, 16000)
        self.assertEqual(self.session.pcm[-1], b"\x00\x00" * LB.FRAME_SAMPLES)
        self.assertEqual(LB.status()["echo_gated"], 1)
        self.assertEqual(self.session.player.flushes, 0)

    def test_loud_mic_during_reply_is_a_local_barge_in(self):
        LB.start()
        self.session.player = FakePlayer()
        self.session.player.speaking = True
        LB.feed(b"\xb8\x0b" * LB.FRAME_SAMPLES, 16000)   # int16 3000 RMS
        self.assertEqual(self.session.pcm[-1], b"\xb8\x0b" * LB.FRAME_SAMPLES)
        self.assertEqual(self.session.player.flushes, 1)
        self.assertEqual(LB.status()["local_barge_in"], 1)


class TranscriptRoutingTest(BridgeTestCase):
    def test_user_words_reach_the_one_command_path_when_his_turn_ends(self):
        LB.start()
        self.session.on_transcript("user", "open youtube")
        self.session.on_state(stage="live_turn_done")
        self.assertEqual(self.submitted, ["open youtube"])
        self.assertEqual(self.remembered, ["open youtube"])
        self.assertEqual(self.turns, [("open youtube", "")])

    def test_jarvis_own_words_are_not_learned_as_facts_and_never_resubmitted(self):
        LB.start()
        self.session.on_transcript("jarvis", "Opening YouTube, sir.")
        self.session.on_state(stage="live_turn_done")
        self.assertEqual(self.submitted, [], "self-feeding loop")
        self.assertEqual(self.remembered, [],
                         "the assistant's wording must not become a fact about Sir")
        self.assertEqual(self.turns, [("", "Opening YouTube, sir.")])
        self.assertEqual(LB.status()["last_jarvis"], "Opening YouTube, sir.")

    def test_both_sides_are_stitched_from_deltas_into_one_line(self):
        # The endpoint streams transcription in pieces ("Loud and" / "clear,"),
        # so memory and the panel must get the finished sentence once. Learned
        # from a live duplex turn on 2026-10-20.
        LB.start()
        self.session.on_transcript("jarvis", "Loud and")
        self.session.on_transcript("jarvis", "clear, sir.")
        self.session.on_transcript("user", "kya")
        self.session.on_transcript("user", "chal raha hai")
        self.assertEqual(self.remembered, [], "a fragment must not be learned")
        self.session.on_state(stage="live_turn_done")
        self.assertEqual(self.remembered, ["kya chal raha hai"])
        self.assertEqual(self.turns, [("kya chal raha hai", "Loud and clear, sir.")])
        self.assertEqual(LB.status()["last_jarvis"], "Loud and clear, sir.")
        self.assertEqual(LB.status()["last_user"], "kya chal raha hai")

    def test_partial_user_transcripts_are_stitched_before_submitting_once(self):
        LB.start()
        self.session.on_transcript("user", "open")
        self.session.on_transcript("user", " youtube")
        self.assertEqual(self.submitted, [])
        self.session.on_state(stage="live_turn_done")
        self.assertEqual(self.submitted, ["open youtube"])

    def test_a_tool_call_suppresses_the_post_turn_os_fallback(self):
        # The model already ran the action through jarvis_command; submitting
        # the same transcript again would execute it twice.
        LB.start()
        self.session.on_state(stage="live_tool", tool="jarvis_command")
        self.session.on_transcript("user", "open youtube")
        self.session.on_state(stage="live_turn_done")
        self.assertEqual(self.submitted, [])
        self.assertEqual(self.remembered, ["open youtube"])
        self.assertEqual(LB.status()["last_tool"], "jarvis_command")
        self.assertEqual(LB.status()["tool_calls"], 1)


class UtterTest(BridgeTestCase):
    def test_action_results_are_spoken_by_the_live_voice(self):
        LB.start()
        self.assertTrue(LB.utter("YouTube is open, sir."))
        self.assertEqual(len(self.session.texts), 1)
        self.assertTrue(self.session.texts[0].startswith("SYSTEM:"))

    def test_utter_returns_false_without_a_live_session(self):
        self.assertFalse(LB.utter("anything"))

    def test_utter_refuses_an_empty_line_rather_than_opening_mouth(self):
        LB.start()
        self.assertFalse(LB.utter("   "))
        self.assertEqual(self.session.texts, [])


class StateTest(BridgeTestCase):
    def test_barge_in_is_counted_for_the_ui(self):
        LB.start()
        self.session.on_state(stage="live_barge_in", dropped_chunks=7)
        self.session.on_state(stage="live_barge_in", dropped_chunks=2)
        st = LB.status()
        self.assertEqual(st["barge_in"], 2)
        self.assertEqual(st["dropped_chunks"], 9)
        self.assertEqual(st["voice_mode"], "live")

    def test_turn_done_records_the_first_audio_latency_that_decides_the_feel(self):
        LB.start()
        self.session.on_state(stage="live_turn_done", first_audio_s=0.42)
        st = LB.status()
        self.assertEqual(st["first_audio_s"], 0.42)
        self.assertEqual(st["turns"], 1)

    def test_status_always_carries_the_fields_the_console_reads(self):
        st = LB.status()
        for key in ("voice_mode", "live_stage", "barge_in", "first_audio_s",
                    "turns", "frames_sent", "last_error"):
            self.assertIn(key, st)
        self.assertEqual(st["voice_mode"], "classic")


class PersonaRuleTest(unittest.TestCase):
    def test_persona_forbids_claiming_an_action_before_the_system_line(self):
        # Task #7's lesson: the brain must not claim actions it never performed.
        # In duplex mode the model hears "open YouTube" and could simply say
        # "Done, sir" before anything ran, so the persona has to forbid it.
        p = LS.PERSONA_DEFAULT
        self.assertIn("SYSTEM", p)
        self.assertIn("acknowledg", p.lower())

    def test_persona_names_jarvis_command_as_the_door_to_every_capability(self):
        # Owner order 2026-10-20: Live must not answer "I have no tool" for a
        # capability classic already has. The one router is the contract.
        p = LS.PERSONA_DEFAULT
        self.assertIn("single action door", p)
        self.assertIn("every installed JARVIS capability", p)
        self.assertIn("WhatsApp", p)
        self.assertIn("never tell him you have no tool", p.lower())

    def test_persona_requires_screen_look_and_teaches_screen_grounded_actions(self):
        # Owner order 2026-10-20: Live must see the real screen before claiming
        # blindness, and desktop mouse/keyboard work stays on the one router.
        p = LS.PERSONA_DEFAULT
        self.assertIn("look_at_screen", p)
        self.assertIn("cannot see the screen", p)
        self.assertIn("mouse", p.lower())
        self.assertIn("keyboard", p.lower())
        self.assertIn("never self-confirm", p.lower())


if __name__ == "__main__":
    unittest.main()
