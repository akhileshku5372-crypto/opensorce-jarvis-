"""Regression: the VAD was fed 48 kHz audio while configured for 16 kHz.

Root cause measured 2026-10-17: this host's microphone refuses 16 kHz
("Invalid sample rate"), so capture_loop opens the stream at 48 kHz and handed
those raw chunks to a VADIterator built with sampling_rate=16000. The model read
every utterance as three times its real length, so a 4.7s clip produced 200ms of
detected speech and an immediate end-of-turn (the same clip at true 16kHz yields
4528ms). The user spoke, JARVIS closed the turn before the clip reached the
minimum length, and nothing happened - the "sunne mein 2 minute lagte hain"
complaint.

Stdlib + numpy + torch only: no mic, no network, no model inference.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ENGINE = _load("voice_engine")


def _chunk(seconds, rate):
    """Silent-ish int16 bytes of the given duration at the given rate."""
    n = int(seconds * rate)
    return (np.zeros(n, dtype=np.int16)).tobytes()


class VadWindowRateTest(unittest.TestCase):
    def setUp(self):
        self._rate = ENGINE._CAP_RATE
        ENGINE._vad_windows_reset()
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE._CAP_RATE = self._rate
        ENGINE._vad_windows_reset()

    def test_windows_are_512_samples(self):
        """Silero's VADIterator only accepts exactly 512-sample windows."""
        ENGINE._CAP_RATE = 16000
        out = ENGINE._vad_windows(_chunk(0.5, 16000))
        self.assertGreater(len(out), 0)
        for w in out:
            self.assertEqual(tuple(w.shape), (1, 512))

    def test_48k_capture_is_decimated_to_16k_windows(self):
        """1s at 48 kHz must become ~1s of 16 kHz windows, not 3s worth."""
        ENGINE._CAP_RATE = 48000
        out = ENGINE._vad_windows(_chunk(1.0, 48000))
        # 16000 samples at 16 kHz = 31 whole 512-sample windows (15872 samples).
        self.assertEqual(len(out), 31,
                         "got %d windows = %.2fs of VAD time for a 1.0s clip"
                         % (len(out), len(out) * 512 / 16000.0))

    def test_fractional_samples_carry_over_instead_of_being_dropped(self):
        """512 samples at 48 kHz is 170.7 at 16 kHz - the remainder must survive."""
        ENGINE._CAP_RATE = 48000
        one = _chunk(512 / 48000.0, 48000)
        self.assertEqual(len(ENGINE._vad_windows(one)), 0)
        total = 0
        for _ in range(6):
            total += len(ENGINE._vad_windows(one))
        # 7 chunks of 170.67 samples = 1194 usable -> 2 windows, not 0 or 7.
        self.assertEqual(total, 2, "%d windows over 7 chunks" % total)

    def test_reset_clears_carry_over(self):
        ENGINE._CAP_RATE = 48000
        ENGINE._vad_windows(_chunk(512 / 48000.0, 48000))
        ENGINE._vad_windows_reset()
        self.assertEqual(len(ENGINE._vad_leftover), 0)


if __name__ == "__main__":
    unittest.main()
