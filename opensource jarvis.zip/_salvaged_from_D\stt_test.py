"""JARVIS STT/TTS live check + mic capture."""
import io
import sys
import threading
import time
import wave

import numpy as np
import sounddevice as sd
import requests


def sapi(text):
    code = ("Add-Type -AssemblyName System.Speech;"
            "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            "$s.SetOutputToDefaultAudioDevice();"
            "$s.Speak('%s');" % text.replace("'", "''"))
    import subprocess
    subprocess.call(["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", code])


def main():
    device = int(sys.argv[1]) if len(sys.argv) > 1 else None
    rate = 16000
    frames = int(rate * 5.0)
    print("capturing 5s while SAPI speaks the wake phrase (device=%s)..." % device, flush=True)
    audio = sd.rec(frames, samplerate=rate, channels=1, dtype="float32", device=device)
    t = threading.Thread(target=sapi, args=("hey jarvis open notepad",))
    t.start()
    sd.wait()
    t.join()
    rms = float(np.sqrt((audio**2).mean()))
    peak = float(np.abs(audio).max())
    print(f"captured RMS={rms:.5f} PEAK={peak:.5f}", flush=True)
    if peak < 0.002:
        print("MIC SILENT - no audio reached the input", flush=True)
        return 1
    buf = io.BytesIO()
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())
    buf.seek(0)
    print("POSTing to /api/stt ...", flush=True)
    r = requests.post("http://127.0.0.1:7777/api/stt",
                      files={"audio": ("audio.wav", buf, "audio/wav"),
                             "language": (None, "auto")}, timeout=60)
    print("STT status:", r.status_code, flush=True)
    print("STT body:", r.text[:300], flush=True)
    try:
        text = (r.json().get("text") or "").strip()
    except Exception:
        text = ""
    print("TRANSCRIPT:", text or "(empty)", flush=True)
    print("STT %s" % ("OK" if text else "FAILED"), flush=True)

    print("--- TTS test ---", flush=True)
    try:
        tts = requests.post("http://127.0.0.1:7777/api/tts",
                            json={"text": "Test one two three", "lang": "en"}, timeout=60)
        print("TTS status:", tts.status_code, "content-type:", tts.headers.get("content-type"), "bytes:", len(tts.content), flush=True)
    except Exception as exc:
        print("TTS FAILED:", exc, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())