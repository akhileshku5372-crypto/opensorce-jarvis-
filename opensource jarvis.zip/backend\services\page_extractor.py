"""
KamiSensei Page-Range Extraction Service (The NotebookLM Heavy Reader)
======================================================================
Direct sequential page extraction from Japanese study PDFs using PyMuPDF (fitz).
When a user query references a specific page (e.g. "Page 45", "page 110"), this
service extracts the raw text of the target page PLUS the next 2 sequential pages
(e.g., Pages 45, 46, and 47) without destructive token chunking.
"""

import os
import re
import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger("KamiSensei.PageExtractor")

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
KNOWLEDGE_BASE_DIR = ROOT_DIR / "knowledge_base"

# Comprehensive structured lesson curriculum for Minna no Nihongo I (Lessons 1-25 / 212 pages)
# Used as high-fidelity ground truth reference when PDF layers are image-only scans.
MINNA_NO_NIHONGO_LESSON_MAP = [
    {
        "lesson": 1,
        "page_start": 8,
        "page_end": 15,
        "title": "Lesson 1: Introductions, Identifications, and Particles (wa, mo, no, ka)",
        "grammar_points": [
            "1. Noun1 wa Noun2 desu (Noun1 is Noun2) — 'wa' marks the topic of the sentence.",
            "2. Noun1 wa Noun2 ja arimasen / dewa arimasen (Noun1 is not Noun2) — Negative form of desu.",
            "3. Sentence + ka (Question Particle) — Form question without changing word order.",
            "4. Noun + mo (Also / Too) — Replaces 'wa' when the same predicate applies.",
            "5. Noun1 no Noun2 (Possession / Qualification) — Noun1 modifies Noun2 (e.g. IMC no shain).",
            "6. Suffix ~san (Polite title added to listener/third party name, never to oneself)."
        ],
        "key_vocabulary": "watashi (I), anata (you), ano hito / ano kata (that person), sensei (teacher), gakusei (student), kaishain (company employee), shain (employee of ~), ginkouin (bank clerk), isha (doctor), kenkyuusha (researcher), daigaku (university), byouin (hospital), dare / donata (who), ~sai (age), nan-sai / o-ikutsu (how old), hai (yes), iie (no).",
        "reference_text": "Lesson 1 Grammar Notes: N1 は N2 です indicates that N1 is N2. Particle は is pronounced 'wa'. です functions as a predicate asserting judgment/affirmation. Negative: じゃありません (informal) or ではありません (formal). Question: add か at the end. Particle も indicates 'also'. Particle の connects two nouns where N1 qualifies N2."
    },
    {
        "lesson": 2,
        "page_start": 16,
        "page_end": 21,
        "title": "Lesson 2: Demonstratives (kore, sore, are), Possessives, and Confirmation",
        "grammar_points": [
            "1. kore / sore / are (Demonstrative pronouns) — kore (near speaker), sore (near listener), are (far from both).",
            "2. kono N / sono N / ano N (Demonstrative determiners modifying a noun directly).",
            "3. sou desu / sou ja arimasen (Affirming/denying noun questions).",
            "4. S1 ka, S2 ka (Alternative questions: Is it S1 or S2?).",
            "5. N1 no N2 (Possession: dare no hon desu ka -> watashi no hon desu / watashi no desu).",
            "6. sou desu ka (I see / Is that so?)."
        ],
        "key_vocabulary": "kore (this), sore (that near you), are (that over there), kono (this ~), sono (that ~), ano (that ~ over there), hon (book), jisho (dictionary), zasshi (magazine), shinbun (newspaper), nooto (notebook), techou (pocket notebook), meishi (business card), kaado (card), enpitsu (pencil), boorupen (ballpoint pen), kagi (key), tokei (clock/watch), kasa (umbrella), kaban (bag), terebi (TV), rajio (radio), kamera (camera), jidousha (car), tsukue (desk), isu (chair), dare (whose / who).",
        "reference_text": "Lesson 2 Grammar Notes: これ, それ, あれ function as independent pronouns referring to things. この, その, あの must be followed immediately by a noun (e.g. この本). To answer an identification question, use はい、そうです or いいえ、ちがいます (or そうじゃありません). の can substitute a previously mentioned noun to avoid repetition (私の[本]です)."
    },
    {
        "lesson": 3,
        "page_start": 22,
        "page_end": 29,
        "title": "Lesson 3: Locations, Directions, and Origin (koko, soko, asoko, doko)",
        "grammar_points": [
            "1. koko / soko / asoko / doko (Place demonstratives: here, there, over there, where).",
            "2. kochira / sochira / achira / dochira (Polite direction/place demonstratives and choices).",
            "3. Noun1 wa Place desu (Noun1 is at / in Place).",
            "4. doko / dochira (Asking where an item, place, or company/country is located).",
            "5. Noun1 no N2 (Country / Manufacturer of a product: doko no camera desu ka -> Nihon no camera desu).",
            "6. Numbers / Prices (~en, ikura desu ka)."
        ],
        "key_vocabulary": "koko (here), soko (there), asoko (over there), doko (where), kochira (this way/polite), sochira (that way), achira (that way over there), dochira (which way / where polite), kyoushitsu (classroom), shokudou (cafeteria), jimusho (office), kaigishitsu (meeting room), uketsuke (reception desk), heya (room), toire / o-tearai (restroom), kaidan (stairs), erebeetaa (elevator), esukareetaa (escalator), kuni (country), kaisha (company), uchi (home/house), denwa (telephone), kutsu (shoes), nekutai (necktie), wain (wine), ikura (how much).",
        "reference_text": "Lesson 3 Grammar Notes: ここ, そこ, あそこ denote locations relative to speaker and listener. こちら, そちら, あちら, どちら indicate direction or polite location/organization. To ask where something was made or what company made it: どこの + Noun (e.g., どこの車ですか -> 日本の車です / トヨタの車です)."
    },
    {
        "lesson": 4,
        "page_start": 30,
        "page_end": 37,
        "title": "Lesson 4: Time, Days of Week, and Verb Conjugation (masu / masen / mashita)",
        "grammar_points": [
            "1. ima ~ji ~fun/pun desu (Telling time: hours and minutes).",
            "2. Verb-masu (Non-past affirmative) / Verb-masen (Non-past negative).",
            "3. Verb-mashita (Past affirmative) / Verb-masen deshita (Past negative).",
            "4. Time ni + Verb (Particle 'ni' marking specific time points).",
            "5. ~kara ~made (From ~ to ~ : starting point and ending point in time or place).",
            "6. Noun1 to Noun2 (Connecting nouns with 'and')."
        ],
        "key_vocabulary": "ima (now), ~ji (o'clock), ~fun / ~pun (minute), han (half), nan-ji (what time), nan-pun (what minute), gozen (a.m.), gogo (p.m.), asa (morning), hiru (daytime/noon), ban / yoru (night), ototoi (day before yesterday), kinou (yesterday), kyou (today), ashita (tomorrow), asatte (day after tomorrow), kesa (this morning), konban (tonight), yasumi (rest/holiday), hiruyasumi (lunch break), maiasa (every morning), maiban (every night), mainichi (every day), Getsuyoubi (Monday), Kayoubi (Tuesday), Suiyoubi (Wednesday), Mokuyoubi (Thursday), Kinyoubi (Friday), Doyoubi (Saturday), Nichiyoubi (Sunday), nan-youbi (what day of week), okimasu (wake up), nemasu (sleep), hatarakimasu (work), yasumimasu (take a rest), benkyoushimasu (study), owarimasu (finish), depaato (department store), ginkou (bank), yuubinkyoku (post office), toshokan (library), bijutsukan (art museum).",
        "reference_text": "Lesson 4 Grammar Notes: Verbs end in 〜ます in non-past polite affirmative. Past is 〜ました, negative is 〜ません, past negative is 〜ませんでした. Particle に is attached to numerical/specific time expressions (7時に起きます). Relative time words (今日, 明日, 毎日) do NOT take に. 〜から indicates starting time/place, 〜まで indicates ending time/place."
    },
    {
        "lesson": 5,
        "page_start": 38,
        "page_end": 45,
        "title": "Lesson 5: Motion Verbs, Direction Particle (e), Means of Transport (de), and (to)",
        "grammar_points": [
            "1. Place e ikimasu / kimasu / kaerimasu (Motion verbs with directional particle 'e' written as へ).",
            "2. doko [e] mo ikimasen / ikimasen deshita (Complete negation: nowhere).",
            "3. Vehicle / Transport de ikimasu (Means of transport with particle 'de'). Exception: aruite (on foot).",
            "4. Person / Animal to + Verb (Accompaniment: with someone using particle 'to'). Alone: hitori de.",
            "5. itsu + Verb (Asking 'when' an action takes place).",
            "6. Sentence + yo (Emphatic sentence-ending particle giving new information)."
        ],
        "key_vocabulary": "ikimasu (go), kimasu (come), kaerimasu (return/go home), gakkou (school), suupaa (supermarket), eki (station), hikouki (airplane), fune (ship), densha (train), chikatetsu (subway), shinkansen (bullet train), basu (bus), takushii (taxi), jitensha (bicycle), aruite (on foot), hito (person), tomodachi (friend), kare (he/boyfriend), kanojo (she/girlfriend), kazoku (family), hitori de (alone), senchou (last week), konshuu (this week), raishuu (next week), sengetsu (last month), kongetsu (this month), raigetsu (next month), kyonen (last year), kotoshi (this year), rainen (next year), ~gatsu (month), nan-gatsu (what month), tsuitachi (1st), futsuka (2nd), mikka (3rd), yokka (4th), itsuka (5th), muika (6th), nanoka (7th), youka (8th), kokonoka (9th), tooka (10th), juu-yokka (14th), hatsuka (20th), ni-juu-yokka (24th), ~nichi (day of month), itsu (when), tanjoubi (birthday).",
        "reference_text": "Lesson 5 Grammar Notes: Direction particle へ (pronounced 'e') follows the destination of motion verbs (行きます, 来ます, 帰ります). Particle で denotes means of transportation (電車で行きます). Note: 歩いて (on foot) does not take で. Particle と marks accompaniment with a person (友達と行きます). どこ[へ]も行きません completely negates destination."
    },
    {
        "lesson": 6,
        "page_start": 46,
        "page_end": 53,
        "title": "Lesson 6: Direct Objects (o), Action Location (de), Invitations (masen ka, mashou)",
        "grammar_points": [
            "1. Noun o Verb (transitive) — Particle を (pronounced 'o') marks the direct object.",
            "2. Noun o shimasu (Performing sports, games, events, work: sakkaa o shimasu, paatii o shimasu).",
            "3. nani o shimasu ka (Asking what someone does / did).",
            "4. nan vs. nani (Usage distinction before d, t, n sounds or counters -> nan; otherwise -> nani).",
            "5. Place de + Verb (Particle 'de' marking the location where an action takes place).",
            "6. Verb-masen ka (Polite invitation: Won't you ~ ?).",
            "7. Verb-mashou (Positive invitation/proposal: Let's do ~ !).",
            "8. Polite prefix o- (o-sake, o-hanami)."
        ],
        "key_vocabulary": "tabemasu (eat), nomimasu (drink), suimasu [tabako o] (smoke), mimasu (see/watch), kikimasu (hear/listen), yomimasu (read), kakimasu (write/draw), kaimasu (buy), torimasu [shashin o] (take photos), shimasu (do), aimasu [tomodachi ni] (meet a friend), gohan (meal/rice), asagohan (breakfast), hirugohan (lunch), bangohan (dinner), pan (bread), tamago (egg), niku (meat), sakana (fish), yasai (vegetable), kudamono (fruit), mizu (water), ocha (green tea), koucha (black tea), gyuunyuu / miruku (milk), juusu (juice), biiru (beer), o-sake (alcohol/sake), terebi (TV), bideo (video), eiga (movie), tegami (letter), repooto (report), shashin (photo), mise (shop/store), resutoran (restaurant), niwa (garden), shukudai (homework), tenisu (tennis), sakkaa (soccer), o-hanami (cherry blossom viewing), nani (what), issho ni (together), chotto (a little/moment), itsumo (always), tokidoki (sometimes).",
        "reference_text": "Lesson 6 Grammar Notes: Direct object particle を (pronounced 'o') is used with transitive verbs (パンを食べます). Place particle で marks the active location where an action occurs (レストランで食べます). Note: particle に marks existence location (Lesson 10) while で marks action location. 〜ませんか is an invitation inviting the listener to act (一緒に京都へ行きませんか). 〜ましょう is an enthusiastic proposal or accepting an invitation (行きましょう)."
    },
    {
        "lesson": 7,
        "page_start": 54,
        "page_end": 61,
        "title": "Lesson 7: Tools/Means (de), Language translations, Giving/Receiving (agemasu, moraimasu)",
        "grammar_points": [
            "1. Tool / Instrument de + Verb — Particle 'de' indicates means or tools used (hashi de tabemasu).",
            "2. Word/Sentence wa Language de nan desu ka (How do you say X in language Y?).",
            "3. Person ni Noun o agemasu / kashimasu / oshiemasu (Giving, lending, teaching to Person).",
            "4. Person ni/kara Noun o moraimasu / karimasu / naraimasu (Receiving, borrowing, learning from Person).",
            "5. mou Verb-mashita (Already did ~) / mada desu (Not yet)."
        ],
        "key_vocabulary": "kirimasu (cut), okurimasu (send), agemasu (give), moraimasu (receive), kashimasu (lend), karimasu (borrow), oshiemasu (teach), naraimasu (learn), kakemasu [denwa o] (make phone call), te (hand), hashi (chopsticks), supun (spoon), naifu (knife), fooku (fork), hasami (scissors), pasokon (PC), keitai (mobile), meeru (email), nengajou (New Year card), panchi (hole puncher), hocchikisu (stapler), seroteepu (scotch tape), keshigomu (eraser), kami (paper), hana (flower), shatsu (shirt), purezento (present), nimotsu (baggage/parcel), okane (money), kippu (ticket), kurisumasu (Christmas), chichi (my father), haha (my mother), otousan (someone's father), okaasan (someone's mother), mou (already), mada (not yet), korekara (from now on).",
        "reference_text": "Lesson 7 Grammar Notes: Particle で denotes instruments or means (日本語でレポートを書きます). Giving verbs (あげます, 貸します, 教えます) take the recipient with に. Receiving verbs (もらいます, 借ります, 習います) take the giver with に or から (when receiving from an institution/school, から is preferred). もう + Verb-ました indicates completed action. Answer negative with いいえ、まだです (never ませんでした)."
    },
    {
        "lesson": 8,
        "page_start": 62,
        "page_end": 69,
        "title": "Lesson 8: Adjectives (i-adjectives and na-adjectives), Modification, and Conjunctions",
        "grammar_points": [
            "1. Classification of Adjectives: i-adjectives (end in ~i) and na-adjectives (take ~na before nouns).",
            "2. Predicate Form: Noun wa na-adj [desu / ja arimasen] ; Noun wa i-adj [~i desu / ~kunai desu].",
            "3. Noun Modification: na-adj + na + Noun ; i-adj + Noun.",
            "4. Degree adverbs: totemo (very, used with positive) / amari (not very, used with negative).",
            "5. Noun wa dou desu ka (How is / was Noun?).",
            "6. Noun1 wa donna Noun2 desu ka (What kind of Noun2 is Noun1?).",
            "7. Sentence1 ga, Sentence2 (Conjunction: S1, but S2)."
        ],
        "key_vocabulary": "hansamu [na] (handsome), kirei [na] (beautiful/clean), shizuka [na] (quiet), nigiyaka [na] (lively), yuumei [na] (famous), shinsetsu [na] (kind), genki [na] (healthy/cheerful), hima [na] (free time), benri [na] (convenient), suteki [na] (wonderful/fine), ookii (big), chiisai (small), atarashii (new), furui (old), ii / yoi (good), warui (bad), atsui (hot), samui (cold weather), tsumetai (cold to touch), muzukashii (difficult), yasashii (easy/kind), takai (expensive/high), yasui (cheap), hikui (low), omoshiroi (interesting), oishii (delicious), isogashii (busy), tanoshii (enjoyable), shiroi (white), kuroi (black), akai (red), aoi (blue), sakura (cherry blossom), yama (mountain), machi (town), tabemono (food), kuruma (car), tokoro (place), ryou (dormitory), benkyou (study), seikatsu (life), o-shigoto (work), dou (how), donna (what kind of), totemo (very), amari (not very), soshite (and then), ga (but).",
        "reference_text": "Lesson 8 Grammar Notes: Japanese adjectives divide strictly into い-adjectives and な-adjectives. い-adjective negative drops い and adds くないです (e.g. 高くないです; exception: いいです -> よくないです). な-adjective negative is じゃありません (e.g. 静かじゃありません). Modifying nouns: な-adj takes な (親切な人), い-adj modifies directly (新しい車). Particle が connects contrasting clauses."
    },
    {
        "lesson": 9,
        "page_start": 70,
        "page_end": 77,
        "title": "Lesson 9: Abilities, Preferences, Ownership (ga arimasu/wakarimasu/suki), and Reason (kara)",
        "grammar_points": [
            "1. Noun ga arimasu / wakarimasu (Possession / Understanding takes particle 'ga').",
            "2. Noun ga suki desu / kirai desu / jouzu desu / heta desu (Likes, dislikes, skills take particle 'ga').",
            "3. donna + Noun (Asking for specific categories/types).",
            "4. Adverbs of degree: yoku (well), daitai (mostly), takusan (many), sukoshi (a little), amari (not much), zenzen (not at all).",
            "5. Sentence1 kara, Sentence2 (Expressing reason/cause: Because S1, S2).",
            "6. doushite (Asking 'why' -> answer ends with ~kara desu)."
        ],
        "key_vocabulary": "wakarimasu (understand), arimasu (have/possess), suki [na] (like), kirai [na] (dislike), jouzu [na] (good at), heta [na] (poor at), nomi-mono (drinks), ryouri (cooking/cuisine), supoutsu (sports), yakyuu (baseball), dansu (dance), ryokou (travel), ongaku (music), uta (song), kurashikku (classical), jazz (jazz), konsaato (concert), karaoke (karaoke), kabuki (Kabuki), e (picture), ji (letter/character), kanji (Kanji), hiragana (Hiragana), katakana (Katakana), roumaji (Romaji), komakai okane (small change), chiketto (ticket), jikan (time), youji (errand/business), yakusoku (promise/appointment), go-shujin (someone's husband), otto / shujin (my husband), okusan (someone's wife), tsuma / kanai (my wife), kodomo (child), yoku (well), daitai (mostly), takusan (a lot), sukoshi (a little), zenzen (not at all), hayaku (early/quickly), kara (because), doushite (why).",
        "reference_text": "Lesson 9 Grammar Notes: Verbs of potential/understanding (わかります, あります) and adjectives of preference/ability (好き, 嫌い, 上手, 下手) mark their target object with が instead of を (e.g. 日本語がわかります, 映画が好きです). から connects reason: 時間がありませんから、テレビを見ません. Questions with どうして are answered with 〜からです."
    },
    {
        "lesson": 10,
        "page_start": 78,
        "page_end": 85,
        "title": "Lesson 10: Existence (arimasu/imasu), Locations, Position Words, and Listing (ya, nado)",
        "grammar_points": [
            "1. Existence verbs: arimasu (inanimate things/plants) vs. imasu (animate: humans, animals).",
            "2. Place ni Noun ga arimasu / imasu (There is Noun in Place).",
            "3. Noun wa Place ni arimasu / imasu (Noun is located at Place).",
            "4. Position words: ue (on/above), shita (under), mae (in front), ushiro (behind), migi (right), hidari (left), naka (inside), soto (outside), tonari (next to), chikaku (near), aida (between). Pattern: Noun1 no Position ni.",
            "5. Noun1 ya Noun2 [nado] (Non-exhaustive listing: N1, N2, and so on)."
        ],
        "key_vocabulary": "arimasu (exist/have inanimate), imasu (exist animate), iroiro [na] (various), otoko no hito (man), onna no hito (woman), otoko no ko (boy), onna no ko (girl), inu (dog), neko (cat), panda (panda), zou (elephant), ki (tree), mono (thing), denchi (battery), hako (box), suicchi (switch), reizouko (refrigerator), teeburu (table), beddo (bed), tana (shelf), doa (door), mado (window), posuto (mailbox), biru (building), kouen (park), kissaten (coffee shop), hon-ya (bookstore), ~ya (store of ~), noriba (taxi stand/platform), ken (prefecture), ue (on/above), shita (below/under), mae (front), ushiro (back/behind), migi (right), hidari (left), naka (inside), soto (outside), tonari (next to), chikaku (near), aida (between), ~ya (and such), nado (etc.).",
        "reference_text": "Lesson 10 Grammar Notes: Distinction between あります (inanimate objects: 車, 机, 花) and います (animate beings: 人, 犬, 先生). Pattern 1: [Place] に [Noun] が あります/います emphasizes what is at the place. Pattern 2: [Noun] は [Place] に あります/います emphasizes where the noun is. Position expressions combine nouns with の: 机の上に (on the desk), 箱の中に (inside the box). や lists examples non-exhaustively."
    },
    {
        "lesson": 11,
        "page_start": 86,
        "page_end": 93,
        "title": "Lesson 11: Counters, Quantifiers, Frequency (ni ~kai), and Time Periods",
        "grammar_points": [
            "1. Japanese counters: ~tsu (general objects 1-10: hitotsu, futatsu, mittsu...), ~nin (people), ~dai (machines/vehicles), ~mai (flat thin objects: paper, shirts), ~kai (times/frequency), ~hon (long cylindrical), ~hai (cups/glasses).",
            "2. Quantifier placement: usually placed immediately before the verb without particles (e.g. りんごを 4つ 買いました).",
            "3. Time period + ni + Quantifier + Verb (Frequency: 1 shukan ni 2 kai = twice a week).",
            "4. Quantifier + dake (Only / Just ~ : replaces or follows particles).",
            "5. dono kurai / dono gurai (Asking duration: How long?)."
        ],
        "key_vocabulary": "hitotsu (1), futatsu (2), mittsu (3), yottsu (4), itsutsu (5), muttsu (6), nanatsu (7), yattsu (8), kokonotsu (9), too (10), ikutsu (how many), hitori (1 person), futari (2 people), ~nin (people counter), ~dai (machine counter), ~mai (thin flat counter), ~kai (times), ringo (apple), mikan (mandarin orange), sandoicchi (sandwich), kareeraisu (curry rice), aisukuriimu (ice cream), kitte (postage stamp), hagaki (postcard), fuutou (envelope), sokutatsu (special delivery), kakitome (registered mail), koukuubin (airmail), funabin (surface/sea mail), ryoushin (parents), kyoudai (siblings), ani (my older brother), ane (my older sister), otouto (younger brother), imouto (younger sister), gaikoku (foreign country), ryuugakusei (international student), ~jikan (hours), ~shuukan (weeks), ~kagetsu (months), ~nen (years), dono kurai (how long), dake (only).",
        "reference_text": "Lesson 11 Grammar Notes: Japanese counters are directly placed before verbs (切手を2枚買いました). Universal ひとつ〜とお counters are used for general objects up to 10. Frequency per time span uses に: 1か月に2回映画を見ます. Quantifier + だけ indicates 'only': 休みは日曜日だけです."
    },
    {
        "lesson": 12,
        "page_start": 94,
        "page_end": 101,
        "title": "Lesson 12: Past Tense of Adjectives and Nouns, Comparisons (yori, dochira, ichiban)",
        "grammar_points": [
            "1. Past forms of Nouns & na-adjectives: ~deshita (affirmative), ~ja arimasen deshita (negative).",
            "2. Past forms of i-adjectives: ~katta desu (affirmative), ~kunakatta desu (negative). Exception: ii desu -> yokatta desu.",
            "3. Noun1 wa Noun2 yori Adjective desu (Noun1 is more Adj than Noun2).",
            "4. Noun1 to Noun2 to dochira ga Adjective desu ka (Which is more Adj, N1 or N2? -> N1 no hou ga Adj desu).",
            "5. Noun [no naka] de nan / doko / dare / itsu ga ichiban Adjective desu ka (Superlative: Which is the most Adj of all?)."
        ],
        "key_vocabulary": "kantan [na] (simple/easy), chikai (near), tooi (far), hayai (fast/early), osoi (slow/late), ooi [hito ga ooi] (many people), sukunai (few), atatakai (warm), suzushii (cool), amai (sweet), karai (spicy/hot), omoi (heavy), karui (light), ii (preferable/better), kisetsu (season), haru (spring), natsu (summer), aki (autumn), fuyu (winter), tenki (weather), ame (rain), yuki (snow), kumori (cloudy), hoteru (hotel), kuukou (airport), umi (sea/ocean), sekai (world), paatii (party), o-matsuri (festival), sukiyaki (sukiyaki), sashimi (sashimi), sushi (sushi), tenpura (tempura), ikebana (flower arrangement), momiji (red maple leaves), dochira (which of two), dochira mo (both), zutto (by far), hajimete (for the first time).",
        "reference_text": "Lesson 12 Grammar Notes: い-adjective past is formed by dropping い and adding かったです (寒かったです / 寒くなかったです). な-adjective and Noun past takes でした (暇でした / 暇じゃありませんでした). Comparison of two items: A は B より [Adj] です (A is more Adj than B). Choice: A と B と どちらが [Adj] ですか -> A のほうが [Adj] です. Superlative: [Category] の中で 〜 が いちばん [Adj] です."
    },
    {
        "lesson": 13,
        "page_start": 102,
        "page_end": 109,
        "title": "Lesson 13: Desires (hoshii, V-tai) and Purpose of Motion (Place e V-stem ni ikimasu)",
        "grammar_points": [
            "1. Noun ga hoshii desu (Wanting an object: Noun ga hoshii / hoshikunai desu).",
            "2. Verb-masu stem + tai desu (Wanting to do an action: tabetai / tabetakunai desu). Object can take 'ga' or 'o'.",
            "3. Place e Verb-masu stem / Noun ni ikimasu / kimasu / kaerimasu (Going to a place in order to do something — Purpose particle 'ni').",
            "4. doko ka (somewhere) / nanika (something) — Used without particles 'e' or 'o' in casual style.",
            "5. go-chuumon wa (May I take your order?)."
        ],
        "key_vocabulary": "asobimasu (play/enjoy oneself), oyogimasu (swim), mukaemasu (go to meet/welcome), tsukaremasu (get tired), dashimasu [tegami o] (send a letter), hairimasu [kissaten ni] (enter a coffee shop), demasu [kissaten o] (leave a coffee shop), kekkonshimasu (marry), kaimonoshimasu (do shopping), shokujishimasu (have a meal), sanposhimasu [kouen o] (take a walk in the park), taihen [na] (hard/tough), hoshii (want object), sabishii (lonely), hiroi (wide/spacious), semai (narrow/small), shiyakusho (city hall), puuru (swimming pool), kawa (river), keizai (economy), bijutsu (fine arts), tsuri (fishing), sukii (skiing), kaigi (meeting), touroku (registration), shuumatsu (weekend), nanika (something), dokoka (somewhere).",
        "reference_text": "Lesson 13 Grammar Notes: ほしい (want thing) behaves as an い-adjective (車がほしいです / ほしくないです). 〜たい (want to do) replaces 〜ます with 〜たいです (水を飲みたいです). Note: ほしい/〜たい are used for the speaker's own desires, not for third persons. Purpose of motion pattern: [Place] へ [V-ます stem / Noun] に 行きます (デパートへ買い物に行きます / 日本へ勉強に来ました)."
    },
    {
        "lesson": 14,
        "page_start": 110,
        "page_end": 117,
        "title": "Lesson 14: Verb Groups, Te-Form (て形) Conjugation, Requests (te kudasai), and In-Progress (te imasu)",
        "grammar_points": [
            "1. Verb Classification: Group 1 (Godan - end in u-sounds: i/chi/ri->tte, mi/bi/ni->nde, ki->ite, gi->ide, shi->shite), Group 2 (Ichidan - end in e/i before ru -> drop ru + te), Group 3 (Irregular: shimasu -> shite, kimasu -> kite).",
            "2. Verb-te kudasai (Polite requests: Please do ~).",
            "3. Verb-te imasu (Present Continuous action: currently doing ~).",
            "4. Verb-masu stem + mashou ka (Offering assistance: Shall I ~ for you?).",
            "5. Sentence1 ga, Sentence2 (Describing background situations)."
        ],
        "key_vocabulary": "tsukemasu (turn on), keshimasu (turn off), akemasu (open), shimemasu (close), isogimasu (hurry), machimasu (wait), tomemasu (stop/park), magarimasu [migi e] (turn right), mochimasu (hold/carry), torimasu (take/pass), tetsudaimasu (help/assist), yobimasu (call), hanashimasu (speak), misemasu (show), oshiemasu [juusho o] (tell/teach address), hajimemasu (begin), furimasu [ame ga] (rain falls), kopiishimasu (photocopy), eakon (air conditioner), pasupooto (passport), namae (name), juusho (address), chizu (map), shio (salt), satou (sugar), yomi-kata (how to read), ~kata (way of doing), yukkuri (slowly), mou ichido (once more), mata (again), ato de (later), mou sukoshi (a little more).",
        "reference_text": "Lesson 14 Grammar Notes: The て-form is the foundational verb conjugation in Japanese. Group 1: い・ち・り -> って (買って, 待って, 帰って); み・び・に -> んで (飲んで, 呼んで, 死んで); き -> いて (書いて; exception: 行って); ぎ -> いで (急いで); し -> して (話して). Group 2: drop ます add て (食べて, 見て). Group 3: して, 来て (きて). Requests: 〜てください (書いてください). Ongoing action: 〜ています (今雨が降っています). Offering help: 〜ましょうか (手伝いましょうか)."
    },
    {
        "lesson": 15,
        "page_start": 118,
        "page_end": 125,
        "title": "Lesson 15: Permissions (te mo ii desu), Prohibitions (te wa ikemasen), and Resulting States (te imasu)",
        "grammar_points": [
            "1. Verb-te mo ii desu ka (Asking permission: May I do ~ ?). Answer: hai, ii desu / sumimasen ga...",
            "2. Verb-te wa ikemasen (Strict prohibition: You must not do ~ / Do not ~).",
            "3. Verb-te imasu (Resulting continuous state: kekkon shite imasu, sunde imasu, motte imasu, shitte imasu).",
            "4. shitte imasu vs. shirimasen (Negative of 'know' is always 知りません, never 知っていません).",
            "5. Group/Company de hataraite imasu / benkyou shite imasu."
        ],
        "key_vocabulary": "okimasu (put/place), tsukurimasu (make/produce), urimasu (sell), shirimasu (get to know), sumimasu [Toukyou ni] (live/reside), kenkyuushimasu (research), shitte imasu (know), sunde imasu (live in), shiryou (materials/data), katarogu (catalogue), jikokuhyou (timetable), fuku (clothes), seihin (products), sofuto (software), denshijisho (electronic dictionary), keizai (economy), shiyakusho (city hall), koukou (high school), haisha (dentist), dokushin (single/unmarried), sumimasen (excuse me/sorry).",
        "reference_text": "Lesson 15 Grammar Notes: Permission: Verb-てもいいですか (ここで写真を撮ってもいいですか). Prohibition: Verb-てはいけません (ここでタバコを吸ってはいけません). Continuous state verbs with 〜ています include 結婚しています (married), 知っています (know), 持っています (possess), 住んでいます (live in). Note: Negative of 知っています is 知りません."
    },
    {
        "lesson": 16,
        "page_start": 126,
        "page_end": 133,
        "title": "Lesson 16: Sequential Actions (V1-te, V2-te), Adjective Chains (kute, de), and (V-te kara)",
        "grammar_points": [
            "1. Verb1-te, Verb2-te, ... Verb_final (Connecting sequential actions chronologically).",
            "2. i-adj (-kute) / na-adj (-de) / Noun (de) (Connecting multiple adjectives or descriptions).",
            "3. Verb1-te kara, Verb2 (After doing V1, then do V2).",
            "4. Noun1 wa Noun2 ga Adjective desu (Topic-attribute description: Maria-san wa kami ga nagai desu).",
            "5. douyatte (How / By what means do you get to ~ ?)."
        ],
        "key_vocabulary": "norimasu [densha ni] (ride/get on train), orimasu [densha o] (get off train), norikaemasu (transfer trains), abimasu [shawaa o] (take a shower), iremasu (put in/insert), dashimasu (take out/withdraw money), oroshimasu [okane o] (withdraw money), hairimasu [daigaku ni] (enter university), demasu [daigaku o] (graduate university), oshimasu (push/press), nomimasu [o-sake o] (drink alcohol), hajimemasu (start), kengakushimasu (tour/visit study), renraku shimasu (contact), wakai (young), nagai (long), mijikai (short), akarui (bright), kurai (dark), se ga takai (tall stature), atama ga ii (smart/clever), karada (body), atama (head), kami (hair), kao (face), me (eye), mimi (ear), hana (nose), kuchi (mouth), ha (tooth), onaka (stomach), ashi (leg/foot), saabisu (service), jogingu (jogging), shawaa (shower), midori (greenery), o-tera (temple), jinja (shrine), douyatte (how/in what way), dono ~ (which ~).",
        "reference_text": "Lesson 16 Grammar Notes: Connect consecutive actions using 〜て: 朝ジョギングをして、シャワーを浴びて、会社へ行きます. Connect い-adjectives by replacing い with くて (安くて、おいしいです). Connect な-adjectives and nouns with で (親切で、きれいです). 〜てから emphasizes that action 2 starts only after action 1 is completed (国へ帰ってから、父の会社で働きます). Topic-Feature: 象は鼻が長いです."
    },
    {
        "lesson": 17,
        "page_start": 134,
        "page_end": 141,
        "title": "Lesson 17: Nai-Form (ない形), Negative Requests (nai de kudasai), Obligations (nakereba narimasen)",
        "grammar_points": [
            "1. Verb Nai-Form (ない形) Conjugation: Group 1 (a-sound + nai: kakanai, nomanai; exception: au -> awanai), Group 2 (drop ru + nai: tabenai, minai), Group 3 (shinai, konai).",
            "2. Verb-nai de kudasai (Please do not ~).",
            "3. Verb-nakereba narimasen (Must do / Obligation: literally 'if you don't do it, it won't do').",
            "4. Verb-naku te mo ii desu (Do not have to / Need not do ~).",
            "5. Object wa + Verb (Emphasizing object as topic: shukudai wa ashita dashite kudasai)."
        ],
        "key_vocabulary": "oboemasu (memorize), wasuremasu (forget), nakushimasu (lose), haraimasu (pay), kaeshimasu (give back/return), dekakemasu (go out), nugimasu (take off clothes/shoes), motte ikimasu (take something along), motte kimasu (bring something along), shinpaishimasu (worry), zangyoushimasu (work overtime), shucchoushimasu (go on business trip), nomimasu [kusuri o] (take medicine), hairimasu [o-furo ni] (take a bath), taisetsu [na] (important/precious), daijoubu [na] (all right/OK), abunai (dangerous), kin'en (no smoking), kenkou hokenshou (health insurance card), netsu (fever), byouki (illness), kusuri (medicine), o-furo (bath), uwagi (jacket), shitagi (underwear), 2-3 nichi (two or three days), ~made ni (by / before time limit).",
        "reference_text": "Lesson 17 Grammar Notes: ない-form rules: Group 1 changes terminal 'u' to 'a' + ない (書く -> 書かない; 話す -> 話さない; 買う -> 買わない). Group 2 drops る + ない (食べる -> 食べない). Group 3: する -> しない, 来る -> こない. Negative requests: 〜ないでください (写真を撮らないでください). Obligation (Must): 〜なければなりません (薬を飲まなければなりません). Lack of obligation: 〜なくてもいいです (靴を脱がなくてもいいです)."
    },
    {
        "lesson": 18,
        "page_start": 142,
        "page_end": 149,
        "title": "Lesson 18: Dictionary Form (辞書形), Potential (koto ga dekimasu), Hobbies, and (mae ni)",
        "grammar_points": [
            "1. Verb Dictionary Form (辞書形 - Plain non-past affirmative): Group 1 (u-sound: kaku, yomu), Group 2 (ru-sound: taberu, miru), Group 3 (suru, kuru).",
            "2. Noun / Verb-dict + koto ga dekimasu (Can do / Potential ability or situational possibility).",
            "3. watashi no shumi wa Noun / Verb-dict + koto desu (My hobby is doing ~).",
            "4. Verb1-dict / Noun no / Time period + mae ni, Verb2 (Before doing V1 / noun / time, do V2).",
            "5. nakanaka + negative (Not easily / Hard to ~) ; zehi (By all means / Definitely)."
        ],
        "key_vocabulary": "dekimasu (can do/be able), araimasu (wash), hikimasu [piano o] (play piano), utaimasu (sing), atsumemasu (collect/gather), sutemasu (throw away), kaemasu (exchange/change), untenshimasu (drive), yoyakushimasu (reserve), kengakushimasu (visit for study), piano (piano), ~meetoru (meters), kokusai~ (international ~), genkin (cash), shumi (hobby), nikki (diary), o-inori (prayer), kachou (section chief), buchou (department manager), shachou (company president), doubutsu (animal), uma (horse), nakanaka (not easily), zehi (by all means).",
        "reference_text": "Lesson 18 Grammar Notes: 辞書形 (Dictionary form) is the base plain form found in dictionaries. Nominalizing verbs using こと: [V-dict] + ことができます expresses ability/possibility (日本語を話すことができます / 漢字を読むことができます). Hobbies: 趣味は写真を撮ることです. Time sequencing with 前に: [V1-dict] まえに、V2 (寝る前に、本を読みます / 食事の前に、手を洗います)."
    },
    {
        "lesson": 19,
        "page_start": 150,
        "page_end": 157,
        "title": "Lesson 19: Ta-Form (た形), Past Experience (koto ga arimasu), Alternating Actions (tari), Becoming (narimasu)",
        "grammar_points": [
            "1. Verb Ta-Form (た形 - Plain past affirmative): Follows the exact same phonetic change rules as Te-form (て -> た, で -> だ).",
            "2. Verb-ta koto ga arimasu (Have the experience of doing ~). Negative: ~koto ga arimasen.",
            "3. Verb1-tari, Verb2-tari shimasu (Listing non-exhaustive alternating actions: do things like V1 and V2).",
            "4. i-adj (-ku) / na-adj (-ni) / Noun (-ni) + narimasu (To become / Change in state: samuku narimasu, jouzu ni narimasu).",
            "5. sou desu ne (Sympathetic agreement)."
        ],
        "key_vocabulary": "noborimasu [yama ni] (climb mountain), tomarimasu [hoteru ni] (stay at hotel), soujishimasu (clean a room), sentakushimasu (wash clothes), renshuushimasu (practice), narimasu (become), nemui (sleepy), tsuyoi (strong), yowai (weak), choushi ga ii (in good condition), choushi ga warui (in bad condition), ichido (once), ichido mo (never / not once), dandan (gradually), mou sugu (soon), o-kagesama de (thanks to you), kanpai (cheers), daietto (diet), o-cha (tea ceremony), pachinko (pachinko).",
        "reference_text": "Lesson 19 Grammar Notes: た-form conjugates identically to て-form (買った, 飲んだ, 書いた, 食べた, した, 来た). Past experience: [V-た] ことがあります (日本へ行ったことがあります / 富士山に登ったことがあります). Representative actions: [V1-たり]、[V2-たり] します (日曜日は掃除したり、洗濯したりします). Becoming/Change of state: い-adj drops い + くなります (寒くなります); な-adj and Nouns take に + なります (元気に成ります / 20歳になります)."
    },
    {
        "lesson": 20,
        "page_start": 158,
        "page_end": 167,
        "title": "Lesson 20: Plain Style (普通体) vs. Polite Style (丁寧体) and Casual Speech Rules",
        "grammar_points": [
            "1. Register distinction: Teinei-tai (丁寧体 - desu/masu for formal/polite conversations) vs. Futsuu-tai (普通体 - plain forms for family, close friends, notes, articles).",
            "2. Conjugation Chart for Plain Style: Verbs (dict, nai, ta, nakatta), i-adj (i, kunai, katta, kunakatta), na-adj/Noun (da, ja nai, datta, ja nakatta).",
            "3. Conversational modifications in Plain Style: Question particle 'ka' dropped with rising intonation; Particle 'wa', 'o', 'e' often dropped; 'te iru' contracted to 'teru'.",
            "4. Affirmative answers use 'un', negative answers use 'uun'."
        ],
        "key_vocabulary": "irimasu [biza ga] (need a visa), shirabemasu (check/investigate), naoshimasu (repair/correct), shu президент (repair), denwa shimasu (phone), boku (I - casual male), kimi (you - casual), ~kun (casual male title), un (yeah/yes), uun (nah/no), kotoba (word/language), kimono (kimono), biza (visa), hajime (beginning), owari (end), kocchi (here), socchi (there), acchi (over there), docchi (which), minna de (all together), ~kedo (although/but casual).",
        "reference_text": "Lesson 20 Grammar Notes: 普通体 (Plain Style) is essential for casual speech and embedded clauses. Nouns/な-adj in non-past affirmative take だ (暇だ), past affirmative だった (暇だった), negative じゃない, past negative じゃなかった. In questions, だ is omitted with rising intonation (明日暇？). うん represents はい and ううん represents いいえ."
    },
    {
        "lesson": 21,
        "page_start": 168,
        "page_end": 175,
        "title": "Lesson 21: Opinions (to omoimasu), Quotations (to iimashita), and Confirmation (deshou)",
        "grammar_points": [
            "1. Plain form + to omoimasu (I think that ~ : expressing thoughts, opinions, or guesses).",
            "2. Plain form / Direct quote + to iimashita (Said that ~ : reported speech).",
            "3. Plain form + deshou? (Right? / Isn't it? : seeking agreement with rising intonation).",
            "4. Place de Event ga arimasu (An event/party/concert takes place in a location — uses particle 'de').",
            "5. Noun (occasion) de (At the occasion of ~ : Nihon de, shiai de)."
        ],
        "key_vocabulary": "omoimasu (think), iimasu (say), tarimasu (be enough), kachimasu (win), makemasu (lose), arimasu [o-matsuri ga] (take place), yakunitachimasu (be useful), ugokimasu (move/work), yamemasu [kaisha o] (quit company), ki o tsukemasu (pay attention), ryuugakushimasu (study abroad), muda [na] (wasteful), fuben [na] (inconvenient), sugoi (terrific/great), hontou (truth), uso (lie), jidousha (car), koutsuu (traffic), bukka (prices/cost of living), housou (broadcast), nyuusu (news), anime (anime), manga (manga), dezain (design), yume (dream), tensai (genius), shiai (game/match), iken (opinion), o-hanashi (story/talk), chikyuu (earth), tsuki (moon), saikin (recently), tabun (probably), kitto (surely), hontou ni (really), sonna ni (not so much).",
        "reference_text": "Lesson 21 Grammar Notes: Quotation particle と embeds plain form clauses. Expressing opinion: [Plain form] と思います (日本は物価が高いと思います / 明日雨が降ると思います). Direct/Indirect quotation: [Quote / Plain form] と言いました (田中さんは明日休むと言いました). Seeking agreement: 〜でしょう (明日のパーティーに行くでしょう？)."
    },
    {
        "lesson": 22,
        "page_start": 176,
        "page_end": 183,
        "title": "Lesson 22: Relative Clauses & Noun Modification (Plain form verbs modifying Nouns)",
        "grammar_points": [
            "1. Relative clause syntax: Japanese relative clauses precede the noun directly without relative pronouns (who, which, that).",
            "2. Verb [Plain form] + Noun (The noun that does / did / doesn't do ~ : watashi ga tsukutta keeki).",
            "3. Subject particle in relative clause: Subject inside the qualifying clause takes 'ga', never 'wa'.",
            "4. [Verb Plain + Noun] wa Noun/Adj desu (The person who is reading a book is Mr. Miller).",
            "5. [Verb Plain] jikan / yakusoku / youji (Time/appointment/errand to do ~)."
        ],
        "key_vocabulary": "kimasu [fuku o] (put on shirt/upper body), hakimasu [kutsu o] (put on shoes/pants), kaburimasu [boushi o] (put on hat), kakemasu [megane o] (put on glasses), tsukemasu [tokei o] (put on watch), umaremasu (be born), watashitachi (we), kouto (coat), seetaa (sweater), suutsu (suit), boushi (hat), megane (glasses), keeki (cake), o-bentou (boxed lunch), juutaku (housing), apaato (apartment), yakusoku (promise/appointment), anou (well/let me see), omedetou gozaimasu (congratulations).",
        "reference_text": "Lesson 22 Grammar Notes: Relative clauses in Japanese are placed immediately before the noun they modify. The verb inside the relative clause must be in Plain Form (普通形). Example: これは [ミラーさんが作った] ケーキです (This is the cake that Mr. Miller made). The subject inside the clause is marked with が: [私が昨日読んだ] 本. Expressing time/plans: 朝ごはんを食べる時間がありません."
    },
    {
        "lesson": 23,
        "page_start": 184,
        "page_end": 193,
        "title": "Lesson 23: Time Clauses (toki - when) and Natural Conditionals (to - when/if)",
        "grammar_points": [
            "1. Verb [Dict / Nai / Ta form] + toki, ... (When doing / not doing / having done ~).",
            "2. i-adj + toki / na-adj + na + toki / Noun + no + toki (When it is Adj / Noun).",
            "3. Verb-dict + to, ... (Natural conditional / Inevitable consequence: When X happens, Y always follows automatically — e.g. turning a knob, road directions).",
            "4. Noun o + Motion Verb (Motion through / along a place takes particle 'o': michi o watarimasu, kouen o sanposhimasu)."
        ],
        "key_vocabulary": "kikimasu [sensei ni] (ask teacher), mawashimasu (turn/rotate), hikimasu (pull), kaemasu (change), sawarimasu [doa ni] (touch door), demasu [o-tsuri ga] (change comes out), arukimasu (walk), watarimasu [hashi o] (cross bridge), magarimasu [migi e] (turn right), sabishii (lonely), yu (hot water), oto (sound), saizu (size), koshou (breakdown), michi (road/street), kousaten (intersection), shingou (traffic light), kado (corner), hashi (bridge), chuushajou (parking lot), shou-gatsu (New Year), go-chisousama deshita (thank you for the meal).",
        "reference_text": "Lesson 23 Grammar Notes: とき (when) connects time conditions: [V-dict] とき (before/in the process of action); [V-た] とき (after completing action): 国へ帰るとき、かばんを買いました (bought bag before going home) vs. 国へ帰ったとき、かばんを買いました (bought bag after arriving home). [V-dict] + と indicates inevitable result or machine operation (このボタンを押すと、お釣りが出ます / 右へ曲がると、郵便局があります). Motion across a path uses を (道を渡ります)."
    },
    {
        "lesson": 24,
        "page_start": 194,
        "page_end": 203,
        "title": "Lesson 24: Giving and Receiving Favors (kuremasu, te agemasu, te moraimasu, te kuremasu)",
        "grammar_points": [
            "1. Person ga watashi ni Noun o kuremasu (Someone gives something to me or my in-group family member).",
            "2. Verb-te agemasu (Do a favor for someone: doing an action for another person's benefit).",
            "3. Verb-te moraimasu (Receive the favor of someone doing an action for oneself).",
            "4. Person ga [watashi ni] Verb-te kuremasu (Someone kindly does an action for me or my family).",
            "5. Interrogative subject takes 'ga': dare ga tetsudatte kuremashita ka."
        ],
        "key_vocabulary": "kuremasu (give to me), naoshimasu (repair/correct), tsurete ikimasu (take someone along), tsurete kimasu (bring someone along), okurimasu [hito o] (see someone off/drive home), shoukaishimasu (introduce), annaishimasu (guide/show around), setsumeishimasu (explain), o-jiisan / ojiisan (grandfather), o-baasan / obaasan (grandmother), junbi (preparation), hikkoshi (moving house), o-kashi (sweets/snacks), houmusutei (homestay), zenbu (all), jibun de (by oneself), hoka ni (besides).",
        "reference_text": "Lesson 24 Grammar Notes: Benefactive verbs express doing/receiving favors. くれます indicates someone gives to me/my in-group (山田さんは私に時計をくれました). 〜てあげます expresses doing something for someone (友達の荷物を持ってあげました). 〜てもらいます expresses having someone do something for you (私は山田さんに日本語を教えてもらいました). 〜てくれます expresses someone doing something for me with gratitude (母は私にお弁当を作ってくれました)."
    },
    {
        "lesson": 25,
        "page_start": 204,
        "page_end": 212,
        "title": "Lesson 25: Conditionals (tara - if/when) and Concessives (temo - even if)",
        "grammar_points": [
            "1. Verb [Ta-form] + ra (〜たら : General conditional 'if' or temporal 'when/after').",
            "2. i-adj (-kattara) / na-adj (-dattara) / Noun (-dattara) (If it is Adj / Noun).",
            "3. moshimo / moshi ~tara (Emphasizing 'in the hypothetical case that...').",
            "4. Verb [Te-form] + mo (〜ても : Concessive conditional 'even if / even though').",
            "5. i-adj (-kutemo) / na-adj (-demo) / Noun (-demo) (Even if it is Adj / Noun).",
            "6. ikura ~temo (No matter how much / even if ~)."
        ],
        "key_vocabulary": "kangaemasu (think/consider), tsukimasu [eki ni] (arrive at station), ryuugakushimasu (study abroad), torimasu [toshi o] (grow older), inaka (countryside/hometown), taishikan (embassy), guruupu (group), chansu (chance), oku (hundred million), moshi [~tara] (if), ikura [~temo] (however much), tenkin (job relocation), koto (matter/thing), ganbarimasu (do one's best), douzo o-genki de (please take care of yourself).",
        "reference_text": "Lesson 25 Grammar Notes: 〜たら is the most versatile conditional in Japanese. It is formed by adding ら to the た-form (雨が降ったら、出かけません / 安かったら、買います / 暇だったら、遊びに来てください). It also expresses 'when/after' for guaranteed future occurrences (10時になったら、出かけましょう). 〜ても expresses concessive 'even if' (雨が降っても、出かけます / 高くても、買います / 日曜日でも、働きます)."
    }
]


class PageExtractorService:
    """Core Page-Range Extractor for KamiSensei Japanese Protocol."""

    def __init__(self, knowledge_dir: Optional[Path] = None):
        self.knowledge_dir = Path(knowledge_dir or KNOWLEDGE_BASE_DIR)
        os.makedirs(self.knowledge_dir, exist_ok=True)

    def detect_page_query(self, query: str) -> Optional[int]:
        """Detects if a user query explicitly asks about a page number.
        Matches patterns like:
        - "Page 45", "page 110", "p. 45", "p45", "Page45"
        - "explain page 14", "what is on page 20"
        - "lesson 5", "chapter 14" -> maps to starting page
        """
        if not query:
            return None

        # Direct page patterns: "Page 45", "p. 45", "p45", "pg 45", "page: 45"
        page_match = re.search(r'\b(?:page|pg|p\.?|p)\s*[:#]?\s*(\d+)\b', query, re.IGNORECASE)
        if page_match:
            try:
                page_num = int(page_match.group(1))
                if 1 <= page_num <= 500:
                    return page_num
            except ValueError:
                pass

        # Lesson number patterns: "Lesson 14", "Lesson14", "L14", "Ch 14"
        lesson_match = re.search(r'\b(?:lesson|chapter|dai)\s*[:#]?\s*(\d+)\b', query, re.IGNORECASE)
        if lesson_match:
            try:
                lesson_num = int(lesson_match.group(1))
                for l_data in MINNA_NO_NIHONGO_LESSON_MAP:
                    if l_data["lesson"] == lesson_num:
                        return l_data["page_start"]
            except ValueError:
                pass

        return None

    def find_target_pdf(self, source_hint: Optional[str] = None) -> Optional[Path]:
        """Finds the most appropriate PDF in knowledge_base."""
        if not self.knowledge_dir.exists():
            return None

        pdf_files = list(self.knowledge_dir.glob("*.pdf"))
        if not pdf_files:
            return None

        if source_hint:
            clean_hint = source_hint.lower().strip()
            for pdf in pdf_files:
                if clean_hint in pdf.name.lower():
                    return pdf

        # Default to the primary Japanese textbook in knowledge base
        for pdf in pdf_files:
            if "minna" in pdf.name.lower() or "genki" in pdf.name.lower() or "nihongo" in pdf.name.lower():
                return pdf

        return pdf_files[0]

    def extract_page_range(
        self,
        pdf_path: Path,
        start_page: int,
        page_count: int = 3
    ) -> Dict[str, Any]:
        """Extracts text for target page + next 2 sequential pages (e.g. P, P+1, P+2).
        Returns full unchunked text block with metadata.
        """
        if not pdf_path.exists():
            return {"ok": False, "error": f"PDF not found at {pdf_path}"}

        target_pages = [start_page + i for i in range(page_count)]
        extracted_pages_data = []
        raw_text_parts = []
        has_any_extracted_text = False

        try:
            try:
                import pymupdf as fitz
            except ImportError:
                import fitz

            doc = fitz.open(str(pdf_path))
            total_doc_pages = len(doc)

            for p_num in target_pages:
                if 1 <= p_num <= total_doc_pages:
                    try:
                        page_obj = doc[p_num - 1]
                        text = (page_obj.get_text("text") or "").strip()
                        if not text and page_obj.get_images(full=True) and os.getenv("KAMISENSEI_OCR_ENABLED", "1") != "0":
                            try:
                                language = os.getenv("KAMISENSEI_OCR_LANG", "eng+jpn")
                                dpi = max(72, min(int(os.getenv("KAMISENSEI_OCR_DPI", "150")), 300))
                                text_page = page_obj.get_textpage_ocr(language=language, dpi=dpi, full=True)
                                text = (page_obj.get_text("text", textpage=text_page) or "").strip()
                            except Exception as ocr_err:
                                logger.warning("OCR failed for page %s of %s: %s", p_num, pdf_path.name, ocr_err)
                        if text:
                            has_any_extracted_text = True
                        extracted_pages_data.append({
                            "page": p_num,
                            "text": text,
                            "has_text": bool(text)
                        })
                        raw_text_parts.append(f"--- [Page {p_num} of {pdf_path.name}] ---\n{text if text else '[Scanned Document Image Page]'}")
                    except Exception as p_err:
                        logger.warning(f"Failed to read page {p_num}: {p_err}")
            doc.close()
        except Exception as exc:
            logger.error(f"PyMuPDF extraction failed for {pdf_path.name}: {exc}")

        # Only return text actually extracted from the source. Curriculum maps
        # are navigation hints, not citation evidence, and must never be injected
        # as if they came from a scanned page.
        combined_text = "\n\n".join(raw_text_parts) if has_any_extracted_text else ""

        source_tag = f"[Source: {pdf_path.name}, Pages {target_pages[0]}-{target_pages[-1]}]"

        return {
            "ok": True,
            "source": pdf_path.name,
            "start_page": start_page,
            "pages_extracted": target_pages,
            "source_tag": source_tag,
            "text": combined_text,
            "has_raw_text": has_any_extracted_text,
            "has_lesson_reference": False
        }

    def _get_lesson_knowledge_for_pages(self, start_page: int, target_pages: List[int]) -> str:
        """Finds lesson curriculum matching the given page range."""
        relevant_lessons = []
        for l_data in MINNA_NO_NIHONGO_LESSON_MAP:
            # Check if any target page falls within lesson page range
            if any(l_data["page_start"] <= p <= l_data["page_end"] for p in target_pages) or \
               (l_data["page_start"] <= start_page <= l_data["page_end"]):
                relevant_lessons.append(l_data)

        if not relevant_lessons:
            # Fallback to closest lesson
            closest = min(MINNA_NO_NIHONGO_LESSON_MAP, key=lambda x: abs(x["page_start"] - start_page))
            relevant_lessons = [closest]

        sections = []
        for l in relevant_lessons:
            sec = [
                f"### {l['title']} (Book Pages {l['page_start']}-{l['page_end']})",
                f"GRAMMAR PATTERNS & PARTICLE USAGE:",
                "\n".join(l["grammar_points"]),
                f"\nKEY VOCABULARY & EXPRESSIONS:\n{l['key_vocabulary']}",
                f"\nDETAILED GRAMMATICAL EXPLANATIONS & NOTES:\n{l['reference_text']}"
            ]
            sections.append("\n".join(sec))

        return "\n\n".join(sections)

    def get_page_context(
        self,
        query: str,
        source_hint: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """High-level entrypoint: if query asks for a page, returns full 3-page unchunked text block."""
        page_num = self.detect_page_query(query)
        if not page_num:
            return None

        target_pdf = self.find_target_pdf(source_hint)
        if not target_pdf:
            logger.warning("Page query requested page %s, but no physical PDF source exists.", page_num)
            return None

        return self.extract_page_range(target_pdf, page_num, page_count=3)


# Global singleton
page_extractor = PageExtractorService()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="KamiSensei Page-Range Extractor")
    parser.add_argument("--page", type=int, help="Target page number to extract (extracts page + next 2 pages)")
    parser.add_argument("--query", type=str, help="Query string containing a page reference")
    parser.add_argument("--source", type=str, help="Specific source filename hint")
    parser.add_argument("--json", action="store_true", help="Output JSON")

    args = parser.parse_args()
    service = PageExtractorService()

    if args.query:
        res = service.get_page_context(args.query, source_hint=args.source)
        if args.json:
            print(json.dumps(res or {}, indent=2))
        else:
            if res:
                print(f"Extracted: {res['source_tag']}\n" + "="*50)
                print(res["text"][:1000] + "...")
            else:
                print("No page reference detected in query.")
    elif args.page:
        target_pdf = service.find_target_pdf(args.source)
        if target_pdf:
            res = service.extract_page_range(target_pdf, args.page, page_count=3)
            if args.json:
                print(json.dumps(res, indent=2))
            else:
                print(f"Extracted: {res['source_tag']}\n" + "="*50)
                print(res["text"][:1000] + "...")
        else:
            print("No PDF found in knowledge_base.")


if __name__ == "__main__":
    main()
