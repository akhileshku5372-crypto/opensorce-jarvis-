/* JARVIS two-hand gesture control
 * ---------------------------------------------------------------------------
 * This file is the real-time half of the Hand Tracking feature that already
 * lives in the JARVIS dashboard. app.js still owns the one camera stream and
 * the UI entry points; this controller owns landmark interpretation, pointer
 * motion, deterministic gesture actions, custom mappings and diagnostics.
 *
 * Design rules (kept deliberately strict):
 *  - One MediaPipe Hands instance, reused. The camera is never re-opened just
 *    because tracking was paused or stopped.
 *  - No AI call is made in the control loop. Every immediate action is local
 *    and deterministic.
 *  - A gesture never reaches a destructive action on its own. Sensitive DOM
 *    targets and password fields are refused; UI Automation refuses controls
 *    whose accessible name is destructive.
 *  - Every number shown in the UI is measured here. There is no invented
 *    latency, FPS or confidence.
 *
 * The pure part below is exposed as window.__JARVIS_GESTURE_ENGINE__ so the
 * headless tests exercise the shipped math, not a copy of it.
 */
(function (root) {
  'use strict'

  var VERSION = '2.1.0'
  var clamp = function (value, low, high) { return Math.max(low, Math.min(high, value)) }
  var distance = function (a, b) { return Math.hypot(a.x - b.x, a.y - b.y) }
  // MediaPipe reports z in roughly the same scale as x, and a hand that points
  // AT the screen is heavily foreshortened: the index tip collapses towards the
  // wrist in the image plane exactly when the finger is most extended. Measuring
  // fingers and pinch gaps in 3D removes that whole class of misclassification.
  var distance3 = function (a, b) {
    var dz = (typeof a.z === 'number' && typeof b.z === 'number') ? a.z - b.z : 0
    return Math.hypot(a.x - b.x, a.y - b.y, dz)
  }

  var PROFILES = {
    precision: {
      label: 'Precision',
      sensitivity: 1.05,
      smoothing: 0.72,
      deadzone: 0.009,
      minCutoff: 0.55,
      beta: 0.008,
      scrollGain: 0.7,
      zoomGain: 0.9
    },
    balanced: {
      label: 'Balanced',
      sensitivity: 1.35,
      smoothing: 0.5,
      deadzone: 0.006,
      minCutoff: 1.2,
      beta: 0.02,
      scrollGain: 1,
      zoomGain: 1.2
    },
    fast: {
      label: 'Fast navigation',
      sensitivity: 1.85,
      smoothing: 0.24,
      deadzone: 0.003,
      minCutoff: 2.8,
      beta: 0.05,
      scrollGain: 1.4,
      zoomGain: 1.6
    }
  }

  var DEFAULT_CONFIG = {
    profile: 'balanced',
    pointerHand: 'right',
    sensitivity: PROFILES.balanced.sensitivity,
    smoothing: PROFILES.balanced.smoothing,
    deadzone: PROFILES.balanced.deadzone,
    minCutoff: PROFILES.balanced.minCutoff,
    beta: PROFILES.balanced.beta,
    scrollGain: PROFILES.balanced.scrollGain,
    zoomGain: PROFILES.balanced.zoomGain,
    minHandConfidence: 0.6,
    clickConfidence: 0.66,
    // 0.42 (the old default) is far looser than a real pinch. On a real hand the
    // wrist->middle-MCP span is about 9-10 cm, so 0.42 allowed the thumb tip to
    // sit 4 cm from the index tip: a normal pointing hand (thumb resting beside
    // the index) measured ~0.35 and was classified as a pinch, which fired
    // clicks nobody asked for. 0.30 is about 2.5-3 cm, and pinchOff adds the
    // hysteresis that stops the state flickering on the threshold itself.
    pinchOn: 0.3,
    pinchOff: 0.42,
    stableFrames: 2,
    clickCooldownMs: 700,
    armDelayMs: 420,
    // Pinch = press-release. Released quickly without moving => click; held or
    // moved => drag. These three numbers decide which.
    dragHoldMs: 380,
    clickMaxMove: 16,
    clickWindowMs: 900,
    // A closed fist that travels this much (normalized landmark units) turns
    // into one wheel notch.
    fistScrollStep: 0.035,
    motionStill: 0.32,
    semantic: true,
    semanticClicks: false,
    semanticHoldMs: 520
  }

  // A label is sensitive when one of these words stands alone. The explicit
  // non-letter lookarounds (instead of \b) also catch "delete_all" while
  // leaving "Unlock" and "Clock settings" alone.
  var SENSITIVE_LIST = 'delete|remove|uninstall|erase|format|purchase|buy|checkout|pay|transfer|' +
    'send|submit|confirm|approve|allow|grant|admin|password|shutdown|restart|reboot|' +
    'clear|wipe|lock|sleep|hibernate|sign out|log out|log off|turn off|power off|' +
    'factory reset|reset all'
  var SENSITIVE_WORDS = new RegExp('(?:^|[^A-Za-z])(?:' + SENSITIVE_LIST + ')(?![A-Za-z])', 'i')
  var SENSITIVE_UNICODE = /(?:हटाएं|मिटाएं|डिलीट|भेजें|खरीदें|भुगतान|रीस्टार्ट|बंद करें|削除|送信|購入|支払|再起動|ログアウト)/

  function isSensitiveLabel(text) {
    var value = String(text || '').trim()
    if (!value) return false
    return SENSITIVE_WORDS.test(value) || SENSITIVE_UNICODE.test(value)
  }

  function fingersUp(lm) {
    if (!lm || lm.length < 21) return [0, 0, 0, 0, 0]
    var wrist = lm[0]
    var size = Math.max(0.001, distance3(lm[0], lm[9]))
    var thumb = (distance3(lm[4], lm[5]) / size > 0.95 && distance3(lm[4], lm[0]) / size > 1.1) ? 1 : 0
    var up = [thumb]
    var pairs = [[8, 6, 5], [12, 10, 9], [16, 14, 13], [20, 18, 17]]
    for (var i = 0; i < pairs.length; i += 1) {
      var tip = lm[pairs[i][0]]
      var pip = lm[pairs[i][1]]
      var tipFromWrist = distance3(tip, wrist)
      var pipFromWrist = distance3(pip, wrist)
      up.push(tipFromWrist / size > 1.35 && tipFromWrist > pipFromWrist * 1.08 ? 1 : 0)
    }
    return up
  }

  function handPose(lm, config) {
    var cfg = config || DEFAULT_CONFIG
    var up = fingersUp(lm)
    var size = Math.max(0.001, distance3(lm[0], lm[9]))
    var pinchI = distance3(lm[4], lm[8]) / size
    var pinchM = distance3(lm[4], lm[12]) / size
    var pinchR = distance3(lm[4], lm[16]) / size
    var pinchP = distance3(lm[4], lm[20]) / size
    var four = up[1] + up[2] + up[3] + up[4]
    return {
      up: up,
      extended: four,
      size: size,
      pinchI: pinchI,
      pinchM: pinchM,
      pinchR: pinchR,
      pinchP: pinchP,
      pointing: up[1] === 1 && up[2] === 0 && up[3] === 0 && up[4] === 0,
      palm: four === 4,
      fist: four === 0,
      peace: up[1] === 1 && up[2] === 1 && up[3] === 0 && up[4] === 0,
      three: up[1] === 1 && up[2] === 1 && up[3] === 1 && up[4] === 0,
      thumbsUp: four === 0 && up[0] === 1,
      ok: pinchI < cfg.pinchOn && up[2] === 1 && up[3] === 1 && up[4] === 1,
      pinchDouble: pinchR < cfg.pinchOn && pinchI > cfg.pinchOff && pinchM > cfg.pinchOff,
      palmPos: {
        x: (lm[0].x + lm[5].x + lm[17].x) / 3,
        y: (lm[0].y + lm[5].y + lm[17].y) / 3
      }
    }
  }

  function classifyPose(lm, pose, score, config) {
    var cfg = config || DEFAULT_CONFIG
    var p = pose || handPose(lm, cfg)
    var on = Number(cfg.pinchOn) || DEFAULT_CONFIG.pinchOn
    var confidence = clamp(Number(score) || 0.7, 0, 1)
    var name = 'unknown'
    var clarity = 0.55
    if (p.pinchDouble) { name = 'double_pinch'; clarity = 0.95 }
    else if (p.ok) { name = 'ok'; clarity = 0.9 }
    else if (p.pinchI < on) { name = 'pinch'; clarity = 0.92 }
    else if (p.pinchM < on) { name = 'right_pinch'; clarity = 0.9 }
    else if (p.thumbsUp) { name = 'thumbs_up'; clarity = 0.9 }
    else if (p.fist) { name = 'fist'; clarity = 0.95 }
    else if (p.palm) { name = 'open_palm'; clarity = 0.97 }
    else if (p.pointing) { name = 'point'; clarity = 0.94 }
    else if (p.peace) { name = 'peace'; clarity = 0.92 }
    else if (p.three) { name = 'three'; clarity = 0.85 }
    return { name: name, confidence: name === 'unknown' ? confidence * 0.35 : confidence * clarity, clarity: clarity }
  }

  // When the classifier lands on "unknown" it must say what it is CLOSEST to
  // instead of inventing an intention. Every candidate is scored from measured
  // geometry only: the share of finger states that match, adjusted for pinch
  // candidates by how close the two fingertips actually are.
  var POSE_TEMPLATES = [
    { name: 'open_palm', up: [1, 1, 1, 1, 1] },
    { name: 'fist', up: [0, 0, 0, 0, 0] },
    { name: 'thumbs_up', up: [1, 0, 0, 0, 0] },
    { name: 'point', up: [0, 1, 0, 0, 0] },
    { name: 'peace', up: [0, 1, 1, 0, 0] },
    { name: 'three', up: [0, 1, 1, 1, 0] },
    { name: 'four', up: [1, 1, 1, 1, 0] },
    { name: 'pinch', up: [null, 1, null, null, null], pinch: 'pinchI' },
    { name: 'right_pinch', up: [null, 1, null, null, null], pinch: 'pinchM' },
    { name: 'double_pinch', up: [null, null, null, null, null], pinch: 'pinchR' }
  ]

  function candidatePoses(pose, limit) {
    if (!pose || !pose.up) return []
    var out = []
    for (var i = 0; i < POSE_TEMPLATES.length; i += 1) {
      var template = POSE_TEMPLATES[i]
      var matched = 0
      var total = 0
      for (var finger = 0; finger < 5; finger += 1) {
        var want = template.up[finger]
        if (want === null || typeof want === 'undefined') continue
        total += 1
        if (pose.up[finger] === want) matched += 1
      }
      var value = total ? matched / total : 1
      if (template.pinch) {
        var gap = Number(pose[template.pinch])
        if (!isFinite(gap)) value = 0
        else value = value * (0.5 + 0.5 * clamp(1 - (gap - 0.1) / 0.45, 0, 1))
      }
      out.push({ name: template.name, confidence: Math.round(value * 100) / 100 })
    }
    out.sort(function (a, b) { return b.confidence - a.confidence })
    return out.slice(0, Number(limit) || 3)
  }

  // Movement, duration and speed: a pose alone is not a gesture. The tracker
  // keeps a smoothed velocity so the readout can say "moving up 1.8/s" and the
  // fist-scroll can integrate real travel instead of guessing from the pose.
  function updateMotion(tracker, point, now) {
    if (!tracker) return { lastDx: 0, lastDy: 0, vx: 0, vy: 0, speed: 0, direction: 'still' }
    var at = Number(now) || Date.now()
    if (tracker.at) {
      var dt = Math.max(0.001, (at - tracker.at) / 1000)
      var dx = point.x - tracker.x
      var dy = point.y - tracker.y
      tracker.lastDx = dx
      tracker.lastDy = dy
      tracker.vx = tracker.vx * 0.72 + (dx / dt) * 0.28
      tracker.vy = tracker.vy * 0.72 + (dy / dt) * 0.28
      tracker.speed = Math.hypot(tracker.vx, tracker.vy)
      tracker.direction = motionDirection(tracker.vx, tracker.vy, tracker.speed)
    }
    tracker.x = point.x
    tracker.y = point.y
    tracker.at = at
    return tracker
  }

  function motionDirection(vx, vy, speed) {
    if (Math.abs(Number(speed) || 0) < DEFAULT_CONFIG.motionStill) return 'still'
    var horizontal = vx > 0 ? 'right' : 'left'
    var vertical = vy > 0 ? 'down' : 'up'
    if (Math.abs(vx) > Math.abs(vy) * 1.3) return horizontal
    if (Math.abs(vy) > Math.abs(vx) * 1.3) return vertical
    return vertical + '-' + horizontal
  }

  function makeMotionTracker() {
    return { x: 0, y: 0, at: 0, vx: 0, vy: 0, speed: 0, direction: 'still', lastDx: 0, lastDy: 0 }
  }

  function describeMotion(tracker) {
    if (!tracker || !tracker.at) return 'not measured'
    var speed = Math.round((Number(tracker.speed) || 0) * 10) / 10
    if (tracker.direction === 'still') return 'steady'
    return 'moving ' + tracker.direction + ' ' + speed + '/s'
  }

  function normalizeLandmarks(lm) {
    var out = new Array(63)
    var wrist = lm[0]
    var scale = Math.max(0.001, distance(lm[0], lm[9]))
    for (var i = 0; i < 21; i += 1) {
      var p = lm[i]
      out[i * 3] = (p.x - wrist.x) / scale
      out[i * 3 + 1] = (p.y - wrist.y) / scale
      out[i * 3 + 2] = (p.z - wrist.z) / scale
    }
    return out
  }

  function mirrorTemplate(vector) {
    var out = new Array(vector.length)
    for (var i = 0; i < vector.length; i += 3) {
      out[i] = -vector[i]
      out[i + 1] = vector[i + 1]
      out[i + 2] = vector[i + 2]
    }
    return out
  }

  function templateDistance(a, b) {
    if (!a || !b || a.length !== b.length || !a.length) return Infinity
    var total = 0
    for (var i = 0; i < a.length; i += 1) total += (a[i] - b[i]) * (a[i] - b[i])
    return Math.sqrt(total / (a.length / 3))
  }

  function matchTemplates(vector, mappings) {
    var best = null
    var bestMirror = null
    var mirrored = mirrorTemplate(vector)
    for (var i = 0; i < (mappings || []).length; i += 1) {
      var mapping = mappings[i]
      if (!mapping || mapping.kind !== 'pose' || !Array.isArray(mapping.template)) continue
      var direct = templateDistance(vector, mapping.template)
      var flip = templateDistance(mirrored, mapping.template)
      if (!best || direct < best.distance) best = { mapping: mapping, distance: direct }
      if (!bestMirror || flip < bestMirror.distance) bestMirror = { mapping: mapping, distance: flip }
    }
    if (bestMirror && (!best || bestMirror.distance < best.distance)) best = bestMirror
    return best
  }

  function OneEuroFilter(options) {
    var opts = options || {}
    this.minCutoff = Number(opts.minCutoff) || 1.2
    this.beta = Number(opts.beta) || 0.02
    this.dCutoff = Number(opts.dCutoff) || 1
    this.reset()
  }
  OneEuroFilter.prototype.reset = function () {
    this.lastValue = null
    this.lastDerivative = 0
    this.lastTime = null
  }
  OneEuroFilter.prototype.alpha = function (cutoff, dt) {
    var tau = 1 / (2 * Math.PI * Math.max(0.001, cutoff))
    return 1 / (1 + tau / Math.max(0.001, dt))
  }
  OneEuroFilter.prototype.filter = function (value, timestamp) {
    var now = typeof timestamp === 'number' ? timestamp : Date.now() / 1000
    if (this.lastValue === null || this.lastTime === null) {
      this.lastValue = value
      this.lastTime = now
      this.lastDerivative = 0
      return value
    }
    var dt = Math.max(0.001, now - this.lastTime)
    var derivative = (value - this.lastValue) / dt
    var edx = this.alpha(this.dCutoff, dt) * derivative + (1 - this.alpha(this.dCutoff, dt)) * this.lastDerivative
    var cutoff = this.minCutoff + this.beta * Math.abs(edx)
    var alpha = this.alpha(cutoff, dt)
    var filtered = alpha * value + (1 - alpha) * this.lastValue
    this.lastValue = filtered
    this.lastDerivative = edx
    this.lastTime = now
    return filtered
  }

  function SequenceMatcher(sequences, options) {
    this.sequences = sequences || []
    this.windowMs = (options && options.windowMs) || 2600
    this.buffer = []
    this.lastFired = {}
  }
  SequenceMatcher.prototype.reset = function () {
    this.buffer = []
    this.lastFired = {}
  }
  SequenceMatcher.prototype.push = function (label, now) {
    var at = typeof now === 'number' ? now : Date.now()
    if (!label) return null
    if (this.buffer.length && this.buffer[this.buffer.length - 1].label === label) {
      this.buffer[this.buffer.length - 1].at = at
    } else {
      this.buffer.push({ label: label, at: at })
    }
    while (this.buffer.length && at - this.buffer[0].at > this.windowMs) this.buffer.shift()
    if (this.buffer.length > 40) this.buffer.splice(0, this.buffer.length - 40)
    var labels = this.buffer.map(function (item) { return item.label })
    for (var i = 0; i < this.sequences.length; i += 1) {
      var seq = this.sequences[i]
      var pattern = seq && seq.sequence
      if (!pattern || !pattern.length || labels.length < pattern.length) continue
      var tail = labels.slice(-pattern.length)
      var matches = true
      for (var j = 0; j < pattern.length; j += 1) {
        if (tail[j] !== pattern[j]) { matches = false; break }
      }
      if (!matches) continue
      var last = this.lastFired[seq.id]
      var cooldown = Number(seq.cooldownMs) || 1200
      if (typeof last === 'number' && at - last < cooldown) continue
      this.lastFired[seq.id] = at
      this.buffer = []
      return seq
    }
    return null
  }

  function mapToScreen(lm, calibration, viewport, sensitivity, tipIndex) {
    var tip = lm[typeof tipIndex === 'number' ? tipIndex : 8]
    var mirroredX = 1 - tip.x
    var xNorm
    var yNorm
    if (calibration && calibration.maxX - calibration.minX > 0.08 && calibration.maxY - calibration.minY > 0.08) {
      xNorm = (mirroredX - calibration.minX) / (calibration.maxX - calibration.minX)
      yNorm = (tip.y - calibration.minY) / (calibration.maxY - calibration.minY)
    } else {
      xNorm = 0.5 + (mirroredX - 0.5) * sensitivity
      yNorm = 0.5 + (tip.y - 0.5) * sensitivity
    }
    xNorm = clamp(xNorm, 0, 1)
    yNorm = clamp(yNorm, 0, 1)
    return {
      x: xNorm * viewport.width,
      y: yNorm * viewport.height,
      nx: xNorm,
      ny: yNorm
    }
  }

  // ── overlay geometry ────────────────────────────────────────────────
  // The preview <video> is fitted with `object-fit: cover`: the frame is
  // scaled uniformly until it covers the panel and the overflow is cropped.
  // The overlay used to rely on the browser applying that rule to a <canvas>
  // whose backing store was the camera's intrinsic frame. That tied the
  // drawing buffer to the camera resolution and made the alignment depend on
  // a CSS behaviour instead of on the geometry. The overlay now maps every
  // landmark through this explicit cover transform and draws in CSS pixels.
  function coverTransform(sourceWidth, sourceHeight, displayWidth, displayHeight) {
    if (!(sourceWidth > 0) || !(sourceHeight > 0) || !(displayWidth > 0) || !(displayHeight > 0)) return null
    var scale = Math.max(displayWidth / sourceWidth, displayHeight / sourceHeight)
    return {
      scale: scale,
      offsetX: (displayWidth - sourceWidth * scale) / 2,
      offsetY: (displayHeight - sourceHeight * scale) / 2,
      width: displayWidth,
      height: displayHeight,
      sourceWidth: sourceWidth,
      sourceHeight: sourceHeight
    }
  }

  // Landmarks arrive in the unmirrored camera frame. The preview is mirrored
  // (a mirror is the natural way to point at your own screen), so the same
  // mirror is applied here: x flips inside the panel, y does not. The pointer
  // mapping already uses `1 - x`, so preview, skeleton and cursor describe the
  // same hand instead of two different ones.
  function projectLandmark(landmark, transform, mirrored) {
    if (!transform || !landmark) return null
    var x = Number(landmark.x)
    var y = Number(landmark.y)
    if (!isFinite(x) || !isFinite(y)) return null
    var screenX = transform.offsetX + x * transform.sourceWidth * transform.scale
    if (mirrored !== false) screenX = transform.width - screenX
    return {
      x: screenX,
      y: transform.offsetY + y * transform.sourceHeight * transform.scale
    }
  }

  // A landmark set is drawable only when it is a complete 21-point hand of
  // finite numbers. MediaPipe can return a partial or garbage set for a frame
  // while a hand is leaving the frame; drawing that can connect unrelated
  // points, so it is rejected instead of patched up.
  function validLandmarks(lm) {
    if (!lm || lm.length !== 21) return false
    for (var i = 0; i < 21; i += 1) {
      var p = lm[i]
      if (!p || typeof p.x !== 'number' || typeof p.y !== 'number') return false
      if (!isFinite(p.x) || !isFinite(p.y)) return false
      // Hands at the frame edge legitimately report slightly outside 0..1.
      // Values beyond this window are a broken result, not a hand.
      if (p.x < -0.25 || p.x > 1.25 || p.y < -0.25 || p.y > 1.25) return false
    }
    return true
  }

  function tipDistanceSq(hand, previousHand) {
    if (!hand || !previousHand || !hand.lm || !previousHand.lm) return Infinity
    var a = hand.lm[8]
    var b = previousHand.lm[8]
    if (!a || !b) return Infinity
    var dx = a.x - b.x
    var dy = a.y - b.y
    if (!isFinite(dx) || !isFinite(dy)) return Infinity
    return dx * dx + dy * dy
  }

  // MediaPipe's handedness label assumes a mirrored (selfie) input image. The
  // raw camera frame is not mirrored, so onResults swaps the label. When two
  // hands arrive with the same side (a crossing hand can collapse the labels),
  // the previous pairing is preferred while it is still the closest one;
  // otherwise the mirrored index tip decides which hand is the user's left.
  function resolveHandSides(hands, previous) {
    if (!hands || hands.length !== 2 || hands[0].side !== hands[1].side) return hands
    var first = hands[0]
    var second = hands[1]
    var previousLeft = previous && previous.left
    var previousRight = previous && previous.right
    if (previousLeft && previousRight) {
      var keep = tipDistanceSq(first, previousLeft) + tipDistanceSq(second, previousRight)
      var swap = tipDistanceSq(first, previousRight) + tipDistanceSq(second, previousLeft)
      if (swap < keep) {
        first.side = 'right'
        second.side = 'left'
      } else {
        first.side = 'left'
        second.side = 'right'
      }
      return hands
    }
    var left = first.lm[8].x >= second.lm[8].x ? first : second
    left.side = 'left'
    ;(left === first ? second : first).side = 'right'
    return hands
  }

  var ENGINE = {
    version: VERSION,
    PROFILES: PROFILES,
    DEFAULT_CONFIG: DEFAULT_CONFIG,
    clamp: clamp,
    distance: distance,
    distance3: distance3,
    fingersUp: fingersUp,
    handPose: handPose,
    classifyPose: classifyPose,
    candidatePoses: candidatePoses,
    POSE_TEMPLATES: POSE_TEMPLATES,
    updateMotion: updateMotion,
    makeMotionTracker: makeMotionTracker,
    motionDirection: motionDirection,
    describeMotion: describeMotion,
    normalizeLandmarks: normalizeLandmarks,
    mirrorTemplate: mirrorTemplate,
    templateDistance: templateDistance,
    matchTemplates: matchTemplates,
    OneEuroFilter: OneEuroFilter,
    SequenceMatcher: SequenceMatcher,
    mapToScreen: mapToScreen,
    coverTransform: coverTransform,
    projectLandmark: projectLandmark,
    validLandmarks: validLandmarks,
    resolveHandSides: resolveHandSides,
    isSensitiveLabel: isSensitiveLabel
  }
  root.__JARVIS_GESTURE_ENGINE__ = ENGINE

  var ACTIONS = {
    click: { label: 'Left click', group: 'pointer' },
    right_click: { label: 'Right click', group: 'pointer' },
    double_click: { label: 'Double click', group: 'pointer' },
    semantic_activate: { label: 'Activate UI control (UI Automation)', group: 'pointer' },
    scroll_up: { label: 'Scroll up', group: 'navigation' },
    scroll_down: { label: 'Scroll down', group: 'navigation' },
    next_section: { label: 'Next section', group: 'navigation' },
    previous_section: { label: 'Previous section', group: 'navigation' },
    home: { label: 'Dashboard home', group: 'navigation' },
    zoom_in: { label: 'Zoom in (HUD)', group: 'navigation' },
    zoom_out: { label: 'Zoom out (HUD)', group: 'navigation' },
    zoom_reset: { label: 'Reset HUD zoom', group: 'navigation' },
    toggle_listening: { label: 'Toggle voice listening', group: 'voice' },
    pointer_pause: { label: 'Pause pointer for 1.5 s', group: 'pointer' },
    emergency_stop: { label: 'Emergency stop gestures', group: 'safety' },
    open_settings: { label: 'Open Settings view', group: 'navigation' },
    open_gesture_view: { label: 'Open Gesture Control view', group: 'navigation' },
    media_play_pause: { label: 'Media play / pause', group: 'media' },
    media_next: { label: 'Next track', group: 'media' },
    media_previous: { label: 'Previous track', group: 'media' },
    window_next: { label: 'Switch window', group: 'windows' },
    window_minimize: { label: 'Minimize window', group: 'windows' },
    window_maximize: { label: 'Maximize window', group: 'windows' },
    window_focus_uia: { label: 'Focus window (UI Automation)', group: 'windows' },
    window_minimize_uia: { label: 'Minimize window (UI Automation)', group: 'windows' },
    window_maximize_uia: { label: 'Maximize window (UI Automation)', group: 'windows' },
    window_restore_uia: { label: 'Restore window (UI Automation)', group: 'windows' },
    window_move_center: { label: 'Move window to the centre', group: 'windows' },
    show_desktop: { label: 'Show desktop', group: 'windows' },
    browser_back: { label: 'Browser back', group: 'browser' },
    browser_forward: { label: 'Browser forward', group: 'browser' },
    new_tab: { label: 'New browser tab', group: 'browser' },
    screenshot: { label: 'Take screenshot', group: 'windows' }
  }

  var BRIDGE_COMMANDS = {
    media_play_pause: 'play',
    media_next: 'next',
    media_previous: 'previous',
    window_next: 'switch window',
    window_minimize: 'minimize current window',
    window_maximize: 'maximize current window',
    show_desktop: 'show desktop',
    browser_back: 'browser back',
    browser_forward: 'browser forward',
    new_tab: 'new tab',
    screenshot: 'take a screenshot'
  }

  var STORAGE_SETTINGS = 'jarvis-gesture-settings-v2'
  var STORAGE_MAPPINGS = 'jarvis-gesture-mappings-v2'
  var STORAGE_CALIBRATION = 'jarvis-gesture-calibration-v2'

  function readJson(key, fallback) {
    try {
      var raw = root.localStorage && root.localStorage.getItem(key)
      if (!raw) return fallback
      var parsed = JSON.parse(raw)
      return parsed == null ? fallback : parsed
    } catch (err) { return fallback }
  }

  function writeJson(key, value) {
    try {
      if (root.localStorage) root.localStorage.setItem(key, JSON.stringify(value))
    } catch (err) { /* storage may be blocked; the session still works */ }
  }

  function makeHandState() {
    return {
      firstSeenAt: 0,
      lastSeenAt: 0,
      armed: true,
      lastClickAt: 0,
      peaceSince: 0,
      resumeSince: 0,
      lastSemanticAt: 0,
      lastCustomAt: 0,
      lastCustomName: '',
      customFrames: 0,
      // pinch = press-release state machine: '' | 'left' | 'right' | 'double'
      pinch: { kind: '', startedAt: 0, startX: 0, startY: 0, startTarget: null, lastTarget: null, armed: false },
      // The secondary hand keeps the old frame-counted pinch: it only clicks
      // JARVIS controls and never drags, so it needs no press-release state.
      holdFrames: 0,
      motion: makeMotionTracker(),
      scrollAcc: 0,
      lastScrollAt: 0
    }
  }

  function GestureController(ctx) {
    this.ctx = ctx
    this.state = ctx.state
    this.active = false
    this.paused = false
    this.emergency = false
    this.pointerSuspendedUntil = 0
    this.tracker = null
    this.video = null
    this.panel = null
    this.raf = 0
    this.sending = false
    this.lastVideoTime = -1
    this.lastCaptureAt = 0
    this.metrics = {
      fps: 0,
      inferenceMs: 0,
      captureMs: 0,
      recognitionMs: 0,
      actionMs: 0,
      captureToActionMs: 0,
      moveMs: 0,
      captureToMoveMs: 0,
      dropped: 0,
      frames: 0,
      lastResultsAt: 0,
      actions: 0,
      failures: 0
    }
    this.frameCaptureAt = 0
    this.pointer = { x: (root.innerWidth || 1280) / 2, y: (root.innerHeight || 720) / 2 }
    this.filterX = new ENGINE.OneEuroFilter(DEFAULT_CONFIG)
    this.filterY = new ENGINE.OneEuroFilter(DEFAULT_CONFIG)
    this.settings = Object.assign({}, DEFAULT_CONFIG, readJson(STORAGE_SETTINGS, {}))
    this.mappings = readJson(STORAGE_MAPPINGS, [])
    this.calibration = readJson(STORAGE_CALIBRATION, null)
    this.handState = { left: makeHandState(), right: makeHandState() }
    this.hands = { left: null, right: null }
    this.lastHandsAt = 0
    this.drag = null
    this.pointerTarget = null
    this.lastTargetScan = 0
    this.lastUiAt = 0
    this.lastMoveSent = 0
    this.lastStatus = ''
    this.lastGesture = { name: 'none', confidence: 0, side: '', at: 0, candidate: null, motion: '' }
    this.lastAction = { label: '', at: 0, ok: null, detail: '' }
    // lastAmbiguous is the MAPPABLE record (it carries the landmark vector);
    // lastCandidate is the readout record for an unknown pose. They are
    // deliberately separate so a readout can never clobber a pose the user is
    // about to map.
    this.lastAmbiguous = null
    this.lastCandidate = null
    this.calibrating = null
    this.poseRecording = null
    this.sequenceRecording = null
    this.recordedLabels = []
    this.lastEdgeLabels = { left: '', right: '', both: '' }
    this.sequenceMatcher = this.buildSequenceMatcher()
    this.two = { mode: '', anchor: 0, base: 1, lastPalm: null, lastSwipeAt: 0, lastScrollAt: 0, pinchActive: false, lastPinchAt: 0 }
    this.ui = {}
    this.uiSnapshot = null
    this.uiAutomation = { checked: false, available: false, reason: 'not checked' }
    this.windows = { checked: false, ok: false, error: 'not checked', list: [] }
    // Desktop space owned by the bridge (authoritative for the real cursor) and
    // the honesty readouts that prove what the real pointer did.
    this.desktop = null
    this.mouseInput = { reported: false, ready: false, error: '', supported: true }
    this.cursor = null
    this.cursorError = ''
    this.mapError = 0
    this.lastCursorPollAt = 0
    this.lastMoveErrorAt = 0
    this.bound = false
    this.hudScale = 1
    // Geometry of the frame the tracker last answered for. It survives a
    // hidden/re-attached <video> so a resize cannot make the overlay guess.
    this.sourceWidth = 0
    this.sourceHeight = 0
    // A tracker that stops answering is a state, not an empty hand: the UI has
    // to say so instead of leaving the last skeleton painted and "LIVE" up.
    this.trackingLost = false
    this.trackingLostAt = 0
    this.trackerFailures = 0
    this.startedAt = 0
  }

  GestureController.prototype.init = function () {
    if (this.bound) return
    this.bound = true
    var self = this
    this.forEachId(['gesture-pause', 'gesture-estop', 'gesture-camera-power', 'gesture-calibrate',
      'gesture-calib-reset', 'gesture-record-pose', 'gesture-record-seq', 'gesture-map-last',
      'gesture-ui-refresh'], function (id) { self.ui[id] = root.document.getElementById(id) })
    this.refreshUiSettings()
    this.bindControls()
    this.populateCameraSelect()
    this.checkUiAutomation()
    root.addEventListener('keydown', function (event) {
      if (event.key === 'F8') {
        event.preventDefault()
        self.emergencyStop('keyboard')
      }
    })
    root.addEventListener('resize', function () {
      self.pointer.x = clamp(self.pointer.x, 0, root.innerWidth || 0)
      self.pointer.y = clamp(self.pointer.y, 0, root.innerHeight || 0)
    })
    // A tab that is hidden or closed mid-drag must not leave the Windows mouse
    // button latched. Best effort: the request may be cut off by the unload.
    var releaseOnHide = function () { if (self.drag) self.releaseDrag() }
    if (root.document) root.document.addEventListener('visibilitychange', function () {
      if (root.document.hidden) releaseOnHide()
    })
    root.addEventListener('pagehide', releaseOnHide)
    this.setStatus('CAMERA OFF')
    this.renderMappings()
    this.updateUi(true)
    root.__JARVIS_GESTURE__ = this.api()
  }

  GestureController.prototype.forEachId = function (ids, fn) {
    for (var i = 0; i < ids.length; i += 1) fn(ids[i])
  }

  GestureController.prototype.api = function () {
    var self = this
    return {
      version: VERSION,
      toggle: function (panel) { return self.toggle(panel) },
      start: function (panel) { return self.start(panel) },
      stop: function () { return self.stop() },
      pause: function (reason) { return self.pause(reason || 'ui') },
      resume: function (reason) { return self.resume(reason || 'ui') },
      emergencyStop: function (reason) { return self.emergencyStop(reason || 'api') },
      activateVoiceTarget: function (source) { return self.activateVoiceTarget(source || 'voice') },
      resetHudScale: function () { self.hudScale = 1 },
      onBridgeStatus: function (online, data) { self.onBridgeStatus(online, data) },
      refreshWindows: function () { self.refreshWindows() },
      windowAction: function (action, handle) { return self.windowAction(action, handle) },
      status: function () { return self.snapshotStatus() },
      setProfile: function (name) { return self.setProfile(name) },
      get active() { return self.active },
      get paused() { return self.paused }
    }
  }

  GestureController.prototype.snapshotStatus = function () {
    return {
      active: this.active,
      paused: this.paused,
      emergency: this.emergency,
      mode: this.settings.profile,
      pointerHand: this.settings.pointerHand,
      gesture: this.lastGesture.name,
      confidence: this.lastGesture.confidence,
      candidate: this.lastGesture.candidate,
      motion: this.lastGesture.motion,
      action: this.lastAction.label,
      actionOk: this.lastAction.ok,
      actionDetail: this.lastAction.detail,
      pointer: { x: this.pointer.x, y: this.pointer.y },
      desktop: this.desktop,
      cursor: this.cursor,
      cursorError: this.cursorError,
      mappingError: Math.round(this.mapError * 10) / 10,
      dragging: Boolean(this.drag),
      target: this.pointerTarget ? this.pointerTarget.label : '',
      app: this.state.activeWindow || '',
      metrics: {
        fps: this.metrics.fps,
        captureMs: this.metrics.captureMs,
        inferenceMs: this.metrics.inferenceMs,
        recognitionMs: this.metrics.recognitionMs,
        actionMs: this.metrics.actionMs,
        captureToActionMs: this.metrics.captureToActionMs,
        moveMs: this.metrics.moveMs,
        captureToMoveMs: this.metrics.captureToMoveMs,
        dropped: this.metrics.dropped,
        frames: this.metrics.frames,
        actions: this.metrics.actions,
        failures: this.metrics.failures
      },
      camera: this.state.cameraStream ? 'on' : 'off',
      bridge: Boolean(this.state.bridgeOnline),
      mouseInput: this.mouseInput,
      uiAutomation: this.uiAutomation,
      windows: this.windows
    }
  }

  GestureController.prototype.setStatus = function (text) {
    var value = String(text || '')
    // With ?gestdebug=1 the status line carries the numbers that place a
    // skeleton, so a ghost overlay names itself instead of needing devtools.
    if (/[?&]gestdebug=1/.test(String(root.location && root.location.search || ''))) {
      var d = this.debugSnapshot()
      var hands = (d.hands || []).map(function (h) {
        return h.side[0].toUpperCase() + ' ' + h.score.toFixed(2) + ' span ' + h.span
      }).join(' | ') || 'none'
      value += '  [src ' + (d.video ? d.video.src : '--') + ' used ' + d.sourceUsed.join('x')
        + ' box ' + (d.canvas && d.canvas.box ? d.canvas.box.join('x') : '--')
        + ' dpr ' + d.dpr + ' ' + hands + ' silent ' + (d.silenceMs === null ? '--' : d.silenceMs) + 'ms]'
    }
    if (value === this.lastStatus) return
    this.lastStatus = value
    if (!root.document) return
    var nodes = root.document.querySelectorAll('.gesture-status')
    for (var i = 0; i < nodes.length; i += 1) if (nodes[i].textContent !== value) nodes[i].textContent = value
    var mini = root.document.getElementById('mini-gesture')
    if (mini && mini.textContent !== value) mini.textContent = value
    var stateNode = root.document.getElementById('gesture-state')
    if (stateNode && stateNode.textContent !== value) stateNode.textContent = value
  }

  GestureController.prototype.flash = function (text) {
    if (!root.document) return
    var nodes = root.document.querySelectorAll('.gesture-feedback')
    for (var i = 0; i < nodes.length; i += 1) {
      var node = nodes[i]
      node.textContent = text
      node.classList.remove('flash')
      void node.offsetWidth
      node.classList.add('flash')
    }
  }

  GestureController.prototype.setError = function (message, options) {
    var text = String(message || '')
    this.setStatus(text)
    if (root.document) {
      var box = root.document.getElementById('gesture-error')
      if (box) {
        box.textContent = text
        box.hidden = false
      }
      var permission = root.document.getElementById('gesture-permission')
      if (permission) permission.textContent = text
    }
    if (!(options && options.silent) && this.ctx.showToast) this.ctx.showToast(text, true)
  }

  GestureController.prototype.updateToggles = function () {
    if (!root.document) return
    var active = this.active
    var nodes = root.document.querySelectorAll('.gesture-toggle')
    for (var i = 0; i < nodes.length; i += 1) {
      var btn = nodes[i]
      btn.classList.toggle('active', active)
      var strong = btn.querySelector('strong')
      if (strong) strong.textContent = active ? 'Stop hand tracking' : 'Start hand tracking'
    }
    var rail = root.document.getElementById('rail-gesture-toggle')
    if (rail) {
      rail.classList.toggle('active', active)
      var span = rail.querySelector('span')
      if (span) span.textContent = active ? 'Stop hand tracking' : 'Start hand tracking'
    }
    var quick = root.document.getElementById('gesture-quick-stop')
    if (quick) {
      quick.hidden = !active
      quick.classList.toggle('paused', this.paused)
      var label = quick.querySelector('strong')
      if (label) label.textContent = this.paused ? 'Resume gestures' : 'Pause gestures'
      quick.setAttribute('aria-pressed', this.paused ? 'true' : 'false')
      quick.title = this.paused ? 'Resume gesture control' : 'Pause gesture control'
    }
    var pause = this.ui['gesture-pause']
    if (pause) pause.textContent = this.paused ? 'Resume controls' : 'Pause controls'
  }

  GestureController.prototype.refreshUiSettings = function () {
    if (!root.document) return
    var set = function (id, value) {
      var node = root.document.getElementById(id)
      if (!node) return
      if (node.type === 'checkbox') node.checked = Boolean(value)
      else node.value = String(value)
    }
    set('gesture-profile', this.settings.profile)
    set('gesture-pointer-hand', this.settings.pointerHand)
    set('gesture-sensitivity', this.settings.sensitivity)
    set('gesture-smoothing', this.settings.smoothing)
    set('gesture-deadzone', this.settings.deadzone)
    set('gesture-confidence-range', this.settings.minHandConfidence)
    set('gesture-zoom', this.settings.zoomGain)
    set('gesture-semantic', this.settings.semantic)
    set('gesture-semantic-clicks', this.settings.semanticClicks)
    set('gesture-pinch', this.settings.pinchOn)
    set('gesture-drag-hold', this.settings.dragHoldMs)
    set('gesture-camera', this.settings.cameraId || '')
    this.updateProfileNote()
  }

  GestureController.prototype.updateProfileNote = function () {
    var node = root.document && root.document.getElementById('gesture-profile-note')
    if (!node) return
    node.textContent = this.settings.profile === 'custom'
      ? 'Custom values: the sliders below override the profile until a profile is picked again.'
      : this.settings.profile === 'precision'
        ? 'Slower, heavily filtered; best for small buttons.'
        : this.settings.profile === 'fast'
          ? 'Wide reach and light filtering; best for large targets.'
          : 'Default balance of reach, smoothing and click stability.'
  }

  GestureController.prototype.bindControls = function () {
    var self = this
    var on = function (id, event, fn) {
      var node = root.document.getElementById(id)
      if (node) node.addEventListener(event, fn)
    }
    on('gesture-pause', 'click', function () { self.togglePause('ui') })
    on('gesture-estop', 'click', function () { self.emergencyStop('ui') })
    on('gesture-quick-stop', 'click', function () { self.togglePause('quick') })
    on('gesture-camera-power', 'click', function () { self.ctx.toggleCamera() })
    on('gesture-profile', 'change', function (event) { self.setProfile(event.target.value) })
    on('gesture-pointer-hand', 'change', function (event) { self.settings.pointerHand = event.target.value; self.persistSettings() })
    on('gesture-camera', 'change', function (event) {
      self.settings.cameraId = event.target.value || ''
      self.persistSettings()
      self.applyCamera(self.settings.cameraId)
    })
    on('gesture-sensitivity', 'input', function (event) {
      self.settings.sensitivity = Number(event.target.value)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-smoothing', 'input', function (event) {
      self.settings.smoothing = Math.min(0.95, Math.max(0, Number(event.target.value)))
      self.settings.minCutoff = 0.6 + (1 - self.settings.smoothing) * 3.2
      self.settings.profile = 'custom'
      // OneEuroFilter reads its cutoff at construction time, so the live
      // slider must rebuild the two filters or the change would only apply
      // after a tracking restart.
      self.filterX = new ENGINE.OneEuroFilter({ minCutoff: self.settings.minCutoff, beta: self.settings.beta })
      self.filterY = new ENGINE.OneEuroFilter({ minCutoff: self.settings.minCutoff, beta: self.settings.beta })
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-deadzone', 'input', function (event) {
      self.settings.deadzone = Number(event.target.value)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-confidence-range', 'input', function (event) {
      self.settings.minHandConfidence = Number(event.target.value)
      self.settings.clickConfidence = Math.min(0.95, self.settings.minHandConfidence + 0.06)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.applyTrackerOptions()
      self.refreshUiSettings()
    })
    on('gesture-zoom', 'input', function (event) {
      self.settings.zoomGain = Number(event.target.value)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-semantic', 'change', function (event) { self.settings.semantic = Boolean(event.target.checked); self.persistSettings() })
    on('gesture-semantic-clicks', 'change', function (event) { self.settings.semanticClicks = Boolean(event.target.checked); self.persistSettings() })
    on('gesture-calibrate', 'click', function () { self.startCalibration() })
    on('gesture-calib-reset', 'click', function () { self.resetCalibration() })
    on('gesture-pinch', 'input', function (event) {
      self.settings.pinchOn = clamp(Number(event.target.value) || DEFAULT_CONFIG.pinchOn, 0.12, 0.5)
      self.settings.pinchOff = Math.min(0.62, self.settings.pinchOn + 0.12)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-drag-hold', 'input', function (event) {
      self.settings.dragHoldMs = clamp(Number(event.target.value) || DEFAULT_CONFIG.dragHoldMs, 200, 900)
      self.settings.profile = 'custom'
      self.persistSettings()
      self.refreshUiSettings()
    })
    on('gesture-record-pose', 'click', function () { self.startPoseRecording() })
    on('gesture-record-seq', 'click', function () { self.startSequenceRecording() })
    on('gesture-map-last', 'click', function () { self.mapLastAmbiguous() })
    on('gesture-ui-refresh', 'click', function () { self.checkUiAutomation(true) })
    on('gesture-windows-refresh', 'click', function () { self.refreshWindows() })
    on('gesture-windows', 'click', function (event) {
      var button = event.target.closest('[data-window-action]')
      if (button) self.windowAction(button.dataset.windowAction, Number(button.dataset.windowHandle))
    })
    on('gesture-mappings', 'click', function (event) {
      var button = event.target.closest('[data-gesture-delete]')
      if (button) self.deleteMapping(button.dataset.gestureDelete)
    })
    this.bindMappingActionOptions()
  }

  GestureController.prototype.bindMappingActionOptions = function () {
    var select = root.document && root.document.getElementById('gesture-mapping-action')
    if (!select || select.dataset.bound) return
    select.dataset.bound = '1'
    var groups = {}
    Object.keys(ACTIONS).forEach(function (key) {
      var group = ACTIONS[key].group
      groups[group] = groups[group] || []
      groups[group].push(key)
    })
    var labelFor = function (group) { return group.charAt(0).toUpperCase() + group.slice(1) }
    Object.keys(groups).forEach(function (group) {
      var optgroup = root.document.createElement('optgroup')
      optgroup.label = labelFor(group)
      groups[group].forEach(function (key) {
        var option = root.document.createElement('option')
        option.value = key
        option.textContent = ACTIONS[key].label
        optgroup.appendChild(option)
      })
      select.appendChild(optgroup)
    })
  }

  GestureController.prototype.persistSettings = function () {
    writeJson(STORAGE_SETTINGS, this.settings)
  }

  GestureController.prototype.setProfile = function (name) {
    if (!PROFILES[name]) return
    var preset = PROFILES[name]
    this.settings.profile = name
    this.settings.sensitivity = preset.sensitivity
    this.settings.smoothing = preset.smoothing
    this.settings.deadzone = preset.deadzone
    this.settings.minCutoff = preset.minCutoff
    this.settings.beta = preset.beta
    this.settings.scrollGain = preset.scrollGain
    this.settings.zoomGain = preset.zoomGain
    this.filterX = new ENGINE.OneEuroFilter({ minCutoff: this.settings.minCutoff, beta: this.settings.beta })
    this.filterY = new ENGINE.OneEuroFilter({ minCutoff: this.settings.minCutoff, beta: this.settings.beta })
    this.persistSettings()
    this.refreshUiSettings()
    this.flash(preset.label.toUpperCase() + ' PROFILE')
  }

  GestureController.prototype.applyTrackerOptions = function () {
    if (!this.tracker) return
    this.tracker.setOptions({
      maxNumHands: 2,
      modelComplexity: 1,
      minDetectionConfidence: this.settings.minHandConfidence,
      minTrackingConfidence: Math.max(0.35, this.settings.minHandConfidence - 0.05)
    })
  }

  GestureController.prototype.populateCameraSelect = function () {
    var self = this
    var select = root.document && root.document.getElementById('gesture-camera')
    if (!select || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return
    var render = function (devices) {
      var current = self.settings.cameraId || ''
      select.innerHTML = '<option value="">Default camera</option>'
      devices.filter(function (device) { return device.kind === 'videoinput' }).forEach(function (device, index) {
        var option = root.document.createElement('option')
        option.value = device.deviceId
        option.textContent = device.label || ('Camera ' + (index + 1))
        select.appendChild(option)
      })
      select.value = current
      if (select.value !== current) select.value = ''
    }
    navigator.mediaDevices.enumerateDevices().then(render).catch(function () { /* permission may hide labels */ })
    if (!this.cameraListenerBound) {
      this.cameraListenerBound = true
      navigator.mediaDevices.addEventListener('devicechange', function () {
        navigator.mediaDevices.enumerateDevices().then(render).catch(function () {})
      })
    }
  }

  GestureController.prototype.applyCamera = async function (deviceId) {
    var wasActive = this.active
    var oldPanel = this.panel
    if (wasActive) this.stop({ silent: true })
    this.ctx.stopCamera()
    var started = await this.ctx.startCamera(deviceId)
    if (!started) {
      this.setError('Camera could not be started. Check Windows camera privacy settings.', { silent: false })
      return
    }
    this.populateCameraSelect()
    if (wasActive) this.start(oldPanel)
  }

  GestureController.prototype.toggle = async function (panel) {
    if (this.active) return this.stop()
    return this.start(panel)
  }

  GestureController.prototype.start = async function (panel) {
    if (this.active) return
    if (!root.Hands || !root.HAND_CONNECTIONS) {
      this.setError('MediaPipe Hands did not load. The tracker is served from jsDelivr; check the connection and reload.')
      return
    }
    var started = await this.ctx.ensureCamera()
    if (!started) {
      this.setError('Camera permission was denied or no camera is available.', { silent: false })
      return
    }
    this.panel = panel || this.ctx.activePanel()
    this.video = this.ctx.videoFor(this.panel)
    if (!this.video) {
      this.setError('No camera preview is rendered in this view. Open the Camera module first.')
      return
    }
    this.active = true
    this.paused = false
    this.emergency = false
    this.trackingLost = false
    this.trackingLostAt = 0
    this.trackerFailures = 0
    this.startedAt = performance.now()
    this.state.gestureActive = true
    this.state.gestureFrame = 0
    this.resetRuntimeState()
    this.updateToggles()
    this.createTracker()
    this.applyTrackerOptions()
    this.video.muted = true
    try { await this.video.play() } catch (err) { /* autoplay may wait for the next gesture */ }
    this.lastVideoTime = -1
    this.metrics.frames = 0
    this.metrics.dropped = 0
    this.metrics.lastResultsAt = 0
    this.metrics.captureToActionMs = 0
    this.metrics.actions = 0
    this.metrics.failures = 0
    this.frameCaptureAt = 0
    this.mapError = 0
    this.cursor = null
    this.cursorError = ''
    this.loop = this.loop.bind(this)
    this.raf = root.requestAnimationFrame(this.loop)
    // Start-of-session truth: ask the bridge now instead of waiting for the
    // next 15 s poll, so "Windows bridge: offline" is the real state immediately.
    if (this.ctx.refreshBridge) this.ctx.refreshBridge()
    this.setStatus('HAND TRACKING STARTING')
    this.updateUi(true)
    this.ctx.showToast('Hand control online. Point to move the real cursor, pinch-tap to click, pinch-hold to drag, fist to scroll, open palm to pause. F8 is the emergency stop.')
  }

  GestureController.prototype.createTracker = function () {
    var self = this
    if (this.tracker) return
    this.tracker = new root.Hands({ locateFile: function (file) { return 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/' + file } })
    this.tracker.onResults(function (results) { self.onResults(results) })
    this.state.handTracker = this.tracker
  }

  GestureController.prototype.stop = function (options) {
    var opts = options || {}
    if (!this.active) return
    this.active = false
    this.paused = false
    this.emergency = false
    this.state.gestureActive = false
    this.state.gestureFrame = 0
    if (this.raf) root.cancelAnimationFrame(this.raf)
    this.raf = 0
    this.sending = false
    this.releaseDrag()
    this.hideCursor()
    // Every panel is cleared, not just the one that happened to own the
    // tracker: otherwise switching views leaves the last skeleton frozen on
    // the panel that is still on screen.
    this.clearOverlays()
    this.trackingLost = false
    this.trackingLostAt = 0
    this.trackerFailures = 0
    this.startedAt = 0
    this.panel = null
    this.video = null
    this.hands = { left: null, right: null }
    this.lastGesture = { name: 'none', confidence: 0, side: '', at: 0, candidate: null, motion: '' }
    this.updateToggles()
    this.updateUi(true)
    this.setStatus(this.state.cameraStream ? 'CAMERA ON - TRACKING OFF' : 'CAMERA OFF')
    if (!opts.silent) this.flash('TRACKING STOPPED')
  }

  GestureController.prototype.dispose = function () {
    this.stop({ silent: true })
    if (this.tracker && this.tracker.close) {
      try { this.tracker.close() } catch (err) { /* already closed */ }
    }
    this.tracker = null
    this.state.handTracker = null
  }

  GestureController.prototype.handleCameraLost = function (message) {
    var text = message || 'Camera disconnected. Gesture control stopped; mouse buttons were released.'
    this.releaseDrag()
    this.hideCursor()
    this.active = false
    this.paused = false
    this.emergency = false
    this.state.gestureActive = false
    this.state.gestureFrame = 0
    if (this.raf) root.cancelAnimationFrame(this.raf)
    this.raf = 0
    this.sending = false
    this.video = null
    this.panel = null
    this.hands = { left: null, right: null }
    this.trackingLost = false
    this.trackingLostAt = 0
    this.trackerFailures = 0
    this.startedAt = 0
    this.clearOverlays()
    this.updateToggles()
    this.setError(text, { silent: false })
    this.updateUi(true)
  }

  GestureController.prototype.resetRuntimeState = function () {
    this.handState = { left: makeHandState(), right: makeHandState() }
    this.hands = { left: null, right: null }
    this.filterX = new ENGINE.OneEuroFilter({ minCutoff: this.settings.minCutoff, beta: this.settings.beta })
    this.filterY = new ENGINE.OneEuroFilter({ minCutoff: this.settings.minCutoff, beta: this.settings.beta })
    this.two = { mode: '', anchor: 0, base: 1, lastPalm: null, lastSwipeAt: 0, lastScrollAt: 0, pinchActive: false, lastPinchAt: 0 }
    this.lastEdgeLabels = { left: '', right: '', both: '' }
    this.sequenceMatcher.reset()
    this.releaseDrag()
  }

  GestureController.prototype.loop = function (timestamp) {
    if (!this.active) return
    // All views share ONE stream. If the active view changes while tracking,
    // move the tracker onto the newly painted video element instead of
    // reading frames from a hidden one.
    if (!this.video || !this.video.getClientRects().length) {
      var visible = this.ctx.videoFor(this.ctx.activePanel())
      if (visible && visible !== this.video && visible.getClientRects().length) {
        // The old panel must not keep the last skeleton while the tracker is
        // already reading a different <video>. The next result repaints.
        this.clearOverlays()
        this.video = visible
        this.video.muted = true
        this.video.play().catch(function () {})
        this.panel = visible.closest('[data-gesture-panel]') || this.panel
        this.lastVideoTime = -1
      }
    }
    var video = this.video
    if (video && video.readyState >= 2 && video.currentTime !== this.lastVideoTime) {
      this.lastVideoTime = video.currentTime
      if (this.sending) {
        this.metrics.dropped += 1
      } else {
        this.sendFrame()
      }
    }
    // A drag must never outlive the frames that justify it: if the tracker has
    // gone quiet (camera unplugged, permission revoked, page throttled) the
    // Windows button is released instead of staying latched.
    if (this.drag && this.metrics.lastResultsAt && performance.now() - this.metrics.lastResultsAt > 1500) {
      this.releaseDrag('no camera frames')
    }
    // The same silence means the picture on the panel is stale: the last
    // skeleton would stay painted forever and the console would keep claiming
    // LIVE. Declare the loss and clear the overlays instead.
    var now = performance.now()
    var lastResult = this.metrics.lastResultsAt
    var silence = lastResult ? now - lastResult : (this.startedAt ? now - this.startedAt : 0)
    if (silence > (lastResult ? 1500 : 10000)) {
      this.markTrackingLost(lastResult
        ? 'no landmarks for ' + (Math.round(silence / 100) / 10) + ' s'
        : 'the hand tracker has not answered')
    }
    this.raf = root.requestAnimationFrame(this.loop)
  }

  // Tracking lost is a visible state, not an empty frame: the pointer is
  // hidden, the drag (if any) is dropped and every skeleton is erased.
  GestureController.prototype.markTrackingLost = function (reason) {
    if (!this.active) return
    var first = !this.trackingLost
    this.trackingLost = true
    this.trackingLostAt = performance.now()
    if (!first) return
    this.releaseDrag('tracking lost')
    this.hideCursor()
    this.clearOverlays()
    this.hands = { left: null, right: null }
    this.pointerTarget = null
    this.publishHands([])
    this.lastGesture = { name: 'none', confidence: 0, side: '', at: this.trackingLostAt, candidate: null, motion: 'tracking lost' }
    this.setStatus('TRACKING LOST - ' + String(reason || 'no camera results').toUpperCase())
    this.updateUi(true)
  }

  GestureController.prototype.sendFrame = function () {
    if (!this.tracker || !this.video || this.sending) return
    var self = this
    var started = performance.now()
    this.sending = true
    this.lastCaptureAt = started
    var request
    try {
      request = this.tracker.send({ image: this.video })
    } catch (err) {
      // MediaPipe can throw synchronously (a closed tracker, a detached
      // video). Without this the `sending` latch would stay true forever and
      // the loop would never recover; count it like any other failed frame.
      this.sending = false
      this.trackerFailures += 1
      if (this.trackerFailures === 12) this.markTrackingLost('the tracker threw on 12 consecutive frames')
      if (root.console && root.console.debug) root.console.debug('[JARVIS] hand frame rejected', err)
      return
    }
    if (!request || typeof request.then !== 'function') {
      this.sending = false
      return
    }
    request.then(function () {
      self.metrics.inferenceMs = Math.max(0, performance.now() - started)
      self.sending = false
      self.metrics.frames += 1
      self.trackerFailures = 0
    }, function (err) {
      self.sending = false
      self.trackerFailures += 1
      if (self.metrics.frames === 0) self.setError('The hand tracker rejected the first camera frame. Stop and restart tracking.', { silent: true })
      else if (self.trackerFailures === 12) self.markTrackingLost('the tracker rejected 12 consecutive frames')
      if (root.console && root.console.debug) root.console.debug('[JARVIS] hand frame skipped', err)
    })
  }

  GestureController.prototype.onResults = function (results) {
    if (!this.active) return
    var now = performance.now()
    this.frameCaptureAt = this.lastCaptureAt || now
    if (this.trackingLost) {
      var lostFor = this.trackingLostAt ? now - this.trackingLostAt : 0
      this.trackingLost = false
      this.trackingLostAt = 0
      this.trackerFailures = 0
      if (lostFor > 1500) this.flash('TRACKING RESTORED')
    }
    var sinceLast = this.metrics.lastResultsAt ? now - this.metrics.lastResultsAt : 0
    this.metrics.lastResultsAt = now
    this.metrics.captureMs = this.lastCaptureAt ? Math.max(0, now - this.lastCaptureAt) : 0
    if (sinceLast > 0) {
      var instant = 1000 / Math.max(1, sinceLast)
      this.metrics.fps = this.metrics.fps ? this.metrics.fps * 0.8 + instant * 0.2 : instant
    }
    var raw = (results && results.multiHandLandmarks) || []
    var handedness = (results && results.multiHandedness) || []
    var hands = []
    var recognitionStarted = performance.now()
    for (var i = 0; i < raw.length; i += 1) {
      var lm = raw[i]
      if (!validLandmarks(lm)) continue
      var info = handedness[i] || {}
      var score = typeof info.score === 'number' ? info.score : 0.8
      var rawLabel = String(info.label || '')
      var side = rawLabel === 'Left' ? 'right' : rawLabel === 'Right' ? 'left' : ((1 - lm[8].x) < 0.5 ? 'left' : 'right')
      var pose = handPose(lm, this.settings)
      var gesture = classifyPose(lm, pose, score, this.settings)
      var candidates = gesture.name === 'unknown' ? ENGINE.candidatePoses(pose, 3) : null
      hands.push({ side: side, lm: lm, score: score, pose: pose, gesture: gesture, candidates: candidates, lowConfidence: score < this.settings.minHandConfidence })
    }
    // Measured recognition cost: pose + classification for every hand in this
    // frame. No sampling, no estimate.
    this.metrics.recognitionMs = performance.now() - recognitionStarted
    hands = resolveHandSides(hands, this.hands)
    hands = hands.filter(function (hand) { return !hand.lowConfidence })
    this.publishHands(hands)
    this.draw(hands)
    // The last snapshot is always on the page: read window.__JARVIS_GESTURE_DEBUG__
    // (the object) or call window.__JARVIS_GESTURE_DEBUG_SNAP__() for a fresh one.
    root.__JARVIS_GESTURE_DEBUG__ = this.debugSnapshot()
    root.__JARVIS_GESTURE_DEBUG_SNAP__ = this.debugSnapshot.bind(this)
    var bySide = {
      left: hands.find(function (hand) { return hand.side === 'left' }) || null,
      right: hands.find(function (hand) { return hand.side === 'right' }) || null
    }
    this.hands = bySide
    this.updateEdgeLabels(bySide, now)
    if (this.calibrating) {
      this.captureCalibration(bySide, now)
      this.updateUi()
      return
    }
    if (this.poseRecording) {
      this.capturePoseSample(bySide, now)
      this.updateUi()
      return
    }
    if (this.sequenceRecording) {
      this.captureSequence(bySide, now)
      this.updateUi()
      return
    }
    if (this.paused) {
      this.hideCursor()
      this.setStatus(this.emergency ? 'EMERGENCY STOP - CONTROL PAUSED' : 'GESTURE CONTROL PAUSED')
      this.checkResumeGesture(bySide, now)
      this.updateUi()
      return
    }
    if (!hands.length) {
      this.lastStatus = ''
      this.setStatus('NO HANDS DETECTED')
      this.clearHandState()
      this.pointerTarget = null
      this.updateUi()
      return
    }
    if (this.paused) return
    this.setStatus(hands.length === 2 ? 'TWO HANDS TRACKED' : (bySide.right ? 'RIGHT HAND TRACKED' : 'LEFT HAND TRACKED'))
    var gestureForReadout = this.pickReadoutHand(bySide)
    if (gestureForReadout) {
      var readoutMotion = ENGINE.describeMotion(this.handState[gestureForReadout.side].motion)
      var readoutCandidate = null
      if (gestureForReadout.gesture.name === 'unknown' && Array.isArray(gestureForReadout.candidates) && gestureForReadout.candidates.length) {
        readoutCandidate = gestureForReadout.candidates[0]
        // Honest reporting: the closest template is named with its measured
        // confidence. Below 50% it is a guess, so the readout says "ambiguous"
        // instead of naming an intention the geometry does not support.
        this.lastCandidate = { name: readoutCandidate.name, confidence: readoutCandidate.confidence, motion: readoutMotion, at: now }
        if (readoutCandidate.confidence < 0.5) readoutCandidate = null
      }
      this.lastGesture = {
        name: gestureForReadout.gesture.name,
        confidence: gestureForReadout.gesture.confidence,
        side: gestureForReadout.side,
        at: now,
        candidate: readoutCandidate,
        motion: readoutMotion
      }
    }
    var consumed = this.handleTwoHands(bySide.left, bySide.right, now)
    if (!consumed) {
      if (bySide.right) this.handleSingleHand(bySide.right, now)
      if (bySide.left) this.handleSingleHand(bySide.left, now)
      this.maybeCustomGestures(bySide, now)
    }
    this.updateUi()
  }

  // A panel's overlay canvas. The dashboard Camera panel shipped an id-only
  // canvas while this lookup required the class, so that panel never received
  // (or cleared) a skeleton. Both spellings are accepted until every panel has
  // the class, and the markup now carries it.
  GestureController.prototype.panelCanvas = function (panel) {
    if (!panel || !panel.querySelector) return null
    return panel.querySelector('canvas.gesture-canvas') || panel.querySelector('canvas#gesture-canvas')
  }

  // Every overlay is cleared together. When the active view changes the
  // tracker moves to another <video>; clearing only the current panel leaves
  // the previous skeleton frozen on screen forever.
  GestureController.prototype.clearOverlays = function () {
    if (!root.document || !root.document.querySelectorAll) return
    var nodes = root.document.querySelectorAll('canvas.gesture-canvas, canvas#gesture-canvas')
    for (var i = 0; i < nodes.length; i += 1) this.clearCanvas(nodes[i])
  }

  GestureController.prototype.clearCanvas = function (canvas) {
    if (!canvas || !canvas.getContext) return
    var context = canvas.getContext('2d')
    if (!context) return
    context.save()
    context.setTransform(1, 0, 0, 1, 0, 0)
    context.clearRect(0, 0, canvas.width || 0, canvas.height || 0)
    context.restore()
  }

  GestureController.prototype.draw = function (hands) {
    if (!root.document) return
    var video = this.video
    var panel = (video && video.closest && video.closest('[data-gesture-panel]')) || this.panel
    var canvas = this.panelCanvas(panel)
    var context = canvas && canvas.getContext && canvas.getContext('2d')
    if (!canvas || !context) return
    // Draw in CSS pixels: the backing store follows the displayed box and the
    // device pixel ratio, so a narrow panel, a window resize or a 125%/200%
    // display can never stretch the skeleton. `object-fit` on the canvas is
    // gone; the same cover crop the video uses is applied to the landmarks.
    var rect = canvas.getBoundingClientRect ? canvas.getBoundingClientRect() : null
    var cssWidth = rect && rect.width ? rect.width : (canvas.clientWidth || 0)
    var cssHeight = rect && rect.height ? rect.height : (canvas.clientHeight || 0)
    if (!(cssWidth > 0) || !(cssHeight > 0)) return
    var dpr = Math.max(1, Number(root.devicePixelRatio) || 1)
    var backingWidth = Math.max(1, Math.round(cssWidth * dpr))
    var backingHeight = Math.max(1, Math.round(cssHeight * dpr))
    if (canvas.width !== backingWidth) canvas.width = backingWidth
    if (canvas.height !== backingHeight) canvas.height = backingHeight
    // Reset, never accumulate: resizing the canvas resets the context, but a
    // same-size frame would otherwise keep whatever transform was left behind.
    context.setTransform(dpr, 0, 0, dpr, 0, 0)
    context.clearRect(0, 0, cssWidth, cssHeight)
    var sourceWidth = video && video.videoWidth
    var sourceHeight = video && video.videoHeight
    if (sourceWidth > 0 && sourceHeight > 0) {
      this.sourceWidth = sourceWidth
      this.sourceHeight = sourceHeight
    }
    sourceWidth = this.sourceWidth
    sourceHeight = this.sourceHeight
    var transform = coverTransform(sourceWidth, sourceHeight, cssWidth, cssHeight)
    if (!transform) return
    var drawable = []
    for (var h = 0; h < hands.length; h += 1) {
      var hand = hands[h]
      if (!hand || !validLandmarks(hand.lm)) continue
      var points = new Array(21)
      for (var p = 0; p < 21; p += 1) points[p] = projectLandmark(hand.lm[p], transform, true)
      drawable.push({ side: hand.side, points: points })
    }
    if (!drawable.length) return
    var connections = root.HAND_CONNECTIONS || []
    for (var d = 0; d < drawable.length; d += 1) {
      var item = drawable[d]
      var pts = item.points
      var core = item.side === 'left' ? 'rgba(255, 166, 87, 0.95)' : 'rgba(127, 243, 255, 0.95)'
      var glow = item.side === 'left' ? 'rgba(255, 122, 26, 0.3)' : 'rgba(34, 199, 242, 0.3)'
      context.save()
      context.lineCap = 'round'
      context.shadowColor = item.side === 'left' ? '#ff9d4d' : '#00d9ff'
      context.shadowBlur = 22
      context.strokeStyle = glow
      context.lineWidth = 9
      context.beginPath()
      for (var c = 0; c < connections.length; c += 1) {
        var pair = connections[c]
        var a = pair && pts[pair[0]]
        var b = pair && pts[pair[1]]
        // A connection that is not inside this hand is never drawn: that is
        // what used to join two hands when both were present.
        if (!a || !b) continue
        context.moveTo(a.x, a.y)
        context.lineTo(b.x, b.y)
      }
      context.stroke()
      context.shadowBlur = 12
      context.strokeStyle = core
      context.lineWidth = 2.5
      context.beginPath()
      for (var c2 = 0; c2 < connections.length; c2 += 1) {
        var pair2 = connections[c2]
        var a2 = pair2 && pts[pair2[0]]
        var b2 = pair2 && pts[pair2[1]]
        if (!a2 || !b2) continue
        context.moveTo(a2.x, a2.y)
        context.lineTo(b2.x, b2.y)
      }
      context.stroke()
      for (var i = 0; i < pts.length; i += 1) {
        var tip = i === 8
        context.shadowBlur = tip ? 26 : 10
        context.fillStyle = tip ? (item.side === 'left' ? '#ffe1c4' : '#b8f7ff') : 'rgba(142, 232, 255, 0.9)'
        context.beginPath()
        context.arc(pts[i].x, pts[i].y, tip ? 7 : 3.5, 0, Math.PI * 2)
        context.fill()
      }
      context.shadowBlur = 6
      context.fillStyle = core
      context.font = 'bold 12px Rajdhani, Arial'
      context.fillText(item.side === 'left' ? 'L' : 'R', pts[0].x + 12, pts[0].y - 12)
      context.restore()
    }
  }

  GestureController.prototype.publishHands = function (hands) {
    root.__JARVIS_HANDS__ = hands
  }

  // One snapshot of every number that decides where a skeleton is painted.
  // The overlay math is proven by tests/test_gesture_overlay.mjs, so when a
  // ghost skeleton appears the cause is in the INPUT (which video, what size,
  // what the model returned, how long since the last result) - and that is what
  // this reports. Read it from devtools as window.__JARVIS_GESTURE_DEBUG__(),
  // or add ?gestdebug=1 to the dashboard URL to see it in the status line.
  GestureController.prototype.debugSnapshot = function () {
    var video = this.video
    var canvas = this.panelCanvas(this.panel)
    var vrect = null, crect = null
    try { vrect = video && video.getBoundingClientRect ? video.getBoundingClientRect() : null } catch (e) { }
    try { crect = canvas && canvas.getBoundingClientRect ? canvas.getBoundingClientRect() : null } catch (e) { }
    var hands = root.__JARVIS_HANDS__ || []
    var rows = []
    for (var i = 0; i < hands.length; i += 1) {
      var lm = (hands[i] && hands[i].lm) || []
      if (lm.length !== 21) continue
      var xs = [], ys = []
      for (var p = 0; p < 21; p += 1) { xs.push(lm[p].x); ys.push(lm[p].y) }
      var minx = Math.min.apply(null, xs), maxx = Math.max.apply(null, xs)
      var miny = Math.min.apply(null, ys), maxy = Math.max.apply(null, ys)
      rows.push({
        side: hands[i].side, score: Number(hands[i].score || 0),
        x: [Number(minx.toFixed(2)), Number(maxx.toFixed(2))],
        y: [Number(miny.toFixed(2)), Number(maxy.toFixed(2))],
        // A real hand fills a plausible part of the frame; a ghost is either
        // tiny (noise) or covers most of it (the model locking onto a face/body).
        span: Number(Math.hypot(maxx - minx, maxy - miny).toFixed(2)),
      })
    }
    return {
      active: !!this.active, lost: !!this.trackingLost,
      silenceMs: this.metrics.lastResultsAt ? Math.round(performance.now() - this.metrics.lastResultsAt) : null,
      fps: Math.round(this.metrics.fps || 0), dropped: this.metrics.dropped,
      video: video ? {
        src: video.videoWidth + 'x' + video.videoHeight,
        box: vrect ? [Math.round(vrect.width), Math.round(vrect.height)] : null,
        ready: video.readyState, visible: !!(vrect && vrect.width > 0),
        time: Number(video.currentTime || 0),
      } : null,
      // The size the projection is actually using. If this disagrees with
      // video.src, every landmark is mapped with the wrong scale.
      sourceUsed: [this.sourceWidth || 0, this.sourceHeight || 0],
      canvas: canvas ? {
        box: crect ? [Math.round(crect.width), Math.round(crect.height)] : null,
        backing: [canvas.width, canvas.height],
      } : null,
      dpr: Number(root.devicePixelRatio || 1),
      hands: rows,
    }
  }

  GestureController.prototype.updateEdgeLabels = function (bySide, now) {
    var current = {
      left: bySide.left ? bySide.left.gesture.name : 'none',
      right: bySide.right ? bySide.right.gesture.name : 'none',
      both: bySide.left && bySide.right && bySide.left.gesture.name === bySide.right.gesture.name ? bySide.left.gesture.name : 'none'
    }
    // A paused, calibrating or recording session must never drive a stored
    // sequence mapping - the labels are still recorded for the UI, but the
    // matcher is not fed.
    var live = !this.paused && !this.calibrating && !this.poseRecording
    for (var key in current) {
      if (!Object.prototype.hasOwnProperty.call(current, key)) continue
      var label = key + ':' + current[key]
      if (this.lastEdgeLabels[key] === label) continue
      this.lastEdgeLabels[key] = label
      this.recordSequenceLabel(label, now)
      if (!live || this.sequenceRecording) continue
      var match = this.sequenceMatcher.push(label, now)
      if (match) this.runSequenceMatch(match)
    }
  }

  GestureController.prototype.recordSequenceLabel = function (label, now) {
    if (!this.sequenceRecording) return
    var last = this.recordedLabels[this.recordedLabels.length - 1]
    if (!last || last.label !== label) this.recordedLabels.push({ label: label, at: now })
  }

  GestureController.prototype.captureCalibration = function (bySide, now) {
    var capture = this.calibrating
    var hand = this.pickPointerHand(bySide)
    if (hand) {
      var mirroredX = 1 - hand.lm[8].x
      capture.samples.push({ x: mirroredX, y: hand.lm[8].y })
    }
    if (now - capture.startedAt >= capture.duration) this.finishCalibration()
  }

  GestureController.prototype.finishCalibration = function () {
    var capture = this.calibrating
    if (!capture) return
    this.calibrating = null
    if (capture.samples.length < 12) {
      this.setError('Calibration saw too few frames. Keep your pointer hand in view and try again.', { silent: false })
      this.updateUi(true)
      return
    }
    var xs = capture.samples.map(function (p) { return p.x })
    var ys = capture.samples.map(function (p) { return p.y })
    var minX = Math.min.apply(null, xs) - 0.02
    var maxX = Math.max.apply(null, xs) + 0.02
    var minY = Math.min.apply(null, ys) - 0.02
    var maxY = Math.max.apply(null, ys) + 0.02
    if (maxX - minX < 0.12 || maxY - minY < 0.12) {
      this.setError('Calibration range is too small. Move the hand across a wider area, then calibrate again.', { silent: false })
      this.updateUi(true)
      return
    }
    this.calibration = { minX: minX, maxX: maxX, minY: minY, maxY: maxY, samples: capture.samples.length, at: Date.now() }
    writeJson(STORAGE_CALIBRATION, this.calibration)
    this.flash('RANGE CALIBRATED')
    this.setStatus('RANGE CALIBRATED')
    this.updateUi(true)
  }

  GestureController.prototype.startCalibration = function () {
    if (!this.active) {
      if (this.ctx.showToast) this.ctx.showToast('Start hand tracking before calibrating.', true)
      return
    }
    this.resetRuntimeState()
    this.calibrating = { startedAt: performance.now(), duration: 4200, samples: [] }
    this.setStatus('CALIBRATING - MOVE THE POINTER HAND ACROSS THE CONTROL AREA')
    this.flash('CALIBRATING 4 S')
    this.updateUi(true)
  }

  GestureController.prototype.resetCalibration = function () {
    this.calibration = null
    try { root.localStorage.removeItem(STORAGE_CALIBRATION) } catch (err) { /* storage blocked */ }
    this.flash('CALIBRATION RESET')
    this.updateUi(true)
  }

  GestureController.prototype.capturePoseSample = function (bySide, now) {
    var capture = this.poseRecording
    var hand = this.pickReadoutHand(bySide)
    if (hand) {
      capture.samples.push(ENGINE.normalizeLandmarks(hand.lm))
      capture.lastScore = hand.score
    }
    if (now - capture.startedAt >= capture.duration) this.finishPoseRecording()
  }

  GestureController.prototype.startPoseRecording = function () {
    if (!this.active) {
      if (this.ctx.showToast) this.ctx.showToast('Start hand tracking before recording a pose.', true)
      return
    }
    this.poseRecording = { startedAt: performance.now(), duration: 1600, samples: [], lastScore: 0 }
    this.setStatus('RECORDING POSE - HOLD IT STEADY')
    this.flash('RECORDING POSE')
    this.updateUi(true)
    var self = this
    root.setTimeout(function () { if (self.poseRecording) self.finishPoseRecording() }, 2100)
  }

  GestureController.prototype.finishPoseRecording = function () {
    var capture = this.poseRecording
    if (!capture) return
    this.poseRecording = null
    if (capture.samples.length < 8) {
      this.setError('Pose recording saw too few frames. Hold the pose in view for the full recording.', { silent: false })
      this.updateUi(true)
      return
    }
    var template = new Array(63).fill(0)
    for (var i = 0; i < capture.samples.length; i += 1) {
      for (var j = 0; j < 63; j += 1) template[j] += capture.samples[i][j]
    }
    for (var k = 0; k < 63; k += 1) template[k] /= capture.samples.length
    this.addMapping('pose', template, null)
  }

  GestureController.prototype.startSequenceRecording = function () {
    if (!this.active) {
      if (this.ctx.showToast) this.ctx.showToast('Start hand tracking before recording a sequence.', true)
      return
    }
    this.recordedLabels = []
    this.lastEdgeLabels = { left: '', right: '', both: '' }
    this.sequenceRecording = { startedAt: performance.now(), duration: 4600 }
    this.setStatus('RECORDING SEQUENCE - PERFORM THE GESTURES NOW')
    this.flash('RECORDING SEQUENCE')
    this.updateUi(true)
    var self = this
    root.setTimeout(function () { if (self.sequenceRecording) self.finishSequenceRecording() }, 5200)
  }

  GestureController.prototype.captureSequence = function (bySide, now) {
    if (now - this.sequenceRecording.startedAt >= this.sequenceRecording.duration) this.finishSequenceRecording()
  }

  GestureController.prototype.finishSequenceRecording = function () {
    var recording = this.sequenceRecording
    if (!recording) return
    this.sequenceRecording = null
    var labels = this.recordedLabels.map(function (item) { return item.label })
    var compressed = labels.filter(function (label, index) { return index === 0 || labels[index - 1] !== label })
    if (compressed.length < 2) {
      this.setError('Sequence recording did not hear enough distinct gestures. Perform at least two gestures.', { silent: false })
      this.updateUi(true)
      return
    }
    this.addMapping('sequence', null, compressed)
  }

  GestureController.prototype.addMapping = function (kind, template, sequence) {
    var nameInput = root.document && root.document.getElementById('gesture-mapping-name')
    var actionSelect = root.document && root.document.getElementById('gesture-mapping-action')
    var name = String((nameInput && nameInput.value) || '').trim() || (kind === 'pose' ? 'Custom pose' : 'Custom sequence')
    var action = String((actionSelect && actionSelect.value) || 'click')
    if (!ACTIONS[action]) {
      this.setError('Choose a valid action for this gesture.', { silent: false })
      return
    }
    var mapping = {
      id: 'g' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name: name.slice(0, 40),
      kind: kind,
      template: template,
      sequence: sequence,
      action: action,
      createdAt: Date.now()
    }
    this.mappings.push(mapping)
    writeJson(STORAGE_MAPPINGS, this.mappings)
    this.sequenceMatcher = this.buildSequenceMatcher()
    if (nameInput) nameInput.value = ''
    this.flash(kind === 'pose' ? 'POSE MAPPED' : 'SEQUENCE MAPPED')
    this.setStatus((kind === 'pose' ? 'POSE' : 'SEQUENCE') + ' MAPPED TO ' + ACTIONS[action].label.toUpperCase())
    this.renderMappings()
    this.updateUi(true)
  }

  GestureController.prototype.deleteMapping = function (id) {
    this.mappings = this.mappings.filter(function (mapping) { return mapping.id !== id })
    writeJson(STORAGE_MAPPINGS, this.mappings)
    this.sequenceMatcher = this.buildSequenceMatcher()
    this.renderMappings()
    this.flash('MAPPING REMOVED')
  }

  GestureController.prototype.buildSequenceMatcher = function () {
    var sequences = []
    for (var i = 0; i < this.mappings.length; i += 1) {
      var mapping = this.mappings[i]
      if (mapping.kind === 'sequence' && Array.isArray(mapping.sequence) && mapping.sequence.length) {
        sequences.push({ id: mapping.id, sequence: mapping.sequence, mapping: mapping, cooldownMs: 1500 })
      }
    }
    return new ENGINE.SequenceMatcher(sequences, { windowMs: 4200 })
  }

  GestureController.prototype.renderMappings = function () {
    var rootNode = root.document && root.document.getElementById('gesture-mappings')
    if (!rootNode) return
    if (!this.mappings.length) {
      rootNode.innerHTML = '<li class="gesture-mapping-empty">No custom gestures yet. Record a pose or a short sequence and choose an action.</li>'
      return
    }
    var rows = []
    for (var i = 0; i < this.mappings.length; i += 1) {
      var mapping = this.mappings[i]
      var action = ACTIONS[mapping.action] || { label: mapping.action }
      rows.push('<li class="gesture-mapping-row"><span class="gesture-mapping-kind">' + (mapping.kind === 'pose' ? 'POSE' : 'SEQUENCE') + '</span>' +
        '<div><strong>' + escapeHtml(mapping.name) + '</strong><small>' + escapeHtml(action.label) + '</small></div>' +
        '<button type="button" data-gesture-delete="' + escapeHtml(mapping.id) + '" aria-label="Delete mapping">Delete</button></li>')
    }
    rootNode.innerHTML = rows.join('')
  }

  GestureController.prototype.mapLastAmbiguous = function () {
    if (!this.lastAmbiguous || !this.lastAmbiguous.vector) {
      if (this.ctx.showToast) this.ctx.showToast('No ambiguous pose captured yet. Hold a pose while tracking.', true)
      return
    }
    this.addMapping('pose', this.lastAmbiguous.vector, null)
    this.lastAmbiguous = null
  }

  GestureController.prototype.maybeCustomGestures = function (bySide, now) {
    if (!this.mappings.length) return
    var hands = [bySide.right, bySide.left].filter(Boolean)
    for (var i = 0; i < hands.length; i += 1) {
      var hand = hands[i]
      if (hand.gesture.name !== 'unknown') continue
      var vector = ENGINE.normalizeLandmarks(hand.lm)
      var best = ENGINE.matchTemplates(vector, this.mappings)
      if (!best) continue
      var distance = best.distance
      var threshold = 0.5
      if (distance <= threshold) {
        var state = this.handState[hand.side]
        state.customFrames += 1
        if (state.customFrames >= 2 && now - state.lastCustomAt > 1200) {
          state.lastCustomAt = now
          state.customFrames = 0
          this.lastGesture = { name: best.mapping.name, confidence: clamp(1 - distance / threshold, 0, 1), side: hand.side, at: now, candidate: null, motion: ENGINE.describeMotion(state.motion) }
          this.runAction(best.mapping.action, { source: 'custom-pose', label: best.mapping.name })
        }
      } else {
        this.handState[hand.side].customFrames = 0
        if (distance <= threshold * 1.4) {
          this.lastAmbiguous = { vector: vector, distance: distance, name: best.mapping.name, at: now }
          this.setStatus('AMBIGUOUS NEAR ' + String(best.mapping.name).toUpperCase() + ' - NOT EXECUTED')
        }
      }
    }
  }

  GestureController.prototype.pickPointerHand = function (bySide) {
    if (this.settings.pointerHand === 'left') return bySide.left || bySide.right
    if (this.settings.pointerHand === 'both') {
      if (bySide.right && bySide.left) {
        var lastRight = this.handState.right.lastSeenAt || 0
        var lastLeft = this.handState.left.lastSeenAt || 0
        return lastRight >= lastLeft ? bySide.right : bySide.left
      }
      return bySide.right || bySide.left
    }
    return bySide.right || bySide.left
  }

  GestureController.prototype.pickSecondaryHand = function (bySide) {
    if (this.settings.pointerHand === 'left') return bySide.right
    if (this.settings.pointerHand === 'both') return null
    return bySide.left
  }

  GestureController.prototype.pickReadoutHand = function (bySide) {
    var hands = [bySide.right, bySide.left].filter(Boolean)
    if (!hands.length) return null
    hands.sort(function (a, b) { return b.score - a.score })
    return hands[0]
  }

  GestureController.prototype.handleSingleHand = function (hand, now) {
    var pointer = this.pickPointerHand({ left: this.hands.left, right: this.hands.right })
    var secondary = this.pickSecondaryHand({ left: this.hands.left, right: this.hands.right })
    if (pointer && pointer.side === hand.side) this.handlePointerHand(hand, now)
    else if (secondary && secondary.side === hand.side) this.handleSecondaryHand(hand, now)
  }

  GestureController.prototype.pointerSuspended = function () {
    return this.pointerSuspendedUntil > performance.now()
  }

  // ── pinch = press and release ────────────────────────────────────────
  // The old code fired a click the moment a pinch was seen, on the loose 0.42
  // threshold, which is why stray clicks happened and why pinch could never be
  // a drag. A pinch is now a press-release:
  //   * released quickly, without travelling more than clickMaxMove  -> click
  //   * held past dragHoldMs, or travelled further                     -> drag
  //   * released after clickWindowMs or after moving far               -> nothing
  // Hysteresis (pinchOn to enter, pinchOff to leave) keeps one noisy frame
  // from opening and closing the state on the threshold itself.
  GestureController.prototype.pinchKind = function (pose, hs) {
    var on = Number(this.settings.pinchOn) || DEFAULT_CONFIG.pinchOn
    var off = Math.max(Number(this.settings.pinchOff) || on + 0.12, on + 0.04)
    var held = hs.pinch.kind
    if (held === 'double') return (pose.pinchR < off && pose.pinchI > off && pose.pinchM > off) ? 'double' : ''
    if (held === 'left') return pose.pinchI < off ? 'left' : ''
    if (held === 'right') return pose.pinchM < off ? 'right' : ''
    if (pose.pinchR < on && pose.pinchI > off && pose.pinchM > off) return 'double'
    if (pose.pinchI < on) return 'left'
    if (pose.pinchM < on) return 'right'
    return ''
  }

  GestureController.prototype.endPinch = function (hs) {
    hs.pinch.kind = ''
    hs.pinch.startedAt = 0
    hs.pinch.armed = false
  }

  // How far the HAND travelled since the pinch started. Measuring the smoothed
  // pointer instead would count the filter's own convergence as movement, so a
  // tap right after a quick reach could be refused as "moved".
  GestureController.prototype.pinchTravel = function (pinch) {
    var from = pinch.startTarget || { x: pinch.startX, y: pinch.startY }
    var to = pinch.lastTarget || { x: this.pointer.x, y: this.pointer.y }
    return Math.hypot(to.x - from.x, to.y - from.y)
  }

  // The travel reference must be the finger that is actually pinching. Reading
  // a middle pinch on the index tip counts the index moving as the hand
  // travelling, which would silently refuse a legitimate right click.
  GestureController.prototype.pinchTipIndex = function (kind) {
    return kind === 'right' ? 12 : kind === 'double' ? 16 : 8
  }

  GestureController.prototype.finishPinch = function (hand, hs, now) {
    var pinch = hs.pinch
    var kind = pinch.kind
    var held = now - pinch.startedAt
    var moved = this.pinchTravel(pinch)
    if (this.drag) {
      // The drag already owns the button; releasing the pinch drops it.
      this.releaseDrag('pinch released')
      return
    }
    if (!pinch.armed) {
      this.setStatus('PINCH IGNORED - HAND WAS NOT SETTLED')
      return
    }
    if (held > this.settings.clickWindowMs) {
      this.setStatus('PINCH HELD TOO LONG - NO CLICK')
      return
    }
    if (moved > this.settings.clickMaxMove) {
      this.setStatus('PINCH MOVED - NO CLICK')
      return
    }
    hs.lastClickAt = now
    if (kind === 'right') {
      this.clickAtPointer('right', hand.side)
      return
    }
    if (kind === 'double') {
      this.clickAtPointer('double', hand.side)
      return
    }
    this.clickAtPointer('left', hand.side)
  }

  GestureController.prototype.handlePointerHand = function (hand, now) {
    var pose = hand.pose
    var hs = this.handState[hand.side]
    if (!hs.firstSeenAt) hs.firstSeenAt = now
    hs.lastSeenAt = now
    // Movement, speed and duration are measured on the mirrored palm point: the
    // same point the pointer follows, so "moving right" in the readout means
    // right on screen.
    ENGINE.updateMotion(hs.motion, { x: 1 - pose.palmPos.x, y: pose.palmPos.y }, now)
    if (this.pointerSuspended()) {
      this.hideCursor()
      this.setStatus('POINTER PAUSED')
      return
    }
    var settled = now - hs.firstSeenAt > this.settings.armDelayMs && hand.score >= this.settings.clickConfidence
    if (pose.palm && !pose.pointing) {
      if (this.drag) this.releaseDrag('open palm')
      this.endPinch(hs)
      this.hideCursor()
      this.setStatus('OPEN PALM - POINTER PAUSED')
      hs.peaceSince = 0
      hs.scrollAcc = 0
      return
    }
    if (pose.fist) {
      // A closed fist grabs the page: real travel accumulates into real wheel
      // notches, so the scroll follows the hand instead of a timer. The pointer
      // is deliberately left alone - a scroll must not fling the cursor.
      if (this.drag) this.releaseDrag('fist')
      this.endPinch(hs)
      hs.armed = true
      hs.scrollAcc += hs.motion.lastDy
      var notches = 0
      while (Math.abs(hs.scrollAcc) >= this.settings.fistScrollStep && notches < 3) {
        notches += 1
        hs.scrollAcc -= hs.scrollAcc > 0 ? this.settings.fistScrollStep : -this.settings.fistScrollStep
      }
      if (notches) {
        var down = hs.motion.lastDy > 0
        var announce = now - hs.lastScrollAt > 420
        if (announce) hs.lastScrollAt = now
        this.scrollDesktop(down ? -notches : notches, announce ? (down ? 'SCROLL DOWN' : 'SCROLL UP') : '')
        if (announce) this.setStatus('FIST SCROLL - ' + (down ? 'DOWN' : 'UP'))
      } else {
        this.hideCursor()
        this.setStatus('FIST SCROLL - MOVE THE HAND UP OR DOWN')
      }
      return
    }
    hs.scrollAcc = 0
    var kind = this.pinchKind(pose, hs)
    if (kind !== hs.pinch.kind) {
      if (hs.pinch.kind) {
        this.finishPinch(hand, hs, now)
        this.endPinch(hs)
      }
      hs.pinch.kind = kind
      if (kind) {
        hs.pinch.startedAt = now
        hs.pinch.startX = this.pointer.x
        hs.pinch.startY = this.pointer.y
        hs.pinch.startTarget = this.screenPointFor(hand.lm, this.pinchTipIndex(kind))
        hs.pinch.lastTarget = hs.pinch.startTarget
        hs.pinch.armed = settled && now - hs.lastClickAt > this.settings.clickCooldownMs
      }
    }
    if (kind) {
      hs.pinch.lastTarget = this.screenPointFor(hand.lm, this.pinchTipIndex(kind))
      this.movePointerFor(hand.lm)
      var held = now - hs.pinch.startedAt
      var moved = this.pinchTravel(hs.pinch)
      if (kind === 'left' && !this.drag && (held >= this.settings.dragHoldMs || moved > this.settings.clickMaxMove * 2)) {
        this.beginDrag(hand, 'pinch hold')
      }
      if (this.drag) {
        this.setStatus('PINCH DRAG - RELEASE THE PINCH TO DROP')
        if (now - this.drag.startedAt > 12000) this.releaseDrag('drag watchdog')
      } else {
        this.setStatus(kind === 'right' ? 'RIGHT CLICK - RELEASE TO CLICK'
          : kind === 'double' ? 'DOUBLE CLICK - RELEASE TO CLICK'
            : 'PINCH - HOLD TO DRAG, RELEASE TO CLICK')
      }
      return
    }
    var semantic = this.settings.semantic && pose.peace
    if (semantic) {
      if (!hs.peaceSince) hs.peaceSince = now
      if (now - hs.peaceSince > this.settings.semanticHoldMs && now - hs.lastSemanticAt > 1600) {
        hs.lastSemanticAt = now
        this.semanticActivate('gesture', hand.side)
      }
    } else {
      hs.peaceSince = 0
    }
    if (pose.up[1] === 1) {
      this.movePointerFor(hand.lm)
      this.setStatus('POINTER CONTROL - ' + hand.side.toUpperCase() + ' HAND')
    } else {
      this.hideCursor()
      this.setStatus('NO POINTER POSE - POINT, PINCH OR FIST')
    }
    if (this.settings.semanticClicks && pose.pointing) this.scanTarget(now, true)
  }

  GestureController.prototype.handleSecondaryHand = function (hand, now) {
    var pose = hand.pose
    var hs = this.handState[hand.side]
    if (!hs.firstSeenAt) hs.firstSeenAt = now
    hs.lastSeenAt = now
    if (pose.palm) {
      if (hs.armed && now - hs.lastClickAt > 1600) {
        hs.armed = false
        hs.lastClickAt = now
        this.ctx.navigateTo('dashboard')
        this.flash('DASHBOARD HOME')
        this.setStatus('LEFT PALM - DASHBOARD HOME')
      }
      return
    }
    hs.armed = true
    if (pose.pinchI < this.settings.pinchOn) {
      hs.holdFrames += 1
      if (hs.armed && hs.holdFrames >= this.settings.stableFrames && now - hs.lastClickAt > this.settings.clickCooldownMs) {
        hs.armed = false
        hs.lastClickAt = now
        var point = this.screenPointFor(hand.lm, 8)
        this.clickDomAt(point, 'left', 'secondary')
      }
    } else {
      hs.holdFrames = 0
    }
  }

  GestureController.prototype.handleTwoHands = function (left, right, now) {
    if (!left || !right) {
      this.two.mode = ''
      this.two.lastPalm = null
      this.two.pinchActive = false
      return false
    }
    var lp = left.pose
    var rp = right.pose
    // Measure the index fingertips, not the palms: the same distance drives
    // both-index scaling and the two-pinch zoom, so it must follow the fingers
    // the user is actually moving.
    var indexDistance = function () {
      return Math.hypot(left.lm[8].x - right.lm[8].x, left.lm[8].y - right.lm[8].y)
    }
    if (lp.fist && rp.fist) {
      if (!this.paused) {
        this.paused = true
        this.emergency = false
        this.releaseDrag()
        this.flash('GESTURES PAUSED')
        this.setStatus('BOTH FISTS - GESTURE CONTROL PAUSED')
        this.updateToggles()
        this.updateUi(true)
      }
      return true
    }
    if (lp.pinchI < this.settings.pinchOn && rp.pinchI < this.settings.pinchOn) {
      if (!this.two.pinchActive) {
        this.two.pinchActive = true
        this.two.lastPinchAt = now
        this.two.mode = 'pinch'
        this.two.anchor = indexDistance()
        this.two.base = this.hudScale
      } else {
        var pinchDelta = (indexDistance() - this.two.anchor) * 2.2 * this.settings.zoomGain
        if (Math.abs(pinchDelta) > 0.004) {
          this.applyZoom(this.two.base + pinchDelta)
          this.flash(pinchDelta > 0 ? 'ZOOM IN' : 'ZOOM OUT')
        }
      }
      return true
    }
    if (this.two.pinchActive) {
      this.two.pinchActive = false
      this.two.mode = ''
    }
    if (lp.pointing && rp.pointing) {
      if (this.two.mode !== 'scale') {
        this.two.mode = 'scale'
        this.two.anchor = indexDistance()
        this.two.base = this.hudScale
      } else {
        this.applyZoom(this.two.base + (indexDistance() - this.two.anchor) * 1.7 * this.settings.zoomGain)
      }
      return true
    }
    if (this.two.mode === 'scale') this.two.mode = ''
    if (lp.palm && rp.palm) {
      var avg = { x: (lp.palmPos.x + rp.palmPos.x) / 2, y: (lp.palmPos.y + rp.palmPos.y) / 2 }
      if (this.two.lastPalm) {
        var dx = -(avg.x - this.two.lastPalm.x)
        var dy = avg.y - this.two.lastPalm.y
        if (Math.abs(dx) > 0.13 && now - this.two.lastSwipeAt > 1200) {
          this.two.lastSwipeAt = now
          this.two.lastPalm = null
          this.ctx.navSection(dx > 0 ? 1 : -1)
          this.flash(dx > 0 ? 'NEXT SECTION' : 'PREVIOUS SECTION')
          return true
        }
        if (Math.abs(dy) > 0.005) {
          this.scrollView(dy * 5600 * this.settings.scrollGain)
          if (now - this.two.lastScrollAt > 700) {
            this.two.lastScrollAt = now
            this.flash('TWO-HAND SCROLL')
          }
        }
      }
      this.two.lastPalm = avg
      return true
    }
    this.two.lastPalm = null
    return false
  }

  GestureController.prototype.checkResumeGesture = function (bySide, now) {
    if (!bySide.left || !bySide.right) return
    if (!(bySide.left.pose.palm && bySide.right.pose.palm)) {
      this.handState.left.resumeSince = 0
      this.handState.right.resumeSince = 0
      return
    }
    if (!this.handState.left.resumeSince) this.handState.left.resumeSince = now
    if (now - this.handState.left.resumeSince > 800) this.resume('both palms')
  }

  GestureController.prototype.movePointerFor = function (lm, tipIndex) {
    var point = this.screenPointFor(lm, typeof tipIndex === 'number' ? tipIndex : 8)
    this.movePointerTo(point, false)
  }

  GestureController.prototype.screenPointFor = function (lm, tipIndex) {
    return ENGINE.mapToScreen(lm, this.calibration, {
      width: root.innerWidth || 1280,
      height: root.innerHeight || 720
    }, this.settings.sensitivity, tipIndex)
  }

  // The JARVIS window sits on the desktop, so the same hand position has to
  // become two coordinates:
  //   * the viewport point, which paints the preview dot and resolves DOM
  //     targets (window space, unchanged); and
  //   * the real cursor pixel, which is what the user actually sees move.
  // The desktop origin/size comes from the bridge, which owns the coordinate
  // space. The old code used screen.availWidth/availHeight: those exclude the
  // taskbar (the bottom of the screen was unreachable) and they are the browser's
  // pixels, not the bridge's, so any DPI difference skewed the whole mapping.
  GestureController.prototype.desktopPoint = function () {
    var viewportWidth = root.innerWidth || 1280
    var viewportHeight = root.innerHeight || 720
    var screenWidth = (root.screen && root.screen.width) || viewportWidth
    var screenHeight = (root.screen && root.screen.height) || viewportHeight
    var desktop = this.desktop
    var scaleX = desktop && desktop.width && screenWidth ? desktop.width / screenWidth : 1
    var scaleY = desktop && desktop.height && screenHeight ? desktop.height / screenHeight : 1
    var originX = desktop ? Number(desktop.left) || 0 : 0
    var originY = desktop ? Number(desktop.top) || 0 : 0
    var chromeX = ((root.outerWidth || viewportWidth) - viewportWidth) / 2
    var chromeY = (root.outerHeight || viewportHeight) - viewportHeight
    var windowX = typeof root.screenX === 'number' ? root.screenX : 0
    var windowY = typeof root.screenY === 'number' ? root.screenY : 0
    var spanX = desktop ? desktop.width : screenWidth
    var spanY = desktop ? desktop.height : screenHeight
    var x = originX + (windowX + chromeX + this.pointer.x) * scaleX
    var y = originY + (windowY + chromeY + this.pointer.y) * scaleY
    return {
      x: Math.round(clamp(x, originX, originX + Math.max(1, spanX) - 1)),
      y: Math.round(clamp(y, originY, originY + Math.max(1, spanY) - 1))
    }
  }

  GestureController.prototype.movePointerTo = function (target, dragging) {
    var viewportWidth = root.innerWidth || 1280
    var viewportHeight = root.innerHeight || 720
    var deadzone = this.settings.deadzone * Math.min(viewportWidth, viewportHeight)
    if (!dragging && Math.abs(target.x - this.pointer.x) < deadzone && Math.abs(target.y - this.pointer.y) < deadzone) {
      this.updateCursorDot()
      return
    }
    var seconds = performance.now() / 1000
    var filteredX = this.filterX.filter(target.x, seconds)
    var filteredY = this.filterY.filter(target.y, seconds)
    if (dragging) {
      this.pointer.x = filteredX
      this.pointer.y = filteredY
    } else {
      this.pointer.x += (filteredX - this.pointer.x) * 0.72
      this.pointer.y += (filteredY - this.pointer.y) * 0.72
    }
    this.pointer.x = clamp(this.pointer.x, 0, viewportWidth)
    this.pointer.y = clamp(this.pointer.y, 0, viewportHeight)
    this.updateCursorDot()
    var nowMs = performance.now()
    if (this.mouseInputReady() && nowMs - this.lastMoveSent > 24) {
      this.lastMoveSent = nowMs
      this.sendBridgeMove(this.desktopPoint())
    }
    this.scanTarget(nowMs, false)
  }

  // The bridge owns the PowerShell input worker. When the bridge explicitly
  // reports that worker as dead, sending forty rejected moves a second helps
  // nobody: the pointer holds still and the console says why. An unreported
  // state is NOT treated as broken - the move ack is the real judge.
  GestureController.prototype.mouseInputReady = function () {
    return Boolean(this.state.bridgeOnline) && this.mouseInput.ready !== false
  }

  // Every move is acked with the position the cursor actually reached. That is
  // the difference between "the bridge accepted the request" and "the pointer
  // moved", which is exactly what the old silent-success path got wrong.
  GestureController.prototype.sendBridgeMove = function (point) {
    var self = this
    var started = performance.now()
    var captureAt = this.frameCaptureAt
    var request = this.ctx.bridgeMouse({ action: 'move', x: point.x, y: point.y })
    if (!request || !request.then) {
      this.reportMoveFailure('the bridge helper is unavailable')
      return
    }
    request.then(function (result) {
      self.markMoveLatency(started, captureAt)
      if (!result || result.ok === false) {
        self.reportMoveFailure(String((result && (result.error || result.message)) || 'no answer from the bridge'))
        return
      }
      if (typeof result.x === 'number' && typeof result.y === 'number') {
        var error = Math.hypot(result.x - point.x, result.y - point.y)
        self.mapError = self.mapError ? self.mapError * 0.8 + error * 0.2 : error
        self.cursor = { x: result.x, y: result.y, at: performance.now() }
        self.cursorError = ''
      }
    }).catch(function () { self.reportMoveFailure('the bridge request failed') })
  }

  GestureController.prototype.reportMoveFailure = function (reason) {
    var now = performance.now()
    this.metrics.failures += 1
    // Rate-limit repeats, but never swallow the FIRST failure: a message at
    // t<1200 ms used to be dropped because the window's zero start looked like
    // a recent message, so the very first rejection was silent.
    if (this.lastMoveErrorAt && now - this.lastMoveErrorAt < 1200) return
    this.lastMoveErrorAt = now
    this.setError('Pointer move rejected: ' + reason + '. Tracking stays live; no click was sent.', { silent: true })
  }

  GestureController.prototype.scrollDesktop = function (notches, flashText) {
    var steps = Math.round(Number(notches) || 0)
    if (!steps) return
    var started = performance.now()
    var label = 'Scroll ' + (steps > 0 ? 'up' : 'down')
    if (this.state.bridgeOnline) {
      this.lastAction = { label: label, at: started, ok: null, detail: '' }
      this.trackPromise(this.ctx.bridgeMouse({ action: 'scroll', delta: steps * 120 }), started, { label: label, flash: flashText || '', failFlash: flashText ? flashText + ' FAILED' : '' })
      return
    }
    // No bridge: the only thing left to scroll honestly is the JARVIS page.
    root.scrollBy({ top: -steps * 120, left: 0, behavior: 'auto' })
    this.lastAction = { label: label + ' (JARVIS page)', at: started, ok: true, detail: '' }
    if (flashText) this.flash(flashText)
    this.updateUi(true)
  }

  // Diagnostics only: ask the bridge where the real cursor is, so the console
  // can show a measured position instead of the DOM dot.
  GestureController.prototype.pollCursor = function (now) {
    if (!this.state.bridgeOnline || !this.active) return
    if (now - this.lastCursorPollAt < 800) return
    this.lastCursorPollAt = now
    var self = this
    var request = this.ctx.bridgeMouse({ action: 'pos' })
    if (!request || !request.then) return
    request.then(function (result) {
      if (!result || result.ok !== true) {
        self.cursorError = String((result && (result.error || result.message)) || 'cursor read failed')
        return
      }
      self.cursor = { x: result.x, y: result.y, at: performance.now() }
      self.cursorError = ''
    }).catch(function () { self.cursorError = 'bridge unreachable' })
  }

  GestureController.prototype.updateCursorDot = function () {
    if (this.state.bridgeOnline) {
      this.hideCursor()
      return
    }
    var dot = this.ensureCursor()
    dot.style.display = 'block'
    dot.style.left = Math.round(this.pointer.x) + 'px'
    dot.style.top = Math.round(this.pointer.y) + 'px'
  }

  GestureController.prototype.ensureCursor = function () {
    if (!root.document) return { style: {} }
    var dot = root.document.getElementById('gesture-cursor')
    if (!dot) {
      dot = root.document.createElement('div')
      dot.id = 'gesture-cursor'
      root.document.body.appendChild(dot)
    }
    return dot
  }

  GestureController.prototype.hideCursor = function () {
    if (!root.document) return
    var dot = root.document.getElementById('gesture-cursor')
    if (dot) dot.style.display = 'none'
  }

  GestureController.prototype.markActionLatency = function (started, captureAt) {
    var finished = performance.now()
    this.metrics.actionMs = Math.max(0, finished - started)
    var from = typeof captureAt === 'number' ? captureAt : this.frameCaptureAt
    if (from > 0 && finished >= from) this.metrics.captureToActionMs = Math.max(0, finished - from)
  }

  // Moves are the hot path and would otherwise dominate the action numbers, so
  // they get their own two readings: the bridge round trip (dispatch) and the
  // whole hand-to-real-cursor path, measured from the frame that produced the
  // landmarks to the ack that says where the cursor ended up.
  GestureController.prototype.markMoveLatency = function (started, captureAt) {
    var finished = performance.now()
    this.metrics.moveMs = Math.max(0, finished - started)
    var from = typeof captureAt === 'number' ? captureAt : this.frameCaptureAt
    if (from > 0 && finished >= from) this.metrics.captureToMoveMs = Math.max(0, finished - from)
  }

  GestureController.prototype.scanTarget = function (now, force) {
    if (!force && now - this.lastTargetScan < 180) return
    this.lastTargetScan = now
    var target = this.domOwnsPointer() ? this.domTargetAt(this.pointer.x, this.pointer.y) : null
    if (target) {
      this.pointerTarget = { kind: 'jarvis', label: target.label, el: target.el }
    } else {
      var app = this.state.activeWindow || 'Foreground app'
      this.pointerTarget = { kind: 'external', label: app + ' - UI Automation target', el: null }
    }
  }

  GestureController.prototype.domTargetAt = function (x, y) {
    if (!root.document) return null
    var el = root.document.elementFromPoint(x, y)
    if (!el || el === root.document.documentElement || el === root.document.body) return null
    if (el.closest('#gesture-cursor') || el.closest('canvas.gesture-canvas') || el.closest('video.camera-feed')) return null
    var interactive = el.closest('button,a,input,select,textarea,[role="button"],[role="tab"],[role="menuitem"],[role="checkbox"],[role="slider"],[data-command],[tabindex]')
    if (!interactive) return null
    return { el: interactive, label: this.labelFor(interactive) }
  }

  GestureController.prototype.labelFor = function (el) {
    if (!el) return 'Unknown target'
    var text = el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-command'))
    if (!text) text = el.textContent || ''
    text = String(text).replace(/\s+/g, ' ').trim()
    if (!text) text = el.tagName ? el.tagName.toLowerCase() : 'control'
    return text.slice(0, 64)
  }

  GestureController.prototype.targetIsBlocked = function (el) {
    if (!el || !root.document) return ''
    var confirm = root.document.getElementById('cowork-confirm')
    if (confirm && !confirm.hidden && (confirm === el || confirm.contains(el))) return 'the confirmation dialog'
    if (el.closest && el.closest('[data-gesture-block]')) return 'this control'
    var command = el.getAttribute && el.getAttribute('data-command')
    if (command && ENGINE.isSensitiveLabel(command)) return 'a sensitive command'
    if (this.labelFor(el) && ENGINE.isSensitiveLabel(this.labelFor(el))) return 'a sensitive control'
    if (el.matches && el.matches('input[type="password"]')) return 'a password field'
    return ''
  }

  // The browser only owns the DOM target while its window has focus. When the
  // user is pointing at ANOTHER app, elementFromPoint would still return a
  // JARVIS control sitting under the same screen coordinates, so the semantic
  // path must resolve the foreground app through UI Automation instead.
  GestureController.prototype.domOwnsPointer = function () {
    return Boolean(root.document && root.document.hasFocus())
  }

  GestureController.prototype.clickDomAt = function (point, kind, source) {
    var target = this.domTargetAt(point.x, point.y)
    if (!target) {
      if (source === 'secondary') this.setStatus('NO JARVIS CONTROL UNDER THE POINTER')
      return false
    }
    var blocked = this.targetIsBlocked(target.el)
    if (blocked) {
      this.setError('Gesture blocked on ' + blocked + '. Use the voice confirmation flow.', { silent: false })
      return false
    }
    var options = { bubbles: true, cancelable: true, clientX: point.x, clientY: point.y, button: kind === 'right' ? 2 : 0 }
    if (kind === 'right') {
      target.el.dispatchEvent(new MouseEvent('contextmenu', options))
    } else if (kind === 'double') {
      target.el.click()
      var self = this
      root.setTimeout(function () { try { target.el.click() } catch (err) { /* detached */ } }, 90)
    } else {
      target.el.click()
    }
    this.lastAction = { label: (kind === 'right' ? 'Right click' : kind === 'double' ? 'Double click' : 'Click') + ': ' + target.label + ' (JARVIS page)', at: performance.now(), ok: true, detail: '' }
    this.flash(kind === 'right' ? 'RIGHT CLICK' : kind === 'double' ? 'DOUBLE CLICK' : 'CLICK')
    this.updateUi(true)
    return true
  }

  GestureController.prototype.clickAtPointer = function (kind, side) {
    var point = { x: this.pointer.x, y: this.pointer.y }
    var target = this.domOwnsPointer() ? this.domTargetAt(point.x, point.y) : null
    if (target) {
      var blocked = this.targetIsBlocked(target.el)
      if (blocked) {
        this.setError('Gesture blocked on ' + blocked + '. Use the voice confirmation flow.', { silent: false })
        return
      }
    }
    if (this.state.bridgeOnline) {
      var started = performance.now()
      if (kind === 'right') {
        this.trackPromise(this.ctx.bridgeMouse({ action: 'rclick' }), started, { label: 'Right click', flash: 'RIGHT CLICK', failFlash: 'RIGHT CLICK FAILED' })
      } else if (kind === 'double') {
        this.trackPromise(this.ctx.bridgeMouse({ action: 'lclick' }), started, { label: 'Double click (1/2)', flash: 'DOUBLE CLICK', failFlash: 'DOUBLE CLICK FAILED' })
        var self = this
        root.setTimeout(function () { self.trackPromise(self.ctx.bridgeMouse({ action: 'lclick' }), performance.now(), { label: 'Double click (2/2)' }) }, 90)
      } else {
        this.trackPromise(this.ctx.bridgeMouse({ action: 'lclick' }), started, { label: 'Left click', flash: 'CLICK', failFlash: 'CLICK FAILED' })
      }
      this.updateUi(true)
      return
    }
    if (target) {
      this.clickDomAt(point, kind, side === 'left' ? 'secondary' : 'pointer')
      return
    }
    this.setError('Windows bridge is offline; the pointer can only click JARVIS controls.', { silent: false })
  }

  GestureController.prototype.trackPromise = function (promise, started, info) {
    var self = this
    var captureAt = this.frameCaptureAt
    var describe = info && typeof info === 'object' ? info : { label: '' }
    var settle = function (result) {
      self.markActionLatency(started, captureAt)
      var ok = !(result && result.ok === false)
      self.metrics.actions += 1
      if (!ok) self.metrics.failures += 1
      if (!describe.label && !describe.flash) return
      self.lastAction = {
        label: describe.label,
        at: started,
        ok: ok,
        detail: ok ? '' : String((result && (result.error || result.message)) || 'the bridge refused the action')
      }
      // The big label is evidence, not a request: CLICK only appears after the
      // bridge has acknowledged the real Windows click. A refusal shows
      // CLICK FAILED and the reason instead of pretending the click happened.
      if (ok) {
        if (describe.flash) self.flash(describe.flash)
      } else {
        if (describe.failFlash) self.flash(describe.failFlash)
        self.setError('Windows action failed: ' + self.lastAction.detail, { silent: true })
      }
      self.updateUi(true)
    }
    if (promise && promise.then) {
      promise.then(settle).catch(function () { settle({ ok: false, error: 'the bridge request failed' }) })
    } else settle({ ok: false, error: 'the bridge helper is unavailable' })
  }

  GestureController.prototype.semanticActivate = function (source, side) {
    var self = this
    var target = this.domOwnsPointer() ? this.domTargetAt(this.pointer.x, this.pointer.y) : null
    if (target) {
      var blocked = this.targetIsBlocked(target.el)
      if (blocked) {
        this.setError('Semantic activation blocked on ' + blocked + '. Use the voice confirmation flow.', { silent: false })
        return Promise.resolve({ ok: false, sensitive: true })
      }
      var started = performance.now()
      target.el.click()
      this.markActionLatency(started)
      this.lastAction = { label: 'Activate: ' + target.label, at: started }
      this.flash('UI CONTROL ACTIVATED')
      this.updateUi(true)
      return Promise.resolve({ ok: true, how: 'DOM', label: target.label })
    }
    if (!this.state.bridgeOnline) {
      this.setError('UI Automation needs the local Windows bridge. Start it with npm run bridge.', { silent: false })
      return Promise.resolve({ ok: false, error: 'bridge offline' })
    }
    var point = this.desktopPoint()
    var startedAt = performance.now()
    var captureAtFrame = this.frameCaptureAt
    var request = this.ctx.uiRequest({ op: 'activate', x: point.x, y: point.y })
    if (!request || !request.then) return Promise.resolve({ ok: false, error: 'UI Automation unavailable' })
    return request.then(function (result) {
      self.markActionLatency(startedAt, captureAtFrame)
      if (!result || result.ok !== true) {
        var reason = String((result && (result.error || result.name)) || 'no reason given')
        self.lastAction = { label: 'UI Automation failed', at: startedAt, ok: false, detail: reason }
        if (result && result.sensitive) {
          self.setError('UI Automation blocked a sensitive control: ' + String(result.name || 'unnamed') + '. Use voice confirmation.', { silent: false })
        } else {
          self.setError('UI Automation could not activate that control. ' + String((result && result.error) || ''), { silent: true })
        }
        self.updateUi(true)
        return result || { ok: false }
      }
      self.lastAction = { label: 'UI Automation: ' + (result.name || result.control_type || 'control'), at: startedAt, ok: true, detail: '' }
      self.flash('UI CONTROL ACTIVATED')
      self.updateUi(true)
      return result
    }).catch(function () {
      self.lastAction = { label: 'UI Automation failed', at: startedAt, ok: false, detail: 'the request failed' }
      self.setError('UI Automation request failed; the click was not repeated.', { silent: true })
      return { ok: false }
    })
  }

  GestureController.prototype.activateVoiceTarget = function (source) {
    if (!this.active) return false
    if (this.paused || this.emergency) {
      if (this.ctx.showToast) this.ctx.showToast('Gesture control is paused. Resume it before using "this" by voice.', true)
      return true
    }
    var target = this.domOwnsPointer() ? this.domTargetAt(this.pointer.x, this.pointer.y) : null
    if (target) {
      var blocked = this.targetIsBlocked(target.el)
      if (blocked) {
        if (this.ctx.showToast) this.ctx.showToast('The gesture target is ' + blocked + '. Say the full command and confirm it with voice.', true)
        return true
      }
      var started = performance.now()
      target.el.click()
      this.markActionLatency(started)
      this.lastAction = { label: 'Voice + gesture: ' + target.label, at: started }
      this.flash('VOICE + GESTURE')
      this.setStatus('VOICE + GESTURE - ' + target.label.toUpperCase())
      this.updateUi(true)
      return true
    }
    if (this.state.bridgeOnline && this.pointerTarget && this.pointerTarget.kind === 'external') {
      this.semanticActivate(source || 'voice')
      return true
    }
    if (this.ctx.showToast) this.ctx.showToast('Point at a button, link or control first, then say "open this".', true)
    return true
  }

  GestureController.prototype.beginDrag = function (hand, reason) {
    if (this.state.bridgeOnline && !this.mouseInputReady()) {
      this.setError('Drag refused: the Windows bridge mouse worker is not answering.', { silent: false })
      return
    }
    var target = this.domOwnsPointer() ? this.domTargetAt(this.pointer.x, this.pointer.y) : null
    if (!this.state.bridgeOnline && !target) {
      this.setError('Drag refused: the Windows bridge is offline and no JARVIS control is under the pointer.', { silent: false })
      return
    }
    var started = performance.now()
    this.drag = {
      side: hand.side,
      startedAt: started,
      target: target ? target.el : null,
      viaBridge: Boolean(this.state.bridgeOnline)
    }
    if (this.drag.viaBridge) {
      this.trackPromise(this.ctx.bridgeMouse({ action: 'ldown' }), started, { label: 'Drag: ' + (reason || 'pinch hold'), flash: 'DRAG STARTED', failFlash: 'DRAG FAILED' })
    } else {
      target.el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: this.pointer.x, clientY: this.pointer.y }))
      this.markActionLatency(started)
      this.lastAction = { label: 'Drag (page): ' + (reason || 'pinch hold'), at: started, ok: true, detail: '' }
      this.flash('DRAG STARTED')
    }
    this.setStatus('DRAG STARTED - MOVE, THEN RELEASE THE PINCH')
    this.updateUi(true)
  }

  GestureController.prototype.releaseDrag = function (reason) {
    if (!this.drag) return
    var drag = this.drag
    this.drag = null
    // Always release a bridge-held button, even if the bridge just dropped:
    // a best-effort `lup` is the only way to clear a stuck Windows button
    // after a reconnect, and a failed request is harmless.
    if (drag.viaBridge) {
      this.trackPromise(this.ctx.bridgeMouse({ action: 'lup' }), performance.now(), {
        label: 'Drag released' + (reason ? ' (' + reason + ')' : ''),
        flash: 'DRAG RELEASED',
        failFlash: 'DRAG RELEASE FAILED'
      })
    } else if (drag.target) {
      drag.target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, clientX: this.pointer.x, clientY: this.pointer.y }))
      this.lastAction = { label: 'Drag released' + (reason ? ' (' + reason + ')' : ''), at: performance.now(), ok: true, detail: '' }
      this.flash('DRAG RELEASED')
    } else {
      this.lastAction = { label: 'Drag released', at: performance.now(), ok: null, detail: '' }
    }
    this.setStatus('DRAG RELEASED' + (reason ? ' - ' + reason.toUpperCase() : ''))
    this.updateUi(true)
  }

  GestureController.prototype.scrollView = function (delta) {
    var before = root.scrollY || 0
    root.scrollBy({ top: delta, left: 0, behavior: 'auto' })
    var after = root.scrollY || 0
    if (Math.abs(after - before) < 1 && this.state.bridgeOnline) {
      this.ctx.bridgeMouse({ action: 'scroll', delta: delta > 0 ? 120 : -120 })
    }
    this.lastAction = { label: 'Scroll ' + (delta > 0 ? 'down' : 'up'), at: performance.now() }
  }

  GestureController.prototype.applyZoom = function (scale) {
    this.hudScale = this.ctx.applyHudScale(scale)
  }

  GestureController.prototype.runSequenceMatch = function (match) {
    if (match && match.mapping) {
      this.lastGesture = { name: match.mapping.name, confidence: 0.9, side: 'both', at: performance.now() }
      this.runAction(match.mapping.action, { source: 'custom-sequence', label: match.mapping.name })
    }
  }

  GestureController.prototype.runAction = function (action, meta) {
    var info = ACTIONS[action]
    if (!info) return
    var started = performance.now()
    var point = { x: this.pointer.x, y: this.pointer.y }
    if (action === 'click') { this.clickAtPointer('left', 'custom'); return }
    if (action === 'right_click') { this.clickAtPointer('right', 'custom'); return }
    if (action === 'double_click') { this.clickAtPointer('double', 'custom'); return }
    if (action === 'semantic_activate') { this.semanticActivate(meta && meta.source); return }
    if (action === 'scroll_up') { this.scrollView(-420 * this.settings.scrollGain); this.lastAction = { label: 'Scroll up', at: started }; this.flash('SCROLL UP'); this.updateUi(true); return }
    if (action === 'scroll_down') { this.scrollView(420 * this.settings.scrollGain); this.lastAction = { label: 'Scroll down', at: started }; this.flash('SCROLL DOWN'); this.updateUi(true); return }
    if (action === 'next_section') { this.ctx.navSection(1); this.lastAction = { label: 'Next section', at: started }; this.flash('NEXT SECTION'); this.updateUi(true); return }
    if (action === 'previous_section') { this.ctx.navSection(-1); this.lastAction = { label: 'Previous section', at: started }; this.flash('PREVIOUS SECTION'); this.updateUi(true); return }
    if (action === 'home') { this.ctx.navigateTo('dashboard'); this.lastAction = { label: 'Dashboard home', at: started }; this.flash('DASHBOARD HOME'); this.updateUi(true); return }
    if (action === 'zoom_in') { this.applyZoom(this.hudScale + 0.05); this.lastAction = { label: 'Zoom in', at: started }; this.flash('ZOOM IN'); this.updateUi(true); return }
    if (action === 'zoom_out') { this.applyZoom(this.hudScale - 0.05); this.lastAction = { label: 'Zoom out', at: started }; this.flash('ZOOM OUT'); this.updateUi(true); return }
    if (action === 'zoom_reset') { this.applyZoom(1); this.lastAction = { label: 'Reset zoom', at: started }; this.flash('ZOOM RESET'); this.updateUi(true); return }
    if (action === 'toggle_listening') { this.ctx.toggleListening(); this.lastAction = { label: 'Toggle voice listening', at: started }; this.flash('VOICE LISTENING TOGGLED'); this.updateUi(true); return }
    if (action === 'pointer_pause') { this.pointerSuspendedUntil = performance.now() + 1500; this.lastAction = { label: 'Pointer paused 1.5 s', at: started }; this.flash('POINTER PAUSED'); this.updateUi(true); return }
    if (action === 'emergency_stop') { this.emergencyStop('mapping'); return }
    if (action === 'open_settings') { this.ctx.navigateTo('settings'); this.lastAction = { label: 'Open Settings', at: started, ok: true, detail: '' }; this.flash('SETTINGS'); this.updateUi(true); return }
    if (action === 'open_gesture_view') { this.ctx.navigateTo('gesture'); this.lastAction = { label: 'Open Gesture Control', at: started, ok: true, detail: '' }; this.flash('GESTURE VIEW'); this.updateUi(true); return }
    if (action === 'window_focus_uia' || action === 'window_minimize_uia' || action === 'window_maximize_uia' || action === 'window_restore_uia' || action === 'window_move_center') {
      // Handle 0 means "the foreground window": the Python layer resolves it
      // through GetForegroundWindow, so a gesture needs no window list.
      var windowAction = action === 'window_focus_uia' ? 'focus'
        : action === 'window_minimize_uia' ? 'minimize'
          : action === 'window_maximize_uia' ? 'maximize'
            : action === 'window_restore_uia' ? 'restore'
              : 'move'
      this.windowAction(windowAction, 0)
      return
    }
    var command = BRIDGE_COMMANDS[action]
    if (command) {
      var self = this
      var captureAtFrame = this.frameCaptureAt
      var request = this.ctx.bridgeAction(command)
      if (request && request.then) request.then(function (result) {
        self.markActionLatency(started, captureAtFrame)
        self.lastAction = { label: info.label + (result && result.handled === false ? ' (unsupported)' : ''), at: started }
        self.flash(info.label.toUpperCase())
        self.updateUi(true)
      }).catch(function () { self.markActionLatency(started) })
      else this.markActionLatency(started)
      return
    }
    this.lastAction = { label: info.label, at: started }
    this.flash(info.label.toUpperCase())
    this.updateUi(true)
  }

  GestureController.prototype.togglePause = function (reason) {
    if (!this.active) {
      if (this.ctx.showToast) this.ctx.showToast('Start hand tracking first.', true)
      return
    }
    if (this.paused) this.resume(reason)
    else this.pause(reason)
  }

  GestureController.prototype.pause = function (reason) {
    if (!this.active || this.paused) return
    this.paused = true
    this.emergency = reason === 'emergency' || reason === 'keyboard' || reason === 'estop'
    this.releaseDrag()
    this.hideCursor()
    this.setStatus(this.emergency ? 'EMERGENCY STOP - CONTROL PAUSED' : 'GESTURE CONTROL PAUSED')
    this.flash(this.emergency ? 'EMERGENCY STOP' : 'GESTURES PAUSED')
    this.updateToggles()
    this.updateUi(true)
  }

  GestureController.prototype.resume = function (reason) {
    if (!this.active) return
    this.paused = false
    this.emergency = false
    this.handState = { left: makeHandState(), right: makeHandState() }
    this.two = { mode: '', anchor: 0, base: 1, lastPalm: null, lastSwipeAt: 0, lastScrollAt: 0, pinchActive: false, lastPinchAt: 0 }
    this.sequenceMatcher.reset()
    this.setStatus('GESTURE CONTROL RESUMED')
    this.flash('GESTURES RESUMED')
    this.updateToggles()
    this.updateUi(true)
  }

  GestureController.prototype.emergencyStop = function (reason) {
    if (!this.active) {
      if (this.ctx.showToast) this.ctx.showToast('Hand tracking is not running, so there is no gesture action to stop.', true)
      return
    }
    this.pause('emergency')
    if (this.ctx.showToast) this.ctx.showToast('Emergency stop: gesture actions are paused and the mouse button was released. Other JARVIS modules are unaffected.', false)
  }

  GestureController.prototype.clearHandState = function () {
    var now = performance.now()
    for (var key in this.handState) {
      if (!Object.prototype.hasOwnProperty.call(this.handState, key)) continue
      var state = this.handState[key]
      if (state.lastSeenAt && now - state.lastSeenAt > 250) {
        state.firstSeenAt = 0
        state.pinch.kind = ''
        state.pinch.startedAt = 0
        state.peaceSince = 0
        state.customFrames = 0
        state.holdFrames = 0
        state.scrollAcc = 0
      }
    }
    this.two.mode = ''
    this.two.lastPalm = null
    this.two.pinchActive = false
  }

  GestureController.prototype.onBridgeStatus = function (online, data) {
    var payload = data && typeof data === 'object' ? data : {}
    if (payload.desktop && payload.desktop.width) this.desktop = payload.desktop
    if (payload.mouse) {
      this.mouseInput = {
        reported: true,
        ready: Boolean(payload.mouse.ready),
        error: String(payload.mouse.error || ''),
        supported: payload.mouse.supported !== false
      }
    } else if (!this.mouseInput.reported) {
      // An older bridge that does not report the input worker: assume nothing.
      // Moves are attempted and judged by their own ack, so an unknown state can
      // never deadlock the pointer; only an explicit failure blocks sends.
      this.mouseInput = { reported: false, ready: true, error: '', supported: true }
    }
    if (!online) {
      // A drag started through the bridge must not leave the Windows mouse
      // button latched when the bridge disappears.
      if (this.drag) this.releaseDrag('bridge offline')
      this.cursor = null
      this.cursorError = 'Windows bridge offline'
      this.uiAutomation = { checked: true, available: false, reason: 'Windows bridge offline' }
      this.renderUiAutomation()
      this.updateUi(true)
      return
    }
    this.uiAutomation = { checked: false, available: false, reason: 'checking Windows UI Automation' }
    this.checkUiAutomation(false)
    this.updateUi(true)
  }

  // ── window control (UI Automation, handle based) ────────────────────
  // Real window state and real actions, read back from the OS. A window that
  // cannot be controlled through accessibility says so; nothing is guessed.
  GestureController.prototype.refreshWindows = function () {
    var self = this
    if (!this.state.bridgeOnline) {
      this.windows = { checked: true, ok: false, error: 'Windows bridge offline', list: [] }
      this.renderWindows()
      return
    }
    var request = this.ctx.uiRequest({ op: 'windows' })
    if (!request || !request.then) {
      this.windows = { checked: true, ok: false, error: 'bridge request failed', list: [] }
      this.renderWindows()
      return
    }
    request.then(function (result) {
      self.windows = {
        checked: true,
        ok: Boolean(result && result.ok),
        error: String((result && result.error) || ''),
        list: result && Array.isArray(result.windows) ? result.windows : []
      }
      self.renderWindows()
    }).catch(function () {
      self.windows = { checked: true, ok: false, error: 'window list failed', list: [] }
      self.renderWindows()
    })
  }

  GestureController.prototype.windowAction = function (action, handle) {
    var self = this
    if (!this.state.bridgeOnline) {
      this.setError('Window control needs the local Windows bridge. Start it with npm run bridge.', { silent: false })
      return Promise.resolve({ ok: false, error: 'bridge offline' })
    }
    var payload = { op: 'window', action: String(action || ''), handle: Number(handle) || 0 }
    if (payload.action === 'move') {
      // Fractions of the desktop, never pixels: the pointer path works in the
      // dashboard's virtualised CSS pixels while UI Automation measures window
      // rectangles in physical pixels, so on a scaled display (125% here) an
      // absolute rect would move the window to the wrong place at the wrong
      // size. The UIA process resolves these fractions in its own space.
      // 62% of the desktop, centred: this action is labelled "to the centre".
      payload.rect = { x: 0.19, y: 0.19, width: 0.62, height: 0.62 }
    }
    var started = performance.now()
    var captureAt = this.frameCaptureAt
    var request = this.ctx.uiRequest(payload)
    if (!request || !request.then) return Promise.resolve({ ok: false, error: 'UI Automation unavailable' })
    return request.then(function (result) {
      self.markActionLatency(started, captureAt)
      var ok = Boolean(result && result.ok)
      var title = result && result.window && result.window.title ? result.window.title : 'window'
      self.lastAction = {
        label: (ok ? 'Window ' + payload.action + ': ' : 'Window ' + payload.action + ' failed: ') + title,
        at: started,
        ok: ok,
        detail: ok ? '' : String((result && result.error) || 'UI Automation refused the action')
      }
      if (!ok) self.setError('Window control failed: ' + self.lastAction.detail, { silent: true })
      else self.flash('WINDOW ' + payload.action.toUpperCase())
      self.updateUi(true)
      self.refreshWindows()
      return result || { ok: false }
    }).catch(function () {
      self.lastAction = { label: 'Window ' + payload.action + ' failed', at: started, ok: false, detail: 'the request failed' }
      self.updateUi(true)
      return { ok: false }
    })
  }

  GestureController.prototype.renderWindows = function () {
    var list = root.document && root.document.getElementById('gesture-windows')
    if (!list) return
    var state = this.windows || { ok: false, error: 'not checked', list: [] }
    var status = root.document.getElementById('gesture-window-status')
    if (status) {
      status.textContent = state.ok
        ? state.list.length + ' window(s) reachable'
        : 'UNAVAILABLE - ' + (state.error || 'not checked')
    }
    if (!state.ok || !state.list.length) {
      list.innerHTML = '<li class="gesture-ui-empty">' +
        escapeHtml(state.ok ? 'No titled windows were reported by UI Automation.' : (state.error || 'Refresh to list windows.')) + '</li>'
      return
    }
    list.innerHTML = state.list.slice(0, 8).map(function (entry) {
      var stateText = entry.minimized ? 'minimized' : entry.maximized ? 'maximized' : 'normal'
      return '<li class="gesture-window-row"><span class="gesture-window-name"><strong>' + escapeHtml(entry.title) + '</strong>' +
        '<small>' + escapeHtml(stateText) + ' · handle ' + Number(entry.handle || 0) + '</small></span>' +
        '<span class="gesture-window-actions">' +
        '<button type="button" data-window-action="focus" data-window-handle="' + Number(entry.handle || 0) + '">Focus</button>' +
        '<button type="button" data-window-action="minimize" data-window-handle="' + Number(entry.handle || 0) + '">Min</button>' +
        '<button type="button" data-window-action="maximize" data-window-handle="' + Number(entry.handle || 0) + '">Max</button>' +
        '<button type="button" data-window-action="restore" data-window-handle="' + Number(entry.handle || 0) + '">Restore</button>' +
        '<button type="button" data-window-action="move" data-window-handle="' + Number(entry.handle || 0) + '">Move</button>' +
        '</span></li>'
    }).join('')
  }

  GestureController.prototype.checkUiAutomation = function (force) {    var self = this
    if (!this.state.bridgeOnline) {
      this.uiAutomation = { checked: true, available: false, reason: 'Windows bridge offline' }
      this.renderUiAutomation()
      return
    }
    if (this.uiAutomation.checked && !force) {
      this.renderUiAutomation()
      return
    }
    var request = this.ctx.uiRequest({ op: 'status' })
    if (!request || !request.then) {
      this.uiAutomation = { checked: true, available: false, reason: 'bridge request failed' }
      this.renderUiAutomation()
      return
    }
    request.then(function (result) {
      self.uiAutomation = {
        checked: true,
        available: Boolean(result && result.ok && result.available),
        reason: String((result && (result.reason || result.error)) || (result && result.ok ? 'ready' : 'unavailable'))
      }
      self.renderUiAutomation()
      if (force) self.refreshUiSnapshot()
    }).catch(function () {
      self.uiAutomation = { checked: true, available: false, reason: 'UI Automation request failed' }
      self.renderUiAutomation()
    })
  }

  GestureController.prototype.refreshUiSnapshot = function () {
    var self = this
    if (!this.state.bridgeOnline) {
      this.setStatus('UI AUTOMATION NEEDS THE WINDOWS BRIDGE')
      return
    }
    this.ctx.uiRequest({ op: 'snapshot' }).then(function (result) {
      if (!result || result.ok !== true) {
        self.uiAutomation = { checked: true, available: false, reason: String((result && (result.error || result.reason)) || 'snapshot failed') }
        self.renderUiAutomation()
        return
      }
      self.uiSnapshot = result
      self.renderUiAutomation()
    }).catch(function () { self.renderUiAutomation() })
  }

  GestureController.prototype.renderUiAutomation = function () {
    var status = root.document && root.document.getElementById('gesture-ui-status')
    if (status) {
      status.textContent = this.uiAutomation.available
        ? 'READY - ' + (this.uiAutomation.reason || 'UI Automation connected')
        : 'UNAVAILABLE - ' + (this.uiAutomation.reason || 'not checked')
    }
    var list = root.document && root.document.getElementById('gesture-ui-elements')
    if (!list) return
    var snapshot = this.uiSnapshot
    if (!snapshot || !snapshot.ok) {
      list.innerHTML = '<li class="gesture-ui-empty">Refresh to read the foreground window accessible controls.</li>'
      return
    }
    var controls = Array.isArray(snapshot.controls) ? snapshot.controls.slice(0, 6) : []
    var windowName = snapshot.window && snapshot.window.title ? snapshot.window.title : 'foreground window'
    list.innerHTML = '<li class="gesture-ui-window"><strong>' + escapeHtml(windowName) + '</strong><small>' +
      controls.length + ' of ' + Number(snapshot.count || 0) + ' accessible controls shown</small></li>' +
      controls.map(function (control) {
        return '<li><span>' + escapeHtml(control.control_type || 'control') + '</span><strong>' +
          escapeHtml(control.name || '(unnamed)') + '</strong></li>'
      }).join('')
  }

  GestureController.prototype.updateUi = function (force) {
    if (!root.document) return
    var now = performance.now()
    if (!force && now - this.lastUiAt < 220) return
    this.lastUiAt = now
    var set = function (id, value) {
      var node = root.document.getElementById(id)
      if (node && node.textContent !== String(value)) node.textContent = String(value)
    }
    var recognized = this.lastGesture.name === 'none' ? 'None' : this.lastGesture.name.replace(/_/g, ' ')
    set('gesture-recognized', recognized)
    set('gesture-confidence', 'confidence ' + (this.lastGesture.confidence ? Math.round(this.lastGesture.confidence * 100) + '%' : '--'))
    var candidateNode = root.document.getElementById('gesture-candidate')
    if (candidateNode) {
      var candidateText = 'pose is unambiguous'
      if (this.lastGesture.name === 'unknown') {
        var candidate = this.lastGesture.candidate || this.lastCandidate
        if (candidate) {
          // A candidate below 50% is reported as a weak guess and is never
          // executed; the mapping card can still adopt it if the user wants it.
          candidateText = (this.lastGesture.candidate ? 'closest match: ' : 'weak guess, not executed: ') +
            candidate.name.replace(/_/g, ' ') + ' ' + Math.round(candidate.confidence * 100) + '%'
          if (candidate.motion) candidateText += ' · ' + candidate.motion
        } else candidateText = 'unknown / ambiguous'
      }
      if (candidateNode.textContent !== candidateText) candidateNode.textContent = candidateText
    }
    set('gesture-motion', this.lastGesture.motion || 'movement not measured')
    var actionNode = root.document.getElementById('gesture-action')
    if (actionNode) {
      var actionText = this.lastAction.label || 'No action yet'
      var resultText = this.lastAction.ok === false ? 'FAILED: ' + (this.lastAction.detail || 'the bridge refused it')
        : this.lastAction.ok === true ? 'done'
          : this.lastAction.label ? 'sent' : ''
      var nextText = actionText + (resultText ? ' — ' + resultText : '')
      if (actionNode.textContent !== nextText) actionNode.textContent = nextText
      actionNode.dataset.state = this.lastAction.ok === false ? 'failed' : this.lastAction.ok === true ? 'ok' : 'idle'
    }
    set('gesture-target', this.pointerTarget ? (this.pointerTarget.kind === 'jarvis' ? 'JARVIS: ' : 'App: ') + this.pointerTarget.label : 'No target under pointer')
    set('gesture-app', this.state.activeWindow || 'Foreground app unavailable')
    set('gesture-mode', this.settings.profile + ' mode | pointer ' + this.settings.pointerHand + (this.paused ? ' | paused' : '') + (this.pointerSuspended() ? ' | pointer held' : ''))
    set('gesture-fps', this.metrics.fps ? Math.round(this.metrics.fps) : '--')
    set('gesture-inference', this.metrics.inferenceMs ? Math.round(this.metrics.inferenceMs) + ' ms' : '--')
    set('gesture-latency', this.metrics.captureToActionMs ? Math.round(this.metrics.captureToActionMs) + ' ms' : '--')
    set('gesture-dropped', String(this.metrics.dropped))
    // Measured pipeline breakdown, every number from this session only.
    set('gesture-capture-ms', this.metrics.captureMs ? Math.round(this.metrics.captureMs) + ' ms' : '--')
    set('gesture-recognition-ms', this.metrics.recognitionMs ? this.metrics.recognitionMs.toFixed(1) + ' ms' : '--')
    set('gesture-move-latency', this.metrics.captureToMoveMs ? Math.round(this.metrics.captureToMoveMs) + ' ms' : '--')
    set('gesture-move-rtt', this.metrics.moveMs ? Math.round(this.metrics.moveMs) + ' ms' : '--')
    set('gesture-dispatch-ms', this.metrics.actionMs ? Math.round(this.metrics.actionMs) + ' ms' : '--')
    set('gesture-actions', this.metrics.actions ? String(this.metrics.actions) : '0')
    set('gesture-failures', String(this.metrics.failures || 0))
    var cursorNode = root.document.getElementById('gesture-cursor-pos')
    if (cursorNode) {
      cursorNode.textContent = this.cursorError
        ? 'cursor read: ' + this.cursorError
        : this.cursor
          ? 'real cursor ' + this.cursor.x + ',' + this.cursor.y + (this.mapError ? ' (±' + Math.round(this.mapError) + ' px mapping error)' : '')
          : this.state.bridgeOnline ? 'cursor not read yet' : 'bridge offline - preview dot only'
    }
    var bridgeNode = root.document.getElementById('gesture-bridge')
    if (bridgeNode) {
      var bridgeText = !this.state.bridgeOnline
        ? 'OFFLINE (npm run bridge)'
        : !this.mouseInput.reported ? 'BRIDGE ONLINE — input worker state not reported'
          : this.mouseInput.ready ? 'READY (PowerShell input worker answered)'
            : this.mouseInput.supported === false ? 'UNSUPPORTED on this platform'
              : 'INPUT WORKER FAILED' + (this.mouseInput.error ? ': ' + this.mouseInput.error : '')
      if (bridgeNode.textContent !== bridgeText) bridgeNode.textContent = bridgeText
      bridgeNode.dataset.state = !this.state.bridgeOnline ? 'offline' : this.mouseInput.ready ? 'ok' : 'failed'
    }
    this.pollCursor(now)
    set('gesture-calib-status', this.calibration
      ? 'Calibrated ' + Math.round((this.calibration.maxX - this.calibration.minX) * 100) + ' x ' + Math.round((this.calibration.maxY - this.calibration.minY) * 100) + ' range'
      : 'Not calibrated - uses sensitivity mapping')
    set('gesture-ui-status', this.uiAutomation.available ? 'READY' : 'UNAVAILABLE - ' + this.uiAutomation.reason)
    var permission = root.document.getElementById('gesture-permission')
    if (permission) {
      permission.textContent = [
        this.state.cameraStream ? 'Camera: live' : 'Camera: off',
        root.Hands ? 'MediaPipe Hands: loaded' : 'MediaPipe Hands: missing',
        this.state.bridgeOnline ? 'Windows bridge: online' : 'Windows bridge: offline',
        this.state.bridgeOnline ? (this.mouseInput.reported ? (this.mouseInput.ready ? 'Mouse input: ready' : 'Mouse input: ' + (this.mouseInput.error || 'not answering')) : 'Mouse input: state not reported') : 'Mouse input: unavailable',
        this.uiAutomation.available ? 'UI Automation: ready' : 'UI Automation: ' + this.uiAutomation.reason
      ].join(' | ')
    }
    var overlay = root.document.getElementById('gesture-pause-overlay')
    if (overlay) overlay.hidden = !(this.active && this.paused)
    var overlayText = root.document.getElementById('gesture-pause-text')
    if (overlayText) overlayText.textContent = this.emergency ? 'EMERGENCY STOP' : 'GESTURE CONTROL PAUSED'
    var session = root.document.getElementById('gesture-session')
    if (session) {
      session.textContent = this.active ? (this.trackingLost ? 'LOST' : this.paused ? 'PAUSED' : 'LIVE') : 'OFF'
      session.dataset.state = this.active ? (this.trackingLost ? 'lost' : this.paused ? 'paused' : 'live') : 'off'
    }
    this.updateToggles()
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
    })
  }

  root.__JARVIS_GESTURE_CONTROL__ = {
    version: VERSION,
    ACTIONS: ACTIONS,
    create: function (ctx) { return new GestureController(ctx) }
  }
})(typeof window !== 'undefined' ? window : globalThis)
