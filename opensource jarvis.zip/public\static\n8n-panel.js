/* ══════════════════════════════════════════════════════════════════════════
   N8N PANEL — drives the Agents tab now that it embeds the real n8n editor.

   Two jobs, and neither of them reimplements n8n:

     1. Health. Polls n8n's own /healthz so the header reports a REAL state.
        If n8n is down it says down and tells the user how to start it - it
        never pretends the editor is loaded.

     2. Describe-to-build. The plain-English box posts the request to the JARVIS
        core, which turns the sentence into a real n8n workflow and creates it
        through n8n's public REST API. On success the panel reloads the iframe
        so the new workflow is genuinely there.

   The iframe itself is n8n's own UI. This file never draws nodes.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict'

  const CORE = 'http://127.0.0.1:7780'
  const N8N = 'http://127.0.0.1:5678'
  const HEALTH_MS = 8000
  // A stopped n8n does not need a probe every 8 seconds. It used to get exactly
  // that, so an idle dashboard logged ERR_CONNECTION_REFUSED forever and buried
  // the errors that actually mattered.
  const HEALTH_MS_OFFLINE = 60000

  const $ = (sel) => document.querySelector(sel)

  let timer = null
  let alive = false
  let lastState = 'checking'

  function setState(state, text) {
    lastState = state
    const chip = $('#n8n-state')
    const dot = $('#n8n-dot')
    if (chip) {
      chip.setAttribute('data-state', state)
      chip.textContent = text
    }
    if (dot) dot.setAttribute('data-state', state)
  }

  function note(text, kind) {
    const box = $('#n8n-note')
    if (!box) return
    if (!text) { box.hidden = true; box.textContent = ''; return }
    box.hidden = false
    box.setAttribute('data-kind', kind || 'info')
    box.textContent = text
  }

  // n8n serves /rest/settings before login, and it reports
  // userManagement.showSetupOnFirstLoad while no real owner exists. That is the
  // one-time state where the editor loads but the public API is still closed.
  // Report it as its own explicit state so the user knows exactly what to do.
  async function flagFirstRunSetup() {
    let needsSetup = false
    try {
      const res = await fetch(N8N + '/rest/settings', { cache: 'no-store' })
      if (!res.ok) return
      const body = await res.json()
      const um = body && body.data && body.data.userManagement
      needsSetup = !!(um && um.showSetupOnFirstLoad)
    } catch (_) {
      return  // settings unreachable: leave the current state alone
    }
    if (!needsSetup) return
    setState('setup', 'setup needed')
    note('n8n is running but still on its first-run owner setup, so it cannot ' +
      'create workflows over the API yet. Open n8n once, create the owner ' +
      'account, then come back. Everything else in the editor already works.',
      'warn')
  }

  // n8n's /healthz is a public endpoint on the same loopback origin, so this
  // works before anyone completes n8n's first-run owner setup.
  async function checkHealth() {
    try {
      const res = await fetch(N8N + '/healthz', { cache: 'no-store' })
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const body = await res.json()
      if (body && body.status === 'ok') {
        setState('online', 'online')
        note('')
      } else {
        setState('degraded', 'degraded')
        note('n8n answered but did not report ok: ' + JSON.stringify(body))
      }
      // n8n is up but may still be on its first-run owner setup, in which case
      // its REST API answers 401 and "Build in n8n" cannot work yet. Say that
      // plainly instead of letting the user hit an unexplained failure.
      flagFirstRunSetup()
    } catch (err) {
      setState('offline', 'offline')
      note('n8n is not answering on ' + N8N + '. Start it with: pm2 start ecosystem.config.cjs --only jarvis-n8n', 'error')
    }
  }

  function startHealthPolling() {
    stopHealthPolling()
    // Self-rescheduling instead of setInterval, so the period can follow the
    // state: 8s while n8n answers, 60s while it is down.
    const loop = () => {
      timer = null
      Promise.resolve(checkHealth()).finally(() => {
        if (timer === null && alive) {
          timer = setTimeout(loop,
            lastState === 'offline' ? HEALTH_MS_OFFLINE : HEALTH_MS)
        }
      })
    }
    alive = true
    loop()
  }

  function stopHealthPolling() {
    alive = false
    if (timer) { clearTimeout(timer); timer = null }
  }

  async function buildWorkflow() {
    const input = $('#n8n-nl')
    const btn = $('#n8n-nl-build')
    if (!input || !btn) return
    const text = (input.value || '').trim()
    if (!text) {
      note('Describe the workflow first — for example "every morning fetch my Gmail and save attachments to disk".', 'warn')
      input.focus()
      return
    }
    btn.disabled = true
    btn.textContent = 'Building…'
    note('Asking the JARVIS core to turn that into an n8n workflow…', 'info')
    try {
      const res = await fetch(CORE + '/n8n/workflow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: text })
      })
      let payload = null
      try { payload = await res.json() } catch (_) { /* non-JSON error page */ }
      if (!res.ok || !payload || !payload.ok) {
        const why = (payload && (payload.error || payload.reason)) || ('HTTP ' + res.status)
        note('Could not build the workflow: ' + why, 'error')
        return
      }
      const wf = payload.workflow || {}
      note('Created “' + (wf.name || 'workflow') + '” in n8n with ' +
        ((wf.nodes || []).length) + ' node(s). It is open in the editor below.',
        'ok')
      input.value = ''
      // Reload so n8n shows the workflow it actually stored.
      const frame = $('#n8n-frame')
      if (frame) frame.src = N8N + '/workflow/' + encodeURIComponent(wf.id || '')
    } catch (err) {
      note('Could not reach the JARVIS core: ' + (err && err.message ? err.message : err), 'error')
    } finally {
      btn.disabled = false
      btn.textContent = 'Build in n8n'
    }
  }

  function reloadFrame() {
    const frame = $('#n8n-frame')
    if (!frame) return
    // Re-assigning src is the reliable way to reload a same-origin iframe.
    frame.src = N8N + '/'
    checkHealth()
  }

  function openFull() {
    const link = $('#n8n-open')
    if (link) link.href = N8N + '/'
  }

  function init() {
    const btn = $('#n8n-nl-build')
    if (btn) btn.addEventListener('click', buildWorkflow)
    const reload = $('#n8n-reload')
    if (reload) reload.addEventListener('click', reloadFrame)
    const form = $('#n8n-nl-form')
    if (form) form.addEventListener('submit', (e) => { e.preventDefault(); buildWorkflow() })
    openFull()
    // Only poll while the panel is on screen: a hidden tab polling n8n every
    // 8s forever is wasted work.
    document.addEventListener('visibilitychange', () => {
      const panel = $('[data-cowork-panel="agents"]')
      const visible = panel && panel.classList.contains('active') && !document.hidden
      if (visible) startHealthPolling(); else stopHealthPolling()
    })
    startHealthPolling()
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }

  window.JarvisN8N = { init, checkHealth, buildWorkflow, reloadFrame, N8N, CORE }
})()