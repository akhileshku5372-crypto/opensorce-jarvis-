"""Co-work runtime: sequential task ledger, real executor injection.

Stdlib only — no mic, no TTS, no network. Runner threads are fake executors.
"""
import importlib.util
import json
import threading
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = ROOT / "background"


def _load(name):
    spec = importlib.util.spec_from_file_location(name, BACKGROUND / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


COWORK = _load("cowork_runtime")


class CoworkRuntimeTest(unittest.TestCase):
    def _clean(self):
        runner = getattr(COWORK, "_runner", None)
        if runner is not None and getattr(runner, "is_alive", lambda: False)():
            runner.join(timeout=5.0)
        COWORK._runner = None
        COWORK._task = None
        for _ in range(10):
            try:
                COWORK.STORE.unlink()
                break
            except FileNotFoundError:
                break
            except OSError:
                time.sleep(0.05)

    def setUp(self):
        self._clean()

    def tearDown(self):
        self._clean()

    def _wait_until(self, predicate, timeout=8.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.05)
        return predicate()

    def test_parse_plan(self):
        title, steps = COWORK.parse_plan("Meri study :: volume up ; gaana chalao")
        self.assertEqual(title, "Meri study")
        self.assertEqual(steps, ["volume up", "gaana chalao"])

    def test_make_task_title_uses_real_request(self):
        self.assertEqual(
            COWORK.make_task_title("organize the downloads folder"),
            "Organize Downloads Folder")
        self.assertEqual(
            COWORK.make_task_title("hey jarvis please do open my project"),
            "Open My Project")
        self.assertEqual(COWORK.make_task_title("jarvis"), "Co-work task")

    def test_run_records_done_per_step(self):
        ran = []
        ok, message = COWORK.start("t1", ["a", "b"], lambda cmd: ran.append(cmd) or (True, "ran " + cmd))
        self.assertTrue(ok, message)
        self.assertTrue(self._wait_until(lambda: COWORK.snapshot()["status"] == "done"))
        self.assertEqual(ran, ["a", "b"])
        self.assertEqual([s["status"] for s in COWORK.snapshot()["steps"]], ["done", "done"])

    def test_failure_stops_and_skips_rest(self):
        ok, _ = COWORK.start("t2", ["a", "b", "c"],
                             lambda cmd: (False, "boom") if cmd == "b" else (True, "ok"))
        self.assertTrue(ok)
        self.assertTrue(self._wait_until(lambda: COWORK.snapshot()["status"] == "failed"))
        self.assertEqual([s["status"] for s in COWORK.snapshot()["steps"]],
                         ["done", "failed", "skipped"])

    def test_second_start_while_running_refused(self):
        gate = threading.Event()
        COWORK.start("t3", ["a"], lambda cmd: gate.wait(5.0) or (True, "x"))
        try:
            ok, message = COWORK.start("t4", ["z"], lambda cmd: (True, "x"))
            self.assertFalse(ok)
            self.assertIn("already", message)
        finally:
            gate.set()
        self.assertTrue(self._wait_until(lambda: COWORK.snapshot()["status"] == "done"))

    def test_cancel_and_describe(self):
        gate = threading.Event()
        started = threading.Event()

        def slow(cmd):
            started.set()
            gate.wait(5.0)
            return (True, "ok")

        ok, _ = COWORK.start("t5", ["a", "b"], slow)
        self.assertTrue(ok)
        self.assertTrue(started.wait(5.0))
        ok, message = COWORK.cancel()
        gate.set()
        self.assertTrue(ok)
        self.assertIn("cancel", message.lower())
        self.assertTrue(self._wait_until(lambda: "cancel" in COWORK.describe()))

    def test_persist_and_interrupt_on_boot(self):
        COWORK.STORE.parent.mkdir(parents=True, exist_ok=True)
        COWORK.STORE.write_text(json.dumps({
            "id": "abc", "title": "old", "status": "running",
            "created_at": 1.0, "updated_at": 1.0, "continue_on_error": False,
            "steps": [{"title": "a", "status": "running", "result": ""}]}), encoding="utf-8")
        task = COWORK.load_persisted()
        self.assertEqual(task["status"], "interrupted")
        self.assertEqual(task["steps"][0]["status"], "skipped")


if __name__ == "__main__":
    unittest.main(verbosity=2)
