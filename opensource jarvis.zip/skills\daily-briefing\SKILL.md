---
name: daily-briefing
description: Subah ka short briefing - time, schedule, system health aur pending kaam.
triggers: daily briefing, morning briefing, subah ki briefing, aaj ka plan, brief me
---

# Daily Briefing

Give a spoken briefing in at most 6 short lines, in the user's own language.
Only use facts that JARVIS can actually verify right now:

1. **Time and date** - from the built-in time skill.
2. **Co-work task** - if a co-work task is running, one line: title + x/y steps.
3. **Scheduled jobs** - count of registered schedule entries (say "none" honestly).
4. **System health** - CPU / RAM / DISK from the bridge telemetry, flags first.
5. **Pending items** - the most recent saved note or reminder, if any.

Rules: never invent meetings, weather or news. If a data source is offline, say
that source is offline instead of guessing. Offer the next action in one line
("kya main aaj ka plan save kar doon?").
