"""Privacy Vault: On-device encrypted secret storage and key management for JARVIS.

Integrates with Windows Credential Manager via keyring to store API keys, tokens,
and credentials safely on disk without exposing plaintext strings in public files.
"""
from __future__ import annotations

import json
from typing import Optional

SERVICE_NAME = "JARVIS_AI_ASSISTANT"


def is_available() -> bool:
    """Check if the system encrypted keyring backend is reachable."""
    try:
        import keyring
        return keyring.get_keyring() is not None
    except Exception:
        return False


def set_secret(key_name: str, secret_val: str) -> bool:
    """Store an encrypted secret under the JARVIS service domain."""
    try:
        import keyring
        keyring.set_password(SERVICE_NAME, key_name.strip(), secret_val)
        return True
    except Exception:
        return False


def get_secret(key_name: str) -> Optional[str]:
    """Retrieve an encrypted secret."""
    try:
        import keyring
        return keyring.get_password(SERVICE_NAME, key_name.strip())
    except Exception:
        return None


def delete_secret(key_name: str) -> bool:
    """Delete a stored secret from the vault."""
    try:
        import keyring
        keyring.delete_password(SERVICE_NAME, key_name.strip())
        return True
    except Exception:
        return False


def vault_status() -> dict:
    """Return live encrypted vault capabilities."""
    ok = is_available()
    backend_name = "Unavailable"
    if ok:
        try:
            import keyring
            backend_name = type(keyring.get_keyring()).__name__
        except Exception:
            backend_name = "GenericKeyring"
    return {
        "available": ok,
        "backend": backend_name,
        "service": SERVICE_NAME,
        "encrypted": True,
    }
