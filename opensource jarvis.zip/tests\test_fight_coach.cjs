/* Headless tests for the Fight-Fitness rep logic (Phase 6.3).
 *
 * Run: node tests/test_fight_coach.cjs
 *
 * The rep counter is pure math over MediaPipe landmarks, so every case below
 * runs without a camera, without a CDN and without permission - which is the
 * only reason the coach's logic can be trusted at all.
 */
const assert = require('assert')
const fs = require('fs')
const path = require('path')

// package.json declares "type": "module", so a plain require() of a browser
// script would go down the ESM loader. Evaluate the real file the way a browser
// would - a classic script that publishes window.__JARVIS_FIGHT__ - so these
// tests exercise the shipped file, not a copy of it.
const source = fs.readFileSync(
  path.join(__dirname, '..', 'public', 'static', 'fight-coach.js'), 'utf8')
const sandboxWindow = {}
// eslint-disable-next-line no-new-func
const fight = new Function('window', source + '\n;return window.__JARVIS_FIGHT__')(
  sandboxWindow)
if (!fight || typeof fight.RepCounter !== 'function') {
  throw new Error('fight-coach.js did not publish __JARVIS_FIGHT__')
}

let passed = 0
function test(name, fn) {
  try {
    fn()
    passed += 1
    console.log('  ok -', name)
  } catch (err) {
    console.error('  FAIL -', name)
    console.error('   ', err.message)
    process.exitCode = 1
  }
}

// Landmarks are [a, VERTEX, b] - angleAt measures at the vertex, so the joint
// whose angle we want must be the middle index.
function blank() {
  return new Array(33).fill(null).map(() => ({
    x: 0.5, y: 0.5, z: 0, visibility: 0.9
  }))
}

// Elbow angle (shoulder 11, elbow 13, wrist 15) set to the target degrees.
// The elbow->shoulder direction is 180deg, so the wrist sits at (180 - angle)
// to make the angle AT THE ELBOW come out as the requested value.
function elbowArm(angleDeg) {
  const rad = (angleDeg * Math.PI) / 180
  const out = blank()
  out[11] = { x: 0.0, y: 0.0, z: 0, visibility: 0.95 }              // shoulder
  out[13] = { x: 0.3, y: 0.0, z: 0, visibility: 0.95 }              // vertex
  out[15] = { x: 0.3 - 0.3 * Math.cos(rad), y: 0.3 * Math.sin(rad), z: 0, visibility: 0.95 }
  return out
}

// Knee angle (hip 23, knee 25, ankle 27), same geometry rule.
function kneePose(angleDeg) {
  const rad = (angleDeg * Math.PI) / 180
  const out = blank()
  out[23] = { x: 0.0, y: 0.0, z: 0, visibility: 0.95 }
  out[25] = { x: 0.3, y: 0.0, z: 0, visibility: 0.95 }
  out[27] = { x: 0.3 - 0.3 * Math.cos(rad), y: 0.3 * Math.sin(rad), z: 0, visibility: 0.95 }
  return out
}

test('angleAt returns a right angle for perpendicular vectors', () => {
  const a = { x: 1, y: 0, z: 0 }
  const b = { x: 0, y: 0, z: 0 }
  const c = { x: 0, y: 1, z: 0 }
  assert.ok(Math.abs(fight.angleAt(a, b, c) - 90) < 0.001)
})

test('angleAt returns null when a landmark is missing', () => {
  assert.strictEqual(fight.angleAt({ x: 0, y: 0 }, null, { x: 1, y: 1 }), null)
})

test('one full push-up counts exactly one rep', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  counter.update(elbowArm(170), t += 33)          // up
  counter.update(elbowArm(90), t += 33)           // down
  counter.update(elbowArm(170), t += 33)          // up -> rep 1
  assert.strictEqual(counter.state().reps, 1)
})

test('a partial movement never counts', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  counter.update(elbowArm(170), t += 33)
  counter.update(elbowArm(120), t += 33)          // shallow, never crosses downBelow
  counter.update(elbowArm(160), t += 33)
  assert.strictEqual(counter.state().reps, 0)
})

test('three full reps count three, not two', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  for (let i = 0; i < 3; i += 1) {
    counter.update(elbowArm(170), t += 100)
    counter.update(elbowArm(95), t += 100)
    counter.update(elbowArm(170), t += 100)
  }
  assert.strictEqual(counter.state().reps, 3)
})

test('no landmarks reports "not visible" and counts nothing', () => {
  const counter = new fight.RepCounter('squat')
  const state = counter.update(null, 1000, 1)
  assert.strictEqual(state.reps, 0)
  assert.strictEqual(state.angle, null)
  assert.ok(state.hints.join(' ').includes('not clearly visible'))
})

test('low visibility pauses counting instead of guessing', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  counter.update(elbowArm(170), t += 33, 1)
  counter.update(elbowArm(90), t += 33, 1)
  const state = counter.update(elbowArm(170), t += 33, 0.2)
  assert.strictEqual(state.reps, 0)
})

test('a too-fast rep is flagged from the measured tempo', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  // First rep sets the baseline timing, the second one is too quick.
  counter.update(elbowArm(170), t += 1500)
  counter.update(elbowArm(90), t += 1500)
  counter.update(elbowArm(170), t += 1500)
  counter.update(elbowArm(90), t += 60)
  const state = counter.update(elbowArm(170), t += 60)
  assert.strictEqual(state.reps, 2)
  assert.ok(state.hints.join(' ').includes('too fast'))
})

test('a shallow rep is flagged with a depth hint', () => {
  const counter = new fight.RepCounter('squat')
  let t = 0
  counter.update(kneePose(170), t += 1000)
  counter.update(kneePose(120), t += 1000)   // past downBelow, above full depth
  const state = counter.update(kneePose(170), t += 1000)
  assert.strictEqual(state.reps, 1)
  assert.ok(state.hints.join(' ').includes('depth shallow'))
})

test('a deep squat rep produces no depth hint', () => {
  const counter = new fight.RepCounter('squat')
  let t = 0
  counter.update(kneePose(170), t += 1200)
  counter.update(kneePose(80), t += 1200)
  const state = counter.update(kneePose(170), t += 1200)
  assert.strictEqual(state.reps, 1)
  assert.ok(!state.hints.join(' ').includes('depth shallow'))
})

test('exercise switch resets the count', () => {
  const counter = new fight.RepCounter('push-up')
  let t = 0
  counter.update(elbowArm(170), t += 1000)
  counter.update(elbowArm(90), t += 1000)
  counter.update(elbowArm(170), t += 1000)
  assert.strictEqual(counter.state().reps, 1)
  const fresh = new fight.RepCounter('plank-hold')
  assert.strictEqual(fresh.state().reps, 0)
  assert.strictEqual(fresh.state().exercise, 'plank-hold')
})

test('landmark indices match the MediaPipe Pose 33-point model', () => {
  assert.strictEqual(fight.landmarks.shoulderL, 11)
  assert.strictEqual(fight.landmarks.elbowR, 14)
  assert.strictEqual(fight.landmarks.ankleR, 28)
})

console.log(`\n${passed} fight-coach tests passed`)
if (process.exitCode) {
  console.error('FIGHT COACH TESTS FAILED')
} else {
  console.log('FIGHT COACH TESTS OK')
}