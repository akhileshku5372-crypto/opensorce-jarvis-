"""Phase 4 (free path) tests: the iCal calendar reader.

Run:  node run_py.cjs -m unittest discover -s tests -p test_calendar_ics.py

No network: the tests write REAL .ics files (the same format Google Calendar's
private feed serves) into a temp folder and point the module at them. Everything
that matters is therefore exercised for real - RFC 5545 line unfolding, TZID
resolution, all-day values, DURATION, simple RRULE expansion, DPAPI storage of
the feed URL, the spoken answers and the real voice route - while the fetch
itself is the one thing mocked.
"""

from __future__ import annotations

import datetime as _dt
import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))

import calendar_ics                                     # noqa: E402
import dpapi_store                                      # noqa: E402


def _load_module(key: str, path: Path):
    spec = importlib.util.spec_from_file_location(key, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


def _day(offset: int = 0) -> str:
    return (_dt.date.today() + _dt.timedelta(days=offset)).isoformat()


def _stamp(offset: int, hour: int, minute: int = 0) -> str:
    day = _day(offset)
    return "%sT%02d%02d00" % (day.replace("-", ""), hour, minute)


def ics_doc(events: str) -> str:
    return ("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//JARVIS tests//EN\r\n"
            + events + "\r\nEND:VCALENDAR\r\n")


class IcsBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="jarvis-ics-")
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.feed = self.folder / "feed.ics"
        # No env feed, so only an explicit file drives the reads.
        env = patch.dict(os.environ, {"JARVIS_CALENDAR_ICS_URL": "",
                                      "JARVIS_CALENDAR_ICS_FILE": ""},
                         clear=False)
        env.start()
        self.addCleanup(env.stop)
        token = patch.object(calendar_ics, "token_path",
                             lambda: self.folder / "feed.url")
        token.start()
        self.addCleanup(token.stop)

    def _write(self, text: str) -> str:
        self.feed.write_text(text, encoding="utf-8")
        os.environ["JARVIS_CALENDAR_ICS_FILE"] = str(self.feed)
        calendar_ics._cache.update({"at": 0.0, "text": "", "source": ""})
        return str(self.feed)

    def _clear_env_feed(self):
        os.environ["JARVIS_CALENDAR_ICS_FILE"] = ""
        calendar_ics._cache.update({"at": 0.0, "text": "", "source": ""})


class ParsingTests(IcsBase):
    def test_folded_lines_are_rejoined(self):
        text = ics_doc(
            "BEGIN:VEVENT\r\nUID:1\r\nSUMMARY:A very long event title that the\r\n"
            " server folded across lines\r\nDTSTART:%s\r\nEND:VEVENT"
            % _stamp(0, 10))
        events = calendar_ics.parse_events(text)
        self.assertEqual(len(events), 1)
        self.assertIn("folded across lines", events[0]["summary"])

    def test_all_day_event_is_not_midnight(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:2\r\nSUMMARY:Holiday\r\n"
                       "DTSTART;VALUE=DATE:%s\r\nDTEND;VALUE=DATE:%s\r\nEND:VEVENT"
                       % (_day(0).replace("-", ""), _day(1).replace("-", "")))
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["results"][0]["summary"], "Holiday")
        self.assertTrue(out["results"][0]["all_day"])
        self.assertIn("poora din", out["results"][0]["when"])

    def test_utc_time_is_converted_to_local(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:3\r\nSUMMARY:UTC call\r\n"
                       "DTSTART:%sZ\r\nDTEND:%sZ\r\nEND:VEVENT"
                       % (_stamp(0, 10), _stamp(0, 11)))
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertTrue(out["ok"], out)
        row = out["results"][0]
        # Whatever the machine timezone, the start must be a real aware stamp
        # and must round-trip to the same instant.
        start = _dt.datetime.fromisoformat(row["start"])
        self.assertEqual(start.astimezone(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S"),
                         _stamp(0, 10) + "Z"[:0] or _stamp(0, 10))

    def test_tzid_is_resolved_when_the_zone_is_known(self):
        stamp = "%sT100000" % _day(0).replace("-", "")
        text = ics_doc("BEGIN:VEVENT\r\nUID:4\r\nSUMMARY:IST standup\r\n"
                       "DTSTART;TZID=Asia/Kolkata:%s\r\nEND:VEVENT" % stamp)
        events = calendar_ics.parse_events(text)
        self.assertFalse(events[0]["tz_unknown"])
        self._write(text)
        self.assertIn("aaj", calendar_ics.today_agenda()["results"][0]["when"])

    def test_unknown_timezone_is_reported_not_hidden(self):
        stamp = "%sT100000" % _day(0).replace("-", "")
        text = ics_doc("BEGIN:VEVENT\r\nUID:5\r\nSUMMARY:Odd zone\r\n"
                       "DTSTART;TZID=Mars/Olympus:%s\r\nEND:VEVENT" % stamp)
        events = calendar_ics.parse_events(text)
        self.assertTrue(events[0]["tz_unknown"])
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertIn("does not know", out.get("note", ""))

    def test_duration_is_understood(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:6\r\nSUMMARY:Long block\r\n"
                       "DTSTART:%s\r\nDURATION:PT1H30M\r\nEND:VEVENT"
                       % _stamp(0, 14))
        self._write(text)
        out = calendar_ics.today_agenda()
        row = out["results"][0]
        self.assertTrue(row["until"])
        self.assertNotEqual(row["until"], row["when"].split()[-1])

    def test_recurring_event_is_expanded_and_flagged(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:7\r\nSUMMARY:Daily standup\r\n"
                       "DTSTART:%s\r\nRRULE:FREQ=DAILY;COUNT=5\r\nEND:VEVENT"
                       % _stamp(0, 9))
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertTrue(out["ok"], out)
        self.assertTrue(out["results"][0]["recurring"])

    def test_cancelled_events_are_hidden(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:8\r\nSUMMARY:Cancelled thing\r\n"
                       "DTSTART:%s\r\nSTATUS:CANCELLED\r\nEND:VEVENT"
                       % _stamp(0, 11))
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertEqual(out["count"], 0)

    def test_escaped_characters_are_cleaned(self):
        text = ics_doc("BEGIN:VEVENT\r\nUID:9\r\nSUMMARY:Budget\\, Q3 review\r\n"
                       "LOCATION:Room 4\\, building B\r\nDTSTART:%s\r\nEND:VEVENT"
                       % _stamp(0, 16))
        self._write(text)
        out = calendar_ics.today_agenda()
        row = out["results"][0]
        self.assertEqual(row["summary"], "Budget, Q3 review")
        self.assertEqual(row["location"], "Room 4, building B")

    def test_events_are_sorted_by_start(self):
        text = ics_doc(
            "BEGIN:VEVENT\r\nUID:10\r\nSUMMARY:Late\r\nDTSTART:%s\r\nEND:VEVENT\r\n"
            "BEGIN:VEVENT\r\nUID:11\r\nSUMMARY:Early\r\nDTSTART:%s\r\nEND:VEVENT"
            % (_stamp(0, 18), _stamp(0, 9)))
        self._write(text)
        out = calendar_ics.today_agenda()
        self.assertEqual([r["summary"] for r in out["results"]],
                         ["Early", "Late"])


class ReadTests(IcsBase):
    def test_today_returns_real_events(self):
        self._write(ics_doc(
            "BEGIN:VEVENT\r\nUID:20\r\nSUMMARY:Team sync\r\nLOCATION:Room 4\r\n"
            "DTSTART:%s\r\nDTEND:%s\r\nEND:VEVENT\r\n"
            "BEGIN:VEVENT\r\nUID:21\r\nSUMMARY:Dentist\r\nDTSTART:%s\r\nEND:VEVENT"
            % (_stamp(0, 10), _stamp(0, 11), _stamp(0, 18))))
        out = calendar_ics.today_agenda()
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["count"], 2)
        said = calendar_ics.spoken_today(out)
        self.assertIn("Team sync", said)
        self.assertIn("Room 4", said)
        self.assertIn("aaj", said)

    def test_empty_day_says_so(self):
        self._write(ics_doc(
            "BEGIN:VEVENT\r\nUID:22\r\nSUMMARY:Tomorrow only\r\nDTSTART:%s\r\n"
            "END:VEVENT" % _stamp(1, 9)))
        out = calendar_ics.today_agenda()
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["count"], 0)
        self.assertIn("khaali hai", calendar_ics.spoken_today(out))

    def test_not_configured_is_reported_not_empty(self):
        self._clear_env_feed()
        out = calendar_ics.today_agenda()
        self.assertFalse(out["ok"])
        self.assertIn("no calendar feed", calendar_ics.spoken_today(out).lower())

    def test_event_beyond_tomorrow_is_labelled_with_its_date(self):
        # Regression: the "beyond tomorrow" branch of the label formatter used a
        # "%s" placeholder after strftime(), which raised ValueError. Only an
        # event more than a day out reaches it.
        self._write(ics_doc(
            "BEGIN:VEVENT\r\nUID:23\r\nSUMMARY:Later meeting\r\nDTSTART:%s\r\n"
            "END:VEVENT" % _stamp(4, 13)))
        out = calendar_ics.upcoming(5)
        self.assertTrue(out["ok"], out)
        row = out["results"][0]
        self.assertEqual(row["summary"], "Later meeting")
        self.assertIn("01:00 PM", row["when"])
        self.assertIn(str((_dt.date.today() + _dt.timedelta(days=4)).day),
                      row["when"])

    def test_unreadable_file_reports_the_reason(self):
        os.environ["JARVIS_CALENDAR_ICS_FILE"] = str(self.folder / "ghost.ics")
        calendar_ics._cache.update({"at": 0.0, "text": "", "source": ""})
        out = calendar_ics.today_agenda()
        self.assertFalse(out["ok"])
        self.assertIn("cannot read", out["error"])

    def test_feed_that_is_not_ics_is_reported(self):
        self._write("<html>not a calendar</html>")
        out = calendar_ics.today_agenda()
        self.assertFalse(out["ok"])
        self.assertIn("no events", out["error"])


class StorageTests(IcsBase):
    def test_feed_url_is_stored_dpapi_encrypted(self):
        out = calendar_ics.connect("https://calendar.google.com/calendar/ical/"
                                   "abc%40group.calendar.google.com/public/"
                                   "basic.ics")
        self.assertTrue(out["ok"], out)
        stored = self.folder / "feed.url"
        self.assertTrue(stored.is_file())
        self.assertNotIn(b"calendar.google.com", stored.read_bytes())
        self.assertEqual(calendar_ics.feed_url(),
                         "https://calendar.google.com/calendar/ical/"
                         "abc%40group.calendar.google.com/public/basic.ics")

    def test_webcal_scheme_is_accepted(self):
        out = calendar_ics.connect("webcal://example.com/basic.ics")
        self.assertTrue(out["ok"], out)

    def test_junk_is_refused(self):
        for bad in ("", "not a url", "javascript:alert(1)"):
            self.assertFalse(calendar_ics.connect(bad)["ok"], bad)

    def test_ics_path_is_accepted_only_when_real(self):
        self.assertFalse(calendar_ics.connect(str(self.folder / "ghost.ics"))
                         ["ok"])
        self._write(ics_doc("BEGIN:VEVENT\r\nUID:30\r\nSUMMARY:X\r\n"
                            "DTSTART:%s\r\nEND:VEVENT" % _stamp(0, 9)))
        out = calendar_ics.connect(str(self.feed))
        self.assertTrue(out["ok"], out)
        self.assertEqual(out["kind"], "file")

    def test_disconnect_removes_the_local_copy_only(self):
        calendar_ics.connect("https://example.com/basic.ics")
        out = calendar_ics.disconnect()
        self.assertTrue(out["ok"])
        self.assertFalse((self.folder / "feed.url").is_file())

    def test_status_is_offline_and_honest(self):
        info = calendar_ics.status()
        self.assertFalse(info["configured"])
        self.assertTrue(info["read_only"])
        self.assertFalse(info["oauth"])
        self.assertIn("JARVIS_CALENDAR_ICS_URL", info["reason"])

    def test_status_after_connecting_reports_encrypted(self):
        calendar_ics.connect("https://example.com/basic.ics")
        info = calendar_ics.status()
        self.assertTrue(info["configured"])
        self.assertTrue(info["stored_encrypted"])


class FetchTests(IcsBase):
    def test_fetch_maps_a_network_error_to_a_reason(self):
        with patch.object(calendar_ics, "feed_url",
                          return_value="https://example.invalid/x.ics"):
            out = calendar_ics.today_agenda()
        self.assertFalse(out["ok"])
        self.assertTrue(out["error"])

    def test_http_error_is_reported_with_status(self):
        import urllib.error

        class _Resp(Exception):
            pass

        def _boom(*_args, **_kw):
            raise urllib.error.HTTPError("https://x", 403, "Forbidden", None, None)

        with patch.object(calendar_ics, "feed_url",
                          return_value="https://example.com/x.ics"), \
             patch.object(calendar_ics.urllib.request, "urlopen", _boom):
            out = calendar_ics.today_agenda()
        self.assertFalse(out["ok"])
        self.assertIn("403", out["error"])
        self.assertEqual(out.get("status"), 403)


class VoiceRouteTests(unittest.TestCase):
    """The real dispatcher answers calendar questions itself."""

    @classmethod
    def setUpClass(cls):
        cls.voice = _load_module("voice_engine_calendar",
                                 ROOT / "background" / "voice_engine.py")

    class _FakeCalendar:
        def __init__(self, today=None, upcoming=None, status=None, connect=None):
            self._returns = {"today_agenda": today, "upcoming": upcoming,
                             "status": status or {"configured": True,
                                                  "read_only": True},
                             "connect": connect or {"ok": True},
                             "spoken_status": lambda info: "calendar set hai"}
            self.calls = []
            self.last_arg = None

        def __getattr__(self, name):
            if name.startswith("spoken_"):
                return lambda *a, **k: ("spoken" if a else "")
            if name not in self._returns:
                raise AttributeError(name)

            def _fn(*args, **_kw):
                self.calls.append(name)
                self.last_arg = args[0] if args else None
                return self._returns[name]
            return _fn

    def test_today_question_is_answered_by_the_calendar_route(self):
        fake = self._FakeCalendar(today={"ok": True, "count": 1, "results": [
            {"summary": "Standup", "when": "aaj 10:30 AM", "all_day": False,
             "until": "11:00 AM", "location": "Room 1"}]})
        said = []
        with patch.object(self.voice, "_calendar_ics_mod", return_value=fake):
            handled = self.voice._calendar_route("aaj ka calendar batao", "",
                                                 said.append)
        self.assertTrue(handled)
        self.assertTrue(said)
        self.assertEqual(fake.calls, ["today_agenda"])

    def test_meeting_question_with_a_time_word_uses_the_route(self):
        fake = self._FakeCalendar(today={"ok": True, "count": 0, "results": []})
        with patch.object(self.voice, "_calendar_ics_mod", return_value=fake):
            handled = self.voice._calendar_route("aaj koi meeting hai?", "",
                                                 lambda _t: None)
        self.assertTrue(handled)
        self.assertEqual(fake.calls, ["today_agenda"])

    def test_pasted_feed_link_connects_the_calendar(self):
        fake = self._FakeCalendar()
        said = []
        with patch.object(self.voice, "_calendar_ics_mod", return_value=fake):
            handled = self.voice._calendar_route(
                "calendar connect https://example.com/feed/basic.ics", "",
                said.append)
        self.assertTrue(handled)
        self.assertEqual(fake.calls, ["connect"])
        self.assertIn("https://example.com/feed/basic.ics", fake.last_arg)
        self.assertIn("calendar set ho gaya", said[0])

    def test_unconfigured_calendar_explains_the_free_setup_step(self):
        fake = self._FakeCalendar(
            today={"ok": False, "error": "no calendar feed configured"},
            status={"configured": False, "reason": "no feed"})
        said = []
        with patch.object(self.voice, "_calendar_ics_mod", return_value=fake):
            self.voice._calendar_route("aaj ka calendar batao", "", said.append)
        self.assertIn("no calendar feed", said[0])
        self.assertIn("Integrate calendar", said[0])
        self.assertIn("OAuth nahi", said[0])
        self.assertIn("bank account nahi", said[0])

    def test_outbound_message_sentence_is_not_stolen(self):
        # Regression guard: "kal meeting bhej do" belongs to WhatsApp, not here.
        for sentence in ("akhilesh ko whatsapp pe kal meeting hai bhejo",
                         "send kal meeting 4 pm to amit"):
            with patch.object(self.voice, "_calendar_ics_mod") as cal:
                handled = self.voice._calendar_route(sentence, "",
                                                     lambda _t: None)
            self.assertIsNone(handled, sentence)
            cal.assert_not_called()

    def test_unrelated_sentence_is_not_stolen(self):
        with patch.object(self.voice, "_calendar_ics_mod") as cal:
            handled = self.voice._calendar_route("play a song", "",
                                                 lambda _t: None)
        self.assertIsNone(handled)
        cal.assert_not_called()

    def test_email_questions_are_no_longer_claimed(self):
        # Gmail was removed by owner request; the route must not answer mail.
        for sentence in ("kitne unread emails hain", "latest email padho",
                         "gmail status"):
            with patch.object(self.voice, "_calendar_ics_mod") as cal:
                handled = self.voice._calendar_route(sentence, "",
                                                     lambda _t: None)
            self.assertIsNone(handled, sentence)
            cal.assert_not_called()


class PluginToolContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plugin = _load_module(
            "jarvis_modules_calendar",
            ROOT / "extensions" / "plugins" / "jarvis-modules" / "plugin.py")
        cls.by_name = {t["name"]: t for t in cls.plugin.TOOLS}

    def test_read_tools_are_auto_and_ungated(self):
        for name in ("calendar_status", "calendar_today", "calendar_upcoming"):
            tool = self.by_name[name]
            self.assertEqual(tool["permission_category"], "read_files", name)
            self.assertFalse(tool["requires_confirmation"], name)

    def test_setting_and_clearing_the_feed_are_double_gated(self):
        for name in ("calendar_connect", "calendar_disconnect"):
            tool = self.by_name[name]
            self.assertEqual(tool["permission_category"], "communication", name)
            self.assertTrue(tool["requires_confirmation"], name)

    def test_no_gmail_tools_survive(self):
        for name in self.by_name:
            self.assertNotIn("gmail", name.lower(), name)


class ModuleCapabilityTests(unittest.TestCase):
    def test_module_exposes_no_write_capability(self):
        names = {n for n in dir(calendar_ics) if not n.startswith("_")}
        for banned in ("create_event", "update_event", "delete_event", "post",
                       "put", "patch"):
            self.assertNotIn(banned, names)

    def test_module_ships_no_oauth_client(self):
        source = (ROOT / "background" / "calendar_ics.py").read_text(
            encoding="utf-8")
        for banned in ("oauth2.googleapis.com", "accounts.google.com",
                       "refresh_token"):
            self.assertNotIn(banned, source, banned)

    def test_gmail_module_is_gone(self):
        self.assertFalse((ROOT / "background" / "gmail_client.py").exists(),
                         "the Gmail integration was removed by owner request")


class CapabilityProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = _load_module("capability_registry_calendar",
                                    ROOT / "background" / "capability_registry.py")

    def test_card_is_ready_with_no_feed_and_names_the_free_step(self):
        cal = self.registry._load("calendar_ics")
        with tempfile.TemporaryDirectory() as tmp, \
             patch.dict(os.environ, {"JARVIS_CALENDAR_ICS_URL": "",
                                     "JARVIS_CALENDAR_ICS_FILE": "",
                                     "JARVIS_DATA_ROOT": tmp}):
            verdict = self.registry._probe_calendar()
        self.assertEqual(verdict["state"], "READY")
        self.assertIn("no OAuth", verdict["reason"])
        self.assertIn("bank account", verdict["reason"])
        self.assertIsNotNone(cal)

    def test_card_is_live_with_a_readable_feed(self):
        cal = self.registry._load("calendar_ics")
        with tempfile.TemporaryDirectory() as tmp:
            feed = Path(tmp) / "f.ics"
            feed.write_text(ics_doc(
                "BEGIN:VEVENT\r\nUID:40\r\nSUMMARY:Probe event\r\nDTSTART:%s\r\n"
                "END:VEVENT" % _stamp(0, 9)), encoding="utf-8")
            with patch.dict(os.environ, {"JARVIS_CALENDAR_ICS_URL": "",
                                         "JARVIS_CALENDAR_ICS_FILE": str(feed),
                                         "JARVIS_DATA_ROOT": tmp}):
                cal._cache.update({"at": 0.0, "text": "", "source": ""})
                verdict = self.registry._probe_calendar()
        self.assertEqual(verdict["state"], "LIVE")
        self.assertFalse(verdict["evidence"]["oauth"])
        self.assertEqual(verdict["evidence"]["today_events"], 1)
        self.assertIn("No OAuth", verdict["reason"])

    def test_gmail_card_is_gone(self):
        ids = {row[0] for row in self.registry.CATALOG}
        self.assertNotIn("gmail-reader", ids)
        self.assertIn("calendar-agenda", ids)


if __name__ == "__main__":
    unittest.main()