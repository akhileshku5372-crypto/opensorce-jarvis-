// Live-DOM proof that the hand skeleton lands where the camera picture is.
//
// Why this exists: the owner's screenshot showed two big skeletons painted over
// his face and the panel while his hands were nowhere in frame. Before touching
// anything, this measures the ONE thing that can put a landmark at the wrong
// pixel: the mapping from MediaPipe's normalized 0..1 camera frame, through the
// video's cover-crop, onto the canvas box at the real devicePixelRatio.
//
// It uses NO camera: the video's intrinsic size is fixed by defineProperty and
// the landmarks are synthetic, so the expected pixel for every point is known
// arithmetic. If the drawing disagrees with that arithmetic, this fails.
//
// Run: node tests/test_gesture_overlay.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'

const UI = 'http://127.0.0.1:7777/'
const PORT = 9255
const EXE = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const profile = mkdtempSync(tmpdir() + '\\jarvis-gest-')
const chrome = spawn(EXE, [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })
const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { }
  try { rmSync(profile, { recursive: true, force: true }) } catch { }
}
setTimeout(() => { cleanup(); process.exit(124) }, 200000).unref()

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

// One page evaluation, so the numbers cannot come from different states.
const HARNESS = `(async () => {
  const api = window.__JARVIS_GESTURE_CONTROL__
  if (!api) return { error: 'gesture-control.js is not loaded' }

  // A panel that mimics the Camera view: video fills it, canvas sits on top.
  document.getElementById('gest-fixture')?.remove()
  const host = document.createElement('div')
  host.id = 'gest-fixture'
  host.setAttribute('data-gesture-panel', 'fixture')
  host.style.cssText = 'position:fixed;left:40px;top:40px;width:420px;height:260px;overflow:hidden'
  const video = document.createElement('video')
  video.className = 'camera-feed'
  video.style.cssText = 'width:100%;height:100%;object-fit:cover;transform:scaleX(-1)'
  const canvas = document.createElement('canvas')
  canvas.className = 'gesture-canvas'
  canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%'
  host.appendChild(video); host.appendChild(canvas); document.body.appendChild(host)

  // The camera's intrinsic frame, without a camera.
  Object.defineProperty(video, 'videoWidth', { value: 1280, configurable: true })
  Object.defineProperty(video, 'videoHeight', { value: 720, configurable: true })

  const ctx = { state: { gestureActive: false, gestureFrame: 0 }, showToast() {}, refreshBridge() {},
    setRuntimeState() {}, navigateTo() {}, executeCommand() {}, speak() {} }
  const ctrl = api.create(ctx)
  ctrl.video = video
  ctrl.panel = host
  ctrl.sourceWidth = 1280
  ctrl.sourceHeight = 720

  // Record every pixel the drawer touches, instead of reading back the bitmap.
  const seen = { arcs: [], lines: [] }
  const realGet = HTMLCanvasElement.prototype.getContext
  let patched = null
  HTMLCanvasElement.prototype.getContext = function (type, ...rest) {
    const c = realGet.call(this, type, ...rest)
    if (this === canvas && type === '2d' && !patched) {
      patched = c
      const arc = c.arc.bind(c)
      c.arc = (x, y, r, s, e) => { seen.arcs.push([x, y]); return arc(x, y, r, s, e) }
      const moveTo = c.moveTo.bind(c), lineTo = c.lineTo.bind(c)
      c.moveTo = (x, y) => { seen.lines.push([x, y]); return moveTo(x, y) }
      c.lineTo = (x, y) => { seen.lines.push([x, y]); return lineTo(x, y) }
    }
    return c
  }
  // MediaPipe supplies this; the drawer falls back to [] without it.
  window.HAND_CONNECTIONS = [[0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 9], [9, 13], [13, 17], [0, 17]]

  // A hand that occupies the middle-left of the frame, in normalized coords.
  const lm = []
  for (let i = 0; i < 21; i += 1) {
    lm.push({ x: 0.20 + (i % 5) * 0.04, y: 0.35 + Math.floor(i / 5) * 0.08, z: 0 })
  }
  const rect = canvas.getBoundingClientRect()
  ctrl.draw([{ side: 'left', lm, score: 0.99, lowConfidence: false }])
  HTMLCanvasElement.prototype.getContext = realGet

  // The same arithmetic the code claims to do, computed here independently.
  const dpr = Math.max(1, window.devicePixelRatio || 1)
  const scale = Math.max(rect.width / 1280, rect.height / 720)
  const offX = (rect.width - 1280 * scale) / 2
  const offY = (rect.height - 720 * scale) / 2
  const expect = lm.map((p) => {
    let x = offX + p.x * 1280 * scale
    x = rect.width - x            // the preview is mirrored
    return [x, offY + p.y * 720 * scale]
  })
  const got = seen.arcs.slice(0, 21)
  const deltas = got.map((g, i) => (i < expect.length
    ? Math.max(Math.abs(g[0] - expect[i][0]), Math.abs(g[1] - expect[i][1])) : null))
  const outside = got.filter(([x, y]) => x < -1 || y < -1 || x > rect.width + 1 || y > rect.height + 1).length
  const backing = { w: canvas.width, h: canvas.height }
  host.remove()
  return {
    canvasBox: [Math.round(rect.width), Math.round(rect.height)],
    backing, dpr,
    arcs: got.length, lines: seen.lines.length,
    maxDelta: deltas.length ? Math.max(...deltas.filter((d) => d !== null)) : null,
    firstGot: got[0] ? got[0].map((v) => Math.round(v)) : null,
    firstExpect: expect[0].map((v) => Math.round(v)),
    outside,
    scale: Number(scale.toFixed(3)),
  }
})()`

async function main() {
  let page = null
  for (let i = 0; i < 40 && !page; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) { const j = await res.json(); if (j?.webSocketDebuggerUrl) page = j }
    } catch { }
    await wait(300)
  }
  if (!page) throw new Error('no CDP page target')
  const ws = new WebSocket(page.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
  })
  const send = (method, params = {}) => new Promise((r) => { const mid = ++id; pending.set(mid, r); ws.send(JSON.stringify({ id: mid, method, params })) })
  const ev = async (e) => { const r = await send('Runtime.evaluate', { expression: e, awaitPromise: true, returnByValue: true }); return r?.result?.result?.value }
  await send('Page.enable'); await send('Runtime.enable')
  await send('Page.navigate', { url: UI })
  await wait(7000)

  const r = await ev(HARNESS)
  if (!r || r.error) { cleanup(); throw new Error('harness could not run: ' + (r && r.error)) }

  console.log('  canvas box ' + JSON.stringify(r.canvasBox) + 'px, backing ' + JSON.stringify(r.backing)
    + ' at dpr ' + r.dpr + ', cover scale ' + r.scale)
  if (r.arcs !== 21) bad(`only ${r.arcs} landmark points were drawn (expected 21)`)
  else ok('all 21 landmarks drawn')
  if (!r.lines) bad('no skeleton connections drawn - HAND_CONNECTIONS never reached the drawer')
  else ok(`${r.lines} connection endpoints drawn`)
  // The backing store must follow the displayed box * dpr, or the skeleton is
  // stretched relative to the picture on a scaled display.
  const wantW = Math.round(r.canvasBox[0] * r.dpr), wantH = Math.round(r.canvasBox[1] * r.dpr)
  if (Math.abs(r.backing.w - wantW) > 1 || Math.abs(r.backing.h - wantH) > 1) {
    bad(`backing store ${r.backing.w}x${r.backing.h} does not match the box x dpr (${wantW}x${wantH})`)
  } else ok('backing store follows the CSS box and devicePixelRatio')
  if (r.maxDelta === null) bad('no point positions captured')
  else if (r.maxDelta > 2) bad(`drawn points differ from the cover-crop math by up to ${r.maxDelta.toFixed(1)}px (first got ${JSON.stringify(r.firstGot)}, expected ${JSON.stringify(r.firstExpect)})`)
  else ok(`every landmark lands within ${r.maxDelta.toFixed(2)}px of the cover-crop math`)
  if (r.outside) bad(`${r.outside} landmark(s) drawn outside the canvas box for points inside 0..1`)
  else ok('no phantom points outside the picture')
}

try { await main() } catch (err) { bad('harness threw: ' + (err && err.stack ? err.stack : err)) } finally { cleanup() }

console.log('')
console.log(`${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
