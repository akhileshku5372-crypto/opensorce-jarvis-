// Live DOM proof for the Modules & Upgrades cards: a click must open a plain,
// single-colour, empty page - and it must be escapable, because a page with no
// way out is a trap, not a page.
//
// This is exactly what was asked for on 2026-10-21 ("click karu tho ek empty,
// kewal pure one coloured empty page jismein kuch nahi hoga"). It deliberately
// contradicts the AGENTS.md rule about never shipping a dead-end card: the
// owner chose the blank page, so the test pins the blank page and nothing more.
//
// Requires the running stack (vite :7777 + voice core :7780 for /modules).
// Run: node tests/test_module_blank_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'

const UI = 'http://127.0.0.1:7777/'
const PORT = 9226
const profile = mkdtempSync(`${tmpdir()}\\jarvis-blank-ui-`)
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { }
  try { rmSync(profile, { recursive: true, force: true }) } catch { }
}
setTimeout(() => { cleanup(); process.exit(124) }, 220000).unref()

let passed = 0
let failed = 0
const ok = (m) => { passed++; console.log('  ok   ' + m) }
const bad = (m) => { failed++; console.log('  FAIL ' + m) }

const PROBE = `(() => {
  const el = document.getElementById('module-blank')
  if (!el) return { exists: false }
  const cs = getComputedStyle(el)
  const r = el.getBoundingClientRect()
  const bar = document.querySelector('.topbar')
  const side = document.getElementById('sidebar')
  const b = bar ? bar.getBoundingClientRect() : { bottom: 0 }
  const s = side && side.getBoundingClientRect().width > 60 ? side.getBoundingClientRect() : { right: 0 }
  return {
    exists: true,
    hidden: el.hidden || cs.display === 'none' || cs.visibility === 'hidden',
    text: (el.textContent || '').trim(),
    children: el.childElementCount,
    bg: cs.backgroundColor,
    flat: cs.backgroundImage === 'none',
    z: Number(cs.zIndex) || 0,
    // The contract is the red box in the owner's screenshot: the content area
    // only. The sidebar and the topbar must stay visible and usable, so the
    // blank must start below the topbar and right of the sidebar, and reach the
    // window's right/bottom edges.
    box: [Math.round(r.top), Math.round(r.left), Math.round(r.right), Math.round(r.bottom)],
    belowTopbar: r.top >= b.bottom - 1,
    rightOfSidebar: r.left >= s.right - 1,
    // Measured against the LAYOUT viewport (clientWidth/Height): innerWidth
    // includes the 15px classic scrollbar, which is painted above every element
    // and no page can cover it - comparing against it would fail forever.
    reachesRight: Math.abs(r.right - document.documentElement.clientWidth) <= 1,
    reachesBottom: Math.abs(r.bottom - document.documentElement.clientHeight) <= 1,
    topbarVisible: (() => { const el2 = bar; if (!el2) return false
      const c = getComputedStyle(el2); return c.display !== 'none' && c.visibility !== 'hidden' })(),
    sidebarVisible: (() => { if (!side) return false
      const c = getComputedStyle(side); return c.display !== 'none' && side.getBoundingClientRect().width > 40 })(),
  }
})()`

// Click the first card that declares no target (those are the only ones allowed
// to show the blank area), and the first that declares a view.
const CLICK_BLANK_CARD = `(() => {
  const c = [...document.querySelectorAll('.module-card-live')]
    .find((x) => /"none"/.test(x.dataset.launch || ''))
  if (!c) return 'NO NONE CARD'
  c.click()
  return c.dataset.moduleId
})()`
const CLICK_VIEW_CARD = `(() => {
  const c = [...document.querySelectorAll('.module-card-live')]
    .find((x) => /"view"/.test(x.dataset.launch || ''))
  if (!c) return 'NO VIEW CARD'
  c.click()
  return c.dataset.moduleId
})()`
const ACTIVE_VIEW = `(() => {
  const v = document.querySelector('.view.active')
  return v ? v.getAttribute('data-view-panel') : null
})()`

async function main() {
  let page = null
  for (let i = 0; i < 40 && !page; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(UI)}`, { method: 'PUT' })
      if (res.ok) { const j = await res.json(); if (j?.webSocketDebuggerUrl) page = j }
    } catch { }
    await wait(400)
  }
  if (!page) throw new Error('no CDP page target')

  const ws = new WebSocket(page.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
  let id = 0
  const pending = new Map()
  const problems = []
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      problems.push((m.params.args || []).map((a) => a.value || a.description || '').join(' '))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      problems.push([m.params.entry.url || '', m.params.entry.text].join(' '))
    }
  })
  const send = (method, params = {}) => new Promise((r) => {
    const mid = ++id
    pending.set(mid, r)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true })
    return r.result && r.result.result ? r.result.result.value : undefined
  }

  await send('Page.enable')
  await send('Runtime.enable')
  await send('Log.enable')
  await send('Page.navigate', { url: UI })
  await wait(6000)

  // Open Modules & Upgrades and wait for the real probe to render the cards.
  const opened = await evaluate(`(() => {
    const nav = document.querySelector('[data-view="modules"]')
    if (!nav) return 'no nav'
    nav.click()
    return 'clicked'
  })()`)
  if (opened !== 'clicked') bad(`cannot reach the Modules view (${opened})`)
  else ok('Modules & Upgrades view opened')

  let cards = 0
  let gridNote = ''
  for (let i = 0; i < 75 && !cards; i++) {
    cards = await evaluate(`document.querySelectorAll('.module-card-live').length`)
    if (!cards) {
      gridNote = await evaluate(`(document.querySelector('[data-modules-grid]')||{}).textContent||''`)
      await wait(1000)
    }
  }
  if (!cards) bad(`no module cards rendered in 75s, so a click cannot be tested (grid says: "${String(gridNote).trim().slice(0, 90)}")`)
  else ok(`${cards} module cards on screen`)

  const before = await evaluate(PROBE)
  if (!before.exists) { cleanup(); throw new Error('the blank page element #module-blank does not exist') }
  if (!before.hidden) bad('the blank page is visible before any card was clicked')
  else ok('blank page starts hidden')

  // 1. A card with nothing to open blanks the CONTENT AREA only. The owner
  // rejected the full-screen version: "empty workspace ka matlab sirf full
  // screen empty nahi, kewal selected part empty hoo".
  const blankCard = await evaluate(CLICK_BLANK_CARD)
  if (blankCard === 'NO NONE CARD') bad('no card declares "none", so the blank path cannot be tested')
  await wait(400)
  const after = await evaluate(PROBE)
  if (after.hidden) bad(`clicking the unconnected card (${blankCard}) still does nothing`)
  else ok(`an unconnected card (${blankCard}) opens the blank area`)
  if (!after.belowTopbar) bad(`blank begins at y=${after.box[0]} - it covers the topbar, which must stay visible`)
  else ok('topbar stays outside the blank')
  if (!after.rightOfSidebar) bad(`blank begins at x=${after.box[1]} - it covers the sidebar, which must stay visible`)
  else ok('sidebar stays outside the blank')
  if (!after.reachesRight || !after.reachesBottom) bad(`blank ends at ${JSON.stringify(after.box)} instead of the window edges`)
  else ok('blank fills the content area right up to the window edges')
  if (!after.topbarVisible || !after.sidebarVisible) bad('topbar or sidebar is not visible while the blank is open')
  else ok('topbar and sidebar both still visible')
  if (after.text || after.children) bad(`the area is not empty (${after.children} children, text "${after.text.slice(0, 40)}")`)
  else ok('area is empty: no text, no children')
  if (after.flat === false || /transparent|rgba\(0, 0, 0, 0\)/.test(after.bg)) bad(`not one flat colour (bg=${after.bg})`)
  else ok(`one solid colour (${after.bg})`)
  if (after.z < 1) bad(`z-index ${after.z} - the module grid would show through it`)
  else ok(`blank sits above the view content (z-index ${after.z})`)

  // 1b. A card that DOES have a target must navigate, never blank. This is the
  // owner's own example: the Split-Brain card and the Brain view are one thing.
  await evaluate(`document.querySelector('[data-view="modules"]')?.click()`)
  await wait(400)
  const viewCard = await evaluate(CLICK_VIEW_CARD)
  await wait(500)
  const landed = await evaluate(ACTIVE_VIEW)
  const stillBlank = await evaluate(PROBE)
  if (viewCard === 'NO VIEW CARD') bad('no card declares a view target, so the wiring cannot be tested')
  else if (landed === 'modules') bad(`card ${viewCard} declares a view but the page did not move`)
  else if (!stillBlank.hidden) bad(`a connected card showed the blank instead of opening (${viewCard})`)
  else ok(`card ${viewCard} opened its own view (${landed}), no blank`)

  // 1c. n8n gets the one-click start the owner asked for.
  const startCmd = await evaluate(`(() => {
    const btn = document.querySelector('.module-start')
    return btn ? btn.getAttribute('data-command') : null
  })()`)
  if (startCmd !== 'start n8n') bad(`the n8n Start button is missing or wrong (${startCmd})`)
  else ok('n8n card carries a Start button that speaks "start n8n"')

  // 2. Going to another view closes it, or the blank would cover the next page.
  await evaluate(`document.querySelector('[data-view="modules"]')?.click()`)
  await wait(300)
  await evaluate(CLICK_BLANK_CARD)
  await wait(300)
  await evaluate(`document.querySelector('[data-view="dashboard"]')?.click()`)
  await wait(400)
  const afterNav = await evaluate(PROBE)
  if (!afterNav.hidden) bad('the blank is still covering the content area after switching to Dashboard')
  else ok('switching view closes the blank')

  // 3. Escape by click.
  await evaluate(`document.querySelector('[data-view="modules"]')?.click()`)
  await wait(300)
  await evaluate(CLICK_BLANK_CARD)
  await wait(300)
  await evaluate(`(() => { const el = document.getElementById('module-blank'); el.click() })()`)
  await wait(300)
  const afterClick = await evaluate(PROBE)
  if (!afterClick.hidden) bad('clicking the blank does not close it - he would be stuck')
  else ok('click closes the blank')

  // 4. Escape by keyboard.
  await evaluate(`document.querySelector('[data-view="modules"]')?.click()`)
  await wait(300)
  await evaluate(CLICK_BLANK_CARD)
  await wait(300)
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 })
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 })
  await wait(300)
  const afterEsc = await evaluate(PROBE)
  if (!afterEsc.hidden) bad('Escape does not close the blank area either')
  else ok('Escape closes the blank area')

  const real = problems.filter((p) => !/favicon|5678/i.test(p))
  if (real.length) bad(`console was not clean (${real.length}): ${real.slice(0, 2).join(' | ')}`)
  else ok('zero console errors from this surface')
}

try { await main() } catch (err) { bad('harness threw: ' + (err && err.stack ? err.stack : err)) } finally { cleanup() }

console.log('')
console.log(`${passed} passed, ${failed} failed`)
process.exit(failed ? 1 : 0)
