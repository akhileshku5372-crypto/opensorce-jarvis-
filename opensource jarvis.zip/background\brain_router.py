"""Human-Brain Router — Split-Brain wiring for every API key as ONE brain.

Turns the scattered provider chain into a human neuro-anatomy WITHOUT
replacing the chain itself (model_catalog + voice_engine._brain_raw). Routes
through it so there is still exactly one voice core / one mic / one memory.

Anatomy:
  Prefrontal Cortex — Groq / Gemini Flash : high-speed router, intent + language
  Cerebrum           — Deep Reasoning      : Gemini free-lite / DeepSeek (FREE pool)
  Broca's Area       — Voice -> Text       : Groq Whisper + faster-whisper
  Motor Cortex       — Local OS execution  : 0-token bypass via cowork_tools/bridge
  Hippocampus        — Memory / RAG        : Chroma + JSON habit feedback loop
"""
from __future__ import annotations
import json, os, re, time, threading
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
def _load(name: str):
    import importlib.util, sys
    full = "jarvis_cowork_" + name
    ex = sys.modules.get(full)
    if ex is not None: return ex
    p = ROOT / "background" / (name + ".py")
    if not p.is_file(): return None
    try:
        spec = importlib.util.spec_from_file_location(full, p)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[full] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception: return None
PREFRONTAL_MODEL = os.environ.get("JARVIS_PREFRONTAL_MODEL", "openai/gpt-oss-120b")
CEREBRUM_MODEL = os.environ.get("JARVIS_CEREBRUM_MODEL", "gemini-3.5-flash-lite")
BUDGET_SOFT = int(os.environ.get("JARVIS_TOKEN_BUDGET_SOFT", "1800"))
BUDGET_HARD = int(os.environ.get("JARVIS_TOKEN_BUDGET_HARD", "3200"))
_lock = threading.RLock()
_last: dict = {}
_diag_fn = None
def _diag(m: str):
    if callable(_diag_fn):
        try: _diag_fn(str(m))
        except Exception: pass
def bind_diag(fn): 
    global _diag_fn; _diag_fn = fn
HIST_DIR = ROOT / "artifacts" / "brain"
HIST_DIR.mkdir(parents=True, exist_ok=True)
STATE_PATH = HIST_DIR / "last_route.json"
HIPPO_JSON = HIST_DIR / "hippocampus.json"
_HINGLISH = re.compile(r"\b(hai|hain|kar|karo|bhai|bro|kya|kaise|kahan|main|mein|mera|tera|yaar|achha|theek|zara|jaldi|samjhao|batao|kholo|band|karo)\b", re.I)
_JA = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")
_DEVA = re.compile(r"[\u0900-\u097f]")
_MOTOR = re.compile(r"\b(open|launch|close|minimize|maximize|type|click|scroll|press|file|folder|notepad|calculator|explorer|chrome|vscode|vs code|settings|volume|brightness|window|desktop|screenshot|copy|paste|create|make file|write file|move mouse|kholo|band karo|likho|banao)\b", re.I)
_HIGH = re.compile(r"\b(prove|proof|theorem|derive|integrate|differential|algorithm|complexity|debug|traceback|stack|optimize|big-?o|recursion|transformer|attention|explain in depth|step by step reasoning|samjhao detail me|gehrai se|vishleshan|ganit|praman)\b", re.I)
_CODE = re.compile(r"(def |class |import |```|function\(|const |let |```python|traceback)", re.I)
def _lang(t: str) -> str:
    s = str(t or "")
    if _JA.search(s): return "ja"
    if _DEVA.search(s): return "hi"
    if _HINGLISH.search(s): return "hinglish"
    try:
        ve = _load("voice_engine")
        if ve and hasattr(ve, "detect_language"): return str(ve.detect_language(s))
    except Exception: pass
    return "en"
def _weight(t: str) -> int: return max(8, (len(str(t or "")) + 3)//4 + 24)
def _complexity(t: str, w: int) -> str:
    s = str(t or "")
    if len(s) > 700 or w > 500: return "HIGH"
    if _HIGH.search(s) or _CODE.search(s): return "HIGH"
    if s.count(" and ") >= 3 and len(s.split()) > 18: return "HIGH"
    return "LOW"
def _state_push(decision: dict):
    """Mirror the routing decision into voice_engine.STATE (no hard import).

    Kept optional: if voice_engine is absent (tests / standalone) this is a
    no-op. The core also mirrors via STATE['brain'] directly, but this lets a
    standalone brain_router caller still publish the decision.
    """
    try:
        ve = _load("voice_engine")
        if ve is not None and hasattr(ve, "STATE") and hasattr(ve, "_SLOCK"):
            with ve._SLOCK:  # type: ignore[attr-defined]
                ve.STATE["brain"] = dict(decision)  # type: ignore[attr-defined]
                ve.STATE["brain_revision"] = int(ve.STATE.get("brain_revision", 0)) + 1  # type: ignore[attr-defined]
                ve.STATE["revision"] = int(ve.STATE.get("revision", 0)) + 1  # type: ignore[attr-defined]
    except Exception:
        pass

def _prefrontal(text: str) -> dict:
    lang = _lang(text); w = _weight(text); comp = _complexity(text, w)
    stripped = str(text or "").strip()
    motor = bool(_MOTOR.search(stripped) and len(stripped.split()) < 18)
    if motor:
        lobe="motor_cortex"; reason="local OS intent -> 0-token bypass"; prov="local"; model="os_executor/bridge"
    elif comp=="HIGH":
        lobe="cerebrum"; reason="HIGH complexity / deep reasoning flagged"; prov="gemini"; model=CEREBRUM_MODEL
    else:
        lobe="prefrontal_cortex"; reason="LOW complexity -> fast chat pool (flash)"; prov="groq"; model=PREFRONTAL_MODEL
    return {"language":lang,"token_weight":w,"token_budget_soft":BUDGET_SOFT,"token_budget_hard":BUDGET_HARD,"complexity":comp,"lobe":lobe,"provider":prov,"model":model,"reason":reason,"motor_bypass":motor,"is_voice_transcript":False,"ts":time.strftime("%Y-%m-%d %H:%M:%S")}
def _hippo_recall(q: str, k: int = 3) -> list:
    out = []
    for name in ("jarvis_memory", "conversation_memory"):
        try:
            m = _load(name)
            if m is None or not hasattr(m, "recall"): continue
            for h in (m.recall(q, k=2) or []):
                t = str(h).strip()
                if t and t not in out: out.append(t)
        except Exception: continue
    try:
        if HIPPO_JSON.is_file():
            d = json.loads(HIPPO_JSON.read_text(encoding="utf-8"))
            ql = str(q or "").lower()
            for h in (d.get("habits") or [])[-12:]:
                t = str(h.get("text") or "").strip()
                if t and any(w in t.lower() for w in ql.split()[:4]):
                    if t not in out: out.append(t)
    except Exception: pass
    return out[: max(0, int(k))]

def _hippo_learn(user_text: str, assistant_text: str = "") -> dict:
    body = str(user_text or "").strip()
    if not body or len(body) > 8000: return {"ok": False}
    try:
        m = _load("conversation_memory")
        if m and hasattr(m, "learn_from_messages"):
            r = m.learn_from_messages([{"role": "user", "content": body}])
            if r.get("learned"): _diag(f"[HIPPOCAMPUS] learned {r.get('keys')}")
    except Exception as e: _diag(f"[HIPPOCAMPUS] vector skip: {e}")
    try:
        d = {}
        if HIPPO_JSON.is_file(): d = json.loads(HIPPO_JSON.read_text(encoding="utf-8"))
        habits = d.get("habits") or []
        habits.append({"text": body[:220], "reply": str(assistant_text or "")[:180],
                        "at": time.strftime("%Y-%m-%d %H:%M:%S"), "ts": time.time()})
        if len(habits) > 120: habits = habits[-120:]
        d["habits"] = habits; d["updated_at"] = time.time()
        HIPPO_JSON.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        _diag(f"[HIPPOCAMPUS] json skip: {e}")
        return {"ok": False, "error": str(e)}
    return {"ok": True}

def hippocampus_status() -> dict:
    cnt = 0
    try:
        if HIPPO_JSON.is_file():
            cnt = len((json.loads(HIPPO_JSON.read_text(encoding="utf-8"))).get("habits") or [])
    except Exception:
        pass
    vec = learned = 0
    try:
        m = _load("jarvis_memory")
        if m and hasattr(m, "status"):
            vec = int(m.status().get("count") or 0)
    except Exception:
        pass
    try:
        m2 = _load("conversation_memory")
        if m2 and hasattr(m2, "status"):
            learned = int(m2.status().get("count") or 0)
    except Exception:
        pass
    return {"json_habits": cnt, "vector_explicit": vec, "vector_learned": learned, "path": str(HIPPO_JSON)}

def route(text: str) -> dict:
    d = _prefrontal(text or "")
    d["hippocampus"] = _hippo_recall(str(text or ""), k=3)
    with _lock:
        global _last
        _last = dict(d); _last["text_preview"] = str(text or "")[:120]
        try: STATE_PATH.write_text(json.dumps(_last, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception: pass
    _diag(f"[BRAIN_ROUTER] {d['lobe']} / {d['complexity']} / {d['language']} w={d['token_weight']}")
    try: _state_push(dict(d) | {"text_preview": str(text or "")[:120]})
    except Exception: pass
    return dict(d) | {"text_preview": str(text or "")[:120]}

def last_route() -> dict:
    with _lock: return dict(_last)

def catalog() -> dict:
    try:
        mc = _load("model_catalog")
        if mc is None:
            return {"error": "model_catalog unavailable"}
        free = mc.catalog(force=False, free_only=True)
        # free_only collapses to free_*_pool; tuples (provider, id) in new catalog.
        raw = free.get("chat_pool") or free.get("free_chat_pool") or []
        counts = free.get("counts") or {}
        total = free.get("total_models") or 0

        def _mid(x):
            if isinstance(x, (list, tuple)) and len(x) >= 2:
                return str(x[1])
            if isinstance(x, dict):
                return str(x.get("id") or "")
            return str(x or "")

        pf = [m for m in raw if "flash" in _mid(m).lower() or "mini" in _mid(m).lower()][:12]
        cer = [m for m in raw if any(k in _mid(m).lower() for k in ("pro", "70b", "deepseek", "r1", "32b"))][:12]
        return {"prefrontal_models": pf, "cerebrum_models": cer,
                "broca_stt": ["whisper-large-v3-turbo (Groq cloud)", "faster-whisper local (cpu int8)"],
                "motor_cortex": ["local-bridge 127.0.0.1:7778 (allowlisted)", "cowork_tools os_executor"],
                "hippocampus": hippocampus_status(), "counts": counts, "total_free": total}
    except Exception as e:
        return {"error": str(e)}

ROUTING_SCHEMA = {"$schema":"https://json-schema.org/draft/2020-12/schema","title":"JARVIS Split-Brain Routing Decision","type":"object","required":["language","token_weight","complexity","lobe","provider","model","reason"],"properties":{"language":{"type":"string","enum":["en","hi","hinglish","ja","auto","blocked"]},"token_weight":{"type":"integer","minimum":0},"token_budget_soft":{"type":"integer"},"token_budget_hard":{"type":"integer"},"complexity":{"type":"string","enum":["LOW","HIGH"]},"lobe":{"type":"string","enum":["prefrontal_cortex","cerebrum","motor_cortex","broca_area","hippocampus"]},"provider":{"type":"string"},"model":{"type":"string"},"reason":{"type":"string"},"motor_bypass":{"type":"boolean"},"hippocampus":{"type":"array","items":{"type":"string"}},"text_preview":{"type":"string"},"ts":{"type":"string"}}}

COGNITIVE_LOOP = {"title":"JARVIS Human-Brain Cognitive Loop","version":"1.0","loop":[{"step":1,"region":"Broca's Area","job":"STT mic->VAD->Whisper->clean text","cost":"voice only"},{"step":2,"region":"Hippocampus","job":"Recall vector+JSON ->3 snippets","cost":"0 tokens"},{"step":3,"region":"Prefrontal Cortex","job":"Route language+weight+complexity->lobe","cost":"~0 tokens"},{"step":4,"region":"Branch","job":"motor_cortex->0-token bridge | cerebrum->Pro deep | else->Groq+Gemini race","cost":"branch"},{"step":5,"region":"Cerebrum/Chat","job":"LLM via _brain_raw free_pool walk (loses no key, timeouts)","cost":"soft->hard budget"},{"step":6,"region":"Hippocampus","job":"Learn selective+JSON habit (self-learns tomorrow)","cost":"0 tokens"},{"step":7,"region":"Motor/TTS","job":"Speak edge-tts Madhur/Keita/Ryan+SAPI fallback","cost":"no key"}],"state_keys":["messages (short)","facts (long explicit)","pinned (fixed)","chat_log (screen)","settings","llm_models catalog","hippocampus.habits[]"],"storage":{"short_memory":"conversation_store.py SQLite WAL surface=jarvis/kamisensei","long_memory_explicit":"jarvis_memory.py Chroma jarvis_memory","long_memory_learned":"conversation_memory.py Chroma jarvis_learned_memory","fixed_memory":"artifacts/brain/hippocampus.json pinned habits","chat_log":"artifacts/brain/last_route.json+_history ring(8)","settings":"localStorage jarvis-settings+.dev.vars","llm_models":"model_catalog.py TTL600s free_pool only"},"json_schema_ref":"ROUTING_SCHEMA"}

def describe() -> str:
    r = _last or {}
    if not r: return "Brain router idle — no route yet. I am ready, Sir."
    return ("Prefrontal -> %(lobe)s (%(complexity)s, %(language)s, weight %(token_weight)s) via %(provider)s:%(model)s — %(reason)s" % r)

