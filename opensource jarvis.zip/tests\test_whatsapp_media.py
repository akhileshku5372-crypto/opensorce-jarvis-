"""Regression tests for the WhatsApp media resolver (spoken hint -> ONE real file).

AGENTS.md: a path or a filename is never taken straight from raw speech. These
tests pin the rules that make that true: the folder must really exist, the file
must live INSIDE it, ambiguity is refused rather than guessed, and a kind
mismatch is reported instead of silently sending something else.

Run:  node run_py.cjs -m unittest tests.test_whatsapp_media
"""
import importlib.util
import shutil
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


WM = _load("whatsapp_media")


class FolderResolutionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="wa_media_"))
        self._real_home = WM._home
        WM._home = lambda: self.tmp
        self.addCleanup(self._restore)

    def _restore(self):
        WM._home = self._real_home

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_empty_hint_uses_the_default_drop_folder(self):
        folder, why = WM.resolve_folder("")
        self.assertEqual(why, "")
        self.assertEqual(folder, self.tmp / "Desktop" / "JARVIS-Send")
        self.assertTrue(folder.is_dir(), "the drop folder is created on demand")

    def test_a_bare_name_is_found_under_the_known_roots(self):
        (self.tmp / "Downloads" / "wa-media").mkdir(parents=True)
        folder, why = WM.resolve_folder("wa-media")
        self.assertEqual(why, "")
        self.assertEqual(folder, self.tmp / "Downloads" / "wa-media")

    def test_a_missing_name_is_reported_not_guessed(self):
        folder, why = WM.resolve_folder("kuch-bhi-nahi")
        self.assertIsNone(folder)
        self.assertIn("nahi mila", why)

    def test_traversal_and_unc_are_refused(self):
        for bad in ("..", "a/../../b", "\\\\server\\share"):
            with self.subTest(bad=bad):
                folder, why = WM.resolve_folder(bad)
                self.assertIsNone(folder)
                self.assertTrue(why)

    def test_an_existing_path_with_separators_is_accepted(self):
        (self.tmp / "Pictures" / "shots").mkdir(parents=True)
        folder, why = WM.resolve_folder(str(self.tmp / "Pictures" / "shots"))
        self.assertEqual(why, "")
        self.assertEqual(folder.name, "shots")


class FileResolutionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="wa_media_"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    def _file(self, name, size=10, age=0.0):
        p = self.tmp / name
        p.write_bytes(b"j" * size)
        return p

    def test_newest_matching_file_is_picked_when_no_name_is_given(self):
        old = self._file("old.png")
        new = self._file("new.png")
        past = time.time() - 500
        import os
        os.utime(old, (past, past))
        pick, why = WM.resolve_file("", self.tmp, "photo")
        self.assertEqual(why, "")
        self.assertEqual(pick, new)

    def test_a_kind_with_no_matching_file_is_reported(self):
        self._file("song.mp3")
        pick, why = WM.resolve_file("", self.tmp, "photo")
        self.assertIsNone(pick)
        self.assertIn("photo", why)

    def test_document_kind_accepts_any_file(self):
        self._file("notes.txt")
        pick, why = WM.resolve_file("", self.tmp, "document")
        self.assertEqual(why, "")
        self.assertEqual(pick.name, "notes.txt")

    def test_an_exact_name_wins_over_kind_guessing(self):
        self._file("report.pdf")
        pick, why = WM.resolve_file("report.pdf", self.tmp, "")
        self.assertEqual(why, "")
        self.assertEqual(pick.name, "report.pdf")

    def test_a_stem_matches_the_full_file(self):
        self._file("report.pdf")
        pick, why = WM.resolve_file("report", self.tmp, "")
        self.assertEqual(why, "")
        self.assertEqual(pick.name, "report.pdf")

    def test_an_ambiguous_name_is_refused_not_guessed(self):
        self._file("report1.pdf")
        self._file("report2.pdf")
        pick, why = WM.resolve_file("report", self.tmp, "")
        self.assertIsNone(pick)
        self.assertIn("kaun si", why)

    def test_a_missing_name_is_reported(self):
        self._file("other.png")
        pick, why = WM.resolve_file("nope.png", self.tmp, "photo")
        self.assertIsNone(pick)
        self.assertIn("nahi mili", why)

    def test_a_name_is_never_a_path(self):
        pick, why = WM.resolve_file("..\\evil.png", self.tmp, "")
        self.assertIsNone(pick)
        self.assertTrue(why)

    def test_a_kind_mismatch_is_reported_not_sent(self):
        self._file("report.pdf")
        pick, why = WM.resolve_file("report.pdf", self.tmp, "photo")
        self.assertIsNone(pick)
        self.assertIn("document", why)
        self.assertIn("photo", why)

    def test_an_empty_file_is_refused(self):
        self._file("blank.png", size=0)
        pick, why = WM.resolve_file("", self.tmp, "photo")
        self.assertIsNone(pick)
        self.assertTrue(why)

    def test_the_pick_must_stay_inside_the_folder(self):
        # A symlink pointing OUTSIDE the folder must never be sent.
        inside = self.tmp / "inside"
        inside.mkdir()
        outside = self.tmp / "outside.txt"
        outside.write_bytes(b"x")
        link = inside / "link.png"
        try:
            link.symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest("symlinks not supported here")
        pick, why = WM.resolve_file("link.png", inside, "photo")
        self.assertIsNone(pick, "a file outside the folder must never be picked")
        self.assertTrue(why)


class ClassifyAndClipboardTest(unittest.TestCase):
    def test_kind_words(self):
        for word, kind in (("photo", "photo"), ("Screenshot", "photo"),
                           ("video", "video"), ("gana", "audio"),
                           ("voice", "audio"), ("pdf", "document"),
                           ("file", "document"), ("kuch", "")):
            with self.subTest(word=word):
                self.assertEqual(WM.kind_of_word(word), kind)

    def test_classify_by_extension(self):
        for name, kind in (("a.png", "photo"), ("b.MP4", "video"),
                           ("c.mp3", "audio"), ("d.pdf", "document"),
                           ("e.xyz", "document")):
            with self.subTest(name=name):
                self.assertEqual(WM.classify(name), kind)

    def test_hdrop_bytes_shape(self):
        import struct
        data = WM.hdrop_bytes(r"C:\tmp\a.png")
        header = struct.unpack("IiiII", data[:20])
        self.assertEqual(header, (20, 0, 0, 0, 1))
        self.assertIn("a.png".encode("utf-16-le"), data)
        self.assertEqual(data[-2:], b"\0\0", "double NUL terminator")

    def test_copy_file_refuses_a_missing_file(self):
        self.assertFalse(WM.copy_file(r"C:\definitely\not\here.png"))


if __name__ == "__main__":
    unittest.main()
