"""Data Forge: real structured dataset generation for JARVIS (Phase 6.2).

Produces genuine `.csv`, `.jsonl` and `.parquet` datasets into
`artifacts/datasets/`, and answers SQL over them with DuckDB.

Honesty rules (the previous version broke two of them)
------------------------------------------------------
1. **No silent format downgrade.** The old `create_dataset()` accepted "parquet"
   and quietly wrote JSONL instead. A request for parquet now either writes a
   real parquet file or fails with the reason (duckdb missing).
2. **No import side effects.** The old module seeded a dataset at import time,
   so merely importing it manufactured evidence for the capability card. Nothing
   here runs on import; a dataset exists only because something asked for one.
3. **Real telemetry.** `telemetry_dataset()` writes the machine's actual CPU /
   RAM / disk / battery numbers, not invented sample rows.

DuckDB is optional: without it CSV and JSONL still work and `status()` reports
`parquet: false` with the install command, so the capability card can say exactly
what is missing.
"""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATASET_DIR = ROOT / "artifacts" / "datasets"
DATASET_EXTS = (".csv", ".tsv", ".parquet", ".jsonl")
FORMAT_NOTE = ("install duckdb for .parquet support: "
               "node run_py.cjs -m pip install duckdb")


def _duckdb():
    """The DuckDB module, or None when it is not installed."""
    try:
        import duckdb                     # type: ignore
        return duckdb
    except Exception:
        return None


def engine() -> str:
    return "duckdb" if _duckdb() is not None else "stdlib"


def ensure_dir() -> Path:
    DATASET_DIR.mkdir(parents=True, exist_ok=True)
    return DATASET_DIR


def _safe_name(name: str) -> str:
    clean = "".join(c for c in str(name or "") if c.isalnum() or c in ("-", "_"))
    return clean.strip("_") or "dataset"


def _infer_type(value):
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "BIGINT"
    if isinstance(value, float):
        return "DOUBLE"
    return "VARCHAR"


def _write_csv(rows: list, target: Path, delimiter: str = ",") -> int:
    keys = sorted({str(k) for row in rows for k in row})
    with open(target, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, delimiter=delimiter,
                                extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in keys})
    return len(keys)


def _write_parquet(rows: list, target: Path) -> int:
    duckdb = _duckdb()
    if duckdb is None:
        raise RuntimeError(FORMAT_NOTE)
    keys = sorted({str(k) for row in rows for k in row})
    columns = []
    for key in keys:
        sample = next((row.get(key) for row in rows if row.get(key) not in
                       (None, "")), None)
        # CAST needs an alias: an un-aliased CAST names the parquet column after
        # the expression ("CAST(cpu AS DOUBLE)"), which breaks later SELECTs.
        columns.append('CAST("%s" AS %s) AS "%s"' % (key, _infer_type(sample),
                                                     key))
    temp = target.with_suffix(".csv.tmp")
    _write_csv(rows, temp)
    con = duckdb.connect()
    try:
        con.execute("COPY (SELECT %s FROM read_csv_auto('%s', header=true)) "
                    "TO '%s' (FORMAT PARQUET)"
                    % (", ".join(columns), temp.as_posix(), target.as_posix()))
    finally:
        con.close()
    try:
        temp.unlink()
    except OSError:
        pass
    return len(columns)


def create_dataset(rows: list, name: str = "dataset", fmt: str = "jsonl") -> dict:
    """Write rows as a real structured dataset. Never downgrades the format."""
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        return {"ok": False, "error": "rows must not be empty"}
    fmt = str(fmt or "jsonl").lower().lstrip(".")
    if fmt not in ("csv", "tsv", "jsonl", "parquet"):
        return {"ok": False, "error": "unsupported format %r (use csv, tsv, "
                                       "jsonl or parquet)" % fmt}
    ensure_dir()
    stamp = time.strftime("%Y%m%d_%H%M%S")
    target = DATASET_DIR / ("%s_%s.%s" % (_safe_name(name), stamp, fmt))
    try:
        if fmt == "jsonl":
            with open(target, "w", encoding="utf-8") as handle:
                for row in rows:
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            columns = len({str(k) for row in rows for k in row})
        elif fmt == "csv":
            columns = _write_csv(rows, target)
        elif fmt == "tsv":
            columns = _write_csv(rows, target, delimiter="\t")
        else:
            columns = _write_parquet(rows, target)
    except Exception as exc:
        try:
            if target.exists():
                target.unlink()
        except OSError:
            pass
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc),
                "format": fmt}
    return {"ok": True, "path": str(target), "name": target.name,
            "rows": len(rows), "columns": columns, "format": fmt,
            "engine": engine(), "size": target.stat().st_size,
            "created": time.time()}


def _fetch_records(con, sql: str) -> list:
    """Rows as dicts. Uses fetchall + description, NOT fetchdf, because
    fetchdf() requires pandas - an optional dependency we do not need."""
    cursor = con.execute(sql)
    columns = [str(info[0]) for info in (cursor.description or [])]
    return [dict(zip(columns, list(row))) for row in cursor.fetchall()]


def read_rows(path: str, limit: int = 10000) -> dict:
    """Read a dataset back as rows. Parquet needs DuckDB; CSV/JSONL do not."""
    target = Path(path)
    if not target.is_file():
        return {"ok": False, "error": "no such file: %s" % target}
    suffix = target.suffix.lower()
    if suffix == ".parquet":
        duckdb = _duckdb()
        if duckdb is None:
            return {"ok": False, "error": FORMAT_NOTE}
        try:
            con = duckdb.connect()
            try:
                rows = _fetch_records(
                    con, "SELECT * FROM read_parquet('%s') LIMIT %d"
                         % (target.as_posix(), int(limit)))
            finally:
                con.close()
            return {"ok": True, "rows": rows, "count": len(rows), "format": "parquet"}
        except Exception as exc:
            return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    try:
        if suffix in (".jsonl", ".ndjson"):
            rows = [json.loads(line) for line in
                    target.read_text(encoding="utf-8").splitlines() if line.strip()]
        elif suffix == ".json":
            rows = json.loads(target.read_text(encoding="utf-8"))
            if isinstance(rows, dict):
                rows = [rows]
        else:
            delimiter = "\t" if suffix == ".tsv" else ","
            with open(target, "r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter=delimiter))
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    rows = rows[:int(limit)]
    return {"ok": True, "rows": rows, "count": len(rows), "format": suffix.lstrip(".")}


def from_file(path: str, name: str = "", fmt: str = "") -> dict:
    """Convert a real file into a clean dataset. Never invents rows."""
    read = read_rows(path)
    if not read.get("ok"):
        return read
    source = Path(path).name
    target_name = name or Path(path).stem or "dataset"
    target_fmt = fmt or Path(path).suffix.lower().lstrip(".")
    if target_fmt not in ("csv", "tsv", "jsonl", "parquet"):
        target_fmt = "csv"
    out = create_dataset(read["rows"], name=target_name, fmt=target_fmt)
    if out.get("ok"):
        out["source"] = str(path)
        out["source_rows"] = read["count"]
    return out


def telemetry_dataset() -> dict:
    """A dataset built from this machine's REAL telemetry snapshot."""
    try:
        import telemetry as _telemetry
    except ImportError:                                  # pragma: no cover
        try:
            from background import telemetry as _telemetry
        except Exception:
            return {"ok": False, "error": "telemetry module unavailable"}
    stamp = time.time()
    rows = []

    def add(section, key, value, unit=""):
        if isinstance(value, (int, float, str)) and value != "":
            rows.append({"timestamp": round(stamp, 3), "section": section,
                         "metric": key, "value": value, "unit": unit})

    try:
        cpu = _telemetry.cpu() or {}
        add("cpu", "cpu_percent", cpu.get("percent"), "%")
        per_core = cpu.get("cores") or []
        add("cpu", "cpu_core_count", len(per_core), "count")
        for idx, value in enumerate(per_core):
            add("cpu", "cpu_core_%d" % idx, value, "%")
        memory = _telemetry.memory() or {}
        add("memory", "ram_used_percent", memory.get("percent"), "%")
        add("memory", "ram_used_gb", memory.get("used_gb"), "GB")
        add("memory", "ram_total_gb", memory.get("total_gb"), "GB")
        for disk in _telemetry.disks() or []:
            add("disk", "free_gb:%s" % disk.get("drive", "?"),
                disk.get("free_gb"), "GB")
            add("disk", "used_percent:%s" % disk.get("drive", "?"),
                disk.get("percent"), "%")
        batt = _telemetry.battery() or {}
        if batt.get("available"):
            add("battery", "charge_percent", batt.get("percent"), "%")
        else:
            # Honest: no battery means no row, plus one row that says so.
            rows.append({"timestamp": round(stamp, 3), "section": "battery",
                         "metric": "charge_percent", "value": "unavailable",
                         "unit": "%"})
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    if not rows:
        return {"ok": False,
                "error": "telemetry returned no numeric metrics to store"}
    out = create_dataset(rows, name="system_telemetry", fmt="parquet")
    if not out.get("ok"):
        out = create_dataset(rows, name="system_telemetry", fmt="csv")
    if out.get("ok"):
        out["rows_sampled"] = len(rows)
    return out


def datasets() -> list:
    """Every real dataset file currently on disk, newest first."""
    ensure_dir()
    rows = []
    try:
        files = [p for p in DATASET_DIR.iterdir()
                 if p.is_file() and p.suffix.lower() in DATASET_EXTS]
    except Exception:
        return rows
    for path in sorted(files, key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            stat = path.stat()
        except OSError:
            continue
        rows.append({"name": path.name, "path": str(path), "bytes": stat.st_size,
                     "mtime": stat.st_mtime,
                     "format": path.suffix.lower().lstrip(".")})
    return rows


def query(sql: str, limit: int = 50) -> dict:
    """Run a read-only SELECT over the produced datasets (DuckDB required)."""
    duckdb = _duckdb()
    statement = str(sql or "").strip()
    if duckdb is None:
        return {"ok": False, "error": FORMAT_NOTE + " (SQL needs DuckDB)"}
    if not statement:
        return {"ok": False, "error": "no SQL given"}
    lowered = statement.lower()
    if not lowered.startswith(("select", "with", "describe", "pragma")):
        return {"ok": False,
                "error": "only read-only SELECT/WITH is allowed here"}
    if any(word in lowered for word in ("insert ", "update ", "delete ",
                                       "drop ", "create ", "attach ")):
        return {"ok": False, "error": "only read-only SELECT/WITH is allowed here"}
    ensure_dir()
    files = [p for p in DATASET_DIR.iterdir()
             if p.is_file() and p.suffix.lower() in DATASET_EXTS] \
        if DATASET_DIR.is_dir() else []
    if not files:
        return {"ok": False,
                "error": "no datasets to query yet - create one first"}
    con = duckdb.connect()
    try:
        rows = _fetch_records(con, statement)
        columns = list(rows[0].keys()) if rows else []
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    finally:
        con.close()
    return {"ok": True, "rows": rows[:int(limit)], "count": len(rows[:int(limit)]),
            "columns": columns, "scanned_files": len(files)}


def status() -> dict:
    """Honest state for the capability card and the /datasets endpoints."""
    found = datasets()
    duck = _duckdb()
    info = {
        "engine": engine(),
        "parquet": duck is not None,
        "dir": str(DATASET_DIR),
        "datasets": found,
        "count": len(found),
        "formats": sorted({row["format"] for row in found}),
    }
    if duck is None:
        info["note"] = FORMAT_NOTE
    elif not found:
        info["note"] = ("engine ready, but no dataset has been produced yet - "
                        "run telemetry_dataset() or from_file()")
    else:
        info["note"] = ("%d real dataset(s) in %s"
                        % (len(found), DATASET_DIR))
    return info


# ── registry tool wrappers (real ToolRegistry, see plugin.py) ──────────────


def _tool_data_forge_status(args=None):
    return status()


def _tool_data_forge_create(args=None):
    args = args or {}
    if args.get("path"):
        return from_file(args["path"], args.get("name", ""),
                         args.get("format", ""))
    rows = args.get("rows")
    if isinstance(rows, str):
        try:
            rows = json.loads(rows)
        except Exception:
            return {"ok": False, "error": "rows must be a JSON array of objects"}
    if not isinstance(rows, list):
        return {"ok": False,
                "error": "give either a real file path or a rows array"}
    return create_dataset(rows, args.get("name", "dataset"),
                          args.get("format", "jsonl"))


def _tool_data_forge_telemetry(args=None):
    return telemetry_dataset()


def _tool_data_forge_query(args=None):
    args = args or {}
    return query(args.get("sql", ""), args.get("limit", 50))