"""Selective long-term memory extracted FROM conversations.

This is deliberately separate from ``conversation_store`` (the transcript) and
from ``jarvis_memory`` (what the user explicitly asked to remember by voice).
Three different things, three different rules:

* transcript      - everything said, forgotten on clear
* explicit memory - only what the user said "remember" to (jarvis_memory.py)
* learned memory  - stable facts/preferences learned from normal chatting (here)

Why this file exists
--------------------
Storing every message as "memory" is the classic ChatGPT-memory failure: the
store fills with "ok", "thanks", one-off questions and stale facts, retrieval
gets worse as it grows, and a correction never replaces the old claim. So this
module is conservative on the way IN and strict about superseding:

* Only messages matching an explicit, auditable pattern become memories. Each
  carries the sentence that produced it, so nothing is invented.
* A memory has a ``key`` (normalized subject). Writing the same key again
  supersedes the old value instead of adding a contradictory duplicate.
* Nothing is written from assistant turns, so the model cannot memorize itself.

Uses the existing ChromaDB infrastructure, but with its OWN collection so
learned memory can be listed, cleared and audited independently of manually
remembered facts.
"""

from __future__ import annotations

import re
import time
import uuid
# Patterns are intentionally few and explicit. Each returns (key, value).
# The value is a cleaned, self-contained statement - not the raw utterance.
def _sentence(text: str) -> str:
    """Trim, upper-case only the first letter, and end with a period."""
    body = str(text or "").strip().rstrip(".!?")
    if not body:
        return ""
    return body[0].upper() + body[1:] + "."


_PATTERNS = [
    # "my name is X" first, then the weaker "i am X" - order matters because
    # the generic pattern would otherwise match the "my" in "my name is".
    (re.compile(r"\bmy name is\s+([A-Za-z][\w'.-]{1,30})\b", re.I),
     lambda m: ("user.name", "User's name is %s." % m.group(1))),
    # "call me X" is safe, but bare "main X" is NOT: in Hinglish "main yaha
    # rehta hun" / "main Delhi se hu" would otherwise capture "yaha"/"Delhi" as
    # the user's NAME. It now requires an explicit naming verb, and the
    # location forms are captured by the residence pattern below instead.
    (re.compile(r"\bcall me\s+([A-Za-z][\w'.-]{1,30})\b", re.I),
     lambda m: ("user.name", "User's name is %s." % m.group(1))),
    (re.compile(r"\bmain\s+([A-Za-z][\w'.-]{1,30})\s+hu\b", re.I),
     lambda m: ("user.name", "User's name is %s." % m.group(1))),
    # "I prefer / I like / I love X"
    (re.compile(r"\b(?:i\s+(?:prefer|like|love|favou?r)\s+)([^.,!?\n]{3,120})", re.I),
     lambda m: ("user.likes", "User prefers %s." % m.group(1).strip())),
    # "I don't like / I hate X"
    (re.compile(r"\b(?:i\s+(?:don'?t like|do not like|hate|dislike|avoid)\s+)([^.,!?\n]{3,120})", re.I),
     lambda m: ("user.dislikes", "User dislikes %s." % m.group(1).strip())),
    # "I live in X" / "main X mein rehta hun" / "I'm based in X". A location is
    # its own durable fact, so it needs its own key to supersede cleanly - and
    # "yaha" (here) is meaningless once stored, so it is rejected.
    (re.compile(r"\b(?:i\s+(?:live|reside|stay)\s+in|i'?m\s+based\s+in|i\s+moved\s+to)\s+([^.,!?\n]{2,80})", re.I),
     lambda m: ("user.location", "User lives in %s." % m.group(1).strip())),
    (re.compile(r"\bmain\s+(?!yaha\b|yahan\b|idhar\b|yahin\b)([A-Za-z][\w'.-]{1,40})\s+(?:mein|in)\s+rehta\s+hu?n?\b", re.I),
     lambda m: ("user.location", "User lives in %s." % m.group(1).strip())),
    # "my <thing> is X" -> a durable attribute (city, timezone, job, stack...).
    # "name" is excluded: it is already captured by the name pattern above, and
    # allowing it here would swallow the rest of the sentence into the value.
    (re.compile(r"\bmy\s+(?!name\b)([a-z][\w]{0,20}(?:\s+[a-z][\w]{0,20})?)\s+is\s+([^.,!?\n]{2,120})", re.I),
     lambda m: ("user.%s" % re.sub(r"\s+", "_", m.group(1).strip().lower()),
                "User's %s is %s." % (m.group(1).strip(), m.group(2).strip()))),
    # "remember that X" typed into chat rather than spoken. Only the first
    # character is touched, so "I work in Mumbai" keeps its internal capitals.
    (re.compile(r"\b(?:remember(?: that)?|note that|keep in mind(?: that)?)\s*:?\s*([^.,!?\n]{4,160})", re.I),
     lambda m: ("user.note", _sentence(m.group(1)))),
]

# Pure filler, with nothing else in the message. Anchored so a real fact that
# merely STARTS with a greeting ("Hi, my name is Prateek") is still learnable.
_JUNK = re.compile(r"^\s*(?:ok|okay|thanks|thank you|yes|no|sure|hi|hello|hey|good\s+morning|good\s+evening|bye|got it|noted)\b[\s.!?]*$", re.I)


def _collection():
    """Lazily open the learned-memory collection (None when ChromaDB absent)."""
    try:
        import chromadb
        from chromadb.config import Settings
        _paths.jarvis_memory_dir().mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(
            path=str(_paths.jarvis_memory_dir()),
            settings=Settings(anonymized_telemetry=False))
        return client.get_or_create_collection(
            name=COLLECTION, metadata={"hnsw:space": "cosine"})
    except Exception:
        return None


def extract(text: str, role: str = "user"):
    """Pull durable facts out of ONE message.

    Returns a list of ``{"key","text"}``. Empty for assistant turns, junk, and
    anything matching no pattern - the default is "do not remember".
    """
    if str(role or "user").lower() != "user":
        return []
    body = " ".join(str(text or "").split())
    if len(body) < MIN_TEXT or _JUNK.match(body):
        return []
    found, seen = [], set()
    for pattern, build in _PATTERNS:
        match = pattern.search(body)
        if not match:
            continue
        try:
            key, statement = build(match)
        except Exception:
            continue
        if key in seen or not statement or _JUNK.match(statement):
            continue
        seen.add(key)
        found.append({"key": key, "text": statement[:MAX_TEXT]})
    return found


def supersede(key: str):
    """Ids of existing memories sharing `key` - these get replaced."""
    col = _collection()
    if col is None or not key:
        return []
    try:
        rows = col.get(include=["metadatas"]) or {}
        ids, metas = rows.get("ids") or [], rows.get("metadatas") or []
        return [i for i, m in zip(ids, metas)
                if str((m or {}).get("key", "")) == key]
    except Exception:
        return []


def remember(key: str, text: str, source: str = "") -> dict:
    """Store one learned memory, replacing any earlier value for the same key."""
    statement = " ".join(str(text or "").split())[:MAX_TEXT]
    if not key or not statement:
        return {"ok": False, "error": "key and text required"}
    col = _collection()
    if col is None:
        return {"ok": False, "error": "memory_store_unavailable"}
    # Quota guard: refuse the write loudly instead of letting the data root
    # grow past its ceiling. Reported, never silent.
    if not _paths.guard_write(len(statement) * 4):
        return {"ok": False, "error": "storage_quota_reached",
                "detail": _paths.quota_status()}
    try:
        stale = supersede(key)
        if stale:
            col.delete(ids=stale)
        col.add(ids=[uuid.uuid4().hex], documents=[statement],
                metadatas=[{"key": key, "source": str(source)[:200],
                            "created_at": time.strftime("%Y-%m-%d %H:%M")}])
        return {"ok": True, "key": key, "text": statement, "superseded": len(stale)}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def learn_from_messages(messages) -> dict:
    """Extract and store from a batch of transcript rows.

    `messages` is an iterable of dicts with `role`/`content`. Returns counts so
    the caller can report honestly what was learned instead of pretending every
    message became a memory.
    """
    learned, superseded = [], 0
    for row in messages or []:
        if not isinstance(row, dict):
            continue
        for item in extract(row.get("content"), row.get("role", "user")):
            res = remember(item["key"], item["text"], source="conversation")
            if res.get("ok"):
                learned.append(item["key"])
                superseded += int(res.get("superseded") or 0)
    return {"ok": True, "learned": len(learned), "superseded": superseded,
            "keys": learned}


def recall(query: str, k: int = 4) -> list:
    """Top-k relevant learned memories for prompt context (never raises)."""
    body = str(query or "").strip()
    if not body:
        return []
    col = _collection()
    if col is None:
        return []
    try:
        if (col.count() or 0) == 0:
            return []
        res = col.query(query_texts=[body], n_results=max(1, min(int(k), 8)))
        return [str(d) for d in ((res.get("documents") or [[]])[0]) if d]
    except Exception:
        return []


def all_memories() -> list:
    """Every learned memory, newest first."""
    col = _collection()
    if col is None:
        return []
    try:
        rows = col.get(include=["documents", "metadatas"]) or {}
        docs = rows.get("documents") or []
        metas = rows.get("metadatas") or [{}] * len(docs)
        ids = rows.get("ids") or [""] * len(docs)
        return [{"id": i, "text": str(d or ""), "key": str((m or {}).get("key", "")),
                 "created_at": str((m or {}).get("created_at", ""))}
                for i, d, m in zip(ids, docs, metas)][::-1]
    except Exception:
        return []


def forget(key: str = "", text: str = "") -> dict:
    """Remove learned memories by key or by substring."""
    col = _collection()
    if col is None:
        return {"ok": False, "error": "memory_store_unavailable"}
    try:
        rows = col.get(include=["documents", "metadatas"]) or {}
        docs, metas = rows.get("documents") or [], rows.get("metadatas") or []
        ids, needle = rows.get("ids") or [], str(text or "").strip().lower()
        targets = [i for i, d, m in zip(ids, docs, metas)
                   if (key and str((m or {}).get("key", "")) == key)
                   or (needle and needle in str(d or "").lower())]
        if not targets:
            return {"ok": True, "deleted": 0}
        col.delete(ids=targets)
        return {"ok": True, "deleted": len(targets)}
    except Exception as exc:
        return {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}


def status() -> dict:
    col = _collection()
    count = 0
    if col is not None:
        try:
            count = int(col.count() or 0)
        except Exception:
            count = 0
    return {"available": col is not None, "count": count,
            "collection": COLLECTION, "dir": str(_paths.jarvis_memory_dir())}
    return found


def analyze() -> dict:
    """Summarize the learned-memory store for the user (ChatGPT-style recall).

    "What do you remember about me?" Groups every memory by its key, counts the
    distinct facts/topics, and returns a ready-to-speak one-liner. Read-only:
    it never mutates the store, so analyze can never lose a memory.
    """
    col = _collection()
    if col is not None:
        rows = col.get(include=["documents", "metadatas"]) or {}
        docs, metas = rows.get("documents") or [], rows.get("metadatas") or []
        groups, stamps = {}, []
        for d, m in zip(docs, metas):
            md = m or {}
            key = str(md.get("key", "general")).strip() or "general"
            groups.setdefault(key, []).append(str(d or "").strip())
            ts = str(md.get("created_at", "")).strip()
            if ts:
                stamps.append(ts)
        total = sum(len(v) for v in groups.values())
        if total == 0:
            return {"ok": True, "count": 0, "topics": 0, "groups": {},
                    "oldest": "", "newest": "",
                    "summary": "I haven't learned any lasting facts yet, Sir."}
        stamps.sort()
        pretty = ", ".join("%s (%d)" % (k, len(v))
                           for k, v in sorted(groups.items()))
        return {"ok": True, "count": total, "topics": len(groups),
                "groups": groups,
                "oldest": stamps[0] if stamps else "",
                "newest": stamps[-1] if stamps else "",
                "summary": "I remember %d %s across %d %s: %s."
                % (total, "fact" if total == 1 else "facts",
                   len(groups), "topic" if len(groups) == 1 else "topics", pretty)}
    if col is None:
        return {"ok": False, "error": "memory_store_unavailable"}


try:
    import storage_paths as _paths
except ImportError:  # pragma: no cover
    from background import storage_paths as _paths

COLLECTION = "jarvis_learned_memory"
MAX_TEXT = 400
MIN_TEXT = 4