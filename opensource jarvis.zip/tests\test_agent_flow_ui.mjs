// Live guard for Co-work -> Agents (the n8n-style flow builder).
//
// Why this exists: public/static/agent-flow.js once had a missing closing brace
// after renderList(). `node --check` passed and the file parsed, but every
// function from renderNodes() onward became a *block-scoped* declaration
// inside renderList's body under 'use strict'. The IIFE therefore died with
// "ReferenceError: loadAgents is not defined" and the whole builder was dead
// while every syntax check stayed green.
//
// So this test asserts the real runtime contract, not the syntax:
//   1. the module IIFE completed and exported window.JarvisAgentFlow,
//   2. the exported surface is made of live functions,
//   3. the Agents tab paints a real canvas populated from the live catalog,
//   4. creating an agent through the UI works against the real core,
//   5. the console stays clean throughout.
//
// Run: node tests/test_agent_flow_ui.mjs
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const artifactsDir = path.join(root, 'artifacts', 'ui-audit', 'agent-flow')
mkdirSync(artifactsDir, { recursive: true })

const UI = 'http://127.0.0.1:7777/'
// Pick a free port instead of a hardcoded one: a stale headless Chrome from an
// aborted run keeps holding the port and silently starves /json/new.
const PORT = 9234 + (process.pid % 400)
const wait = (ms) => new Promise((r) => setTimeout(r, ms))

let passed = 0
let failed = 0
const lines = []
// Write the report with fs.writeFileSync on every assertion and keep
// process.exit() out of the way: stdout redirected to a file is buffered, and
// process.exit() discards that buffer, which silently loses the whole report.
const REPORT = process.argv[2] || path.join(tmpdir(), 'agent-flow-ui-report.txt')
const flush = () => writeFileSync(REPORT, lines.join('\n') + '\n', 'utf8')
const say = (m) => { lines.push(m); console.log(m); flush() }
const ok = (m) => { passed++; say('  ok   ' + m) }
const bad = (m) => { failed++; say('  FAIL ' + m) }

const IGNORE = [/favicon/i, /\[vite\]/i, /React DevTools/i, /net::ERR_/i]
const noise = []
const record = (kind, text) => {
  if (IGNORE.some((re) => re.test(text))) return
  noise.push(kind + ' ' + text)
}

const profile = mkdtempSync(path.join(tmpdir(), 'jarvis-aflow-'))
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
  '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
  '--window-size=1600,1000', 'about:blank'
], { stdio: ['ignore', 'ignore', 'pipe'] })

const cleanup = () => {
  try { if (chrome.pid) spawnSync('taskkill', ['/PID', String(chrome.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {}
  try { rmSync(profile, { recursive: true, force: true }) } catch {}
}
// Watchdog must NOT be unref()'d: an unref'd timer does not keep the loop
// alive, so a harness stuck in connect() would never be reaped and would hang
// the whole suite with no report written at all.
const watchdog = setTimeout(() => {
  say('  FAIL harness timed out after 150s (stuck before first assertion)')
  flush()
  cleanup()
  process.exit(1)
}, 150000)

async function connect() {
  for (let i = 0; i < 40; i++) {
    try {
      // AbortSignal.timeout is required: a bare fetch() to a dead port hangs for
      // minutes instead of failing, so this retry loop never advances and the
      // harness never writes a report.
      const res = await fetch(`http://127.0.0.1:${PORT}/json/new?${encodeURIComponent(UI)}`, {
        method: 'PUT',
        signal: AbortSignal.timeout(3000)
      })
      if (res.ok) {
        const page = await res.json()
        if (page?.webSocketDebuggerUrl) return page.webSocketDebuggerUrl
      }
    } catch {}
    await wait(500)
  }
  throw new Error('CDP did not come up on port ' + PORT)
}

try {
  const ws = new WebSocket(await connect())
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', reject)
  })
  say('  ..   CDP websocket connected on port ' + PORT)
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails
      record('EXC', d?.exception?.description || d?.text || '?')
    }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      record('console.error', (m.params.args || []).map((a) => a.value ?? a.description ?? '').join(' '))
    }
    if (m.method === 'Log.entryAdded' && m.params.entry.level === 'error') {
      record('ERR', m.params.entry.text)
    }
  })
  const send = (method, params = {}) => new Promise((resolve) => {
    const mid = ++id
    pending.set(mid, resolve)
    ws.send(JSON.stringify({ id: mid, method, params }))
  })
  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    if (r.result?.exceptionDetails) {
      const d = r.result.exceptionDetails
      record('EXC', d.exception?.description || d.text || '?')
      return null
    }
    return r.result?.result?.value
  }

  await send('Runtime.enable')
  await send('Log.enable')
  await send('Page.enable')
  await send('Page.navigate', { url: UI })

  let mounted = false
  for (let i = 0; i < 45; i++) {
    const v = await evaluate('({ hasLog: !!document.getElementById("chat-log") })')
    if (v?.hasLog) { mounted = true; break }
    await wait(1000)
  }
  if (!mounted) bad('dashboard did not mount')
  else ok('dashboard mounted')

  // 1. The regression guard: the IIFE must run to completion and export itself.
  //    A missing brace killed this exact line while node --check stayed green.
  //    agent-flow.js is a `defer` script, so the export does not exist the
  //    instant the static markup appears - poll instead of sampling once.
  let exported = null
  for (let i = 0; i < 30; i++) {
    exported = await evaluate('typeof window.JarvisAgentFlow === "object" ? Object.keys(window.JarvisAgentFlow).sort() : null')
    if (Array.isArray(exported)) break
    await wait(500)
  }
  if (Array.isArray(exported) && exported.includes('openAgent') && exported.includes('render')) {
    ok('flow builder IIFE completed and exported: ' + exported.join(','))
  } else {
    bad('JarvisAgentFlow export missing (IIFE died before the export) -> ' + JSON.stringify(exported))
  }

  const surface = await evaluate(`(() => {
    const m = window.JarvisAgentFlow
    if (!m) return null
    return { state: !!m.state, render: typeof m.render, refresh: typeof m.refresh, openAgent: typeof m.openAgent }
  })()`)
  if (surface?.state && surface?.render === 'function' && surface?.refresh === 'function' && surface?.openAgent === 'function') {
    ok('exported state/render/refresh/openAgent are all live functions')
  } else {
    bad('exported surface incomplete -> ' + JSON.stringify(surface))
  }

  await evaluate(`document.querySelector('.nav-item[data-view="cowork"]')?.click(), 'ok'`)
  await wait(900)
  const tab = await evaluate(`(() => {
    const t = document.querySelector('[data-cowork-tab="agents"]')
    if (!t) return 'no-tab'
    t.click()
    return 'clicked'
  })()`)
  if (tab === 'clicked') ok('Agents tab clicked')
  else bad('Agents tab -> ' + tab)

  // The catalog is resolved against the live ToolRegistry, so poll for it
  // instead of sleeping a fixed amount.
  let painted = null
  for (let i = 0; i < 30; i++) {
    painted = await evaluate(`(() => {
      const panel = document.querySelector('[data-cowork-panel="agents"]')
      if (!panel || !panel.classList.contains('active')) return { active: false }
      const nodes = document.getElementById('af-nodes')
      const edges = document.getElementById('af-edges')
      const palette = document.getElementById('af-palette')
      const store = document.getElementById('af-store')
      return {
        active: true,
        hasCanvas: !!nodes && !!edges,
        paletteKinds: palette ? palette.querySelectorAll('[data-af-add]').length : 0,
        store: store ? store.textContent.trim() : '',
        domNodes: nodes ? nodes.querySelectorAll('[data-af-node]').length : 0
      }
    })()`)
    if (painted?.hasCanvas && /registry\s+[1-9]/.test(painted.store || '')) break
    await wait(1000)
  }
  if (painted?.active && painted.hasCanvas) ok('Agents panel active with a real node canvas + edge layer')
  else bad('Agents panel/canvas did not render -> ' + JSON.stringify(painted))

  // The store line must show the LIVE registry counts, not a placeholder.
  const m = /registry\s+(\d+)\s+tools/i.exec(painted?.store || '')
  if (m && Number(m[1]) > 0) ok('live catalog bound into the UI: ' + painted.store.replace(/\s+/g, ' '))
  else bad('catalog counts not bound -> ' + JSON.stringify(painted?.store))
  if (painted?.paletteKinds > 0) ok('palette offers ' + painted.paletteKinds + ' real node kinds')
  else bad('palette did not render any node kinds')

  // 4. Create an agent through the real button -> real POST /agents.
  const created = await evaluate(`(async () => {
    document.getElementById('af-new')?.click()
    for (let i = 0; i < 20; i++) {
      await new Promise(r => setTimeout(r, 500))
      const list = document.getElementById('af-list')
      const items = list ? list.querySelectorAll('[data-af-agent]').length : 0
      if (items > 0) {
        const id = list.querySelector('[data-af-agent]').getAttribute('data-af-agent')
        return { ok: true, id, count: items }
      }
    }
    return { ok: false }
  })()`)
  if (created?.ok) ok('created an agent through the UI: ' + created.id + ' (' + created.count + ' in library)')
  else bad('could not create an agent through the UI')

  // 5. The saved flow must be real: nodes on canvas, edges drawn, validation run.
  if (created?.ok) {
    const flow = await evaluate(`(async () => {
      await new Promise(r => setTimeout(r, 1200))
      const st = window.JarvisAgentFlow.state
      return {
        dirty: st.dirty,
        nodeCount: st.agent && st.agent.flow ? st.agent.flow.nodes.length : 0,
        edgeCount: st.agent && st.agent.flow ? st.agent.flow.edges.length : 0,
        domNodes: document.querySelectorAll('#af-nodes [data-af-node]').length,
        domEdges: document.querySelectorAll('#af-edges path, #af-edges line, #af-edges polyline').length,
        validation: st.validation ? st.validation.ok : null,
        enabled: st.agent ? st.agent.enabled !== false : null
      }
    })()`)
    if (flow?.nodeCount > 0) ok('default flow has ' + flow.nodeCount + ' real nodes, ' + flow.edgeCount + ' edges')
    else bad('saved agent has no nodes -> ' + JSON.stringify(flow))
    if (flow?.domNodes > 0) ok('canvas painted ' + flow.domNodes + ' node(s)')
    else bad('canvas painted no nodes')
    if (flow?.domEdges > 0) ok('edge layer drew ' + flow.domEdges + ' connection(s)')
    else bad('edge layer drew no connections -> ' + JSON.stringify(flow))
    if (flow?.dirty === false) ok('freshly opened flow is clean (dirty-state protection intact)')
    else bad('dirty state wrong after open -> ' + JSON.stringify(flow?.dirty))
  }

  // 6. Clean up the agent this test created so the store stays honest.
  //    Must use POST /agents/delete, exactly like the UI: a raw DELETE is a
  //    simple-method-free cross-origin request the core's CORS preflight
  //    rejects, which would fail here for reasons unrelated to the builder.
  const cleaned = await evaluate(`(async () => {
    const id = ${JSON.stringify(created?.id || '')}
    if (!id) return 'no-id'
    const r = await fetch('http://127.0.0.1:7780/agents/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    })
    return r.ok ? 'ok' : ('status ' + r.status)
  })()`)
  if (cleaned === 'ok') ok('test agent deleted (store left clean)')
  else bad('cleanup delete -> ' + cleaned)

  const shot = await send('Page.captureScreenshot', { format: 'png' })
  if (shot.result?.data) {
    const out = path.join(artifactsDir, 'agents-builder.png')
    writeFileSync(out, Buffer.from(shot.result.data, 'base64'))
    ok('screenshot -> ' + path.relative(root, out).replace(/\\/g, '/'))
  }

  if (noise.length) bad('console was not clean (' + noise.length + ')\n       ' + noise.join('\n       '))
  else ok('no console errors or uncaught exceptions')
} catch (e) {
  bad('harness error: ' + e.message)
} finally {
  clearTimeout(watchdog)
  cleanup()
}

say('\nAGENT FLOW UI: ' + passed + ' passed, ' + failed + ' failed')
flush()
process.exitCode = failed ? 1 : 0
