import React, { useEffect, useRef, useState } from 'react';
import { MaterialItem, resolvePhysicalAppearance } from '../data/archiveData';

export interface ShelfSlotRect {
  index: number;
  tier: number;
  // Normalized coordinates (0..1) of the physical book itself relative to the Center Atrium
  x: number;
  y: number;
  w: number;
  h: number;
  slopeY: number;
}

/**
 * Exact 3D Shelf Compartment Slots for Individual Books on the Left (Soft Skills)
 * and Right (Hard Skills) shelves.
 * - Each slot represents ONE physical 3D book standing INSIDE the shelf bay,
 *   resting on the recessed dark shelf plank just behind the golden LED front lip!
 */
export const LEFT_SHELF_SLOTS: ShelfSlotRect[] = [
  // Row 1 (Eye-Level Shelf Bay — rests on the 2nd Golden Shelf Plank at y ≈ 0.442..0.452)
  { index: 0, tier: 1, x: 0.048, y: 0.312, w: 0.092, h: 0.126, slopeY: 0.048 },
  { index: 1, tier: 1, x: 0.152, y: 0.318, w: 0.09, h: 0.125, slopeY: 0.048 },
  { index: 2, tier: 1, x: 0.254, y: 0.324, w: 0.088, h: 0.124, slopeY: 0.048 },

  // Row 2 (3rd Golden Shelf Plank at y ≈ 0.586..0.592)
  { index: 3, tier: 2, x: 0.048, y: 0.468, w: 0.092, h: 0.118, slopeY: -0.015 },
  { index: 4, tier: 2, x: 0.152, y: 0.466, w: 0.09, h: 0.118, slopeY: -0.015 },
  { index: 5, tier: 2, x: 0.254, y: 0.464, w: 0.088, h: 0.118, slopeY: -0.015 },

  // Row 3 (4th Golden Shelf Plank at y ≈ 0.715..0.738)
  { index: 6, tier: 3, x: 0.048, y: 0.612, w: 0.092, h: 0.118, slopeY: -0.068 },
  { index: 7, tier: 3, x: 0.152, y: 0.604, w: 0.09, h: 0.118, slopeY: -0.068 },
  { index: 8, tier: 3, x: 0.254, y: 0.596, w: 0.088, h: 0.118, slopeY: -0.068 },

  // Row 4 (5th Golden Shelf Plank at y ≈ 0.840..0.885)
  { index: 9, tier: 4, x: 0.048, y: 0.754, w: 0.092, h: 0.12, slopeY: -0.115 },
  { index: 10, tier: 4, x: 0.152, y: 0.742, w: 0.09, h: 0.12, slopeY: -0.115 },
];

export const RIGHT_SHELF_SLOTS: ShelfSlotRect[] = [
  // Row 1 (Eye-Level Shelf Bay — rests on the 2nd Golden Shelf Plank on Right Shelf)
  { index: 0, tier: 1, x: 0.682, y: 0.324, w: 0.088, h: 0.124, slopeY: -0.048 },
  { index: 1, tier: 1, x: 0.782, y: 0.318, w: 0.09, h: 0.125, slopeY: -0.048 },
  { index: 2, tier: 1, x: 0.884, y: 0.312, w: 0.09, h: 0.126, slopeY: -0.048 },

  // Row 2 (3rd Golden Shelf Plank on Right Shelf)
  { index: 3, tier: 2, x: 0.682, y: 0.464, w: 0.088, h: 0.118, slopeY: 0.015 },
  { index: 4, tier: 2, x: 0.782, y: 0.466, w: 0.09, h: 0.118, slopeY: 0.015 },
  { index: 5, tier: 2, x: 0.884, y: 0.468, w: 0.09, h: 0.118, slopeY: 0.015 },

  // Row 3 (4th Golden Shelf Plank on Right Shelf)
  { index: 6, tier: 3, x: 0.682, y: 0.596, w: 0.088, h: 0.118, slopeY: 0.068 },
  { index: 7, tier: 3, x: 0.782, y: 0.604, w: 0.09, h: 0.118, slopeY: 0.068 },
  { index: 8, tier: 3, x: 0.884, y: 0.612, w: 0.09, h: 0.118, slopeY: 0.068 },

  // Row 4 (5th Golden Shelf Plank on Right Shelf)
  { index: 9, tier: 4, x: 0.682, y: 0.742, w: 0.088, h: 0.12, slopeY: 0.115 },
  { index: 10, tier: 4, x: 0.782, y: 0.754, w: 0.09, h: 0.12, slopeY: 0.115 },
];

interface AtriumBackdropCanvasProps {
  activeBeamPulse: boolean;
  softMaterials: MaterialItem[];
  hardMaterials: MaterialItem[];
  selectedSourceId?: string | null;
  hoveredSourceId?: string | null;
}

function wrapCoverLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines = 3
): string[] {
  const words = text.trim().split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      current = test;
    } else {
      if (current) {
        lines.push(current);
        current = word;
      } else {
        let chunk = word;
        while (ctx.measureText(chunk).width > maxWidth && chunk.length > 3) {
          chunk = chunk.slice(0, -1);
        }
        lines.push(chunk);
        current = '';
      }
    }
  }
  if (current) lines.push(current);

  if (lines.length > maxLines) {
    const truncated = lines.slice(0, maxLines);
    let last = truncated[maxLines - 1];
    while (ctx.measureText(`${last}…`).width > maxWidth && last.length > 2) {
      last = last.slice(0, -1);
    }
    truncated[maxLines - 1] = `${last}…`;
    return truncated;
  }
  return lines;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

/**
 * Renders ONE standalone, recessed 3D physical book / PDF volume / cream notebook
 * standing INSIDE the 3D shelf compartment (resting on the recessed dark shelf plank
 * behind the golden LED lip, with back-wall cast shadow, shelf floor reflection,
 * overhead shelf ceiling shadow, and reactive under-shelf glow on hover).
 */
function drawRecessedPhysicalBookInShelf(
  ctx: CanvasRenderingContext2D,
  item: MaterialItem,
  slot: ShelfSlotRect,
  side: 'left' | 'right',
  isSelected: boolean,
  isHovered: boolean,
  W: number,
  H: number
) {
  const coverX = slot.x * W;
  const coverY = slot.y * H;
  const coverW = slot.w * W;
  const coverH = slot.h * H;
  const { look, emblem } = resolvePhysicalAppearance(item, slot.index);
  const isCream = look === 'cream-notebook';
  const isActiveOrHover = isSelected || isHovered;

  ctx.save();
  ctx.translate(coverX, coverY);
  // Perspective shear matching the exact shelf plank angle
  ctx.transform(1, slot.slopeY, 0, 1, 0, 0);

  // 1. Cast Shadow onto the Recessed Back Wall & Shelf Plank inside the compartment
  ctx.save();
  const wallShadowX = side === 'left' ? 12 : -18;
  const wallShadowGrad = ctx.createRadialGradient(
    coverW * 0.55 + wallShadowX,
    coverH * 0.52,
    coverW * 0.1,
    coverW * 0.55 + wallShadowX,
    coverH * 0.52,
    coverW * 0.75
  );
  wallShadowGrad.addColorStop(0, 'rgba(0, 0, 0, 0.85)');
  wallShadowGrad.addColorStop(0.65, 'rgba(0, 0, 0, 0.45)');
  wallShadowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = wallShadowGrad;
  ctx.fillRect(-24, -10, coverW + 48, coverH + 24);
  ctx.restore();

  // 2. Contact Shadow where the Book Base rests on the Dark Recessed Shelf Plank
  const baseShadow = ctx.createLinearGradient(0, coverH - 5, 0, coverH + 10);
  baseShadow.addColorStop(0, 'rgba(0, 0, 0, 0.96)');
  baseShadow.addColorStop(0.5, 'rgba(0, 0, 0, 0.72)');
  baseShadow.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = baseShadow;
  ctx.fillRect(-14, coverH - 3, coverW + 24, 13);

  // 3. Under-Shelf Glow & Warm Golden LED Reflection (intensifies when hovered!)
  const shelfReflect = ctx.createLinearGradient(0, coverH - 2, 0, coverH + (isActiveOrHover ? 22 : 12));
  shelfReflect.addColorStop(0, isActiveOrHover ? 'rgba(251, 191, 36, 0.75)' : 'rgba(251, 191, 36, 0.36)');
  shelfReflect.addColorStop(0.45, isActiveOrHover ? 'rgba(34, 211, 238, 0.38)' : 'rgba(217, 119, 6, 0.14)');
  shelfReflect.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = shelfReflect;
  ctx.fillRect(-12, coverH - 2, coverW + 22, isActiveOrHover ? 24 : 12);

  // 4. 3D Extruded Book Spine & Recessed Paper Block
  const spineW = 13;

  // Top Recessed Paper Block (darkened because it sits under the upper shelf ceiling!)
  ctx.beginPath();
  ctx.moveTo(-spineW, -5);
  ctx.lineTo(coverW - 4, -5);
  ctx.lineTo(coverW, 0);
  ctx.lineTo(0, 0);
  ctx.closePath();
  const topPaperGrad = ctx.createLinearGradient(0, -5, coverW, 0);
  topPaperGrad.addColorStop(0, isCream ? '#6b6356' : '#1e293b');
  topPaperGrad.addColorStop(0.4, isCream ? '#9c917d' : '#64748b');
  topPaperGrad.addColorStop(1, isCream ? '#786f5e' : '#334155');
  ctx.fillStyle = topPaperGrad;
  ctx.fill();

  // Left 3D Rounded Book Spine
  ctx.beginPath();
  ctx.moveTo(-spineW, -5);
  ctx.lineTo(0, 0);
  ctx.lineTo(0, coverH);
  ctx.lineTo(-spineW, coverH - 4);
  ctx.closePath();
  const spineGrad = ctx.createLinearGradient(-spineW, 0, 0, 0);
  if (isCream) {
    spineGrad.addColorStop(0, '#141210');
    spineGrad.addColorStop(0.4, '#292524');
    spineGrad.addColorStop(1, '#090807');
  } else {
    spineGrad.addColorStop(0, '#071120');
    spineGrad.addColorStop(0.45, '#172b47');
    spineGrad.addColorStop(1, '#030710');
  }
  ctx.fillStyle = spineGrad;
  ctx.fill();

  // Spine Foil Ribs
  ctx.fillStyle = item.type === 'PDF' ? 'rgba(225, 29, 72, 0.7)' : 'rgba(245, 158, 11, 0.65)';
  ctx.fillRect(-spineW + 1, 18, spineW - 2, 2.5);
  ctx.fillRect(-spineW + 1, coverH - 22, spineW - 2, 2.5);

  // Right 3D Layered Paper Edge
  ctx.beginPath();
  ctx.moveTo(coverW, 0);
  ctx.lineTo(coverW + 5, -3);
  ctx.lineTo(coverW + 5, coverH - 3);
  ctx.lineTo(coverW, coverH);
  ctx.closePath();
  const sidePagesGrad = ctx.createLinearGradient(coverW, 0, coverW + 5, coverH);
  sidePagesGrad.addColorStop(0, isCream ? '#8a7f6c' : '#475569');
  sidePagesGrad.addColorStop(0.5, isCream ? '#cfc4ae' : '#94a3b8');
  sidePagesGrad.addColorStop(1, isCream ? '#968a74' : '#475569');
  ctx.fillStyle = sidePagesGrad;
  ctx.fill();

  // 5. Front 3D Cover Board
  drawRoundedRect(ctx, 0, 0, coverW, coverH, 3.5);
  const coverGrad = ctx.createLinearGradient(0, 0, coverW, coverH);
  if (isCream) {
    coverGrad.addColorStop(0, '#ddd3be');
    coverGrad.addColorStop(0.5, '#cfc3ab');
    coverGrad.addColorStop(1, '#b8aa90');
  } else {
    coverGrad.addColorStop(0, '#102038');
    coverGrad.addColorStop(0.5, '#091323');
    coverGrad.addColorStop(1, '#050a14');
  }
  ctx.fillStyle = coverGrad;
  ctx.fill();

  // Spine Crease Groove on Front Cover
  ctx.beginPath();
  ctx.moveTo(7, 1);
  ctx.lineTo(7, coverH - 1);
  ctx.strokeStyle = isCream ? 'rgba(28, 25, 23, 0.2)' : 'rgba(0, 0, 0, 0.65)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // 6. Cover Emblem + Side Title Typography (Exact 2nd Reference Image Style!)
  if (isCream) {
    const padX = 14;
    const maxTextW = coverW - padX - 8;
    ctx.font = '700 18px "Plus Jakarta Sans", sans-serif';
    const lines = wrapCoverLines(ctx, item.title, maxTextW, 3);

    ctx.fillStyle = '#1c1917';
    lines.forEach((line, idx) => {
      ctx.fillText(line, padX, 34 + idx * 21);
    });

    // Subtle ruled lines at bottom of cream notebook
    ctx.strokeStyle = 'rgba(28, 25, 23, 0.22)';
    ctx.lineWidth = 1;
    for (let r = 0; r < 3; r++) {
      const ly = coverH - 38 + r * 9;
      ctx.beginPath();
      ctx.moveTo(padX, ly);
      ctx.lineTo(coverW - 12, ly);
      ctx.stroke();
    }
    ctx.font = '600 10px "JetBrains Mono", monospace';
    ctx.fillStyle = '#44403c';
    ctx.fillText(
      item.category === 'hard' ? '∑ ∫ π  √x' : `${item.subcategory.slice(0, 9)}`,
      padX,
      coverH - 10
    );
  } else {
    // Dark Hardcover / PDF Case ("Public Speaking PDF" style from 2nd image!)
    const badgeX = 13;
    const badgeY = 16;
    const badgeSize = 28;

    if (item.type === 'PDF' || emblem === 'pdf') {
      // Red [PDF] Square Badge on Top-Left of Cover
      const pdfGrad = ctx.createLinearGradient(badgeX, badgeY, badgeX + badgeSize, badgeY + badgeSize);
      pdfGrad.addColorStop(0, '#e11d48');
      pdfGrad.addColorStop(1, '#9f1239');
      ctx.fillStyle = pdfGrad;
      drawRoundedRect(ctx, badgeX, badgeY, badgeSize, badgeSize, 4);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = '800 8.5px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('PDF', badgeX + 5, badgeY + 18);

      // Circular Red/White Seal at Bottom-Left of Cover
      const sealCx = badgeX + 14;
      const sealCy = coverH - 20;
      ctx.beginPath();
      ctx.arc(sealCx, sealCy, 7.5, 0, Math.PI * 2);
      ctx.fillStyle = '#be123c';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(sealCx, sealCy - 1, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = '#e2e8f0';
      ctx.fill();
    } else {
      // Glowing Subject Emblem for Book / Course / Web
      ctx.fillStyle = 'rgba(14, 116, 144, 0.35)';
      drawRoundedRect(ctx, badgeX, badgeY, badgeSize, badgeSize, 5);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
      ctx.lineWidth = 1;
      drawRoundedRect(ctx, badgeX, badgeY, badgeSize, badgeSize, 5);
      ctx.stroke();

      ctx.fillStyle = emblem === 'python' ? '#facc15' : '#38bdf8';
      ctx.font = '800 11px "JetBrains Mono", monospace';
      const sym =
        emblem === 'python'
          ? 'Py'
          : emblem === 'code'
          ? '</>'
          : emblem === 'math'
          ? '∑π'
          : emblem === 'atom'
          ? '⚛'
          : item.type.slice(0, 3).toUpperCase();
      ctx.fillText(sym, badgeX + 4, badgeY + 18);
    }

    // Source Name Written Cleanly on the Side of the Physical Cover
    const textStartX = 48;
    const maxTitleW = coverW - textStartX - 8;
    ctx.font = '700 17.5px "Plus Jakarta Sans", sans-serif';
    let lines = wrapCoverLines(ctx, item.title, maxTitleW, 3);
    if (lines.some((l) => l.endsWith('…')) && item.title.length > 12) {
      ctx.font = '700 15px "Plus Jakarta Sans", sans-serif';
      lines = wrapCoverLines(ctx, item.title, maxTitleW, 3);
    }

    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
    ctx.shadowBlur = 3;
    ctx.shadowOffsetY = 1.5;
    ctx.fillStyle = '#e2e8f0';
    lines.forEach((line, idx) => {
      ctx.fillText(line, textStartX, 29 + idx * 19.5);
    });
    ctx.restore();

    // Subtle Footer on Cover
    ctx.font = '600 9.5px "JetBrains Mono", monospace';
    ctx.fillStyle = 'rgba(148, 163, 184, 0.78)';
    ctx.fillText(`${item.type} · ${item.fileSize || '2.4 MB'}`, textStartX, coverH - 15);
  }

  // 7. INTERIOR SHELF LIGHTING OVERLAY:
  //    - Overhead Shelf Ceiling Shadow across top 26% of the book (tucks book INSIDE the shelf!)
  //    - Warm Golden LED Bounce Light across bottom of the book (intensifies on hover!)
  const interiorLight = ctx.createLinearGradient(0, 0, 0, coverH);
  interiorLight.addColorStop(0, 'rgba(2, 6, 14, 0.52)');
  interiorLight.addColorStop(0.26, 'rgba(2, 6, 14, 0)');
  interiorLight.addColorStop(isActiveOrHover ? 0.65 : 0.78, 'rgba(245, 158, 11, 0)');
  interiorLight.addColorStop(1, isActiveOrHover ? 'rgba(251, 191, 36, 0.48)' : 'rgba(251, 191, 36, 0.26)');
  ctx.fillStyle = interiorLight;
  drawRoundedRect(ctx, 0, 0, coverW, coverH, 3.5);
  ctx.fill();

  // Subtle Cover Edge Rim
  ctx.lineWidth = isActiveOrHover ? 2 : 1;
  ctx.strokeStyle = isActiveOrHover
    ? 'rgba(56, 189, 248, 0.9)'
    : isCream
    ? 'rgba(255, 251, 235, 0.35)'
    : 'rgba(148, 163, 184, 0.25)';
  drawRoundedRect(ctx, 0, 0, coverW, coverH, 3.5);
  ctx.stroke();

  // 8. Front Golden Shelf Lip Occlusion Line at the very base of the book
  const lipGrad = ctx.createLinearGradient(0, coverH - 1.5, 0, coverH + 2.5);
  lipGrad.addColorStop(0, isActiveOrHover ? 'rgba(253, 224, 71, 0.95)' : 'rgba(251, 191, 36, 0.55)');
  lipGrad.addColorStop(1, 'rgba(180, 83, 9, 0.25)');
  ctx.fillStyle = lipGrad;
  ctx.fillRect(-spineW, coverH - 1, coverW + spineW + 4, 3);

  ctx.restore();
}

export const AtriumBackdropCanvas: React.FC<AtriumBackdropCanvasProps> = ({
  activeBeamPulse,
  softMaterials,
  hardMaterials,
  selectedSourceId,
  hoveredSourceId,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [emptyImgLoaded, setEmptyImgLoaded] = useState(false);
  const [popFullLoaded, setPopFullLoaded] = useState(false);
  const emptyImgRef = useRef<HTMLImageElement | null>(null);
  const popFullRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    const img1 = new Image();
    img1.crossOrigin = 'anonymous';
    img1.src = '/assets/library/atrium-wide.png';
    img1.onload = () => {
      emptyImgRef.current = img1;
      setEmptyImgLoaded(true);
    };

    const img2 = new Image();
    img2.crossOrigin = 'anonymous';
    img2.src = '/assets/library/atrium-near.png';
    img2.onload = () => {
      popFullRef.current = img2;
      setPopFullLoaded(true);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 2100;
    const H = 1440;
    canvas.width = W;
    canvas.height = H;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    if (emptyImgRef.current && emptyImgLoaded) {
      const img = emptyImgRef.current;
      const sx = img.width * 0.0908;
      const sy = img.height * 0.055;
      const sw = img.width * 0.6462;
      const sh = img.height * 0.937;

      // 1. Draw the 3D Atrium Architecture
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, W, H);

      // 2. Clean BOTH Left and Right Tier-1 Shelf Bays of the baked-in "No materials yet" PNG text
      //    Left Shelf Bay 1:
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(W * 0.032, H * 0.212);
      ctx.lineTo(W * 0.362, H * 0.262);
      ctx.lineTo(W * 0.362, H * 0.448);
      ctx.lineTo(W * 0.032, H * 0.436);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(
        img,
        sx + sw * 0.032,
        sy + sh * 0.464,
        sw * 0.33,
        sh * 0.118,
        W * 0.032,
        H * 0.205,
        W * 0.33,
        H * 0.246
      );
      const leftBayShade = ctx.createLinearGradient(0, H * 0.21, 0, H * 0.45);
      leftBayShade.addColorStop(0, 'rgba(3, 8, 16, 0.62)');
      leftBayShade.addColorStop(0.5, 'rgba(6, 14, 25, 0.28)');
      leftBayShade.addColorStop(1, 'rgba(3, 8, 16, 0.68)');
      ctx.fillStyle = leftBayShade;
      ctx.fillRect(W * 0.032, H * 0.205, W * 0.33, H * 0.246);
      ctx.restore();

      //    Right Shelf Bay 1:
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(W * 0.658, H * 0.262);
      ctx.lineTo(W * 0.968, H * 0.212);
      ctx.lineTo(W * 0.968, H * 0.436);
      ctx.lineTo(W * 0.658, H * 0.448);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(
        img,
        sx + sw * 0.658,
        sy + sh * 0.464,
        sw * 0.31,
        sh * 0.118,
        W * 0.658,
        H * 0.205,
        W * 0.31,
        H * 0.246
      );
      const rightBayShade = ctx.createLinearGradient(0, H * 0.21, 0, H * 0.45);
      rightBayShade.addColorStop(0, 'rgba(3, 8, 16, 0.62)');
      rightBayShade.addColorStop(0.5, 'rgba(6, 14, 25, 0.28)');
      rightBayShade.addColorStop(1, 'rgba(3, 8, 16, 0.68)');
      ctx.fillStyle = rightBayShade;
      ctx.fillRect(W * 0.658, H * 0.205, W * 0.31, H * 0.246);
      ctx.restore();

      // 3. Clean the baked-in "Select a source to start" PNG card from the Center Hallway
      //    using ONLY the upper unobstructed hallway (psy: 0.46..0.60) so [Selected Source] never peeks out!
      if (popFullRef.current && popFullLoaded) {
        const popImg = popFullRef.current;
        ctx.save();
        drawRoundedRect(ctx, W * 0.38, H * 0.495, W * 0.275, H * 0.165, 16);
        ctx.clip();
        const psx = popImg.width * 0.274;
        const psy = popImg.height * 0.485;
        const psw = popImg.width * 0.198;
        const psh = popImg.height * 0.135;
        ctx.drawImage(popImg, psx, psy, psw, psh, W * 0.38, H * 0.495, W * 0.275, H * 0.165);
        ctx.restore();
      }

      // 4. Render each uploaded Soft Skills material physically INSIDE the Left 3D Shelf compartments!
      softMaterials.slice(0, LEFT_SHELF_SLOTS.length).forEach((item, idx) => {
        const slot = LEFT_SHELF_SLOTS[idx];
        drawRecessedPhysicalBookInShelf(
          ctx,
          item,
          slot,
          'left',
          selectedSourceId === item.id,
          hoveredSourceId === item.id,
          W,
          H
        );
      });

      // 5. Render each uploaded Hard Skills material physically INSIDE the Right 3D Shelf compartments!
      hardMaterials.slice(0, RIGHT_SHELF_SLOTS.length).forEach((item, idx) => {
        const slot = RIGHT_SHELF_SLOTS[idx];
        drawRecessedPhysicalBookInShelf(
          ctx,
          item,
          slot,
          'right',
          selectedSourceId === item.id,
          hoveredSourceId === item.id,
          W,
          H
        );
      });
    }

    if (activeBeamPulse) {
      ctx.save();
      const beamX = W * 0.517;
      const beamGrad = ctx.createRadialGradient(beamX, H * 0.45, 12, beamX, H * 0.45, W * 0.22);
      beamGrad.addColorStop(0, 'rgba(34, 211, 238, 0.22)');
      beamGrad.addColorStop(0.5, 'rgba(6, 182, 212, 0.06)');
      beamGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = beamGrad;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }, [
    emptyImgLoaded,
    popFullLoaded,
    activeBeamPulse,
    softMaterials,
    hardMaterials,
    selectedSourceId,
    hoveredSourceId,
  ]);

  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none select-none">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
