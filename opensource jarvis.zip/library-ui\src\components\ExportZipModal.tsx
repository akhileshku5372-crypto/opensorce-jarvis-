import React, { useState } from 'react';
import JSZip from 'jszip';
import { Download, Check, Copy, X, Terminal, FileArchive, Code2 } from 'lucide-react';
import { MaterialItem } from '../data/archiveData';
import { downloadCompleteProjectZip } from '../utils/exportProjectZip';

interface ExportZipModalProps {
  isOpen: boolean;
  onClose: () => void;
  materials: MaterialItem[];
}

export const ExportZipModal: React.FC<ExportZipModalProps> = ({
  isOpen,
  onClose,
  materials,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'zip' | 'python' | 'js'>('zip');

  if (!isOpen) return null;

  const generateStandaloneHtml = () => {
    return `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>JARVIS — Research Archive HUD</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Rajdhani:wght@500;600;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; background: #040a12; color: #e2e8f0; overflow: hidden; user-select: none; }
    .font-display { font-family: 'Rajdhani', sans-serif; }
    .font-mono-tabular { font-family: 'JetBrains Mono', monospace; font-variant-numeric: tabular-nums; }
  </style>
</head>
<body class="h-screen w-screen flex flex-col bg-[#040a12] text-slate-100">
  <!-- JARVIS Python / WebSocket Bridge Ready -->
  <script>
    window.JARVIS_ARCHIVE_DATA = ${JSON.stringify(materials, null, 2)};
    window.jarvisBridge = {
      setOnlineStatus: (online) => document.dispatchEvent(new CustomEvent('jarvis:status', { detail: { online } })),
      askSource: (question) => document.dispatchEvent(new CustomEvent('jarvis:ask', { detail: { question } })),
      speak: (text) => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(text);
          u.rate = 1.0;
          window.speechSynthesis.speak(u);
        }
      }
    };
  </script>
  <div class="p-8 max-w-3xl mx-auto my-auto border border-cyan-500/40 bg-[#071426]/90 rounded-2xl text-center space-y-4 shadow-[0_0_40px_rgba(34,211,238,0.2)]">
    <h1 class="font-display text-3xl font-bold tracking-widest text-cyan-300">JARVIS RESEARCH ARCHIVE</h1>
    <p class="text-sm text-slate-300">Full React + Vite source code is included in this ZIP archive. Run <code class="text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded">npm install && npm run dev</code> or mount the built <code class="text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded">dist/</code> folder inside your Python PyQt / pywebview / Electron JARVIS window.</p>
  </div>
</body>
</html>`;
  };

  const pythonIntegrationSnippet = `# Python JARVIS Desktop Integration (pywebview or PyQt6)
# pip install pywebview

import webview

class JarvisArchiveAPI:
    def on_source_question(self, source_title: str, question: str):
        print(f"[JARVIS ARCHIVE] Querying '{source_title}': {question}")
        # Connect your local LLM / Ollama / Gemini API here:
        return f"Synthesis from {source_title}: Answered '{question}' with verified citations."

    def on_system_telemetry(self):
        return {"cpu": 12, "gpu": 28, "state": "Online · Ready"}

if __name__ == "__main__":
    api = JarvisArchiveAPI()
    # Point to your running Vite dev server (http://localhost:3000) or built dist/index.html
    window = webview.create_window(
        "JARVIS — Research Archive",
        "http://localhost:3000",
        js_api=api,
        width=1536,
        height=960,
        frameless=False,
        background_color="#040a12"
    )
    webview.start()`;

  const jsBridgeSnippet = `// Connect your external JARVIS Voice/Backend to this UI from anywhere:
window.dispatchEvent(new CustomEvent('jarvis:external-command', {
  detail: {
    action: 'ASK_SOURCE', // or 'SET_ONLINE' | 'SELECT_SOURCE' | 'READ_ALOUD'
    payload: {
      question: 'Summarize the key takeaways from this source',
      online: true
    }
  }
}));`;

  const handleDownloadZip = async () => {
    setIsGenerating(true);
    try {
      await downloadCompleteProjectZip();
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(key);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl rounded-2xl border border-cyan-400/50 bg-[#061324] shadow-[0_0_50px_rgba(6,182,212,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/25 bg-[#08192e]">
          <div className="flex items-center gap-3">
            <FileArchive className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="font-display text-lg font-bold tracking-wider text-white">
                EXPORT TO YOUR JARVIS SYSTEM (.ZIP & BRIDGE)
              </h2>
              <p className="text-xs text-slate-400">
                Download ready-to-use integration package or connect directly to Python / Node JARVIS
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-cyan-500/15 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-cyan-500/15">
          <button
            onClick={() => setActiveTab('zip')}
            className={`px-4 py-2 text-xs font-medium rounded-t-lg border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'zip'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            1. Download ZIP Package
          </button>
          <button
            onClick={() => setActiveTab('python')}
            className={`px-4 py-2 text-xs font-medium rounded-t-lg border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'python'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            2. Python (PyQt / pywebview) Bridge
          </button>
          <button
            onClick={() => setActiveTab('js')}
            className={`px-4 py-2 text-xs font-medium rounded-t-lg border-b-2 transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'js'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            3. JS Voice Event Bridge
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {activeTab === 'zip' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-cyan-500/25 bg-[#081a30]/70 space-y-2">
                <div className="text-sm font-semibold text-cyan-200">
                  How to plug this directly into your JARVIS:
                </div>
                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside leading-relaxed">
                  <li>
                    Click <strong>Download JARVIS Integration ZIP</strong> below (or use the top-right AI Studio <strong>Download / Export ZIP</strong> icon to get the full React + Vite workspace).
                  </li>
                  <li>
                    Run <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">npm install && npm run dev</code> (or <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">npm run build</code> for static <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">dist/</code> files).
                  </li>
                  <li>
                    Load it inside your Python JARVIS desktop window using <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">pywebview</code>, <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">PyQt6 QWebEngineView</code>, or <code className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono">Electron</code>.
                  </li>
                </ol>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl border border-cyan-400/40 bg-gradient-to-r from-cyan-500/15 to-blue-600/10 gap-3">
                <div>
                  <div className="text-sm font-semibold text-white">
                    jarvis-research-archive-complete.zip
                  </div>
                  <div className="text-xs text-slate-300">
                    Complete React + TypeScript codebase, 3D Atrium textures, Python launcher & Agent implementation guide
                  </div>
                </div>
                <button
                  onClick={handleDownloadZip}
                  disabled={isGenerating}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs transition-colors shadow-[0_0_20px_rgba(34,211,238,0.4)] whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  {isGenerating ? 'Downloading...' : '1-Click Download Full .ZIP'}
                </button>
              </div>
            </div>
          )}

          {activeTab === 'python' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300 flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-cyan-400" />
                  Launch this UI inside your Python JARVIS Assistant:
                </span>
                <button
                  onClick={() => handleCopy('python', pythonIntegrationSnippet)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg border border-cyan-400/40 bg-cyan-500/10 text-cyan-300 text-xs hover:bg-cyan-500/20 transition-colors"
                >
                  {copiedTab === 'python' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedTab === 'python' ? 'Copied!' : 'Copy Python Code'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-[#030912] border border-cyan-500/25 text-xs text-cyan-200 font-mono overflow-x-auto leading-relaxed">
                {pythonIntegrationSnippet}
              </pre>
            </div>
          )}

          {activeTab === 'js' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-cyan-400" />
                  Trigger JARVIS UI actions programmatically from your voice engine:
                </span>
                <button
                  onClick={() => handleCopy('js', jsBridgeSnippet)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg border border-cyan-400/40 bg-cyan-500/10 text-cyan-300 text-xs hover:bg-cyan-500/20 transition-colors"
                >
                  {copiedTab === 'js' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedTab === 'js' ? 'Copied!' : 'Copy JS Bridge'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-[#030912] border border-cyan-500/25 text-xs text-cyan-200 font-mono overflow-x-auto leading-relaxed">
                {jsBridgeSnippet}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
