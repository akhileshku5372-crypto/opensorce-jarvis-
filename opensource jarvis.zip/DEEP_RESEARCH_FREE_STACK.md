# Unlimited deep research on free plumbing — what exists, what it really costs, what JARVIS needs

Research-only document. **No code was changed to produce it.** Numbers below were checked
against live sources on 2026-10-19.

## 0. The answer in one paragraph

Depth does not come from a search API. Search APIs are the **narrowest** free thing that
exists (1,000 requests/month is a *ceiling*, not a plan). The unlimited layers are four
things nobody sells him:

1. **Keyless structured corpora** — OpenAlex (≈100,000 calls/day, no key), Semantic Scholar,
   Crossref, CORE, Unpaywall, arXiv, Europe PMC, GDELT, SEC EDGAR, Wikipedia/Wikidata,
   StackExchange, Hacker News Algolia, GitHub. These are *indexed, filtered, citation-linked*
   data — for factual depth they beat a SERP by an order of magnitude.
2. **Local fetch + extract** — `requests` + `trafilatura`/`Crawl4AI` on his own laptop.
   **There is no quota at all here.** Only politeness (per-host rate) and wall-clock. This is
   the single biggest unlock: Firecrawl's `/scrape` was never the bottleneck, the *bill* was.
3. **Self-hosted metasearch** — SearXNG aggregates up to 264 engines into a JSON endpoint with
   **no key and no billing**. Public instances rate-limit hard; his own instance does not.
4. **Modalities he already owns** — `faster-whisper` (any video/podcast → text), PyMuPDF +
   `ocr_engine.py` (any PDF/scan → text), `doc_index.py` + Chroma (his own files). Nobody
   quotas these. They are pure extra corpus.

Genspark's headline (1,338 sources / 1.6M words / 20-30 min) is **~1,338 fetches plus a
map-reduce read**. Fetch is free and unlimited locally. So the honest ceiling on his machine is
*time and free-tier LLM RPM* — not money, and not sources.

## 1. Measured reality before the shopping list

| Constraint | His machine / account | What it means |
|---|---|---|
| CPU-only, 15.3 GB RAM, Ryzen 7 250/780M | no local 7B+ VLM, no hosting OWI/Common Crawl | remote LLMs stay; heavy indexes are queried, never hosted |
| Firecrawl ×3 keys | all HTTP 402; credits are **per account**, not per key | 3 keys were never redundancy — replace the provider, not the key |
| Free search tiers | Tavily 1,000/mo · Exa 1,000/mo + $5 · Serper 2,500 one-time · **Brave no longer has a free plan** ($5 credit, changed Feb 2026) | SERP queries are the scarce resource → spend them last, not first |
| Free LLM tiers (Groq/Gemini/OpenRouter/NVIDIA/xkiro) | RPM caps, not token caps | the *reduce* step must round-robin across providers with per-provider backoff |
| Local fetch, 8 polite workers, ~1.5-2.5 s/page | 1,000 pages ≈ **25-45 min**; 5,000 pages ≈ 2-4 h | "whole internet" is an overnight job, so it must be **resumable** |

## 2. Tier ladder — this is what "prompt ke anusaar" means concretely

The engine picks a tier from the sentence, and he can always override by voice.

| Tier | Trigger words | Queries | Sources read | Wall clock | What runs |
|---|---|---|---|---|---|
| **T0 LOOKUP** | "kitna hai", "bata do", "just tell" | 1 | 5 | ~10 s | 1 keyless search, snippets only, no fetch |
| **T1 SEARCH** | "search karo", news | 3-6 | 20-40 | ~1 min | today's Firecrawl level, but local fetch |
| **T2 DEEP** | "research karo", "dhundo" | 10-20 | 80-150 | 5-10 min | sub-question loop + cross-check |
| **T3 EXHAUSTIVE** | "deeply", "poora", "detail mein" | 40-80 + citation snowball | 400-1,500 | 25-45 min | + OpenAlex/S2 graph walk, + 2-3 languages |
| **T4 SWEEP** | "poora internet", "1000 sites", "raat bhar" | 150-600, all verticals | 3,000-20,000 | 2-8 h, **resumable**, scheduler-run | every provider + archives + transcripts + PDFs + n-language + claim graph |

**30-50× Genspark is a T4 number, and it is only reachable because T4 is built on quota-free
layers.** T4 must therefore be a *background job with a manifest*, not a chat turn.

## 3. The registry (free, real, and what each one buys)

### A. Keyless general search (unofficial, rate-limited — spend last)
| Tool | Limit in practice | Note |
|---|---|---|
| `ddgs` (python, DuckDuckGo/aggregate) | soft rate limits, breaks occasionally | `pip install ddgs`, no key, web+news+images+maps |
| **SearXNG (self-hosted)** | **no quota, no key**, 264 engines, JSON out | the correct backbone; docker or bare python, loopback only |
| Mojeek / Marginalia | free, small indexes | Marginalia reaches the "indie/deep web" Google buries |

### B. Free-key search APIs (the 1,000/mo club)
Tavily 1,000 credits/mo (research-grade snippets) · Exa 1,000/mo + $5 (neural/link-graph search)
· Serper 2,500 one-time (Google SERP) · SearchAPI/SerpApi tiny trial. **Use only for the
queries where Google's ranking genuinely matters.**

### C. Scholarly + factual graph — the depth engine (keyless or free key)
| Source | Free limit | Why it matters for JARVIS |
|---|---|---|
| **OpenAlex** | ~100,000 calls/day, no key (add `mailto:`) | 250M+ works, authors, institutions, concepts, **reference edges** → snowball 5,000 papers from 1 seed with zero SERP cost |
| Semantic Scholar (S2AG) | public, shared pool (~1 rps unauth; free key raises) | embeddings + citation graph + TLDRs |
| Crossref | ~50k/hr polite pool | DOI, dates, funding, license — the *fact-check* layer |
| CORE.ac.uk | keyless low rate, free key higher | 250M+ open-access **full texts** (readable, not just metadata) |
| Unpaywall | free key, 100k/day | legal OA PDF for paywalled DOIs |
| arXiv / OpenAIRE / DOAJ / dblp / Europe PMC / PubMed | no key (arXiv ~1 req/3 s; E-utilities 3/s, 10/s with key) | preprints, OA journals, CS + bio full text |

### D. News, government, money, patents (all keyless)
**GDELT DOC 2.0** (global news, 15-min updates, no key) · **SEC EDGAR full-text** (10 req/s, no
key) · USAspending · World Bank · FRED · IMF · data.gov.in · **Open-Meteo** (weather, no key) ·
USPTO PatentsView / EPO OPS · EUR-Lex / CORDIS · WHO. For a "research anything" engine these are
the difference between opinions and numbers.

### E. Archive layer — read anything, including pages that were deleted
| Source | Limit | Use |
|---|---|---|
| **Wayback CDX API** | ~60 req/min (429 over that) | every snapshot of a URL; `&output=json` |
| **Common Crawl CDX** (`index.commoncrawl.org`) | no key, generous | "was this page ever like that" + bulk URL discovery per domain |
| CC-News / **Open Web Index** | free download, too big to host locally | 1.3 PB crawled since 2025; query slices, don't host |
| Internet Archive full-text + `archive.org/advancedsearch` | free | books, audio, scans, government docs |

### F. Community / code
Hacker News Algolia (no key) · StackExchange API (300/day keyless, 10k/day free key) · GitHub
search (5k/hr auth; code search 30/min) · PyPI/npm/crates/HF hub APIs (no key) · Reddit `.json`
(UA required, ~100/min before it complains) · Lobsters.

### G. Unlimited local modalities (already in this repo)
`faster-whisper` (video/podcast → text, CPU int8) · `youtube-transcript-api` when captions exist
(known to break; whisper is the fallback) · PyMuPDF for digital PDFs · `ocr_engine.py` for
scans · `doc_index.py` + Chroma for his own corpus · ffmpeg for slicing. **This is the layer
with literally no quota, no key and no network.**

## 4. The architecture that makes T3/T4 real (7 parts, none of them a new framework)

1. **Depth controller** — regex first (his existing deterministic routing), LLM fallback, to
   pick the tier from prompt + quantity words. Estimates `sources × seconds` up front and shows
   it in the UI *before* starting.
2. **Query expander** — per tier, generate facets: entities, time windows, geography, language,
   adversarial angles ("criticism of", "failed attempts at", "primary source for"), and
   **per-vertical queries** (scholarly vs news vs gov vs code). Breadth comes from facets, not
   from repeating one query.
3. **Provider bus** — one interface, `search(query, budget) → rows[]`, implemented by every
   source in §3, each with its own quota counter, backoff, and **honest fail row** (`ok:false`,
   `status`, `error`). This replaces the fake 3-key Firecrawl pool with real redundancy.
4. **Local fetch + extract pool** — 8 workers, 1 req/s per host, robots-aware, `trafilatura`
   → markdown, timeout + retry + Wayback fallback when the live page 404s/blocks. **This is
   where the 1,338-source number comes from.**
5. **Dedup & canonicalisation** — URL normalise, strip tracking, per-host cluster, MinHash on
   shingles for near-dup. 1,000 URLs typically collapse to ~250 distinct claims — without this,
   "1,338 sources" is 1,338 copies of the same press release.
6. **Claim store (the trick that fits a 15 GB laptop)** — never stuff pages into context. Each
   page is reduced *once* to rows: `{claim, subject, predicate, value, date, quote_span, url,
   fetched_at, http_status, host, lang}` in SQLite + embeddings in Chroma. 20,000 pages → maybe
   60,000 claim rows, which the LLM can actually reason over in map-reduce batches.
7. **Cross-check + critic loop** — score each claim by **independent host count + domain
   diversity + recency + primary-vs-secondary**; disagreement → `disputed`; uncovered
   sub-questions → new queries → loop until coverage or budget. This is exactly what
   `cortex.py`'s `LOOP_SIGNATURE_LIMIT = 3` currently punishes — research tools must be exempt
   (the same fix already made for `gui_scroll`).
8. **Report compiler + persistence** — outline → per-section reduce → inline citations →
   MD/PPT through `presentation_builder.py`; plus a **run manifest on disk** so a 4-hour T4 job
   survives a PM2 restart and resumes instead of dying silently.

## 5. What is NOT possible free, on this machine (so the UI never promises it)

- No free tier gives Google-fresh global coverage. Common Crawl / OWI are **snapshots** (weeks
  old) and far too large to host locally — they are queried, not owned.
- X/Twitter, Instagram, LinkedIn, most paywalled journalism: auth or bot walls. Only snippets,
  Wayback, or licensed OA copies.
- Brave Search is **no longer free** for new keys (Feb 2026) — do not build on it.
- Free LLM RPM caps make T4 slow even when fetching is free; the reducer must spread across
  Groq/Gemini/OpenRouter/NVIDIA/xkiro with per-provider backoff.
- 30-50× is achievable in **breadth**. In *accuracy* the ceiling is claim-extraction discipline
  and cross-checking, not source count — 1,338 sources of one wire story is still one source.
- Google captcha still blocks the browser path (existing wall, unrelated to research).

## 6. Where this plugs into the console UI we designed

| UI element | New data it needs |
|---|---|
| Tier selector chips (`LOOKUP · SEARCH · DEEP · EXHAUSTIVE · SWEEP`) | chosen tier + `est_sources`, `est_minutes` from the depth controller |
| Provider bus rows (replaces the single `1 of 3 keys` chip) | per provider: `quota_used/quota_max`, `backoff_s`, `ok/fail` counts, `needs_key` |
| EVIDENCE ledger | per source: `host`, `ok`, `bytes`, `ms`, `http_status`, `error`, `via=live\|wayback\|cc` |
| ANSWER claim cards | computed `cross_checked / single_source / disputed` from the claim store, not from the model |
| Footer verified strip | `VERIFIED n/m sources · claims · disputed k · provider mix` |
| T3/T4 runs | `resume_token`, `elapsed_s`, `eta_s`, `resumable: true` badge |

Backend contract to add later: `STATE.research_run = {tier, budget, providers[], sources_ok,
sources_fail, claims_total, cross_checked, disputed, elapsed_s, eta_s, resume_token}` — the
console renders whatever exists and shows an honest empty state when it does not.

## 7. Build order — smallest thing that changes the answer first

| # | Step | Why first | Verify |
|---|---|---|---|
| 1 | `web_fetch.py`: local requests + trafilatura, 8 workers, per-host throttle, Wayback fallback | kills the quota wall instantly, no key | fetch 40 real URLs, assert ≥30 non-empty markdown, each with `http_status` |
| 2 | `providers/ddgs.py` + self-hosted SearXNG behind one bus interface | unlimited-ish query supply, keyless | 20 queries, assert results + honest fail rows when throttled |
| 3 | Claim store (SQLite) + dedup/MinHash | makes 1,000 sources mean something | 200 pages → report duplicate-collapse count |
| 4 | Tier controller + budgets wired to `research` route | "prompt ke anusaar" | T0 vs T3 on the same sentence: different query counts, both finish |
| 5 | Keyless verticals: OpenAlex, Crossref, GDELT, EDGAR, Wikipedia, HN, Wayback CDX | the actual depth, zero cost | each provider returns ≥1 real row for a fixed probe query |
| 6 | Critic loop + `LOOP_EXEMPT_TOOLS` for research tools | stops the loop guard killing legitimate re-search | a T2 run that iterates ≥2 rounds and terminates on coverage |
| 7 | Resumable run manifest + scheduler for T4 overnight | T4 is hours, not seconds | kill PM2 mid-run, restart, run resumes from the manifest |
| 8 | Transcripts + PDFs/OCR into the same claim store | free corpus nobody else indexes | one video + one scanned PDF produce claim rows |
| 9 | Console wiring (the PNG layout) | renders the truth | live `/api/voice-state` dump matches the pixels |

**Highest leverage per hour of work: steps 1 + 2.** They remove the 402 wall and the 1,000/mo
ceiling in one move, and everything after that is depth, not plumbing.

## 8. Sources checked (2026-10-19)

- [Brave: best web search APIs for AI in 2026](https://brave.com/learn/best-search-api-2026/) ·
  [PSA: Brave Search API no longer free](https://www.reddit.com/r/openclaw/comments/1r340jz/psa_brave_search_api_no_longer_free_other_changes/)
- [Firecrawl: best web search APIs 2026 (Tavily 1,000/mo)](https://www.firecrawl.dev/blog/best-web-search-apis) ·
  [Exa: best web search tools for AI agents](https://exa.ai/blog/best-web-search-tools-for-ai-agents) ·
  [Search API rate limits in 2026 compared](https://keirolabs.cloud/blog/search-api-rate-limits-2026)
- [OpenAlex](https://openalex.org/) · [OpenAlex free API, 100k calls/day guidance](https://libguides.ucalgary.ca/c.php?g=732144&p=5260804) ·
  [Semantic Scholar Academic Graph API](https://www.semanticscholar.org/product/api) ·
  [measured S2 rate limits](https://casrai.org/guides/semantic-scholar-api) ·
  [CORE provider notes, 250M+ OA papers](https://github.com/zoharbabin/web-researcher-mcp/issues/267)
- [Common Crawl](https://commoncrawl.org/) · [Common Crawl Index/CDX server](https://index.commoncrawl.org/) ·
  [Open Web Index in a nutshell](https://openwebsearch.eu/open-webindex/) ·
  [Open Search Foundation: OWI 1.3 PB and partner projects](https://opensearchfoundation.org/ows-project-results/)
- [Wayback CDX server README](https://github.com/internetarchive/wayback/blob/master/wayback-cdx-server/README.md) ·
  [Web archiving in 2026 (CDX ~60 req/min, 429)](https://archivarix.com/en/blog/webarchive-2026/)
- [SearXNG docs](https://searxng.org/) · [SearXNG as agent search infrastructure](https://till-freitag.com/en/blog/searxng-agent-search) ·
  [self-host SearXNG, no key no quota](https://www.ssdnodes.com/learn/searxng-self-hosted-search)
- [ddgs metasearch library](https://github.com/deedy5/ddgs) · [duckduckgo-search on PyPI](https://pypi.org/project/duckduckgo-search/) ·
  [DuckDuckGo API developer guide 2026](https://iproyal.com/blog/duckduckgo-api/)
- [Jina Reader](https://jina.ai/reader/) · [jina-ai/reader](https://github.com/jina-ai/reader) ·
  [Firecrawl vs Jina Reader](https://blog.apify.com/jina-ai-vs-firecrawl/)
- [GPT Researcher](https://github.com/assafelovic/gpt-researcher) · [LangChain Open Deep Research](https://www.langchain.com/blog/open-deep-research) ·
  [HF: open-source DeepResearch](https://huggingface.co/blog/open-deep-research) ·
  [12 self-hosted deep-research systems compared](https://www.glukhov.org/ai-systems/comparisons/deep-research-with-ai/) ·
  [state of local research tools, May 2026](https://www.reddit.com/r/LocalLLaMA/comments/1t4e83m/current_state_of_local_research_tools_as_of_may/)
- [youtube-transcript-api](https://github.com/jdepoix/youtube-transcript-api) ·
  [best YouTube transcript extractors 2026](https://www.firecrawl.dev/blog/best-youtube-transcript-extractors)
