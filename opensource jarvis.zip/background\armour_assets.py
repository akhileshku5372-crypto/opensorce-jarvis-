"""Phase 5 - armour model assets: what is REALLY on disk.

The Armour Studio viewport is honest by construction, and this module is where
that honesty is decided. There is no Iron Man model in this repository and none
can be downloaded here, so:

* `list_models()` returns only real .glb/.gltf files it can see, each with its
  real byte size. An empty list is an empty list - never a bundled sample
  pretending to be a model.
* `resolve()` accepts only a bare file name inside the model folder. Anything
  with a separator, a drive letter or ".." is refused, so a crafted HTTP request
  cannot walk out of the folder.
* The dashboard renders procedurally built placeholder geometry when the list is
  empty, and labels it as a placeholder in the UI.

Model folder: ``<repo>/artifacts/3d`` (override with ``JARVIS_3D_MODELS``).
"""

from __future__ import annotations

import os
from pathlib import Path

MODEL_EXTS = {".glb", ".gltf"}
MODELS_ENV = "JARVIS_3D_MODELS"
MAX_BYTES = 200 * 1024 * 1024        # a 200 MB+ model is not a viewport asset
REPO = Path(__file__).resolve().parent.parent
CONTENT_TYPES = {
    ".glb": "model/gltf-binary",
    ".gltf": "model/gltf+json",
}


def models_dir() -> Path:
    """Folder holding user-supplied armour models."""
    configured = (os.environ.get(MODELS_ENV) or "").strip()
    path = Path(configured) if configured else REPO / "artifacts" / "3d"
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return path


def list_models() -> list:
    """Real model files, smallest name first. Never a fabricated entry."""
    folder = models_dir()
    rows = []
    try:
        entries = sorted(folder.iterdir(), key=lambda p: p.name.casefold())
    except Exception:
        return rows
    for path in entries:
        try:
            if not path.is_file() or path.suffix.lower() not in MODEL_EXTS:
                continue
            size = path.stat().st_size
        except OSError:
            continue
        if size <= 0 or size > MAX_BYTES:
            continue
        rows.append({"name": path.name, "bytes": size,
                     "ext": path.suffix.lower()})
    return rows


def resolve(name: str):
    """Path for a listed model, or None when the name is not allowed.

    Refuses separators, drive letters and any traversal, then re-checks that the
    resolved path really sits inside the model folder. Both checks are kept: the
    first is cheap, the second is the one that actually holds.
    """
    name = (name or "").strip()
    if not name or name in (".", ".."):
        return None
    if any(ch in name for ch in ("/", "\\", ":", "\0")):
        return None
    if Path(name).suffix.lower() not in MODEL_EXTS:
        return None
    folder = models_dir().resolve()
    try:
        candidate = (folder / name).resolve()
    except Exception:
        return None
    if candidate.parent != folder or not candidate.is_file():
        return None
    try:
        if not (0 < candidate.stat().st_size <= MAX_BYTES):
            return None
    except OSError:
        return None
    return candidate


def content_type(path: Path) -> str:
    return CONTENT_TYPES.get(path.suffix.lower(), "application/octet-stream")


def status() -> dict:
    """Honest report for the Modules card and GET /armour/models."""
    folder = models_dir()
    models = list_models()
    return {
        "dir": str(folder),
        "exists": folder.is_dir(),
        "models": models,
        "count": len(models),
        # The reason string the card shows: the viewport works, the Iron Man
        # asset is not here, and only the owner can add it.
        "note": ("no model file yet - drop a .glb/.gltf in %s (or set %s); "
                 "until then the viewport shows labelled placeholder geometry"
                 % (folder, MODELS_ENV)) if not models else
                ("%d real model file(s) in %s" % (len(models), folder)),
    }