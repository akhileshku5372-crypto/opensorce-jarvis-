/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SubsystemId, SubsystemInfo } from '../../types/jarvis';
import { soundFx } from '../../services/soundEffects';

interface CentralHologramDiagramProps {
  subsystems: Record<SubsystemId, SubsystemInfo>;
  selectedSubsystemId: SubsystemId | null;
  onSelectSubsystem: (id: SubsystemId) => void;
}

export const CentralHologramDiagram: React.FC<CentralHologramDiagramProps> = ({
  subsystems,
  selectedSubsystemId,
  onSelectSubsystem,
}) => {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
      {/* Background Holographic Coordinate Radar Rings */}
      <div className="relative w-[360px] h-[360px] sm:w-[460px] sm:h-[460px] flex items-center justify-center">
        {/* Concentric Reticles */}
        <div className="absolute inset-0 rounded-full border border-cyan-500/15 animate-arc-rotate" />
        <div className="absolute inset-6 rounded-full border border-dashed border-cyan-400/20" />
        <div className="absolute inset-16 rounded-full border border-cyan-500/10" />
        <div className="absolute inset-28 rounded-full border border-dotted border-cyan-400/15 animate-pulse-slow" />

        {/* Crosshair coordinate markers */}
        <div className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />
        <div className="absolute h-full w-[1px] bg-gradient-to-b from-transparent via-cyan-500/20 to-transparent" />

        {/* Central Glowing Brain Silhouette & Synapse Nodes */}
        <svg
          viewBox="0 0 500 500"
          className="w-full h-full filter drop-shadow-[0_0_25px_rgba(6,182,212,0.4)]"
        >
          <defs>
            <radialGradient id="brainGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
              <stop offset="60%" stopColor="#0284c7" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#030712" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="axonPulse" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.4" />
            </linearGradient>
          </defs>

          {/* Ambient Core Glow */}
          <circle cx="250" cy="240" r="160" fill="url(#brainGlow)" />

          {/* Cortical Outer Folds / Gyri Silhouette Paths */}
          <path
            d="M 230 110 C 290 100 360 120 380 170 C 400 220 395 280 360 320 C 330 355 290 365 270 395 C 255 415 240 415 235 390 C 220 365 190 365 160 340 C 130 310 115 260 125 210 C 135 155 180 120 230 110 Z"
            fill="none"
            stroke="#0ea5e9"
            strokeWidth="1.5"
            strokeDasharray="4 3"
            opacity="0.5"
          />

          {/* Internal Hemispheric & Lobe Sulci Folds */}
          <path
            d="M 230 110 Q 240 240 250 380"
            fill="none"
            stroke="#38bdf8"
            strokeWidth="1.2"
            opacity="0.4"
          />
          <path
            d="M 160 210 Q 240 220 340 190"
            fill="none"
            stroke="#06b6d4"
            strokeWidth="1"
            opacity="0.35"
          />
          <path
            d="M 150 270 Q 250 280 350 260"
            fill="none"
            stroke="#a855f7"
            strokeWidth="1"
            opacity="0.35"
          />
          <path
            d="M 180 160 Q 270 170 320 230"
            fill="none"
            stroke="#10b981"
            strokeWidth="1"
            opacity="0.3"
          />

          {/* Synaptic Pathway Curves Connecting Nodes */}
          {Object.entries(subsystems).map(([id, sub], index) => {
            const angle = (index / 8) * Math.PI * 2;
            const x = 250 + Math.cos(angle) * 110;
            const y = 240 + Math.sin(angle) * 95;
            const isSelected = selectedSubsystemId === id;

            return (
              <g key={id}>
                {/* Connecting axon to center core */}
                <line
                  x1="250"
                  y1="240"
                  x2={x}
                  y2={y}
                  stroke={sub.color}
                  strokeWidth={isSelected ? '2' : '1'}
                  opacity={isSelected ? '0.9' : '0.4'}
                />

                {/* Subsystem Node Circle */}
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? '9' : '6'}
                  fill={sub.color}
                  opacity="0.9"
                  className="transition-all"
                />
                <circle
                  cx={x}
                  cy={y}
                  r={isSelected ? '15' : '10'}
                  fill="none"
                  stroke={sub.color}
                  strokeWidth="1.5"
                  opacity={isSelected ? '0.9' : '0.5'}
                  className={isSelected ? 'animate-ping' : ''}
                />
              </g>
            );
          })}

          {/* Central Nucleus / Limbic Core */}
          <circle
            cx="250"
            cy="240"
            r="12"
            fill="#38bdf8"
            opacity="0.9"
            className="animate-pulse"
          />
          <circle
            cx="250"
            cy="240"
            r="22"
            fill="none"
            stroke="#38bdf8"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
        </svg>

        {/* Ambient Holographic Glow */}
        <div className="absolute inset-0 bg-cyan-500/5 rounded-full filter blur-3xl pointer-events-none" />
      </div>
    </div>
  );
};
