"""Scheduler Core + Automation Studio: real one-shot and recurring voice timers.

Backs three catalog cards honestly:
  * "Scheduler Core"     - one-shot + recurring timers, spoken when they fire
  * "Automation Studio"  - saved, named voice workflows with run history
  * "Command Composer"   - an ordered macro of existing JARVIS commands

Design constraints (AGENTS.md):
  * stdlib only, no APScheduler requirement
  * NO shell, no argv, no filesystem path from the user. A timer stores a
    COMMAND STRING, which is handed back to the voice engine to submit through
    the normal run_command() path - so the power guard, the duplicate-action
    suppression and every confirm gate still apply. This module never executes
    anything itself; it only decides *when*.
  * state is a small JSON file under artifacts/ so it survives a restart
"""
from __future__ import annotations

import json
import re
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATE_DIR = ROOT / "artifacts" / "scheduler"
STATE_PATH = STATE_DIR / "state.json"

_lock = threading.RLock()
_timers = {}          # id -> timer record
_workflows = {}        # name -> workflow record
_runs = []             # append-only run history (oldest first)
_MAX_RUNS = 200

_UNITS = {"s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
          "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
          "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
          "d": 86400, "day": 86400, "days": 86400}

_DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


# ── persistence ─────────────────────────────────────────────────────────────
def _load() -> None:
    with _lock:
        if _timers or _workflows or _runs:
            return
        try:
            data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            return
        if not isinstance(data, dict):
            return
        for row in data.get("runs") or []:
            if isinstance(row, dict):
                _runs.append(row)
        for row in data.get("workflows") or []:
            if isinstance(row, dict) and row.get("name"):
                _workflows[str(row["name"])] = row
        # A one-shot timer whose deadline passed while the process was down
        # cannot be honoured honestly, so only recurring timers are restored.
        for row in data.get("timers") or []:
            if isinstance(row, dict) and row.get("recurring"):
                _create(row.get("command", ""), interval_s=row.get("interval_s"),
                        label=row.get("label", ""))


# Runtime-only keys: live thread handles and similar objects that must never
# be written to disk. `default=str` would silently persist a repr like
# "<Timer(Thread-82, started daemon 46336)>", which then round-trips as junk
# state and makes the on-disk file disagree with the in-memory API.
_RUNTIME_KEYS = ("_timer",)


def _persistable(row) -> dict:
    """A JSON-safe copy of one timer/workflow with runtime handles removed."""
    if not isinstance(row, dict):
        return {}
    return {k: v for k, v in row.items()
            if k not in _RUNTIME_KEYS and not k.startswith("_timer")}


def _save() -> None:
    with _lock:
        payload = {"timers": [_persistable(t) for t in _timers.values()],
                   "workflows": [_persistable(w) for w in _workflows.values()],
                   "runs": _runs[-_MAX_RUNS:],
                   "updated_at": time.time()}
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(payload, indent=2, default=str),
                              encoding="utf-8")
    except Exception:
        pass


# ── parsing ─────────────────────────────────────────────────────────────────
def parse_duration(text: str) -> float:
    """'10m', 'in 2 hours', '90s' -> seconds. 0.0 when it is not a duration."""
    raw = str(text or "").strip().lower().replace(",", " ")
    if not raw:
        return 0.0
    for prefix in ("in ", "after ", "for "):
        if raw.startswith(prefix):
            raw = raw[len(prefix):].strip()
    total = 0.0
    found = False
    for amount, unit in re.findall(r"(\d+(?:\.\d+)?)\s*([a-z]+)", raw):
        factor = _UNITS.get(unit) or _UNITS.get(unit.rstrip("s"))
        if factor:
            total += float(amount) * factor
            found = True
    return total if found else 0.0


def _next_weekday_time(days, hour=9, minute=0) -> float:
    """Next occurrence (epoch seconds) of hour:minute on one of `days`."""
    import datetime as _dt
    wanted = {str(d)[:3] for d in days}
    now = _dt.datetime.now()
    for offset in range(0, 8):
        try:
            day = (now + _dt.timedelta(days=offset)).replace(
                hour=hour, minute=minute, second=0, microsecond=0)
        except (OverflowError, ValueError):
            continue
        if day.strftime("%a").lower()[:3] in wanted and day > now:
            return day.timestamp()
    return now.timestamp() + 86400


# ── timers ──────────────────────────────────────────────────────────────────
def _create(command: str, delay_s: float = 0.0, at: float = None,
            interval_s: float = None, label: str = "") -> dict:
    """Build and arm one timer. Deadlines are computed by the caller."""
    now = time.time()
    if interval_s:
        fire_at = now + float(interval_s)
    elif at is not None:
        fire_at = float(at)
    else:
        fire_at = now + max(1.0, float(delay_s or 1.0))
    record = {
        "id": "tmr_" + uuid.uuid4().hex[:10],
        "command": str(command or "").strip()[:400],
        "label": str(label or "").strip()[:80],
        "fire_at": fire_at,
        "interval_s": float(interval_s) if interval_s else None,
        "recurring": bool(interval_s),
        "created_at": now, "armed": True, "fired": 0,
    }
    with _lock:
        _timers[record["id"]] = record

    def _fire() -> None:
        with _lock:
            live = _timers.get(record["id"])
            if live is None or not live.get("armed"):
                return
            if live.get("recurring"):
                live["fire_at"] = time.time() + (live.get("interval_s") or 3600)
                live["fired"] = int(live.get("fired") or 0) + 1
            else:
                _timers.pop(record["id"], None)
        record_run(record["id"], record["command"], "fired")
        _save()
        _dispatch(record)

    timer = threading.Timer(max(0.2, fire_at - now), _fire)
    timer.daemon = True
    timer.start()
    record["_timer"] = timer
    return record


def _dispatch(record: dict) -> None:
    """Hand the command back to the voice engine's normal submit path.

    This module deliberately does NOT execute the command. Submitting it
    through voice_engine keeps the power guard, the confirm gate and the
    duplicate-action suppression in charge.
    """
    import sys
    # Prefer the LIVE engine in this very process. voice_engine runs as
    # __main__, so looking it up only by the cowork key would MISS it and
    # import a SECOND copy of the brain - which AGENTS.md forbids. We accept
    # the live module only if it really is the running engine (it exposes
    # submit_command), so importing it here can never start a second voice
    # loop, a second microphone or a second memory.
    engine = None
    live = sys.modules.get("__main__")
    if live is not None and hasattr(live, "submit_command"):
        engine = live
    if engine is None:
        engine = sys.modules.get("jarvis_cowork_voice_engine")
    if engine is None:
        return
    submit = getattr(engine, "submit_command", None)
    if not callable(submit):
        return
    args = getattr(engine, "ARGS", None)
    try:
        submit(record.get("command", ""),
               getattr(args, "ui", True), getattr(args, "bridge", True), "timer")
    except Exception:
        pass


def set_timer(command: str, seconds: float = 0.0, label: str = "",
              fire_at: float = None, interval_s: float = None) -> dict:
    """Public entry: arm a one-shot or recurring timer for a COMMAND STRING."""
    cmd = str(command or "").strip()[:400]
    if not cmd:
        return {"ok": False, "error": "no command given"}
    _load()
    if interval_s:
        if float(interval_s) < 5:
            return {"ok": False,
                    "error": "recurring interval must be 5 seconds or more"}
        record = _create(cmd, interval_s=float(interval_s), label=label)
    elif fire_at:
        if float(fire_at) <= time.time():
            return {"ok": False, "error": "that time is already in the past"}
        record = _create(cmd, at=float(fire_at), label=label)
    else:
        if float(seconds or 0) <= 0:
            return {"ok": False, "error": "duration must be greater than zero"}
        record = _create(cmd, delay_s=float(seconds), label=label)
    _save()
    return {"ok": True, "timer": _public(record)}


def schedule_every(command: str, every: str, label: str = "") -> dict:
    """schedule_every("what is the time", "30m") -> recurring timer."""
    seconds = parse_duration(every)
    if seconds <= 0:
        return {"ok": False,
                "error": "could not read the interval '%s'" % (every or "")}
    return set_timer(command, interval_s=seconds, label=label)


def _one_day():
    import datetime as _dt
    return _dt.timedelta(days=1)


def schedule_at(command: str, when: str) -> dict:
    """Accepts '09:30' (today if still ahead, else tomorrow) or 'mon 09:30'."""
    text = str(when or "").strip().lower()
    clock = re.search(r"(\d{1,2}):(\d{2})", text)
    if not clock:
        return {"ok": False, "error": "time must look like 09:30"}
    hour, minute = int(clock.group(1)), int(clock.group(2))
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return {"ok": False, "error": "that is not a valid time of day"}
    for day in _DAYS:
        if day in text:
            return set_timer(command, fire_at=_next_weekday_time([day], hour, minute),
                             label=command)
    now = datetime.now()
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        target = target + _one_day()
    return set_timer(command, fire_at=target.timestamp(), label=command)


def cancel(timer_id: str) -> dict:
    with _lock:
        record = _timers.pop(str(timer_id or "").strip(), None)
    if record is None:
        return {"ok": False, "error": "no timer with that id"}
    native = record.get("_timer")
    if native is not None:
        try:
            native.cancel()
        except Exception:
            pass
    _save()
    return {"ok": True, "cancelled": record["id"]}


def _public(record: dict) -> dict:
    fire_at = record.get("fire_at")
    return {"id": record.get("id"), "command": record.get("command", ""),
            "label": record.get("label", ""), "fire_at": fire_at,
            "in_seconds": int(max(0, (fire_at or 0) - time.time())),
            "interval_s": record.get("interval_s"),
            "recurring": bool(record.get("recurring")),
            "fired": int(record.get("fired") or 0)}


def timers() -> list:
    _load()
    with _lock:
        return sorted((_public(r) for r in _timers.values()),
                      key=lambda r: r.get("fire_at") or 0)


# ── workflows (Automation Studio / Command Composer) ────────────────────────
def save_workflow(name: str, steps: list) -> dict:
    """Save an ordered list of COMMAND STRINGS. Nothing runs at save time."""
    label = str(name or "").strip()[:64]
    if not label:
        return {"ok": False, "error": "workflow needs a name"}
    if isinstance(steps, str):
        steps = [steps]
    clean = [str(s).strip()[:400] for s in (steps or [])
             if isinstance(s, str) and s.strip()]
    if not clean:
        return {"ok": False, "error": "workflow needs at least one step"}
    with _lock:
        _workflows[label] = {"name": label, "steps": clean[:25],
                             "updated_at": time.time(),
                             "runs": int(_workflows.get(label, {}).get("runs") or 0)}
    _save()
    return {"ok": True, "workflow": dict(_workflows[label])}


def run_workflow(name: str) -> dict:
    """Return the ordered steps for the caller to submit one by one.

    Steps are NOT executed here - the voice engine submits each one through
    run_command() so every confirm gate and dedupe rule still applies.
    """
    label = str(name or "").strip()
    with _lock:
        workflow = _workflows.get(label)
        if workflow is None:
            return {"ok": False, "error": "no workflow named '%s'" % label}
        steps = list(workflow.get("steps") or [])
        workflow["runs"] = int(workflow.get("runs") or 0) + 1
    record_run("wf:" + label, " / ".join(steps), "workflow")
    _save()
    return {"ok": True, "name": label, "steps": steps, "count": len(steps)}


def delete_workflow(name: str) -> dict:
    with _lock:
        removed = _workflows.pop(str(name or "").strip(), None)
    _save()
    return {"ok": removed is not None,
            "error": "" if removed else "no workflow with that name"}


def workflows() -> list:
    _load()
    with _lock:
        return sorted(({"name": w["name"], "steps": w.get("steps") or [],
                        "runs": int(w.get("runs") or 0),
                        "updated_at": w.get("updated_at")}
                       for w in _workflows.values()),
                      key=lambda r: r["name"].lower())


# ── run history ─────────────────────────────────────────────────────────────
def record_run(ref: str, detail: str, kind: str) -> dict:
    entry = {"at": time.time(),
             "iso": datetime.now().isoformat(timespec="seconds"),
             "ref": str(ref or "")[:64], "kind": str(kind or "")[:24],
             "detail": str(detail or "")[:400]}
    with _lock:
        _runs.append(entry)
        del _runs[:-_MAX_RUNS]
    return entry


def history(limit: int = 30) -> list:
    _load()
    with _lock:
        return list(_runs[-max(1, min(200, int(limit or 30))):])


def status() -> dict:
    _load()
    with _lock:
        return {"ok": True, "source": "local", "timers": len(_timers),
                "workflows": len(_workflows), "runs": len(_runs),
                "state_path": str(STATE_PATH)}


def describe() -> str:
    snap = status()
    return ("Sir, scheduler: %d timer(s) armed, %d saved workflow(s), "
            "%d run(s) in history."
            % (snap["timers"], snap["workflows"], snap["runs"]))


# ── cortex tool specs ───────────────────────────────────────────────────────
def _ok_line(out: dict) -> str:
    if "timer" in out:
        timer = out["timer"]
        kind = ("every %ss" % timer["interval_s"]) if timer.get("recurring") \
            else ("in %ds" % timer["in_seconds"])
        return "Sir, timer set: %s (%s)." % (timer.get("command", "")[:80], kind)
    if "steps" in out:
        return "Sir, workflow '%s' has %d step(s)." % (out.get("name", ""),
                                                       out["count"])
    if "workflow" in out:
        return "Sir, workflow '%s' saved with %d step(s)." % (
            out["workflow"]["name"], len(out["workflow"]["steps"]))
    if out.get("cancelled"):
        return "Sir, timer cancelled."
    return "Scheduler updated, Sir."


def _result(out: dict) -> dict:
    if not out.get("ok"):
        return {"ok": False, "output": out.get("error") or "scheduler call failed"}
    return {"ok": True, "output": _ok_line(out), "data": out}


def _tool_set_timer(args: dict) -> dict:
    args = args or {}
    interval = args.get("interval_s")
    return _result(set_timer(
        args.get("command", ""), seconds=float(args.get("seconds") or 0),
        label=args.get("label", ""),
        interval_s=float(interval) if interval else None))


def _tool_schedule_every(args: dict) -> dict:
    args = args or {}
    return _result(schedule_every(args.get("command", ""), args.get("every", ""),
                                  args.get("label", "")))


def _tool_schedule_at(args: dict) -> dict:
    args = args or {}
    return _result(schedule_at(args.get("command", ""), args.get("when", "")))


def _tool_cancel(args: dict) -> dict:
    return _result(cancel((args or {}).get("id", "")))


def _tool_save_workflow(args: dict) -> dict:
    args = args or {}
    return _result(save_workflow(args.get("name", ""), args.get("steps") or []))


def _tool_run_workflow(args: dict) -> dict:
    return _result(run_workflow((args or {}).get("name", "")))


def _tool_scheduler_status(args: dict) -> dict:
    return {"ok": True, "output": describe(),
            "data": {"ok": True, **status(),
                     "timer_list": timers(), "workflow_list": workflows(),
                     "history": history(20)}}


def specs() -> list:
    """cortex ToolSpec list.

    Arming/cancelling a timer and running a saved workflow all change machine
    or conversational state, so they are confirm-gated exactly like the rest
    of the write side of the registry. Reading status is free.
    """
    cortex = _load_cortex()
    return [
        cortex.ToolSpec("scheduler_set_timer",
                        "Arm a one-shot or recurring timer for a JARVIS command string.",
                        _tool_set_timer,
                        parameters={"command": "the command to submit when it fires",
                                    "seconds": "one-shot delay in seconds",
                                    "interval_s": "recurring interval in seconds (>=5)",
                                    "label": "optional label"},
                        requires_confirmation=True, timeout_s=15.0,
                        tags=("scheduler", "automation")),
        cortex.ToolSpec("scheduler_repeat",
                        "Repeat a command on an interval, e.g. '30m'.",
                        _tool_schedule_every,
                        parameters={"command": "command to repeat",
                                    "every": "interval like 30m, 2h, 1d",
                                    "label": "optional label"},
                        requires_confirmation=True, timeout_s=15.0,
                        tags=("scheduler", "automation")),
        cortex.ToolSpec("scheduler_at",
                        "Schedule a command for a clock time, e.g. '09:30' or 'mon 09:30'.",
                        _tool_schedule_at,
                        parameters={"command": "command to run",
                                    "when": "clock time, optionally with a weekday"},
                        requires_confirmation=True, timeout_s=15.0,
                        tags=("scheduler", "automation")),
        cortex.ToolSpec("scheduler_cancel", "Cancel an armed timer by id.",
                        _tool_cancel, parameters={"id": "timer id"},
                        requires_confirmation=False, timeout_s=10.0,
                        tags=("scheduler",)),
        cortex.ToolSpec("automation_save_workflow",
                        "Save a named, ordered list of commands (no execution).",
                        _tool_save_workflow,
                        parameters={"name": "workflow name", "steps": "list of commands"},
                        requires_confirmation=True, timeout_s=15.0,
                        tags=("automation", "scheduler")),
        cortex.ToolSpec("automation_run_workflow",
                        "Return the ordered steps of a saved workflow to run.",
                        _tool_run_workflow, parameters={"name": "workflow name"},
                        requires_confirmation=True, timeout_s=15.0,
                        tags=("automation", "scheduler")),
        cortex.ToolSpec("scheduler_status",
                        "Armed timers, saved workflows and run history.",
                        _tool_scheduler_status, parameters={},
                        requires_confirmation=False, timeout_s=15.0,
                        tags=("scheduler", "automation")),
    ]


def _load_cortex():
    """Single shared cortex module - classes must be identical everywhere."""
    import importlib.util
    import sys
    name = "jarvis_cowork_cortex"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "cortex.py"
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


cortex = _load_cortex()



