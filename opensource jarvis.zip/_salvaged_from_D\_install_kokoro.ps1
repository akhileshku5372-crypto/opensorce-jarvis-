# KamiSensei Local Podcast Engine - Kokoro-82M installer (100% offline TTS).
# Run from repo root:  powershell -NoProfile -ExecutionPolicy Bypass -File _install_kokoro.ps1
#
# WHY A DEDICATED PYTHON 3.11 VENV:
# kokoro 0.9.4 and misaki 0.9.4 both declare Requires-Python >=3.10,<3.13,
# and every older pair drags a C-extension without Python 3.13 wheels
# (numpy==1.26.4 pin, piper-phonemize, mojimoji, pyopenjtalk). The machine's
# default `python` is 3.13 (Microsoft Store), so the original
# `pip install kokoro soundfile "misaki[ja]"` aborts there.
# This installer creates a proper Python 3.11 venv (.kokoro-env) using the
# uv-managed CPython 3.11 when available, then installs the official wheel set:
#   kokoro==0.9.4, soundfile, scipy, fugashi, unidic-lite, "misaki[en]==0.9.4"
#   (pulls torch CPU, transformers, spacy, phonemizer-fork, espeakng-loader +
#   bundled espeak-ng.dll), and best-effort "misaki[ja]" for JP segments.
# Every step is checked; failures abort so the probe can never pass on a
# half-installed environment.
Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Path)
$log = "_pip_kokoro.log"
"=== kokoro install $(Get-Date -Format o) ===`n" | Out-File $log
$repo = (Get-Location).Path
$py = Join-Path $repo ".kokoro-env\Scripts\python.exe"

if (-not (Test-Path $py)) {
  Write-Host "[kokoro] creating Python 3.11 venv (.kokoro-env) ..."
  $uvPy = Get-ChildItem "$env:APPDATA\uv\python" -Directory -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -match 'cpython-3\.(11|12)' } |
      Sort-Object Name -Descending | Select-Object -First 1
  if (-not $uvPy) { Write-Error "[kokoro] no Python 3.11/3.12 found (install one: uv python install 3.11)."; exit 1 }
  $srcPy = Join-Path $uvPy.FullName "python.exe"
  Write-Host "[kokoro]   using $srcPy"
  & $srcPy -m venv "$repo\.kokoro-env"
  if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] venv creation FAILED"; exit 1 }
}

& $py --version *>> $log
if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] venv interpreter broken - see $log"; exit 1 }
Write-Host "[kokoro] engine interpreter: $py"

Write-Host "[kokoro] upgrading pip ..."
& $py -m pip install --upgrade pip *>> $log
if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] pip upgrade FAILED - see $log"; exit 1 }

Write-Host "[kokoro] installing kokoro 0.9.4 + misaki[en] + core runtime ..."
& $py -m pip install kokoro==0.9.4 soundfile scipy fugashi unidic-lite "misaki[en]==0.9.4" *>> $log
if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] kokoro/misaki[en] install FAILED - see $log"; exit 1 }

Write-Host "[kokoro] best-effort misaki[ja] (optional; Japan segments) ..."
& $py -m pip install "misaki[ja]" *>> $log
if ($LASTEXITCODE -ne 0) { Write-Host "[kokoro]   (skipped - JP segments will be skipped at runtime)"; "misaki[ja] skipped (exit $LASTEXITCODE)" | Out-File $log -Append }

# Import smoke-test on the venv interpreter. _probe_kokoro.py exits 1 on any
# broken/missing module, so this is the real gate before the engine starts.
Write-Host "[kokoro] running import probe ..."
& $py _probe_kokoro.py
if ($LASTEXITCODE -ne 0) { Write-Error "[kokoro] import probe FAILED - see $log"; exit 1 }

Write-Host "[kokoro] Installed OK." -ForegroundColor Green
Write-Host "[kokoro] Start engine:  .kokoro-env\Scripts\python.exe background\kokoro_podcast.py"
Write-Host "[kokoro] Health check:  curl http://127.0.0.1:7779/health"
"DONE (rc=0)`n" | Out-File $log -Append

