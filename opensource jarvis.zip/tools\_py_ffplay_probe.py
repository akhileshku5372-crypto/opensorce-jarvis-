"""Why does ffplay hang on playback? Generate a real mp3, then time ffplay."""
import os, subprocess, sys, time, tempfile
sys.path.insert(0, 'background')
# reuse edge-tts synth to make a real file
import asyncio
try:
    import edge_tts
except Exception as e:
    print('edge_tts import:', e); sys.exit(0)

async def _syn():
    c = edge_tts.Communicate('Hello Sir, JARVIS online. This is a playback timing test.',
                             'en-GB-RyanNeural')
    fd, path = tempfile.mkstemp(suffix='.mp3'); os.close(fd)
    await c.save(path)
    return path

path = asyncio.run(_syn())
print('mp3 bytes:', os.path.getsize(path))

FFPLAY = 'ffplay'
for extra, label in [([], 'default'), (['-nodisp','-autoexit','-loglevel','error'], 'nodisp-autoexit')]:
    cmd = [FFPLAY] + extra + [path]
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=0x08000000)
        out, err = p.communicate(timeout=12)
        dt = time.time() - t0
        print('ffplay %-20s rc=%s  %.2fs  err=%r' % (label, p.returncode, dt, err[:120]))
    except subprocess.TimeoutExpired:
        p.kill()
        print('ffplay %-20s HUNG >12s (this is the wedge)' % label)
os.remove(path)
print('DONE')
