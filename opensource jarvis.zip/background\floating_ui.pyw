#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JARVIS v0.8 desktop HUD.

Three independent, transparent, always-on-top Windows surfaces recreate the
reference layout without covering the usable desktop: an animated reactor orb
on the left, a glass conversation console on the right, and a click-through
screen-scan layer that covers every window while the core's real
screen_watch is enabled. All are clients of the single background core on
127.0.0.1:7780; they never capture the microphone or run a second AI/action
pipeline.

Controls: drag either HUD surface | double-click = dashboard | Enter = typed command
Mouse wheel scrolls the conversation feed. Panel minus collapses to orb-only
mode; the cyan chevron beside the orb (or a click on the orb itself) restores
the full panel. The panel has no close button - closing the HUD is only
possible through the right-click menu's explicit "Close HUD" item. A close
hides BOTH surfaces and keeps the process parked (PM2 must not restart it);
the dashboard HUD pill, Ctrl+Shift+J, or `npm run jarvis:floating` bring the
same HUD straight back (a manual close is remembered, so the tab-hidden
heartbeat never forces it back on its own); "Exit JARVIS" stops the
background engine.
"""
import argparse
import json
import math
import os
import re
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser

import tkinter as tk
from tkinter import font as tkfont

TRANS = "#010204"
TRANS_RGB = tuple(int(TRANS[index:index + 2], 16) for index in (1, 3, 5))
GWL_EXSTYLE = -20
WS_EX_TOPMOST = 0x00000008
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000
WDA_EXCLUDEFROMCAPTURE = 0x00000011
BG = "#050b11"
PANEL = "#07121b"
PANEL_2 = "#091823"
EDGE = "#14506a"
CYAN = "#17d9ff"
CYAN_SOFT = "#b9f5ff"
CYAN_DIM = "#0b6f8d"
GREEN = "#2af2ae"
ORANGE = "#ffad58"
RED = "#ff6472"
MUTE = "#607c89"
TEXT = "#e8f9ff"
GUARD_ADDR = ("127.0.0.1", 7781)
DIAG_PATH = os.path.join(
    os.environ.get("TEMP") or os.environ.get("TMP") or os.getcwd(),
    "jarvis_hud_diag.log",
)


def diag(message):
    """Persist HUD diagnostics because pythonw has no visible stderr console."""
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(DIAG_PATH, "a", encoding="utf-8") as handle:
        handle.write(f"[{stamp}] {message}\n")


STATUS_COLORS = {
    "idle": CYAN, "listening": CYAN, "thinking": ORANGE,
    "searching": "#7ce5ff", "executing": ORANGE, "working": ORANGE,
    "speaking": GREEN, "interrupted": ORANGE, "error": RED, "offline": MUTE,
    "sleeping": MUTE,
}
STATUS_LABELS = {
    "idle": "READY", "listening": "LISTENING", "thinking": "THINKING",
    "searching": "SEARCHING", "executing": "EXECUTING", "working": "EXECUTING",
    "speaking": "SPEAKING", "interrupted": "INTERRUPTED",
    "error": "ERROR", "offline": "OFFLINE",
    "sleeping": "SLEEPING",
}
TICK_MS = {
    "idle": 90, "listening": 45, "thinking": 55, "searching": 55,
    "executing": 55, "working": 55, "speaking": 45,
    "interrupted": 80, "error": 140, "offline": 220,
    "sleeping": 240,
}


def parse():
    parser = argparse.ArgumentParser(description="JARVIS floating desktop HUD")
    parser.add_argument("--state-port", type=int, default=int(os.environ.get("JARVIS_STATE_PORT", "7780")))
    parser.add_argument("--ui", default=os.environ.get("JARVIS_UI", "http://127.0.0.1:7777"))
    parser.add_argument("--from-auto", action="store_true",
                        help="spawned by the tab-hidden heartbeat, not by a "
                             "user ask: only 'peek' an existing HUD so a "
                             "manually-closed one is not resurrected")
    return parser.parse_args()


def clean_text(value):
    """Remove tool syntax, markup, URLs and machine payloads from visual speech."""
    text = str(value or "")
    text = re.sub(r"\[ACTION:[^\]]*\]", "", text, flags=re.IGNORECASE)
    text = re.sub(r"```.*?```", " ", text, flags=re.DOTALL)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"(?:https?://|www\.)\S+", "the requested website", text)
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_>{}\[\]]+", " ", text)
    return " ".join(text.split()).strip()


def wrap_lines(text, limit=45, max_lines=3):
    lines, current = [], ""
    for word in str(text or "").split():
        if len(current) + len(word) + bool(current) <= limit:
            current += (" " if current else "") + word
        else:
            if current:
                lines.append(current)
            current = word
            if len(lines) >= max_lines:
                break
    if current and len(lines) < max_lines:
        lines.append(current)
    shown = len(" ".join(lines))
    return lines[:max_lines], len(str(text or "")) > shown + 1


def rounded_rect(canvas, x1, y1, x2, y2, radius, **kwargs):
    points = [
        x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
        x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
        x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, **kwargs)


class FloatingUI:
    PANEL_W, PANEL_H = 390, 510
    ORB_W, ORB_H = 230, 262
    SCAN_EXTEND_SEC = 0.65
    SCAN_CYCLE_SEC = 2.6
    SCAN_TICK_MS = 33
    SCAN_LAYERS = ((12, "#003b4b"), (5, "#0099b8"), (2, "#00f0ff"))

    def __init__(self, port, ui, guard_socket):
        self.port = port
        self.ui = ui.rstrip("/")
        self.guard = guard_socket
        self.status = "offline"
        self.history = []          # (role, text, timestamp) — full scrollback feed
        self.active_task = ""
        self.action_name = ""      # live tool card (e.g. "YouTube")
        self.action_status = ""    # searching | executing | done
        self.top_results = []      # live result titles ("Top Results" card)
        self.mic_level = 0.0       # raw level from core state
        self._mic_display = 0.0    # smoothed for animation
        self.scroll = 0            # px from bottom; 0 = follow latest
        self.hidden = False         # both surfaces explicitly hidden
        self.panel_collapsed = False  # minimized mode keeps the live orb available
        self._last_event_id = 0
        self._clear_seq = 0          # Clear Chat sync: wipe history when the core bell changes
        self._clear_pulse = 0.0      # timestamp of the last wipe (brief "CHAT CLEARED" overlay)
        self._drag = {}
        self.screen_scan_enabled = False
        self.scan_overlay = None
        self.scan_canvas = None
        self.scan_overlay_visible = False
        self.scan_started = 0.0
        self.scan_size = (0, 0)
        self.scan_items = {"left": [], "right": [], "horizontal": []}

        # Local view: 'chat' = conversation feed, 'research' = research dossier,
        # 'system' = co-work deck (live task/channels/schedule/power-lock mirror),
        # 'demo' = demo-only concept rail (static preview, not wired to any backend).
        self.view = "chat"
        self.research = None         # latest research payload from core STATE
        self.research_seq = 0
        self.research_scroll = 0

        # Co-work deck state: a straight mirror of core STATE (same numbers the
        # dashboard Co-work panel shows). Empty registries stay empty here — no
        # invented rows, no fake task turns.
        self.cowork = {}
        self.cowork_revision = -1
        self.channels = []
        self.schedule_count = 0
        self.skills_revision = 0
        self.skills = []
        self.mcp_tools = []
        self.power_lock = True
        self.system_scroll = 0

        self.root = tk.Tk()
        self.root.title("J.A.R.V.I.S")
        self._configure_window(self.root)
        screen_w, screen_h = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        panel_x = max(18, screen_w - self.PANEL_W - 28)
        panel_y = max(18, (screen_h - self.PANEL_H) // 2 - 20)
        self.root.geometry(f"{self.PANEL_W}x{self.PANEL_H}+{panel_x}+{panel_y}")

        self.panel = tk.Canvas(self.root, width=self.PANEL_W, height=self.PANEL_H,
                               bg=TRANS, highlightthickness=0)
        self.panel.pack(fill="both", expand=True)
        self.command_var = tk.StringVar()
        self.command = tk.Entry(
            self.root, textvariable=self.command_var, bd=0, relief="flat",
            bg="#0b1720", fg=TEXT, insertbackground=CYAN,
            selectbackground=CYAN_DIM, font=("Segoe UI", 9),
        )
        self.command.place(x=27, y=self.PANEL_H - 54, width=self.PANEL_W - 74, height=31)
        self.command.bind("<Return>", self._submit_command)

        self.orb_window = tk.Toplevel(self.root)
        self.orb_window.title("J.A.R.V.I.S Voice Link")
        self._configure_window(self.orb_window)
        orb_x = max(20, int(screen_w * 0.075))
        orb_y = max(30, (screen_h - self.ORB_H) // 2)
        self.orb_window.geometry(f"{self.ORB_W}x{self.ORB_H}+{orb_x}+{orb_y}")
        self.orb = tk.Canvas(self.orb_window, width=self.ORB_W, height=self.ORB_H,
                             bg=TRANS, highlightthickness=0)
        self.orb.pack(fill="both", expand=True)
        self._create_scan_overlay()

        self._bind_surface(self.panel, self.root)
        self._bind_surface(self.orb, self.orb_window)
        self.panel.bind("<Button-1>", self._panel_click, add="+")
        self.orb.bind("<Button-1>", self._orb_click, add="+")
        self.root.bind("<Escape>", lambda _event: self.collapse_panel())
        self.panel.bind("<MouseWheel>", self._on_wheel)          # Windows/macOS
        self.panel.bind("<Button-4>", lambda _e: self._wheel(40))   # X11 up
        self.panel.bind("<Button-5>", lambda _e: self._wheel(-40))  # X11 down
        for surface in (self.panel, self.orb):
            surface.bind("<Double-Button-1>", lambda _event: self.restore_console())
            surface.bind("<Button-3>", self._show_menu)

    def _on_wheel(self, event):
        self._wheel(40 if event.delta > 0 else -40)

    def _wheel(self, amount):
        # Positive = towards older messages; clamped during draw.
        # The demo rail is a fixed static preview — nothing to scroll there.
        if self.view == "research":
            self.research_scroll = max(0, self.research_scroll + amount)
        elif self.view == "system":
            self.system_scroll = max(0, self.system_scroll + amount)
        elif self.view == "demo":
            pass
        else:
            self.scroll = max(0, self.scroll + amount)

    @staticmethod
    def _configure_window(window):
        window.overrideredirect(True)
        window.attributes("-topmost", True)
        window.configure(bg=TRANS)
        try:
            window.attributes("-alpha", 0.96)
            window.attributes("-transparentcolor", TRANS)
        except Exception:
            pass
        if sys.platform == "win32":
            try:
                import ctypes
                window.update_idletasks()
                hwnd = int(window.wm_frame(), 16)
                if hwnd:
                    ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0043)
                diag(f"Configured window {window} frame={window.wm_frame()} winfo_id={window.winfo_id()} hwnd={hwnd}")
            except Exception as e:
                diag(f"Failed configuring window {window}: {e}")

    @staticmethod
    def _screen_geometry(width, height, x, y):
        """Geometry for a window that may start on a monitor left of primary."""
        left = f"+{x}" if x >= 0 else str(x)
        top = f"+{y}" if y >= 0 else str(y)
        return f"{width}x{height}{left}{top}"

    def _virtual_screen_rect(self):
        """Cover the whole Windows desktop, including secondary monitors."""
        if sys.platform == "win32":
            try:
                import ctypes
                metrics = ctypes.windll.user32.GetSystemMetrics
                x, y, width, height = metrics(76), metrics(77), metrics(78), metrics(79)
                if width > 0 and height > 0:
                    return int(x), int(y), int(width), int(height)
            except Exception as exc:
                diag(f"virtual screen metrics failed: {type(exc).__name__}: {exc}")
        return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight()

    def _create_scan_overlay(self):
        """Build the one click-through scan surface, hidden until watch is on."""
        if sys.platform != "win32":
            return
        window = None
        try:
            x, y, width, height = self._virtual_screen_rect()
            window = tk.Toplevel(self.root)
            window.title("J.A.R.V.I.S Screen Scan")
            window.withdraw()
            window.overrideredirect(True)
            window.attributes("-topmost", True)
            window.configure(bg=TRANS)
            window.attributes("-alpha", 1.0)
            window.attributes("-transparentcolor", TRANS)
            try:
                window.attributes("-toolwindow", True)
            except Exception:
                pass
            window.geometry(self._screen_geometry(width, height, x, y))
            canvas = tk.Canvas(window, width=width, height=height,
                               bg=TRANS, highlightthickness=0)
            canvas.pack(fill="both", expand=True)
            for key in ("left", "right", "horizontal"):
                for line_width, color in self.SCAN_LAYERS:
                    endpoints = (0, 0, 0, height) if key != "horizontal" else (0, 0, width, 0)
                    item = canvas.create_line(*endpoints, fill=color, width=line_width,
                                              state="hidden")
                    self.scan_items[key].append((item, color))
            self.scan_overlay = window
            self.scan_canvas = canvas
            self.scan_size = (width, height)
            window.update_idletasks()
            self._make_scan_overlay_clickthrough(window)
            window.withdraw()
            diag(f"scan overlay ready rect={x},{y} {width}x{height} frame={window.wm_frame()}")
        except Exception as exc:
            diag(f"scan overlay creation failed: {type(exc).__name__}: {exc}")
            self.scan_overlay = None
            self.scan_canvas = None
            self.scan_items = {"left": [], "right": [], "horizontal": []}
            if window is not None:
                try:
                    window.destroy()
                except Exception:
                    pass

    def _make_scan_overlay_clickthrough(self, window):
        """Exclude the layer from input; keep it out of JARVIS's own captures."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            window.update_idletasks()
            hwnd = int(window.wm_frame(), 16)
            if not hwnd:
                diag("scan overlay has no HWND; click-through not applied")
                return
            user32 = ctypes.windll.user32
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style |= (WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW |
                      WS_EX_LAYERED | WS_EX_NOACTIVATE)
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0013)
            try:
                if not user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE):
                    diag("scan overlay capture exclusion was refused; OCR may see the lines")
            except Exception as exc:
                diag(f"scan overlay capture exclusion unavailable: {type(exc).__name__}: {exc}")
        except Exception as exc:
            diag(f"scan overlay click-through failed: {type(exc).__name__}: {exc}")

    def _raise_scan_overlay(self):
        if not self.scan_overlay_visible or self.scan_overlay is None:
            return
        if sys.platform != "win32":
            return
        try:
            import ctypes
            self.scan_overlay.update_idletasks()
            hwnd = int(self.scan_overlay.wm_frame(), 16)
            if hwnd:
                ctypes.windll.user32.SetWindowPos(
                    hwnd, -1, 0, 0, 0, 0, 0x0013)  # topmost, no move/size/activate
        except Exception:
            pass

    def _show_scan_overlay(self):
        if self.scan_overlay is None:
            return
        try:
            self.scan_overlay.deiconify()
            self.scan_overlay.attributes("-topmost", True)
            self.scan_overlay.update_idletasks()
            self._make_scan_overlay_clickthrough(self.scan_overlay)
            self.scan_overlay_visible = True
            self.scan_started = time.monotonic()
            self._raise_scan_overlay()
            self._draw_scan_overlay()
        except Exception as exc:
            diag(f"scan overlay show failed: {type(exc).__name__}: {exc}")
            self.scan_overlay_visible = False
            try:
                self.scan_overlay.withdraw()
            except Exception:
                pass

    def _hide_scan_overlay(self):
        if self.scan_overlay is not None:
            try:
                self.scan_overlay.withdraw()
            except Exception:
                pass
        self.scan_overlay_visible = False

    def _sync_scan_overlay(self):
        # The scan layer is owned by the real screen_watch state, not by the
        # conversation panel. Minimizing or closing the HUD must not hide the
        # animation while Live Screen is still reading the desktop.
        if self.screen_scan_enabled:
            if not self.scan_overlay_visible:
                self._show_scan_overlay()
        else:
            self._hide_scan_overlay()

    def _set_scan_enabled(self, enabled):
        enabled = bool(enabled)
        if enabled == self.screen_scan_enabled:
            return
        self.screen_scan_enabled = enabled
        self._sync_scan_overlay()

    @staticmethod
    def _blend_hex(color, alpha):
        alpha = max(0.0, min(1.0, alpha))
        red = int(color[1:3], 16)
        green = int(color[3:5], 16)
        blue = int(color[5:7], 16)
        channels = tuple(
            int(round(base + (foreground - base) * alpha))
            for base, foreground in zip(TRANS_RGB, (red, green, blue))
        )
        return "#%02x%02x%02x" % channels

    def _draw_scan_overlay(self):
        if not self.scan_overlay_visible or self.scan_canvas is None:
            return
        width, height = self.scan_size
        if width <= 1 or height <= 1:
            return
        canvas = self.scan_canvas
        elapsed = max(0.0, time.monotonic() - self.scan_started)
        extend = min(1.0, elapsed / self.SCAN_EXTEND_SEC)
        ease = 1.0 - (1.0 - extend) ** 3
        alpha = min(1.0, extend / 0.15)
        center = width / 2.0
        left_x = center + (1.0 - center) * ease
        right_x = center + ((width - 1.0) - center) * ease
        for key, x in (("left", left_x), ("right", right_x)):
            for item, color in self.scan_items[key]:
                canvas.coords(item, x, 0, x, height)
                canvas.itemconfigure(item, fill=self._blend_hex(color, alpha),
                                     state="normal")
        sweep_elapsed = elapsed - self.SCAN_EXTEND_SEC
        if sweep_elapsed < 0:
            for item, _color in self.scan_items["horizontal"]:
                canvas.itemconfigure(item, state="hidden")
            return
        phase = (sweep_elapsed % self.SCAN_CYCLE_SEC) / self.SCAN_CYCLE_SEC
        y = -2.0 + phase * height
        if phase < 0.08:
            opacity = phase / 0.08
        elif phase > 0.92:
            opacity = 1.0 - 0.1 * ((phase - 0.92) / 0.08)
        else:
            opacity = 1.0
        if opacity <= 0.02:
            for item, _color in self.scan_items["horizontal"]:
                canvas.itemconfigure(item, state="hidden")
            return
        for item, color in self.scan_items["horizontal"]:
            canvas.coords(item, 0, y, width, y)
            canvas.itemconfigure(item, fill=self._blend_hex(color, opacity),
                                 state="normal")

    def _scan_tick(self):
        if self.scan_overlay_visible:
            try:
                self._draw_scan_overlay()
            except Exception as exc:
                if not getattr(self, "_scan_draw_error_logged", False):
                    self._scan_draw_error_logged = True
                    diag(f"scan draw failed: {type(exc).__name__}: {exc}")
        delay = self.SCAN_TICK_MS if self.scan_overlay_visible else 250
        try:
            self.root.after(delay, self._scan_tick)
        except Exception:
            pass

    def _bind_surface(self, canvas, window):
        canvas.bind("<ButtonPress-1>", lambda event, w=window: self._drag_start(event, w))
        canvas.bind("<B1-Motion>", lambda event, w=window: self._drag_move(event, w))

    def _drag_start(self, event, window):
        self._drag[id(window)] = (event.x_root - window.winfo_x(), event.y_root - window.winfo_y())

    def _drag_move(self, event, window):
        offset = self._drag.get(id(window))
        if offset:
            window.geometry(f"+{event.x_root - offset[0]}+{event.y_root - offset[1]}")

    def post_action(self, command):
        try:
            import urllib.request
            import json
            import threading
            req = urllib.request.Request(
                f"http://127.0.0.1:{self.port}/action",
                data=json.dumps({"command": command}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            threading.Thread(target=urllib.request.urlopen, args=(req,), kwargs={"timeout": 2.0}, daemon=True).start()
        except Exception:
            pass

    def _panel_click(self, event):
        if 94 <= event.x <= 122 and 10 <= event.y <= 32:
            self.clear_chat()
        elif 10 <= event.y <= 30 and 125 <= event.x <= 315:
            if 125 <= event.x <= 160:
                self.post_action("open chat")
            elif 170 <= event.x <= 215:
                self.post_action("show system info")
            elif 225 <= event.x <= 265:
                self.post_action("open tools")
            elif 275 <= event.x <= 315:
                self.post_action("analyze camera")
        elif 90 <= event.y <= 99 and 22 <= event.x <= 62:
            self.view = "chat"
        elif 90 <= event.y <= 99 and 66 <= event.x <= 152:
            self.view = "research"
            self.research_scroll = 0
        elif 90 <= event.y <= 99 and 156 <= event.x <= 222:
            # CO-WORK deck: live co-work task / channels / schedule / power lock.
            self.view = "system"
            self.system_scroll = 0
        elif 90 <= event.y <= 99 and 226 <= event.x <= 286:
            # DEMO is a static concept preview only — no backend, no state sync.
            self.view = "demo"
        elif self.PANEL_W - 67 <= event.x < self.PANEL_W - 37 and 7 <= event.y <= 31:
            # Minimize means orb-only mode. Hiding both borderless windows left
            # no on-screen affordance from which the user could restore the HUD.
            # The old "×" close button was removed on purpose: it destroyed the
            # HUD process, leaving nothing on screen to restore it from.
            self.collapse_panel()
        elif self.PANEL_W - 55 <= event.x <= self.PANEL_W - 15 and self.PANEL_H - 60 <= event.y <= self.PANEL_H - 20:
            try:
                import urllib.request
                import threading
                req = urllib.request.Request(f"http://127.0.0.1:{self.port}/listen", data=b"", method="POST")
                threading.Thread(target=urllib.request.urlopen, args=(req,), kwargs={"timeout": 2.0}, daemon=True).start()
            except Exception:
                pass
        elif self.PANEL_H - 58 <= event.y <= self.PANEL_H - 18:
            self.command.focus_set()

    def _orb_click(self, event):
        """Restore compact mode reliably; the small chevron also toggles it.

        A borderless orb must not require pixel-perfect aiming to recover its
        panel. While collapsed, clicking anywhere in the reactor's main circle
        expands the conversation console. In full mode only the chevron toggles,
        preserving the orb surface as a safe drag target.
        """
        cx, cy = self.ORB_W // 2 - 8, 101
        on_chevron = cx + 88 <= event.x <= cx + 122 and cy - 28 <= event.y <= cy + 28
        on_reactor = (event.x - cx) ** 2 + (event.y - cy) ** 2 <= 82 ** 2
        if on_chevron:
            self.toggle_panel()
        elif self.panel_collapsed and on_reactor:
            self.expand_panel()

    def _show_menu(self, event):
        menu = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=TEXT,
                       activebackground=CYAN_DIM, activeforeground=TEXT)
        menu.add_command(label="Open JARVIS dashboard", command=self.restore_console)
        menu.add_command(label="Show conversation panel", command=self.expand_panel)
        menu.add_command(label="Orb-only mode", command=self.collapse_panel)
        menu.add_command(label="Clear conversation", command=self.clear_chat)
        menu.add_command(label="Focus command input", command=self.focus_command)
        menu.add_separator()
        menu.add_command(label="Close HUD (reopen: dashboard HUD button / Ctrl+Shift+J)",
                         command=self.close_hud)
        menu.add_command(label="Exit JARVIS (stop everything)", command=self.exit_everything)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass

    def _submit_command(self, _event=None):
        command = self.command_var.get().strip()
        if not command:
            return "break"
        self.command_var.set("")
        payload = json.dumps({"command": command}).encode("utf-8")
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/action", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        threading.Thread(target=self._send_request, args=(request,), daemon=True).start()
        return "break"

    def clear_chat(self):
        """Floating-HUD Clear Chat -> the SAME centralized clear as the dashboard and voice.

        The core wipes the canonical session + event feed and bumps clear_seq;
        every live UI (including this one) then resyncs through the normal poll.
        The local history is also cleared immediately for instant feedback.
        """
        self.history = []
        self._last_event_id = 0
        self.scroll = 0
        self._clear_pulse = time.time()
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/clear", data=b"", method="POST")
        threading.Thread(target=self._send_request, args=(request,), daemon=True).start()

    @staticmethod
    def _send_request(request):
        try:
            urllib.request.urlopen(request, timeout=2).read()
        except Exception:
            pass

    def restore_console(self):
        try:
            subprocess.Popen(["cmd", "/c", "start", "", self.ui],
                             creationflags=0x08000000)
        except Exception:
            webbrowser.open(self.ui)

    def focus_command(self):
        self.expand_panel()
        self.command.focus_set()

    def _force_topmost(self, window):
        try:
            window.deiconify()
            window.lift()
            window.attributes("-topmost", False)
            window.attributes("-topmost", True)
            if sys.platform == "win32":
                import ctypes
                hwnd = int(window.wm_frame(), 16)
                if hwnd:
                    ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                    ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0043)
                    ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def collapse_panel(self):
        """Minimized floating mode: preserve the orb and background runtime."""
        self.panel_collapsed = True
        self.root.withdraw()
        if not self.hidden:
            self._force_topmost(self.orb_window)
            self._raise_scan_overlay()

    def expand_panel(self):
        # Reopening the panel is an EXPLICIT owner act (hotkey, chevron, chat
        # click) - it revokes the manual close so peeks may summon again.
        self.closed_manually = False
        self.hidden = False
        self.panel_collapsed = False
        for window in (self.root, self.orb_window):
            self._force_topmost(window)
        try:
            self.root.focus_force()
        except Exception:
            pass
        self._sync_scan_overlay()
        self._raise_scan_overlay()

    def toggle_panel(self):
        if self.panel_collapsed or not self.root.winfo_viewable():
            self.expand_panel()
        else:
            self.collapse_panel()

    def show_hud(self):
        # A voice request or second launcher explicitly restores the complete
        # reference composition regardless of the previous minimized state.
        self.expand_panel()

    def close_hud(self):
        """Close the panel and orb; the process itself stays alive.

        The screen-scan layer is deliberately independent: it keeps following
        the core's real screen_watch state, so closing the conversation panel
        never hides the full-desktop animation while Live Screen is on.

        Live 2026-10-19: close_hud() called os._exit(0), so the PM2-supervised
        jarvis-hud instance restarted instantly and the HUD "closed" only to
        re-open itself a second later - an infinite close/relaunch loop. The
        engine must never be disturbed by a window close, so the surfaces
        disappear and the SAME process stays parked. Every existing reopen
        path wakes THIS process: the dashboard HUD pill (UDP "show" via
        /float), the Ctrl+Shift+J hotkey, and a second launcher instance.
        """
        self.panel_collapsed = True
        self.hidden = True
        for window in (self.root, self.orb_window):
            try:
                window.withdraw()
            except Exception:
                pass
        self._sync_scan_overlay()
        try:
            self.root.after(600, self._vivid_recheck_closed_surfaces)
        except Exception:
            pass

    def _vivid_recheck_closed_surfaces(self):
        """Verify the close really latched (panel and orb unmapped)."""
        try:
            visible = bool(self.root.winfo_viewable() or self.root.winfo_ismapped())
        except Exception:
            return
        if visible:
            try:
                self.root.withdraw()
                self.orb_window.withdraw()
            except Exception:
                pass

    def exit_everything(self):
        # "Exit JARVIS" is destructive (stops the background engine + HUD); the
        # launcher (`npm run jarvis`) brings everything back. Confirm first so an
        # accidental click never kills the always-on voice loop.
        try:
            from tkinter import messagebox
            confirmed = messagebox.askyesno(
                "Exit JARVIS",
                "Stop the background JARVIS engine and floating HUD?\n\n"
                "Start it again anytime with: npm run jarvis\n"
                "(choose No to keep the engine running in the background)")
        except Exception:
            confirmed = True
        if not confirmed:
            return
        request = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/shutdown", data=b"", method="POST")
        self._send_request(request)
        try:
            self.guard.close()
        except Exception:
            pass
        os._exit(0)

    def _guard_loop(self):
        while True:
            try:
                data, _addr = self.guard.recvfrom(64)
                # 'peek' (tab-hidden heartbeat) must not resurrect a HUD the
                # owner closed on purpose; 'show' is always an explicit ask.
                if data.strip() == b"peek":
                    if getattr(self, "closed_manually", False):
                        continue
                    self.root.after(0, self.show_hud)
                else:
                    self.closed_manually = False
                    self.root.after(0, self.show_hud)
            except Exception:
                return

    def _hotkey_loop(self):
        """Global Windows hotkey listener (Ctrl+Shift+J) via Win32 RegisterHotKey.

        Allows toggling/summoning the JARVIS HUD from any application, fullscreen
        game, or editor without needing focus or a tray click.
        """
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            MOD_CONTROL = 0x0002
            MOD_SHIFT = 0x0004
            MOD_NOREPEAT = 0x4000
            VK_J = 0x4A
            HOTKEY_ID = 101

            ok = user32.RegisterHotKey(None, HOTKEY_ID, MOD_CONTROL | MOD_SHIFT | MOD_NOREPEAT, VK_J)
            if not ok:
                ok = user32.RegisterHotKey(None, HOTKEY_ID, MOD_CONTROL | MOD_SHIFT, VK_J)
            if not ok:
                diag("could not register global hotkey Ctrl+Shift+J (may already be in use)")
                return
            diag("global hotkey Ctrl+Shift+J registered")

            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                if msg.message == 0x0312 and msg.wParam == HOTKEY_ID:
                    self.root.after(0, self.toggle_panel)
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        except Exception as exc:
            diag(f"global hotkey loop failed: {type(exc).__name__}: {exc}")

    def _poll_worker(self):
        while not getattr(self, '_stopped', False):
            data = None
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/state", timeout=1.5) as response:
                    data = json.loads(response.read().decode("utf-8", "replace"))
            except Exception:
                pass
            if not getattr(self, '_stopped', False):
                try:
                    self.root.after(0, self._apply_state, data)
                except Exception:
                    pass
            time.sleep(0.4 if data else 0.8)

    def _apply_state(self, data):
        if not data:
            self.status = "offline"
            self.active_task = ""
            self.action_name = ""
            self.top_results = []
            self.mic_level = 0.0
            self._set_scan_enabled(False)
            return
        session = data.get('session_id')
        if session and session != getattr(self, '_core_session', None):
            self._core_session = session
            self.history = []
            self._last_event_id = 0
            self.scroll = 0
        watch = data.get("screen_watch")
        self._set_scan_enabled(bool(watch.get("enabled")) if isinstance(watch, dict) else False)
        self.status = str(data.get("status") or "idle").lower()
        self.active_task = clean_text(data.get("last_error") or data.get("active_task"))
        self.action_name = clean_text(data.get("action_name"))
        self.action_status = str(data.get("action_status") or "").lower()
        try:
            rseq = int(data.get("research_seq") or 0)
        except Exception:
            rseq = 0
        if rseq != self.research_seq:
            self.research_seq = rseq
            self.research = data.get("research")
            self.research_scroll = 0
        elif self.research is None and data.get("research"):
            self.research = data.get("research")
        try:
            cowork_rev = int(data.get("cowork_revision") or 0)
        except Exception:
            cowork_rev = 0
        if cowork_rev != self.cowork_revision or not self.cowork:
            self.cowork_revision = cowork_rev
            fresh = data.get("cowork")
            self.cowork = fresh if isinstance(fresh, dict) else {}
        self.channels = [c for c in (data.get("channels") or []) if isinstance(c, dict)]
        try:
            self.schedule_count = int(data.get("schedule_count") or 0)
        except Exception:
            self.schedule_count = 0
        try:
            self.skills_revision = int(data.get("skills_revision") or 0)
        except Exception:
            self.skills_revision = 0
        names = data.get("skills_list")
        self.skills = [str(n) for n in names[:10]] if isinstance(names, list) else []
        tools = data.get("mcp_tools")
        self.mcp_tools = [t for t in tools[:10] if isinstance(t, dict)] if isinstance(tools, list) else []
        self.power_lock = bool(data.get("power_lock", True))
        try:
            clear_seq = int(data.get("clear_seq") or 0)
        except Exception:
            clear_seq = 0
        if clear_seq != self._clear_seq:
            self._clear_seq = clear_seq
            self.history = []
            self._last_event_id = 0
            self.scroll = 0
            self._clear_pulse = time.time()
        self.top_results = [clean_text(t) for t in (data.get("top_results") or [])[:3] if clean_text(t)]
        try:
            self.mic_level = max(0.0, min(1.0, float(data.get("mic_level") or 0.0)))
        except Exception:
            self.mic_level = 0.0
        for event in data.get("events") or []:
            event_id = int(event.get("id") or 0)
            if event_id <= self._last_event_id:
                continue
            text = clean_text(event.get("text"))
            if text:
                try:
                    stamp = time.strftime("%I:%M %p", time.localtime(float(event.get("at"))))
                except Exception:
                    stamp = time.strftime("%I:%M %p")
                self.history.append(("jarvis" if event.get("role") == "assistant" else "you", text, stamp))
            self._last_event_id = max(self._last_event_id, event_id)
        del self.history[:-30]

    def _draw_orb(self):
        canvas = self.orb
        canvas.delete("all")
        now = time.time()
        color = STATUS_COLORS.get(self.status, CYAN)
        cx, cy = self.ORB_W // 2 - 8, 101

        # Smooth the live mic level so the reactor breathes with REAL audio.
        target = self.mic_level if self.status in ("listening", "speaking") else 0.0
        self._mic_display += (target - self._mic_display) * 0.35
        boost = self._mic_display * 10

        # Radar arcs, range rings and animated instrumentation from the reference.
        for radius, width, dash in ((88, 1, (2, 6)), (77, 1, (1, 5)), (65, 2, None), (52, 1, None)):
            canvas.create_oval(cx-radius, cy-radius, cx+radius, cy+radius,
                               outline=CYAN_DIM, width=width, dash=dash)
        for index in range(48):
            angle = math.radians(index * 7.5 + now * (15 if index % 2 else -9))
            inner = 69 + (index % 4) * 2
            outer = inner + (8 if index % 6 == 0 else 3) + (boost if index % 6 == 0 else boost * .4)
            canvas.create_line(cx + math.cos(angle)*inner, cy + math.sin(angle)*inner,
                               cx + math.cos(angle)*outer, cy + math.sin(angle)*outer,
                               fill=color if index % 6 == 0 else CYAN_DIM,
                               width=2 if index % 6 == 0 else 1)
        pulse = 44 + math.sin(now * (5 if self.status == "speaking" else 2.4)) * (5 if self.status != "idle" else 2) + boost * .8
        canvas.create_oval(cx-pulse-7, cy-pulse-7, cx+pulse+7, cy+pulse+7,
                           outline=color, width=2)
        canvas.create_oval(cx-pulse, cy-pulse, cx+pulse, cy+pulse,
                           fill="#061923", outline=CYAN_SOFT, width=2)
        for ring in range(3):
            radius = 18 + ring * 8 + math.sin(now * 3 + ring) * 2 + boost * .5
            canvas.create_oval(cx-radius, cy-radius, cx+radius, cy+radius,
                               outline=color if ring == 1 else CYAN_DIM, width=2)
        # Broken outer brackets from the reference reactor (gaps face the chip).
        canvas.create_arc(cx-95, cy-95, cx+95, cy+95, start=28, extent=124,
                          style="arc", outline=CYAN, width=2)
        canvas.create_arc(cx-95, cy-95, cx+95, cy+95, start=208, extent=124,
                          style="arc", outline=CYAN_DIM, width=2)

        if self.status == "speaking":
            for index in range(9):
                height = 5 + abs(math.sin(now * 9 + index * .8)) * (14 + boost * 1.4)
                x = cx - 24 + index * 6
                canvas.create_line(x, cy-height/2, x, cy+height/2,
                                   fill=CYAN_SOFT if index % 2 else color, width=3)
        elif self.status == "listening" and self._mic_display > 0.04:
            for index in range(9):
                height = 4 + abs(math.sin(now * 8 + index)) * (6 + boost * 2.2)
                x = cx - 24 + index * 6
                canvas.create_line(x, cy-height/2, x, cy+height/2, fill=color, width=3)
        elif self.status in ("thinking", "searching", "executing", "working"):
            for index in range(8):
                angle = math.radians(index * 45 + now * 170)
                x, y = cx + math.cos(angle)*28, cy + math.sin(angle)*28
                canvas.create_oval(x-3, y-3, x+3, y+3, fill=color, outline="")
        else:
            canvas.create_text(cx, cy, text="J.A.R.V.I.S", fill=CYAN_SOFT,
                               font=("Bahnschrift", 9, "bold"))

        # Real expander control: orb-only mode can always recover the glass panel.
        # The entire reactor is also clickable while collapsed for accessibility.
        chip_x = cx + 96
        rounded_rect(canvas, chip_x, cy-17, chip_x+20, cy+17, 7,
                     fill="#07131b", outline=color, width=1)
        canvas.create_text(chip_x+10, cy, text="»" if self.panel_collapsed else "‹",
                           fill=CYAN_SOFT, font=("Segoe UI", 11, "bold"))

        # READY pill (reference: pill directly under the reactor ring).
        rounded_rect(canvas, cx-45, 196, cx+45, 220, 10,
                     fill="#06131a", outline=color, width=1)
        canvas.create_oval(cx-34, 205, cx-26, 213, fill=GREEN if self.status != "offline" else MUTE, outline="")
        canvas.create_text(cx+6, 208, text=STATUS_LABELS.get(self.status, self.status.upper()),
                           fill=color, font=("Segoe UI", 8, "bold"))

        # Icon row under the pill (reference: mic / eye / keyboard / camera glyphs).
        icons = ("\U0001F3A4", "\U0001F441", "\u2328", "\U0001F4F7")
        for index, glyph in enumerate(icons):
            ix = cx - 57 + index * 38
            canvas.create_oval(ix-12, 228, ix+12, 252, outline=CYAN_DIM, width=1)
            canvas.create_text(ix, 239, text=glyph, fill=CYAN_SOFT,
                               font=("Segoe UI Symbol", 9))

    def _draw_wave(self, canvas, y, color):
        now = time.time()
        left, right = 28, self.PANEL_W - 148
        count = 40
        step = (right - left) / (count - 1)
        canvas.create_line(left, y, right, y, fill="#12323f")
        # Reference-style segmented level bars driven by the REAL mic/TTS energy.
        live = self.status in ("listening", "speaking")
        for index in range(count):
            x = left + index * step
            envelope = math.sin(math.pi * index / (count - 1)) ** 0.7
            shimmer = (abs(math.sin(now * 6.4 + index * 0.58)) * 0.65
                       + abs(math.sin(now * 12.2 + index * 1.9)) * 0.35)
            level = (2.5 + (self._mic_display * 16 if live else 1.5)) * envelope * (0.35 + 0.65 * shimmer)
            amplitude = max(1.5, min(13, level))
            canvas.create_line(x, y - amplitude, x, y + amplitude, fill=color, width=2)

    # ---- conversation feed layout -------------------------------------------
    FEED_TOP, FEED_BOTTOM_GAP = 100, 66

    def _feed_blocks(self):
        """Convert history + live action card into measured layout blocks."""
        blocks = []
        for index, (role, text, stamp) in enumerate(self.history):
            lines, _ = wrap_lines(text, 47, 8)
            blocks.append({"kind": role, "lines": lines, "stamp": stamp,
                           "height": 24 + len(lines) * 15 + 8, "sep": index > 0})
        if self.action_name:
            blocks.append({"kind": "action", "height": 52})
        if self.top_results:
            blocks.append({"kind": "results", "height": 30 + len(self.top_results) * 17 + 10})
        if not blocks:
            # Empty state is not inserted into history as fake demonstration chat.
            blocks = [{"kind": "empty", "height": 86}]
        return blocks

    def _draw_block(self, canvas, block, y, color):
        width = self.PANEL_W
        if block["kind"] == "empty":
            canvas.create_oval(width//2-15, y+8, width//2+15, y+38,
                               outline=CYAN_DIM, width=1)
            canvas.create_text(width//2, y+23, text="J", fill=CYAN,
                               font=("Bahnschrift", 9, "bold"))
            canvas.create_text(width//2, y+53, text="VOICE LINK READY", fill=MUTE,
                               font=("Segoe UI", 7, "bold"))
            return
        if block["kind"] == "action":
            # Reference-style tool card: icon square, tool name, status, progress ring.
            done = self.action_status == "done"
            card_color = GREEN if done else color
            rounded_rect(canvas, 24, y+4, width-24, y+46, 9,
                         fill=PANEL_2, outline=card_color, width=1)
            rounded_rect(canvas, 34, y+12, 60, y+38, 6, fill="#0c2733", outline=CYAN_DIM)
            canvas.create_text(47, y+25, text="\u25B6", fill=RED if self.action_name == "YouTube" else CYAN_SOFT,
                               font=("Segoe UI Symbol", 9))
            canvas.create_text(70, y+18, text=self.action_name, anchor="w",
                               fill=TEXT, font=("Segoe UI", 9, "bold"))
            status_text = "Done" if done else ("Searching\u2026" if self.action_status == "searching" else "Executing\u2026")
            canvas.create_text(70, y+33, text=status_text, anchor="w",
                               fill=MUTE, font=("Segoe UI", 7))
            ring_x = width - 48
            canvas.create_oval(ring_x-11, y+14, ring_x+11, y+36, outline="#123240", width=3)
            if done:
                canvas.create_oval(ring_x-11, y+14, ring_x+11, y+36, outline=card_color, width=3)
                canvas.create_text(ring_x, y+25, text="100%", fill=card_color, font=("Segoe UI", 6, "bold"))
            else:
                sweep = (time.time() * 220) % 360
                canvas.create_arc(ring_x-11, y+14, ring_x+11, y+36, start=-sweep, extent=110,
                                  style="arc", outline=card_color, width=3)
            return
        if block["kind"] == "results":
            # Reference-style "Top Results" card: header + cyan bullet links.
            card_h = block["height"] - 8
            rounded_rect(canvas, 24, y+4, width-24, y+4+card_h, 9,
                         fill=PANEL_2, outline="#123240", width=1)
            canvas.create_text(38, y+19, text="Top Results", anchor="w",
                               fill=MUTE, font=("Segoe UI", 7, "bold"))
            line_y = y + 36
            for title in self.top_results:
                canvas.create_text(42, line_y, text="\u2022", anchor="w", fill=CYAN,
                                   font=("Segoe UI", 8, "bold"))
                shown, _ = wrap_lines(title, 44, 1)
                canvas.create_text(52, line_y, text=(shown[0] if shown else title), anchor="w",
                                   fill=CYAN, font=("Segoe UI", 8))
                line_y += 17
            return
        is_user = block["kind"] == "you"
        if block.get("sep"):
            canvas.create_line(24, y + 1, width - 24, y + 1, fill="#10242e")
        accent = CYAN if is_user else STATUS_COLORS.get(self.status, CYAN)
        canvas.create_oval(20, y+2, 39, y+21, fill="#0a2531" if is_user else "#082631",
                           outline=CYAN_DIM if is_user else accent)
        canvas.create_text(29, y+11, text="Y" if is_user else "J",
                           fill=CYAN_SOFT if is_user else accent,
                           font=("Segoe UI" if is_user else "Bahnschrift", 7, "bold"))
        canvas.create_text(48, y+7, text="YOU" if is_user else "JARVIS", anchor="w",
                           fill=CYAN if is_user else accent, font=("Segoe UI", 7, "bold"))
        canvas.create_text(self.PANEL_W-22, y+7, text=block["stamp"], anchor="e",
                           fill="#3e5c68", font=("Segoe UI", 6))
        line_y = y + 26
        for line in block["lines"]:
            canvas.create_text(49, line_y, text=line, anchor="w", fill=TEXT, font=("Segoe UI", 9))
            line_y += 15

    @staticmethod
    def _wrap_px(text, font, width):
        """Wrap long text to a pixel width using the canvas font metrics."""
        lines = []
        for para in str(text).split("\n"):
            if not para.strip():
                lines.append("")
                continue
            current = ""
            for word in para.split():
                trial = ((current + " " + word).strip() if current else word)
                if current and font.measure(trial) > width:
                    lines.append(current)
                    current = word
                else:
                    current = trial
            lines.append(current)
        return lines

    def _draw_research_view(self, canvas, width, height):
        """Render the latest research dossier (core STATE['research']) as a scrollable
        glass card — the floating twin of the dashboard's research panel."""
        font = tkfont.Font(family="Segoe UI", size=9)
        bold = tkfont.Font(family="Segoe UI", size=10, weight="bold")
        small = tkfont.Font(family="Segoe UI", size=8)
        body_w = width - 60
        r = self.research or {}
        lines = []   # (text, font, fill)
        if not r:
            lines = [("No research yet, Sir.", font, MUTE),
                     ("Type:  research <topic>  in the box below.", small, MUTE)]
        elif isinstance(r, dict) and r.get("error"):
            lines = [("RESEARCH FAILED", bold, RED),
                     (str(r.get("error"))[:300], font, RED)]
        else:
            kind = str(r.get("type") or "search").upper()
            label = r.get("query") or r.get("topic") or ""
            lines.append((kind + ("  \u2022  " + label if label else ""), bold, CYAN))
            body = str(r.get("answer") or r.get("report") or "").strip()
            if body:
                for line in self._wrap_px(body[:3000], font, body_w):
                    lines.append((line, font, TEXT))
            if not body or r.get("results"):
                for item in (r.get("results") or [])[:8]:
                    for line in self._wrap_px(str(item.get("title") or "Result")[:200], font, body_w - 8):
                        lines.append(("\u25B8 " + line, font, CYAN_SOFT))
                    for line in self._wrap_px(str(item.get("url") or "")[:120], small, body_w - 8):
                        lines.append(("  " + line, small, GREEN))
                    for line in self._wrap_px(str(item.get("content") or "")[:240], small, body_w - 8):
                        lines.append(("  " + line, small, MUTE))
                    lines.append(("", font, TEXT))
            if r.get("sources"):
                lines.append(("SOURCES", small, MUTE))
                for src in (r.get("sources") or [])[:10]:
                    for line in self._wrap_px(str(src)[:120], small, body_w - 8):
                        lines.append(("  " + line, small, GREEN))
                lines.append(("", font, TEXT))
        line_h = 15
        total = len(lines) * line_h + 10
        viewport = height - self.FEED_BOTTOM_GAP - self.FEED_TOP
        max_scroll = max(0, total - viewport)
        self.research_scroll = min(self.research_scroll, max_scroll)
        offset = total - viewport - self.research_scroll  # px hidden above the viewport
        y = self.FEED_TOP - max(0, offset)
        for text, f, fill in lines:
            if y + line_h > self.FEED_TOP and y < height - self.FEED_BOTTOM_GAP:
                if text:
                    canvas.create_text(30, y + 2, text=text, anchor="nw", fill=fill, font=f)
            y += line_h
        if max_scroll > 0:
            track_top, track_bottom = self.FEED_TOP, height - self.FEED_BOTTOM_GAP
            span = track_bottom - track_top
            thumb = max(26, int(span * viewport / total))
            position = track_top + int((span - thumb) * (1 - self.research_scroll / max_scroll))
            canvas.create_line(width - 13, track_top, width - 13, track_bottom, fill="#0e2731", width=3)
            canvas.create_line(width - 13, position, width - 13, position + thumb, fill=CYAN_DIM, width=3)
        if self.research_scroll > 0:
            canvas.create_text(width // 2, height - self.FEED_BOTTOM_GAP - 4, text="\u25BC latest",
                               fill=MUTE, font=("Segoe UI", 6, "bold"))

    def _draw_system_view(self, canvas, width, height):
        """SYSTEM deck: co-work task, channels, schedule and the power lock.

        A read-only mirror of core STATE (cowork / channels / schedule_count /
        skills_revision / power_lock) — the floating twin of the dashboard
        Co-work panel. Empty registries render an explicit empty state instead
        of placeholder rows, and no step is ever shown that the core did not
        report. Scrollable with its own offset (self.system_scroll).
        """
        font = tkfont.Font(family="Segoe UI", size=9)
        bold = tkfont.Font(family="Segoe UI", size=10, weight="bold")
        small = tkfont.Font(family="Segoe UI", size=8)
        body_w = width - 60
        task = self.cowork if isinstance(self.cowork, dict) else {}
        steps = [s for s in (task.get("steps") or []) if isinstance(s, dict)]
        done = len([s for s in steps if str(s.get("status") or "") == "done"])
        lines = []   # (text, font, fill)
        # ---- live co-work task ----
        if task.get("running") or task.get("title"):
            lines.append(("CO-WORK TASK  %d/%d  %s" % (
                done, len(steps), "RUNNING" if task.get("running") else "IDLE"),
                small, MUTE))
            for line in self._wrap_px(str(task.get("title") or "(untitled)")[:160],
                                      bold, body_w):
                lines.append((line, bold, CYAN))
            glyphs = {"done": "\u2714", "running": "\u25B6", "failed": "\u2716"}
            for step in steps[:14]:
                label = str(step.get("title") or step.get("text") or "").strip()
                if not label:
                    continue
                status = str(step.get("status") or "").lower()
                fill = GREEN if status == "done" else (RED if status == "failed" else TEXT)
                wrapped = self._wrap_px(label[:160], font, body_w - 16)
                for index, line in enumerate(wrapped):
                    prefix = (glyphs.get(status, "\u2022") + " ") if index == 0 else "   "
                    lines.append((prefix + line, font, fill))
            if not steps:
                lines.append(("No steps recorded yet.", small, MUTE))
        else:
            lines.append(("CO-WORK", small, MUTE))
            lines.append(("No task running, Sir.", bold, CYAN_SOFT))
            lines.append(("Assign work from the dashboard Co-work panel — this "
                          "deck only mirrors real core state.", small, MUTE))
        lines.append(("", font, TEXT))
        # ---- channels (paired messaging surfaces) ----
        if self.channels:
            lines.append(("CHANNELS  %d paired" % len(self.channels), small, MUTE))
            for channel in self.channels[:6]:
                name = str(channel.get("name") or channel.get("id") or "channel")
                status = str(channel.get("status") or "linked")
                lines.append(("\u25B8 %s  (%s)" % (name[:38], status[:16]),
                              font, CYAN_SOFT))
        else:
            lines.append(("CHANNELS  none paired", small, MUTE))
            lines.append(("The loopback Windows bridge is the only surface "
                          "right now.", small, MUTE))
        lines.append(("", font, TEXT))
        # ---- schedule ----
        jobs = int(self.schedule_count or 0)
        lines.append(("SCHEDULE  %d job(s)" % jobs, small, MUTE))
        lines.append(("Recurring and one-shot voice timers live in the core "
                      "scheduler." if jobs else
                      "No scheduled job yet \u2014 try \u201cstop for 10 minutes\u201d.",
                      small, MUTE))
        lines.append(("", font, TEXT))
        # ---- skills ----
        lines.append(("SKILLS  revision %d" % int(self.skills_revision or 0),
                      small, MUTE))
        if self.skills:
            for name in self.skills[:6]:
                lines.append(("\u2022 " + name[:44], font, CYAN_SOFT))
        else:
            lines.append(("No SKILL.md in skills/ yet — workspace skills appear here.", small, MUTE))
        lines.append(("Ask \u201ckya kya skills\u201d to hear the loaded list.",
                      small, MUTE))
        lines.append(("", font, TEXT))
        # ---- MCP connectors (read-only mirror of the core tool listing) ----
        if self.mcp_tools:
            callables = sum(1 for row in self.mcp_tools if row.get("allow_call"))
            lines.append(("MCP  %d tools, %d callable" % (len(self.mcp_tools), callables),
                          small, MUTE))
            for row in self.mcp_tools[:6]:
                tag = "call" if row.get("allow_call") else "list-only"
                lines.append(("\u2022 %s.%s  (%s)" % (
                    str(row.get("server") or "")[:24], str(row.get("tool") or "")[:24],
                    tag), font, CYAN_SOFT))
        else:
            lines.append(("MCP  none listed", small, MUTE))
            lines.append(("Add a server in mcp/servers.json.", small, MUTE))
        lines.append(("", font, TEXT))
        # ---- P0 power lock (informational only; it is never a toggle) ----
        lines.append(("POWER LOCK", small, MUTE))
        if self.power_lock:
            lines.append(("ON \u2014 laptop shutdown / restart / sleep stays with "
                          "you and Windows.", font, GREEN))
        else:
            lines.append(("OFF \u2014 unexpected; check core state.", font, RED))
        # ---- render (same scroll model as the research dossier) ----
        line_h = 15
        total = len(lines) * line_h + 10
        viewport = height - self.FEED_BOTTOM_GAP - self.FEED_TOP
        max_scroll = max(0, total - viewport)
        self.system_scroll = min(self.system_scroll, max_scroll)
        offset = total - viewport - self.system_scroll
        y = self.FEED_TOP - max(0, offset)
        for text, f, fill in lines:
            if y + line_h > self.FEED_TOP and y < height - self.FEED_BOTTOM_GAP:
                if text:
                    canvas.create_text(30, y + 2, text=text, anchor="nw",
                                       fill=fill, font=f)
            y += line_h
        if max_scroll > 0:
            track_top, track_bottom = self.FEED_TOP, height - self.FEED_BOTTOM_GAP
            span = track_bottom - track_top
            thumb = max(26, int(span * viewport / total))
            position = track_top + int((span - thumb) *
                                       (1 - self.system_scroll / max_scroll))
            canvas.create_line(width - 13, track_top, width - 13, track_bottom,
                               fill="#0e2731", width=3)
            canvas.create_line(width - 13, position, width - 13, position + thumb,
                               fill=CYAN_DIM, width=3)
        if self.system_scroll > 0:
            canvas.create_text(width // 2, height - self.FEED_BOTTOM_GAP - 4,
                               text="\u25BC latest", fill=MUTE,
                               font=("Segoe UI", 6, "bold"))

    def _draw_demo_view(self, canvas, width, height):
        """DEMO-ONLY concept rail — a static preview of possible future modules.

        Nothing here is wired to any backend, command, or STATE field: no click
        handlers, no scrolling, no network, no state sync. It is a purely
        visual, non-functioning mock so future module ideas can be reviewed in
        place next to the live CHAT / RESEARCH tabs.
        """
        font = tkfont.Font(family="Segoe UI", size=9)
        bold = tkfont.Font(family="Segoe UI", size=10, weight="bold")
        small = tkfont.Font(family="Segoe UI", size=7)
        y = self.FEED_TOP + 4
        canvas.create_text(30, y, text="CONCEPT RAIL  \u2022  DEMO ONLY", anchor="nw",
                           fill=CYAN, font=bold)
        y += 22
        canvas.create_text(30, y, text="Preview mock \u2014 nothing here runs yet.",
                           anchor="nw", fill=MUTE, font=small)
        y += 24
        concepts = (
            ("Routines", "Morning briefing at 8 AM"),
            ("Reminders", "Water the plants \u2014 Fri 6 PM"),
            ("Focus Mode", "Silence alerts for 25 min"),
            ("Health Nudge", "Stand up + stretch hourly"),
            ("Trip Planner", "Weekend in Jaipur, 2 days"),
            ("Bill Watch", "Electricity due on the 5th"),
        )
        for title, hint in concepts:
            if y > height - self.FEED_BOTTOM_GAP - 60:
                break
            rounded_rect(canvas, 22, y, width - 22, y + 40, 8,
                         fill="#0a1a23", outline="#123240", width=1)
            canvas.create_text(34, y + 12, text="\u25CB", fill=MUTE,
                               font=("Segoe UI", 10))
            canvas.create_text(52, y + 5, text=title, anchor="nw",
                               fill=CYAN_SOFT, font=font)
            canvas.create_text(52, y + 22, text=hint, anchor="nw",
                               fill=MUTE, font=small)
            y += 46
        canvas.create_text(30, height - self.FEED_BOTTOM_GAP - 18,
                           text="Static mock \u2014 taps do nothing here.",
                           anchor="nw", fill=MUTE, font=small)

    def _draw_panel(self):
        canvas = self.panel
        canvas.delete("all")
        width, height = self.PANEL_W, self.PANEL_H
        color = STATUS_COLORS.get(self.status, CYAN)
        # Layered dark-glass shell and cyan edge bloom from the reference.
        rounded_rect(canvas, 1, 1, width-1, height-1, 20,
                     fill="#02070b", outline="#052331", width=2)
        rounded_rect(canvas, 3, 3, width-3, height-3, 18,
                     fill=BG, outline="#0b7491", width=2)
        rounded_rect(canvas, 6, 6, width-6, height-6, 15,
                     fill=PANEL, outline=EDGE, width=1)
        canvas.create_line(32, 3, 112, 3, fill=CYAN, width=2)
        canvas.create_line(width-126, height-3, width-45, height-3, fill=CYAN, width=2)
        canvas.create_line(18, 39, width-18, 39, fill="#173745")
        canvas.create_line(126, 39, 126, 66, fill="#173745")
        canvas.create_oval(17, 17, 25, 25, fill=color, outline="")
        canvas.create_text(32, 21, text="J.A.R.V.I.S", anchor="w", fill=CYAN_SOFT,
                           font=("Bahnschrift", 9, "bold"))
        # Small Clear Chat control — the floating twin of the dashboard button;
        # both call the SAME centralized POST /clear on the canonical core.
        rounded_rect(canvas, 96, 12, 120, 30, 7, fill="#0b1d27", outline="#123240", width=1)
        canvas.create_text(108, 21, text="\u232B", fill=MUTE,
                           font=("Segoe UI Symbol", 9, "bold"))
        for label, x in (("CHAT", 132), ("SYSTEM", 180), ("TOOLS", 238), ("VISION", 287)):
            if label == "CHAT":
                rounded_rect(canvas, x-8, 10, x+39, 32, 8, fill="#0c2732", outline="")
            canvas.create_text(x, 21, text=label, anchor="w",
                               fill=color if label == "CHAT" else MUTE,
                               font=("Segoe UI", 6, "bold"))
        canvas.create_text(width-52, 20, text="−", fill=MUTE, font=("Segoe UI", 12, "bold"))

        # Status strip: live waveform + status word + language pill (reference: "ENG (US)").
        self._draw_wave(canvas, 61, color)
        canvas.create_text(width-138, 61, text=f"{STATUS_LABELS.get(self.status, 'READY').title()}...",
                           anchor="w", fill=color, font=("Segoe UI", 8, "bold"))
        rounded_rect(canvas, width-84, 50, width-20, 72, 9,
                     fill="#0b1d27", outline="#123240", width=1)
        canvas.create_text(width-52, 61, text="ENG (US) \u25BE", fill=CYAN_SOFT,
                           font=("Segoe UI", 6, "bold"))
        canvas.create_line(18, 88, width-18, 88, fill="#173745")

        # Brief "Chat cleared" pulse after a centralized clear (any source).
        if time.time() - self._clear_pulse < 2.5:
            canvas.create_text(width // 2, 100, text="CHAT CLEARED", fill=GREEN,
                               font=("Segoe UI", 8, "bold"))

        # ---- scrollable view: conversation feed, research dossier, or demo rail ----
        if self.view == "research":
            self._draw_research_view(canvas, width, height)
        elif self.view == "system":
            self._draw_system_view(canvas, width, height)
        elif self.view == "demo":
            self._draw_demo_view(canvas, width, height)
        else:
            blocks = self._feed_blocks()
            feed_height = height - self.FEED_BOTTOM_GAP - self.FEED_TOP
            total = sum(block["height"] for block in blocks)
            max_scroll = max(0, total - feed_height)
            self.scroll = min(self.scroll, max_scroll)
            offset = total - feed_height - self.scroll  # px hidden above the viewport
            y = self.FEED_TOP - max(0, offset)
            for block in blocks:
                # Draw anything intersecting the viewport; masks below crop overflow.
                if y + block["height"] > 89 and y < height - self.FEED_BOTTOM_GAP:
                    self._draw_block(canvas, block, y, color)
                y += block["height"]
        # Mask feed overflow above the divider and below the feed viewport.
        canvas.create_rectangle(6, 89, width-6, self.FEED_TOP - 4, fill=PANEL, outline="")
        canvas.create_rectangle(6, height - self.FEED_BOTTOM_GAP, width-6, height-8, fill=PANEL, outline="")
        if self.view == "chat":  # chat-only scrollbar/hint; research draws its own, demo is static
            if max_scroll > 0:
                # Slim scrollbar on the right edge of the feed.
                track_top, track_bottom = self.FEED_TOP, height - self.FEED_BOTTOM_GAP
                span = track_bottom - track_top
                thumb = max(26, int(span * feed_height / total))
                position = track_top + int((span - thumb) * (1 - self.scroll / max_scroll))
                canvas.create_line(width-13, track_top, width-13, track_bottom, fill="#0e2731", width=3)
                canvas.create_line(width-13, position, width-13, position + thumb, fill=CYAN_DIM, width=3)
            if self.scroll > 0:
                canvas.create_text(width//2, height - self.FEED_BOTTOM_GAP - 4, text="\u25BC latest",
                                   fill=MUTE, font=("Segoe UI", 6, "bold"))

        # ---- Local view switcher (drawn above the crop mask so it is always tappable) ----
        for label, x0, x1, active in (("CHAT", 22, 62, self.view == "chat"),
                                      ("RESEARCH", 66, 152, self.view == "research"),
                                      # "CO-WORK" (not SYSTEM) so the tab cannot be
                                      # confused with the top-bar SYSTEM button.
                                      ("CO-WORK", 156, 222, self.view == "system"),
                                      ("DEMO", 226, 286, self.view == "demo")):
            rounded_rect(canvas, x0, 90, x1, 99, 6,
                         fill="#0c2732" if active else "#07121b",
                         outline=CYAN_DIM if active else "#123240", width=1)
            canvas.create_text((x0 + x1) // 2, 94, text=label,
                               fill=CYAN_SOFT if active else MUTE,
                               font=("Segoe UI", 7, "bold"))

        # Command input (reference: "Say something…" bar with mic glyph).
        rounded_rect(canvas, 18, height-61, width-18, height-16, 10,
                     fill="#091720", outline="#174456", width=1)
        canvas.create_text(width-35, height-39, text="\U0001F3A4", fill=color,
                           font=("Segoe UI Symbol", 10))
        if not self.command_var.get() and self.command.focus_get() is not self.command:
            canvas.create_text(29, height-39, text="Say something\u2026", anchor="w",
                               fill="#4d6874", font=("Segoe UI", 9))

    def tick(self):
        if not self.hidden:
            try:
                self._draw_orb()
                if not self.panel_collapsed:
                    self._draw_panel()
            except Exception:
                pass
        self.root.after(TICK_MS.get(self.status, 100), self.tick)

    def run(self):
        threading.Thread(target=self._guard_loop, daemon=True).start()
        threading.Thread(target=self._hotkey_loop, daemon=True).start()
        threading.Thread(target=self._poll_worker, daemon=True).start()
        self._scan_tick()
        self.tick()
        try:
            self.root.mainloop()
        finally:
            self._stopped = True
            try:
                self.guard.close()
            except Exception:
                pass
            os._exit(0)


def _find_pid_on_port(port=7781):
    try:
        out = subprocess.check_output(
            ["netstat", "-ano", "-p", "UDP"],
            creationflags=0x08000000
        ).decode("utf-8", "ignore")
        for line in out.splitlines():
            if f":{port}" in line:
                parts = line.strip().split()
                if len(parts) >= 4:
                    return int(parts[-1])
    except Exception:
        pass
    return None


def main():
    args = parse()
    guard = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bound = False
    try:
        guard.bind(GUARD_ADDR)
        bound = True
    except OSError as exc:
        diag(f"single-instance guard initially prevented startup: {type(exc).__name__}: {exc}")
        existing_pid = _find_pid_on_port(GUARD_ADDR[1])
        has_window = False
        if sys.platform == "win32":
            try:
                import ctypes
                h_panel = ctypes.windll.user32.FindWindowW(None, "J.A.R.V.I.S")
                h_orb = ctypes.windll.user32.FindWindowW(None, "J.A.R.V.I.S Voice Link")
                if (h_panel and ctypes.windll.user32.IsWindow(h_panel)) or (h_orb and ctypes.windll.user32.IsWindow(h_orb)):
                    has_window = True
                    target = h_panel or h_orb
                    ctypes.windll.user32.ShowWindow(target, 9)
                    ctypes.windll.user32.SetWindowPos(target, -1, 0, 0, 0, 0, 0x0043)
                    ctypes.windll.user32.SetForegroundWindow(target)
            except Exception:
                pass

        if has_window:
            try:
                # An auto-spawn (tab-hidden heartbeat) only peeks: a HUD that
                # was closed BY HAND must stay closed. An explicit second
                # launch always sends 'show'.
                guard.sendto(b"peek" if args.from_auto else b"show", GUARD_ADDR)
                diag("signalled the existing HUD before exiting (peek=%s)"
                     % bool(args.from_auto))
            except Exception as signal_exc:
                diag(f"failed to signal existing HUD: {type(signal_exc).__name__}: {signal_exc}")
            finally:
                guard.close()
            return

        # No visible window exists! The process holding port 7781 is a zombie.
        if existing_pid and existing_pid != os.getpid():
            diag(f"found zombie HUD process {existing_pid} holding port {GUARD_ADDR[1]}; terminating")
            try:
                subprocess.run(["taskkill", "/F", "/PID", str(existing_pid)],
                               creationflags=0x08000000, timeout=3)
                time.sleep(0.3)
            except Exception as kill_exc:
                diag(f"failed to kill zombie process {existing_pid}: {kill_exc}")

        try:
            guard.bind(GUARD_ADDR)
            bound = True
            diag("successfully acquired HUD guard after terminating zombie process")
        except Exception as retry_exc:
            diag(f"failed to acquire HUD guard on retry: {retry_exc}")
            guard.close()
            return

    diag(f"HUD guard acquired on {GUARD_ADDR[0]}:{GUARD_ADDR[1]}; starting UI")
    FloatingUI(args.state_port, args.ui, guard).run()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        diag("unhandled HUD crash:\n" + traceback.format_exc())
        raise
