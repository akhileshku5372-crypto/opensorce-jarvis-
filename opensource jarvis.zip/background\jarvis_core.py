"""Compatibility entry point. The only voice implementation is voice_engine.py."""
import runpy
from pathlib import Path

if __name__ == '__main__':
    runpy.run_path(str(Path(__file__).with_name('voice_engine.py')), run_name='__main__')
