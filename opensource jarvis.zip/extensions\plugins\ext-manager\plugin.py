"""ext-manager: real introspection plugin for the JARVIS Extension System.

Tools here read live state through background/extensions.py - they never
invent a capability. `TOOLS` is the contract the Plugin Manager reads when it
registers into the cortex ToolRegistry; `handler` is a plain callable, so no
shell and no eval is ever involved.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _extensions():
    import importlib.util
    key = "jarvis_extensions"
    mod = sys.modules.get(key)
    if mod is not None:
        return mod
    spec = importlib.util.spec_from_file_location(
        key, ROOT / "background" / "extensions.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


def _handle_list(args: dict) -> dict:
    ext = _extensions()
    try:
        caps = ext.capabilities()
    except Exception as exc:
        return {"ok": False, "output": "could not read capabilities: %s" % exc}
    limit = int((args or {}).get("limit") or 20)
    lines = []
    for row in (caps.get("plugins") or [])[:limit]:
        lines.append("plugin %s v%s - %s" % (
            row.get("slug"), row.get("version"),
            "enabled" if row.get("enabled") else "disabled"))
    for row in (caps.get("skills") or [])[:limit]:
        lines.append("skill %s - %s" % (
            row.get("slug"), "enabled" if row.get("enabled") else "disabled"))
    for row in (caps.get("mcp") or [])[:limit]:
        lines.append("mcp %s - %s" % (
            row.get("name"),
            "online" if row.get("ok") else ("disabled" if not row.get("enabled")
                                             else "offline")))
    counts = caps.get("counts") or {}
    summary = ("%d plugins, %d skills, %d MCP (%d online), %d tools"
               % (counts.get("plugins", 0), counts.get("skills", 0),
                  counts.get("mcp_total", 0), counts.get("mcp_online", 0),
                  counts.get("tools", 0)))
    return {"ok": True, "output": summary + "\n" + "\n".join(lines)[:1500]}


def _handle_health(args: dict) -> dict:
    ext = _extensions()
    name = str((args or {}).get("name") or "").strip()
    if not name:
        return {"ok": False, "output": "name is required"}
    for row in ext.plugins():
        if row.get("slug") == name:
            report = ext.plugin_health(name)
            return {"ok": bool(report.get("ok")),
                    "output": "%s: %s" % (name, report.get("error") or "healthy")}
    for row in ext.mcp_servers():
        if row.get("name") == name:
            return {"ok": bool(row.get("ok")),
                    "output": "mcp %s: %s" % (
                        name, "online" if row.get("ok") else (row.get("error") or "offline"))}
    for row in ext.skills():
        if row.get("slug") == name or row.get("name") == name:
            return {"ok": True, "output": "skill %s is installed" % name}
    return {"ok": False, "output": "no plugin, skill or MCP server named '%s'" % name}


TOOLS = [
    {
        "name": "list_extensions",
        "description": "List every installed plugin, skill and MCP server with real health.",
        "parameters": {
            "limit": {"type": "integer", "description": "max rows per kind"},
        },
        "permission_category": "read_files",
        "requires_confirmation": False,
        "handler": _handle_list,
    },
    {
        "name": "extension_health",
        "description": "Health-check one plugin, skill or MCP connector by name.",
        "parameters": {
            "name": {"type": "string", "description": "plugin, skill or MCP server name"},
        },
        "permission_category": "read_files",
        "requires_confirmation": False,
        "handler": _handle_health,
    },
]
