"""Claude-style Skills loader for JARVIS (SKILL.md folders, stdlib only).

A "skill" is a folder with a SKILL.md file:

    skills/<slug>/SKILL.md
    ---
    name: meeting-notes
    description: Turn a rough transcript into structured meeting notes.
    triggers: meeting notes, minutes banao, notes banao meeting se
    ---
    <markdown instructions the assistant follows>

Progressive disclosure (same idea as Claude Skills):
  * level 1 - every skill's name + description goes into the system prompt
    (a tiny catalog, so token cost stays flat as skills grow);
  * level 2 - the full body is only injected when the user's text actually
    matches a trigger, or when he explicitly asks for that skill.

Read-only and safe: files are only read, capped in size, and never executed.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILLS_DIR = ROOT / "skills"

_MAX_BODY_CHARS = 6000      # hard cap for one skill body pulled into a prompt
_MAX_CATALOG = 40           # catalog entries injected into the prompt
_FRONT_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.S)
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9\-_. ]{0,60}$", re.I)

_cache: dict = {"revision": None, "skills": []}


def _parse_frontmatter(raw: str) -> tuple:
    """Tiny YAML subset: `key: value` lines, comma-separated trigger lists."""
    meta, body = {}, raw
    match = _FRONT_RE.match(raw)
    if match:
        body = raw[match.end():]
        for line in match.group(1).splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            meta[key.strip().lower()] = value.strip()
    return meta, body.strip()


def parse_skill(path: Path):
    """Parse one SKILL.md (or <slug>.md). Returns None when unusable."""
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")[:_MAX_BODY_CHARS * 2]
    except Exception:
        return None
    meta, body = _parse_frontmatter(raw)
    slug = path.parent.name if path.name.lower() == "skill.md" else path.stem
    name = (meta.get("name") or slug).strip()
    if not _SLUG_RE.match(name):
        return None
    # Triggers accept BOTH the shipped comma form (`a, b, c`, see
    # skills/meeting-notes) and natural YAML inline lists
    # (`["a", "b"]`). The old split-only parser kept the brackets and quotes,
    # so a YAML-list skill loaded fine but could never match a task - a silent
    # dead skill. Strip them and drop empties instead.
    raw_triggers = meta.get("triggers", "")
    if isinstance(raw_triggers, (list, tuple)):
        parts = [str(t) for t in raw_triggers]
    else:
        parts = re.split(r"[,;|]", str(raw_triggers))
    triggers = []
    for part in parts:
        t = str(part).strip().strip("[]").strip().strip('"').strip("'").strip().lower()
        if t:
            triggers.append(t)
    description = (meta.get("description") or "").strip()
    if not description:
        # First non-heading line becomes the description (never invent one).
        for line in body.splitlines():
            if line.strip() and not line.lstrip().startswith("#"):
                description = line.strip()[:160]
                break
    return {
        "name": name,
        "slug": slug,
        "description": description[:200],
        "triggers": triggers,
        "body": body[:_MAX_BODY_CHARS],
        "path": str(path),
    }


def _iter_files():
    if not SKILLS_DIR.is_dir():
        return []
    found = []
    for entry in sorted(SKILLS_DIR.iterdir()):
        if entry.is_dir():
            for candidate in ("SKILL.md", "skill.md", "Skill.md"):
                path = entry / candidate
                if path.is_file():
                    found.append(path)
                    break
        elif entry.is_file() and entry.suffix.lower() == ".md":
            found.append(entry)
    return found


def revision() -> int:
    """Cheap change token (names + mtimes + sizes) for STATE['skills_revision']."""
    stamp = 0
    for path in _iter_files():
        try:
            stat = path.stat()
            stamp = (stamp * 31 + int(stat.st_mtime) + stat.st_size) % (2 ** 62)
        except Exception:
            continue
    return stamp


def load(force: bool = False) -> list:
    """All usable skills, cached until the folder changes."""
    current = revision()
    if force or _cache["revision"] != current:
        skills = []
        for path in _iter_files():
            parsed = parse_skill(path)
            if parsed:
                skills.append(parsed)
        _cache["revision"] = current
        _cache["skills"] = skills
    return list(_cache["skills"])


def names() -> list:
    return [s["name"] for s in load()]


def get(name: str):
    wanted = str(name or "").strip().lower()
    for skill in load():
        if wanted in (skill["name"].lower(), skill["slug"].lower()):
            return skill
    return None


def body(name: str) -> str:
    skill = get(name)
    return skill["body"] if skill else ""


def match(text: str, limit: int = 2) -> list:
    """Skills whose trigger phrase appears in the text (longest trigger wins)."""
    haystack = " " + re.sub(r"\s+", " ", str(text or "").lower()).strip() + " "
    hits = []
    for skill in load():
        for trigger in skill["triggers"]:
            if len(trigger) >= 4 and trigger in haystack:
                hits.append((len(trigger), skill))
                break
    hits.sort(key=lambda item: -item[0])
    out, seen = [], set()
    for _length, skill in hits:
        if skill["name"] in seen:
            continue
        seen.add(skill["name"])
        out.append(skill)
        if len(out) >= limit:
            break
    return out


def describe(limit: int = 6) -> str:
    """Spoken summary of the installed skills (honest when the folder is empty)."""
    skills = load()
    if not skills:
        return ("Sir, skills folder khaali hai - koi SKILL.md nahi mila. "
                "skills/<name>/SKILL.md banaiye to main use load kar lunga.")
    head = ", ".join(s["name"] for s in skills[:limit])
    more = "" if len(skills) <= limit else " (aur %d)" % (len(skills) - limit)
    return "Sir, %d skill%s loaded: %s%s." % (
        len(skills), "" if len(skills) == 1 else "s", head, more)


def context_for(text: str) -> str:
    """Prompt fragment: compact catalog + full body of the matched skills only."""
    skills = load()
    if not skills:
        return ""
    catalog = " | ".join("%s: %s" % (s["name"], s["description"]) for s in skills[:_MAX_CATALOG])
    out = " SKILLS (instruction packs, use only when relevant): %s. " % catalog
    for skill in match(text):
        out += (" SKILL '%s' ACTIVE - follow these instructions for this task:\n%s\n"
                % (skill["name"], skill["body"][:3000]))
    return out
