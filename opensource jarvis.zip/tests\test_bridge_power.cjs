// Bridge P0 power-isolation checks. Extracts the shipped deny gate out of
// local-bridge/server.cjs (no HTTP server is started) and asserts that the
// verbs which would reach shutdown.exe / SetSuspendState are denied, while the
// rescue action and app-target verbs still pass through.
// Run:  npm run test:power
const fs = require('fs')
const path = require('path')

const source = fs.readFileSync(path.join(__dirname, '..', 'local-bridge', 'server.cjs'), 'utf8')
const start = source.indexOf('const POWER_VERB_PATTERN')
const end = source.indexOf('async function routeAction')
if (start < 0 || end <= start) {
  console.error('FAIL: power gate block not found in local-bridge/server.cjs')
  process.exit(1)
}
const denyPowerIntent = new Function(source.slice(start, end) + '\nreturn denyPowerIntent')()

const denied = [
  'shutdown', 'shut down', 'power off', 'restart', 'reboot', 'hibernate',
  'suspend', 'standby', 'halt', 'log off', 'sign out', 'lock workstation',
  'sleep', 'shutdown now', 'shutdown karo', 'shut down karo', 'restart karo',
  'reboot karo', 'laptop band karo', 'system band karo', 'pc band karo',
  'computer so jao', 'laptop sula do', 'put my laptop to sleep',
  'restart the laptop', 'shutdown the system', 'system shutdown'
]
const allowed = [
  'shutdown cancel', 'cancel shutdown', 'restart chrome', 'close chrome',
  'open youtube', 'set brightness 50', 'volume up', 'take a screenshot',
  'restart notepad', 'log off teams', 'what time is it', 'kya haal hai'
]

let failures = 0
for (const command of denied) {
  if (!denyPowerIntent(command)) {
    failures++
    console.error('FAIL denied expected: %j', command)
  }
}
for (const command of allowed) {
  if (denyPowerIntent(command)) {
    failures++
    console.error('FAIL allowed expected: %j', command)
  }
}
if (failures) {
  console.error('BRIDGE POWER GATE: %d failure(s)', failures)
  process.exit(1)
}
console.log('BRIDGE POWER GATE: %d denied + %d allowed checks pass', denied.length, allowed.length)
