﻿"""Tests for DB-backed conversation history, selective memory, and D: storage.

Every test redirects JARVIS_DATA_ROOT at a temp directory BEFORE importing the
modules under test, so:
  * the suite never touches the real D:\\JARVIS_DATA, and
  * it proves the storage root is genuinely configurable rather than hardcoded.

The "restart" tests are the important ones: they drop every cached module and
re-import from scratch, which is what a real process restart looks like. A test
that only reused the same imported module would pass even if nothing was
actually persisted.
"""

import importlib
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent


def _fresh_modules(root: Path):
    """Point the data root at `root` and force a genuine re-import."""
    os.environ["JARVIS_DATA_ROOT"] = str(root)
    for name in ("conversation_store", "conversation_memory",
                 "jarvis_memory", "storage_paths"):
        sys.modules.pop(name, None)
    sys.path.insert(0, str(ROOT / "background"))
    return (importlib.import_module("storage_paths"),
            importlib.import_module("conversation_store"),
            importlib.import_module("conversation_memory"))


class _TempRoot:
    """Temp dir that tolerates Windows file locks.

    ChromaDB keeps its index files open for the life of the process, so a
    plain TemporaryDirectory.cleanup() raises PermissionError on Windows and
    turns every test into a cleanup error even when the assertion passed.
    """

    def __init__(self):
        self._tmp = tempfile.TemporaryDirectory()

    @property
    def path(self) -> Path:
        return Path(self._tmp.name)

    def cleanup(self):
        try:
            self._tmp.cleanup()
        except (PermissionError, OSError):
            # Best effort: the OS will reclaim the temp dir on its own. A lock
            # here must never be reported as a test failure.
            pass


class ConversationStoreTest(unittest.TestCase):
    def setUp(self):
        self.tmp = _TempRoot()
        self.addCleanup(self.tmp.cleanup)
        self.paths, self.cs, self.cm = _fresh_modules(self.tmp.path)

    def test_uses_configured_root_not_c_or_repo(self):
        """The whole point of the migration: data lands under the chosen root."""
        self.cs.new_conversation("jarvis")
        db = self.cs.storage_status()["surfaces"]["jarvis"]["path"]
        self.assertTrue(db.startswith(str(self.tmp.path)),
                        "conversation DB escaped the configured root: %s" % db)
        self.assertNotIn(str(ROOT / "chroma_db"), db)

    def test_save_survives_restart(self):
        """Write, drop every module, re-import, read back. Real persistence."""
        conv = self.cs.new_conversation("jarvis")
        self.cs.append_message(conv["id"], "user", "my city is Pune")
        self.cs.append_message(conv["id"], "assistant", "Noted.")

        _paths, cs2, _cm = _fresh_modules(self.tmp.path)

        again = cs2.get_conversation(conv["id"])
        self.assertTrue(again["ok"])
        self.assertEqual(len(again["messages"]), 2)
        self.assertEqual(again["messages"][0]["content"], "my city is Pune")

    def test_surfaces_are_isolated(self):
        """KamiSensei history must never leak into general chat."""
        a = self.cs.new_conversation("jarvis")
        b = self.cs.new_conversation("kamisensei")
        self.cs.append_message(a["id"], "user", "general chat")
        self.cs.append_message(b["id"], "user", "study chat")

        jarvis_ids = {c["id"] for c in self.cs.list_conversations("jarvis")}
        ks_ids = {c["id"] for c in self.cs.list_conversations("kamisensei")}
        self.assertIn(a["id"], jarvis_ids)
        self.assertNotIn(b["id"], jarvis_ids)
        self.assertNotIn(a["id"], ks_ids)

    def test_title_rename_delete_and_ordering(self):
        first = self.cs.new_conversation("jarvis")
        self.cs.append_message(first["id"], "user", "hello there friend")
        self.assertIn("hello", self.cs.get_conversation(first["id"])["title"])

        renamed = self.cs.rename_conversation(first["id"], "Trip planning")
        self.assertTrue(renamed["ok"])
        self.assertEqual(self.cs.get_conversation(first["id"])["title"],
                         "Trip planning")

        second = self.cs.new_conversation("jarvis")
        rows = self.cs.list_conversations("jarvis")
        # Most recently updated first.
        self.assertEqual(rows[0]["id"], second["id"])

        self.assertTrue(self.cs.delete_conversation(first["id"])["ok"])
class MemoryExtractionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = _TempRoot()
        self.addCleanup(self.tmp.cleanup)
        _p, _cs, self.cm = _fresh_modules(self.tmp.path)

    def test_junk_is_never_remembered(self):
        """The core anti-ChatGPT-clutter guarantee."""
        for text in ("ok", "thanks!", "hey", "good morning", "what is 2+2",
                     "ok thanks", "sure"):
            with self.subTest(text=text):
                self.assertEqual(self.cm.extract(text), [])

    def test_assistant_turns_are_never_learned(self):
        self.assertEqual(self.cm.extract("My name is Bob", "assistant"), [])

    def test_durable_facts_are_extracted(self):
        found = self.cm.extract("Hi, my name is Testbot and my city is Zurich")
        keys = {item["key"] for item in found}
        self.assertIn("user.name", keys)
        self.assertIn("user.city", keys)

    def test_preferences_are_extracted(self):
        keys = {i["key"] for i in self.cm.extract("I prefer short Hinglish answers")}
        self.assertIn("user.likes", keys)
        keys = {i["key"] for i in self.cm.extract("I do not like long explanations")}
        self.assertIn("user.dislikes", keys)

    def test_capitals_inside_values_are_preserved(self):
        found = self.cm.extract("remember that I work in Mumbai")
        self.assertEqual(found[0]["text"], "I work in Mumbai.")

    def test_supersede_replaces_rather_than_duplicates(self):
        """Newer information must update, not accumulate contradictions."""
        if not self.cm.status()["available"]:
            self.skipTest("chromadb unavailable")
        self.cm.forget()
        self.assertEqual(self.cm.remember("user.city", "User's city is Pune.")["ok"], True)
        second = self.cm.remember("user.city", "User's city is Mumbai.")
        self.assertEqual(second["superseded"], 1)
        rows = [m["text"] for m in self.cm.all_memories() if m["key"] == "user.city"]
        self.assertEqual(rows, ["User's city is Mumbai."])

    def test_learn_reports_honestly_what_it_stored(self):
        if not self.cm.status()["available"]:
            self.skipTest("chromadb unavailable")
        self.cm.forget()
        result = self.cm.learn_from_messages([
            {"role": "user", "content": "my city is Pune"},
            {"role": "assistant", "content": "Got it"},
            {"role": "user", "content": "thanks"},
        ])
        self.assertEqual(result["learned"], 1)

    def test_retrieval_returns_relevant_memory(self):
        if not self.cm.status()["available"]:
            self.skipTest("chromadb unavailable")
        self.cm.forget()
        self.cm.remember("user.city", "User's city is Zurich.")
        self.assertTrue(any("Zurich" in r for r in self.cm.recall("where do I live")))


class MemoryIsSeparateFromTranscriptTest(unittest.TestCase):
    def setUp(self):
        self.tmp = _TempRoot()
        self.addCleanup(self.tmp.cleanup)
        self.paths, self.cs, self.cm = _fresh_modules(self.tmp.path)

    def test_deleting_chat_does_not_erase_memory(self):
        """Clear-chat and forget-a-fact are different user intents."""
        if not self.cm.status()["available"]:
            self.skipTest("chromadb unavailable")
        self.cm.forget()
        conv = self.cs.new_conversation("jarvis")
        self.cs.append_message(conv["id"], "user", "my city is Pune")
        self.cm.learn_from_messages(self.cs.get_conversation(conv["id"])["messages"])
        self.assertTrue(any("Pune" in m["text"] for m in self.cm.all_memories()))

        self.cs.delete_conversation(conv["id"])
        self.assertEqual(self.cs.list_conversations("jarvis"), [])
        self.assertTrue(any("Pune" in m["text"] for m in self.cm.all_memories()),
                        "memory must survive deleting the conversation")

    def test_user_memory_is_not_stored_in_the_rag_collection(self):
        """KamiSensei documents and user memory must not share a namespace."""
        if not self.cm.status()["available"]:
            self.skipTest("chromadb unavailable")
        self.cm.forget()
        self.cm.remember("user.city", "User's city is Pune.")
        self.assertNotEqual(self.cm.COLLECTION, "kami_sensei_knowledge")
        self.assertNotEqual(str(self.paths.jarvis_memory_dir()),
                            str(self.paths.kamisensei_rag_dir()))


class StorageFallbackTest(unittest.TestCase):
    def test_unusable_root_falls_back_instead_of_crashing(self):
        """A missing D: must not take the app down, and must be reported."""
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        os.environ["JARVIS_DATA_ROOT"] = r"Z:\nonexistent_volume_xyz"
        sys.modules.pop("storage_paths", None)
        paths = importlib.import_module("storage_paths")
        status = paths.status()
        # Either it resolved somewhere real, or it fell back - both are safe.
        # What must never happen is an exception or a silent fake success.
        self.assertIn("root", status)
        self.assertTrue(status["root"])


class _Store:
    """A temp-rooted pair (conversation_memory, memory_protocol).

    Wraps the existing _TempRoot helper, which exposes cleanup() rather than
    the context-manager protocol - reusing it keeps the Windows file-lock
    handling in one place instead of duplicating it.
    """

    def __init__(self):
        self._tmp = _TempRoot()
        # _fresh_modules returns (storage_paths, conversation_store,
        # conversation_memory) - the memory module is the THIRD slot.
        _, _, self.mem = _fresh_modules(self._tmp.path)
        sys.path.insert(0, str(ROOT / "background"))
        sys.modules.pop("memory_protocol", None)
        self.proto = importlib.import_module("memory_protocol")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self._tmp.cleanup()
        return False


class TestTokenParsing(unittest.TestCase):
    """Parsing is pure string work - no store needed."""

    def setUp(self):
        sys.path.insert(0, str(ROOT / "background"))
        sys.modules.pop("memory_protocol", None)
        self.proto = importlib.import_module("memory_protocol")

    def test_parses_remember_and_forget(self):
        reply = "Note kar liya Sir.\nMEMORY: Sir ka favourite colour deep blue hai\nDone."
        ops = self.proto.parse_triggers(reply)
        self.assertEqual(len(ops), 1)
        self.assertEqual(ops[0][0], "remember")
        self.assertIn("deep blue", ops[0][1])

    def test_forget_token(self):
        ops = self.proto.parse_triggers("theek hai\nMEMORY_FORGET: favourite colour")
        self.assertEqual(ops[0][0], "forget")

    def test_token_stripped_from_spoken_reply(self):
        reply = "Saved Sir, noted it. MEMORY: Sir ka sheher Delhi hai"
        cleaned = self.proto.strip_triggers(reply)
        self.assertNotIn("MEMORY:", cleaned)
        self.assertIn("Saved Sir", cleaned)

    def test_empty_value_ignored(self):
        # A stray "MEMORY:" with nothing after it must not become a no-op write.
        self.assertEqual(self.proto.parse_triggers("ok\nMEMORY:\nbye"), [])

    def test_no_token_returns_clean_reply_untouched(self):
        reply = "Sir ye toh classic move hai"
        self.assertEqual(self.proto.parse_triggers(reply), [])
        self.assertEqual(self.proto.strip_triggers(reply), reply)


class TestRealWrites(unittest.TestCase):
    """Hit the real store in a temp dir - proving the prompt can lie no more."""

    def test_token_actually_persists_and_supersedes(self):
        with _Store() as t:
            r1 = t.proto.apply_triggers("ok\nMEMORY: my name is Prateek")
            self.assertEqual(r1["learned"], 1, r1)
            self.assertNotIn("MEMORY:", r1["reply"])
            self.assertTrue(t.mem.recall("what is my name", 4), "must be recallable")
            # A NEWER value for the same key must replace, not accumulate.
            r2 = t.proto.apply_triggers("ok\nMEMORY: my name is Rahul")
            self.assertEqual(r2["learned"], 1, r2)
            joined = " ".join(m["text"] for m in t.mem.all_memories())
            self.assertNotIn("Prateek", joined, "old value must be superseded")

    def test_forget_token_really_deletes(self):
        with _Store() as t:
            t.proto.apply_triggers("ok\nMEMORY: my city is Delhi")
            self.assertTrue(t.mem.all_memories())
            res = t.proto.apply_triggers("hata do\nMEMORY_FORGET: Delhi")
            self.assertEqual(res["forgotten"], 1, res)
            self.assertFalse(t.mem.all_memories(), "must really be gone")

    def test_extraction_is_selective_not_blob(self):
        # A long essay must NOT be stored verbatim, only auditable facts.
        with _Store() as t:
            essay = ("Aaj mausam bahut badhiya hai. " * 40 +
                     "My name is Prateek. " +
                     "I hate waking up early. " * 30)
            res = t.proto.apply_triggers("saved\nMEMORY: " + essay)
            self.assertLessEqual(res["learned"], 5, "must extract, not store blob")
            for m in t.mem.all_memories():
                self.assertLess(len(m["text"]), 200, "no raw essay stored")

    def test_junk_produces_no_memory(self):
        with _Store() as t:
            res = t.proto.apply_triggers("ok\nMEMORY: hmm ok")
            self.assertEqual(res["learned"], 0, res)


class TestPromptHonesty(unittest.TestCase):
    """The prompt must announce the capability and never contradict itself."""

    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "background"))
        sys.modules.pop("memory_protocol", None)
        cls.proto = importlib.import_module("memory_protocol")

    def test_rules_advertise_write_capability(self):
        text = self.proto.MEMORY_RULES
        self.assertIn("MEMORY:", text)
        self.assertIn("MEMORY_FORGET:", text)
        self.assertIn("SUPERSEDES", text.upper())

    def test_rules_never_teach_a_refusal(self):
        # The exact regression: a prompt that tells the model memory is
        # forbidden would recreate the original bug.
        low = self.proto.MEMORY_RULES.lower()
        for forbidden in ("cannot edit", "can't edit", "not allowed to save",
                          "forbidden to write", "security policy prevents"):
            self.assertNotIn(forbidden, low,
                             "prompt must not teach a memory refusal: %r" % forbidden)

    def test_voice_prompt_includes_memory_rules(self):
        sys.path.insert(0, str(ROOT / "background"))
        for name in ("voice_engine", "memory_protocol"):
            sys.modules.pop(name, None)
        voice = importlib.import_module("voice_engine")
        prompt = voice._system_prompt("Sir, aapka naam kya hai?")
        self.assertIn("MEMORY:", prompt)
        self.assertIn("JARVIS CORE PROTOCOL", prompt)

    def test_chat_prompt_includes_memory_rules(self):
        tsx = (ROOT / "src" / "index.tsx").read_text(encoding="utf-8")
        self.assertIn("MEMORY_FORGET:", tsx)
        self.assertIn("JARVIS_CORE_PROTOCOL", tsx)


class TestExtractionQuality(unittest.TestCase):
    """Regressions for the extraction bugs found in real use."""

    def setUp(self):
        sys.path.insert(0, str(ROOT / "background"))
        for name in ("conversation_memory", "memory_protocol", "storage_paths"):
            sys.modules.pop(name, None)
        self.mem = importlib.import_module("conversation_memory")

    def test_hinglish_main_is_not_mistaken_for_a_name(self):
        # "main yaha rehta hun" used to be stored as the user's NAME being
        # "yaha", which then poisoned every later answer.
        self.assertEqual(self.mem.extract("main yaha rehta hun", "user"), [])

    def test_hinglish_location_is_captured_as_location(self):
        got = self.mem.extract("main Zurich mein rehta hun", "user")
        self.assertEqual([g["key"] for g in got], ["user.location"])
        self.assertIn("Zurich", got[0]["text"])

    def test_explicit_name_still_works(self):
        for text in ("my name is Prateek", "main Prateek hu", "call me Prateek"):
            keys = [g["key"] for g in self.mem.extract(text, "user")]
            self.assertIn("user.name", keys, text)

    def test_small_talk_stores_nothing(self):
        for text in ("chalo testing karte hai", "ok", "thanks", "hmm"):
            self.assertEqual(self.mem.extract(text, "user"), [], text)


class TestCrossChatAndAutoLearn(unittest.TestCase):
    """The two gaps the user actually hit: cross-chat recall + auto-learn."""

    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "background"))
        for name in ("voice_engine", "memory_protocol"):
            sys.modules.pop(name, None)
        cls.voice = importlib.import_module("voice_engine")

    def test_prompt_carries_cross_chat_context_instruction(self):
        # The context block is data-driven, but the prompt must at least be
        # able to receive it.
        self.assertTrue(callable(self.voice._cross_chat_context))
        self.assertEqual(self.voice._cross_chat_context(""), "")

    def test_voice_auto_learn_runs_on_user_turn_only(self):
        self.assertTrue(callable(self.voice._auto_learn_voice))
        # Empty / junk input must be a no-op rather than an exception.
        self.voice._auto_learn_voice("")
        self.voice._auto_learn_voice("   ")

    def test_learn_route_rejects_non_jarvis_surface(self):
        src = (ROOT / "background" / "voice_engine.py").read_text(encoding="utf-8")
        self.assertIn("learn_not_allowed_on_this_surface", src)

    def test_chat_reads_memory_from_core_not_localstorage(self):
        js = (ROOT / "public" / "static" / "app.js").read_text(encoding="utf-8")
        self.assertIn("recallMemories", js)
        self.assertIn("conversationWindow", js)
        # The stale localStorage-only read must be gone from the send path.
        self.assertNotIn("localStorage.getItem('jarvis-memories') || '[]').map", js)


class TestStorageQuota(unittest.TestCase):
    """The 10 GB ceiling on the data root.

    Without a ceiling the only limit is the disk itself, so a runaway RAG
    ingest could fill D:. These tests use a tiny ceiling so the guard can be
    exercised without writing gigabytes.
    """

    def setUp(self):
        sys.path.insert(0, str(ROOT / "background"))
        os.environ.pop("JARVIS_DATA_MAX_GB", None)
        for name in ("storage_paths",):
            sys.modules.pop(name, None)
        self.paths = importlib.import_module("storage_paths")
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.paths._STATE.update({"root": self.root, "fallback": None})
        self.paths._USAGE_CACHE.update({"at": 0.0, "bytes": None})

    def tearDown(self):
        os.environ.pop("JARVIS_DATA_MAX_GB", None)
        try:
            self.tmp.cleanup()
        except (PermissionError, OSError):
            pass

    def test_default_ceiling_is_ten_gb(self):
        self.assertEqual(self.paths.DEFAULT_MAX_GB, 10.0)
        self.assertEqual(self.paths.max_bytes(), 10 * 1024 ** 3)

    def test_usage_counts_real_files(self):
        (self.root / "a.bin").write_bytes(b"x" * 5000)
        self.assertGreaterEqual(self.paths.usage_bytes(max_age=0.0), 5000)

    def test_write_allowed_below_ceiling(self):
        os.environ["JARVIS_DATA_MAX_GB"] = "0.00001"   # ~10 KB
        self.assertTrue(self.paths.guard_write(100))

    def test_write_blocked_above_ceiling(self):
        os.environ["JARVIS_DATA_MAX_GB"] = "0.00001"   # ~10 KB
        (self.root / "big.bin").write_bytes(b"y" * 40000)
        self.paths._USAGE_CACHE.update({"at": 0.0, "bytes": None})
        self.assertFalse(self.paths.guard_write(100))

    def test_zero_disables_the_ceiling(self):
        os.environ["JARVIS_DATA_MAX_GB"] = "0"
        self.assertEqual(self.paths.max_bytes(), 0)
        self.assertTrue(self.paths.guard_write(10 ** 15))

    def test_garbage_env_falls_back_to_default(self):
        os.environ["JARVIS_DATA_MAX_GB"] = "not-a-number"
        self.assertEqual(self.paths.max_bytes(), 10 * 1024 ** 3)

    def test_status_reports_both_numbers(self):
        info = self.paths.status()
        self.assertIn("used_bytes", info)
        self.assertIn("max_gb", info)

    def test_memory_write_respects_quota(self):
        os.environ["JARVIS_DATA_MAX_GB"] = "0.00001"
        for name in ("conversation_memory", "jarvis_memory", "storage_paths"):
            sys.modules.pop(name, None)
        self.paths = importlib.import_module("storage_paths")
        self.paths._STATE.update({"root": self.root, "fallback": None})
        (self.root / "big.bin").write_bytes(b"z" * 40000)
        self.paths._USAGE_CACHE.update({"at": 0.0, "bytes": None})
        mem = importlib.import_module("conversation_memory")
        res = mem.remember("user.test", "a new fact to store")
        self.assertFalse(res.get("ok"))
        self.assertEqual(res.get("error"), "storage_quota_reached")


class TestActiveConversationRuntimeContext(unittest.TestCase):
    """The missing runtime connection: stored transcript -> prompt -> LLM request.

    Locks in the live failure: task -> "confirm" -> done, then an indirect
    follow-up must resolve WITHOUT the user repeating the task - even when the
    process-local `_history` window is empty (core restart, mixed surfaces, or
    a provider hop that skips the window). Also locks the New Chat split: a new
    transcript starts clean while long-term memory stays retrievable.
    """

    @classmethod
    def setUpClass(cls):
        cls.tmp = _TempRoot()
        cls.addClassCleanup(cls.tmp.cleanup)
        os.environ["JARVIS_DATA_ROOT"] = str(cls.tmp.path)
        sys.path.insert(0, str(ROOT / "background"))
        # Purge plain AND _load_bg shared-key identities so store, memory and
        # the voice core all resolve against THIS temp root, never a stale one.
        for name in list(sys.modules):
            if (name in ("conversation_store", "conversation_memory",
                         "jarvis_memory", "storage_paths", "voice_engine",
                         "memory_protocol")
                    or name.startswith("jarvis_cowork_")):
                sys.modules.pop(name, None)
        cls.store = importlib.import_module("conversation_store")
        cls.voice = importlib.import_module("voice_engine")
        # Never touch the real runtime pointer file from a test.
        cls.active_file = cls.tmp.path / "active_conversation.json"
        cls.voice._ACTIVE_CONVERSATION_FILE = str(cls.active_file)

    def setUp(self):
        self.voice._history.clear()
        self.voice._CONTEXT_CONV_ID = ""
        self.voice._provider_retry_at.clear()
        self.voice.STATE["cortex_confirm"] = None
        self.voice._WA_PENDING.clear()

    def _activate(self, conv_id):
        """Browser reports which conversation is on screen (same route as
        POST /conversations/active)."""
        self.active_file.write_text(
            json.dumps({"id": conv_id, "at": time.time()}), encoding="utf-8")

    def _whatsapp_thread(self):
        """The exact reported scenario: task -> confirm -> done."""
        conv = self.store.new_conversation("jarvis")
        self.store.append_message(conv["id"], "user",
                                  "akhilesh ko whatsapp pe hello bhejo")
        self.store.append_message(conv["id"], "assistant",
                                  "Sir, message stage hai - boliye confirm.")
        self.store.append_message(conv["id"], "user", "confirm")
        self.store.append_message(conv["id"], "assistant", "bhej diye message.")
        return conv

    def test_indirect_reference_after_confirm_needs_no_repetition(self):
        conv = self._whatsapp_thread()
        self._activate(conv["id"])
        # Process-local window is EMPTY - a core restart. Only the stored
        # transcript can carry the task forward, and it must.
        prompt = self.voice._system_prompt("aur uska kya hua, sab ho gaya?")
        self.assertIn("ACTIVE CONVERSATION", prompt)
        self.assertIn("akhilesh ko whatsapp pe hello bhejo", prompt)
        self.assertIn("bhej diye message", prompt)

    def test_context_is_injected_into_the_llm_request(self):
        """Retrieval is worthless unless the payload carries it: build the REAL
        provider request and assert the context is inside it."""
        conv = self._whatsapp_thread()
        self._activate(conv["id"])
        seen = {}

        class _Resp:
            def raise_for_status(self):
                return None

            def json(self):
                return {"reply": "theek hai Sir"}

        def fake_post(url, **kw):
            seen["url"], seen["payload"] = str(url), kw.get("json")
            return _Resp()

        keys = ("GOOGLE_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY_2",
                "GROQ_API_KEY", "XKIRO_API_KEY", "OPENROUTER_API_KEY",
                "NVIDIA_API_KEY", "OLLAMA_URL")
        saved = {k: os.environ.pop(k, None) for k in keys}
        try:
            with patch.object(self.voice.requests, "post", side_effect=fake_post):
                reply = self.voice._brain_raw(
                    "confirm ke baad kya hua?", "http://127.0.0.1:7777")
        finally:
            os.environ.update({k: v for k, v in saved.items() if v is not None})
        self.assertEqual(reply, "theek hai Sir")
        self.assertIn("/api/ai/chat", seen["url"])
        messages = seen["payload"]["messages"]
        self.assertEqual(messages[-1]["content"], "confirm ke baad kya hua?")
        system = messages[0]["content"]
        self.assertIn("akhilesh ko whatsapp pe hello bhejo", system)
        self.assertIn("bhej diye message", system)

    def test_older_message_from_same_conversation_pulled_when_needed(self):
        conv = self.store.new_conversation("jarvis")
        self.store.append_message(
            conv["id"], "user",
            "project umbra ka deadline friday hai, use priority banao")
        for i in range(16):
            self.store.append_message(conv["id"], "user", "filler update %d" % i)
            self.store.append_message(conv["id"], "assistant",
                                      "theek hai sir %d" % i)
        self._activate(conv["id"])
        prompt = self.voice._system_prompt("umbra deadline kab hai?")
        # Row 0 sits far beyond the recent window - only relevance pulls it in.
        self.assertIn("project umbra ka deadline friday hai", prompt)
        self.assertIn("older rows matched to this message", prompt)

    def test_new_chat_starts_fresh_and_long_term_memory_survives(self):
        conv = self._whatsapp_thread()
        self._activate(conv["id"])
        mem = self.voice._load_bg("conversation_memory")
        if not mem.status()["available"]:
            self.skipTest("chromadb unavailable")
        mem.forget(text="Pune")
        self.assertTrue(mem.remember("user.city", "User's city is Pune.")["ok"])
        try:
            self.voice._system_prompt("hello")     # adopts conv id
            self.voice._remember_turn("old side task", "done")
            self._activate("")                     # New Chat posts active id ''
            prompt = self.voice._system_prompt("mera sheher kaun sa hai?")
            self.assertNotIn("akhilesh ko whatsapp pe hello bhejo", prompt)
            self.assertNotIn("old side task", prompt)
            self.assertEqual(self.voice._history, [])   # stale window dropped
            self.assertIn("Pune", prompt)               # long-term memory intact
        finally:
            mem.forget(text="Pune")

    def test_pending_task_state_reaches_the_prompt(self):
        conv = self.store.new_conversation("jarvis")
        self._activate(conv["id"])
        self.voice.STATE["cortex_confirm"] = {
            "tool": "whatsapp_send", "args": {"contact": "akhilesh"},
            "at": time.time()}
        self.voice._WA_PENDING.update(
            {"at": time.time(), "recipient": "akhilesh", "message": "hello",
             "label": "akhilesh", "text": ""})
        prompt = self.voice._system_prompt("confirm karun?")
        self.assertIn("TASK STATE", prompt)
        self.assertIn("whatsapp_send", prompt)
        self.assertIn("unsent WhatsApp message to akhilesh", prompt)

    def test_voice_and_text_read_the_same_session_store(self):
        """Parity: the rows the voice prompt injects are exactly the rows the
        browser conversationWindow() GETs from /conversations/<id> - one
        store, one surface, one session for both channels."""
        conv = self._whatsapp_thread()
        self._activate(conv["id"])
        prompt = self.voice._system_prompt("kya bheja tha?")
        rows = self.store.get_conversation(conv["id"], "jarvis")["messages"]
        self.assertTrue(rows)
        for row in rows:
            self.assertIn(row["content"], prompt)
        js = (ROOT / "public" / "static" / "app.js").read_text(encoding="utf-8")
        self.assertIn("conversationWindow(20, text)", js)
        self.assertIn("recallMemories", js)

    def test_live_session_starts_with_the_open_chat_not_only_facts(self):
        """Classic -> Live must not forget the conversation on screen.

        The reported bug: opening Live asked about a task that had just been
        discussed as if it had never happened. Live has no chat-message window,
        so its system instruction must carry both the stored transcript and the
        process-local turns (deduplicated), plus any pending task state.
        """
        conv = self._whatsapp_thread()
        self._activate(conv["id"])
        # The same two turns also live in the process window, as they do in
        # production; the digest must not repeat them.
        self.voice._history[:] = [
            {"role": "user", "content": "akhilesh ko whatsapp pe hello bhejo"},
            {"role": "assistant", "content": "Sir, message stage hai - boliye confirm."},
            {"role": "user", "content": "live kholne se pehle wala turn"},
            {"role": "assistant", "content": "yaad hai sir"},
        ]
        self.voice._WA_PENDING.update(
            {"at": time.time(), "recipient": "akhilesh", "message": "hello",
             "label": "akhilesh", "text": ""})

        captured = {}

        class _FakeLive:
            def __init__(self, **kwargs):
                captured.update(kwargs)

        class _FakeLiveModule:
            PERSONA_DEFAULT = "BASE PERSONA"
            LiveSession = _FakeLive

        real_load = self.voice._load_bg

        def _load(name):
            return _FakeLiveModule if name == "live_session" else real_load(name)

        with patch.object(self.voice, "_load_bg", side_effect=_load):
            self.voice._live_session_factory(lambda *_a: None, lambda **_k: None)

        persona = captured["persona"]
        self.assertIn("akhilesh ko whatsapp pe hello bhejo", persona)
        self.assertIn("bhej diye message", persona)
        self.assertIn("live kholne se pehle wala turn", persona)
        self.assertIn("yaad hai sir", persona)
        self.assertEqual(
            persona.count("akhilesh ko whatsapp pe hello bhejo"), 1,
            "a turn present in both stores must be injected once")
        self.assertIn("TASK STATE", persona)
        self.assertIn("unsent WhatsApp message to akhilesh", persona)
        self.assertIn("RECENT CHAT", persona)

    def test_live_turn_is_persisted_and_survives_back_to_classic(self):
        """Live -> classic / restart: a spoken exchange must still be there.

        Live audio never goes through the dashboard send path, so the core is
        the only writer. The event is marked `origin=live` so the browser does
        not write the assistant half again.
        """
        conv = self.store.new_conversation("jarvis")
        self._activate(conv["id"])
        self.voice._live_turn("live question", "live answer")

        rows = self.store.get_conversation(conv["id"], "jarvis")["messages"]
        self.assertEqual(
            [(r["role"], r["content"]) for r in rows],
            [("user", "live question"), ("assistant", "live answer")])
        events = [e for e in (self.voice.get_state().get("events") or [])
                  if e.get("text") in ("live question", "live answer")]
        self.assertEqual(len(events), 2)
        self.assertTrue(all(e.get("origin") == "live" for e in events))

        # A core restart empties the process window. The stored transcript is
        # then the only thing that can carry the Live turn into classic.
        self.voice._history.clear()
        prompt = self.voice._system_prompt("hum kya baat kar rahe the?")
        self.assertIn("live question", prompt)
        self.assertIn("live answer", prompt)


if __name__ == "__main__":
    unittest.main(verbosity=2)

