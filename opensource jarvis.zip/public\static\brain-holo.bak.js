/* JARVIS Brain Hologram — an anatomically-inspired human brain (Three.js).
   Renders the Neural-Brain centerpiece only: a folded cortical surface (gyri +
   sulci from seeded simplex noise), a deep longitudinal fissure splitting the
   two hemispheres, a ridged cerebellum and a brainstem. The whole brain is
   tinted by the active routing lobe. Orbit (drag) / zoom (scroll) via
   OrbitControls. The 8 capability cards + SVG wires + status bar live in the
   HTML layer (index.tsx) and are driven from app.js via the CAPS / LOBE_TO_CAP
   maps exposed on window.__JARVIS_BRAIN_HOLO__. This file never fabricates
   data — it only visualises the lobe the core already routed. */
(() => {
  const CAPS = [
    { id:'vision',       label:'Vision',       color:'#22c55e' },
    { id:'language',     label:'Language',     color:'#14b8a6' },
    { id:'audio',        label:'Audio',        color:'#f43f5e' },
    { id:'memory',       label:'Memory',       color:'#3b82f6' },
    { id:'tools',        label:'Tools',        color:'#f97316' },
    { id:'planning',     label:'Planning',     color:'#eab308' },
    { id:'coding',       label:'Coding',       color:'#8b5cf6' },
    { id:'computer_use', label:'Computer Use', color:'#06b6d4' },
  ]
  const LOBE_TO_CAP = {
    prefrontal_cortex:'planning', cerebrum:'coding', motor_cortex:'tools',
    hippocampus:'memory', broca_area:'audio',
  }
  const LOBE_COLOR = {
    prefrontal_cortex:'#19e6ff', cerebrum:'#8b5cf6', motor_cortex:'#ff8a00',
    hippocampus:'#25dda2', broca_area:'#f472b6',
  }
  const DEFAULT_COLOR = '#19e6ff'

  // ── seeded 3D simplex noise (Gustavson) ───────────────────────────────────
  function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
  const F3=1/3,G3=1/6
  const grad3=new Float32Array([1,1,0,-1,1,0,1,-1,0,-1,-1,0,1,0,1,-1,0,1,1,0,-1,-1,0,-1,0,1,1,0,-1,1,0,1,-1,0,-1,-1])
  function SimplexNoise(seed){
    const p=new Uint8Array(256); for(let i=0;i<256;i++)p[i]=i
    const rnd=mulberry32(seed||1)
    for(let i=255;i>0;i--){const j=Math.floor(rnd()*(i+1));const t=p[i];p[i]=p[j];p[j]=t}
    this.perm=new Uint8Array(512); this.permMod12=new Uint8Array(512)
    for(let i=0;i<512;i++){this.perm[i]=p[i&255];this.permMod12[i]=this.perm[i]%12}
  }
  SimplexNoise.prototype.noise3D=function(xin,yin,zin){
    const perm=this.perm,permMod12=this.permMod12
    let n0,n1,n2,n3
    const s=(xin+yin+zin)*F3
    const i=Math.floor(xin+s),j=Math.floor(yin+s),k=Math.floor(zin+s)
    const t=(i+j+k)*G3
    const x0=xin-(i-t),y0=yin-(j-t),z0=zin-(k-t)
    let i1,j1,k1,i2,j2,k2
    if(x0>=y0){ if(y0>=z0){i1=1;j1=0;k1=0;i2=1;j2=1;k2=0} else if(x0>=z0){i1=1;j1=0;k1=0;i2=1;j2=0;k2=1} else {i1=0;j1=0;k1=1;i2=1;j2=0;k2=1} }
    else { if(y0<z0){i1=0;j1=0;k1=1;i2=0;j2=1;k2=1} else if(x0<z0){i1=0;j1=1;k1=0;i2=0;j2=1;k2=1} else {i1=0;j1=1;k1=0;i2=1;j2=1;k2=0} }
    const x1=x0-i1+G3,y1=y0-j1+G3,z1=z0-k1+G3
    const x2=x0-i2+2*G3,y2=y0-j2+2*G3,z2=z0-k2+2*G3
    const x3=x0-1+3*G3,y3=y0-1+3*G3,z3=z0-1+3*G3
    const ii=i&255,jj=j&255,kk=k&255
    let t0=0.6-x0*x0-y0*y0-z0*z0
    if(t0<0)n0=0;else{const gi0=permMod12[ii+perm[jj+perm[kk]]]*3;t0*=t0;n0=t0*t0*(grad3[gi0]*x0+grad3[gi0+1]*y0+grad3[gi0+2]*z0)}
    let t1=0.6-x1*x1-y1*y1-z1*z1
    if(t1<0)n1=0;else{const gi1=permMod12[ii+i1+perm[jj+j1+perm[kk+k1]]]*3;t1*=t1;n1=t1*t1*(grad3[gi1]*x1+grad3[gi1+1]*y1+grad3[gi1+2]*z1)}
    let t2=0.6-x2*x2-y2*y2-z2*z2
    if(t2<0)n2=0;else{const gi2=permMod12[ii+i2+perm[jj+j2+perm[kk+k2]]]*3;t2*=t2;n2=t2*t2*(grad3[gi2]*x2+grad3[gi2+1]*y2+grad3[gi2+2]*z2)}
    let t3=0.6-x3*x3-y3*y3-z3*z3
    if(t3<0)n3=0;else{const gi3=permMod12[ii+1+perm[jj+1+perm[kk+1]]]*3;t3*=t3;n3=t3*t3*(grad3[gi3]*x3+grad3[gi3+1]*y3+grad3[gi3+2]*z3)}
    return 32*(n0+n1+n2+n3)
  }
  const NZ=new SimplexNoise(20261012)

  // Cortical fold field: layered simplex -> ridge field (crests where |n| small).
  function gyri(x,y,z){
    let n = NZ.noise3D(x*2.0+13.1, y*2.0+2.7, z*2.0+5.3)
    n += 0.55*NZ.noise3D(x*4.1+7.2, y*4.1+1.1, z*4.1+3.9)
    n += 0.28*NZ.noise3D(x*8.3+4.4, y*8.3+9.2, z*8.3+1.6)
    return n/1.83
  }

  let THREE=null, OC=null, renderer=null, scene=null, camera=null, controls=null
  let brainGroup=null, ro=null
  const surfaces=[], wires=[], pointMats=[]
  let coreGlow=null
  let raf=0, phase=0, initialized=false, reduceMotion=false
  let activeLobe='prefrontal_cortex', activeColor=DEFAULT_COLOR, autoRotate=true
  let wrap=null, canvas=null

  const getThree=()=>window.__JARVIS_THREE__||null
  const getOC=()=>window.__JARVIS_OrbitControls__||null
  const ensureDom=()=>{ canvas=document.getElementById('brain-canvas'); wrap=document.getElementById('brain-canvas-wrap'); return !!(canvas&&wrap) }

  // Soft round sprite so neuron points glow instead of looking like squares.
  function discTexture(){
    const c=document.createElement('canvas'); c.width=c.height=64
    const ctx=c.getContext('2d'); const g=ctx.createRadialGradient(32,32,0,32,32,32)
    g.addColorStop(0,'rgba(255,255,255,1)'); g.addColorStop(0.35,'rgba(255,255,255,0.55)'); g.addColorStop(1,'rgba(255,255,255,0)')
    ctx.fillStyle=g; ctx.fillRect(0,0,64,64)
    return new THREE.CanvasTexture(c)
  }

  // Cerebrum: ellipsoidal cortex + gyri/sulci + deep longitudinal fissure +
  // a subtle lateral (Sylvian) temporal depression. Pure function of the unit
  // direction, so a smooth-indexed sphere stays watertight and seam-free.
  function buildCerebrum(){
    const geo=new THREE.SphereGeometry(1,150,110)
    const pos=geo.attributes.position
    for(let i=0;i<pos.count;i++){
      const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i)
      const len=Math.sqrt(x*x+y*y+z*z)||1, dx=x/len,dy=y/len,dz=z/len
      const ridge=1-Math.abs(gyri(dx,dy,dz))       // 0..1, high on crests
      let disp=(ridge-0.42)*0.13                    // gyri (+) / sulci (-)
      const top=Math.max(0,dy), bot=Math.max(0,-dy)*0.55
      const fiss=Math.exp(-(dx*dx)/0.02)            // narrow midline valley
      disp-=fiss*(top+bot)*0.18
      const syl=Math.exp(-Math.pow((dy+0.28)/0.16,2))*Math.abs(dx)
      disp-=syl*0.05                               // temporal dip
      const r=1+disp
      pos.setXYZ(i, dx*r*1.16, dy*r*0.99, dz*r*1.30)
    }
    geo.computeVertexNormals()
    return geo
  }

  // Cerebellum: smaller ellipsoid with fine horizontal folia + central vermis.
  function buildCerebellum(){
    const geo=new THREE.SphereGeometry(1,120,90)
    const pos=geo.attributes.position
    for(let i=0;i<pos.count;i++){
      const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i)
      const len=Math.sqrt(x*x+y*y+z*z)||1, dx=x/len,dy=y/len,dz=z/len
      const n=NZ.noise3D(dx*7.5+3.1, dy*2.2+0.7, dz*7.5+6.2)
      const ridge=1-Math.abs(n)
      let disp=(ridge-0.45)*0.12
      const vermis=Math.exp(-(dx*dx)/0.015)
      disp-=vermis*0.12
      const r=1+disp
      pos.setXYZ(i, dx*r*0.74, dy*r*0.44, dz*r*0.54)
    }
    geo.computeVertexNormals()
    return geo
  }

  // Brainstem: tapered tube, gently ridged.
  function buildStem(){
    const geo=new THREE.CylinderGeometry(0.17,0.10,0.66,28,6,false)
    const pos=geo.attributes.position
    for(let i=0;i<pos.count;i++){
      const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i)
      const n=NZ.noise3D(x*6+2, y*6, z*6)
      const k=1+(1-Math.abs(n))*0.05
      pos.setXYZ(i, x*k, y, z*k)
    }
    geo.computeVertexNormals()
    return geo
  }

  // Bake fake lighting (two key dirs + rim, view~+z) into greyscale vertex
  // colors so the folds read clearly without any real lights.
  function bakeShade(geo){
    geo.computeVertexNormals()
    const n=geo.attributes.normal, cnt=n.count
    const colors=new Float32Array(cnt*3)
    const L1x=0.45,L1y=0.75,L1z=0.5,L1l=Math.sqrt(L1x*L1x+L1y*L1y+L1z*L1z)
    const L2x=-0.6,L2y=-0.15,L2z=0.4,L2l=Math.sqrt(L2x*L2x+L2y*L2y+L2z*L2z)
    for(let i=0;i<cnt;i++){
      const x=n.getX(i),y=n.getY(i),z=n.getZ(i)
      const d1=Math.max(0,(x*L1x+y*L1y+z*L1z)/L1l)
      const d2=Math.max(0,(x*L2x+y*L2y+z*L2z)/L2l)
      const rim=Math.pow(1-Math.min(1,Math.max(0,z)),2)
      let lum=0.18+0.62*d1+0.22*d2+0.35*rim
      lum=Math.min(1.35,lum)
      colors[i*3]=lum; colors[i*3+1]=lum; colors[i*3+2]=lum
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors,3))
  }

  // Sample ~target surface verts as glowing neuron points.
  function samplePoints(geo,target){
    const pos=geo.attributes.position, cnt=pos.count
    const step=Math.max(1,Math.floor(cnt/target))
    const arr=[]
    for(let i=0;i<cnt;i+=step) arr.push(pos.getX(i),pos.getY(i),pos.getZ(i))
    const g=new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(arr,3))
    return g
  }


  function surfMat(){ return new THREE.MeshBasicMaterial({vertexColors:true, color:new THREE.Color(activeColor)}) }
  function wireMat(){ return new THREE.MeshBasicMaterial({color:new THREE.Color(activeColor), wireframe:true, transparent:true, opacity:0.10, blending:THREE.AdditiveBlending, depthWrite:false}) }
  function ptsMat(tex,size){ return new THREE.PointsMaterial({size, map:tex, color:new THREE.Color(activeColor), transparent:true, opacity:0.9, blending:THREE.AdditiveBlending, depthWrite:false, sizeAttenuation:true}) }

  function buildScene(){
    THREE=getThree(); OC=getOC()
    if(!THREE||!OC) return false
    if(!ensureDom()) return false
    reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)

    scene=new THREE.Scene()
    const w=Math.max(320,Math.round(wrap.clientWidth)||640)
    const h=Math.max(300,Math.round(wrap.clientHeight)||520)
    camera=new THREE.PerspectiveCamera(45, w/h, 1, 4000)
    camera.position.set(50,132,432)
    renderer=new THREE.WebGLRenderer({canvas, antialias:true, alpha:true})
    renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1))
    renderer.setSize(w,h,false)

    controls=new OC(camera, renderer.domElement)
    controls.enableDamping=true; controls.dampingFactor=0.06
    controls.minDistance=235; controls.maxDistance=980
    controls.enablePan=false
    controls.autoRotate=false            // we spin the model, not the camera
    controls.target.set(0,-6,0); controls.update()

    brainGroup=new THREE.Group()
    brainGroup.scale.setScalar(150)
    brainGroup.rotation.x=-0.12
    scene.add(brainGroup)

    const tex=discTexture()

    // Cerebrum + wireframe + cortex neuron points.
    const cGeo=buildCerebrum(); bakeShade(cGeo)
    const cSurf=new THREE.Mesh(cGeo, surfMat()); brainGroup.add(cSurf); surfaces.push(cSurf.material)
    const cWire=new THREE.Mesh(cGeo, wireMat()); cWire.scale.setScalar(1.008); brainGroup.add(cWire); wires.push(cWire.material)
    const cPoints=new THREE.Points(samplePoints(cGeo,1500), ptsMat(tex,6.5)); brainGroup.add(cPoints); pointMats.push(cPoints.material)

    // Cerebellum (lower-rear) + its own wireframe/points.
    const cerGeo=buildCerebellum(); bakeShade(cerGeo)
    const cerGroup=new THREE.Group(); cerGroup.position.set(0,-0.50,-0.60); cerGroup.rotation.x=-0.14; brainGroup.add(cerGroup)
    const cerSurf=new THREE.Mesh(cerGeo, surfMat()); cerGroup.add(cerSurf); surfaces.push(cerSurf.material)
    const cerWire=new THREE.Mesh(cerGeo, wireMat()); cerWire.scale.setScalar(1.012); cerGroup.add(cerWire); wires.push(cerWire.material)
    const cerPoints=new THREE.Points(samplePoints(cerGeo,300), ptsMat(tex,5.5)); cerGroup.add(cerPoints); pointMats.push(cerPoints.material)

    // Brainstem (descends behind the cerebellum).
    const stGeo=buildStem(); bakeShade(stGeo)
    const stGroup=new THREE.Group(); stGroup.position.set(0,-0.42,-0.30); stGroup.rotation.x=0.52; brainGroup.add(stGroup)
    const stSurf=new THREE.Mesh(stGeo, surfMat()); stGroup.add(stSurf); surfaces.push(stSurf.material)

    // Soft additive inner-energy halo (drawn faintly over the cortex).
    coreGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:tex, color:new THREE.Color(activeColor), transparent:true, opacity:0.10, blending:THREE.AdditiveBlending, depthWrite:false, depthTest:false}))
    coreGlow.scale.set(0.85,0.85,1); brainGroup.add(coreGlow)

    if(typeof ResizeObserver==='function'&&!ro){
      ro=new ResizeObserver(()=>{
        if(!renderer||!camera||!wrap) return
        const r=wrap.getBoundingClientRect()
        const ww=Math.max(320,Math.round(r.width)||640), hh=Math.max(300,Math.round(r.height)||520)
        renderer.setSize(ww,hh,false); camera.aspect=ww/hh; camera.updateProjectionMatrix()
      })
      ro.observe(wrap)
    }
    initialized=true
    return true
  }


  function setBrain(brain){
    const lobe=String((brain&&brain.lobe)||'prefrontal_cortex').toLowerCase()
    activeLobe=LOBE_COLOR[lobe]?lobe:'prefrontal_cortex'
    activeColor=LOBE_COLOR[activeLobe]||DEFAULT_COLOR
    try{ window.__BRAIN_LAST__=brain||window.__BRAIN_LAST__||null }catch{}
    if(!THREE) return
    const c=new THREE.Color(activeColor)
    surfaces.forEach(m=>{ if(m) m.color.copy(c) })
    wires.forEach(m=>{ if(m) m.color.copy(c) })
    pointMats.forEach(m=>{ if(m) m.color.copy(c) })
    if(coreGlow&&coreGlow.material) coreGlow.material.color.copy(c)
  }
  function setAuto(v){ autoRotate=!!v }
  function reset(){
    if(!controls||!camera) return
    camera.position.set(50,132,432); controls.target.set(0,-6,0)
    if(brainGroup) brainGroup.rotation.y=0
    controls.update()
  }
  function animate(){
    cancelAnimationFrame(raf)
    const loop=()=>{
      raf=requestAnimationFrame(loop); phase+=reduceMotion?0.004:0.014
      if(brainGroup){
        if(autoRotate&&!reduceMotion) brainGroup.rotation.y+=0.0011
        brainGroup.rotation.x=-0.12+Math.sin(phase*0.18)*0.03
      }
      const baseOp=0.82+Math.sin(phase*2.4)*0.08
      pointMats.forEach(m=>{ if(m) m.opacity=baseOp })
      const wfOp=Math.max(0.03,0.09+Math.sin(phase*1.9)*0.03)
      wires.forEach(m=>{ if(m) m.opacity=wfOp })
      if(coreGlow&&coreGlow.material){ const g=0.80+Math.sin(phase*1.3)*0.06; coreGlow.scale.set(g,g,1); coreGlow.material.opacity=0.09+Math.sin(phase*1.5)*0.03 }
      if(controls) controls.update()
      if(renderer&&scene&&camera) renderer.render(scene,camera)
    }; loop()
  }
  function initIfNeeded(){
    if(initialized) return
    const ok=buildScene()
    if(!ok){ setTimeout(initIfNeeded,200); return }
    animate()
  }
  window.__JARVIS_BRAIN_HOLO__={
    init:initIfNeeded, setBrain, setAuto, reset, isReady:()=>initialized,
    get activeLobe(){return activeLobe}, get activeColor(){return activeColor},
    get hoverId(){return null}, get pinnedId(){return null}, set pinnedId(v){},
    CAPS, LOBE_TO_CAP, LOBE_COLOR,
  }
  window.__brainHoloDraw=setBrain
  function whenReady(cb){ if(getThree()&&getOC()) cb(); else window.addEventListener('jarvis:three-ready',cb,{once:true}) }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>whenReady(initIfNeeded),{once:true}); else whenReady(initIfNeeded)
})()
