import io

path = "background/cortex.py"
f = io.open(path, "r", encoding="utf-8", newline="")
lines = f.readlines()
f.close()

# Find where step = { is (in the new code)
step_idx = None
for i, line in enumerate(lines):
    if "step = {" in line and i > 630:
        step_idx = i
        break

if step_idx is None:
    print("step = { NOT FOUND")
    exit(1)

# Find the second "})" after step = {
count = 0
for i in range(step_idx, len(lines)):
    if lines[i].strip() == "})":
        count += 1
        if count == 2:
            print("removing line", i + 1)
            del lines[i]
            break

f = io.open(path, "w", encoding="utf-8", newline="")
f.writelines(lines)
f.close()
print("done")
