"""JARVIS Phase-1 local skills (stdlib-first, no new API keys).

All entry points are imported lazily by background/voice_engine.py so a
missing optional package never breaks boot. Every function returns a short
spoken string, never raw tracebacks.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

IST = "Asia/Kolkata"


def _now():
    """IST when tzdata exists (Linux), else local Windows clock (no new dep)."""
    try:
        return datetime.now(ZoneInfo(IST))
    except Exception:
        return datetime.now()

# ---------------------------------------------------------------- time/date

def time_date() -> str:
    now = _now()
    return "Sir, time is %s, %s." % (
        now.strftime("%I:%M %p"),
        now.strftime("%d %B %Y, %A"),
    )


# ---------------------------------------------------------------- notes

def _notes_dir() -> Path:
    d = Path.home() / "Documents" / "JARVIS" / "Notes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_note(text: str) -> str:
    body = (text or "").strip()
    if not body:
        return "Kya note likhun, Sir? Please repeat."
    stamp = _now().strftime("%Y-%m-%d_%H-%M")
    f = _notes_dir() / f"note-{stamp}.txt"
    f.write_text(body + "\n", encoding="utf-8")
    return "Note save kar diya, Sir: %s." % f.name


def read_last_note() -> str:
    files = sorted(_notes_dir().glob("note-*.txt"))
    if not files:
        return "Abhi koi note nahi mila, Sir."
    body = files[-1].read_text(encoding="utf-8", errors="ignore").strip()[:600]
    return "Last note (%s): %s" % (files[-1].name, body or "(empty)")


# ---------------------------------------------------------------- clipboard

def clipboard_set(text: str) -> str:
    body = (text or "").strip()[:4000]
    if not body:
        return "Clipboard me kya copy karun, Sir?"
    # 1) pyperclip (optional)
    try:
        import pyperclip  # type: ignore

        pyperclip.copy(body)
        return "Clipboard me copy kar diya, Sir."
    except Exception:
        pass
    # 2) PowerShell Set-Clipboard (stdlib, always on Windows)
    try:
        b64 = __import__("base64").b64encode(body.encode("utf-8")).decode()
        ps = (
            "$t=[Text.Encoding]::UTF8.GetString("
            "[Convert]::FromBase64String('%s')); Set-Clipboard -Value $t" % b64
        )
        subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
             "-WindowStyle", "Hidden", "-Command", ps],
            timeout=10, capture_output=True,
            creationflags=0x08000000,
        )
        return "Clipboard me copy kar diya, Sir."
    except Exception:
        return "Clipboard copy fail ho gaya, Sir."


def clipboard_get() -> str:
    try:
        import pyperclip  # type: ignore

        val = (pyperclip.paste() or "").strip()
        return ("Clipboard me hai: %s" % val[:400]) if val else "Clipboard khaali hai, Sir."
    except Exception:
        return "Clipboard read ke liye pyperclip install karna hoga, Sir."


# ---------------------------------------------------------------- typing

def type_text(text: str) -> str:
    body = (text or "").strip()
    if not body:
        return "Kya type karun, Sir?"
    try:
        import pyautogui  # type: ignore

        time.sleep(0.4)  # user focuses the target window
        pyautogui.write(body[:2000], interval=0.02)
        return "Type kar diya, Sir."
    except Exception:
        return ("Auto-typing ke liye pyautogui chahiye. "
                "Install: venvScripts python -m pip install pyautogui")


# ---------------------------------------------------------------- screenshot

def take_screenshot() -> str:
    folder = Path.home() / "Pictures" / "JARVIS"
    folder.mkdir(parents=True, exist_ok=True)
    fname = "jarvis-%s.png" % _now().strftime("%Y%m%d-%H%M%S")
    dest = folder / fname
    # 1) mss (fast, optional)
    try:
        import mss  # type: ignore

        with mss.mss() as sct:
            sct.shot(output=str(dest))
        return "Screenshot save ho gaya, Sir: %s." % fname
    except Exception:
        pass
    # 2) Pillow ImageGrab (optional)
    try:
        from PIL import ImageGrab  # type: ignore

        ImageGrab.grab().save(dest)
        return "Screenshot save ho gaya, Sir: %s." % fname
    except Exception:
        pass
    # 3) PowerShell fallback (stdlib, always works)
    try:
        esc = str(dest).replace("'", "''")
        ps = ("Add-Type -AssemblyName System.Windows.Forms;"
              "Add-Type -AssemblyName System.Drawing;"
              "$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
              "$i=New-Object System.Drawing.Bitmap $b.Width,$b.Height;"
              "$g=[System.Drawing.Graphics]::FromImage($i);"
              "$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);"
              "$i.Save('%s');$g.Dispose();$i.Dispose()" % esc)
        subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
             "-Command", ps],
            timeout=25, capture_output=True, creationflags=0x08000000)
        if dest.exists() and dest.stat().st_size > 0:
            return "Screenshot save ho gaya, Sir: %s." % fname
    except Exception:
        pass
    return "Screenshot fail ho gaya, Sir."
