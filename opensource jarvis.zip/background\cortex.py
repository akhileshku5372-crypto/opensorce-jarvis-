"""Cortex: OpenClaw-style Plan -> Act -> Observe engine for JARVIS (additive).

Ports the architecture of OpenClaw's agent runtime (github.com/openclaw/openclaw)
into the Jarvis backend without touching the voice/UI pipeline:

  * Agent loop (docs/concepts/agent-loop.md, embedded-agent-runner/run-loop.ts):
    a serialized run where a planner proposes ONE tool action, the registry
    executes it, the observation is fed back, and the loop ends on a terminal
    reason - completed, budget_exhausted, loop_detected, no_progress,
    cancelled, interrupted - with a step budget and per-tool timeouts.
  * Tool registry (src/agents/tools/common.ts): erased tool specs with name,
    description, param schema and an execute() returning {ok, output}; strict
    typed param readers that raise ToolInputError; a confirmation gate
    (the ActionGate idea) for tools marked requires_confirmation; an honest
    prompt catalog that is empty when nothing is registered.
  * Skills (src/skills/*): reused, not reimplemented - Jarvis already has
    progressive-disclosure SKILL.md loading in background/skill_loader.py, so
    Cortex passes the matched skill context to the planner only.

Safety (AGENTS.md): no shell anywhere, no subprocess, no eval; only Python
callables that were explicitly registered can ever run; planner output is
validated as data (dict with tool+args or done+answer) and never executed as
code; duplicate registration, unknown tools and missing confirmation are
refused with honest messages; observations and steps are size-bounded.
"""
from __future__ import annotations

import importlib.util
import json
import re
import threading
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STORE = ROOT / "artifacts" / "cortex" / "last_run.json"


def _grant_tool_approval(tool_name: str) -> None:
    """Tell the permission engine the user just approved this exact tool.

    Resolved through the same `jarvis_cowork_*` key the rest of the codebase
    uses, so this is guaranteed to be the SAME module object that the plugin
    permission wrapper consults. A plain `import permissions` would create a
    second module instance with a separate approval ledger.
    """
    try:
        import sys
        mod = sys.modules.get("jarvis_cowork_permissions")
        if mod is None:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "jarvis_cowork_permissions", ROOT / "background" / "permissions.py")
            mod = importlib.util.module_from_spec(spec)
            sys.modules["jarvis_cowork_permissions"] = mod
            spec.loader.exec_module(mod)
        mod.grant_approval(tool_name)
    except Exception:
        # Never block a tool the user already confirmed because of this.
        pass

MAX_STEPS = 8                 # plan->act->observe iterations before the budget ends the run
MAX_ARGS_CHARS = 2000         # canonical JSON cap for one action's arguments
MAX_OBSERVATION_CHARS = 1200  # per-step observation cap
MAX_ANSWER_CHARS = 2000       # final answer cap
MAX_GOAL_CHARS = 1000
LOOP_SIGNATURE_LIMIT = 3      # identical tool+args repeated -> loop_detected
# Repeating IS the point of these. "scroll karte raho jab tak main na bolun"
# and "scroll until the PDF link appears" both need the same call over and
# over; the 3-strike signature killed the run and Sir heard "main atak gaya".
# Exempt here rather than raising the limit, so a runaway on a mutating tool
# is still caught at 3. Their worst case is bounded by the step budget.
LOOP_EXEMPT_TOOLS = frozenset(("gui_scroll", "gui_read_screen_region"))
NO_PROGRESS_LIMIT = 3         # consecutive empty/failed observations -> no_progress

_TOOL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

STATUS_IDLE = "idle"
STATUS_RUNNING = "running"
STATUS_DONE = "done"
STATUS_FAILED = "failed"
STATUS_CANCELLED = "cancelled"
STATUS_INTERRUPTED = "interrupted"

_lock = threading.RLock()
_runner = None
_run = None
_cancel = threading.Event()
_skills_mod = None


class CortexError(Exception):
    """Base error for Cortex contracts."""


class ToolInputError(CortexError):
    """A parameter failed strict validation (never guessed, never coerced blindly)."""


class ToolAuthorizationError(CortexError):
    """A confirmation/action gate refused the call."""


def canonical_args(args) -> str:
    """Stable JSON used for loop-signature detection (sorted keys, bounded)."""
    try:
        text = json.dumps(args if isinstance(args, dict) else {}, sort_keys=True,
                          ensure_ascii=False, default=str)
    except Exception:
        text = repr(args)
    return text[:MAX_ARGS_CHARS]


def ok_result(output, **data) -> dict:
    result = {"ok": True, "output": str(output)[:MAX_OBSERVATION_CHARS]}
    result.update(data)
    return result


def fail_result(output, **data) -> dict:
    result = {"ok": False, "output": str(output)[:MAX_OBSERVATION_CHARS]}
    result.update(data)
    return result


def read_str_param(args: dict, key: str, required: bool = True,
                   default: str = "", max_chars: int = 400) -> str:
    """Strict string reader - blank optional values fall back, invalid types raise."""
    if not isinstance(args, dict) or key not in args or args.get(key) is None:
        if required:
            raise ToolInputError("missing required string parameter '%s'" % key)
        return default
    value = args.get(key)
    if not isinstance(value, str):
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            value = str(value)
        else:
            raise ToolInputError("parameter '%s' must be a string" % key)
    value = value.strip()
    if not value and required:
        raise ToolInputError("parameter '%s' must not be blank" % key)
    return value[:max_chars]


def read_int_param(args: dict, key: str, required: bool = True, default: int = 0,
                   minimum: int | None = None, maximum: int | None = None) -> int:
    """Strict integer reader - rejects bools and non-finite junk."""
    if not isinstance(args, dict) or key not in args or args.get(key) is None:
        if required:
            raise ToolInputError("missing required integer parameter '%s'" % key)
        return default
    value = args.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value != int(value):
        raise ToolInputError("parameter '%s' must be an integer" % key)
    value = int(value)
    if minimum is not None and value < minimum:
        raise ToolInputError("parameter '%s' must be >= %d" % (key, minimum))
    if maximum is not None and value > maximum:
        raise ToolInputError("parameter '%s' must be <= %d" % (key, maximum))
    return value


class ToolSpec:
    """Erased tool contract (the AnyAgentTool idea, stdlib edition).

    handler(args: dict) -> str | dict   (dict results must carry "ok")
    requires_confirmation tools run through the confirm gate before execute.
    """

    def __init__(self, name: str, description: str, handler,
                 parameters: dict | None = None, requires_confirmation: bool = False,
                 timeout_s: float = 20.0, tags=()):
        self.name = str(name)
        self.description = str(description).strip()
        self.handler = handler
        self.parameters = dict(parameters or {})
        self.requires_confirmation = bool(requires_confirmation)
        try:
            self.timeout_s = max(0.1, float(timeout_s))
        except (TypeError, ValueError):
            self.timeout_s = 20.0
        self.tags = tuple(str(t) for t in (tags or ()))

    def to_prompt(self) -> str:
        args = ", ".join(sorted(self.parameters)) or "-"
        suffix = " [confirmation required]" if self.requires_confirmation else ""
        return "%s(%s): %s%s" % (self.name, args, self.description[:110], suffix)


class ToolRegistry:
    """Dynamic tool registry: explicit registration, duplicate refusal, no shell."""

    def __init__(self):
        self._tools: dict = {}

    def register(self, spec: ToolSpec) -> tuple:
        if not isinstance(spec, ToolSpec):
            return (False, "register() needs a ToolSpec")
        if not _TOOL_NAME_RE.match(spec.name):
            return (False, "tool name '%s' must match %s" %
                    (spec.name, _TOOL_NAME_RE.pattern))
        if not callable(spec.handler):
            return (False, "tool '%s' handler must be callable" % spec.name)
        if not spec.description:
            return (False, "tool '%s' needs a description" % spec.name)
        if spec.name in self._tools:
            return (False, "tool '%s' is already registered" % spec.name)
        self._tools[spec.name] = spec
        return (True, "tool '%s' registered" % spec.name)

    def unregister(self, name: str) -> bool:
        return self._tools.pop(str(name), None) is not None

    def get(self, name: str):
        return self._tools.get(str(name))

    def names(self) -> list:
        return sorted(self._tools)

    def list(self) -> list:
        return [self._tools[n] for n in sorted(self._tools)]

    def catalog(self, max_rows: int = 48) -> str:
        """Prompt fragment listing callable tools ("" when empty - honest).

        The default had to grow with the registry: at 16 rows the real catalog
        (MCP connectors + OS executor + app index + web + WhatsApp) was being
        truncated mid-list, so the planner literally could not see the last
        tools. Truncation must never silently hide a callable action.
        """
        specs = self.list()[:max_rows]
        if not specs:
            return ""
        return " CORTEX TOOLS (registered local actions): %s. " % " | ".join(
            s.to_prompt() for s in specs)


    def execute(self, name: str, args: dict, confirm=None) -> dict:
        """Validate -> gate -> run one tool (timed). Never raises; always {ok, output}."""
        spec = self.get(name)
        if spec is None:
            return fail_result("tool '%s' is not registered in the cortex registry"
                               % str(name)[:80])
        if not isinstance(args, dict):
            return fail_result("arguments for '%s' must be a JSON object" % spec.name)
        if len(canonical_args(args)) >= MAX_ARGS_CHARS:
            return fail_result("arguments for '%s' exceed the %d char budget"
                               % (spec.name, MAX_ARGS_CHARS))
        if spec.requires_confirmation:
            if not callable(confirm):
                self._record(spec.name, False, "no confirmation gate wired",
                             denied=True)
                return fail_result(
                    "tool '%s' requires confirmation and no confirm gate is wired"
                    % spec.name, denied=True)
            try:
                approved = bool(confirm(spec.name, dict(args)))
            except Exception as exc:
                self._record(spec.name, False, "confirm gate failed", denied=True)
                return fail_result("confirmation gate for '%s' failed: %s: %s"
                                   % (spec.name, type(exc).__name__, exc), denied=True)
            if not approved:
                self._record(spec.name, False, "confirmation refused", denied=True)
                return fail_result("confirmation refused for tool '%s'" % spec.name,
                                   denied=True)
            # One user confirmation satisfies BOTH gates: the permission wrapper
            # around plugin handlers runs on a worker thread and cannot see this
            # local, so record the approval for that exact tool name. A `deny` in
            # permissions.json still wins - check() ignores `approved` for DENY.
            try:
                _grant_tool_approval(spec.name)
            except Exception:
                pass
        started = time.monotonic()
        result = _execute_with_timeout(spec, dict(args))
        self._record(spec.name, bool(result.get("ok")),
                     str(result.get("error") or result.get("output") or "")[:120],
                     ms=(time.monotonic() - started) * 1000.0,
                     denied=bool(result.get("denied")))
        return result

    def _record(self, name, ok, why="", ms=0.0, denied=False):
        """Self-learning P2: every real outcome lands in the result ledger."""
        try:
            import results
            results.record(name, ok, why=why, ms=ms, denied=denied)
        except Exception:
            pass


def _normalize_handler_result(spec: ToolSpec, raw) -> dict:
    """Handlers may return a str (ok) or a dict carrying "ok"; anything else fails."""
    if isinstance(raw, dict):
        if "ok" not in raw:
            return fail_result("tool '%s' returned a dict without an 'ok' field"
                               % spec.name)
        out = dict(raw)
        out["ok"] = bool(out["ok"])
        out["output"] = str(out.get("output") or out.get("text") or "")[:MAX_OBSERVATION_CHARS]
        return out
    if isinstance(raw, str):
        return ok_result(raw)
    if raw is None:
        return ok_result("")
    return fail_result("tool '%s' returned unsupported type %s"
                       % (spec.name, type(raw).__name__))


def _execute_with_timeout(spec: ToolSpec, args: dict) -> dict:
    """Run the handler on a daemon thread with a join timeout (cooperative bound)."""
    box: dict = {}

    def _target_fn():
        try:
            box["result"] = spec.handler(args)
        except BaseException as exc:  # noqa: BLE001 - honest capture, never crash the loop
            box["error"] = exc

    thread = threading.Thread(target=_target_fn, name="cortex-tool-%s" % spec.name,
                              daemon=True)
    thread.start()
    thread.join(spec.timeout_s)
    if thread.is_alive():
        return fail_result("tool '%s' timed out after %.1fs"
                           % (spec.name, spec.timeout_s))
    if "error" in box:
        exc = box["error"]
        if isinstance(exc, ToolInputError):
            return fail_result("invalid input for '%s': %s" % (spec.name, exc))
        if isinstance(exc, ToolAuthorizationError):
            return fail_result("authorization refused for '%s': %s" % (spec.name, exc),
                               denied=True)
        return fail_result("tool '%s' failed: %s: %s"
                           % (spec.name, type(exc).__name__, exc))
    return _normalize_handler_result(spec, box.get("result"))




def _empty() -> dict:
    return {
        "id": "", "goal": "", "status": STATUS_IDLE, "reason": "", "answer": "",
        "steps": [], "created_at": 0.0, "updated_at": 0.0,
    }


def _save(run: dict) -> None:
    """Persist the latest run best-effort without ever blocking the agent loop."""
    try:
        STORE.parent.mkdir(parents=True, exist_ok=True)
        temp = STORE.with_suffix(".tmp")
        temp.write_text(json.dumps(run, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(STORE)
    except Exception:
        pass


def _load() -> dict:
    try:
        data = json.loads(STORE.read_text(encoding="utf-8", errors="ignore") or "{}")
    except Exception:
        return _empty()
    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        return _empty()
    data.setdefault("id", "")
    data.setdefault("goal", "")
    data.setdefault("status", STATUS_IDLE)
    data.setdefault("reason", "")
    data.setdefault("answer", "")
    return data


def _notify(on_update) -> None:
    if callable(on_update):
        try:
            on_update(snapshot())
        except Exception:
            pass


def snapshot() -> dict:
    """Return a bounded, JSON-safe view of the latest real run."""
    with _lock:
        run = _run or _empty()
        steps = []
        for step in run.get("steps") or []:
            steps.append({
                "tool": str(step.get("tool") or "")[:64],
                "args": str(step.get("args") or "")[:MAX_ARGS_CHARS],
                "status": str(step.get("status") or "pending"),
                "output": str(step.get("output") or "")[:MAX_OBSERVATION_CHARS],
            })
        return {
            "run_id": str(run.get("id") or ""),
            "goal": str(run.get("goal") or "")[:MAX_GOAL_CHARS],
            "status": str(run.get("status") or STATUS_IDLE),
            "reason": str(run.get("reason") or "")[:80],
            "answer": str(run.get("answer") or "")[:MAX_ANSWER_CHARS],
            "steps": steps,
            "created_at": float(run.get("created_at") or 0.0),
            "updated_at": float(run.get("updated_at") or 0.0),
            "summary": run.get("summary") or {},
        }


def is_running() -> bool:
    with _lock:
        return bool(_run and _run.get("status") == STATUS_RUNNING)


def _skill_context(goal: str) -> str:
    """Load progressive skill context lazily, matching the existing loader."""
    global _skills_mod
    try:
        if _skills_mod is None:
            path = ROOT / "background" / "skill_loader.py"
            spec = importlib.util.spec_from_file_location("jarvis_cortex_skill_loader", path)
            if spec is None or spec.loader is None:
                return ""
            _skills_mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(_skills_mod)
        context_for = getattr(_skills_mod, "context_for", None)
        return str(context_for(goal) or "") if callable(context_for) else ""
    except Exception:
        return ""


def _validate_proposal(raw) -> dict:
    """Planner output is data only. Never eval/exec it."""
    if not isinstance(raw, dict):
        raise ToolInputError("planner response must be a JSON object")
    if "done" in raw and "tool" not in raw:
        if raw.get("done") is not True:
            raise ToolInputError("planner 'done' must be true")
        return {"done": True, "answer": str(raw.get("answer") or "")[:MAX_ANSWER_CHARS]}
    name = raw.get("tool")
    if not isinstance(name, str) or not name.strip():
        raise ToolInputError("planner response needs tool plus args, or done plus answer")
    name = name.strip()
    if not _TOOL_NAME_RE.match(name):
        raise ToolInputError("invalid tool name in planner response")
    args = raw.get("args", {})
    if args is None:
        args = {}
    if not isinstance(args, dict):
        raise ToolInputError("planner args must be a JSON object")
    if len(canonical_args(args)) >= MAX_ARGS_CHARS:
        raise ToolInputError("planner args exceed the cortex size budget")
    fan_out = raw.get("fan_out")
    if fan_out is not None:
        if not isinstance(fan_out, list):
            raise ToolInputError("'fan_out' must be a list of {tool, args}")
        for item in fan_out:
            if not isinstance(item, dict) or not item.get("tool"):
                raise ToolInputError("each fan-out item needs {tool, args}")
            if not _TOOL_NAME_RE.match(str(item["tool"])):
                raise ToolInputError("invalid tool name in fan-out")
            if not isinstance(item.get("args"), dict):
                raise ToolInputError("fan-out args must be a JSON object")
        return {"done": False, "tool": name, "args": dict(args), "fan_out": fan_out}
    return {"done": False, "tool": name, "args": dict(args)}




def _finish(run_id: str, status: str, reason: str, answer: str = "") -> None:
    with _lock:
        run = _run
        if not run or run.get("id") != run_id:
            return
        run["status"] = status
        run["reason"] = reason
        run["answer"] = str(answer or "")[:MAX_ANSWER_CHARS]
        run["updated_at"] = time.time()
        for step in run.get("steps") or []:
            if step.get("status") == "running":
                step["status"] = "cancelled" if status == STATUS_CANCELLED else "interrupted"
                step["output"] = status
        _save(run)


def _execute_loop(run_id: str, planner, registry: ToolRegistry, confirm,
                  catalog: str, skill_context: str, on_update) -> None:
    """One serialized planner/tool loop. Each callback invocation proposes one action."""
    global _runner
    try:
        observations = []
        signatures = {}
        no_progress = 0
        for index in range(MAX_STEPS):
            if _cancel.is_set():
                _finish(run_id, STATUS_CANCELLED, "cancelled")
                break
            with _lock:
                run = _run
                if not run or run.get("id") != run_id or run.get("status") != STATUS_RUNNING:
                    break
                goal = str(run.get("goal") or "")
            try:
                proposal = planner(goal, catalog, list(observations), skill_context)
                action = _validate_proposal(proposal)
            except Exception as exc:
                _finish(run_id, STATUS_FAILED, "planner_error", str(exc))
                break
            if action["done"]:
                _finish(run_id, STATUS_DONE, "completed", action.get("answer", ""))
                break

            # NEW: parallel fan-out
            if action.get("fan_out") and isinstance(action["fan_out"], list):
                _execute_fanout(run_id, action, registry, confirm, observations, on_update)
                continue

            name = action["tool"]
            args = action["args"]
            signature = name + " " + canonical_args(args)
            signatures[signature] = signatures.get(signature, 0) + 1
            if (signatures[signature] >= LOOP_SIGNATURE_LIMIT
                    and name not in LOOP_EXEMPT_TOOLS):
                _finish(run_id, STATUS_FAILED, "loop_detected")
                break

            step = {
                "tool": name, "args": canonical_args(args), "status": "running",
                "output": "", "index": index + 1, "created_at": time.time(),
            }
            with _lock:
                run = _run
                if not run or run.get("id") != run_id or run.get("status") != STATUS_RUNNING:
                    break
                run["steps"].append(step)
                run["updated_at"] = time.time()
                _save(run)
            _notify(on_update)

            result = registry.execute(name, args, confirm=confirm)
            ok = bool(result.get("ok"))
            output = str(result.get("output") or "")[:MAX_OBSERVATION_CHARS]
            with _lock:
                run = _run
                if not run or run.get("id") != run_id or run.get("status") != STATUS_RUNNING:
                    break
                step["status"] = "done" if ok else "failed"
                step["output"] = output
                run["updated_at"] = time.time()
                _save(run)
            _notify(on_update)

            observations.append({
                "tool": name, "args": args, "ok": ok, "output": output,
                "denied": bool(result.get("denied")),
            })
            if not ok or not output.strip():
                no_progress += 1
            else:
                no_progress = 0
            if _cancel.is_set():
                _finish(run_id, STATUS_CANCELLED, "cancelled")
                break
            if no_progress >= NO_PROGRESS_LIMIT:
                _finish(run_id, STATUS_FAILED, "no_progress")
                break
        else:
            _finish(run_id, STATUS_FAILED, "budget_exhausted")
    finally:
        with _lock:
            if _runner is threading.current_thread():
                _runner = None
        _notify(on_update)



def start(goal, planner, registry: ToolRegistry, confirm=None, on_update=None, parallel: bool = False) -> tuple:
    """Start one background run. `planner` receives goal/catalog/observations/skills.

    The planner must return either ``{"done": True, "answer": "..."}`` or
    ``{"tool": "registered_name", "args": {...}}``. No planner text is executed.
    """
    global _runner, _run, _cancel
    clean_goal = str(goal or "").strip()[:MAX_GOAL_CHARS]
    if not clean_goal:
        return (False, "Cortex: goal khaali hai.")
    if not callable(planner):
        return (False, "Cortex: planner callable hona chahiye.")
    if not isinstance(registry, ToolRegistry):
        return (False, "Cortex: valid ToolRegistry chahiye.")
    if is_running():
        return (False, "Cortex: ek run already chal raha hai; pehle cancel karein.")

    now = time.time()
    with _lock:
        if _run and _run.get("status") == STATUS_RUNNING:
            return (False, "Cortex: ek run already chal raha hai; pehle cancel karein.")
        _cancel = threading.Event()
        _run = {
            "id": uuid.uuid4().hex[:12], "goal": clean_goal,
            "status": STATUS_RUNNING, "reason": "", "answer": "", "steps": [],
            "created_at": now, "updated_at": now,
            "parallel": parallel,
        }
        run_id = _run["id"]
        catalog = registry.catalog()
        skill_context = _skill_context(clean_goal)
        _save(_run)
    _notify(on_update)

    _runner = threading.Thread(
        target=_execute_loop,
        args=(run_id, planner, registry, confirm, catalog, skill_context, on_update),
        name="jarvis-cortex", daemon=True,
    )
    _runner.start()
    return (True, "Cortex run %s shuru: %s" % (run_id, clean_goal[:80]))
def _execute_fanout(run_id: str, action: dict, registry: ToolRegistry, confirm,
                    observations: list, on_update) -> dict:
    fan_out_actions = action.get("fan_out", [])
    if not isinstance(fan_out_actions, list) or not fan_out_actions:
        return fail_result("fan_out must be a non-empty list of {tool, args}")
    import concurrent.futures
    results: list = []
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, min(len(fan_out_actions), 16))) as executor:
        future_to_name = {}
        for item in fan_out_actions:
            name = item.get("tool")
            args = item.get("args", {})
            if not name:
                results.append(fail_result("fan-out item missing 'tool'"))
                continue
            if not isinstance(args, dict):
                results.append(fail_result("fan-out args must be a JSON object for '%s'" % name))
                continue
            future = executor.submit(_execute_single, name, args, registry, confirm)
            future_to_name[future] = name
        for future in concurrent.futures.as_completed(future_to_name):
            name = future_to_name[future]
            try:
                results.append(future.result())
            except Exception as exc:
                results.append(fail_result("fan-out '%s' raised: %s" % (name, exc)))
    for result in results:
        step = {
            "tool": result.get("tool", ""),
            "args": result.get("args", {}),
            "status": "done" if result.get("ok") else "failed",
            "output": str(result.get("output") or "")[:MAX_OBSERVATION_CHARS],
            "denied": bool(result.get("denied")),
            "index": len(observations) + 1, "created_at": time.time(),
        }
        with _lock:
            run = _run
            if not run or run.get("id") != run_id or run.get("status") != STATUS_RUNNING:
                continue
            run["steps"].append(step)
            run["updated_at"] = time.time()
            _save(run)
        observations.append({
            "tool": result.get("tool", ""),
            "args": result.get("args", {}),
            "ok": result.get("ok", False),
            "output": str(result.get("output") or ""),
            "denied": bool(result.get("denied")),
        })
    succeeded = sum(1 for r in results if r.get("ok"))
    summary = {"ok": succeeded > 0,
               "output": "fan-out: %d/%d actions completed" % (succeeded, len(results)),
               "results": results[:10]}
    # Store summary in the run state for later inspection
    with _lock:
        run = _run
        if run and run.get("id") == run_id and run.get("status") == STATUS_RUNNING:
            run["summary"] = summary
            run["updated_at"] = time.time()
            _save(run)
    if callable(on_update):
        try:
            on_update({"run_id": run_id, "status": "running", "type": "fan_out",
                       "output": summary["output"]})
        except Exception:
            pass
    return summary


def _execute_single(name: str, args: dict, registry: ToolRegistry, confirm):
    return registry.execute(name, args, confirm=confirm)



def run_subagent(goal, planner, registry: ToolRegistry, confirm=None,
                 allowed: list | None = None, max_steps: int = 4,
                 skill_context: str = "", on_step=None) -> dict:
    """Run the SAME Plan->Act->Observe loop for a nested agent, in-line.

    Why this exists: the Agent + Sub-Agent Flow Builder needs a real second
    agent - its own system prompt, its own tool allowlist, its own step budget.
    Implementing that as a new loop would create a second brain, which AGENTS.md
    forbids. So this reuses ``_validate_proposal``, ``registry.execute``,
    ``canonical_args`` and the same loop guards, and only adds the scoping the
    builder needs:

      * ``allowed``   - tool names this sub-agent may call. A proposal naming
                        anything else is refused and fed back as an observation,
                        exactly like an unknown tool in the main loop.
      * ``max_steps`` - its own smaller budget.
      * synchronous   - it RETURNS a result dict instead of writing the module
                        globals ``_run``/``_runner``, so a flow can nest agents
                        without corrupting (or being blocked by) the top-level
                        run the user started.

    Returns ``{ok, status, reason, answer, steps}``. Never raises.
    """
    clean_goal = str(goal or "").strip()[:MAX_GOAL_CHARS]
    if not clean_goal:
        return {"ok": False, "status": "failed", "reason": "empty_goal",
                "answer": "", "steps": []}
    if not callable(planner) or not isinstance(registry, ToolRegistry):
        return {"ok": False, "status": "failed", "reason": "bad_planner",
                "answer": "", "steps": []}
    allow = set(allowed or []) if allowed else None
    budget = max(1, min(int(max_steps or 1), MAX_STEPS))

    def _visible(spec) -> bool:
        return allow is None or spec.name in allow

    scoped = registry.catalog()
    if allow is not None:
        specs = [s for s in registry.list() if s.name in allow]
        if not specs:
            scoped = ""
        else:
            scoped = " CORTEX TOOLS (this sub-agent may call only these): %s. " % (
                " | ".join(s.to_prompt() for s in specs))

    steps: list = []
    observations: list = []
    signatures: dict = {}
    no_progress = 0
    for index in range(budget):
        try:
            action = _validate_proposal(planner(clean_goal, scoped, list(observations),
                                                str(skill_context or "")))
        except Exception as exc:
            return {"ok": False, "status": "failed", "reason": "planner_error",
                    "answer": "%s: %s" % (type(exc).__name__, exc), "steps": steps}
        if action["done"]:
            return {"ok": True, "status": "done", "reason": "completed",
                    "answer": action.get("answer", ""), "steps": steps}
        name = action["tool"]
        if allow is not None and name not in allow:
            # Same contract as an unregistered tool: refused, reported, and the
            # planner gets a chance to correct itself on the next step.
            msg = "tool '%s' is not available to this sub-agent (allowed: %s)" % (
                name, ", ".join(sorted(allow)) or "none")
            steps.append({"tool": name, "args": canonical_args(action["args"]),
                          "status": "failed", "output": msg, "index": index + 1})
            observations.append({"tool": name, "args": action["args"], "ok": False,
                                 "output": msg, "denied": True})
            no_progress += 1
            if no_progress >= NO_PROGRESS_LIMIT:
                return {"ok": False, "status": "failed", "reason": "no_progress",
                        "answer": "sub-agent kept reaching for a tool it was not "
                                  "given", "steps": steps}
            continue
        signature = name + " " + canonical_args(action["args"])
        signatures[signature] = signatures.get(signature, 0) + 1
        if (signatures[signature] >= LOOP_SIGNATURE_LIMIT
                and name not in LOOP_EXEMPT_TOOLS):
            return {"ok": False, "status": "failed", "reason": "loop_detected",
                    "answer": "sub-agent repeated the same call", "steps": steps}
        step = {"tool": name, "args": canonical_args(action["args"]),
                "status": "running", "output": "", "index": index + 1}
        steps.append(step)
        if callable(on_step):
            try:
                on_step(dict(step))
            except Exception:
                pass
        result = registry.execute(name, action["args"], confirm=confirm)
        ok = bool(result.get("ok"))
        output = str(result.get("output") or "")[:MAX_OBSERVATION_CHARS]
        step["status"] = "done" if ok else "failed"
        step["output"] = output
        if callable(on_step):
            try:
                on_step(dict(step))
            except Exception:
                pass
        observations.append({"tool": name, "args": action["args"], "ok": ok,
                             "output": output, "denied": bool(result.get("denied"))})
        no_progress = 0 if (ok and output.strip()) else no_progress + 1
        if no_progress >= NO_PROGRESS_LIMIT:
            return {"ok": False, "status": "failed", "reason": "no_progress",
                    "answer": "sub-agent produced no usable output", "steps": steps}
    return {"ok": False, "status": "failed", "reason": "budget_exhausted",
            "answer": "sub-agent used its %d step budget" % budget, "steps": steps}


def cancel() -> tuple:
    global _cancel
    with _lock:
        if not _run or _run.get("status") != STATUS_RUNNING:
            return (False, "Cortex: koi running run nahi hai.")
        _cancel.set()
        _run["status"] = STATUS_CANCELLED
        _run["reason"] = "cancelled"
        _run["updated_at"] = time.time()
        for step in _run.get("steps") or []:
            if step.get("status") == "running":
                step["status"] = "cancelled"
                step["output"] = "cancel requested"
        _save(_run)
    return (True, "Cortex run cancel kar diya.")


def describe() -> str:
    view = snapshot()
    if not view["run_id"]:
        return "Cortex: abhi koi run nahi hua."
    if view["status"] == STATUS_RUNNING:
        return "Cortex run %s chal raha hai: %s (%d steps)." % (
            view["run_id"], view["goal"], len(view["steps"]))
    tail = view["answer"] or view["reason"] or "no final answer"
    return "Cortex run %s %s hai (%s): %s" % (
        view["run_id"], view["status"], view["reason"] or "unknown", tail)


def load_persisted():
    """Restore the last run; a process restart turns 'running' into 'interrupted'."""
    global _run
    run = _load()
    if not run.get("id"):
        return None
    if run.get("status") == STATUS_RUNNING:
        run["status"] = STATUS_INTERRUPTED
        run["reason"] = "interrupted"
        run["updated_at"] = time.time()
        for step in run.get("steps") or []:
            if step.get("status") in ("pending", "running"):
                step["status"] = "skipped"
                step["output"] = "interrupted by process restart"
        _save(run)
    with _lock:
        _run = run
    return snapshot()

