"""The free-tier deep research engine: extraction, dedup, corroboration, tiers.

Stdlib + fakes only. No network and no LLM: every provider and every page fetch
is monkeypatched, so this suite is deterministic and costs nothing to run.
"""
import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


dr = _load("deep_research")

PAGE = """<html><head><style>.x{color:red}</style><script>var a=1;</script></head>
<body><nav>Home About Contact</nav>
<h1>Solid state batteries store more energy per kilogram</h1>
<p>%s</p><ul><li>%s second sentence about the electrolyte and its density.</li></ul>
<footer>Copyright blurb that nobody should ever read aloud.</footer></body></html>""" % (
    "Solid state cells replace the liquid electrolyte with a ceramic or sulfide "
    "layer, which lets the anode go to lithium metal and lifts the usable energy "
    "density well past today's graphite cells.",
    "Independent labs measured the volumetric gains across three chemistries.")


class MachineFormatTest(unittest.TestCase):
    """A page that returns metadata is not a finding - measured on springer.nl."""

    META = ('{"indexed":true,"date-parts":[[2026,4,1]],"publisher":"Springer Science",'
            '"reference-count":28,"url":"https://www.springer.nl/gb/researchers"} ' * 4)

    def test_json_metadata_is_not_prose(self):
        self.assertTrue(dr._machine_format(self.META))

    def test_xml_and_empty_are_not_prose(self):
        self.assertTrue(dr._machine_format('<?xml version="1.0"?><feed>' + 'x' * 200))
        self.assertTrue(dr._machine_format(""))
        self.assertTrue(dr._machine_format("too short to be a finding"))

    def test_plain_article_text_passes(self):
        self.assertFalse(dr._machine_format(
            "Solid state cells replace the liquid electrolyte with a ceramic layer, "
            "which lets the anode use lithium metal and lifts usable energy density "
            "well past what graphite anodes deliver in current production cells."))

    def test_a_json_page_is_a_failed_read_not_a_source(self):
        self._request = dr._request
        try:
            dr._request = lambda url, data=None, headers=None, timeout=14.0: (200, self.META)
            reads = dr.fetch_all([{"url": "https://springer.nl/x", "host": "springer.nl",
                                   "title": "meta"}], 1)
        finally:
            dr._request = self._request
        self.assertEqual(len(reads), 1)
        self.assertFalse(reads[0]["ok"], "metadata must fail the read")
        self.assertIn("machine data", reads[0]["error"])
        self.assertEqual(dr.build_sections(reads), [], "and never become a claim")


class ExtractTest(unittest.TestCase):
    def test_keeps_article_text_and_drops_chrome(self):
        text = dr.extract_text(PAGE)
        self.assertIn("store more energy per kilogram", text)
        self.assertIn("ceramic or sulfide", text)
        self.assertNotIn("Copyright blurb", text)
        self.assertNotIn("color:red", text)
        self.assertNotIn("var a=1", text)

    def test_plain_text_input_is_passed_through(self):
        self.assertEqual(dr.extract_text("already extracted prose"), "already extracted prose")

    def test_unparseable_html_never_raises(self):
        self.assertEqual(dr.extract_text("<p><div><span unclosed"), "")


class DedupeTest(unittest.TestCase):
    def test_trailing_slash_and_www_are_the_same_page(self):
        rows = [{"url": "https://www.a.com/x/", "title": "Alpha page about batteries", "content": "a"},
                {"url": "https://a.com/x", "title": "Alpha page about batteries", "content": "b"},
                {"url": "https://b.com/y", "title": "Beta page about cells", "content": "c"}]
        unique, collapsed = dr.dedupe(rows)
        self.assertEqual(len(unique), 2)
        self.assertEqual(collapsed, 1)
        self.assertEqual(unique[0]["host"], "a.com")

    def test_non_http_urls_are_dropped_before_fetch(self):
        unique, _ = dr.dedupe([{"url": "javascript:alert(1)", "title": "x", "content": ""}])
        self.assertEqual(unique, [])


class CorroborateTest(unittest.TestCase):
    def _sections(self):
        return [
            {"host": "a.com", "url": "https://a.com", "title": "battery density results",
             "text": "battery density results show ceramic electrolyte gains", "kw": dr._keywords("battery density results ceramic electrolyte gains")},
            {"host": "b.com", "url": "https://b.com", "title": "battery density results",
             "text": "battery density results confirm ceramic electrolyte gains", "kw": dr._keywords("battery density results ceramic electrolyte gains")},
            {"host": "c.com", "url": "https://c.com", "title": "unrelated cooking",
             "text": "a recipe for bread with butter and salt", "kw": dr._keywords("recipe bread butter salt")}]

    def test_a_claim_backed_by_another_host_is_cross_checked(self):
        out = dr.corroborate(self._sections())
        self.assertEqual(out[0]["verdict"], "cross_checked")
        self.assertGreaterEqual(out[0]["support"], 2)

    def test_a_lone_host_is_never_marked_cross_checked(self):
        out = dr.corroborate(self._sections())
        self.assertEqual(out[2]["verdict"], "single_source")
        self.assertEqual(out[2]["support"], 1)


class TierTest(unittest.TestCase):
    def test_words_pick_the_depth(self):
        self.assertEqual(dr.pick_tier("poora internet research kar do"), "exhaustive")
        self.assertEqual(dr.pick_tier("bas bata do ye kya hai"), "search")
        self.assertEqual(dr.pick_tier("research quantum error correction"), "deep")

    def test_facets_grow_with_the_tier_but_stay_bounded(self):
        self.assertEqual(len(dr._facets("topic", "search")), 1)
        self.assertEqual(len(dr._facets("topic", "deep")), 4)
        self.assertLessEqual(len(dr._facets("topic", "exhaustive")), 9)

    def test_estimate_reports_numbers_not_adjectives(self):
        est = dr.estimate("deep")
        self.assertEqual(est["queries"], 4)
        self.assertGreaterEqual(est["read"], 1)


class FailoverTest(unittest.TestCase):
    """A dead key must not stop the run, and a narrow query must not park a key."""

    def setUp(self):
        self._providers = dr.PROVIDERS
        dr._PARK.clear()
        dr._FAILS.clear()

    def tearDown(self):
        dr.PROVIDERS = self._providers
        dr._PARK.clear()
        dr._FAILS.clear()

    def test_two_queried_providers_survive_one_dead_one(self):
        dr.PROVIDERS = [("dead", lambda q, limit=8: (None, "HTTP 402 credits")),
                        ("alive", lambda q, limit=8: ([dr._row("https://a.com/x", "t", "s", "alive")], ""))]
        rows, providers, _ = dr.search_all(["topic"])
        self.assertEqual(len(rows), 1)
        self.assertEqual([p["ok"] for p in providers], [False, True])
        self.assertIn("402", providers[0]["error"])

    def test_three_failures_park_a_provider_and_it_stops_being_called(self):
        calls = {"n": 0}

        def broken(q, limit=8):
            calls["n"] += 1
            raise RuntimeError("connection reset")
        dr.PROVIDERS = [("broken", broken)]
        for _ in range(4):
            dr.search_all(["q"])
        self.assertEqual(calls["n"], dr.PARK_AFTER_FAILS, "parked providers must not be retried")
        _rows, providers, _ans = dr.search_all(["q again"])
        self.assertTrue(providers[0]["parked"])
        self.assertIn("parked", providers[0]["error"])

    def test_an_empty_result_set_is_an_answer_not_a_failure(self):
        dr.PROVIDERS = [("narrow", lambda q, limit=8: ([], ""))]
        for _ in range(5):
            dr.search_all(["very obscure phrase"])
        self.assertFalse(dr._parked("narrow"),
                         "0 hits must not park a working provider")


class ProviderListTest(unittest.TestCase):
    """The full provider chain is present, with free providers still active."""

    def test_provider_chain_includes_restored_providers(self):
        self.assertEqual([name for name, _ in dr.PROVIDERS],
                         ["firecrawl", "tavily", "exa", "serper", "core",
                          "openalex", "wikipedia", "hackernews"])


class OpenAlexKeyTest(unittest.TestCase):
    """A bad token must cost one request, never the whole provider."""

    def setUp(self):
        self._request = dr._request
        self._env = dr._env
        self._ok = list(dr._OPENALEX_KEY_OK)
        dr._OPENALEX_KEY_OK[0] = True
        dr._env = lambda name, default="": "bogus-token" if name == "OPENALEX_API_KEY" else default

    def tearDown(self):
        dr._request = self._request
        dr._env = self._env
        dr._OPENALEX_KEY_OK[:] = self._ok

    def test_401_falls_back_to_the_keyless_pool_and_stops_sending_the_key(self):
        import json as _json
        import urllib.error
        seen = []

        def fake_request(url, data=None, headers=None, timeout=14.0):
            seen.append(bool(headers and "Authorization" in headers))
            if seen[-1]:
                raise urllib.error.HTTPError(url, 401, "Invalid or missing API key", {}, None)
            return 200, _json.dumps({"results": [{"display_name": "A paper",
                                                 "doi": "https://doi.org/10.1/x",
                                                 "cited_by_count": 7,
                                                 "publication_year": 2026}]}).encode()
        dr._request = fake_request
        rows, _extra = dr.openalex_search("battery")
        self.assertEqual(len(rows), 1)
        self.assertEqual(seen, [True, False], "retry must be keyless")
        self.assertFalse(dr._OPENALEX_KEY_OK[0])
        dr.openalex_search("battery again")
        self.assertEqual(seen[-1], False, "a rejected key must not be re-sent")


class CoreKeyTest(unittest.TestCase):
    """A rejected CORE token falls back to the working keyless endpoint."""

    def setUp(self):
        self._request = dr._request
        self._env = dr._env
        self._ok = list(dr._CORE_KEY_OK)
        dr._CORE_KEY_OK[0] = True
        dr._env = lambda name, default="": "bogus-token" if name == "CORE_API_KEY" else default

    def tearDown(self):
        dr._request = self._request
        dr._env = self._env
        dr._CORE_KEY_OK[:] = self._ok

    def test_500_falls_back_to_the_keyless_pool_and_stops_sending_the_key(self):
        import json as _json
        import urllib.error
        seen = []

        def fake_request(url, data=None, headers=None, timeout=14.0):
            seen.append(bool(headers and "Authorization" in headers))
            if seen[-1]:
                raise urllib.error.HTTPError(url, 500, "Internal Server Error", {}, None)
            return 200, _json.dumps({"results": [{"title": "A paper",
                                                 "download_url": "https://core.ac.uk/x",
                                                 "abstract": "Abstract"}]}).encode()
        dr._request = fake_request
        rows, _extra = dr.core_search("battery")
        self.assertEqual(len(rows), 1)
        self.assertEqual(seen, [True, False], "retry must be keyless")
        self.assertFalse(dr._CORE_KEY_OK[0])
        dr.core_search("battery again")
        self.assertEqual(seen[-1], False, "a rejected key must not be re-sent")


class RunTest(unittest.TestCase):
    """End-to-end with every network call faked."""

    def setUp(self):
        self._providers = dr.PROVIDERS
        self._request = dr._request
        self._writer = dr._writer
        # No test may spend the free writer chain - or touch the network.
        dr._writer = lambda: None

    def tearDown(self):
        dr.PROVIDERS = self._providers
        dr._request = self._request
        dr._writer = self._writer

    def test_search_tier_reads_no_pages_and_says_so(self):
        """A web search answers from snippets; it must not pretend to have read."""
        rows = [{"url": "https://a.com/1", "title": "battery density results",
                 "content": "some snippet", "provider": "fake"}]
        dr.PROVIDERS = [("fake", lambda q, limit=8: (rows, ""))]
        called = {"n": 0}

        def spy(url, data=None, headers=None, timeout=14.0):
            called["n"] += 1
            return 200, PAGE
        dr._request = spy
        out = dr.run("battery density", tier="search")
        self.assertEqual(called["n"], 0, "search tier must not fetch any page")
        self.assertEqual(out["attempted"], 0)
        self.assertEqual(out["scraped"], 0)
        self.assertEqual(out["evidence_mode"], "snippets")
        self.assertIn("battery density results", out["report"])

    def test_deep_tier_reports_who_wrote_the_prose(self):
        rows = [{"url": "https://a.com/1", "title": "battery density results",
                 "content": "x", "provider": "fake"}]
        dr.PROVIDERS = [("fake", lambda q, limit=8: (rows, ""))]
        dr._request = lambda url, data=None, headers=None, timeout=14.0: (200, PAGE)
        out = dr.run("battery density", tier="deep")
        self.assertEqual(out["written_by"], "deterministic-dossier",
                         "without a writer pool the dossier must be labelled honestly")
        self.assertEqual(out["evidence_mode"], "pages-read")

    def test_run_reports_what_it_read_and_what_failed(self):
        rows = [{"url": "https://a.com/1", "title": "battery density results", "content": "x", "provider": "fake"},
                {"url": "https://b.com/2", "title": "ceramic electrolyte gains measured", "content": "y", "provider": "fake"},
                {"url": "https://c.com/3", "title": "unrelated cooking", "content": "z", "provider": "fake"}]
        dr.PROVIDERS = [("fake", lambda q, limit=8: (rows, "")),
                        ("broken", lambda q, limit=8: (None, "no key configured"))]

        def fake_request(url, data=None, headers=None, timeout=14.0):
            if "c.com" in url:
                raise AssertionError("simulated 403 wall")
            return 200, PAGE
        dr._request = fake_request

        out = dr.run("battery density", tier="deep")
        self.assertEqual(out["tier"], "deep")
        self.assertEqual(out["attempted"], 3)
        self.assertEqual(out["scraped"], 2, "only the pages that really returned text")
        self.assertEqual(out["found"], 12, "deep tier asks 4 facets x 3 rows each")
        self.assertGreaterEqual(out["cross_checked"], 1)
        failed = [p for p in out["providers"] if not p["ok"]]
        self.assertEqual({p["name"] for p in failed}, {"broken"})
        self.assertEqual(len(failed), 4, "one honest fail row per facet query")
        self.assertIn("no key configured", failed[0]["error"])
        failed = [d for d in out["sources_detail"] if not d["ok"]]
        self.assertEqual(len(failed), 1)
        self.assertTrue(failed[0]["error"])
        self.assertNotIn("text", failed[0])
        self.assertNotIn("text", out["sources_detail"][0], "payload must not carry page bodies")
        self.assertTrue(out["report"].startswith("### "))

    def test_every_provider_dead_is_reported_as_zero_pages_not_an_empty_report(self):
        dr.PROVIDERS = [("broken", lambda q, limit=8: (None, "no key configured"))]
        dr._request = lambda *a, **k: (_ for _ in ()).throw(AssertionError("must not fetch"))
        out = dr.run("anything", tier="search")
        self.assertIn("0 pages readable", out["error"])
        self.assertEqual(out["scraped"], 0)
        self.assertEqual(out["sources"], [])


if __name__ == "__main__":
    unittest.main()
