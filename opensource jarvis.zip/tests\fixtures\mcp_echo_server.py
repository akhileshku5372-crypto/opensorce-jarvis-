"""Offline MCP stdio server used by the JARVIS MCP client tests.

Speaks real newline-delimited JSON-RPC 2.0 (MCP stdio transport) and exposes a
single `echo` tool. No network, no credentials - it exists so the MCP client can
be tested end-to-end against a real subprocess.
"""
import json
import sys

TOOLS = [{
    "name": "echo",
    "description": "Repeat the given text back.",
    "inputSchema": {
        "type": "object",
        "properties": {"text": {"type": "string"}},
        "required": ["text"],
    },
}]


def reply(request_id, result):
    sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result}) + "\n")
    sys.stdout.flush()


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except Exception:
            continue
        method = message.get("method")
        request_id = message.get("id")
        if method == "initialize":
            reply(request_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "jarvis-echo", "version": "1.0.0"},
            })
        elif method == "tools/list":
            reply(request_id, {"tools": TOOLS})
        elif method == "tools/call":
            params = message.get("params") or {}
            arguments = params.get("arguments") or {}
            text = arguments.get("text", "")
            if not isinstance(text, str):
                reply(request_id, {"content": [{"type": "text", "text": "invalid 'text' argument"}],
                                   "isError": True})
                continue
            reply(request_id, {"content": [{"type": "text", "text": "echo: " + text}],
                               "isError": False})
        elif request_id is not None:
            sys.stdout.write(json.dumps({
                "jsonrpc": "2.0", "id": request_id,
                "error": {"code": -32601, "message": "method not found: %s" % method}}) + "\n")
            sys.stdout.flush()
        # notifications (no id) are simply ignored


if __name__ == "__main__":
    main()
