﻿"""Edge-TTS Podcast Engine (port 7781) - session /podcast/* contract.

Drop-in replacement for the retired stub. Hono /api/kamisensei/generate-podcast
calls these endpoints:
  POST /podcast/start    {notebook_id, language_mode, speed} -> {ok, session}
  POST /podcast/turn     {session, speaker, text}            -> {ok, seconds}
  POST /podcast/finalize {session}                           -> {ok, url, file, seconds}
  GET  /health                                               -> {ok, engine}

Voices: Hindi/Hinglish - hi-IN-MadhurNeural (HostA) / hi-IN-SwaraNeural (HostB);
English - en-GB-RyanNeural / en-GB-SoniaNeural; Japanese - ja-JP-KeitaNeural /
ja-JP-NanamiNeural. Devanagari / CJK segments route to the matching language
voice even inside a Hinglish episode (code-switching).
"""
import asyncio
import io
import json
import os
import re
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import edge_tts
from edge_tts_http import _pronounce_fix

HOST = "127.0.0.1"
PORT = int(os.environ.get("PODCAST_PORT", "7781"))
STATIC_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "public", "static")

VOICES = {
    "hinglish": ("hi-IN-MadhurNeural", "hi-IN-SwaraNeural"),
    "hindi": ("hi-IN-MadhurNeural", "hi-IN-SwaraNeural"),
    "hi": ("hi-IN-MadhurNeural", "hi-IN-SwaraNeural"),
    "english": ("en-GB-RyanNeural", "en-GB-SoniaNeural"),
    "en": ("en-GB-RyanNeural", "en-GB-SoniaNeural"),
    "japanese": ("ja-JP-KeitaNeural", "ja-JP-NanamiNeural"),
    "ja": ("ja-JP-KeitaNeural", "ja-JP-NanamiNeural"),
}
_JA_VOICES = ("ja-JP-KeitaNeural", "ja-JP-NanamiNeural")
_RATE = "+8%"
_DEVANAGARI_RE = re.compile(r"[\u0900-\u097f]")
_CJK_RE = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")
_SEG_RE = re.compile(
    r"[\u0900-\u097f]+|[\u3040-\u30ff\u4e00-\u9fff]+|"
    r"[^\u0900-\u097f\u3040-\u30ff\u4e00-\u9fff]+")
_sessions = {}
_state_lock = threading.Lock()


def _log(msg):
    print("[podcast-engine] %s" % msg, flush=True)


async def _synth_segment(seg, voice):
    fixed = _pronounce_fix(seg)
    comm = edge_tts.Communicate(fixed, voice, rate=_RATE)
    buf = io.BytesIO()
    async for chunk in comm.stream():
        if chunk["type"] == "audio":
            buf.write(chunk["data"])
    return buf.getvalue()


def _turn_mp3(text, mode, speaker):
    male, female = VOICES.get(mode, VOICES["hinglish"])
    base = male if speaker != "HostB" else female
    hi = male if speaker != "HostB" else female
    jp = _JA_VOICES[0] if speaker != "HostB" else _JA_VOICES[1]
    out = io.BytesIO()
    for seg in _SEG_RE.findall(text):
        seg = seg.strip()
        if not seg:
            continue
        if _DEVANAGARI_RE.search(seg):
            voice = hi
        elif _CJK_RE.search(seg):
            voice = jp
        else:
            voice = base
        try:
            out.write(asyncio.run(_synth_segment(seg, voice)))
        except Exception as exc:
            _log("segment failed (%s); skipping: %r" % (exc, seg[:60]))
    return out.getvalue()


class _Handler(BaseHTTPRequestHandler):
    server_version = "edge-podcast/1.0"

    def log_message(self, *args):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if not 0 <= length <= 4 * 1024 * 1024:
                return None
            raw = self.rfile.read(length) if length else b""
            return json.loads(raw.decode("utf-8", "replace"))
        except Exception:
            return None

    def do_GET(self):
        if self.path.split("?")[0] == "/health":
            self._json(200, {"ok": True, "engine": "edge-tts-python"})
        else:
            self._json(404, {"error": "not_found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        body = self._read_body() or {}
        if path == "/podcast/start":
            notebook_id = str(body.get("notebook_id") or "session")[:160]
            try:
                speed = max(0.5, min(2.0, float(body.get("speed") or 1.0)))
            except (TypeError, ValueError):
                speed = 1.0
            language_mode = str(body.get("language_mode") or "hinglish")[:40]
            sid = uuid.uuid4().hex[:12]
            with _state_lock:
                _sessions[sid] = {"id": sid, "notebook_id": notebook_id,
                                  "language_mode": language_mode,
                                  "audio": b"", "seconds": 0.0}
            _log("session %s started (notebook=%s lang=%s)" % (sid, notebook_id, language_mode))
            self._json(200, {"ok": True, "session": sid})
        elif path == "/podcast/turn":
            sid = str(body.get("session") or "")
            with _state_lock:
                sess = _sessions.get(sid)
            if sess is None:
                self._json(404, {"error": "unknown_session"})
                return
            text = str(body.get("text") or "").strip()
            speaker = "HostB" if body.get("speaker") == "HostB" else "HostA"
            if not text:
                self._json(400, {"error": "empty_text"})
                return
            mp3 = _turn_mp3(text, sess["language_mode"], speaker)
            est = len(text) / 14.0
            with _state_lock:
                sess["audio"] += mp3
                sess["seconds"] += est
            _log("turn ok (%s) %.2fs est audio, %d bytes" % (speaker, est, len(mp3)))
            self._json(200, {"ok": True, "seconds": est})
        elif path == "/podcast/finalize":
            sid = str(body.get("session") or "")
            with _state_lock:
                sess = _sessions.pop(sid, None)
            if sess is None:
                self._json(404, {"error": "unknown_session"})
                return
            audio = sess["audio"]
            safe_id = re.sub(r"[^a-zA-Z0-9_-]+", "_", sess["notebook_id"])[:80] or "session"
            os.makedirs(STATIC_DIR, exist_ok=True)
            mp3_path = os.path.join(STATIC_DIR, "podcast_%s.mp3" % safe_id)
            if audio:
                with open(mp3_path, "wb") as fh:
                    fh.write(audio)
                url = "/static/podcast_%s.mp3" % safe_id
            else:
                url = ""
            _log("session %s finalized -> %s (%.1fs)" % (sid, url or "NO_AUDIO", sess["seconds"]))
            self._json(200, {"ok": bool(audio), "url": url,
                             "file": os.path.basename(mp3_path) if audio else "",
                             "seconds": sess["seconds"]})
        elif path == "/podcast/cancel":
            sid = str(body.get("session") or "")
            with _state_lock:
                _sessions.pop(sid, None)
            self._json(200, {"ok": True})
        else:
            self._json(404, {"error": "not_found"})


if __name__ == "__main__":
    _log("edge-tts podcast engine listening on http://%s:%d" % (HOST, PORT))
    ThreadingHTTPServer((HOST, PORT), _Handler).serve_forever()
