/* JARVIS 2.0 — Holographic 3D Neural Brain Engine & Interactive HUD
   Direct WebGL Three.js implementation (4200 pts, 8 cluster centroids, 36 action potential pulses)
   Integrates Image 2 layout: 8 Subsystems, Detail Drawer, System Status, Cognitive Trends, Recent Activity, Bottom Command Bar, ZIP Exporter
*/
(() => {
  // ── Web Audio API Sci-Fi Sound Synthesizer ─────────────────────────────────
  class JarvisSoundManager {
    constructor() {
      this.ctx = null;
      this.isMuted = false;
      if (typeof window !== 'undefined') {
        const saved = localStorage.getItem('jarvis_brain_muted');
        if (saved !== null) this.isMuted = saved === 'true';
      }
    }
    getContext() {
      if (this.isMuted) return null;
      if (!this.ctx && typeof window !== 'undefined') {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    }
    toggleMute() {
      this.isMuted = !this.isMuted;
      if (typeof window !== 'undefined') {
        localStorage.setItem('jarvis_brain_muted', String(this.isMuted));
      }
      return this.isMuted;
    }
    getMuted() { return this.isMuted; }
    playChirp() {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const now = ctx.currentTime;
        osc.frequency.setValueAtTime(1200, now);
        osc.frequency.exponentialRampToValueAtTime(420, now + 0.05);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.05);
      } catch {}
    }
    playSelect() {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        const now = ctx.currentTime;
        osc.frequency.setValueAtTime(740, now);
        osc.frequency.setValueAtTime(1480, now + 0.03);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.09);
      } catch {}
    }
    playPulse() {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const osc = ctx.createOscillator();
        const filter = ctx.createBiquadFilter();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(800, ctx.currentTime);
        filter.Q.value = 4;
        const now = ctx.currentTime;
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.14);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.15);
      } catch {}
    }
    playAlert() {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        const now = ctx.currentTime;
        osc.frequency.setValueAtTime(980, now);
        osc.frequency.setValueAtTime(1320, now + 0.08);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
      } catch {}
    }
  }
  const soundFx = new JarvisSoundManager();

  // ── 8 Primary Functional Subsystems (Matching Image 2 & JARVIS Architecture) ───
  const SUBSYSTEMS = {
    vision: {
      id: 'vision',
      title: 'Vision',
      subtitle: 'Camera • Screen • Image',
      providers: 'Gemini Lite / xKiro / NVIDIA',
      color: '#06b6d4',
      lobeRegion: 'Occipital Lobe & Visual Cortex',
      status: 'active',
      models: ['gemini-flash-lite-latest', 'qwen/qwen3-vl-plus:free', 'meta/llama-3.2-11b-vision-instruct'],
      description: 'Real-time multi-modal stream parsing, desktop screen OCR, optical object tracking, and gesture recognition.',
      registeredTools: ['screen_capture', 'webcam_stream', 'inspect_ui_tree', 'ocr_kamisensei'],
      recentAction: 'Analyzed primary viewport optical feed (1080p, 60fps)',
      latencyMs: 142,
      position: 'left',
      clusterPosition: [0.9, 0.2, -1.2],
      synapticRateHz: 84,
      dataFlowRateMBs: 18.4,
    },
    language: {
      id: 'language',
      title: 'Language',
      subtitle: 'Conversation • Translation',
      providers: 'Groq / Gemini Lite / xKiro',
      color: '#10b981',
      lobeRegion: 'Temporal Lobe & Broca / Wernicke Area',
      status: 'active',
      models: ['openai/gpt-oss-120b', 'gemini-flash-lite-latest', 'qwen/qwen3.7-flash:free'],
      description: 'Conversational synthesis, intent parsing, semantic query resolution, and multilingual translation.',
      registeredTools: ['synthesize_dialogue', 'format_response', 'parse_user_intent', 'detect_sentiment'],
      recentAction: 'Generated neural prompt response for user query',
      latencyMs: 98,
      position: 'left',
      clusterPosition: [-1.4, -0.3, 0.2],
      synapticRateHz: 112,
      dataFlowRateMBs: 4.2,
    },
    memory: {
      id: 'memory',
      title: 'Memory',
      subtitle: 'Long-term • Context • Facts',
      providers: 'ChromaDB + SQLite + Mem0',
      color: '#a855f7',
      lobeRegion: 'Hippocampus & Limbic Core',
      status: 'active',
      models: ['jarvis_memory (ChromaDB)', 'kami_sensei_rag', 'mem0_cloud'],
      description: 'Vector embeddings indexing, semantic conversation persistence, entity recall, and episodic knowledge indexing.',
      registeredTools: ['query_vector_store', 'store_episodic_memory', 'recall_facts', 'reindex_rag_corpus'],
      recentAction: 'Indexed 3 conversation facts into local collection D:\\JARVIS_DATA',
      latencyMs: 45,
      position: 'left',
      clusterPosition: [0.0, -0.7, -0.1],
      synapticRateHz: 67,
      dataFlowRateMBs: 1.8,
    },
    planning: {
      id: 'planning',
      title: 'Planning',
      subtitle: 'Task Analysis • Decision',
      providers: 'Qwen / Nemotron / MiniMax',
      color: '#f59e0b',
      lobeRegion: 'Prefrontal Cortex (Executive Hub)',
      status: 'active',
      models: ['qwen/qwen3.7-flash:free', 'nvidia/nemotron-3.5-lightning-30b-a3b', 'minimax/minimax-m3.1-flash:free'],
      description: 'Hierarchical goal decomposition, task graph sequencing, dependency resolution, and autonomous verification.',
      registeredTools: ['generate_task_graph', 'verify_prerequisites', 'evaluate_heuristic', 'route_agent_step'],
      recentAction: 'Evaluated sub-agent execution tree for neural explorer',
      latencyMs: 110,
      position: 'left',
      clusterPosition: [-0.9, 0.8, 1.1],
      synapticRateHz: 95,
      dataFlowRateMBs: 3.1,
    },
    audio: {
      id: 'audio',
      title: 'Audio',
      subtitle: 'Speech • STT • TTS',
      providers: 'Whisper + Piper / Edge-TTS',
      color: '#ef4444',
      lobeRegion: 'Superior Temporal Gyrus (Auditory Cortex)',
      status: 'active',
      models: ['whisper-base-int8', 'en-GB-RyanNeural', 'hi-IN-MadhurNeural'],
      description: 'Continuous wake-word monitoring ("Hey JARVIS"), real-time Whisper STT transcription, and Edge Neural voice audio synthesis.',
      registeredTools: ['listen_mic_stream', 'synthesize_speech_wav', 'detect_barge_in', 'filter_noise_ambient'],
      recentAction: 'Edge-TTS RyanNeural audio channel active on port 7782',
      latencyMs: 62,
      position: 'right',
      clusterPosition: [1.4, -0.3, 0.2],
      synapticRateHz: 78,
      dataFlowRateMBs: 5.6,
    },
    tools: {
      id: 'tools',
      title: 'Tools',
      subtitle: 'Browser • Files • Apps',
      providers: 'xKiro / OpenRouter / n8n',
      color: '#0ea5e9',
      lobeRegion: 'Parietal Lobe (Tool Manipulation Network)',
      status: 'active',
      models: ['qwen/qwen3.7-flash:free', 'minimax/minimax-m3.1-flash:free', 'n8n-workflow-api', 'firecrawl-v1'],
      description: 'Dynamic tool dispatching, file system operations, web scraping via Firecrawl, and n8n webhook automations.',
      registeredTools: ['firecrawl_search', 'read_file_system', 'execute_n8n_flow', 'fetch_weather_api'],
      recentAction: 'Dispatched Firecrawl search query for system updates',
      latencyMs: 185,
      position: 'right',
      clusterPosition: [0.8, 0.9, -0.5],
      synapticRateHz: 88,
      dataFlowRateMBs: 8.9,
    },
    coding: {
      id: 'coding',
      title: 'Coding',
      subtitle: 'Code • Debug • Git',
      providers: 'Qwen / Gemini Lite / DeepSeek',
      color: '#8b5cf6',
      lobeRegion: 'Left Hemisphere Angular Gyrus (Symbolic Logic)',
      status: 'active',
      models: ['qwen/qwen3.8-27b', 'gemini-flash-lite-latest', 'deepseek-ai/deepseek-coder-6.7b-instruct'],
      description: 'Source code syntax AST generation, patch creation, automated test execution, and Git repository introspection.',
      registeredTools: ['git_diff_inspector', 'run_test_suite', 'refactor_ast', 'github_repos_reader'],
      recentAction: 'Verified Three.js 3D WebGL shader geometry buffer allocation',
      latencyMs: 130,
      position: 'right',
      clusterPosition: [-0.6, 0.4, -0.9],
      synapticRateHz: 104,
      dataFlowRateMBs: 12.3,
    },
    computer_use: {
      id: 'computer_use',
      title: 'Computer Use',
      subtitle: 'Mouse • Keyboard • OS',
      providers: 'Agent-S / Playwright / Bridge',
      color: '#14b8a6',
      lobeRegion: 'Primary Motor Cortex & Cerebellum',
      status: 'active',
      models: ['Agent-S (GUI grounded)', 'Playwright / Chromium', 'Windows Bridge Local (Port 7778)'],
      description: 'Desktop GUI grounding, mouse clicking, keyboard automation, window management, and native Windows loopback bridge control.',
      registeredTools: ['mouse_move_click', 'send_keyboard_keys', 'window_manager_focus', 'launch_windows_app'],
      recentAction: 'Windows loopback bridge active on 127.0.0.1:7778',
      latencyMs: 72,
      position: 'right',
      clusterPosition: [0.0, -1.1, -1.2],
      synapticRateHz: 118,
      dataFlowRateMBs: 15.2,
    },
  };

  const CAPS = Object.values(SUBSYSTEMS).map(s => ({ id: s.id, label: s.title, color: s.color }));
  const LOBE_TO_CAP = {
    prefrontal_cortex: 'planning', cerebrum: 'coding', motor_cortex: 'tools', hippocampus: 'memory',
    broca_area: 'audio', vision: 'vision', language: 'language', memory: 'memory',
    planning: 'planning', audio: 'audio', tools: 'tools', coding: 'coding', computer_use: 'computer_use'
  };
  const LOBE_COLOR = {
    prefrontal_cortex: '#f59e0b', cerebrum: '#8b5cf6', motor_cortex: '#0ea5e9', hippocampus: '#a855f7',
    broca_area: '#ef4444', vision: '#06b6d4', language: '#10b981', memory: '#a855f7',
    planning: '#f59e0b', audio: '#ef4444', tools: '#0ea5e9', coding: '#8b5cf6', computer_use: '#14b8a6'
  };
  const DEFAULT_COLOR = '#06b6d4';

  // Three.js Scene Variables
  let THREE = null, wrap = null, container = null, scene = null, camera = null, renderer = null;
  let brainRoot = null, pointsMesh = null, linesGroup = null, pulsesGroup = null, centroidsGroup = null, reticlesGroup = null;
  let nodes = [], centroidMeshes = new Map(), fiberCurves = [], pulseSpheres = [], originalPositions = null;
  let explodeAmount = 0, isExploded = false, isRotating = true, isOverclocked = false, is3DActive = true;
  let isDragging = false, prevMouse = { x: 0, y: 0 }, mouse = null, rotationVel = { x: 0, y: 0.002 }, targetCamPos = null;
  let clock = null, raf = 0, initialized = false, ro = null, selectedSubsystemId = null;
  let activeLobe = 'prefrontal_cortex', activeColor = DEFAULT_COLOR, hoveredNode = null;
  let currentTheme = 'arc_cyan';
  let cameraStream = null;

  const getThree = () => window.THREE || window.__JARVIS_THREE__ || null;

  // ── Color Theme Map ────────────────────────────────────────────────────────
  const THEMES = {
    arc_cyan: { primary: 0x06b6d4, secondary: 0x38bdf8, pulse: 0xffffff, bg: 0x020617 },
    stark_gold: { primary: 0xf59e0b, secondary: 0xfbbf24, pulse: 0xffffff, bg: 0x020617 },
    quantum_violet: { primary: 0xa855f7, secondary: 0xc084fc, pulse: 0x38bdf8, bg: 0x020617 },
    tactical_emerald: { primary: 0x10b981, secondary: 0x34d399, pulse: 0x6ee7b7, bg: 0x020617 },
    neural_crimson: { primary: 0xef4444, secondary: 0xf87171, pulse: 0xfbbf24, bg: 0x020617 },
  };

  function ensureDom() {
    wrap = document.getElementById('brain-canvas-wrap');
    if (!wrap) return false;
    try {
      const cs = getComputedStyle(wrap);
      if (cs.position === 'static') wrap.style.position = 'relative';
    } catch {}
    if (!wrap.style.minHeight) wrap.style.minHeight = '560px';
    if (wrap.clientHeight < 12) wrap.style.minHeight = '560px';

    if (!container) {
      container = document.createElement('div');
      container.id = 'brain-holo-mount';
      container.style.cssText = 'position:absolute;inset:0;z-index:2;width:100%;height:100%;cursor:grab;display:block;background:transparent;';
      wrap.appendChild(container);
      try { wrap.classList.add('brain-holo-ready'); } catch {}
      const c = document.getElementById('brain-canvas'); if (c) c.style.display = 'none';
      const w = document.getElementById('brain-wires'); if (w) w.style.display = 'none';

      if (!document.getElementById('brain-tooltip')) {
        const t = document.createElement('div');
        t.id = 'brain-tooltip';
        t.className = 'brain-tooltip';
        t.hidden = true;
        t.style.cssText = 'position:fixed;z-index:50;pointer-events:none;background:rgba(2,6,23,0.92);border:1px solid #22c7f280;padding:6px 10px;border-radius:8px;font-size:11px;color:#e5f7fc;max-width:240px;box-shadow:0 8px 24px rgba(0,0,0,0.6)';
        document.body.appendChild(t);
      }
    } else {
      try { wrap.classList.add('brain-holo-ready'); } catch {}
    }
    return true;
  }

  // ── Procedural Anatomical Brain Geometry (4200 Points + Convolutions) ──────
  function generateBrainGeometry() {
    const pointsCount = 4200;
    const positions = [];
    const colors = [];
    const genNodes = [];

    // Register centroid nodes for the 8 JARVIS subsystems
    Object.values(SUBSYSTEMS).forEach((sub) => {
      const [cx, cy, cz] = sub.clusterPosition;
      genNodes.push({
        id: `node-${sub.id}-centroid`,
        label: sub.title,
        subsystemId: sub.id,
        position: [cx, cy, cz],
        color: sub.color,
        size: 0.12,
        activityLevel: 0.95,
        isCentroid: true,
        connections: [],
        description: `${sub.title} neural processing hub (${sub.lobeRegion})`,
      });
    });

    // Interconnect centroids into a coherent neural graph
    const centroidList = genNodes.filter(n => n.isCentroid);
    for (let i = 0; i < centroidList.length; i++) {
      for (let j = i + 1; j < centroidList.length; j++) {
        centroidList[i].connections.push(centroidList[j].id);
        centroidList[j].connections.push(centroidList[i].id);
      }
    }

    // Generate thousands of cortical surface and deep neural points
    for (let i = 0; i < pointsCount; i++) {
      const isLeft = Math.random() < 0.5;
      const hemiSign = isLeft ? -1 : 1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      // Base brain dimensions (ellipsoid stretched along Z-axis)
      const rx = 1.15;
      const ry = 0.95;
      const rz = 1.45;

      // Cortex gyri & sulci undulating waves
      const gyrusFolds =
        1 +
        0.09 * Math.sin(theta * 7) * Math.cos(phi * 9) +
        0.05 * Math.sin(phi * 16) +
        0.04 * Math.cos(theta * 12);

      let x = rx * Math.sin(phi) * Math.cos(theta) * gyrusFolds;
      let y = ry * Math.sin(phi) * Math.sin(theta) * gyrusFolds;
      let z = rz * Math.cos(phi) * gyrusFolds;

      // Hemispheric split: push apart laterally and pinch medial longitudinal fissure
      x = hemiSign * (0.07 + Math.abs(x) * 0.94);

      // Anatomical shaping:
      if (y < -0.3 && z < -0.3) {
        y = y * 0.9 - 0.2;
        x = x * 0.85;
      }
      if (y < -0.7 && Math.abs(x) < 0.4 && z > -0.5 && z < 0.2) {
        x = x * 0.45;
        z = z * 0.5 - 0.1;
      }
      if (z > 0.8) {
        y = y * 0.95;
        x = x * 0.92;
      }

      // Assign to nearest subsystem cluster for coloring
      let nearestSub = SUBSYSTEMS.planning;
      let minDistance = Infinity;

      Object.values(SUBSYSTEMS).forEach((sub) => {
        const [cx, cy, cz] = sub.clusterPosition;
        const dist = Math.hypot(x - cx, y - cy, z - cz);
        if (dist < minDistance) {
          minDistance = dist;
          nearestSub = sub;
        }
      });

      positions.push(x, y, z);

      const baseColor = new THREE.Color(nearestSub.color);
      baseColor.offsetHSL(0, (Math.random() - 0.5) * 0.15, (Math.random() - 0.5) * 0.2);
      colors.push(baseColor.r, baseColor.g, baseColor.b);

      if (i % 60 === 0) {
        genNodes.push({
          id: `node-synapse-${i}`,
          label: `${nearestSub.title} Synapse #${i}`,
          subsystemId: nearestSub.id,
          position: [x, y, z],
          color: nearestSub.color,
          size: 0.08,
          activityLevel: 0.5 + Math.random() * 0.4,
          connections: [`node-${nearestSub.id}-centroid`],
        });
      }
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.08,
      sizeAttenuation: true,
      vertexColors: true,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
    });

    const mesh = new THREE.Points(geometry, material);
    mesh.frustumCulled = false;

    return {
      pointsMesh: mesh,
      nodes: genNodes,
      originalPositions: new Float32Array(positions),
    };
  }

  // ── Build Scene ────────────────────────────────────────────────────────────
  function buildScene() {
    THREE = getThree();
    if (!THREE) return false;
    if (!ensureDom()) return false;

    try {
      const W = Math.max(320, container.clientWidth || wrap.clientWidth || 640);
      const H = Math.max(300, container.clientHeight || wrap.clientHeight || 520);

      scene = new THREE.Scene();
      scene.fog = new THREE.FogExp2(0x020617, 0.015);

      camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 100);
      targetCamPos = new THREE.Vector3(0, 0.4, 5.2);
      camera.position.copy(targetCamPos);
      camera.lookAt(0, 0, 0);

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
      renderer.setSize(W, H);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setClearColor(0x000000, 0);
      renderer.domElement.style.cssText = 'width:100%;height:100%;display:block;outline:none;';

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      brainRoot = new THREE.Group();
      scene.add(brainRoot);

      // Points mesh
      const geomData = generateBrainGeometry();
      pointsMesh = geomData.pointsMesh;
      nodes = geomData.nodes;
      originalPositions = geomData.originalPositions;
      brainRoot.add(pointsMesh);

      // Lines & Pulses
      linesGroup = new THREE.Group();
      brainRoot.add(linesGroup);

      pulsesGroup = new THREE.Group();
      brainRoot.add(pulsesGroup);

      centroidsGroup = new THREE.Group();
      brainRoot.add(centroidsGroup);

      centroidMeshes.clear();
      nodes.forEach((node) => {
        if (node.isCentroid) {
          const geom = new THREE.SphereGeometry(0.12, 16, 16);
          const sub = SUBSYSTEMS[node.subsystemId];
          const mat = new THREE.MeshBasicMaterial({
            color: new THREE.Color(sub.color),
            transparent: true,
            opacity: 0.9,
            wireframe: true,
          });
          const mesh = new THREE.Mesh(geom, mat);
          mesh.position.set(...node.position);
          mesh.userData = { nodeId: node.id, subsystemId: node.subsystemId, node };
          centroidsGroup.add(mesh);
          centroidMeshes.set(node.id, mesh);

          // Outer glowing ring
          const ringGeom = new THREE.RingGeometry(0.14, 0.18, 24);
          const ringMat = new THREE.MeshBasicMaterial({
            color: new THREE.Color(sub.color),
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.55,
          });
          const ringMesh = new THREE.Mesh(ringGeom, ringMat);
          ringMesh.position.set(...node.position);
          centroidsGroup.add(ringMesh);
        }
      });

      // Axon fiber tracts & pulses
      fiberCurves = [];
      nodes.forEach((n1) => {
        n1.connections.forEach((connId) => {
          const n2 = nodes.find(n => n.id === connId);
          if (n2 && n1.id < n2.id) {
            const p1 = new THREE.Vector3(...n1.position);
            const p2 = new THREE.Vector3(...n2.position);
            const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
            mid.y += (Math.random() - 0.5) * 0.3;
            mid.x *= 0.7;
            mid.z *= 0.8;

            const curve = new THREE.CatmullRomCurve3([p1, mid, p2]);
            fiberCurves.push({ curve, subsystemId: n1.subsystemId });

            const pts = curve.getPoints(24);
            const lineGeom = new THREE.BufferGeometry().setFromPoints(pts);
            const sub = SUBSYSTEMS[n1.subsystemId];
            const lineMat = new THREE.LineBasicMaterial({
              color: new THREE.Color(sub.color),
              transparent: true,
              opacity: 0.28,
              blending: THREE.AdditiveBlending,
            });
            linesGroup.add(new THREE.Line(lineGeom, lineMat));
          }
        });
      });

      // 36 travelling action potential pulse particles
      pulseSpheres = [];
      const pulseCount = 36;
      const pulseGeom = new THREE.SphereGeometry(0.04, 8, 8);
      for (let i = 0; i < pulseCount && fiberCurves.length > 0; i++) {
        const { curve, subsystemId } = fiberCurves[i % fiberCurves.length];
        const sub = SUBSYSTEMS[subsystemId];
        const pMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color(sub.color),
          transparent: true,
          opacity: 0.95,
        });
        const pMesh = new THREE.Mesh(pulseGeom, pMat);
        pulsesGroup.add(pMesh);
        pulseSpheres.push({
          mesh: pMesh,
          curve,
          progress: Math.random(),
          speed: 0.003 + Math.random() * 0.007,
        });
      }

      // Concentric Floor Reticles
      reticlesGroup = new THREE.Group();
      scene.add(reticlesGroup);

      const floorRing1 = new THREE.Mesh(
        new THREE.RingGeometry(2.4, 2.45, 64),
        new THREE.MeshBasicMaterial({ color: 0x06b6d4, side: THREE.DoubleSide, transparent: true, opacity: 0.22 })
      );
      floorRing1.rotation.x = Math.PI / 2;
      floorRing1.position.y = -1.6;
      reticlesGroup.add(floorRing1);

      const floorRing2 = new THREE.Mesh(
        new THREE.RingGeometry(3.1, 3.12, 64),
        new THREE.MeshBasicMaterial({ color: 0x0ea5e9, side: THREE.DoubleSide, transparent: true, opacity: 0.15 })
      );
      floorRing2.rotation.x = Math.PI / 2;
      floorRing2.position.y = -1.6;
      reticlesGroup.add(floorRing2);

      const axisMat = new THREE.LineBasicMaterial({ color: 0x06b6d4, transparent: true, opacity: 0.15 });
      const ax = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-3.2, -1.6, 0), new THREE.Vector3(3.2, -1.6, 0)]);
      const az = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, -1.6, -3.2), new THREE.Vector3(0, -1.6, 3.2)]);
      reticlesGroup.add(new THREE.Line(ax, axisMat));
      reticlesGroup.add(new THREE.Line(az, axisMat));

      // Mouse & Raycasting Interactions
      const raycaster = new THREE.Raycaster();
      mouse = new THREE.Vector2();

      function onMouseMove(e) {
        const rect = container.getBoundingClientRect();
        const cx = e.clientX - rect.left;
        const cy = e.clientY - rect.top;
        mouse.x = (cx / rect.width) * 2 - 1;
        mouse.y = -(cy / rect.height) * 2 + 1;

        if (isDragging && brainRoot) {
          const dx = e.clientX - prevMouse.x;
          const dy = e.clientY - prevMouse.y;
          brainRoot.rotation.y += dx * 0.007;
          brainRoot.rotation.x += dy * 0.007;
          rotationVel = { x: dy * 0.002, y: dx * 0.002 };
          prevMouse = { x: e.clientX, y: e.clientY };
          const th = document.getElementById('brain-tooltip');
          if (th) th.hidden = true;
          container.style.cursor = 'grabbing';
          return;
        }

        raycaster.setFromCamera(mouse, camera);
        const hits = raycaster.intersectObjects(centroidsGroup.children);
        if (hits.length > 0 && hits[0].object.userData && hits[0].object.userData.node) {
          const node = hits[0].object.userData.node;
          const sub = SUBSYSTEMS[node.subsystemId];
          hoveredNode = node;
          container.style.cursor = 'pointer';

          const tip = document.getElementById('brain-tooltip');
          if (tip) {
            tip.innerHTML = `<strong style="color:${sub.color};font-family:Orbitron,sans-serif">${node.label} Hub</strong><br><small style="color:#94a3b8">${sub.lobeRegion}</small><br><small style="color:#22d3ee;font-weight:600">Click to inspect subsystem architecture</small>`;
            tip.style.left = `${e.clientX + 14}px`;
            tip.style.top = `${e.clientY - 30}px`;
            tip.style.border = `1px solid ${sub.color}80`;
            tip.hidden = false;
          }
          return;
        }

        hoveredNode = null;
        container.style.cursor = isDragging ? 'grabbing' : 'grab';
        const t = document.getElementById('brain-tooltip');
        if (t) t.hidden = true;
      }

      container.addEventListener('mousemove', onMouseMove);
      container.addEventListener('mouseleave', () => {
        hoveredNode = null;
        isDragging = false;
        const t = document.getElementById('brain-tooltip');
        if (t) t.hidden = true;
        if (container) container.style.cursor = 'grab';
      });
      container.addEventListener('mousedown', (e) => {
        isDragging = true;
        prevMouse = { x: e.clientX, y: e.clientY };
        container.style.cursor = 'grabbing';
        try { e.preventDefault(); } catch {}
      });
      window.addEventListener('mouseup', () => {
        isDragging = false;
        if (container) container.style.cursor = 'grab';
      });

      // Mouse Wheel Zoom
      container.addEventListener('wheel', (e) => {
        e.preventDefault();
        const d = e.deltaY * 0.003;
        const dir = targetCamPos.clone().normalize();
        const len = THREE.MathUtils.clamp(targetCamPos.length() + d, 1.8, 8.5);
        targetCamPos = dir.multiplyScalar(len);
      }, { passive: false });

      // Click centroid selection
      container.addEventListener('click', (e) => {
        const rect = container.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        const rc = new THREE.Raycaster();
        rc.setFromCamera(new THREE.Vector2(x, y), camera);
        const hs = rc.intersectObjects(centroidsGroup.children);
        if (hs.length > 0 && hs[0].object.userData && hs[0].object.userData.subsystemId) {
          selectSubsystem(hs[0].object.userData.subsystemId);
        }
      });

      clock = new THREE.Clock();
      initialized = true;
      console.log(`[JARVIS Brain] 3D Neural Holo READY: 4200pts, 8 centroids, 36 pulses (${W}x${H})`);

      bindUIControls();
      return true;
    } catch (e) {
      console.error('[JARVIS Brain] buildScene failed:', e);
      return false;
    }
  }

  // ── Subsystem Selection & Slide-out Drawer ─────────────────────────────────
  function selectSubsystem(id, openDrawer = true) {
    if (!SUBSYSTEMS[id]) return;
    selectedSubsystemId = id;
    const sub = SUBSYSTEMS[id];
    if (openDrawer) soundFx.playSelect();

    // Pulse point cloud size briefly
    if (pointsMesh) {
      const m = pointsMesh.material;
      const oldSize = m.size;
      m.size = 0.12;
      setTimeout(() => { m.size = oldSize; }, 320);
    }

    // Scale target centroid
    centroidMeshes.forEach((mesh, key) => {
      const isTarget = key === `node-${id}-centroid`;
      mesh.scale.setScalar(isTarget ? 1.45 : 1);
      mesh.material.opacity = isTarget ? 1 : 0.85;
    });

    // Update active state on 8 flanking cards
    document.querySelectorAll('.brain-cap').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.cap === id);
    });

    // Update lobe bar
    const lobeBar = document.getElementById('brain-lobe');
    if (lobeBar) {
      lobeBar.textContent = sub.title.toUpperCase();
      lobeBar.style.color = sub.color;
      lobeBar.style.borderColor = sub.color;
    }
    const reasonEl = document.getElementById('brain-reason');
    if (reasonEl) reasonEl.textContent = sub.recentAction;

    if (openDrawer) {
      openDetailDrawer(id);
    }
  }

  function openDetailDrawer(id) {
    const sub = SUBSYSTEMS[id];
    if (!sub) return;

    const drawer = document.getElementById('brain-detail-drawer');
    if (!drawer) return;

    const titleEl = document.getElementById('bdd-title');
    if (titleEl) titleEl.textContent = `${sub.title.toUpperCase()} ARCHITECTURE`;

    const regionEl = document.getElementById('bdd-region');
    if (regionEl) regionEl.textContent = sub.lobeRegion;

    const dotEl = document.getElementById('bdd-dot');
    if (dotEl) {
      dotEl.style.backgroundColor = sub.color;
      dotEl.style.boxShadow = `0 0 10px ${sub.color}`;
    }

    const rateEl = document.getElementById('bdd-rate');
    if (rateEl) {
      const rate = isOverclocked ? 240 : (sub.synapticRateHz || 112);
      rateEl.innerHTML = `${rate} <span style="font-size:12px;font-weight:normal">Hz</span>`;
    }

    const latEl = document.getElementById('bdd-latency');
    if (latEl) {
      const lat = isOverclocked ? Math.round(sub.latencyMs * 0.4) : (sub.latencyMs || 24);
      latEl.innerHTML = `${lat} <span style="font-size:12px;font-weight:normal">ms</span>`;
    }

    const purposeEl = document.getElementById('bdd-purpose');
    if (purposeEl) purposeEl.textContent = sub.description;

    const modelsEl = document.getElementById('bdd-models');
    if (modelsEl) {
      modelsEl.innerHTML = sub.models.map(m => `<span class="bdd-pill" style="border-color:${sub.color}50;color:${sub.color}">${m}</span>`).join('');
    }

    const toolsEl = document.getElementById('bdd-tools');
    if (toolsEl) {
      toolsEl.innerHTML = sub.registeredTools.map(t => `<span class="bdd-pill" style="border-color:rgba(16,185,129,0.35);color:#34d399">${t}</span>`).join('');
    }

    const eventEl = document.getElementById('bdd-last-event');
    if (eventEl) eventEl.textContent = sub.recentAction;

    drawer.hidden = false;
    drawer.classList.add('open');
  }

  function closeDetailDrawer() {
    const drawer = document.getElementById('brain-detail-drawer');
    if (drawer) {
      drawer.classList.remove('open');
      setTimeout(() => { drawer.hidden = true; }, 260);
    }
  }

  function stimulateCurrentNode() {
    if (!selectedSubsystemId) selectedSubsystemId = 'planning';
    const sub = SUBSYSTEMS[selectedSubsystemId];
    soundFx.playPulse();

    // Centroid surge
    const mesh = centroidMeshes.get(`node-${selectedSubsystemId}-centroid`);
    if (mesh) {
      mesh.scale.setScalar(2.1);
      setTimeout(() => mesh.scale.setScalar(1.4), 300);
    }

    if (pointsMesh) {
      const m = pointsMesh.material;
      const oldSize = m.size;
      m.size = 0.11;
      setTimeout(() => { m.size = oldSize; }, 360);
    }

    addRecentActivity(`Action Potential: ${sub.title}`, `Synaptic spike propagated across ${sub.lobeRegion} (142 Hz)`);
  }

  // ── Recent Activity Feed ───────────────────────────────────────────────────
  function addRecentActivity(title, desc) {
    const list = document.getElementById('brp-activity-list');
    if (!list) return;

    const item = document.createElement('div');
    item.className = 'brp-activity-item';
    item.innerHTML = `
      <div class="brp-act-icon"><i data-lucide="zap"></i></div>
      <div class="brp-act-body">
        <div class="brp-act-row"><strong>${title}</strong><small>Now</small></div>
        <p>${desc}</p>
      </div>
    `;
    list.prepend(item);
    if (window.lucide) window.lucide.createIcons();
    while (list.children.length > 8) {
      list.removeChild(list.lastChild);
    }
  }

  // ── Theme Switcher ─────────────────────────────────────────────────────────
  function setTheme(themeName) {
    if (!THEMES[themeName]) return;
    currentTheme = themeName;
    const theme = THEMES[themeName];
    soundFx.playChirp();

    document.querySelectorAll('.theme-dot').forEach((dot) => {
      dot.classList.toggle('active', dot.dataset.theme === themeName);
    });

    if (reticlesGroup) {
      reticlesGroup.children.forEach((child) => {
        if (child.material) child.material.color.setHex(theme.primary);
      });
    }

    if (pointsMesh && originalPositions) {
      const colors = pointsMesh.geometry.attributes.color.array;
      const primaryColor = new THREE.Color(theme.primary);
      for (let i = 0; i < colors.length; i += 3) {
        if (Math.random() < 0.25) {
          colors[i] = primaryColor.r;
          colors[i + 1] = primaryColor.g;
          colors[i + 2] = primaryColor.b;
        }
      }
      pointsMesh.geometry.attributes.color.needsUpdate = true;
    }
  }

  // ── House Party Protocol ───────────────────────────────────────────────────
  function triggerHouseParty() {
    soundFx.playAlert();
    let pulses = 0;
    const interval = setInterval(() => {
      pulses++;
      centroidMeshes.forEach((mesh) => {
        mesh.scale.setScalar(1.5 + Math.random() * 0.5);
      });
      if (pulses > 6) {
        clearInterval(interval);
        centroidMeshes.forEach(mesh => mesh.scale.setScalar(1));
      }
    }, 120);

    if (pointsMesh) {
      const m = pointsMesh.material;
      m.size = 0.095;
      setTimeout(() => { m.size = 0.045; }, 1400);
    }

    addRecentActivity('House Party Protocol', 'Simultaneous neural synchronization of all 8 subsystems initiated');
  }

  // ── Arc Core Overclock ─────────────────────────────────────────────────────
  function toggleOverclock() {
    isOverclocked = !isOverclocked;
    soundFx.playAlert();
    const btn = document.getElementById('brain-overclock-btn');
    if (btn) {
      btn.classList.toggle('active', isOverclocked);
      btn.style.boxShadow = isOverclocked ? '0 0 18px rgba(245,158,11,0.8)' : '';
    }

    const rateEl = document.getElementById('bdd-rate');
    if (rateEl) {
      rateEl.innerHTML = `${isOverclocked ? 240 : 112} <span style="font-size:12px;font-weight:normal">Hz</span>`;
    }

    addRecentActivity(
      isOverclocked ? 'Arc Core Overclocked' : 'Normal Clock Restored',
      isOverclocked ? 'Elevated synaptic clock rate beyond 120Hz (240Hz peak surge)' : 'Synaptic rate stabilized at baseline frequencies'
    );
  }

  // ── Reset Camera ───────────────────────────────────────────────────────────
  function resetCamera() {
    targetCamPos = new THREE.Vector3(0, 0.4, 5.2);
    if (brainRoot) brainRoot.rotation.set(0, 0, 0);
    if (camera) camera.position.set(0, 0.4, 5.2);
    soundFx.playSelect();
  }

  // ── UI Controls Binding ────────────────────────────────────────────────────
  function bindUIControls() {
    // Flanking Subsystem Cards
    document.querySelectorAll('.brain-cap').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cap = btn.dataset.cap;
        if (cap) selectSubsystem(cap);
      });
    });

    // Close Detail Drawer
    document.getElementById('bdd-close')?.addEventListener('click', () => {
      soundFx.playChirp();
      closeDetailDrawer();
    });

    // Stimulate Action Potential
    document.getElementById('bdd-stimulate-btn')?.addEventListener('click', stimulateCurrentNode);

    // Zoom Controls
    document.getElementById('brain-zoom-in')?.addEventListener('click', () => {
      if (!targetCamPos) return;
      const len = Math.max(1.8, targetCamPos.length() - 0.7);
      targetCamPos = targetCamPos.clone().normalize().multiplyScalar(len);
      soundFx.playChirp();
    });

    document.getElementById('brain-zoom-out')?.addEventListener('click', () => {
      if (!targetCamPos) return;
      const len = Math.min(8.5, targetCamPos.length() + 0.7);
      targetCamPos = targetCamPos.clone().normalize().multiplyScalar(len);
      soundFx.playChirp();
    });

    document.getElementById('brain-zoom-reset')?.addEventListener('click', resetCamera);
    document.getElementById('brain-orbit-reset')?.addEventListener('click', resetCamera);

    // Explode
    const explodeBtn = document.getElementById('brain-explode');
    if (explodeBtn) {
      explodeBtn.addEventListener('click', () => {
        isExploded = !isExploded;
        explodeBtn.setAttribute('aria-pressed', String(isExploded));
        explodeBtn.classList.toggle('active', isExploded);
        soundFx.playSelect();
      });
    }

    // 3D toggle
    const toggle3D = document.getElementById('brain-3d-toggle');
    if (toggle3D) {
      toggle3D.addEventListener('click', () => {
        is3DActive = !is3DActive;
        toggle3D.classList.toggle('active', is3DActive);
        toggle3D.innerHTML = `<i data-lucide="box"></i> 3D: ${is3DActive ? 'ON' : 'OFF'}`;
        if (pointsMesh) pointsMesh.visible = is3DActive;
        if (linesGroup) linesGroup.visible = is3DActive;
        if (pulsesGroup) pulsesGroup.visible = is3DActive;
        soundFx.playSelect();
        if (window.lucide) window.lucide.createIcons();
      });
    }

    // Sound toggle
    const soundBtn = document.getElementById('brain-sound-toggle');
    if (soundBtn) {
      soundBtn.addEventListener('click', () => {
        const muted = soundFx.toggleMute();
        soundBtn.innerHTML = `<i data-lucide="${muted ? 'volume-x' : 'volume-2'}" id="brain-sound-icon"></i>`;
        if (window.lucide) window.lucide.createIcons();
        if (!muted) soundFx.playChirp();
      });
    }

    // Theme dots
    document.querySelectorAll('.theme-dot').forEach((dot) => {
      dot.addEventListener('click', () => {
        const t = dot.dataset.theme;
        if (t) setTheme(t);
      });
    });

    // Overclock & House Party
    document.getElementById('brain-overclock-btn')?.addEventListener('click', toggleOverclock);
    document.getElementById('brain-party-btn')?.addEventListener('click', triggerHouseParty);

    // Clear activity
    document.getElementById('brp-clear-activity')?.addEventListener('click', () => {
      const list = document.getElementById('brp-activity-list');
      if (list) list.innerHTML = '<div style="color:#64748b;font-size:11px;padding:8px;text-align:center">Activity cleared</div>';
      soundFx.playChirp();
    });

    // Camera view toggle
    const camToggle = document.getElementById('brp-cam-toggle');
    const camBox = document.getElementById('brp-camera-box');
    const camVideo = document.getElementById('brp-cam-video');
    const camEmpty = document.getElementById('brp-cam-empty');
    const camHud = document.getElementById('brp-cam-hud');

    async function toggleCamera() {
      soundFx.playSelect();
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        cameraStream = null;
        if (camVideo) { camVideo.srcObject = null; camVideo.style.display = 'none'; }
        if (camEmpty) camEmpty.style.display = 'flex';
        if (camHud) camHud.style.display = 'none';
        if (camToggle) { camToggle.textContent = 'CAMERA OFF'; camToggle.classList.remove('active'); }
      } else {
        try {
          if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            cameraStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 } });
            if (camVideo) {
              camVideo.srcObject = cameraStream;
              camVideo.style.display = 'block';
              camVideo.play().catch(() => {});
            }
            if (camEmpty) camEmpty.style.display = 'none';
            if (camHud) camHud.style.display = 'block';
            if (camToggle) { camToggle.textContent = 'CAMERA ON'; camToggle.classList.add('active'); }
          } else {
            // Simulated feed
            if (camEmpty) camEmpty.innerHTML = '<strong style="color:#22d3ee">Simulated Optical Feed</strong><small>60 FPS • Active</small>';
            if (camToggle) { camToggle.textContent = 'CAMERA ON'; camToggle.classList.add('active'); }
          }
        } catch {
          // Fallback to simulated feed
          if (camEmpty) camEmpty.innerHTML = '<strong style="color:#22d3ee">Simulated Optical Feed</strong><small>60 FPS • Active</small>';
          if (camToggle) { camToggle.textContent = 'CAMERA ON'; camToggle.classList.add('active'); }
        }
      }
    }
    camToggle?.addEventListener('click', toggleCamera);
    camBox?.addEventListener('click', toggleCamera);

    // Quick Actions
    document.querySelectorAll('.brp-quick-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const act = btn.dataset.quick;
        soundFx.playSelect();
        if (act === 'new_chat') {
          const navChat = document.querySelector('[data-view="dashboard"]');
          if (navChat) navChat.click();
        } else if (act === 'screenshot') {
          addRecentActivity('Screenshot Captured', 'Saved desktop buffer to memory');
          alert('JARVIS: Desktop screenshot captured.');
        } else if (act === 'files') {
          const navSys = document.querySelector('[data-view="system"]');
          if (navSys) navSys.click();
        } else if (act === 'browser') {
          const navWeb = document.querySelector('[data-view="web"]');
          if (navWeb) navWeb.click();
        }
      });
    });

    // Bottom Command Bar
    const cmdForm = document.getElementById('brain-command-form');
    const cmdInput = document.getElementById('brain-command-input');
    cmdForm?.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = (cmdInput?.value || '').trim();
      if (!val) return;
      soundFx.playPulse();

      // Route intent to matching subsystem
      const lower = val.toLowerCase();
      let target = 'planning';
      if (/look|see|camera|image|screen|vision/i.test(lower)) target = 'vision';
      else if (/audio|sound|listen|speak|voice|mic/i.test(lower)) target = 'audio';
      else if (/code|git|script|debug|program/i.test(lower)) target = 'coding';
      else if (/memory|remember|fact|recall/i.test(lower)) target = 'memory';
      else if (/tool|browser|search|web|find/i.test(lower)) target = 'tools';
      else if (/click|mouse|window|app|desktop/i.test(lower)) target = 'computer_use';
      else if (/translate|hindi|english|japanese|speak/i.test(lower)) target = 'language';

      selectSubsystem(target);
      addRecentActivity(`Command: "${val.slice(0, 28)}..."`, `Routed to ${SUBSYSTEMS[target].title} (${SUBSYSTEMS[target].lobeRegion})`);
      cmdInput.value = '';

      // Route through core voice/command if available
      try {
        if (typeof window.__sendJARVISCommand === 'function') {
          window.__sendJARVISCommand(val);
        }
      } catch {}
    });

    // Bottom Mic Button
    const micBtn = document.getElementById('brain-mic-btn');
    micBtn?.addEventListener('click', () => {
      soundFx.playSelect();
      const topMic = document.getElementById('voice-orb');
      if (topMic) topMic.click();
    });

    // Settings Submenu Navigation (Image 2)
    const settingsParent = document.getElementById('nav-item-settings');
    const settingsSubmenu = document.getElementById('nav-settings-submenu');
    const settingsChevron = document.getElementById('nav-settings-chevron');

    settingsParent?.addEventListener('click', (e) => {
      if (settingsSubmenu) {
        const isCollapsed = settingsSubmenu.classList.toggle('collapsed');
        if (settingsChevron) settingsChevron.style.transform = isCollapsed ? 'rotate(-90deg)' : 'rotate(0deg)';
      }
    });

    // ZIP Exporter Button in Topbar
    const zipBtn = document.getElementById('topbar-zip-btn');
    zipBtn?.addEventListener('click', async () => {
      soundFx.playChirp();
      await exportProjectZip();
    });
  }

  // ── Project ZIP Exporter ───────────────────────────────────────────────────
  async function exportProjectZip() {
    if (!window.JSZip) {
      alert('JSZip library loading. Please try again in a moment.');
      return;
    }
    try {
      const zip = new window.JSZip();

      // Bundle package.json
      zip.file('package.json', JSON.stringify({
        name: 'jarvis-holographic-neural-brain',
        version: '2.0.0',
        description: 'Interactive 3D Holographic Neural Brain Explorer for JARVIS',
        main: 'src/index.tsx',
        scripts: {
          dev: 'vite',
          build: 'vite build',
        },
        dependencies: {
          three: '^0.186.1',
          hono: '^4.13.3',
          jszip: '^3.10.1',
        }
      }, null, 2));

      // Bundle README.md
      zip.file('README.md', `# JARVIS — Interactive 3D Holographic Neural Brain Explorer

A production-grade, zoomable, interactive 3D holographic neural brain visualizer engineered for JARVIS 2.0.

## Subsystems Mapped
- **Vision**: Occipital Lobe & Visual Cortex (Gemini Lite / xKiro / NVIDIA)
- **Language**: Temporal Lobe & Broca / Wernicke Area (Groq / Gemini Lite / xKiro)
- **Memory**: Hippocampus & Limbic Core (ChromaDB + SQLite + Mem0)
- **Planning**: Prefrontal Cortex Executive Hub (Qwen / Nemotron / MiniMax)
- **Audio**: Superior Temporal Gyrus Auditory Cortex (Whisper + Piper / Edge-TTS)
- **Tools**: Parietal Lobe Manipulation Network (xKiro / OpenRouter / n8n)
- **Coding**: Left Hemisphere Angular Gyrus (Qwen / Gemini Lite / DeepSeek)
- **Computer Use**: Primary Motor Cortex & Cerebellum (Agent-S / Playwright / Bridge)

## Controls
- Drag: Orbit 3D Brain
- Scroll: Zoom in/out to inspect individual nodes & synaptic fibers
- Click Centroid or Card: Open architecture detail drawer
- Overclock / House Party: Trigger synaptic firing pulses
`);

      // Add .env.example
      zip.file('.env.example', `# JARVIS Configuration
JARVIS_GEMINI_MODEL=gemini-flash-lite-latest
JARVIS_STT_LANGUAGE=auto
JARVIS_WHISPER_MODEL=base
GROQ_API_KEY=
OPENROUTER_API_KEY=
GOOGLE_API_KEY=
NVIDIA_API_KEY=
PORT=7777
JARVIS_DATA_ROOT=D:\\JARVIS_DATA
`);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'jarvis-holographic-neural-brain.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      addRecentActivity('ZIP Export Complete', 'Downloaded jarvis-holographic-neural-brain.zip');
    } catch (err) {
      console.error('[JARVIS Brain] ZIP export failed:', err);
    }
  }

  // ── Animation Loop ─────────────────────────────────────────────────────────
  function animate() {
    cancelAnimationFrame(raf);
    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (!clock || !scene || !camera || !renderer) return;

      const time = clock.getElapsedTime();
      const speedMult = isOverclocked ? 2.4 : 1.0;

      // Explode animation interpolation
      const tgt = isExploded ? 0.75 : 0;
      explodeAmount = THREE.MathUtils.lerp(explodeAmount, tgt, 0.08);

      if (pointsMesh && originalPositions) {
        const arr = pointsMesh.geometry.attributes.position.array;
        for (let i = 0; i < originalPositions.length; i += 3) {
          const f = 1 + explodeAmount * 0.45;
          arr[i] = originalPositions[i] * f;
          arr[i + 1] = originalPositions[i + 1] * f;
          arr[i + 2] = originalPositions[i + 2] * f;
        }
        pointsMesh.geometry.attributes.position.needsUpdate = true;
      }

      // Smooth camera position lerp
      if (camera && targetCamPos) {
        camera.position.lerp(targetCamPos, 0.05);

        // Update LOD text
        const dist = camera.position.length();
        let lod = 'Overview';
        if (dist < 2.5) lod = 'Node';
        else if (dist < 3.8) lod = 'Network';
        else if (dist < 4.8) lod = 'Region';
        const lodEl = document.getElementById('brain-lod-val');
        if (lodEl && lodEl.textContent !== lod) lodEl.textContent = lod;
      } else if (camera && !targetCamPos && mouse) {
        // Holographic Spatial Depth Parallax (Anamorphic 3D perspective)
        const parallaxTargetX = (mouse.x || 0) * 0.65;
        const parallaxTargetY = 0.4 + (mouse.y || 0) * 0.5;
        camera.position.x = THREE.MathUtils.lerp(camera.position.x, parallaxTargetX, 0.05);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, parallaxTargetY, 0.05);
        camera.lookAt(0, 0, 0);
      }

      // Brain Root Rotation
      if (brainRoot) {
        if (!isDragging && isRotating) {
          brainRoot.rotation.y += 0.0035 * speedMult;
        } else {
          brainRoot.rotation.y += rotationVel.y;
          brainRoot.rotation.x += rotationVel.x;
          rotationVel.y *= 0.94;
          rotationVel.x *= 0.94;
        }
      }

      // Floor Reticle Rotation
      if (reticlesGroup) reticlesGroup.rotation.y -= 0.001 * speedMult;

      // Pulse traveling particles along fiber curves
      pulseSpheres.forEach((p) => {
        p.progress += p.speed * speedMult;
        if (p.progress > 1) p.progress = 0;
        const pt = p.curve.getPoint(p.progress);
        const f = 1 + explodeAmount * 0.45;
        p.mesh.position.set(pt.x * f, pt.y * f, pt.z * f);
        const s = 0.8 + Math.sin(time * 8 + p.progress * 10) * 0.3;
        p.mesh.scale.set(s, s, s);
      });

      // Centroid glow breathing
      centroidMeshes.forEach((m) => {
        const s = 1 + Math.sin(time * 3 + m.position.x * 2) * 0.08;
        m.scale.set(s, s, s);
      });

      renderer.render(scene, camera);
    };
    loop();
  }

  // ── Public API and Lifecycle ───────────────────────────────────────────────
  function initIfNeeded() {
    if (initialized) return;
    const ok = buildScene();
    if (!ok) {
      setTimeout(initIfNeeded, 200);
      return;
    }
    animate();
  }

  window.__JARVIS_BRAIN_HOLO__ = {
    init: initIfNeeded,
    setBrain: (brain) => {
      const lobe = String((brain && brain.lobe) || 'prefrontal_cortex').toLowerCase();
      activeLobe = LOBE_COLOR[lobe] ? lobe : 'prefrontal_cortex';
      activeColor = LOBE_COLOR[activeLobe] || DEFAULT_COLOR;
      const cap = LOBE_TO_CAP[lobe] || lobe;
      if (SUBSYSTEMS[cap]) selectSubsystem(cap, false);
    },
    setAuto: (v) => { isRotating = !!v; },
    reset: resetCamera,
    setExploded: (v) => { isExploded = !!v; },
    isReady: () => initialized,
    status: () => ({ initialized, hasRenderer: !!renderer, hasScene: !!scene, wrap: !!wrap }),
    SUBSYSTEMS,
    soundFx,
    selectSubsystem,
    exportProjectZip,
  };

  window.__brainHoloDraw = window.__JARVIS_BRAIN_HOLO__.setBrain;
  window.__JARVIS_BRAIN_SELECT__ = selectSubsystem;

  function whenReady(cb) {
    if (getThree()) cb();
    else window.addEventListener('jarvis:three-ready', cb, { once: true });
  }

  function _boot() {
    try { whenReady(initIfNeeded); } catch (e) { console.warn('[brain-holo] boot err', e); }
    let tries = 0;
    const retry = setInterval(() => {
      tries++;
      if (initialized) { clearInterval(retry); return; }
      if (tries > 50) { clearInterval(retry); return; }
      if (getThree() && !initialized) {
        try { initIfNeeded(); } catch {}
        if (initialized) clearInterval(retry);
      }
    }, 400);

    document.addEventListener('click', (e) => {
      const nav = e.target && e.target.closest && e.target.closest('[data-view="brain"]');
      if (nav) {
        setTimeout(() => { if (!initialized) initIfNeeded(); }, 120);
        setTimeout(() => {
          if (renderer && camera && wrap) {
            const r = wrap.getBoundingClientRect();
            if (r.width > 80 && r.height > 80) {
              camera.aspect = r.width / r.height;
              camera.updateProjectionMatrix();
              renderer.setSize(r.width, r.height, false);
            }
          }
        }, 350);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _boot, { once: true });
  } else {
    _boot();
  }
})();
