// Standalone repro of selectEdgeVoice() detection logic from src/index.tsx
function detectScriptLangs(text) {
  const has = (re) => re.test(text)
  const devanagari = has(/[\u0900-\u097F]/)
  const japanese = has(/[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF\uF900-\uFAFF]/)
  const latin = has(/[A-Za-z]/)
  const langs = []
  if (devanagari) langs.push('hi')
  if (japanese) langs.push('ja')
  if (latin) langs.push('en')
  return langs
}
function selectEdgeVoice(text, langHint) {
  const detected = detectScriptLangs(text)
  if (detected.length === 0) {
    const l = langHint.startsWith('ja') ? 'ja' : langHint.startsWith('hi') || langHint === 'hinglish' ? 'hi' : 'en'
    return { voice: l === 'ja' ? 'ja-JP-KeitaNeural' : l === 'hi' ? 'hi-IN-MadhurNeural' : 'en-GB-RyanNeural', rate: l === 'hi' ? '+4%' : '+0%', path: 'fallback-hint' }
  }
  if (detected.length > 1) return { voice: 'en-US-AndrewMultilingualNeural', rate: '-3%', path: 'mixed', langs: detected }
    // Pure single language → specialist male voice for the crispest accent.
  // Caveat: Latin-only text can't distinguish English from Roman-script Hinglish,
  // so let an explicit Hindi/Hinglish client language hint tip the balance to Madhur.
  let l = detected[0]
  if (l === 'en' && (langHint.startsWith('hi') || langHint === 'hinglish')) l = 'hi'
  return { voice: l === 'ja' ? 'ja-JP-KeitaNeural' : l === 'hi' ? 'hi-IN-MadhurNeural' : 'en-GB-RyanNeural', rate: l === 'ja' ? '+0%' : l === 'hi' ? '+4%' : '-5%', path: 'single', lang: l }
}
const cases = [
  ['Hello world how are you', ''],                       // pure English
  ['नमस्ते आप कैसे हैं', ''],                             // pure Hindi (Devanagari)
  ['こんにちは、元気ですか。', ''],                         // pure Japanese (kana)
  ['今日は良い天気ですね。', ''],                          // pure Japanese (kanji)
  ['नमस्ते please こんにちは', ''],                        // MIXED hindi+english+japanese ✅
  ['kal meeting 9 baje hai', 'hinglish'],                 // Roman Hinglish + hint → Madhur
  ['kal meeting 9 baje hai', ''],                         // Roman Hinglish, no hint → Ryan
  ['100% ready आज', ''],                                  // mixed numbers + hindi
  ['12345', ''],                                          // numbers only → fallback
]
for (const [t, l] of cases) {
  console.log(JSON.stringify({ text: t.slice(0, 18), hint: l || 'auto', ...selectEdgeVoice(t, l) }))
}
