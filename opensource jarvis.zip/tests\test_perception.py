"""Advanced Perception: unit + integration + permission + registry + privacy.

Every assertion runs against the SAME modules the voice core uses. Detectors
execute on a real frame - nothing is mocked.
"""
import importlib.util
import inspect
import json
import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "background"))


def _load(name):
    key = "jarvis_cowork_" + name
    ex = sys.modules.get(key)
    if ex is not None:
        return ex
    spec = importlib.util.spec_from_file_location(
        key, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


EXT = _load("extensions")
PERMS = _load("permissions")
TOOLS = _load("cowork_tools")
PERC, _err = EXT._import_plugin("perception")
PLUGIN_SRC = (ROOT / "extensions" / "plugins" / "perception" /
              "plugin.py").read_text(encoding="utf-8")


def _frame():
    import numpy as np
    return np.zeros((480, 640, 3), dtype=np.uint8)


class PluginFeatureTest(unittest.TestCase):
    """Feature registry: a REAL discoverable JARVIS feature."""

    def test_plugin_is_discovered_by_the_real_registry(self):
        self.assertIn("perception", {p["slug"] for p in EXT.plugins()})

    def test_plugin_health_imports_the_entry(self):
        report = EXT.plugin_health("perception")
        self.assertTrue(report["ok"], report.get("error"))

    def test_manifest_declares_four_tools(self):
        meta = [p for p in EXT.plugins() if p["slug"] == "perception"][0]
        self.assertEqual(sorted(meta["tools"]), [
            "perceive_attention", "perceive_faces",
            "perceive_objects", "perception_status"])

    def test_models_are_present_and_real(self):
        status = PERC.model_status()
        self.assertTrue(status["objects"]["present"], "yolov10n.onnx missing")
        self.assertTrue(status["faces"]["present"], "yunet model missing")
        self.assertGreater(status["objects"]["bytes"], 1_000_000)
        self.assertGreater(status["faces"]["bytes"], 100_000)


class ToolRegistryTest(unittest.TestCase):
    """UI feature == registered capability == agent-discoverable tool."""

    def setUp(self):
        self.registry = TOOLS.build_default_registry()
        self.result = EXT.register_plugin_tools(self.registry)

    def test_no_registration_failures(self):
        self.assertEqual(self.result["failed"], 0, self.result["errors"])
        self.assertGreaterEqual(self.result["registered"], 4)

    def test_all_four_tools_are_callable(self):
        names = [t.name for t in self.registry.list()]
        for tool in ("perceive_objects", "perceive_faces",
                     "perceive_attention", "perception_status"):
            self.assertIn("plug_perception_" + tool, names)

    def test_every_tool_has_a_real_handler(self):
        for t in self.registry.list():
            if t.name.startswith("plug_perception_"):
                self.assertTrue(callable(t.handler), t.name)

    def test_ui_advertisement_matches_the_runtime(self):
        advertised = {t["name"] for t in EXT.capabilities()["tools"]}
        runtime = {t.name for t in self.registry.list()}
        self.assertEqual(advertised, runtime)

    def test_status_tool_executes_without_a_camera(self):
        out = self.registry.execute("plug_perception_perception_status", {})
        self.assertTrue(out["ok"], out)
        self.assertIn("yolov10n.onnx", out["output"])


class DetectorTest(unittest.TestCase):
    """Real inference on a real frame."""

    def test_object_detection_returns_a_normalized_result(self):
        r = PERC.detect_objects(_frame())
        self.assertTrue(r["ok"], r.get("error"))
        self.assertEqual(r["source"], "local")
        self.assertIn("latency_ms", r)
        self.assertIsInstance(r["detections"], list)

    def test_face_detection_returns_count_and_boxes(self):
        r = PERC.detect_faces(_frame())
        self.assertTrue(r["ok"], r.get("error"))
        self.assertEqual(r["source"], "local")
        self.assertIsInstance(r["face_count"], int)
        self.assertIsInstance(r["faces"], list)

    def test_empty_frame_is_an_honest_error(self):
        r = PERC.detect_objects(None)
        self.assertFalse(r["ok"])
        self.assertIn("empty frame", r["error"])


class AttentionTest(unittest.TestCase):
    """Observable signal states ONLY - never an emotion claim."""

    def test_no_face_yields_face_not_visible(self):
        s = PERC.attention_from_faces({"ok": True, "face_count": 0, "faces": []})
        self.assertEqual(s["state"], "FACE_NOT_VISIBLE")

    def test_detector_failure_yields_unknown(self):
        self.assertEqual(
            PERC.attention_from_faces({"ok": False, "error": "x"})["state"],
            "UNKNOWN")

    def test_face_visible_yields_focused(self):
        s = PERC.attention_from_faces(
            {"ok": True, "face_count": 1,
             "faces": [{"confidence": 0.9, "box": [0, 0, 1, 1]}]})
        self.assertEqual(s["state"], "FOCUSED")
        self.assertEqual(s["signals"]["face_count"], 1)

    def test_state_is_always_one_of_four(self):
        allowed = {"FOCUSED", "POSSIBLY_DISTRACTED",
                   "FACE_NOT_VISIBLE", "UNKNOWN"}
        self.assertIn(PERC.attention_from_faces({"ok": False})["state"], allowed)
        self.assertIn(PERC.attention_from_faces(
            {"ok": True, "faces": []})["state"], allowed)

    def test_never_claims_an_emotion(self):
        blob = json.dumps(PERC.attention_from_faces(
            {"ok": True, "face_count": 1,
             "faces": [{"confidence": 0.9, "box": [0, 0, 1, 1]}]})).lower()
        for word in ("angry", "happy", "sad", "emotion", "mood",
                     "feeling", "psycholog"):
            self.assertNotIn(word, blob, word)


class PermissionTest(unittest.TestCase):
    """One permission system, reused - not a new one."""

    def setUp(self):
        self.original = PERMS.load()

    def tearDown(self):
        PERMS.save_overrides(self.original)
        PERMS.load(force=True)

    def test_camera_category_exists_and_defaults_to_ask(self):
        self.assertIn("camera", PERMS.CATEGORIES)
        self.assertEqual(PERMS.decision_for("camera"), "ask")

    def test_deny_blocks_and_cannot_be_approved_away(self):
        PERMS.save_overrides({"camera": "deny"})
        PERMS.load(force=True)
        self.assertFalse(PERMS.check("camera")["allowed"])
        self.assertFalse(PERMS.check("camera", approved=True)["allowed"])

    def test_ask_blocks_until_approved(self):
        PERMS.save_overrides({"camera": "ask"})
        PERMS.load(force=True)
        v = PERMS.check("camera")
        self.assertFalse(v["allowed"])
        self.assertTrue(v["requires_approval"])
        self.assertTrue(PERMS.check("camera", approved=True)["allowed"])

    def test_auto_allows(self):
        PERMS.save_overrides({"camera": "auto"})
        PERMS.load(force=True)
        self.assertTrue(PERMS.check("camera")["allowed"])

    def test_denied_camera_blocks_the_real_tool(self):
        PERMS.save_overrides({"camera": "deny"})
        PERMS.load(force=True)
        reg = TOOLS.build_default_registry()
        EXT.register_plugin_tools(reg)
        out = reg.execute("plug_perception_perceive_objects", {"source": "camera"})
        self.assertFalse(out["ok"])
        self.assertIn("denied", out["output"].lower())

    def test_ui_policy_matches_backend_policy(self):
        ui = {(c["category"], c["effective"]) for c in PERMS.policy()["categories"]}
        be = {(c, PERMS.decision_for(c)) for c in PERMS.CATEGORIES}
        self.assertEqual(ui, be)


class PrivacyTest(unittest.TestCase):
    """The guarantees the feature is designed around."""

    def test_no_identity_or_embedding_code(self):
        """No identity machinery. Documentation may name what we DO NOT do,
        so only executable code is scanned, never comments/docstrings."""
        import ast
        tree = ast.parse(PLUGIN_SRC)
        code = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                code.append(node.id.lower())
            elif isinstance(node, ast.Attribute):
                code.append(node.attr.lower())
            elif isinstance(node, ast.alias):
                code.append((node.name or "").lower())
        blob = " ".join(code)
        for banned in ("face_recognition", "insightface", "deepface",
                       "face_embedding", "biometric", "enroll",
                       "known_faces", "identify", "dlib"):
            self.assertNotIn(banned, blob, banned)

    def test_detector_persists_nothing(self):
        src = inspect.getsource(PERC.detect_faces)
        for banned in ("open(", "write", "save", "pickle", "sqlite", "json.dump"):
            self.assertNotIn(banned, src, banned)

    def test_results_carry_no_raw_frame(self):
        self.assertNotIn("frame", PERC.detect_objects(_frame()))

    def test_every_result_declares_local_or_cloud_source(self):
        for r in (PERC.detect_objects(_frame()), PERC.detect_faces(_frame())):
            self.assertIn(r["source"], ("local", "cloud"))

    def test_no_api_keys_in_the_plugin(self):
        for marker in ("sk-", "gsk_", "AIza", "Bearer ", "api_key"):
            self.assertNotIn(marker, PLUGIN_SRC, marker)


class FailureHandlingTest(unittest.TestCase):
    def test_unsupported_source_is_refused(self):
        frame, err = PERC.grab_frame("not-a-source", 0)
        self.assertIsNone(frame)
        self.assertIn("unsupported source", err)

    def test_screen_source_is_not_dead_code(self):
        """source="screen" must reach the real capture path and decode a frame.

        The plugin used to call screen_agent.capture_screen(), which no longer
        existed; the hasattr guard turned that into a permanent silent
        "screen capture unavailable". This locks the public entry point in
        place so the screen source cannot rot again.
        """
        import numpy as np
        SA = _load("screen_agent")
        self.assertTrue(hasattr(SA, "capture_screen"),
                        "screen_agent must expose a public capture_screen()")
        png = None
        try:
            import cv2
            png = cv2.imencode(".png", np.zeros((32, 64, 3), dtype=np.uint8))[1].tobytes()
        except Exception:
            self.skipTest("cv2 not installed")
        if png is None:
            self.skipTest("cv2 could not encode a PNG")
        real = SA.capture_screen
        SA.capture_screen = lambda: png
        try:
            frame, err = PERC.grab_frame("screen", 0)
        finally:
            SA.capture_screen = real
        self.assertEqual(err, "", err)
        self.assertIsNotNone(frame)
        self.assertEqual(tuple(frame.shape[:2]), (32, 64))

    def test_screen_capture_helper_decodes_real_bytes(self):
        """capture_screen() returns decodable PNG bytes (b64 -> bytes)."""
        import base64
        import numpy as np
        SA = _load("screen_agent")
        try:
            import cv2
            buf = cv2.imencode(".png", np.zeros((8, 8, 3), dtype=np.uint8))[1].tobytes()
        except Exception:
            self.skipTest("cv2 not installed")
        real = SA._capture_screen_png_b64
        SA._capture_screen_png_b64 = lambda: base64.b64encode(buf).decode("ascii")
        try:
            out = SA.capture_screen()
        finally:
            SA._capture_screen_png_b64 = real
        self.assertEqual(out, buf)

    def test_missing_model_is_reported_not_crashed(self):
        """Point the model dir somewhere empty and reload the real detector."""
        original = os.environ.get("JARVIS_PERCEPTION_MODELS")
        empty = ROOT / "temp" / "_no_models_probe"
        empty.mkdir(parents=True, exist_ok=True)
        os.environ["JARVIS_PERCEPTION_MODELS"] = str(empty)
        saved_dir, saved_cache, saved_err = PERC.MODEL_DIR, dict(PERC._cache), dict(PERC._errors)
        PERC.MODEL_DIR = empty
        PERC._cache.clear()
        PERC._errors.clear()
        try:
            status = PERC.model_status()
            self.assertFalse(status["objects"]["present"])
            self.assertFalse(status["faces"]["present"])
            # The detectors must report, not raise, and not silently succeed.
            self.assertFalse(PERC.detect_objects(_frame())["ok"])
            self.assertFalse(PERC.detect_faces(_frame())["ok"])
        finally:
            PERC.MODEL_DIR, PERC._cache, PERC._errors = saved_dir, saved_cache, saved_err
            if original is None:
                os.environ.pop("JARVIS_PERCEPTION_MODELS", None)
            else:
                os.environ["JARVIS_PERCEPTION_MODELS"] = original


class IntentTest(unittest.TestCase):
    """Phrasings route without hardcoding one exact sentence."""

    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location(
            "jarvis_cowork_voice_engine",
            ROOT / "background" / "voice_engine.py")
        cls.ve = importlib.util.module_from_spec(spec)
        sys.modules["jarvis_cowork_voice_engine"] = cls.ve
        spec.loader.exec_module(cls.ve)

    def test_face_phrasings(self):
        for text in ("camera mein kitne faces hain", "how many faces",
                     "count the faces", "detect faces",
                     "camera mein kitne log hain"):
            self.assertTrue(self.ve._FACES_RE.search(text), text)

    def test_attention_phrasings(self):
        for text in ("kya main screen ki taraf dekh raha hoon",
                     "am i looking at the screen", "attention",
                     "main dhyan", "am i focused"):
            self.assertTrue(self.ve._ATTENTION_RE.search(text), text)

    def test_faces_and_objects_are_separate_intents(self):
        self.assertTrue(self.ve._FACES_RE.search("camera mein kitne faces hain"))
        self.assertTrue(self.ve._CAMERA_RE.search("camera mein kya dikh raha hai"))


if __name__ == "__main__":
    unittest.main()
