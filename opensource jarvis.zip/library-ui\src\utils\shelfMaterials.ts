// Maps the core's real shelf onto the zip's MaterialItem shape.
//
// Nothing here invents content. A book only becomes a material when its text is
// on disk, and paragraphs stay empty until /library/chapter actually returns the
// chapter - so an unopened book never shows fake prose in the inspector.
import type { MaterialItem, SourceType, SkillCategory, SoftSubcategory, HardSubcategory } from '../data/archiveData';
import type { DeskBook, DeskShelf } from './jarvisDesk';

const SOFT_AISLES: { re: RegExp; to: SoftSubcategory }[] = [
  { re: /speak|communic|talk|listen|persua|write/i, to: 'COMMUNICATION' },
  { re: /mind|think|learn|intell|psych|reason/i, to: 'THINKING' },
  { re: /habit|behavio|will|discipl|charact|conduct/i, to: 'BEHAVIOUR' },
];
const HARD_AISLES: { re: RegExp; to: HardSubcategory }[] = [
  { re: /python|code|coding|program|software|engineer/i, to: 'CODING' },
  { re: /math|logic|stat|calc/i, to: 'MATH' },
  { re: /science|physic|biolog|chem/i, to: 'SCIENCE' },
  { re: /tool|git|linux|cli|devops/i, to: 'TOOLS' },
];

function humanSize(chars: number): string {
  if (!chars) return 'size unknown';
  if (chars < 1000) return `${chars} chars`;
  return `${(chars / 1000).toFixed(chars < 10000 ? 1 : 0)}k chars`;
}

export function bookToMaterial(book: DeskBook): MaterialItem {
  const link = book.kind === 'link';
  if (link) {
    // A link card is painted so the shelf shows every source he named, but it
    // holds no text: the licence says so, and the card says so on its face.
    return {
      id: `shelf-${book.slug}`,
      slug: book.slug,
      title: book.title || book.slug,
      subtitle: book.author || book.attribution || '',
      type: 'Web',
      category: book.stream === 'soft' ? 'soft' : 'hard',
      subcategory: book.stream === 'soft' ? 'LIFE' : 'TECH',
      author: book.author || book.slug,
      dateAdded: '',
      durationOrPages: 'link only',
      fileSize: 'no text stored',
      tier: 1,
      physicalLook: 'holo-screen',
      summary: book.reason || 'their licence does not allow storing the text',
      paragraphs: [],
      keyTakeaways: [],
      linkedIds: [],
      readable: false,
      url: book.url || book.source_url,
      license: book.license,
      attribution: book.attribution,
      chapterN: 1,
      chapterCount: 1,
    };
  }
  const category: SkillCategory = book.stream === 'hard' ? 'hard' : 'soft';
  const aisle = `${book.aisle || ''} ${book.title || ''}`;
  const subcategory: SoftSubcategory | HardSubcategory = category === 'hard'
    ? (HARD_AISLES.find((a) => a.re.test(aisle))?.to ?? 'TECH')
    : (SOFT_AISLES.find((a) => a.re.test(aisle))?.to ?? 'LIFE');
  const type: SourceType = book.kind === 'vendor' ? 'Course' : 'Book';
  const chapters = Array.isArray(book.chapters) ? book.chapters : [];
  return {
    id: `shelf-${book.slug}`,
    slug: book.slug,
    title: book.title || book.slug,
    subtitle: book.author ? `${book.author}` : (book.attribution || ''),
    type,
    category,
    subcategory,
    author: book.author || book.attribution || 'unattributed',
    dateAdded: book.level || '',
    durationOrPages: `${chapters.length} chapter${chapters.length === 1 ? '' : 's'}`,
    fileSize: humanSize(book.chars || 0),
    tier: category === 'hard' ? 4 : 2,
    physicalLook: type === 'Book' ? 'dark-book' : 'holo-screen',
    summary: [
      book.license || 'licence not stated',
      chapters.length === 1 && chapters[0]?.title === 'Full text'
        ? 'imported as one block: the text has no chapter headings'
        : `${chapters.length} chapters from its own headings`,
      humanSize(book.chars || 0),
    ].join('  ·  '),
    paragraphs: [],
    keyTakeaways: [],
    linkedIds: [],
    chapterN: 1,
    chapterCount: chapters.length,
    license: book.license,
    attribution: book.attribution,
  };
}

export function shelfMaterials(shelf: DeskShelf): MaterialItem[] {
  return (shelf.books || []).filter((b) => b.ok).map(bookToMaterial);
}

// The honest "what is missing" line for the shelf, straight from the core.
export function unavailableNote(shelf: DeskShelf): string {
  const list = shelf.unavailable || [];
  if (!list.length) return '';
  const first = list[0];
  return `${list.length} listed source${list.length === 1 ? '' : 's'} not on the shelf: `
    + `${(first.title || first.slug).slice(0, 48)} - ${first.reason.slice(0, 80)}`;
}
