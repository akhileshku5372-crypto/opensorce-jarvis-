"""The Skill Library shelf: what is really on disk, and the text of one chapter.

Single source of truth is skills/library/books/<slug>/ written by
scripts/import_library_books.py. Nothing here invents a book:

  - a slug only appears when meta.json + chapters.json + book.txt all parse;
  - a source from sources.json that has no local text is reported in
    `unavailable` WITH the reason, never as a volume on the shelf;
  - a chapter read is clamped to that chapter's own offsets, and the slug is
    checked against traversal before anything touches the filesystem.

`ask()` answers a question about one chapter through the Radox prose pool only -
no Groq, no Gemini - and says how much of the chapter it was allowed to read.
"""
import importlib.util
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(ROOT, "skills", "library")
BOOKS = os.path.join(LIB, "books")
SOURCES = os.path.join(LIB, "sources.json")

SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
# How much of the chapter the pool may read. My first cut to 6k chars was wrong
# for him: "lambe message ko pura nahi pad pa raha" - a long question was being
# answered from a fragment. 16k is ~8-10 pages, and the passage size is NOT what
# drives latency (measured: 12k -> 6k changed 106s to 128s, i.e. nothing), so
# there is no speed cost to reading more of the chapter.
ASK_CONTEXT_CHARS = 16000
# The pool floors every request at its own MIN_TOKENS (1200), so this number is a
# ceiling, not a budget - the word rule in SYSTEM is what sets the reply length,
# and reply length is what sets the wait.
ASK_MAX_TOKENS = 1200

SYSTEM = (
    "You are JARVIS, running a private study library for Prateek. You are given "
    "ONE chapter of ONE licensed book and a question about it.\n"
    "Answer only from the supplied passage. If the passage does not contain the "
    "answer, say which part of the chapter would, and stop - never invent book "
    "content.\n"
    "Structure: 1) what the passage actually teaches, in three or four plain "
    "sentences; 2) how Prateek uses it, as 3-5 numbered steps in his everyday "
    "words, each step concrete enough to do today; 3) one short line on what to "
    "watch out for.\n"
    "If he asks to summarise or explain the whole chapter, work through it in "
    "order and use the extra length instead of repeating one idea.\n"
    "Speak the way JARVIS speaks: calm, precise, a little dry, addresses him as "
    "'Sir'. Hinglish or English follows the question's own language. No markdown "
    "headings, no preamble, no restating the question.\n"
    # Measured on this pool: a free-length reply took 106-128s, a 90-word cap
    # took ~45s. 250 words is the compromise he asked for - full sentences, still
    # short enough to answer while he is looking at the screen.
    "LENGTH: about 200-250 words. Never pad, never repeat a point to fill space."
)


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _safe_slug(slug):
    s = str(slug or "").strip().lower()
    return s if SLUG_RE.match(s) else None


def _book_dir(slug):
    """books/<slug> only - separators, drive letters and .. are refused twice."""
    s = _safe_slug(slug)
    if not s:
        return None
    d = os.path.abspath(os.path.join(BOOKS, s))
    if not d.startswith(os.path.abspath(BOOKS) + os.sep) or not os.path.isdir(d):
        return None
    return d


def _vendor_chapter(name, number=None):
    """One markdown file out of vendor/<name>/ - the folder is the allowlist."""
    safe, d = _vendor_dir(name)
    if not safe:
        return {"ok": False, "error": "bad_slug", "reason": "not a vendor folder name"}
    if not d:
        return {"ok": False, "error": "not_found", "reason": "no such vendored repo"}
    chapters = _vendor_chapters(d)
    if not chapters:
        return {"ok": False, "error": "not_found", "reason": "that vendor folder has no README.md"}
    try:
        n = int(number or 1)
    except (TypeError, ValueError):
        n = 1
    n = min(max(n, 1), len(chapters))
    row = chapters[n - 1]
    path = os.path.abspath(os.path.join(d, row["file"]))
    if not path.startswith(d + os.sep) or not os.path.isfile(path):
        return {"ok": False, "error": "not_found", "reason": f"{row['file']} is not on disk"}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError as err:
        return {"ok": False, "error": "unreadable", "reason": str(err)[:160]}
    meta = _read_json(os.path.join(d, "meta.json")) or {}
    sources = _read_json(SOURCES) or {}
    listed = next((i for i in sources.get("vendor_text_copied", [])
                   if str(i.get("local", "")).rstrip("/\\ ").endswith(safe)), {})
    return {"ok": True, "slug": f"vendor-{safe}", "kind": "vendor", "readable": True,
            "title": _human_name(safe), "n": n,
            "chapter_title": row["title"], "chapter_count": len(chapters),
            "license": meta.get("license") or str(listed.get("license", "MIT")).split(" -")[0],
            "attribution": meta.get("url") or listed.get("repo", safe),
            "chars": len(text.strip()), "text": text.strip()}


def shelf():
    """Every real book, plus every source that could not be opened and why."""
    books = []
    listed = set()
    if os.path.isdir(BOOKS):
        for slug in sorted(os.listdir(BOOKS)):
            d = os.path.join(BOOKS, slug)
            meta = _read_json(os.path.join(d, "meta.json"))
            chapters = _read_json(os.path.join(d, "chapters.json"))
            txt = os.path.join(d, "book.txt")
            if not (isinstance(meta, dict) and isinstance(chapters, list) and chapters
                    and os.path.isfile(txt)):
                books.append({"slug": slug, "title": slug, "ok": False,
                              "reason": "folder exists but meta.json/chapters.json/book.txt "
                                        "are missing or unreadable - re-run the importer"})
                continue
            if os.path.getsize(txt) < 1000:
                books.append({"slug": slug, "title": meta.get("title", slug), "ok": False,
                              "reason": f"book.txt is only {os.path.getsize(txt)} bytes"})
                continue
            listed.add(slug)
            books.append({
                "slug": slug, "ok": True,
                "title": meta.get("title", slug),
                "author": meta.get("author", ""),
                "stream": meta.get("stream", "soft"),
                "aisle": meta.get("aisle", ""),
                "level": meta.get("level", ""),
                "license": meta.get("license", ""),
                "attribution": meta.get("attribution", ""),
                "source_url": meta.get("source_url", ""),
                "chars": meta.get("chars", 0),
                "split": meta.get("split", ""),
                "chapters": [{"n": c["n"], "title": c["title"], "chars": c["chars"]}
                             for c in chapters],
            })
    unavailable = []
    sources = _read_json(SOURCES) or {}
    for item in sources.get("books_ready_to_import", []):
        slug = item.get("slug")
        if slug in listed:
            continue
        unavailable.append({"slug": slug, "title": item.get("title", slug),
                            "stream": item.get("stream", ""),
                            "reason": "no text on disk - sources.json has no fetch URL, "
                                      "so the book was never imported"
                            if not item.get("fetch") else "listed for import but not imported yet"})
    for item in sources.get("own_files", []):
        path = os.path.join(ROOT, str(item.get("path", "")))
        if os.path.isfile(path):
            unavailable.append({"slug": item.get("path"), "title": item.get("title"),
                                "stream": item.get("stream", "hard"),
                                "reason": "file is present but the importer only reads "
                                          "plain-text books; PDFs go through doc_index/OCR"})
        else:
            unavailable.append({"slug": item.get("path"), "title": item.get("title"),
                                "stream": item.get("stream", "hard"),
                                "reason": item.get("status_note") or "file is not in the working tree"})
    links = []
    for item in sources.get("index_only_do_not_copy", []):
        repo = str(item.get("repo", "?"))
        name = repo.rstrip("/").split("/")[-1] or "link"
        url = item.get("url") or (repo if repo.startswith("http") else f"https://github.com/{repo}")
        # Every source he named shows up on the shelf. This one shows up as a LINK
        # card with its licence written on it, because that is all their licence
        # allows: readable in the browser, never copied into the library, so the
        # desk cannot quote it.
        links.append({
            "slug": f"link-{name}".lower()[:60], "ok": True, "kind": "link", "readable": False,
            "title": (item.get("title") or name.replace("-", " - "))[:70],
            "author": url.replace("https://github.com/", ""),
            "stream": item.get("stream", "hard"), "aisle": item.get("aisle", ""),
            "level": "all", "license": str(item.get("license", "no licence stated")).split(" (")[0],
            "attribution": url, "source_url": url, "url": url, "chars": 0,
            "split": "link only",
            "reason": str(item.get("store") or "topic + URL only") + f" ({item.get('license', 'no licence stated')})",
            "chapters": [{"n": 1, "title": "Open in the browser", "chars": 0}],
        })
    # Order matters for what he sees first: the imported books (English, chapter
    # split), then the vendored repos, then the link cards at the end.
    volumes = books + _vendor_books() + links
    readable = [b for b in volumes if b.get("readable", True)]
    return {"ok": True, "books": volumes, "unavailable": unavailable,
            "counts": {"live": len(readable), "listed": len(volumes),
                       "links": len(links), "unavailable": len(unavailable)}}


# The vendored MIT repos are the only hard-skill prose we legally hold until a
# hard book is imported, so they read as one-document volumes.
VENDOR = os.path.join(LIB, "vendor")


def _vendor_dir(name):
    """vendor/<name> only - the folder is the allowlist, checked twice."""
    safe = _safe_slug(name)
    if not safe:
        return None, None
    root = os.path.abspath(VENDOR)
    d = os.path.abspath(os.path.join(root, safe))
    if not d.startswith(root + os.sep) or not os.path.isdir(d):
        return safe, None
    return safe, d


def _human_name(name):
    """The card is named after the work, not after its GitHub blurb. Using the
    description as the title turned the shelf into a link dump."""
    return re.sub(r"[-_]+", " ", str(name or "")).strip().title()[:70]


def _vendor_chapters(d):
    """The markdown files this repo was vendored with, with their real sizes.

    chapters.json comes from the importer and names the file each chapter lives
    in. A recorded file that is not on disk is dropped, so the count the shelf
    shows is the count that can actually be opened.
    """
    readme = os.path.join(d, "README.md")
    if not os.path.isfile(readme):
        return []
    listed = _read_json(os.path.join(d, "chapters.json")) or []
    out = []
    for row in listed:
        fname = str(row.get("file") or "")
        path = os.path.abspath(os.path.join(d, fname))
        if not path.startswith(os.path.abspath(d) + os.sep) or not os.path.isfile(path):
            continue
        out.append({"n": len(out) + 1, "title": str(row.get("title") or fname)[:90],
                    "chars": os.path.getsize(path), "file": fname})
    if not out:
        out.append({"n": 1, "title": "README", "chars": os.path.getsize(readme),
                    "file": "README.md"})
    return out


def _vendor_books():
    out = []
    sources = _read_json(SOURCES) or {}
    by_local = {str(i.get("local", "")).strip("/\\ ").split(os.sep)[-1]: i
                for i in sources.get("vendor_text_copied", [])}
    if not os.path.isdir(VENDOR):
        return out
    for name in sorted(os.listdir(VENDOR)):
        safe, d = _vendor_dir(name)
        if not d:
            continue
        chapters = _vendor_chapters(d)
        if not chapters:
            continue
        meta = _read_json(os.path.join(d, "meta.json")) or {}
        row = by_local.get(name, {})
        out.append({
            "slug": f"vendor-{safe}", "ok": True, "kind": "vendor", "readable": True,
            "title": _human_name(safe),
            "description": str(meta.get("description") or "")[:220],
            "author": meta.get("repo") or (row.get("repo", "") or "").replace("https://github.com/", ""),
            "stream": meta.get("stream", "hard"),
            "aisle": meta.get("aisle", "software craft"), "level": "all",
            "license": meta.get("license") or str(row.get("license", "MIT")).split(" -")[0],
            "attribution": meta.get("url") or row.get("attribution") or row.get("repo", safe),
            "source_url": meta.get("url", ""),
            "chars": sum(c["chars"] for c in chapters),
            "split": "markdown files" if len(chapters) > 1 else "single document",
            "chapters": [{"n": c["n"], "title": c["title"], "chars": c["chars"]} for c in chapters],
        })
    return out


def chapter(slug, number=None):
    """One chapter's real text, clamped to the offsets the importer recorded."""
    s = _safe_slug(slug)
    if not s:
        return {"ok": False, "error": "bad_slug", "reason": "the slug is not a library folder name"}
    if s.startswith("link-"):
        # A link card has no text here by design. Say so, with the licence reason,
        # instead of pretending the chapter is empty.
        for row in (shelf().get("books") or []):
            if row.get("slug") == s and row.get("kind") == "link":
                return {"ok": False, "error": "link_only", "url": row.get("url", ""),
                        "reason": row.get("reason", "their licence does not allow storing this")}
        return {"ok": False, "error": "not_found", "reason": "no such link on the shelf"}
    if s.startswith("vendor-"):
        return _vendor_chapter(s[len("vendor-"):], number)
    d = _book_dir(s)
    if not d:
        return {"ok": False, "error": "not_found", "reason": "no such book in skills/library/books"}
    chapters = _read_json(os.path.join(d, "chapters.json")) or []
    meta = _read_json(os.path.join(d, "meta.json")) or {}
    try:
        with open(os.path.join(d, "book.txt"), "r", encoding="utf-8") as fh:
            text = fh.read()
    except OSError as err:
        return {"ok": False, "error": "unreadable", "reason": str(err)[:160]}
    if not chapters:
        return {"ok": False, "error": "no_chapters",
                "reason": "chapters.json is missing - re-run scripts/import_library_books.py"}
    try:
        n = int(number or 1)
    except (TypeError, ValueError):
        n = 1
    n = min(max(n, 1), len(chapters))
    c = chapters[n - 1]
    start = max(0, min(int(c.get("start", 0)), len(text)))
    end = max(start, min(int(c.get("end", len(text))), len(text)))
    body = text[start:end]
    return {"ok": True, "slug": s, "title": meta.get("title", s), "n": n,
            "chapter_title": c.get("title", ""), "chapter_count": len(chapters),
            "license": meta.get("license", ""), "attribution": meta.get("attribution", ""),
            "chars": len(body.strip()), "text": body.strip()}


def _window(body, question):
    """The part of a long chapter the question is actually about.

    'kewal utna hi padho jitna main pucha hoon' - so a 300k-char chapter is never
    dumped into the prompt. Keyword hits pick the paragraph window; with no hits
    the opening is used and the caller is told that is what happened.
    """
    if len(body) <= ASK_CONTEXT_CHARS:
        return body, "full chapter"
    terms = [t for t in re.split(r"[^\w]+", (question or "").lower()) if len(t) > 3][:12]
    paras = [p for p in re.split(r"\n\s*\n", body) if len(p.strip()) > 120]
    if terms and paras:
        # Score every paragraph on all question terms, keep the best ones in order.
        scored = sorted(range(len(paras)),
                        key=lambda i: -sum(paras[i].lower().count(t) for t in terms))
        best = sorted(scored[:8])
        out, used = [], 0
        for i in best:
            p = paras[i].strip()
            if used + len(p) > ASK_CONTEXT_CHARS:
                break
            out.append(p)
            used += len(p)
        if out:
            return "\n\n[...]\n\n".join(out), f"{used} chars from {len(paras)} paragraphs, chosen by your question"
    return body[:ASK_CONTEXT_CHARS], f"first {ASK_CONTEXT_CHARS} chars (the question had no words to match on)"


def _load_sibling(name):
    """Import a background module by path, or None. Same pattern deep_research uses,
    so the prose pool resolves whether this file is loaded as a module or run from
    a test - the core reaches us through _load_bg, which does not put background/
    on sys.path."""
    key = "jarvis_library_" + name
    cached = sys.modules.get(key)
    if cached is not None:
        return cached
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), name + ".py")
        spec = importlib.util.spec_from_file_location(key, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[key] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        sys.modules.pop(key, None)
        return None


def ask(slug, number, question):
    """Answer a question about one real chapter, on the Radox pool only."""
    q = str(question or "").strip()
    if len(q) < 3:
        return {"ok": False, "error": "empty_question", "reason": "nothing was asked"}
    got = chapter(slug, number)
    if not got.get("ok"):
        return got
    window, how = _window(got["text"], q)
    prompt = (f"BOOK: {got['title']} ({got['license']})\n"
              f"CHAPTER {got['n']}: {got['chapter_title']}\n"
              f"PASSAGE ({how} of {got['chars']} chapter chars):\n{window}\n\n"
              f"PRATEEK ASKS: {q}\n")
    radox = _load_sibling("radox_writer")
    if radox is None:
        return {"ok": False, "error": "radox_missing",
                "reason": "background/radox_writer.py could not be imported"}
    if not radox.available():
        return {"ok": False, "error": "radox_unavailable",
                "reason": "no RADOX_API_KEY configured - Groq and Gemini are not allowed for this desk"}
    text, meta = radox.write(prompt, system=SYSTEM, max_tokens=ASK_MAX_TOKENS, timeout=120)
    if not text:
        return {"ok": False, "error": "radox_failed", "reason": (meta.get("error") or "no key answered")[:200],
                "attempts": meta.get("attempts", [])}
    return {"ok": True, "answer": text.strip(), "engine": "Radox",
            "model": meta.get("model", ""), "ms": meta.get("ms", 0),
            "context": how, "chapter": {"slug": got["slug"], "n": got["n"],
                                         "title": got["chapter_title"], "chars": got["chars"]},
            "attribution": got.get("attribution", "")}


def speak(text, lang="en", max_segments=8):
    """Read a passage with the existing edge-tts service - never a cloud TTS key.

    The service at 7782 refuses more than 600 characters per request (its own
    guard), so a long passage is cut at sentence boundaries and the MP3 segments
    are concatenated. That is how a whole chapter page becomes one continuous
    clip instead of a 400 Bad Request.
    """
    import urllib.request
    body_text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not body_text:
        return {"ok": False, "error": "nothing_to_read", "reason": "the passage was empty"}
    parts = []
    rest = body_text[:max_segments * 560]
    while rest:
        head, tail = rest[:560], rest[560:]
        if tail:
            cut = max(head.rfind(". "), head.rfind("! "), head.rfind("? "), head.rfind("; "))
            if cut > 180:
                head, tail = head[:cut + 1], rest[cut + 1:].lstrip()
        parts.append(head.strip())
        rest = tail
    clips = []
    for part in parts:
        req = urllib.request.Request(
            "http://127.0.0.1:7782/tts",
            data=json.dumps({"text": part, "lang": lang}).encode(),
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=90) as res:
                clips.append(res.read())
        except Exception as err:  # noqa: BLE001 - the caller only needs the reason
            return {"ok": False, "error": "edge_tts_unavailable", "reason": str(err)[:200]}
    audio = b"".join(clips)
    return {"ok": True, "audio": audio, "voice": "", "status": 200,
            "segments": len(clips), "bytes": len(audio)}
