"""Phase 4.3 (free path) - Google Calendar via a private iCal feed, no OAuth.

Why this exists
---------------
The first version of this integration used the Google Calendar REST API with an
OAuth Desktop client. That path is free (no bank account, no billing), but it
asks the owner to open the Google Cloud console, create a project, enable APIs
and paste four credentials - a lot of ceremony for "what is on today?".

A calendar has a much older, completely free and OAuth-free door: the **private
iCal feed**. Google Calendar exposes a secret per-calendar ICS URL in
Settings -> Integrate calendar, Outlook/Apple/Thunderbird can import the same
format, and any app can export a plain `.ics` file. So:

* a feed URL or a local `.ics` file is the only thing this module needs;
* the feed URL is a bearer secret (anyone with it can read your calendar), so it
  is stored through :mod:`dpapi_store` - Windows DPAPI, never plaintext;
* reading is the only capability. There is no create/update/delete code path, so
  "JARVIS cannot change your calendar" is a missing capability, not a promise.

Where to get the URL (free, no billing, no bank account)
-------------------------------------------------------
Google Calendar -> gear icon -> "Integrate calendar" -> "Secret address in iCal
format" -> copy. Put it in `.env` as `JARVIS_CALENDAR_ICS_URL=...` or hand it to
JARVIS with "calendar connect <url>". Any exported `.ics` file also works via
`JARVIS_CALENDAR_ICS_FILE`.

Honesty rules
-------------
* No feed configured => "not connected yet", never "0 events".
* An unreachable or malformed feed reports the reason (HTTP status, parse error,
  unknown timezone) instead of returning an empty day.
* Recurring events are expanded for the queried window and labelled
  `recurring: true`, because a weekly standup that silently vanishes from the
  agenda is a lie of omission.
* An all-day event is spoken as all-day, not as midnight.
"""

from __future__ import annotations

import datetime as _dt
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

try:
    import dpapi_store as _dpapi
    import storage_paths as _paths
except ImportError:                                  # pragma: no cover
    from background import dpapi_store as _dpapi
    from background import storage_paths as _paths

FEED_URL_ENV = "JARVIS_CALENDAR_ICS_URL"
FEED_FILE_ENV = "JARVIS_CALENDAR_ICS_FILE"
TIMEOUT = 20.0
CACHE_TTL = 60.0                     # a voice question must not refetch per word
MAX_EVENTS = 25
MAX_ICS_BYTES = 8 * 1024 * 1024
_cache = {"at": 0.0, "text": "", "source": ""}


# ── configuration ──────────────────────────────────────────────────────────

def token_path():
    return _paths.jarvis_apps_dir() / "calendar_feed.url"


def _env_url() -> str:
    return (os.environ.get(FEED_URL_ENV) or "").strip()


def _env_file() -> str:
    return (os.environ.get(FEED_FILE_ENV) or "").strip()


def configured() -> bool:
    return bool(feed_url() or feed_file())


def feed_url() -> str:
    """The stored feed URL, falling back to the env var.

    The stored copy is DPAPI-encrypted; the env var is read only because an owner
    may prefer to keep the secret in their own env file.
    """
    stored = _dpapi.load(token_path())
    if isinstance(stored, dict) and stored.get("url"):
        return str(stored["url"]).strip()
    return _env_url()


def feed_file() -> str:
    return _env_file()


def connect(url: str) -> dict:
    """Store a feed URL (encrypted) or an .ics file path. Read-only forever."""
    url = str(url or "").strip()
    if not url:
        return {"ok": False,
                "error": "no URL given - Google Calendar -> Integrate calendar "
                         "-> secret iCal address, or an .ics file path"}
    if not url.lower().startswith(("http://", "https://", "webcal://")):
        # Not a feed URL, so it must be a local .ics path. The scheme check has
        # to come FIRST: plenty of real feed URLs also end in ".ics".
        path = Path(url)
        if not url.lower().endswith(".ics"):
            return {"ok": False, "error": "not an http(s)/webcal feed URL and "
                                         "not a .ics file path"}
        if not path.is_file():
            return {"ok": False, "error": "no such .ics file: %s" % path}
        os.environ[FEED_FILE_ENV] = str(path.resolve())
        return {"ok": True, "kind": "file", "path": str(path.resolve()),
                "note": "stored for this session; put %s in .env to make it "
                        "permanent" % FEED_FILE_ENV}
    saved = _dpapi.save(token_path(), {"url": url, "stored": time.time()})
    if not saved["ok"]:
        return {"ok": False, "error": "could not store the feed URL: %s"
                % saved["error"]}
    return {"ok": True, "kind": "url", "encrypted": True,
            "note": "stored DPAPI-encrypted at %s" % saved["path"]}


def disconnect() -> dict:
    """Forget the stored feed URL. Nothing is deleted from Google."""
    return {"ok": _dpapi.clear(token_path()), "path": str(token_path()),
            "note": "local copy removed; the Google feed itself is unchanged"}


def missing_reason() -> str:
    if not configured():
        return ("no calendar feed configured - Google Calendar -> gear icon -> "
                "Integrate calendar -> copy the secret iCal address, then say "
                "\"calendar connect <url>\" (no OAuth, no billing, no bank "
                "account), or point %s / %s at an .ics file"
                % (FEED_URL_ENV, FEED_FILE_ENV))
    return ""


# ── fetching ───────────────────────────────────────────────────────────────

def _read_source() -> dict:
    """ICS text from the .ics file or the feed URL, with an honest error."""
    path = _env_file()
    if path:
        target = Path(path)
        try:
            size = target.stat().st_size
        except OSError as exc:
            return {"ok": False, "error": "cannot read %s: %s" % (path, exc)}
        if size > MAX_ICS_BYTES:
            return {"ok": False, "error": "%s is too large (%d KB)"
                    % (path, size // 1024)}
        try:
            return {"ok": True, "text": target.read_text(encoding="utf-8",
                                                         errors="replace"),
                    "source": str(target)}
        except OSError as exc:
            return {"ok": False, "error": "cannot read %s: %s" % (path, exc)}
    url = feed_url()
    if not url:
        return {"ok": False, "error": missing_reason()}
    fetch = url.replace("webcal://", "https://", 1)
    request = urllib.request.Request(fetch, headers={
        "User-Agent": "JARVIS/0.10 (local calendar read-only)",
        "Accept": "text/calendar",
    })
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read(MAX_ICS_BYTES + 1)
    except urllib.error.HTTPError as exc:
        return {"ok": False, "status": exc.code,
                "error": "the calendar feed answered HTTP %s%s"
                % (exc.code, " - Google private feeds need a working internet "
                             "connection" if exc.code else "")}
    except Exception as exc:
        return {"ok": False,
                "error": "%s: %s" % (type(exc).__name__, exc)}
    if len(raw) > MAX_ICS_BYTES:
        return {"ok": False, "error": "feed larger than %d MB"
                % (MAX_ICS_BYTES // (1024 * 1024))}
    return {"ok": True, "text": raw.decode("utf-8", errors="replace"),
            "source": "feed"}


def ics_text(force: bool = False) -> dict:
    """Cached ICS text for the configured source."""
    now = time.time()
    if (not force and _cache["text"]
            and now - _cache["at"] < CACHE_TTL):
        # A cache hit may only be served while a source still exists: if the
        # owner removed the feed, answering from a stale cache would look like a
        # working calendar that no longer exists.
        if configured():
            return {"ok": True, "text": _cache["text"],
                    "source": _cache["source"], "cached": True}
        _cache.update({"at": 0.0, "text": "", "source": ""})
    out = _read_source()
    if out.get("ok"):
        _cache.update({"at": now, "text": out["text"],
                       "source": out.get("source", "")})
    return out


# ── parsing ────────────────────────────────────────────────────────────────
_PROP_RE = re.compile(r"^(?P<name>[A-Za-z-]+)(?P<params>(?:;[^:]*)?):(?P<value>.*)$")


def _unfold(text: str) -> list:
    """RFC 5545 line unfolding: a leading space/tab continues the previous line."""
    lines = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if raw[:1] in (" ", "\t") and lines:
            lines[-1] += raw[1:]
        else:
            lines.append(raw)
    return lines


def _parse_params(params: str) -> dict:
    out = {}
    for chunk in params.split(";"):
        if not chunk:
            continue
        key, _, value = chunk.partition("=")
        out[key.strip().upper()] = value.strip().strip('"')
    return out


def _tz(name: str):
    """ZoneInfo for a TZID, or None when the zone is unknown on this machine."""
    if not name:
        return None
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:
        return None


def _parse_dt(value: str, params: dict) -> tuple:
    """(datetime|None, is_date_only, tz_known)."""
    if not value:
        return None, False, True
    if params.get("VALUE", "").upper() == "DATE":
        try:
            return _dt.datetime.strptime(value[:8], "%Y%m%d"), True, True
        except ValueError:
            return None, False, False
    tz_known = True
    tzinfo = None
    if value.endswith("Z"):
        value = value[:-1]
        tzinfo = _dt.timezone.utc
    else:
        tz = _tz(params.get("TZID", ""))
        if tz is not None:
            tzinfo = tz
        elif params.get("TZID"):
            # Unknown zone: keep the wall-clock time as local and say so.
            tz_known = False
    try:
        stamp = _dt.datetime.strptime(value, "%Y%m%dT%H%M%S")
    except ValueError:
        try:
            stamp = _dt.datetime.strptime(value, "%Y%m%dT%H%M")
        except ValueError:
            return None, False, False
    return stamp.replace(tzinfo=tzinfo), False, tz_known


def _unescape(value: str) -> str:
    return (value.replace("\\n", " ").replace("\\N", " ")
            .replace("\\,", ",").replace("\\;", ";")
            .replace("\\\\", "\\"))


def _duration_iso(value: str) -> float:
    """DURATION -> seconds (P1DT2H30M style)."""
    match = re.match(r"^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$",
                      value or "")
    if not match:
        return 0.0
    days, hours, minutes, seconds = (float(g or 0) for g in match.groups())
    return days * 86400 + hours * 3600 + minutes * 60 + seconds


def _expand_rrule(rule: str, start: _dt.datetime, window_end: _dt.datetime,
                  limit: int = 60) -> list:
    """Expand simple DAILY/WEEKLY/MONTHLY rules inside the window.

    Deliberately small: anything exotic (BYDAY, BYMONTHDAY, COUNT/UNTIL combos)
    is not guessed at - the event keeps its first occurrence and is flagged so the
    answer can say the feed holds rules this parser does not expand.
    """
    parts = {}
    for chunk in (rule or "").split(";"):
        key, _, value = chunk.partition("=")
        if key:
            parts[key.strip().upper()] = value.strip()
    freq = parts.get("FREQ", "").upper()
    try:
        interval = max(1, int(parts.get("INTERVAL", "1")))
    except ValueError:
        interval = 1
    if freq not in ("DAILY", "WEEKLY", "MONTHLY"):
        return [start]
    # Compare on ONE timeline. astimezone() on a NAIVE stamp assumes local time
    # and returns an aware one, which is exactly what a floating DTSTART (no
    # TZID, no Z) means - mixing the two raised "offset-naive vs offset-aware".
    cursor = start.astimezone()
    horizon = window_end.astimezone()
    stamps = []
    guard = 0
    while cursor <= horizon and len(stamps) < limit and guard < 2000:
        guard += 1
        # Append the occurrence we are standing on BEFORE advancing, otherwise
        # the first (original) occurrence is dropped and a daily standup looks
        # like it starts tomorrow.
        stamps.append(cursor)
        if freq == "DAILY":
            cursor = cursor + _dt.timedelta(days=interval)
        elif freq == "WEEKLY":
            cursor = cursor + _dt.timedelta(weeks=interval)
        else:
            month = cursor.month + interval
            year = cursor.year + (month - 1) // 12
            month = (month - 1) % 12 + 1
            day = min(cursor.day, [31, 29 if year % 4 == 0 and (year % 100 != 0
                         or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31,
                         30, 31, 30, 31][month - 1])
            cursor = cursor.replace(year=year, month=month, day=day)
    return stamps


def parse_events(text: str) -> list:
    """Every VEVENT in the feed as a dict. Raises nothing; bad lines are skipped."""
    events = []
    current = None
    for line in _unfold(text or ""):
        match = _PROP_RE.match(line)
        if not match:
            continue
        name = match.group("name").upper()
        params = _parse_params(match.group("params"))
        value = match.group("value")
        if name == "BEGIN" and value.upper() == "VEVENT":
            current = {"summary": "", "location": "", "rrule": "",
                       "status": "", "tz_unknown": False}
            continue
        if current is None:
            continue
        if name == "END" and value.upper() == "VEVENT":
            if current.get("start"):
                events.append(current)
            current = None
            continue
        if name == "SUMMARY":
            current["summary"] = _unescape(value)
        elif name == "LOCATION":
            current["location"] = _unescape(value)
        elif name == "STATUS":
            current["status"] = value.upper()
        elif name == "RRULE":
            current["rrule"] = value
        elif name == "EXDATE":
            current.setdefault("exdates", []).append(value)
        elif name in ("DTSTART", "DTEND"):
            stamp, date_only, tz_known = _parse_dt(value, params)
            if stamp is None:
                continue
            if not tz_known:
                current["tz_unknown"] = True
            if name == "DTSTART":
                current["start"] = stamp
                current["all_day"] = date_only
            else:
                current["end"] = stamp
        elif name == "DURATION":
            current["duration_s"] = _duration_iso(value)
    return events


def _localise(stamp, tz_unknown: bool):
    if stamp.tzinfo is None:
        return stamp.astimezone()
    return stamp.astimezone()


def _label(stamp, all_day: bool) -> str:
    local = _localise(stamp, False)
    today = _dt.date.today()
    if all_day:
        if local.date() == today:
            return "aaj poora din"
        if local.date() == today + _dt.timedelta(days=1):
            return "kal poora din"
        return local.strftime("%d %b poora din")
    clock = local.strftime("%I:%M %p").lstrip("0")
    if local.date() == today:
        return "aaj %s" % clock
    if local.date() == today + _dt.timedelta(days=1):
        return "kal %s" % clock
    # Dates beyond tomorrow keep the day+month. (A "%s" placeholder passed to
    # strftime then %-formatted raised ValueError - only reachable for events
    # more than a day out, which is why the E2E caught it and the unit tests,
    # which only ever used today/tomorrow, did not.)
    return local.strftime("%d %b %I:%M %p").lstrip("0")


def events_in_window(start: _dt.datetime, end: _dt.datetime,
                     limit: int = MAX_EVENTS) -> dict:
    """Events overlapping [start, end), recurring ones expanded."""
    source = ics_text()
    if not source.get("ok"):
        return {"ok": False, "error": source.get("error", "feed unavailable"),
                "status": source.get("status", 0)}
    try:
        parsed = parse_events(source["text"])
    except Exception as exc:                        # pragma: no cover
        return {"ok": False, "error": "could not parse the feed: %s: %s"
                % (type(exc).__name__, exc)}
    if not parsed:
        return {"ok": False,
                "error": "the feed contains no events (empty calendar, or the "
                         "URL is not an ICS feed)"}
    rows = []
    tz_unknown = False
    window_end = end.astimezone() + _dt.timedelta(days=1)
    for event in parsed:
        base = event["start"]
        stamps = _expand_rrule(event.get("rrule", ""), base, window_end) \
            if event.get("rrule") else [base]
        for stamp in stamps:
            if stamp.tzinfo is not None:
                stamp_local = stamp.astimezone()
            else:
                stamp_local = stamp.astimezone()
            end_stamp = event.get("end")
            if end_stamp is None and event.get("duration_s"):
                end_stamp = stamp + _dt.timedelta(seconds=event["duration_s"])
            if stamp_local >= end.astimezone() or (
                    end_stamp and end_stamp.astimezone() <= start.astimezone()):
                continue
            if event.get("status") == "CANCELLED":
                continue
            if event.get("tz_unknown"):
                tz_unknown = True
            rows.append({
                "summary": event.get("summary") or "(no title)",
                "when": _label(stamp, event.get("all_day", False)),
                "until": ("" if event.get("all_day")
                          else _localise(end_stamp, False).strftime(
                              "%I:%M %p").lstrip("0") if end_stamp else ""),
                "start": stamp_local.isoformat(),
                "all_day": bool(event.get("all_day")),
                "location": event.get("location", ""),
                "recurring": bool(event.get("rrule")),
            })
    rows.sort(key=lambda r: r["start"])
    rows = rows[:int(limit)]
    note = ""
    if tz_unknown:
        note = ("some events carry a timezone this machine does not know; their "
                "wall-clock time was used as-is")
    return {"ok": True, "count": len(rows), "results": rows, "source":
            source.get("source", ""), "note": note}


# ── public reads ───────────────────────────────────────────────────────────

def today_agenda(limit: int = MAX_EVENTS) -> dict:
    """Everything from local midnight to local midnight, in local time."""
    now = _dt.datetime.now().astimezone()
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return events_in_window(start, start + _dt.timedelta(days=1), limit)


def upcoming(n: int = 5) -> dict:
    """The next `n` events from now (60-day horizon)."""
    try:
        n = max(1, min(int(n or 5), MAX_EVENTS))
    except (TypeError, ValueError):
        n = 5
    now = _dt.datetime.now().astimezone()
    return events_in_window(now, now + _dt.timedelta(days=60), n)


def status() -> dict:
    """Honest state for the capability card and GET /calendar/status (offline)."""
    url, path = feed_url(), feed_file()
    info = {
        "configured": bool(url or path),
        "kind": "ics_file" if path else ("ics_url" if url else ""),
        "read_only": True,
        "oauth": False,
        "path": str(token_path()),
        "dpapi": _dpapi.available(),
        "env": [FEED_URL_ENV, FEED_FILE_ENV],
    }
    reason = missing_reason()
    if reason:
        info["reason"] = reason
    stored = _dpapi.load(token_path())
    if isinstance(stored, dict) and stored.get("url"):
        info["stored_encrypted"] = True
        info["stored_at"] = stored.get("stored", 0)
    err = _dpapi.last_error()
    if err:
        info["error"] = err
    return info


# ── spoken answers ─────────────────────────────────────────────────────────

def spoken_today(out: dict) -> str:
    if not out.get("ok"):
        return ("Calendar nahi padh saka: %s" % out.get("error", "unknown error"))
    rows = out.get("results") or []
    if not rows:
        return "Sir, aaj ka calendar khaali hai, koi event nahi."
    parts = ["Sir, aaj %d event%s hain:" % (len(rows), "" if len(rows) == 1
                                             else "s")]
    for idx, row in enumerate(rows, 1):
        if row.get("all_day"):
            line = "%d. %s (poora din)" % (idx, row.get("summary"))
        else:
            line = "%d. %s - %s" % (idx, row.get("when", ""),
                                    row.get("summary", ""))
            if row.get("until"):
                line += " se %s" % row["until"]
        if row.get("location"):
            line += ", %s" % row["location"]
        parts.append(line)
    if out.get("note"):
        parts.append(out["note"])
    return " ".join(parts) + "."


def spoken_upcoming(out: dict) -> str:
    if not out.get("ok"):
        return "Agenda nahi mila: %s" % out.get("error", "unknown error")
    rows = out.get("results") or []
    if not rows:
        return "Sir, aage koi scheduled event nahi hai."
    parts = ["Sir, aage %d event%s:" % (len(rows), "" if len(rows) == 1
                                         else "s")]
    for idx, row in enumerate(rows, 1):
        parts.append("%d. %s, %s" % (idx, row.get("when", ""),
                                     row.get("summary", "")))
    if out.get("note"):
        parts.append(out["note"])
    return " ".join(parts) + "."


def spoken_status(info: dict) -> str:
    if not info.get("configured"):
        return ("Sir, calendar feed set nahi hai. %s"
                % info.get("reason", "Google Calendar se iCal link copy kijiye."))
    return ("Sir, calendar feed set hai (%s), read-only, bina OAuth ke."
            % ("ics file" if info.get("kind") == "ics_file" else "private URL"))


# ── registry tool wrappers (real ToolRegistry, see plugin.py) ──────────────

def _tool_calendar_status(args=None):
    return status()


def _tool_calendar_today(args=None):
    return today_agenda()


def _tool_calendar_upcoming(args=None):
    args = args or {}
    return upcoming(args.get("n", 5))


def _tool_calendar_connect(args=None):
    args = args or {}
    return connect(args.get("url") or args.get("path") or "")


def _tool_calendar_disconnect(args=None):
    return disconnect()