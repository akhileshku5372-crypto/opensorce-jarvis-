# Free research access — collect list (direct links + what each one needs)

Checklist file. Tick as you collect. **Aapke do repos ka verdict §1 mein hai, UI integration
ka jawab §6 mein.**

Legend: `—` = kuch nahi chahiye (keyless) · `signup` = free account + key · `install` = pip/docker
· `paid-now` = pehle free tha, ab nahi.

## 0. AAPKE SIRF 4 KAAM (aasan version — baaki sab main karunga)

Aapko **kuch install nahi karna**. Bas ye 4 websites kholni hain, ek-ek key copy karni hai. Har
key 2 minute ka kaam hai. Sab free hain, card manga jaaye toh Skip kar dena.

| # | Link kholo | Wahan kya karna hai | Kya copy karna hai |
|---|---|---|---|
| 1 | https://www.tavily.com | "Sign up" → free plan → dashboard mein **API Keys** | `tvly-…` se shuru hone wali key |
| 2 | https://exa.ai | "Sign up" → dashboard → **API Key** | lambi hex/alphanumeric key |
| 3 | https://serper.dev | email se sign up → **API Keys** tab | `xxxx…` key (2,500 free queries) |
| 4 | https://core.ac.uk | "Register" → free account → Settings → **API token** | CORE token |

Skip karne wale (aapki marzi, zaroori nahi): https://www.semanticscholar.org/product/api
("Request an API key" — isse 429 error theek hota hai) · https://github.com/settings/tokens
("Generate token", **koi checkbox mat bharo**, bas Generate — rate limit badh jaayega).

### Key mujhe kaise deni hai — 2 tarike

**Tarika A (sabse aasan):** chat mein hi paste kar do, ek line mein ek key, label ke saath —

```
tavily: tvly-abcdef123456
exa: 8f2c...
serper: a91b...
core: sk_core_...
```

Main inhe `C:\Users\PRATEEK\Desktop\jarvis-2.0\.dev.vars` mein daal dunga. Wo file git-managed
nahi hai (`.gitignore` mein hai), toh key repo/GitHub par nahi jaayegi.

**Tarika B (key kisi ko dikhana nahi):** Notepad se wo file khud kholo —
`C:\Users\PRATEEK\Desktop\jarvis-2.0\.dev.vars` — aur bilkul niche ye lines add kar do
(braacket mat bharo, sirf value):

```
TAVILY_API_KEY=
EXA_API_KEY=
SERPER_API_KEY=
CORE_API_KEY=
SEMANTIC_SCHOLAR_API_KEY=
```

Save karo, phir mujhe bolo **"daal diya"** — main verify kar lunga ki kaunsi key live jawab de
rahi hai kaunsi nahi.

### Jo cheezein aapko deni HI nahi hain

13 sources bina kisi key ke kaam karte hain (OpenAlex, Crossref, Unpaywall, Wikipedia, HN,
StackExchange, GitHub, World Bank, Wayback CDX, Common Crawl CDX, Europe PMC, arXiv,
r.jina.ai) — main **aaj hi unpe kaam shuru kar sakta hoon**, keys ka intezaar nahi karna.
`pip install trafilatura ddgs` bhi main kar lunga.

## 0.1 "Toh in 4 keys se mera Jarvis ban jayega?" — **NAHI.** Ye sach hai

Keys is kaam ka **~1%** hain. Wo sirf "Google result laane wali nal" hain, aur un par bhi
ceiling hai (1,000/month). **30-50× depth keys se nahi aati, 7 code modules se aati hai — jo
abhi JARVIS mein hain hi nahi:**

| Jo cheez depth deti hai | Kaun banayega | Key chahiye? |
|---|---|---|
| Local fetch + extract (1,000 pages, **zero quota**) | **main** (`pip install trafilatura`) | ❌ |
| Provider bus (13 keyless + 4 keyed sources, ek jaisa interface) | **main** | ❌ (13 bina key ke) |
| Dedup (1,000 URL → ~250 asli fact) | **main** | ❌ |
| Claim store (SQLite — pages context mein nahi, claims jaate hain) | **main** | ❌ |
| Cross-check + critic loop (CROSS-CHECKED / SINGLE SOURCE / DISPUTED) | **main** | ❌ |
| Tier controller (T0 LOOKUP … T4 SWEEP, prompt ke anusaar) | **main** | ❌ |
| Resumable run manifest (T4 = 2-8 ghante, restart pe mar nahi) | **main** | ❌ |
| Google-rank wale results (kabhi-kabhi) | aap | ✅ Tavily/Exa/Serper |
| Paywalled paper ka legal OA PDF | aap | ✅ CORE/Unpaywall(email) |
| The console UI (already designed) | **main** | ❌ |

**Matlab: ek bhi key na do, toh bhi T2 DEEP aur T3 EXHAUSTIVE chal sakte hain** — 13 keyless
sources verified hain. Keys sirf T1 ke "Google ranking" wale hisse aur kuch full-text PDFs ke
liye hain. **Optional hain, zaroori nahi.**

Aur ek imaandar hadd: T4 "poora internet" = **2-8 ghante ka background job** (aapka CPU laptop +
free LLM rate limits). Paisa nahi lagega, waqt lagega — isliye wo chat turn nahi, raat bhar chalne
wala resumable task hai.


## 0.2 Chat ke wo 20+ "Sources" links kya the

Wo **mere research ke citations** hain — jahan se maine 2026 ke live quota numbers nikale
(Tavily 1,000/mo, Brave ab free nahi, CDX ~60 req/min, OpenAlex 100k/day). **Aapko unmein se
kuch nahi karna** — wo proof hain, kaam nahi. Kaam ki list sirf §0 (aapke 4 kaam) aur §0.1
(mere 7 modules) hai.

## 1. Verdict on the two repos you named


### `public-apis/public-apis` — catalog, not code
It is a curated README table of ~1,400 free/public APIs (Animals → Weather). **There is no
runtime to install** — nothing to integrate. Its real value for JARVIS: it is the *index* you
browse to find a vertical you did not know existed. Useful sections for deep research:
**Open Data, Weather, Science & Data, Government, News, Video, Cryptocurrency, Geocoding.**
→ https://github.com/public-apis/public-apis
Verdict: **bookmark it, don't clone it.** The concrete APIs worth wiring from it are already
listed in §2 below (World Bank, USGS, Open-Meteo, EDGAR, GDELT…).

### `patchy631/ai-engineering-hub` — ~54 tutorial folders, 5 worth reading
Most folders are walkthroughs tied to a **paid vendor** (BrightData, GroundX, Firecrawl cloud,
AssemblyAI, Milvus Cloud) — those do not help a zero-budget build. The ones genuinely worth
reading for JARVIS:

| Folder | Why it matters to you |
|---|---|
| `Multi-Agent-deep-researcher-mcp-windows-linux` | A multi-agent deep researcher that runs **on Windows** and exposes itself as MCP — closest thing in that repo to your Co-work target |
| `corrective-rag` | The "retrieve → grade the retrieval → re-query" loop = your missing **critic loop** |
| `trustworthy-rag` | Citation grounding + refusal when evidence is thin = your claim-card / UNCITED logic |
| `context-engineering-pipeline` + `context-engineering-workflow` | How to compress many docs into a reasoning-ready brief = your **claim store** idea |
| `web-browsing-agent` | Agent that browses instead of searching — compare against your `screen_agent.py` |

Also skim: `colbert-rag`, `modernbert-rag` (retrieval models — **CPU-heavy, skip on your
laptop**), `rag-with-dockling` (IBM document parser, good for messy PDFs), `ai_news_generator`
(GDELT-style news pipeline), `github-rag`, `document-chat-rag`.
→ https://github.com/patchy631/ai-engineering-hub
Verdict: **read 5 folders, install none.** Nothing there replaces the tier architecture — it is
reference code, not a dependency.

## 2. Group A — keyless, works today, zero signup (this is where "unlimited" comes from)

Test each in a browser right now; they return JSON.

| # | Source | Direct access | Limit | Buys you |
|---|---|---|---|---|
| 1 | **OpenAlex** | `https://api.openalex.org/works?search=YOUR+TOPIC&per-page=25&mailto=you@mail.com` | ~100,000/day, no key | 250M+ papers + **citation edges** → snowball depth |
| 2 | Crossref | `https://api.crossref.org/works?query=YOUR+TOPIC&rows=20&mailto=you@mail.com` | polite pool, no key | DOI, exact dates, funder, license = fact-check layer |
| 3 | Semantic Scholar | `https://api.semanticscholar.org/graph/v1/paper/search?query=TOPIC&fields=title,year,citationCount,abstract` | shared pool — **measured 429 from here**, key required in practice | TLDRs + graph |
| 4 | **Unpaywall** | `https://api.unpaywall.org/v2/DOI?email=you@mail.com` | 100k/day, email only | legal open-access PDF for paywalled DOIs |
| 5 | arXiv | `https://export.arxiv.org/api/query?search_query=all:TOPIC&max_results=50` (**https**; `http://` 301s) | ~1 req/3 s | preprints (full text) |
| 6 | Europe PMC | `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=TOPIC&format=json` | no key | bio/med full text |
| 7 | PubMed | `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=TOPIC&retmode=json` | 3/s (10/s with key) | indexed literature |
| 8 | **GDELT DOC 2.0** | `https://api.gdeltproject.org/api/v2/doc/doc?query=TOPIC&mode=artlist&format=json&maxrecords=75` | no key, **but 429s on bursts** — measured; space calls ≥30 s + backoff | global news, 15-min refresh, **timeline sweeps** |
| 9 | Wikipedia | `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=TOPIC&format=json` | no key, generous | tertiary overview + references to chase |
| 10 | Wikidata | `https://www.wikidata.org/wiki/Special:EntityData/Q42.json` | no key | structured facts (dates, orgs, people) |
| 11 | Hacker News | `https://hn.algolia.com/api/v1/search?query=TOPIC` | no key | practitioner consensus + primary links |
| 12 | StackExchange | `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=votes&q=TOPIC&site=stackoverflow` | 300/day keyless | how-to truth |
| 13 | GitHub | `https://api.github.com/search/repositories?q=TOPIC&per_page=20` | 10/min keyless, 5k/hr with token | code that already solved it |
| 14 | World Bank | `https://api.worldbank.org/v2/country/IN/indicator/NY.GDP.MKTP.CD?format=json` | no key | hard numbers |
| 15 | Open-Meteo | `https://api.open-meteo.com/v1/forecast?latitude=28.6&longitude=77.2&daily=temperature_2m_max` | no key | weather/climate data |
| 16 | USGS | `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&limit=20` | no key | quake/hazard data |
| 17 | **SEC EDGAR** | full-text UI https://www.sec.gov/edgar/search/ · JSON `https://data.sec.gov/submissions/CIK0000320193.json` (needs User-Agent) | ~10 req/s | company filings — primary sources |
| 18 | **Wayback CDX** | `https://web.archive.org/cdx/search/cdx?url=example.com&output=json&limit=10` | ~60 req/min | every past version of a URL (deleted pages too) |
| 19 | **Common Crawl CDX** | `https://index.commoncrawl.org/CC-MAIN-2025-33-index?url=example.com&output=json` | no key | "what did this site look like" + bulk URL discovery |
| 20 | Internet Archive | `https://archive.org/advancedsearch.php?q=TOPIC&output=json` | no key | books, audio, scans, gov docs |
| 21 | **Jina Reader (keyless)** | `https://r.jina.ai/https://any.url/here` | low rate without key | any URL → clean markdown, free |
| 22 | **ddgs** (python) | https://github.com/deedy5/ddgs | soft rate limits | keyless web+news+images search |
| 23 | Marginalia | https://search.marginalia.nu/ | no API — polite HTML | the indie/small web Google hides |

**21 of these 23 need nothing from you.** That is the "unlimited" layer — no key, no card, no
1,000/month ceiling.

### Measured just now from this machine (2026-10-19, `curl`, same interpreter network)

| Result | Endpoints |
|---|---|
| **200 + real JSON (13)** | OpenAlex 25 KB · Crossref · Unpaywall · HN Algolia · Wikipedia · World Bank · Wayback CDX · Common Crawl CDX · StackExchange · GitHub · Europe PMC · **r.jina.ai** (markdown back, no key) · arXiv (over **https** — `http://` 301s) |
| **429 even after 20 s spacing (2)** | **Semantic Scholar** — the shared unauthenticated pool is saturated from here → collect the free key (§3.5), do not build on the keyless path · **GDELT DOC 2.0** — throttles bursts; needs ≥30 s spacing + retry/backoff, so treat it as a *slow sweep* provider, not an interactive one |

So the honest count is **13 of 15 keyless sources verified working from your laptop right now**,
not 23 — the rest of §2 (Wikidata, USGS, Open-Meteo, EDGAR, Archive.org, ddgs, Marginalia) is
listed but **not yet probed**. Probe before wiring; do not trust this table as proof.

## 3. Group B — free signup keys (collect these 6, in this order)

| # | Service | Where to sign up | Free you get | Worth it because |
|---|---|---|---|---|
| 1 | **Tavily** | https://www.tavily.com/ → Get API key | 1,000 credits/mo | best LLM-tuned snippets + `extract`; the one true Firecrawl replacement |
| 2 | **Exa** | https://exa.ai/ → dashboard | ~1,000 req/mo + $5 | neural/link-graph search — finds "the 3 pages that actually answer this" |
| 3 | **Serper** | https://serper.dev/ | 2,500 queries (one-time) | real Google SERP when ranking genuinely matters |
| 4 | **CORE** | https://core.ac.uk/services/api | free key raises rate | 250M+ open-access **full texts** |
| 5 | **Semantic Scholar key** | https://www.semanticscholar.org/product/api | higher shared rate | graph walking without 429s |
| 6 | **GitHub PAT (classic, no scopes)** | https://github.com/settings/tokens | 5k/hr search, code search 30/min | code-vertical research |
| 7 | *(optional)* FRED | https://fred.stlouisfed.org/docs/api/fred/ | free key | US economic series |
| 8 | *(optional)* NASA | https://api.nasa.gov/ | free key | APOD/earth data |
| ⚠ | ~~Brave Search~~ | https://brave.com/search/api/ | **no longer free** ($5 credit) since Feb 2026 | do not build on it |
| ⚠ | ~~Firecrawl keys ×3~~ | already have | **all HTTP 402** | credits are per-account, not per-key |

## 4. Group C — install / self-host (no key, no quota)

| # | What | How | Why it matters |
|---|---|---|---|
| 1 | **trafilatura** | `pip install trafilatura` | the local HTML→text engine. **This single line removes the Firecrawl dependency** |
| 2 | **ddgs** | `pip install ddgs` | keyless search provider |
| 3 | **Crawl4AI** | `pip install crawl4ai` (needs playwright browsers) | JS-heavy pages → markdown; heavier, use as fallback |
| 4 | **SearXNG (self-hosted)** | Docker or bare python → https://searxng.org · https://github.com/searxng/searxng | 264 engines, JSON out, **no quota at all** — the real backbone |
| 5 | Firecrawl **OSS** | https://github.com/firecrawl/firecrawl (Docker) | same API you already coded against, self-hosted — but it still needs search-engine creds inside |
| 6 | faster-whisper | already in this repo | any video/podcast → text, CPU int8 |
| 7 | PyMuPDF + `ocr_engine.py` | already in this repo | PDFs/scans → text |

Your laptop: 15.3 GB, CPU-only. Items 1-3 run fine. **4 (SearXNG) runs in Docker — if Docker
Desktop is not installed, use public instances + ddgs instead, and skip 5** (Firecrawl OSS wants
Elasticsearch + Redis + workers; that is too heavy for this machine).

## 5. Group D — the 7 pieces JARVIS itself must have (this is the "kya chahiye" list)

1. **Depth controller** — pick tier T0…T4 from the sentence; show `est_sources · est_minutes`
   before starting.
2. **Provider bus** — one interface `search(query, budget) → rows[]`, every §2/§3 source behind
   it, each with its own quota counter, backoff, and an honest `ok:false` fail row.
3. **Local fetch+extract pool** — 8 workers, 1 req/s per host, robots-aware, Wayback fallback.
4. **Dedup** — URL canonicalise + MinHash near-dup + host cluster (1,000 URLs → ~250 facts).
5. **Claim store** — SQLite rows `{claim, subject, value, date, quote_span, url, http_status,
   fetched_at, host, lang}` + Chroma embeddings. **Pages never enter the LLM context.**
6. **Critic loop** — score claims by independent hosts + domain diversity + recency; uncovered
   sub-questions generate new queries; research tools exempt from `LOOP_SIGNATURE_LIMIT`.
7. **Resumable run manifest** — T3/T4 are hours; a PM2 restart must resume, not kill.

## 6. Will all of this show up in the console UI I designed? **Yes — here is the exact mapping**

| Capability from §2-§5 | Where it appears in that HTML console |
|---|---|
| Tier controller (§5.1) | **new chip row** under the title: `LOOKUP · SEARCH · DEEP · EXHAUSTIVE · SWEEP`, each labelled with `est sources · est minutes` |
| Provider bus (§5.2) | the single `firecrawl · 1 of 3 keys` chip **becomes the whole left SOURCES panel header + a new PROVIDERS list**: one row per provider = `quota used/max · ok · fail · backoff · needs_key` |
| Local fetch pool (§5.3) | **EVIDENCE ledger** rows — `host · ok/402/404 · bytes · ms · via live\|wayback\|cc` |
| Dedup (§5.4) | SOURCES counts become *distinct* facts, with a `collapsed n→m` note so the number is honest |
| Claim store (§5.5) | **ANSWER claim cards** — text + citation chips `[1][3]`; the confidence dots become a computed value |
| Cross-check scoring (§5.6) | badge per claim: `CROSS-CHECKED (n≥2)` cyan · `SINGLE SOURCE` amber · `DISPUTED` red · `UNCITED` red; footer strip `VERIFIED n/m` |
| Verticals (scholar/news/gov/code) | **new tab strip** above SOURCES: `ALL · SCHOLARLY · NEWS · GOV/NUMBERS · CODE · COMMUNITY · ARCHIVES` — each tab is a provider group |
| Resumable T3/T4 (§5.7) | footer `resumable` badge + `elapsed / ETA`, and a **STOP that keeps the ledger** |
| Transcripts + PDFs (§4.6-4.7) | PAGE PREVIEW thumbnails gain a `VIDEO` / `PDF` / `SCAN` kind badge |
| Follow-up chips | stay real commands — they re-enter the same tier controller, so "Verify claims" runs a T2 against the existing claim store instead of starting over |

What must change in the data contract for all of that:
`STATE.research_run = {tier, est_sources, est_minutes, providers[], sources_ok, sources_fail,
claims_total, cross_checked, single_source, disputed, collapsed_urls, elapsed_s, eta_s,
resume_token, vertical}` — plus per-source rows inside it. The console renders whatever exists
and shows an honest empty state when it does not (rule already in `WEB_RESEARCH_UI_SPEC.md`).

## 7. Collect order (do these 6 things and you are unblocked)

- [ ] `pip install trafilatura ddgs` — no account, kills the 402 wall
- [ ] Tavily key (1,000/mo)
- [ ] Exa key (1,000/mo + $5)
- [ ] Serper key (2,500 one-time)
- [ ] CORE key + Semantic Scholar key (both free, full-text + graph)
- [ ] GitHub PAT (no scopes needed, just for rate limit)
- [ ] *(optional, if Docker exists)* SearXNG self-host → true unlimited SERP
- [ ] Nothing else to collect: all 23 sources in §2 need **zero** signup

Then tell me and I build in this order: **§5.3 local fetch → §5.2 provider bus → §5.5 claim
store → §5.6 critic loop → §5.1 tiers → §5.7 resume → console wiring.** First two steps are
what make the difference visible.
