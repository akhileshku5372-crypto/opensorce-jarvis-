"""Agent routing upgrades: write-content synthesis + conversational fallback.

STEP 1 (the Notepad bug): "open notepad and write a code of simple calculator"
used to pass the request's own words as the file content. The planner wrapper
must now synthesize real code first, keep genuine content untouched, and fail
honestly (no junk write) when generation returns nothing.

STEP 2: chat-shaped input must bypass the tool loop and answer directly, while
file/machine/app intents must still reach the real tools.

Stdlib + fakes only: no network, no LLM, no app launch, no browser.
"""
import importlib.util
import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


_load("cortex")                     # publish jarvis_cowork_cortex first
_load("os_executor")
ENGINE = _load("voice_engine")
OSEXEC = _load("os_executor")

CALC_CODE = ("def add(a, b):\n"
             "    return a + b\n\n\n"
             "def main():\n"
             "    print('2+3 =', add(2, 3))\n\n\n"
             "if __name__ == '__main__':\n"
             "    main()")


class RestatementDetectionTest(unittest.TestCase):
    def test_request_wording_is_flagged_for_synthesis(self):
        for goal, content in (
            ("write a code of simple calculator", "code of simple calculator"),
            ("create a program for a calculator", "a program for a calculator"),
            ("os write file with the code of calculator", "the code of calculator"),
            ("likho ek essay on climate", "an essay on climate"),
        ):
            self.assertTrue(ENGINE._content_needs_synthesis(goal, content),
                            "%r / %r" % (goal, content))

    def test_empty_content_is_flagged(self):
        self.assertTrue(ENGINE._content_needs_synthesis(
            "write a calculator program", ""))

    def test_real_content_is_never_replaced(self):
        for goal, content in (
            ("write hello into artifacts/notes.txt", "hello"),
            ("append 'meeting at 5' to the log file", "meeting at 5"),
            ("create a calculator program in artifacts/calc.py", CALC_CODE),
            ("add a line of code to the parser", "return a + b\n"),
        ):
            self.assertFalse(ENGINE._content_needs_synthesis(goal, content),
                             "%r / %r" % (goal, content[:40]))

    def test_no_artifact_intent_means_no_synthesis(self):
        self.assertFalse(ENGINE._content_needs_synthesis(
            "read package.json", "package.json"))

    def test_subject_strips_the_request_wording(self):
        self.assertEqual(
            ENGINE._synthesis_subject("write a code of simple calculator",
                                      "code of simple calculator"),
            "simple calculator")
        self.assertTrue(ENGINE._synthesis_subject("likho essay on X", ""))


class PlannerSynthesisTest(unittest.TestCase):
    """The planner wrapper must synthesize BEFORE the write tool executes."""

    def setUp(self):
        self._real_raw = ENGINE._brain_raw
        self.addCleanup(lambda: setattr(ENGINE, "_brain_raw", self._real_raw))

    @staticmethod
    def _planner_json(path, content):
        return ('{"tool": "os_write_file", "args": {"path": "%s", '
                '"content": "%s"}}' % (path, content))

    def test_restated_write_becomes_real_code_on_disk(self):
        seen = []

        def fake_raw(text, ui):
            seen.append(text)
            if "co-work planner" in text:
                return self._planner_json("artifacts/synthesis-probe.py",
                                          "code of simple calculator")
            return "```python\n" + CALC_CODE + "\n```"

        ENGINE._brain_raw = fake_raw
        action = ENGINE._cortex_planner(
            "write a code of simple calculator into artifacts/synthesis-probe.py",
            "catalog", [], "")
        self.assertEqual(action["tool"], "os_write_file")
        content = action["args"]["content"]
        self.assertNotIn("code of simple calculator", content)
        self.assertNotIn("```", content)
        self.assertIn("def add", content)
        target = ROOT / "artifacts" / "synthesis-probe.py"
        try:
            got = OSEXEC.tool_write_file({"path": "artifacts/synthesis-probe.py",
                                          "content": content})
            self.assertTrue(got["ok"], got)
            self.assertIn("def add", target.read_text(encoding="utf-8"))
        finally:
            if target.exists():
                target.unlink()
        self.assertTrue(any("simple calculator" in line and
                            "complete, working code" in line for line in seen))

    def test_genuine_content_passes_through_with_one_call(self):
        calls = []

        def fake_raw(text, ui):
            calls.append(text)
            return self._planner_json("artifacts/plain.txt", "hello")

        ENGINE._brain_raw = fake_raw
        action = ENGINE._cortex_planner("write hello into artifacts/plain.txt",
                                        "catalog", [], "")
        self.assertEqual(action["args"]["content"], "hello")
        self.assertEqual(len(calls), 1, "no synthesis call for real content")

    def test_failed_generation_finishes_honestly_and_writes_nothing(self):
        def fake_raw(text, ui):
            if "co-work planner" in text:
                return self._planner_json("artifacts/never.py",
                                          "code of a calculator")
            return "   "

        ENGINE._brain_raw = fake_raw
        action = ENGINE._cortex_planner(
            "write a code of a calculator into artifacts/never.py",
            "catalog", [], "")
        self.assertTrue(action.get("done"), action)
        self.assertIn("generate nahi ho paya", action["answer"])
        self.assertFalse((ROOT / "artifacts" / "never.py").exists())

    def test_done_actions_are_untouched(self):
        def fake_raw(text, ui):
            return '{"done": true, "answer": "Sir, hello."}'

        ENGINE._brain_raw = fake_raw
        action = ENGINE._cortex_planner("hello", "catalog", [], "")
        self.assertTrue(action.get("done"))

    def test_voice_write_route_asks_for_the_real_code(self):
        with mock.patch.object(ENGINE, "brain",
                               return_value="```python\n" + CALC_CODE + "\n```") as stub:
            body, _note = ENGINE._expand_writing_request(
                True, "a code of simple calculator", "http://127.0.0.1:7777")
        prompt = stub.call_args[0][0]
        self.assertIn("simple calculator", prompt)
        self.assertNotIn("code of simple calculator", prompt)
        self.assertIn("def add", body)
        self.assertNotIn("```", body)


class ChatRoutingTest(unittest.TestCase):
    CHAT = ["hello", "how are you doing sir", "kaise ho", "tell me a joke",
            "explain recursion in simple words", "who is Ada Lovelace",
            "kya aap german bol sakte ho", "what is the meaning of entropy"]
    TASKS = ["open notepad", "write a python script that prints hello",
             "read package.json", "list my skills", "what time is it",
             "how much disk space is left", "open spotify",
             "mcp call echo.echo", "search for jarvis in background"]

    def test_chat_shaped_input_is_conversational(self):
        for text in self.CHAT:
            self.assertTrue(ENGINE._is_conversational(text), text)

    def test_tool_intents_are_not_conversational(self):
        for text in self.TASKS:
            self.assertFalse(ENGINE._is_conversational(text), text)

    def test_reply_is_direct_recorded_and_no_run_is_started(self):
        with mock.patch.object(ENGINE, "brain", return_value="Hello Sir, main hoon."):
            reply = ENGINE._conversational_reply("hello")
        self.assertEqual(reply, "Hello Sir, main hoon.")
        rows = ENGINE.get_state()["activity"]
        self.assertTrue(any(row["role"] == "agent" and "main hoon" in row["text"]
                            for row in rows))
        self.assertEqual(ENGINE.get_state()["status"], "idle")
        self.assertNotEqual((ENGINE.get_state().get("cortex") or {}).get("status"),
                            "running")

    def test_brain_failure_still_returns_an_honest_line(self):
        with mock.patch.object(ENGINE, "brain", return_value=""):
            self.assertTrue(ENGINE._conversational_reply("hello"))


class FileToolsTest(unittest.TestCase):
    def test_find_files_matches_real_repo_files(self):
        got = OSEXEC.tool_find_files({"pattern": "voice_engine.py",
                                      "path": "background"})
        self.assertTrue(got["ok"], got)
        self.assertIn("background/voice_engine.py", got["output"])

    def test_find_files_refuses_paths_outside_the_repo(self):
        self.assertFalse(OSEXEC.tool_find_files({"pattern": "*", "path": ".."})["ok"])
        self.assertFalse(OSEXEC.tool_find_files({"pattern": "*", "path": ".env"})["ok"])

    def test_open_file_refuses_script_suffixes_that_would_execute(self):
        refused = OSEXEC.tool_open_file({"path": "public/static/app.js"})
        self.assertFalse(refused["ok"])
        self.assertIn("band hai", refused["output"])

    def test_open_file_refuses_outside_repo_and_missing_files(self):
        self.assertFalse(OSEXEC.tool_open_file({"path": "../package.json"})["ok"])
        self.assertFalse(OSEXEC.tool_open_file({"path": "nope.txt"})["ok"])

    def test_open_file_uses_the_repo_path_with_no_argv(self):
        with mock.patch.object(OSEXEC.os, "startfile", create=True) as start:
            got = OSEXEC.tool_open_file({"path": "README.md"})
        self.assertTrue(got["ok"], got)
        start.assert_called_once_with(str(ROOT / "README.md"))

    def test_executor_gating_set(self):
        gated = {s.name for s in OSEXEC.specs() if s.requires_confirmation}
        self.assertEqual(gated, {"os_write_file", "os_run_command", "os_open_file"})


class VoiceWriteRouteTest(unittest.TestCase):
    """"open notepad and write a code of simple calculator" - the live bug."""

    def setUp(self):
        self.spoken = []

        class FakeAgent:
            def __init__(self):
                self.task = None
                self.body = None

            def screen_task(self, task, ui=None, lang="en", gated=False, body=None):
                self.task = str(task or "")
                self.body = body
                return "TYPED"

            def has_pending(self):
                return False

        self.agent = FakeAgent()
        self._real_speak = ENGINE.speak
        self._real_agent = ENGINE._screen_agent
        self.engine = ENGINE
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)), True)[1]
        ENGINE._screen_agent = lambda: self.agent
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real_speak
        ENGINE._screen_agent = self._real_agent

    def test_voice_route_types_real_code_not_the_request_words(self):
        with mock.patch.object(ENGINE, "brain",
                               return_value="```python\n" + CALC_CODE + "\n```"):
            with ENGINE._recent_lock:
                ENGINE._recent.clear()
            with ENGINE._action_stamps_lock:
                ENGINE._action_stamps.clear()
            handled = ENGINE.run_command(
                "open notepad and write a code of simple calculator",
                "http://127.0.0.1:7777", "http://127.0.0.1:7778", "typed")
        self.assertTrue(handled)
        self.assertIn("notepad", (self.agent.task or "").lower())
        self.assertIsNotNone(self.agent.body, "no content was generated for the app")
        self.assertIn("def add", self.agent.body)
        self.assertNotIn("code of simple calculator", self.agent.body)
        self.assertNotIn("```", self.agent.body)


class AppIndexRouteTest(unittest.TestCase):
    """Voice launch: bridge first, then the real index, never a wrong app."""

    def setUp(self):
        index_mod = sys.modules.get("app_index") or _load("app_index")
        self.index = index_mod
        with index_mod._cache["lock"]:
            index_mod._cache["rows"] = [
                {"name": "KMPlayer", "kind": "lnk", "target": r"C:\Start\KMPlayer.lnk",
                 "source": "start-menu"}]
            index_mod._cache["at"] = 9e9
        self.spoken = []
        self._real_speak = ENGINE.speak
        self._real_bridge = ENGINE.bridge_command
        ENGINE.speak = lambda message, ui=None: (self.spoken.append(str(message)), True)[1]
        ENGINE.bridge_command = lambda command, bridge, source="voice": None
        ENGINE._app_index_mod = index_mod
        ENGINE._app_index_failed = False
        self.addCleanup(self._restore)

    def _restore(self):
        ENGINE.speak = self._real_speak
        ENGINE.bridge_command = self._real_bridge

    def test_installed_app_is_launched_from_the_index(self):
        with mock.patch.object(self.index, "_startfile") as start:
            handled = ENGINE._try_index_launch("kmplayer", self.spoken.append)
        self.assertTrue(handled)
        start.assert_called_once_with(r"C:\Start\KMPlayer.lnk")
        self.assertIn("KMPlayer", self.spoken[0])

    def test_unknown_app_is_refused_and_nothing_launches(self):
        with mock.patch.object(self.index, "_startfile") as start:
            handled = ENGINE._try_index_launch("zzzzqq", self.spoken.append)
        self.assertFalse(handled, "a total miss must let the caller speak")
        start.assert_not_called()
        self.assertEqual(self.spoken, [])

    def test_long_or_wordy_input_never_reaches_the_index(self):
        with mock.patch.object(self.index, "_startfile") as start:
            self.assertFalse(ENGINE._try_index_launch(
                "the quick brown fox jumps over it", self.spoken.append))
        start.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)

