"""Phase 5 tests: armour asset honesty, Code Red route, bundle integrity.

Run:  node run_py.cjs -m unittest discover -s tests -p test_armour_codered.py

The point of these tests is honesty, not rendering: a 3D viewport that pretends
to show a model it does not have is exactly the kind of lie this repo refuses, so
the asset lister, the Code Red voice route and the served bundle are all pinned.
"""

from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "background"))

import armour_assets                                      # noqa: E402


def _load_module(key: str, path: Path):
    spec = importlib.util.spec_from_file_location(key, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[key] = mod
    spec.loader.exec_module(mod)
    return mod


class ArmourAssetTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="jarvis-armour-")
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        patcher = patch.dict(os.environ,
                             {"JARVIS_3D_MODELS": str(self.folder)})
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_empty_folder_reports_zero_not_a_sample(self):
        out = armour_assets.status()
        self.assertEqual(out["count"], 0)
        self.assertEqual(out["models"], [])
        self.assertIn("placeholder geometry", out["note"])

    def test_only_real_glb_files_are_listed(self):
        (self.folder / "mark85.glb").write_bytes(b"glTF-binary-bytes")
        (self.folder / "notes.txt").write_text("not a model", encoding="utf-8")
        (self.folder / "scene.gltf").write_text('{"asset":{}}', encoding="utf-8")
        rows = armour_assets.list_models()
        self.assertEqual([r["name"] for r in rows], ["mark85.glb", "scene.gltf"])
        self.assertEqual(rows[0]["bytes"], len(b"glTF-binary-bytes"))
        self.assertEqual(rows[0]["ext"], ".glb")

    def test_zero_byte_file_is_not_a_model(self):
        (self.folder / "empty.glb").write_bytes(b"")
        self.assertEqual(armour_assets.list_models(), [])

    def test_resolve_rejects_traversal_and_foreign_extensions(self):
        (self.folder / "ok.glb").write_bytes(b"data")
        (self.folder.parent / "secret.txt").write_text("no", encoding="utf-8")
        self.assertIsNotNone(armour_assets.resolve("ok.glb"))
        for bad in ("../secret.txt", "..\\secret.txt", "sub/ok.glb",
                    "C:\\Windows\\System32\\drivers\\etc\\hosts",
                    "ok.glb\x00.txt", "", "ok.exe", "nope.glb"):
            self.assertIsNone(armour_assets.resolve(bad), bad)

    def test_content_types_match_the_extension(self):
        self.assertEqual(armour_assets.content_type(Path("a.glb")),
                         "model/gltf-binary")
        self.assertEqual(armour_assets.content_type(Path("a.gltf")),
                         "model/gltf+json")

    def test_env_override_is_honoured(self):
        self.assertEqual(armour_assets.models_dir(), self.folder)


class BundleIntegrityTests(unittest.TestCase):
    def test_armour_bundle_has_a_loader_and_orb_controls(self):
        bundle = ROOT / "public" / "static" / "armour-bundle.js"
        self.assertTrue(bundle.is_file(), "run node scripts/build-armour-bundle.cjs")
        text = bundle.read_text(encoding="utf-8", errors="ignore")
        for needle in ("GLTFLoader", "OrbitControls", "JARVIS_ARMOUR_THREE"):
            self.assertIn(needle, text)

    def test_viewer_consumes_shared_gesture_landmarks(self):
        view = (ROOT / "public" / "static" / "armour-view.js").read_text(
            encoding="utf-8")
        # It must NOT start its own camera/MediaPipe pipeline.
        self.assertIn("__JARVIS_HANDS__", view)
        self.assertNotIn("getUserMedia", view)
        self.assertNotIn("new Hands(", view)

    def test_viewer_labels_placeholder_geometry(self):
        view = (ROOT / "public" / "static" / "armour-view.js").read_text(
            encoding="utf-8")
        self.assertIn("placeholder", view)


class CodeRedRouteTests(unittest.TestCase):
    """The real voice route inside the real dispatcher."""

    @classmethod
    def setUpClass(cls):
        cls.voice = _load_module("voice_engine_codered",
                                 ROOT / "background" / "voice_engine.py")

    def setUp(self):
        self.voice.set_state(battle_mode=False, battle_since=0.0, open_view="")

    def _say(self, text):
        said = []
        handled = self.voice._codered_route(text, text, said.append)
        return handled, said[0] if said else ""

    def test_code_red_flips_the_battle_state(self):
        handled, reply = self._say("initiate code red")
        self.assertTrue(handled)
        self.assertTrue(self.voice.STATE["battle_mode"])
        self.assertGreater(self.voice.STATE["battle_since"], 0)
        self.assertIn("Code Red active", reply)

    def test_code_red_promise_is_honest_about_destructive_actions(self):
        self._say("code red")
        reply = self.voice.get_state()
        self.assertTrue(reply["battle_mode"])
        # The spoken line must NOT claim apps were closed.
        _, said = self._say("battle mode status")
        self.assertIn("seconds se", said)

    def test_stand_down_turns_it_off(self):
        self._say("code red on")
        handled, reply = self._say("stand down")
        self.assertTrue(handled)
        self.assertFalse(self.voice.STATE["battle_mode"])
        self.assertEqual(self.voice.STATE["battle_since"], 0.0)
        self.assertIn("off", reply.lower())

    def test_stand_down_when_already_off_is_honest(self):
        _, reply = self._say("stand down")
        self.assertIn("pehle se band", reply)

    def test_unrelated_sentence_is_not_stolen(self):
        handled, _ = self._say("play a song")
        self.assertFalse(handled)

    def test_armour_request_asks_the_dashboard_to_open_the_view(self):
        handled, reply = self._say("open the armour studio")
        self.assertTrue(handled)
        self.assertEqual(self.voice.STATE["open_view"], "armour")
        self.assertIn("Armour Studio", reply)

    def test_repeating_the_same_view_request_still_asks_for_it(self):
        self._say("open the armour studio")
        first = self.voice.STATE["open_view_seq"]
        self._say("open the armour studio again")
        self.assertEqual(self.voice.STATE["open_view_seq"], first + 1)

    def test_armour_reply_names_the_missing_asset_honestly(self):
        with patch.dict(os.environ, {"JARVIS_3D_MODELS": str(ROOT / "artifacts" / "3d")}):
            self.voice._ARMOUR_MOD = None
            _, reply = self._say("armour studio kholo")
        self.assertIn("placeholder geometry", reply)


class CapabilityProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "background"))
        cls.registry = _load_module("capability_registry_probe",
                                    ROOT / "background" / "capability_registry.py")

    def test_armour_card_is_blocked_until_a_real_model_exists(self):
        # Owner decision: no model asset => BLOCKED (there is nothing to show),
        # with the exact folder that flips it named in the reason.
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"JARVIS_3D_MODELS": tmp}):
                verdict = self.registry._probe_armour_studio()
        self.assertEqual(verdict["state"], "BLOCKED")
        self.assertIn(".glb/.gltf", verdict["reason"])

    def test_armour_card_goes_live_with_a_real_model_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "mark85.glb").write_bytes(b"glTF")
            with patch.dict(os.environ, {"JARVIS_3D_MODELS": tmp}):
                verdict = self.registry._probe_armour_studio()
        self.assertEqual(verdict["state"], "LIVE")
        self.assertIn("1 real model file", verdict["reason"])

    def test_code_red_card_is_live_and_says_it_is_not_destructive(self):
        verdict = self.registry._probe_code_red()
        self.assertEqual(verdict["state"], "LIVE")
        self.assertFalse(verdict["evidence"]["destructive"])


if __name__ == "__main__":
    unittest.main()