"""The Radox writer pool: rotation, honest failure, and keys kept off argv.

No network: subprocess.run is faked, and the env loader is stubbed.
"""
import importlib.util
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def _load(name):
    spec = importlib.util.spec_from_file_location(
        name, ROOT / "background" / (name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


rw = _load("radox_writer")

KEYS = ["cc_one", "cc_two", "cc_three", "cc_four"]


def _ok(content, finish="stop", tokens=800):
    return json.dumps({"choices": [{"finish_reason": finish,
                                    "message": {"content": content}}],
                       "usage": {"total_tokens": tokens}})


class FakeProc:
    def __init__(self, stdout, rc=0, stderr=""):
        self.stdout, self.returncode, self.stderr = stdout, rc, stderr


class WriterTest(unittest.TestCase):
    def setUp(self):
        self._env = rw._env
        rw._env = lambda name, default="": {
            "RADOX_API_KEY": KEYS[0], "RADOX_API_KEY_2": KEYS[1],
            "RADOX_API_KEY_3": KEYS[2], "RADOX_API_KEY_4": KEYS[3],
            "RADOX_BASE_URL": "https://radox.test/v1", "RADOX_MODEL": "m-test",
        }.get(name, default)
        rw._STATE.update({"next": 0, "fails": {}, "parked": {}})

    def tearDown(self):
        rw._env = self._env
        rw._STATE.update({"next": 0, "fails": {}, "parked": {}})

    def test_the_key_never_appears_in_the_command_line(self):
        seen = {}

        def fake_run(argv, input=None, **kw):
            seen["argv"] = argv
            seen["stdin"] = input
            return FakeProc(_ok("Solid prose here, long enough to pass."))
        with patch.object(rw.subprocess, "run", fake_run):
            text, meta = rw.write("write something")
        self.assertTrue(text.startswith("Solid prose"))
        self.assertEqual(seen["argv"], ["curl", "--config", "-"],
                         "the key must travel on stdin, not in argv")
        self.assertIn("cc_", seen["stdin"])
        self.assertNotIn("max_tokens", seen["argv"])

    @staticmethod
    def _budget_of(cfg):
        """Pull max_tokens back out of the curl config (data is double-encoded)."""
        for line in cfg.splitlines():
            if line.startswith("data = "):
                payload = json.loads(line[len("data = "):])
                return int(json.loads(payload)["max_tokens"])
        return 0

    def test_a_reasoning_truncated_reply_retries_the_same_key_with_more_budget(self):
        answers = [_ok("", finish="length", tokens=30), _ok("Same key answered after escalation.")]
        seen = []

        def fake_run(argv, input=None, **kw):
            seen.append(input)
            return FakeProc(answers[len(seen) - 1])
        with patch.object(rw.subprocess, "run", fake_run):
            text, meta = rw.write("write something")
        self.assertIn("Same key answered", text)
        self.assertEqual(meta["slot"], 1, "content=null from length is not a dead key")
        self.assertGreater(self._budget_of(seen[1]), self._budget_of(seen[0]),
                           "the retry must ask for a bigger budget")

    def test_a_real_failure_rotates_to_the_next_key(self):
        answers = [json.dumps({"error": "quota exceeded"}), _ok("Key two wrote this fine.")]
        used = []

        def fake_run(argv, input=None, **kw):
            used.append(input)
            return FakeProc(answers[len(used) - 1])
        with patch.object(rw.subprocess, "run", fake_run):
            text, meta = rw.write("write something")
        self.assertIn("Key two wrote", text)
        self.assertEqual(meta["slot"], 2)
        self.assertEqual(len(used), 2)

    def test_three_failures_park_a_key_and_it_stops_being_tried(self):
        calls = {"n": 0}

        def fake_run(argv, input=None, **kw):
            calls["n"] += 1
            return FakeProc(json.dumps({"error": "quota exceeded"}))
        with patch.object(rw.subprocess, "run", fake_run):
            for _ in range(4):
                rw.write("x")
        self.assertLessEqual(calls["n"], 4 * rw.PARK_AFTER_FAILS + 4)
        status = rw.pool_status()
        self.assertTrue(status["parked_slots"], "some slot must be parked by now")

    def test_no_keys_configured_is_reported_not_raised(self):
        rw._env = lambda name, default="": default
        text, meta = rw.write("anything")
        self.assertIsNone(text)
        self.assertIn("no RADOX_API_KEY", meta["error"])

    def test_max_tokens_is_never_below_the_reasoning_floor(self):
        seen = {}

        def fake_run(argv, input=None, **kw):
            seen["cfg"] = input
            return FakeProc(_ok("ok enough text to be usable here"))
        with patch.object(rw.subprocess, "run", fake_run):
            rw.write("x", max_tokens=30)
        self.assertIn(str(rw.MIN_TOKENS), seen["cfg"],
                      "30 tokens returns content=null from these endpoints")


if __name__ == "__main__":
    unittest.main()
