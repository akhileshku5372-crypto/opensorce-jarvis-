"""Phase 7 - read back what is ACTUALLY on screen, so JARVIS stops guessing.

The bug this fixes, from the owner's transcript:
    "open notepad and write an essay ..."  ->  "Opening notepad. typed: '...'"
    "notepad me kya likha hai"             ->  no idea / the brain guessed

Typing into a window is not the same as knowing what landed in it. The typed
string went into the composer, some characters were dropped by the keystroke
synthesiser (measured: "Environment protects us from pollution" arrived as
"Environment ects us from pollution"), and JARVIS reported the string it INTENDED
to type. So the answer to "what did you write" was a fiction.

This module reads the real text of a foreground window, preferring UIA:
  1. `Document` / `Edit` control's legacy `Value` property
  2. the window's own `WM_GETTEXT`
  3. Ctrl+A / Ctrl+C into a temporary clipboard (restored afterwards)
Nothing is inferred, and a failure is reported as a failure.
"""
from __future__ import annotations

import ctypes
import sys
import time

MAX_CHARS = 1200
SETTLE_S = 0.6

# Windows that hold a real document and are worth reading back.
READABLE_CLASSES = ("notepad", "wordpad", "chrome_widgetwin_1",
                    "applicationframewindow", "mintnotepad")


def available() -> tuple:
    """(ok, why) - the read-back stack actually being importable."""
    if sys.platform != "win32":
        return (False, "sirf Windows pe chalta hai")
    try:
        from pywinauto import Desktop  # noqa: F401
    except Exception as exc:
        return (False, "pywinauto missing (%s)" % type(exc).__name__)
    return (True, "ready")


def foreground_window():
    """The hwnd the user is actually looking at."""
    if sys.platform != "win32":
        return 0
    try:
        return ctypes.windll.user32.GetForegroundWindow()
    except Exception:
        return 0


def foreground_title() -> str:
    hwnd = foreground_window()
    if not hwnd:
        return ""
    try:
        user32 = ctypes.windll.user32
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 2)
        user32.GetWindowTextW(hwnd, buf, length + 2)
        return str(buf.value or "")
    except Exception:
        return ""


def _uia_text(hwnd) -> str:
    """Best text from a UIA Document/Edit, or '' when the app exposes none."""
    from pywinauto import Desktop
    win = Desktop(backend="uia").window(handle=hwnd)
    best = ""
    for e in win.descendants():
        try:
            if e.element_info.control_type not in ("Document", "Edit"):
                continue
        except Exception:
            continue
        text = ""
        try:
            # Measured 2026-10-19: this is what Notepad's Document actually
            # answers. `iface_text.GetDocumentRange` raises AttributeError on it
            # and `get_value()` does not exist, so the legacy Value property is
            # the working accessor - trying the others first only costs time.
            value = e.legacy_properties().get("Value")
            if value:
                text = str(value)
        except Exception:
            pass
        if not text:
            try:
                text = str(e.window_text() or "")
            except Exception:
                continue
        if len(text) > len(best):
            best = text
    return best


def _title_only(text: str, title: str) -> bool:
    """True when `text` is just the window title repeated, not real content.

    Measured 2026-10-19: an EMPTY Notepad has a Document whose only text is
    "Untitled - Notepad" - the title, not anything the user typed. Reporting that
    as "notepad me likha hai: Untitled - Notepad" is a confident lie, so a title
    echo is treated as "nothing written" instead.
    """
    left = (text or "").strip().casefold()
    right = (title or "").strip().casefold()
    if not left:
        return True
    # Notepad prefixes the title with "*" once the buffer is modified, so the
    # marker may appear on EITHER side of the comparison.
    left = left.lstrip("*").strip()
    right = right.lstrip("*").strip()
    if not left:
        return True
    return bool(right) and left == right


def _wm_gettext(hwnd) -> str:
    try:
        user32 = ctypes.windll.user32
        buf = ctypes.create_unicode_buffer(MAX_CHARS + 2)
        user32.SendMessageW(hwnd, 0x000D, MAX_CHARS + 2, buf)   # WM_GETTEXT
        return str(buf.value or "")
    except Exception:
        return ""


def _clipboard_read() -> str:
    """Ctrl+A / Ctrl+C out of the focused window, restoring the old clipboard."""
    try:
        import pyperclip
    except Exception:
        return ""
    previous = ""
    try:
        previous = pyperclip.paste() or ""
    except Exception:
        pass
    try:
        import pyautogui
        pyautogui.hotkey("ctrl", "a")
        time.sleep(0.4)
        pyautogui.hotkey("ctrl", "c")
        time.sleep(0.8)
        got = pyperclip.paste() or ""
    except Exception:
        got = ""
    finally:
        try:
            if previous:
                pyperclip.copy(previous)
        except Exception:
            pass
    return got


def read_screen_text(allow_clipboard: bool = True) -> dict:
    """Real text of the foreground window.

    Returns {"ok", "text", "how", "title"}. `ok` is False when nothing could be
    read - JARVIS then says so rather than inventing an answer.
    """
    ok, why = available()
    if not ok:
        return {"ok": False, "error": why}
    hwnd = foreground_window()
    if not hwnd:
        return {"ok": False, "error": "koi active window nahi mila"}
    title = foreground_title()
    try:
        text = _uia_text(hwnd)
    except Exception:
        text = ""
    how = "UIA" if text else ""
    # A Document that only echoes the window title means nothing was typed.
    if text and _title_only(text, title):
        text, how = "", ""
    if not text:
        raw = _wm_gettext(hwnd)
        if raw and not _title_only(raw, title):
            text, how = raw, "WM_GETTEXT"
    if not text and allow_clipboard:
        raw = _clipboard_read()
        if raw and not _title_only(raw, title):
            text, how = raw, "clipboard"
    text = (text or "").strip()
    if not text:
        return {"ok": False, "empty": True, "title": title,
                "error": "'%s' abhi khaali hai - kuch likha nahi hai"
                         % (title or "is window")}
    return {"ok": True, "text": text[:MAX_CHARS],
            "how": how or "unknown", "title": title,
            "truncated": len(text) > MAX_CHARS}


def spoken(out: dict) -> str:
    """One honest sentence about what is really on screen."""
    if not out.get("ok"):
        error = str(out.get("error", "text nahi mila"))
        if out.get("empty"):
            return "Sir, %s" % error
        return "Sir, %s. Kuch nahi padha, isliye kuch nahi bata raha." % error
    text = out.get("text", "")
    said = text if len(text) <= 220 else text[:220] + " ..."
    tail = " (text lamba hai, pehla hissa bol raha hoon)" \
        if out.get("truncated") or len(text) > 220 else ""
    return ("Sir, '%s' me likha hai: %s%s"
            % (out.get("title") or "window", said, tail))